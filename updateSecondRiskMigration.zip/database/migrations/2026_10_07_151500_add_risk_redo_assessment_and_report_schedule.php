<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\QueryException;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        if (!Schema::hasTable('risk_redo_assessment_requests')) {
            Schema::create('risk_redo_assessment_requests', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('risk_id');
                $table->string('status', 40)->default('pending_risk_team'); // pending_risk_team|in_progress|completed|rejected
                $table->text('notes')->nullable();
                $table->unsignedBigInteger('started_by')->nullable();
                $table->unsignedBigInteger('reviewed_by')->nullable();
                $table->timestamp('reviewed_at')->nullable();
                $table->text('review_comments')->nullable();
                $table->timestamps();
            });
        }

        $this->addForeignKeyIfPossible('risk_redo_assessment_requests', 'risk_id', 'risks', 'cascade');
        $this->addForeignKeyIfPossible('risk_redo_assessment_requests', 'started_by', 'users', 'set null');
        $this->addForeignKeyIfPossible('risk_redo_assessment_requests', 'reviewed_by', 'users', 'set null');

        if (!Schema::hasTable('risk_redo_assessment_evidences')) {
            Schema::create('risk_redo_assessment_evidences', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('redo_request_id');
                $table->unsignedBigInteger('action_plan_id')->nullable();
                $table->string('file_path')->nullable();
                $table->string('file_name')->nullable();
                $table->text('comment')->nullable();
                $table->timestamps();
            });
        }

        $this->addForeignKeyIfPossible('risk_redo_assessment_evidences', 'redo_request_id', 'risk_redo_assessment_requests', 'cascade', 'redo_ev_req_fk');
        $this->addForeignKeyIfPossible('risk_redo_assessment_evidences', 'action_plan_id', 'mitigation_action_plans', 'set null', 'redo_ev_ap_fk');

        if (!Schema::hasTable('risk_report_schedules')) {
            Schema::create('risk_report_schedules', function (Blueprint $table) {
                $table->id();
                $table->string('frequency', 20); // weekly|monthly|quarterly
                $table->string('report_type', 50); // register|assessment_treatment|acceptance
                $table->json('recipient_roles')->nullable(); // risk_team|ciso|steering
                $table->boolean('is_active')->default(true);
                $table->timestamp('last_run_at')->nullable();
                $table->timestamps();
            });

            // Seed default schedules (KSU #6)
            \DB::table('risk_report_schedules')->insert([
                [
                    'frequency' => 'weekly',
                    'report_type' => 'register',
                    'recipient_roles' => json_encode(['risk_team']),
                    'is_active' => true,
                    'created_at' => now(),
                    'updated_at' => now(),
                ],
                [
                    'frequency' => 'monthly',
                    'report_type' => 'assessment_treatment',
                    'recipient_roles' => json_encode(['risk_team', 'ciso']),
                    'is_active' => true,
                    'created_at' => now(),
                    'updated_at' => now(),
                ],
                [
                    'frequency' => 'quarterly',
                    'report_type' => 'acceptance',
                    'recipient_roles' => json_encode(['risk_team', 'ciso', 'steering']),
                    'is_active' => true,
                    'created_at' => now(),
                    'updated_at' => now(),
                ],
            ]);
        }
    }

    /**
     * Skip the foreign key when MySQL/MariaDB denies REFERENCES (error 1142).
     */
    private function addForeignKeyIfPossible($table, $column, $referenced, $onDelete, $name = null)
    {
        if (!Schema::hasTable($table) || !Schema::hasTable($referenced) || !Schema::hasColumn($table, $column)) {
            return;
        }

        if ($this->foreignKeyExists($table, $column)) {
            return;
        }

        try {
            Schema::table($table, function (Blueprint $blueprint) use ($column, $referenced, $onDelete, $name) {
                $foreign = $blueprint->foreign($column, $name)->references('id')->on($referenced);
                if ($onDelete === 'cascade') {
                    $foreign->cascadeOnDelete();
                } else {
                    $foreign->nullOnDelete();
                }
            });
        } catch (QueryException $e) {
            $code = isset($e->errorInfo[1]) ? (int) $e->errorInfo[1] : 0;
            if ($code === 1142 || strpos($e->getMessage(), 'REFERENCES command denied') !== false) {
                return;
            }

            throw $e;
        }
    }

    private function foreignKeyExists($table, $column)
    {
        $connection = Schema::getConnection();
        if ($connection->getDriverName() !== 'mysql') {
            return false;
        }

        $rows = $connection->select(
            'select CONSTRAINT_NAME from information_schema.KEY_COLUMN_USAGE
             where TABLE_SCHEMA = ? and TABLE_NAME = ? and COLUMN_NAME = ? and REFERENCED_TABLE_NAME is not null
             limit 1',
            [$connection->getDatabaseName(), $table, $column]
        );

        return !empty($rows);
    }

    public function down()
    {
        Schema::dropIfExists('risk_redo_assessment_evidences');
        Schema::dropIfExists('risk_redo_assessment_requests');
        Schema::dropIfExists('risk_report_schedules');
    }
};
