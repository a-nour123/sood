<?php

namespace App\Imports;

use App\Models\Family;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\Importable;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;

class DomainsImport implements
    ToCollection,
    WithHeadingRow,
    WithValidation
{
    use Importable;

    /**
     * Mapping of columns from the import file to database columns.
     *
     * @var array
     */
    public $columnsMapping;

    /**
     * Constructor to set the columns mapping.
     *
     * @param array $columnsMapping
     */
    public function __construct($columnsMapping)
    {
        $this->columnsMapping = $columnsMapping;
    }

    public function collection(Collection $rows)
    {
        foreach ($rows as $row) {
            $nameAr = $row[$this->columnsMapping['name_ar']] ?? '';
            $nameEn = $row[$this->columnsMapping['name_en']] ?? '';
            $name = ['en' => $nameEn, 'ar' => $nameAr];

            // Check if the family already exists (by both en and ar names)
            $existingFamily = Family::where('name->en', $nameEn)
                ->orWhere('name->ar', $nameAr)
                ->first();

            // Update only if the record exists
            if ($existingFamily) {
                $existingFamily->update([
                    'name' => $name,
                    // 'order' => $row[$this->columnsMapping['order']] ?? '',
                    // 'parent_id' => $row[$this->columnsMapping['parent']] ?? null,
                ]);
            }
            // If it doesn't exist, do nothing (skip the row)
        }
    }

    public function rules(): array
    {
        $name_en = $this->columnsMapping['name_en'] ?? 'name_en';
        $name_ar = $this->columnsMapping['name_ar'] ?? 'name_ar';
        return [
            $name_en => ['required', 'max:255'],
            $name_ar => ['required', 'max:255'],
        ];
    }
}