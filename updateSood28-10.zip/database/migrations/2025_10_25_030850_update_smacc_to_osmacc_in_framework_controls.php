<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class UpdateSmaccToOsmaccInFrameworkControls extends Migration
{
        /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Process in batches to avoid memory issues for large tables
        $batchSize = 100;
        
        // Update records in batches
        DB::table('framework_controls')
            ->where(function ($query) {
                $query->where('short_name', 'LIKE', '%SMACC%')
                      ->orWhere('long_name', 'LIKE', '%SMACC%')
                      ->orWhere('control_number', 'LIKE', '%SMACC%');
            })
            ->orderBy('id')
            ->chunkById($batchSize, function ($controls) {
                foreach ($controls as $control) {
                    $updateData = [];
                    
                    // Check and update each column if it contains SMACC
                    if (str_contains($control->short_name, 'SMACC')) {
                        $updateData['short_name'] = str_replace('SMACC', 'OSMACC', $control->short_name);
                    }
                    
                    if (str_contains($control->long_name, 'SMACC')) {
                        $updateData['long_name'] = str_replace('SMACC', 'OSMACC', $control->long_name);
                    }
                    
                    if (str_contains($control->control_number, 'SMACC')) {
                        $updateData['control_number'] = str_replace('SMACC', 'OSMACC', $control->control_number);
                    }
                    
                    // Only update if there are changes
                    if (!empty($updateData)) {
                        DB::table('framework_controls')
                            ->where('id', $control->id)
                            ->update($updateData);
                    }
                }
            });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        // Reverse the changes
        $batchSize = 100;
        
        DB::table('framework_controls')
            ->where(function ($query) {
                $query->where('short_name', 'LIKE', '%OSMACC%')
                      ->orWhere('long_name', 'LIKE', '%OSMACC%')
                      ->orWhere('control_number', 'LIKE', '%OSMACC%');
            })
            ->orderBy('id')
            ->chunkById($batchSize, function ($controls) {
                foreach ($controls as $control) {
                    $updateData = [];
                    
                    if (str_contains($control->short_name, 'OSMACC')) {
                        $updateData['short_name'] = str_replace('OSMACC', 'SMACC', $control->short_name);
                    }
                    
                    if (str_contains($control->long_name, 'OSMACC')) {
                        $updateData['long_name'] = str_replace('OSMACC', 'SMACC', $control->long_name);
                    }
                    
                    if (str_contains($control->control_number, 'OSMACC')) {
                        $updateData['control_number'] = str_replace('OSMACC', 'SMACC', $control->control_number);
                    }
                    
                    if (!empty($updateData)) {
                        DB::table('framework_controls')
                            ->where('id', $control->id)
                            ->update($updateData);
                    }
                }
            });
    }
}