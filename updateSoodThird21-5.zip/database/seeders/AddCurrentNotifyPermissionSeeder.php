<?php

namespace Database\Seeders;

use App\Models\Permission;
use App\Models\PermissionGroup;
use App\Models\RoleResponsibility;
use App\Models\Subgroup;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class AddCurrentNotifyPermissionSeeder extends Seeder
{
    public function run()
    {
        $permissionGroups = PermissionGroup::pluck('id', 'name');

        if (!isset($permissionGroups['configuration'])) {
            return;
        }

        $governanceId = $permissionGroups['configuration'];

        $subgroup = Subgroup::firstOrCreate([
            "name" => 'current_notify',
            "permission_group_id" => $governanceId
        ]);

        $permissions = [
            [
                'key' => 'current_notify.list',
                'name' => 'list',
                'subgroup_id' => $subgroup->id,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'key' => 'current_notify.create',
                'name' => 'create',
                'subgroup_id' => $subgroup->id,
                'created_at' => now(),
                'updated_at' => now(),
            ]
        ];

        // Insert permissions if not exists
        foreach ($permissions as $permissionData) {
            $permission = Permission::firstOrCreate(
                ['key' => $permissionData['key']],
                $permissionData
            );

            // Assign permission to role_id = 1
            RoleResponsibility::firstOrCreate([
                'role_id' => 1,
                'permission_id' => $permission->id,
            ]);
        }
    }
}