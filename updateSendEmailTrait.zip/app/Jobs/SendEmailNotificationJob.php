<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;
use PHPMailer\PHPMailer\PHPMailer;
use Exception;
use Illuminate\Support\Facades\Log;

class SendEmailNotificationJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $userId;
    protected $subject;
    protected $body;

    /**
     * The number of times the job may be attempted.
     *
     * @var int
     */
    public $tries = 3;

    /**
     * The number of seconds to wait before retrying the job.
     *
     * @var int
     */
    public $backoff = 10;

    /**
     * Create a new job instance.
     */
    public function __construct($userId, $subject, $body)
    {
        $this->userId = $userId;
        $this->subject = $subject;
        $this->body = $body;
    }

    /**
     * Execute the job.
     */
    public function handle()
    {
        try {
            $email_to = DB::table('users')->where('id', $this->userId)->value('email');
            
            if (!$email_to) {
                Log::warning("User email not found for user ID: {$this->userId}");
                return;
            }

            $email_config = DB::table('email_config')->first();
            
            if (!$email_config) {
                Log::error("Email configuration not found");
                return;
            }

            $mail = new PHPMailer(true);
            $mail->CharSet = 'UTF-8';

            $mail->isSMTP();
            $mail->isHTML(true);
            $mail->SMTPDebug = 0;
            $mail->Mailer = "smtp";
            $mail->SMTPAuth = false;
            $mail->Port = $email_config->smtp_port;
            $mail->Host = $email_config->smtp_server;
            $mail->Username = $email_config->smtp_username;
            $mail->Password = base64_decode($email_config->smtp_password);
            $mail->SMTPSecure = $email_config->ssl_tls;
            $mail->addAddress($email_to);
            $mail->setFrom($email_config->smtp_from_username, $email_config->smtp_username);
            $mail->Subject = $this->subject;
            $mail->Body = $this->body;

            $mail->SMTPOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                )
            );

            $mail->send();
            
            Log::info("Email sent successfully to user ID: {$this->userId}");

        } catch (Exception $e) {
            Log::error("Email sending failed for user ID: {$this->userId}. Error: " . $e->getMessage());
            
            // Rethrow the exception to trigger retry mechanism
            throw $e;
        }
    }

    /**
     * Handle a job failure.
     */
    public function failed(Exception $exception)
    {
        Log::error("Email job failed permanently for user ID: {$this->userId}. Error: " . $exception->getMessage());
    }
}