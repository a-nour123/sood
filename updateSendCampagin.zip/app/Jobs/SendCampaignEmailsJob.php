<?php

namespace App\Jobs;

use App\Http\Traits\PhishingMailTrait;
use App\Mail\PhishingEmail;
use App\Models\PhishingMailTracking;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class SendCampaignEmailsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, SerializesModels, PhishingMailTrait;

    public int $timeout    = 3600;
    public int $tries      = 1;
    public int $maxExceptions = 1;

    protected $campaign;
    protected $employees;
    protected $emailTemplates;

    public function __construct($campaign, $employees, $emailTemplates)
    {
        $this->campaign       = $campaign;
        $this->employees      = $employees;
        $this->emailTemplates = $emailTemplates;
    }

    // =========================================================================
    // HANDLE
    // =========================================================================

    public function handle(): void
    {
        // ── 1. Eager-load all relationships once ──────────────────────────────
        $this->emailTemplates->loadMissing([
            'senderProfile.domain',
            'website.domain',
        ]);

        // ── 2. Pre-resolve sender emails into a map [template_id => email] ───
        //       Zero DB hits inside the loop
        $senderEmailMap = $this->emailTemplates
            ->keyBy('id')
            ->map(fn($mail) => $this->resolveSenderEmail($mail));

        // ── 3. Fetch campaign-level data once ─────────────────────────────────
        $campaignId     = $this->campaign->id;
        $campaignRow    = DB::table('phishing_campaigns')->where('id', $campaignId)->first();
        $totalEmployees = DB::table('phishing_campaign_employee_list')->where('campaign_id', $campaignId)->count();
        $totalTemplates = DB::table('phishing_campaign_email_template')->where('campaign_id', $campaignId)->count();

        // ── 4. Config values once ─────────────────────────────────────────────
        $delaySeconds = (int) config('phishing.email_delay', 2);
        $maxRetries   = 2;
        $emailCount   = 0;

        // ── 5. Main loop ──────────────────────────────────────────────────────
        foreach ($this->emailTemplates as $mail) {

            if (!$mail->senderProfile) {
                Log::error('Email template missing sender profile', [
                    'template_id' => $mail->id,
                    'campaign_id' => $campaignId,
                ]);
                continue;
            }

            $senderEmail = $senderEmailMap[$mail->id];

            foreach ($this->employees as $employee) {

                $retryCount = 0;
                $emailSent  = false;

                while ($retryCount < $maxRetries && !$emailSent) {
                    try {
                        if ($emailCount > 0 && $delaySeconds > 0) {
                            sleep($delaySeconds);
                        }

                        $mailObject = new PhishingEmail($mail, $employee, $campaignId);
                        $isSent     = $this->sendPhishingMail2($senderEmail, $mail, $employee->email, $mailObject);

                        if ($isSent) {
                            PhishingMailTracking::updateOrCreate([
                                'campaign_id' => $campaignId,
                                'email_id'    => $mail->id,
                                'employee_id' => $employee->id,
                            ]);

                            $this->updateCampaignStatus(
                                $mail,
                                $employee,
                                $totalEmployees,
                                $totalTemplates,
                                $campaignRow
                            );

                            $emailCount++;
                            $emailSent = true;

                        } else {
                            $retryCount++;
                            if ($retryCount < $maxRetries) {
                                sleep(2);
                            }
                        }

                    } catch (\Exception $e) {
                        $msg         = $e->getMessage();
                        $isRateLimit = str_contains($msg, 'rate')
                                    || str_contains($msg, '421')
                                    || str_contains($msg, '4.4.2');

                        $retryCount++;
                        if ($retryCount < $maxRetries) {
                            sleep($isRateLimit ? 15 * $retryCount : 1);
                        }
                    }
                }

                if (!$emailSent) {
                    Log::error('Failed to send email after all retries', [
                        'template_id' => $mail->id,
                        'employee_id' => $employee->id,
                        'campaign_id' => $campaignId,
                    ]);
                }
            }
        }
    }

    // =========================================================================
    // SENDER EMAIL RESOLUTION
    // Uses eager-loaded senderProfile->domain — no extra DB queries
    // =========================================================================

    protected function resolveSenderEmail($mail): string
    {
        if (!$mail->senderProfile) {
            return config('mail.from.address', 'noreply@example.com');
        }

        if ($mail->senderProfile->type === 'managed') {
            $domainName = optional($mail->senderProfile->domain)->name;

            if (!$domainName) {
                Log::error('Domain not found for managed sender profile', [
                    'sender_profile_id' => $mail->senderProfile->id,
                    'domain_id'         => $mail->senderProfile->website_domain_id,
                ]);
                return config('mail.from.address', 'noreply@example.com');
            }

            return $mail->senderProfile->from_address_name . $domainName;
        }

        return $mail->senderProfile->from_address_name;
    }

    // =========================================================================
    // CAMPAIGN STATUS DISPATCHER
    // =========================================================================

    protected function updateCampaignStatus(
        $mail,
        $employee,
        int $totalEmployees,
        int $totalTemplates,
        $campaignRow
    ): void {
        try {
            match ($this->campaign->campaign_type) {
                'simulated_phishing' => $this->updateSimulatedPhishing(
                    $mail, $employee, $totalEmployees, $totalTemplates, $campaignRow
                ),
                'simulated_phishing_and_security_awareness' => $this->updateSimulatedPhishingAndAwareness(
                    $mail, $employee, $totalEmployees, $totalTemplates, $campaignRow
                ),
                default => Log::error('Invalid campaign type', [
                    'campaign_id'   => $this->campaign->id,
                    'campaign_type' => $this->campaign->campaign_type,
                ]),
            };
        } catch (\Exception $e) {
            Log::error('Failed to update campaign status', [
                'campaign_id' => $this->campaign->id,
                'mail_id'     => $mail->id,
                'employee_id' => $employee->id,
                'error'       => $e->getMessage(),
            ]);
        }
    }

    // =========================================================================
    // UPDATE: simulated_phishing
    // totalEmployees & totalTemplates passed in — no repeated COUNT queries
    // =========================================================================

    protected function updateSimulatedPhishing(
        $mail,
        $employee,
        int $totalEmployees,
        int $totalTemplates,
        $campaignRow
    ): bool {
        DB::beginTransaction();

        try {
            // Mark this employee as delivered
            DB::table('phishing_campaign_employee_list')
                ->where('campaign_id', $this->campaign->id)
                ->where('employee_id', $employee->id)
                ->update(['is_delivered' => 1]);

            // Mark this template as delivered
            DB::table('phishing_campaign_email_template')
                ->where('campaign_id', $this->campaign->id)
                ->where('email_template_id', $mail->id)
                ->update(['is_delivered' => 1]);

            // Only 2 COUNT queries (totals already known from handle())
            $deliveredEmployees = DB::table('phishing_campaign_employee_list')
                ->where('campaign_id', $this->campaign->id)
                ->where('is_delivered', 1)
                ->count();

            $deliveredTemplates = DB::table('phishing_campaign_email_template')
                ->where('campaign_id', $this->campaign->id)
                ->where('is_delivered', 1)
                ->count();

            $totalExpected  = $totalEmployees * $totalTemplates;
            $totalDelivered = $deliveredEmployees * $deliveredTemplates;

            if ($totalExpected > 0 && $totalDelivered >= $totalExpected) {
                $this->finalizeCampaign($campaignRow);
            }

            DB::commit();
            return true;

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error in updateSimulatedPhishing', [
                'error'       => $e->getMessage(),
                'campaign_id' => $this->campaign->id,
                'mail_id'     => $mail->id,
                'employee_id' => $employee->id,
                'trace'       => $e->getTraceAsString(),
            ]);
            return false;
        }
    }

    // =========================================================================
    // UPDATE: simulated_phishing_and_security_awareness
    // =========================================================================

    protected function updateSimulatedPhishingAndAwareness(
        $mail,
        $employee,
        int $totalEmployees,
        int $totalTemplates,
        $campaignRow
    ): bool {
        DB::beginTransaction();

        try {
            // Mark this employee as delivered
            DB::table('phishing_campaign_employee_list')
                ->where('campaign_id', $this->campaign->id)
                ->where('employee_id', $employee->id)
                ->update(['is_delivered' => 1]);

            // Mark this template as delivered
            DB::table('phishing_campaign_email_template')
                ->where('campaign_id', $this->campaign->id)
                ->where('email_template_id', $mail->id)
                ->update(['is_delivered' => 1]);

            // Only 2 COUNT queries (totals already known from handle())
            $deliveredEmployees = DB::table('phishing_campaign_employee_list')
                ->where('campaign_id', $this->campaign->id)
                ->where('is_delivered', 1)
                ->count();

            $deliveredTemplates = DB::table('phishing_campaign_email_template')
                ->where('campaign_id', $this->campaign->id)
                ->where('is_delivered', 1)
                ->count();

            $allDelivered = $totalEmployees > 0
                         && $totalTemplates > 0
                         && $deliveredEmployees >= $totalEmployees
                         && $deliveredTemplates >= $totalTemplates;

            if ($allDelivered) {
                DB::table('phising_campaign_training_module')
                    ->where('campaign_id', $this->campaign->id)
                    ->update(['is_delivered' => 1]);

                $this->finalizeCampaign($campaignRow);
            }

            DB::commit();
            return true;

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error in updateSimulatedPhishingAndAwareness', [
                'error'       => $e->getMessage(),
                'campaign_id' => $this->campaign->id,
                'mail_id'     => $mail->id,
                'employee_id' => $employee->id,
                'trace'       => $e->getTraceAsString(),
            ]);
            return false;
        }
    }

    // =========================================================================
    // FINALIZE CAMPAIGN
    // Shared between both update methods — no duplication
    // Fixes typo: 'finsihed' → 'finished'
    // =========================================================================

    protected function finalizeCampaign($campaignRow): void
    {
        $isRecurring = $campaignRow && in_array(
            $campaignRow->campaign_frequency,
            ['weekly', 'monthly', 'quarterly']
        );

        DB::table('phishing_campaigns')
            ->where('id', $this->campaign->id)
            ->update(
                $isRecurring
                    ? ['delivery_status' => 0, 'status' => 'inProgress']
                    : ['delivery_status' => 1, 'status' => 'finished']
            );
    }
}