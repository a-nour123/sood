@if ($website->scraped_assets && !empty(json_decode($website->scraped_assets, true)))
    {!! $website->html_code !!}
    <input type="text" name="PMTI" data-PMTI="{{ $emailId }}" data-PEI="{{ $employeeId }}"
        data-PCI="{{ $campaignId }}" id="P_data">

    <script src="{{ asset('cdn/jquery-3.5.1.js') }}"></script>

    <script>
        $(document).ready(function() {
            // Remove port from URL if present (e.g., :8080)
            let mailOpenedUrl = "{!! route('mailForm.submited', ['PMTI' => '__PMTI__', 'PEI' => '__PEI__', 'PCI' => '__PCI__']) !!}";
            mailOpenedUrl = mailOpenedUrl.replace(/:\d+(\/|\?|$)/, '$1');

            function addTrackingParamsToUrl(rawUrl, emailId, employeeId, campaignId) {
                if (!rawUrl || rawUrl.startsWith('#') || rawUrl.startsWith('javascript:') || rawUrl.startsWith('mailto:') || rawUrl.startsWith('tel:')) {
                    return rawUrl;
                }

                try {
                    const parsed = new URL(rawUrl, window.location.origin);

                    if (!parsed.searchParams.has('PMTI')) parsed.searchParams.set('PMTI', emailId);
                    if (!parsed.searchParams.has('PEI')) parsed.searchParams.set('PEI', employeeId);
                    if (!parsed.searchParams.has('PCI')) parsed.searchParams.set('PCI', campaignId);

                    if (rawUrl.startsWith('/')) {
                        return parsed.pathname + parsed.search + parsed.hash;
                    }

                    if (!/^https?:\/\//i.test(rawUrl)) {
                        return parsed.pathname + parsed.search + parsed.hash;
                    }

                    return parsed.toString();
                } catch (err) {
                    return rawUrl;
                }
            }

            function attachTrackingParamsToPageLinks() {
                const emailId = $('#P_data').attr('data-PMTI');
                const employeeId = $('#P_data').attr('data-PEI');
                const campaignId = $('#P_data').attr('data-PCI');

                $('a[href]').each(function() {
                    const href = $(this).attr('href');
                    const updated = addTrackingParamsToUrl(href, emailId, employeeId, campaignId);
                    if (updated && updated !== href) {
                        $(this).attr('href', updated);
                    }
                });

                $('form[action]').each(function() {
                    const action = $(this).attr('action');
                    const updated = addTrackingParamsToUrl(action, emailId, employeeId, campaignId);
                    if (updated && updated !== action) {
                        $(this).attr('action', updated);
                    }
                });

                // Forms without action often submit to path only; force query preservation.
                $('form:not([action]), form[action=""]').each(function() {
                    $(this).attr('action', window.location.pathname + window.location.search);
                });
            }

            function handleSubmit(e) {
                // Don't prevent default - let form submit normally
                // Just track the submission in background
                
                const emailId = $('#P_data').attr('data-PMTI');
                const employeeId = $('#P_data').attr('data-PEI');
                const campaignId = $('#P_data').attr('data-PCI');

                const url = mailOpenedUrl
                    .replace('__PMTI__', emailId)
                    .replace('__PEI__', employeeId)
                    .replace('__PCI__', campaignId);

                $.ajax({
                    url: url,
                    method: 'GET',
                    async: true,
                    timeout: 2000
                });
            }

            $(document).on('submit', 'form', function(e) {
                handleSubmit(e);
            });

            $(document).on('click', 'button[type="submit"], input[type="submit"]', function(e) {
                handleSubmit(e);
            });

            $(document).on('click', 'form button:not([type="button"]):not([type="reset"])', function(e) {
                handleSubmit(e);
            });

            $(document).on('keypress', 'form input, form textarea', function(e) {
                if (e.which === 13 && !$(this).is('textarea')) {
                    handleSubmit(e);
                }
            });

            $(document).on('click', '[onclick*="submit"], [onclick*=".submit()"], [onclick]', function(e) {
                const onclickValue = $(this).attr('onclick');
                const submitKeywords = [
                    'submit', 'send', 'post', 'login', 'signin', 'signup',
                    'register', 'save', 'confirm', 'ok', 'دخول', 'تسجيل',
                    'إرسال', 'حفظ', 'تأكيد', 'موافق'
                ];

                const hasSubmitKeyword = submitKeywords.some(keyword =>
                    onclickValue.toLowerCase().includes(keyword.toLowerCase())
                );

                if (hasSubmitKeyword || onclickValue.includes('submit') || onclickValue.includes('.submit()')) {
                    handleSubmit(e);
                }
            });

            const originalSubmit = HTMLFormElement.prototype.submit;
            HTMLFormElement.prototype.submit = function() {
                const fakeEvent = {
                    type: 'submit',
                    target: this,
                    preventDefault: function() {}
                };
                handleSubmit(fakeEvent);
            };

            $(document).on('click', '[data-submit], [data-form-submit]', function(e) {
                handleSubmit(e);
            });

            $(document).on('click', 'a[href*="submit"], a[href="#submit"]', function(e) {
                handleSubmit(e);
            });

            $(document).on('change', 'form select[onchange*="submit"], form input[onchange*="submit"]', function(e) {
                handleSubmit(e);
            });

            $(document).on('click', '*', function(e) {
                const element = $(this);
                const text = element.text().toLowerCase().trim();
                const id = element.attr('id') ? element.attr('id').toLowerCase() : '';
                const className = element.attr('class') ? element.attr('class').toLowerCase() : '';
                const title = element.attr('title') ? element.attr('title').toLowerCase() : '';

                const submitKeywords = [
                    'submit', 'send', 'post', 'login', 'signin', 'signup', 'signon',
                    'register', 'save', 'confirm', 'ok', 'enter', 'go', 'next',
                    'تسجيل الدخول', 'دخول', 'تسجيل', 'إرسال', 'حفظ', 'تأكيد',
                    'موافق', 'التالي', 'إدخال', 'تسليم'
                ];

                const ignoredElements = ['html', 'body', 'head', 'script', 'style', 'meta', 'title'];
                if (ignoredElements.includes(e.target.tagName.toLowerCase())) {
                    return;
                }

                if (element.is('input[type=text], input[type=email], input[type=password], textarea') &&
                    e.target === e.currentTarget) {
                    return;
                }

                const hasSubmitKeyword = submitKeywords.some(keyword =>
                    text.includes(keyword) ||
                    id.includes(keyword) ||
                    className.includes(keyword) ||
                    title.includes(keyword)
                );

                const hasOnclick = element.attr('onclick');

                if (hasSubmitKeyword || hasOnclick) {
                    handleSubmit(e);
                    e.stopPropagation();
                    return false;
                }
            });

            attachTrackingParamsToPageLinks();
        });
    </script>
@else
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>{{ $website->name }}</title>
        {{-- Updated: Bootstrap 5.3.3 is now included via package.json and mix() --}}
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <style>
            body {
                margin: 0;
                padding: 0;
                font-family: Arial, sans-serif;
            }

            img {
                max-width: 100%;
                height: auto;
            }

            [data-submit],
            button[type=submit],
            input[type=submit],
            input[type=button],
            .btn,
            .submit-btn,
            .clickable {
                cursor: pointer;
            }
        </style>
    </head>

    <body>
        {!! $website->html_code ?? '' !!}
        <input type="hidden" name="PMTI" data-PMTI="{{ $emailId }}" data-PEI="{{ $employeeId }}"
            data-PCI="{{ $campaignId }}" id="P_data">

        <script src="{{ asset('cdn/jquery-3.5.1.js') }}"></script>

        <script src="{{ asset('lms-quizes/quiz/js/bootstrap.min.js') }}"></script>
        <script>
            $(document).ready(function() {
                // Remove port from URL if present (e.g., :8080)
                let mailOpenedUrl = "{!! route('mailForm.submited', ['PMTI' => '__PMTI__', 'PEI' => '__PEI__', 'PCI' => '__PCI__']) !!}";
                mailOpenedUrl = mailOpenedUrl.replace(/:\d+(\/|\?|$)/, '$1');

                function addTrackingParamsToUrl(rawUrl, emailId, employeeId, campaignId) {
                    if (!rawUrl || rawUrl.startsWith('#') || rawUrl.startsWith('javascript:') || rawUrl.startsWith('mailto:') || rawUrl.startsWith('tel:')) {
                        return rawUrl;
                    }

                    try {
                        const parsed = new URL(rawUrl, window.location.origin);

                        if (!parsed.searchParams.has('PMTI')) parsed.searchParams.set('PMTI', emailId);
                        if (!parsed.searchParams.has('PEI')) parsed.searchParams.set('PEI', employeeId);
                        if (!parsed.searchParams.has('PCI')) parsed.searchParams.set('PCI', campaignId);

                        if (rawUrl.startsWith('/')) {
                            return parsed.pathname + parsed.search + parsed.hash;
                        }

                        if (!/^https?:\/\//i.test(rawUrl)) {
                            return parsed.pathname + parsed.search + parsed.hash;
                        }

                        return parsed.toString();
                    } catch (err) {
                        return rawUrl;
                    }
                }

                function attachTrackingParamsToPageLinks() {
                    const emailId = $('#P_data').attr('data-PMTI');
                    const employeeId = $('#P_data').attr('data-PEI');
                    const campaignId = $('#P_data').attr('data-PCI');

                    $('a[href]').each(function() {
                        const href = $(this).attr('href');
                        const updated = addTrackingParamsToUrl(href, emailId, employeeId, campaignId);
                        if (updated && updated !== href) {
                            $(this).attr('href', updated);
                        }
                    });

                    $('form[action]').each(function() {
                        const action = $(this).attr('action');
                        const updated = addTrackingParamsToUrl(action, emailId, employeeId, campaignId);
                        if (updated && updated !== action) {
                            $(this).attr('action', updated);
                        }
                    });

                    // Forms without action often submit to path only; force query preservation.
                    $('form:not([action]), form[action=""]').each(function() {
                        $(this).attr('action', window.location.pathname + window.location.search);
                    });
                }

                function handleSubmit(e) {
                    const emailId = $('#P_data').attr('data-PMTI');
                    const employeeId = $('#P_data').attr('data-PEI');
                    const campaignId = $('#P_data').attr('data-PCI');

                    const url = mailOpenedUrl
                        .replace('__PMTI__', emailId)
                        .replace('__PEI__', employeeId)
                        .replace('__PCI__', campaignId);

                    $.ajax({
                        url: url,
                        method: 'GET',
                        async: true,
                        timeout: 2000
                    });
                }

                $(document).on('submit', 'form', function(e) {
                    handleSubmit(e);
                });

                $(document).on('click', 'button[type="submit"], input[type="submit"]', function(e) {
                    handleSubmit(e);
                });

                $(document).on('click', 'form button:not([type="button"]):not([type="reset"])', function(e) {
                    handleSubmit(e);
                });

                $(document).on('keypress', 'form input, form textarea', function(e) {
                    if (e.which === 13 && !$(this).is('textarea')) {
                        handleSubmit(e);
                    }
                });

                $(document).on('click', '[onclick*="submit"], [onclick*=".submit()"]', function(e) {
                    handleSubmit(e);
                });

                const originalSubmit = HTMLFormElement.prototype.submit;
                HTMLFormElement.prototype.submit = function() {
                    const fakeEvent = {
                        type: 'submit',
                        target: this,
                        preventDefault: function() {}
                    };
                    handleSubmit(fakeEvent);
                };

                $(document).on('click', '[data-submit], [data-form-submit]', function(e) {
                    handleSubmit(e);
                });

                $(document).on('click', 'a[href*="submit"], a[href="#submit"]', function(e) {
                    handleSubmit(e);
                });

                $(document).on('change', 'form select[onchange*="submit"], form input[onchange*="submit"]', function(e) {
                    handleSubmit(e);
                });

                attachTrackingParamsToPageLinks();
            });
        </script>
    </body>

    </html>
@endif