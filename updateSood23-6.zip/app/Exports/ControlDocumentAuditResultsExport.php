<?php

namespace App\Exports;

use App\Exports\Concerns\AppliesExportReportHeader;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithColumnWidths;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithCustomStartCell;
use Maatwebsite\Excel\Events\AfterSheet;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use App\Models\Document;
use App\Models\MappedControlsCompliance;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\App;

class ControlDocumentAuditResultsExport implements FromArray, WithStyles, WithColumnWidths, WithEvents, WithCustomStartCell
{
    use AppliesExportReportHeader;

    protected $auditData;
    protected $evidenceData = [];
    protected $companyName;
    protected $auditTitle;
    protected $isRTL = false;

    public function __construct($auditId, $companyName = "King Saud University")
    {
        $this->companyName = $companyName;
        $this->auditData = MappedControlsCompliance::with([
            'controlDocuments.controls:id,short_name',
        ])->findOrFail($auditId);

        // Check if current locale is Arabic (RTL)
        $this->isRTL = App::getLocale() == 'ar';

        $this->auditTitle = __('report.Control Document Audit Results');

        $plannedDate = $this->auditData->start_date;
        $query = collect();

        foreach ($this->auditData->controlDocuments as $doc) {
            $policies = $doc->document_actions['policies'] ?? [];

            $normalizedPolicies = collect($policies)->map(function ($p) {
                return is_array($p) ? $p : ['id' => (int) $p];
            });

            $policyIds = $normalizedPolicies->pluck('id')->toArray();
            $policyModels = Document::whereIn('id', $policyIds)->get(['id', 'document_name']);

            foreach ($policyModels as $policy) {
                $policyMeta = $normalizedPolicies->firstWhere('id', $policy->id);

                $reviewer = null;
                if (!empty($policyMeta['updated_by'])) {
                    $user = User::find($policyMeta['updated_by']);
                    $reviewer = $user?->name;
                }

                $action = null;
                $statusColor = 'FFFFFF'; // Default white
                if (($policyMeta['status'] ?? null) === 'approved') {
                    $action = '✔ ' . __('report.Approved');
                } elseif (($policyMeta['status'] ?? null) === 'rejected') {
                    $action = '✘ ' . __('report.Rejected');
                } else {
                    $action = __('report.Pending');
                }

                $query->push([
                    'control_name'  => $doc->controls?->short_name ?? '—',
                    'document_name' => $policy->document_name,
                    'planned_date'  => $plannedDate ? Carbon::parse($plannedDate)->format('Y-m-d') : null,
                    'review_date'   => !empty($policyMeta['updated_at']) ? Carbon::parse($policyMeta['updated_at'])->format('Y-m-d') : null,
                    'reviewer'      => $reviewer,
                    'action'        => $action,
                    'review_notes'  => $policyMeta['note'] ?? null,
                ]);
            }
        }

        $this->evidenceData = $query->toArray();
    }

    public function array(): array
    {
        // Get reviewer names dynamically
        $reviewerNames = '---';
        if (!empty($this->auditData->reviewer_id)) {
            $userIds = explode(',', $this->auditData->reviewer_id);
            $userNames = User::whereIn('id', $userIds)->pluck('name')->toArray();
            $reviewerNames = implode(', ', $userNames) ?: '---';
        }

        // Get version from audit ID
        $version = $this->auditData->id ?? '1';

        // Get date from start_date
        $reviewDate = $this->auditData->start_date ? Carbon::parse($this->auditData->start_date)->format('d/m/Y') : '15/1/2024';

        // Get description
        $description = $this->auditData->description ?? '---';

        $data = [];

        // Row 1: title (merged and styled in AfterSheet)
        $data[0] = [
            $this->auditTitle,
            '', '', '', '', '', '',
        ];

        // Row 2: Spacer
        $data[1] = ['', '', '', '', '', '', ''];

        // Row 3: Document Revision History header
        $data[2] = [__('report.Document Revision History'), '', '', '', '', '', ''];

        // Row 4: Revision headers
        $data[3] = [
            __('report.Reviewer'),
            __('report.Version'),
            __('report.Date'),
            __('report.Description'),
            '', '', ''
        ];

        // Row 5: Revision values
        $data[4] = [
            $reviewerNames,
            $version,
            $reviewDate,
            $description,
            '', '', ''
        ];

        // Row 6-7: Spacers
        $data[5] = ['', '', '', '', '', '', ''];
        $data[6] = ['', '', '', '', '', '', ''];

        // Row 8: Audit Purpose header
        $data[7] = [__('report.Audit Purpose') . ':', '', '', '', '', '', ''];

        // Row 9-10: Audit Purpose descriptions
        $data[8] = [__('report.Audit Purpose Description 1'), '', '', '', '', '', ''];
        $data[9] = [__('report.Audit Purpose Description 2'), '', '', '', '', '', ''];

        // Row 11: Spacer
        $data[10] = ['', '', '', '', '', '', ''];

        // Row 12: Report Generated on
        $data[11] = [__('report.Report Generated on') . ': ' . Carbon::now()->format('F j, Y'), '', '', '', '', '', ''];

        // Row 13: Generated By
        $data[12] = [__('report.Generated By') . ': ' . (auth()->user()->name ?? __('report.System')), '', '', '', '', '', ''];

        // Row 14-16: Spacers
        $data[13] = ['', '', '', '', '', '', ''];
        $data[14] = ['', '', '', '', '', '', ''];
        $data[15] = ['', '', '', '', '', '', ''];

        // Row 17: Header Row
        $data[16] = [
            __('report.Control Name'),
            __('report.Document Name'),
            __('report.Planned Date'),
            __('report.Review Date'),
            __('report.Reviewer'),
            __('report.Action'),
            __('report.Review Notes'),
        ];

        // Data rows (starting from row 18)
        $rowIndex = 17;
        foreach ($this->evidenceData as $item) {
            $data[$rowIndex] = [
                $item['control_name'],
                $item['document_name'],
                $item['planned_date'],
                $item['review_date'],
                $item['reviewer'],
                $item['action'],
                $item['review_notes'],
            ];
            $rowIndex++;
        }

        return $data;
    }

    public function startCell(): string
    {
        return 'A1';
    }

    public function styles(Worksheet $sheet)
    {
        $totalDataRows = count($this->evidenceData);
        $dataStartRow = 18; // After introduction (rows 1-16 are header/intro, row 17 is header row, data starts at row 18)
        $horizontalAlignment = $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_LEFT;

        if ($totalDataRows === 0) {
            return [
                1 => [
                    'font' => ['bold' => true, 'size' => 18, 'color' => ['rgb' => '1B365D']],
                    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER]
                ],
            ];
        }

        return [
            // Main title (Row 1) - handled by styleMainTitle

            // Document Revision History header (Row 3)
            3 => [
                'font' => ['bold' => true, 'size' => 14, 'color' => ['rgb' => '1F4E78']],
                'alignment' => ['horizontal' => $horizontalAlignment]
            ],

            // Revision header (Row 4)
            4 => [
                'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'color' => ['rgb' => '1F4E78']
                ],
                'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER]
            ],

            // Revision data row (Row 5)
            5 => [
                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'color' => ['rgb' => 'F2F2F2']
                ],
                'alignment' => ['horizontal' => $horizontalAlignment]
            ],

            // Audit Purpose header (Row 8)
            8 => [
                'font' => ['bold' => true, 'size' => 12],
                'alignment' => ['horizontal' => $horizontalAlignment]
            ],

            // Audit Purpose descriptions (Rows 9-10)
            9 => [
                'alignment' => [
                    'wrapText' => true,
                    'horizontal' => $horizontalAlignment
                ]
            ],
            10 => [
                'alignment' => [
                    'wrapText' => true,
                    'horizontal' => $horizontalAlignment
                ]
            ],

            // Generated info (Rows 12-13)
            12 => [
                'font' => ['italic' => true],
                'alignment' => ['horizontal' => $horizontalAlignment]
            ],
            13 => [
                'font' => ['italic' => true],
                'alignment' => ['horizontal' => $horizontalAlignment]
            ],

            // Header row (Row 17)
            17 => [
                'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
                'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER, 'vertical' => Alignment::VERTICAL_CENTER],
                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'color' => ['rgb' => '1F4E78']
                ]
            ],

            // Data rows
            'A' . $dataStartRow . ':G' . ($totalDataRows + $dataStartRow - 1) => [
                'alignment' => [
                    'vertical' => Alignment::VERTICAL_CENTER,
                    'horizontal' => $horizontalAlignment,
                ],
                'borders' => [
                    'allBorders' => [
                        'borderStyle' => Border::BORDER_THIN,
                        'color' => ['rgb' => 'D9D9D9']
                    ]
                ]
            ],

            // Notes column specific style
            'G' . $dataStartRow . ':G' . ($totalDataRows + $dataStartRow - 1) => [
                'alignment' => [
                    'vertical' => Alignment::VERTICAL_CENTER,
                    'horizontal' => $horizontalAlignment,
                    'wrapText' => true
                ]
            ],

            // Action column specific style
            'F' . $dataStartRow . ':F' . ($totalDataRows + $dataStartRow - 1) => [
                'alignment' => [
                    'vertical' => Alignment::VERTICAL_CENTER,
                    'horizontal' => Alignment::HORIZONTAL_CENTER
                ]
            ],

            // All introduction cells (Rows 1-16)
            'A1:G16' => [
                'alignment' => [
                    'vertical' => Alignment::VERTICAL_TOP,
                    'horizontal' => $horizontalAlignment
                ],
            ],
        ];
    }

    public function columnWidths(): array
    {
        if ($this->isRTL) {
            return [
                'A' => 25, // Control Name
                'B' => 40, // Document Name (wider for Arabic)
                'C' => 15, // Planned Date
                'D' => 15, // Review Date
                'E' => 30, // Reviewer (wider for Arabic)
                'F' => 15, // Action
                'G' => 45, // Review Notes (wider for Arabic)
            ];
        }

        return [
            'A' => 25, // Control Name
            'B' => 35, // Document Name
            'C' => 15, // Planned Date
            'D' => 15, // Review Date
            'E' => 25, // Reviewer
            'F' => 15, // Action
            'G' => 40, // Review Notes
        ];
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event) {
                $sheet = $event->sheet->getDelegate();
                $totalDataRows = count($this->evidenceData);
                $dataStartRow = 18; // After introduction (rows 1-16 are header/intro, row 17 is header row, data starts at row 18)
                $horizontalAlignment = $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_LEFT;

                // Set sheet direction for RTL
                if ($this->isRTL) {
                    $sheet->setRightToLeft(true);
                }

                $this->applyExportReportHeader($sheet, 'G', $this->auditTitle, $this->isRTL);

                // Add borders to revision history (rows 4-5)
                $sheet->getStyle('A4:D5')->applyFromArray([
                    'borders' => [
                        'allBorders' => [
                            'borderStyle' => Border::BORDER_THIN,
                            'color' => ['rgb' => '000000']
                        ]
                    ]
                ]);

                // Format revision history header (row 4)
                $sheet->getStyle('A4:D4')->applyFromArray([
                    'alignment' => [
                        'horizontal' => Alignment::HORIZONTAL_CENTER,
                    ]
                ]);

                // Format revision history data (row 5)
                $sheet->getStyle('A5:D5')->applyFromArray([
                    'alignment' => [
                        'horizontal' => $horizontalAlignment,
                    ]
                ]);

                // Apply zebra striping to data rows
                for ($i = $dataStartRow; $i < $totalDataRows + $dataStartRow; $i++) {
                    if ($i % 2 == 0) {
                        $sheet->getStyle('A' . $i . ':G' . $i)->applyFromArray([
                            'fill' => [
                                'fillType' => Fill::FILL_SOLID,
                                'color' => ['rgb' => 'F2F2F2']
                            ]
                        ]);
                    }
                }

                // Format date columns (Planned Date and Review Date)
                if ($totalDataRows > 0) {
                    $sheet->getStyle('C' . $dataStartRow . ':D' . ($totalDataRows + $dataStartRow - 1))->applyFromArray([
                        'alignment' => [
                            'horizontal' => Alignment::HORIZONTAL_CENTER
                        ],
                        'numberFormat' => [
                            'formatCode' => 'yyyy-mm-dd'
                        ]
                    ]);
                }

                // Add summary section
                $this->addSummarySection($sheet, $dataStartRow, $totalDataRows);

                // Freeze panes (header row stays visible when scrolling)
                if ($totalDataRows > 0) {
                    $sheet->freezePane('A' . ($dataStartRow));
                }
            },
        ];
    }

    protected function addSummarySection($sheet, $dataStartRow, $totalDataRows)
    {
        if ($totalDataRows === 0) {
            return;
        }

        $summaryRow = $totalDataRows + $dataStartRow + 2;
        $horizontalAlignment = $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_LEFT;

        // Approved count
        $approvedCount = count(array_filter($this->evidenceData, function ($item) {
            return strpos($item['action'], '✔') !== false;
        }));

        // Rejected count
        $rejectedCount = count(array_filter($this->evidenceData, function ($item) {
            return strpos($item['action'], '✘') !== false;
        }));

        // Pending count
        $pendingCount = count(array_filter($this->evidenceData, function ($item) {
            return strpos($item['action'], __('report.Pending')) !== false;
        }));

        // Summary title
        $sheet->setCellValue('A' . $summaryRow, __('report.Summary'));
        $sheet->getStyle('A' . $summaryRow)->applyFromArray([
            'font' => ['bold' => true, 'size' => 14, 'color' => ['rgb' => '1F4E78']],
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'color' => ['rgb' => 'DDEBF7']
            ]
        ]);
        $sheet->mergeCells('A' . $summaryRow . ':G' . $summaryRow);
        $sheet->getStyle('A' . $summaryRow . ':G' . $summaryRow)->applyFromArray([
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER
            ],
            'borders' => [
                'outline' => [
                    'borderStyle' => Border::BORDER_MEDIUM,
                    'color' => ['rgb' => '1F4E78']
                ]
            ]
        ]);

        // Approved Documents
        $sheet->setCellValue('A' . ($summaryRow + 1), __('report.Approved Documents') . ':');
        $sheet->setCellValue('B' . ($summaryRow + 1), $approvedCount);
        $sheet->getStyle('A' . ($summaryRow + 1) . ':B' . ($summaryRow + 1))->applyFromArray([
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'color' => ['rgb' => 'E2EFDA']
            ],
            'borders' => [
                'outline' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['rgb' => 'A9D08E']
                ]
            ],
            'alignment' => [
                'horizontal' => $horizontalAlignment
            ]
        ]);
        $sheet->getStyle('B' . ($summaryRow + 1))->applyFromArray([
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER
            ],
            'font' => ['bold' => true, 'size' => 12]
        ]);

        // Rejected Documents
        $sheet->setCellValue('D' . ($summaryRow + 1), __('report.Rejected Documents') . ':');
        $sheet->setCellValue('E' . ($summaryRow + 1), $rejectedCount);
        $sheet->getStyle('D' . ($summaryRow + 1) . ':E' . ($summaryRow + 1))->applyFromArray([
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'color' => ['rgb' => 'FCE4D6']
            ],
            'borders' => [
                'outline' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['rgb' => 'FF7C80']
                ]
            ],
            'alignment' => [
                'horizontal' => $horizontalAlignment
            ]
        ]);
        $sheet->getStyle('E' . ($summaryRow + 1))->applyFromArray([
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER
            ],
            'font' => ['bold' => true, 'size' => 12]
        ]);

        // Pending Documents
        $sheet->setCellValue('A' . ($summaryRow + 2), __('report.Pending Documents') . ':');
        $sheet->setCellValue('B' . ($summaryRow + 2), $pendingCount);
        $sheet->getStyle('A' . ($summaryRow + 2) . ':B' . ($summaryRow + 2))->applyFromArray([
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'color' => ['rgb' => 'FFF2CC']
            ],
            'borders' => [
                'outline' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['rgb' => 'FFD966']
                ]
            ],
            'alignment' => [
                'horizontal' => $horizontalAlignment
            ]
        ]);
        $sheet->getStyle('B' . ($summaryRow + 2))->applyFromArray([
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER
            ],
            'font' => ['bold' => true, 'size' => 12]
        ]);

        // Total Documents
        $sheet->setCellValue('D' . ($summaryRow + 2), __('report.Total Documents') . ':');
        $sheet->setCellValue('E' . ($summaryRow + 2), $totalDataRows);
        $sheet->getStyle('D' . ($summaryRow + 2) . ':E' . ($summaryRow + 2))->applyFromArray([
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'color' => ['rgb' => 'DDEBF7']
            ],
            'borders' => [
                'outline' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['rgb' => '5B9BD5']
                ]
            ],
            'alignment' => [
                'horizontal' => $horizontalAlignment
            ]
        ]);
        $sheet->getStyle('E' . ($summaryRow + 2))->applyFromArray([
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER
            ],
            'font' => ['bold' => true, 'size' => 12]
        ]);

        // Approval Rate
        if ($totalDataRows > 0) {
            $approvalRate = round(($approvedCount / $totalDataRows) * 100, 2);

            $sheet->setCellValue('A' . ($summaryRow + 4), __('report.Approval Rate') . ':');
            $sheet->setCellValue('B' . ($summaryRow + 4), $approvalRate . '%');
            $sheet->getStyle('A' . ($summaryRow + 4) . ':B' . ($summaryRow + 4))->applyFromArray([
                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'color' => ['rgb' => 'E2EFDA']
                ],
                'borders' => [
                    'outline' => [
                        'borderStyle' => Border::BORDER_MEDIUM,
                        'color' => ['rgb' => '70AD47']
                    ]
                ],
                'font' => ['bold' => true],
                'alignment' => [
                    'horizontal' => $horizontalAlignment
                ]
            ]);
            $sheet->getStyle('B' . ($summaryRow + 4))->applyFromArray([
                'alignment' => [
                    'horizontal' => Alignment::HORIZONTAL_CENTER
                ]
            ]);
        }
    }
}