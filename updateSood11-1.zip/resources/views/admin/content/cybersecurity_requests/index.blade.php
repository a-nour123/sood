@extends('admin/layouts/contentLayoutMaster')

@section('title', __('request.title'))

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/dataTables.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/responsive.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/buttons.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/flatpickr/flatpickr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/spinner/jquery.bootstrap-touchspin.css')) }}">
@endsection

@section('page-style')
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-sweet-alerts.css')) }}">
    <style>
        .attachment-item {
            max-width: 300px;
            word-break: break-all;
        }

        .modal-xl {
            max-width: 1200px;
        }

        .request-details-table th {
            width: 30%;
            background-color: #f8f9fa;
        }

        .timeline-item {
            border-left: 2px solid #ddd;
            padding-left: 15px;
            margin-bottom: 15px;
            position: relative;
        }

        .timeline-item::before {
            content: '';
            position: absolute;
            left: -6px;
            top: 5px;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background-color: #666;
        }
    </style>
@endsection

@section('content')
    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">
            <div class="row breadcrumbs-top widget-grid">
                <div class="col-12">
                    <div class="page-title mt-2">
                        <div class="row">
                            <div class="col-md-6 ps-0">
                                @if (@isset($breadcrumbs))
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item">
                                            <a href="{{ route('admin.dashboard') }}" style="display: flex;">
                                                <svg class="stroke-icon">
                                                    <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}">
                                                    </use>
                                                </svg>
                                            </a>
                                        </li>
                                        @foreach ($breadcrumbs as $breadcrumb)
                                            <li class="breadcrumb-item">
                                                @if (isset($breadcrumb['link']))
                                                    <a
                                                        href="{{ $breadcrumb['link'] == 'javascript:void(0)' ? $breadcrumb['link'] : url($breadcrumb['link']) }}">
                                                @endif
                                                {{ __($breadcrumb['name']) }}
                                                @if (isset($breadcrumb['link']))
                                                    </a>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ol>
                                @endisset
                        </div>
                        <div class="col-md-6 pe-0" style="text-align: end;">
                            <div class="action-content">
                                @if (auth()->user()->hasPermission('cybersecurity_requests.create'))
                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                        data-bs-target="#createRequestModal">
                                        <i class="fa fa-plus"></i>
                                    </button>
                                @endif
                                @if (auth()->user()->hasPermission('cybersecurity_requests.approve'))
                                    <a href="{{ route('admin.cybersecurity_requests.approvals') }}"
                                        class="btn btn-warning">
                                        <i class="fa fa-check-circle"></i>
                                    </a>
                                @endif
                                @if (auth()->user()->hasPermission('cybersecurity_requests.operate'))
                                    <a href="{{ route('admin.cybersecurity_requests.operator') }}"
                                        class="btn btn-info">
                                        <i class="fa fa-tasks"></i>
                                    </a>
                                @endif
                                @if (auth()->user()->hasPermission('cybersecurity_requests.dashboard'))
                                    <a href="{{ route('admin.cybersecurity_requests.dashboard') }}"
                                        class="btn btn-success">
                                        <i class="fa fa-chart-bar"></i>
                                    </a>
                                @endif
                                @if (auth()->user()->hasPermission('cybersecurity_requests.create'))
                                <a  href="{{ route('admin.cybersecurity_requests.configuretion') }}"
                                        class=" btn btn-primary" target="_self">
                                        <i class="fa fa-solid fa-gear"></i>
                                    </a>
                                @endif
                                 @if (auth()->user()->hasPermission('cybersecurity_requests.create'))
                                <a  href="{{ route('admin.cybersecurity_requests.notificationsSetting') }}"
                                        class=" btn btn-primary" target="_self">
                                    <i class="fa-regular fa-bell"></i>
                                    </a>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">{{ __('request.cybersecurity_requests') }}</h4>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-3">
                        <label>{{ __('request.status') }}</label>
                        <select id="filter-status" class="form-select">
                            <option value="">{{ __('request.all') }}</option>
                            <option value="created">{{ __('request.created') }}</option>
                            <option value="under management approval">{{ __('request.under_management_approval') }}
                            </option>
                            <option value="approved">{{ __('request.approved') }}</option>
                            <option value="under process">{{ __('request.under_process') }}</option>
                            <option value="closed">{{ __('request.closed') }}</option>
                            <option value="rejected">{{ __('request.rejected') }}</option>
                            <option value="planned">{{ __('request.planned') }}</option>
                            <option value="returned">{{ __('request.returned') }}</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label>{{ __('request.priority') }}</label>
                        <select id="filter-priority" class="form-select">
                            <option value="">{{ __('request.all') }}</option>
                            <option value="High">{{ __('request.high') }}</option>
                            <option value="Moderate">{{ __('request.moderate') }}</option>
                            <option value="Low">{{ __('request.low') }}</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label>{{ __('request.department') }}</label>
                        <select id="filter-department" class="form-select">
                            <option value="">{{ __('request.all') }}</option>
                            @foreach ($departments as $dept)
                                <option value="{{ $dept->id }}">{{ __($dept->name) }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label>{{ __('request.late_requests') }}</label>
                        <select id="filter-late" class="form-select">
                            <option value="">{{ __('request.all') }}</option>
                            <option value="1">{{ __('request.late_only') }}</option>
                        </select>
                    </div>
                </div>

                <table class="table table-hover" id="requests-table">
                    <thead>
                        <tr>
                            <th>{{ __('request.request_number') }}</th>
                            <th>{{ __('request.requester') }}</th>
                            <th>{{ __('request.department') }}</th>
                            <th>{{ __('request.type') }}</th>
                            <th>{{ __('request.priority') }}</th>
                            <th>{{ __('request.due_date') }}</th>
                            <th>{{ __('request.status') }}</th>
                            <th>{{ __('request.assigned_to') }}</th>
                            <th>{{ __('request.actions') }}</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Create Request Modal -->
<div class="modal fade" id="createRequestModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">{{ __('request.create_new_request') }}</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="createRequestForm" enctype="multipart/form-data">
                @csrf
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label"
                                for="create_receiving_department">{{ __('request.receiving_department') }} <span
                                    class="text-danger">*</span></label>
                            <select class="form-select select2" id="create_receiving_department"
                                name="receiving_department" required>
                                <option value="">{{ __('request.select_department') }}</option>
                                @foreach ($departments as $dept)
                                    <option value="{{ $dept->id }}">{{ __($dept->name) }}</option>
                                @endforeach
                            </select>
                            <div class="invalid-feedback" id="create_receiving_department_error"></div>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="create_request_type">{{ __('request.request_type') }}
                                <span class="text-danger">*</span></label>
                            <select class="form-select select2" id="create_request_type" name="request_type"
                                required>
                                <option value="">{{ __('request.select_type') }}</option>
                                @foreach ($requestTypes as $type)
                                    <option value="{{ $type->id }}">{{ $type->name }}</option>
                                @endforeach
                            </select>
                            <div class="invalid-feedback" id="create_request_type_error"></div>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="create_request_reason">{{ __('request.request_reason') }}
                                <span class="text-danger">*</span></label>
                            <select class="form-select select2" id="create_request_reason" name="request_reason"
                                required>
                                <option value="">{{ __('request.select_reason') }}</option>
                                @foreach ($requestReasons as $reason)
                                    <option value="{{ $reason->id }}">{{ $reason->name }}</option>
                                @endforeach
                            </select>
                            <div class="invalid-feedback" id="create_request_reason_error"></div>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="create_priority">{{ __('request.priority') }} <span
                                    class="text-danger">*</span></label>
                            <select class="form-select select2" id="create_priority" name="priority" required>
                                <option value="">{{ __('request.select_priority') }}</option>
                                <option value="High">{{ __('request.high') }}</option>
                                <option value="Moderate">{{ __('request.moderate') }}</option>
                                <option value="Low">{{ __('request.low') }}</option>
                            </select>
                            <div class="invalid-feedback" id="create_priority_error"></div>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="create_due_date">{{ __('request.due_date') }} <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control flatpickr" id="create_due_date"
                                name="due_date" placeholder="{{ __('request.select_date_time') }}" required>
                            <div class="invalid-feedback" id="create_due_date_error"></div>
                        </div>

                        <div class="col-md-12 mb-3">
                            <label class="form-label" for="create_description">{{ __('request.description') }} <span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control" id="create_description" name="description" rows="5"
                                placeholder="{{ __('request.describe_request_detail') }}" required></textarea>
                            <div class="invalid-feedback" id="create_description_error"></div>
                        </div>

                        <div class="col-md-12 mb-3">
                            <label class="form-label"
                                for="create_attachments">{{ __('request.attachments') }}</label>
                            <input type="file" class="form-control" id="create_attachments" name="attachments[]"
                                multiple>
                            <small class="text-muted">{{ __('request.max_file_size') }}</small>
                            <div class="invalid-feedback" id="create_attachments_error"></div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary"
                        data-bs-dismiss="modal">{{ __('request.cancel') }}</button>
                    <button type="submit" class="btn btn-primary" id="createSubmitBtn">
                        <span class="spinner-border spinner-border-sm d-none" role="status"
                            aria-hidden="true"></span>
                        {{ __('request.submit_request') }}
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- View Request Modal -->
<div class="modal fade" id="viewRequestModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">{{ __('request.request_details') }}</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="viewRequestContent">
                <!-- Content will be loaded via AJAX -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary"
                    data-bs-dismiss="modal">{{ __('request.close') }}</button>
            </div>
        </div>
    </div>
</div>

<!-- Edit Request Modal -->
<div class="modal fade" id="editRequestModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">{{ __('request.edit_request') }}</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="editRequestForm" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                <input type="hidden" id="edit_request_id" name="id">
                <div class="modal-body" id="editRequestContent">
                    <!-- Content will be loaded via AJAX -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary"
                        data-bs-dismiss="modal">{{ __('request.cancel') }}</button>
                    <button type="submit" class="btn btn-primary" id="editSubmitBtn">
                        <span class="spinner-border spinner-border-sm d-none" role="status"
                            aria-hidden="true"></span>
                        {{ __('request.update_request') }}
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@section('vendor-script')
<script src="{{ asset(mix('vendors/js/tables/datatable/jquery.dataTables.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.bootstrap5.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.responsive.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/responsive.bootstrap5.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/pickers/flatpickr/flatpickr.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/forms/spinner/jquery.bootstrap-touchspin.js')) }}"></script>
@endsection

@section('page-script')
<script>
    $(document).ready(function() {
        // Initialize DataTable
        const table = $('#requests-table').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: '{{ route('admin.cybersecurity_requests.data') }}',
                data: function(d) {
                    d.status = $('#filter-status').val();
                    d.priority = $('#filter-priority').val();
                    d.department = $('#filter-department').val();
                    d.late = $('#filter-late').val();
                }
            },
            columns: [{
                    data: 'request_number',
                    name: 'request_number'
                },
                {
                    data: 'requester_name',
                    name: 'requester.name'
                },
                {
                    data: 'receiving_department',
                    name: 'receiving_department'
                },
                {
                    data: 'request_type_name',
                    name: 'request_types.name'
                },
                {
                    data: 'priority_badge',
                    name: 'priority',
                    orderable: false
                },
                {
                    data: 'due_date',
                    name: 'due_date'
                },
                {
                    data: 'status_badge',
                    name: 'status',
                    orderable: false
                },
                {
                    data: 'assigned_to_name',
                    name: 'assignedUser.name'
                },
                {
                    data: 'actions',
                    name: 'actions',
                    orderable: false,
                    searchable: false
                }
            ],
            order: [
                [0, 'desc']
            ],
            responsive: true,
            language: {
                search: "{{ __('request.search') }}:",
                lengthMenu: "{{ __('request.show_entries') }}",
                info: "{{ __('request.showing_entries') }}",
                infoEmpty: "{{ __('request.showing_zero_entries') }}",
                infoFiltered: "{{ __('request.filtered_from_total') }}",
                zeroRecords: "{{ __('request.no_matching_records') }}",
                paginate: {
                    first: "{{ __('request.first') }}",
                    last: "{{ __('request.last') }}",
                    next: "{{ __('request.next') }}",
                    previous: "{{ __('request.previous') }}"
                }
            }
        });

        // Filter handlers
        $('#filter-status, #filter-priority, #filter-department, #filter-late').change(function() {
            table.ajax.reload();
        });

        // Initialize flatpickr for create modal
        $('#create_due_date').flatpickr({
            enableTime: true,
            dateFormat: "Y-m-d H:i",
            time_24hr: true,
            minDate: "today"
        });

        // Initialize select2 for create modal
        $('#createRequestModal .select2').select2({
            dropdownParent: $('#createRequestModal'),
            placeholder: '{{ __('request.select_option') }}',
            allowClear: true
        });

        // Create Request Form Submission
        $('#createRequestForm').on('submit', function(e) {
            e.preventDefault();

            const formData = new FormData(this);
            const submitBtn = $('#createSubmitBtn');
            const spinner = submitBtn.find('.spinner-border');

            // Reset errors
            $(this).find('.is-invalid').removeClass('is-invalid');
            $(this).find('.invalid-feedback').text('');

            // Show loading
            spinner.removeClass('d-none');
            submitBtn.prop('disabled', true);

            $.ajax({
                url: '{{ route('admin.cybersecurity_requests.store') }}',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    toastr.success(response.message ||
                        '{{ __('request.request_created_successfully') }}');
                    $('#createRequestModal').modal('hide');
                    $('#createRequestForm')[0].reset();
                    $('#createRequestModal .select2').val(null).trigger('change');
                    table.ajax.reload();
                },
                error: function(xhr) {
                    if (xhr.status === 422) {
                        const errors = xhr.responseJSON.errors;
                        $.each(errors, function(key, value) {
                            const input = $('#create_' + key);
                            const errorDiv = $('#create_' + key + '_error');
                            input.addClass('is-invalid');
                            errorDiv.text(value[0]);
                        });
                    } else {
                        toastr.error(xhr.responseJSON.message ||
                            '{{ __('request.error_creating_request') }}');
                    }
                },
                complete: function() {
                    spinner.addClass('d-none');
                    submitBtn.prop('disabled', false);
                }
            });
        });

        // Edit Request - Load Form
        $(document).on('click', '.edit-request', function() {

            const requestId = $(this).data('id');
            $('#edit_request_id').val(requestId);

            $.ajax({
                url: '{{ route('admin.cybersecurity_requests.edit') }}',
                type: 'POST',
                data: {
                    _token: '{{ csrf_token() }}',
                    id: requestId
                },
                success: function(response) {

                    if (!response.success) {
                        toastr.error(response.message);
                        return;
                    }

                    const data = response.data;
                    const request = data.request;

                    let html = `
            <div class="row g-3">

                <div class="col-md-6">
                    <label class="form-label">{{ __('request.receiving_department') }} <span class="text-danger">*</span></label>
                    <select name="receiving_department" class="form-control select2" required>
                        <option value="">{{ __('request.select_department') }}</option>
                        ${data.departments.map(d =>
                            `<option value="${d.id}" ${d.id == request.receiving_department ? 'selected' : ''}>${d.name}</option>`
                        ).join('')}
                    </select>
                </div>

                <div class="col-md-6">
                    <label class="form-label">{{ __('request.request_type') }} <span class="text-danger">*</span></label>
                    <select name="request_type_id" class="form-control select2" required>
                        <option value="">{{ __('request.select_type') }}</option>
                        ${data.requestTypes.map(t =>
                            `<option value="${t.id}" ${t.id == request.request_type_id ? 'selected' : ''}>${t.name}</option>`
                        ).join('')}
                    </select>
                </div>

                <div class="col-md-6">
                    <label class="form-label">{{ __('request.request_reason') }} <span class="text-danger">*</span></label>
                    <select name="request_reason_id" class="form-control select2" required>
                        <option value="">{{ __('request.select_reason') }}</option>
                        ${data.requestReasons.map(r =>
                            `<option value="${r.id}" ${r.id == request.request_reason_id ? 'selected' : ''}>${r.name}</option>`
                        ).join('')}
                    </select>
                </div>

                <div class="col-md-6">
                    <label class="form-label">{{ __('request.priority') }} <span class="text-danger">*</span></label>
                    <select name="priority" class="form-control select2" required>
                        <option value="">{{ __('request.select_priority') }}</option>
                        ${data.priorities.map(p =>
                            `<option value="${p}" ${p == request.priority ? 'selected' : ''}>${p}</option>`
                        ).join('')}
                    </select>
                </div>

                <div class="col-md-6">
                    <label class="form-label">{{ __('request.due_date') }} <span class="text-danger">*</span></label>
                    <input type="text" name="due_date" class="form-control flatpickr"
                        value="${request.due_date ? new Date(request.due_date).toISOString().slice(0, 16).replace('T', ' ') : ''}"
                        required>
                </div>

                <div class="col-12">
                    <label class="form-label">{{ __('request.description') }} <span class="text-danger">*</span></label>
                    <textarea name="description" class="form-control" rows="5" required>${request.description || ''}</textarea>
                </div>

                ${request.attachments && request.attachments.length > 0 ? `
                <div class="col-12">
                    <label class="form-label">{{ __('request.existing_attachments') }}</label>
                    <div class="existing-attachments d-flex flex-wrap gap-2">

                        ${request.attachments.map(attachment => `
                            <div class="attachment-item d-flex align-items-center p-2 border rounded">
                                <i class="fas fa-paperclip me-2"></i>

                                <a href="${attachment.file_url}"
                                   download
                                   class="me-2">
                                   ${attachment.file_name}
                                </a>

                                <button type="button"
                                        class="btn btn-sm btn-danger delete-attachment"
                                        data-id="${attachment.id}">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        `).join('')}

                    </div>
                </div>
                ` : ''}

                <div class="col-12">
                    <label class="form-label">{{ __('request.add_new_attachments') }}</label>
                    <input type="file"
                           class="form-control"
                           id="new_attachments"
                           name="new_attachments[]"
                           multiple>
                    <small class="text-muted">{{ __('request.max_file_size') }}</small>
                </div>

            </div>
            `;

                    $('#editRequestContent').html(html);
                    $('#editRequestModal').modal('show');

                    // Re-init plugins
                    $('#editRequestModal .flatpickr').flatpickr({
                        enableTime: true,
                        dateFormat: "Y-m-d H:i",
                        time_24hr: true
                    });

                    $('#editRequestModal .select2').select2({
                        dropdownParent: $('#editRequestModal'),
                        placeholder: '{{ __('request.select_option') }}',
                        allowClear: true
                    });
                },
                error: function() {
                    toastr.error('{{ __('request.error_loading_edit_data') }}');
                }
            });
        });


        // Edit Request Form Submission
        $('#editRequestForm').on('submit', function(e) {
            e.preventDefault();

            const formData = new FormData(this);
            const requestId = $('#edit_request_id').val();
            const submitBtn = $('#editSubmitBtn');
            const spinner = submitBtn.find('.spinner-border');

            // Show loading
            spinner.removeClass('d-none');
            submitBtn.prop('disabled', true);

            $.ajax({
                url: '{{ route('admin.cybersecurity_requests.update', '') }}/' + requestId,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    toastr.success(response.message ||
                        '{{ __('request.request_updated_successfully') }}');
                    $('#editRequestModal').modal('hide');
                    table.ajax.reload();
                },
                error: function(xhr) {
                    if (xhr.status === 422) {
                        const errors = xhr.responseJSON.errors;
                        $.each(errors, function(key, value) {
                            const input = $('#edit_' + key);
                            const errorDiv = $('#edit_' + key + '_error');
                            if (input.length) {
                                input.addClass('is-invalid');
                                if (errorDiv.length) {
                                    errorDiv.text(value[0]);
                                }
                            }
                        });
                    } else {
                        toastr.error(xhr.responseJSON.message ||
                            '{{ __('request.error_updating_request') }}');
                    }
                },
                complete: function() {
                    spinner.addClass('d-none');
                    submitBtn.prop('disabled', false);
                }
            });
        });

        // Delete attachment in edit modal
        $(document).on('click', '.delete-attachment', function() {

            const attachmentId = $(this).data('id');
            const attachmentElement = $(this).closest('.attachment-item');

            toastr.warning(
                `
        <div class="text-center">
            <p class="mb-2">{{ __('request.confirm_delete_attachment') }}</p>
            <button type="button" class="btn btn-sm btn-danger confirm-delete me-2"
                    data-id="${attachmentId}">
                {{ __('request.yes_delete') }}
            </button>
            <button type="button" class="btn btn-sm btn-secondary cancel-delete">
                {{ __('request.cancel') }}
            </button>
        </div>
        `,
                '{{ __('request.confirm_deletion') }}', {
                    closeButton: true,
                    timeOut: 0,
                    extendedTimeOut: 0,
                    tapToDismiss: false,
                    allowHtml: true,
                    positionClass: 'toast-top-center'
                }
            );

            // Confirm delete
            $(document).off('click', '.confirm-delete').on('click', '.confirm-delete', function() {

                const id = $(this).data('id');

                toastr.clear();

                $.ajax({
                    url: '{{ route('admin.cybersecurity_requests.attachment.delete', '') }}/' +
                        id,
                    type: 'DELETE',
                    data: {
                        _token: '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        if (response.success) {
                            attachmentElement.fadeOut(300, function() {
                                $(this).remove();
                            });
                            toastr.success(response.message);
                        } else {
                            toastr.error(response.message);
                        }
                    },
                    error: function() {
                        toastr.error(
                            '{{ __('request.error_deleting_attachment') }}');
                    }
                });
            });

            // Cancel delete
            $(document).off('click', '.cancel-delete').on('click', '.cancel-delete', function() {
                toastr.clear();
            });

        });

        // Delete request
        $(document).on('click', '.delete-request', function(e) {
            e.preventDefault();
            const requestId = $(this).data('id');

            Swal.fire({
                title: '{{ __('request.are_you_sure') }}',
                text: "{{ __('request.cannot_revert') }}",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: '{{ __('request.yes_delete_it') }}',
                cancelButtonText: '{{ __('request.cancel') }}',
                customClass: {
                    confirmButton: 'btn btn-danger',
                    cancelButton: 'btn btn-secondary'
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: '{{ route('admin.cybersecurity_requests.destroy', '') }}/' +
                            requestId,
                        type: 'DELETE',
                        data: {
                            _token: '{{ csrf_token() }}'
                        },
                        success: function(response) {
                            if (response.success) {
                                toastr.success(response.message);
                                table.ajax.reload();
                            } else {
                                toastr.error(response.message);
                            }
                        },
                        error: function(xhr) {
                            toastr.error(
                                '{{ __('request.error_deleting_request') }}');
                        }
                    });
                }
            });
        });

        // Reset create modal when closed
        $('#createRequestModal').on('hidden.bs.modal', function() {
            $('#createRequestForm')[0].reset();
            $('#createRequestModal .select2').val(null).trigger('change');
            $('#createRequestModal .is-invalid').removeClass('is-invalid');
            $('#createRequestModal .invalid-feedback').text('');
        });
    });
</script>
@endsection
