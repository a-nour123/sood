@extends('admin/layouts/contentLayoutMaster')

@section('title', __('request.title'))

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/dataTables.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/responsive.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
@endsection

@section('page-style')
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-sweet-alerts.css')) }}">
@endsection

@section('content')
    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">
            <div class="row breadcrumbs-top widget-grid">
                <div class="col-12">
                    <div class="page-title mt-2">
                        <div class="row">
                            <div class="col-md-12 ps-0">
                                @if (@isset($breadcrumbs))
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item">
                                            <a href="{{ route('admin.dashboard') }}" style="display: flex;">
                                                <svg class="stroke-icon">
                                                    <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}">
                                                    </use>
                                                </svg>
                                            </a>
                                        </li>
                                        @foreach ($breadcrumbs as $breadcrumb)
                                            <li class="breadcrumb-item">
                                                @if (isset($breadcrumb['link']))
                                                    <a
                                                        href="{{ $breadcrumb['link'] == 'javascript:void(0)' ? $breadcrumb['link'] : url($breadcrumb['link']) }}">
                                                @endif
                                                {{ __($breadcrumb['name']) }}
                                                @if (isset($breadcrumb['link']))
                                                    </a>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ol>
                                @endisset
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">{{ __('request.pending_approvals') }}</h4>
                </div>
                <div class="card-body">
                    <table class="table table-hover" id="approvals-table">
                        <thead>
                            <tr>
                                <th>{{ __('request.request_number') }}</th>
                                <th>{{ __('request.requester') }}</th>
                                <th>{{ __('request.department') }}</th>
                                <th>{{ __('request.type') }}</th>
                                <th>{{ __('request.priority') }}</th>
                                <th>{{ __('request.due_date') }}</th>
                                <th>{{ __('request.status') }}</th>
                                <th>{{ __('request.actions') }}</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Approve Modal -->
    <div class="modal fade" id="approveModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">{{ __('request.approve_request') }}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="approveForm">
                    @csrf
                    <input type="hidden" name="request_id" id="approve_request_id">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">{{ __('request.assign_to') }} <span class="text-danger">*</span></label>
                            <select class="form-select select2" id="assigned_to" name="assigned_to" required>
                                <option value="">{{ __('request.select_operator') }}</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">{{ __('request.notes') }}</label>
                            <textarea class="form-control" name="notes" rows="3" placeholder="{{ __('request.optional_approval_notes') }}"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">{{ __('request.cancel') }}</button>
                        <button type="submit" class="btn btn-success">{{ __('request.approve') }}</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Reject Modal -->
    <div class="modal fade" id="rejectModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">{{ __('request.reject_request') }}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="rejectForm">
                    @csrf
                    <input type="hidden" name="request_id" id="reject_request_id">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">{{ __('request.rejection_reason') }} <span class="text-danger">*</span></label>
                            <textarea class="form-control" name="notes" rows="3" placeholder="{{ __('request.rejection_reason_placeholder') }}" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">{{ __('request.cancel') }}</button>
                        <button type="submit" class="btn btn-danger">{{ __('request.reject') }}</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Return Modal -->
    <div class="modal fade" id="returnModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">{{ __('request.return_request') }}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="returnForm">
                    @csrf
                    <input type="hidden" name="request_id" id="return_request_id">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">{{ __('request.return_reason') }} <span class="text-danger">*</span></label>
                            <textarea class="form-control" name="notes" rows="3" placeholder="{{ __('request.return_reason_placeholder') }}" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">{{ __('request.cancel') }}</button>
                        <button type="submit" class="btn btn-warning">{{ __('request.return') }}</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@section('vendor-script')
<script src="{{ asset(mix('vendors/js/tables/datatable/jquery.dataTables.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.bootstrap5.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.responsive.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/responsive.bootstrap5.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
@endsection

@section('page-script')
<script>
    $(document).ready(function() {
        const table = $('#approvals-table').DataTable({
            processing: true,
            serverSide: true,
            ajax: '{{ route('admin.cybersecurity_requests.approvals.data') }}',
            columns: [{
                    data: 'request_number',
                    name: 'request_number'
                },
                {
                    data: 'requester_name',
                    name: 'requester.name'
                },
                {
                    data: 'receiving_department',
                    name: 'receiving_department'
                },
                {
                    data: 'request_type_name',
                    name: 'request_types.name'
                },
                {
                    data: 'priority_badge',
                    name: 'priority',
                    orderable: false
                },
                {
                    data: 'due_date',
                    name: 'due_date'
                },
                {
                    data: 'status_badge',
                    name: 'status',
                    orderable: false
                },
                {
                    data: 'actions',
                    name: 'actions',
                    orderable: false,
                    searchable: false
                }
            ],
            order: [
                [0, 'desc']
            ],
            responsive: true,
            language: {
                processing: '<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">{{ __('request.loading') }}</span>'
            }
        });

        // Approve request
        $(document).on('click', '.approve-request', function() {
            const id = $(this).data('id');
            $('#approve_request_id').val(id);

            // Load operators for the department
            const department = $(this).closest('tr').find('td:eq(2)').text();
            loadOperators(department);

            $('#approveModal').modal('show');
        });

        $('#approveForm').on('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);

            $.ajax({
                url: '{{ route('admin.cybersecurity_requests.approvals.approve') }}',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        $('#approveModal').modal('hide');
                        $('#approveForm')[0].reset();
                        $('.select2').val(null).trigger('change');
                        table.ajax.reload();
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr) {
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        toastr.error(xhr.responseJSON.message);
                    } else {
                        toastr.error('{{ __('request.error_approving') }}');
                    }
                }
            });
        });

        // Reject request
        $(document).on('click', '.reject-request', function() {
            const id = $(this).data('id');
            $('#reject_request_id').val(id);
            $('#rejectModal').modal('show');
        });

        $('#rejectForm').on('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);

            $.ajax({
                url: '{{ route('admin.cybersecurity_requests.approvals.reject') }}',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        $('#rejectModal').modal('hide');
                        $('#rejectForm')[0].reset();
                        table.ajax.reload();
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr) {
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        toastr.error(xhr.responseJSON.message);
                    } else {
                        toastr.error('{{ __('request.error_rejecting') }}');
                    }
                }
            });
        });

        // Return request
        $(document).on('click', '.return-request', function() {
            const id = $(this).data('id');
            $('#return_request_id').val(id);
            $('#returnModal').modal('show');
        });

        $('#returnForm').on('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);

            $.ajax({
                url: '{{ route('admin.cybersecurity_requests.approvals.return') }}',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        $('#returnModal').modal('hide');
                        $('#returnForm')[0].reset();
                        table.ajax.reload();
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr) {
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        toastr.error(xhr.responseJSON.message);
                    } else {
                        toastr.error('{{ __('request.error_returning') }}');
                    }
                }
            });
        });

        function loadOperators(department) {
            $.ajax({
                url: '{{ route('admin.cybersecurity_requests.approvals.operators') }}',
                type: 'GET',
                data: {
                    department: department
                },
                success: function(response) {
                    const select = $('#assigned_to');
                    select.empty().append('<option value="">{{ __('request.select_operator') }}</option>');

                    if (response.operators && response.operators.length > 0) {
                        response.operators.forEach(function(operator) {
                            select.append(
                                `<option value="${operator.id}">${operator.name} (${operator.email})</option>`
                                );
                        });
                    } else {
                        select.append(
                            `<option value="" disabled>{{ __('request.no_operators') }}</option>`
                            );
                    }

                    select.select2({
                        dropdownParent: $('#approveModal')
                    });
                },
                error: function() {
                    toastr.error('{{ __('request.error_loading_operators') }}');
                }
            });
        }

        // Initialize Select2
        $('.select2').select2({
            dropdownParent: $('#approveModal')
        });

        // Reset forms when modal is hidden
        $('#approveModal').on('hidden.bs.modal', function() {
            $('#approveForm')[0].reset();
            $('.select2').val(null).trigger('change');
        });

        $('#rejectModal').on('hidden.bs.modal', function() {
            $('#rejectForm')[0].reset();
        });

        $('#returnModal').on('hidden.bs.modal', function() {
            $('#returnForm')[0].reset();
        });
    });
</script>
@endsection