<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RequestCommunicationAttachment extends Model
{
    use HasFactory;

    protected $fillable = [
        'communication_id',
        'file_name',
        'file_path',
        'file_type',
        'file_size'
    ];

    protected $casts = [
        'file_size' => 'integer',
    ];

    /**
     * Get the communication that owns this attachment
     */
    public function communication()
    {
        return $this->belongsTo(RequestCommunication::class, 'communication_id');
    }

    /**
     * Get formatted file size
     */
    public function getFileSizeFormatted()
    {
        $bytes = $this->file_size;
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $i = 0;
        
        while ($bytes >= 1024 && $i < count($units) - 1) {
            $bytes /= 1024;
            $i++;
        }
        
        return round($bytes, 2) . ' ' . $units[$i];
    }

    /**
     * Get file extension
     */
    public function getFileExtension()
    {
        return pathinfo($this->file_name, PATHINFO_EXTENSION);
    }

    /**
     * Check if file is an image
     */
    public function isImage()
    {
        $imageTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml'];
        return in_array($this->file_type, $imageTypes);
    }

    /**
     * Check if file is a PDF
     */
    public function isPdf()
    {
        return $this->file_type === 'application/pdf';
    }

    /**
     * Check if file is a document
     */
    public function isDocument()
    {
        $docTypes = [
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/vnd.ms-excel',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'application/vnd.ms-powerpoint',
            'application/vnd.openxmlformats-officedocument.presentationml.presentation'
        ];
        return in_array($this->file_type, $docTypes);
    }

    /**
     * Get file icon class based on file type
     */
    public function getFileIcon()
    {
        if ($this->isImage()) {
            return 'fa-file-image';
        } elseif ($this->isPdf()) {
            return 'fa-file-pdf';
        } elseif ($this->isDocument()) {
            return 'fa-file-word';
        } elseif (strpos($this->file_type, 'zip') !== false || strpos($this->file_type, 'compressed') !== false) {
            return 'fa-file-archive';
        } else {
            return 'fa-file';
        }
    }

    /**
     * Get download URL
     */
    public function getDownloadUrl()
    {
        return \Storage::url($this->file_path);
    }
}