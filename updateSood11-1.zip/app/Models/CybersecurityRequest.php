<?php
// ============================================================
// FILE: app/Models/CybersecurityRequest.php
// ============================================================

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;

class CybersecurityRequest extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'request_number',
        'requester_id',
        'requester_department',
        'receiving_department',
        'request_type_id',
        'request_reason_id',
        'priority',
        'due_date',
        'description',
        'status',
        'final_status',
        'assigned_to',
        'approved_by',
        'approved_at',
        'approval_notes',
        'completed_at',
        'is_late'
    ];


    protected static function boot()
    {
        parent::boot();
        static::creating(function ($model) {
            $year = date('Y');

            $lastNumber = self::withTrashed()
                ->where('request_number', 'like', "REQ-$year-%")
                ->max(DB::raw("CAST(SUBSTRING(request_number, -6) AS UNSIGNED)"));

            $nextNumber = ($lastNumber ?? 0) + 1;

            $model->request_number = 'REQ-' . $year . '-' . str_pad($nextNumber, 6, '0', STR_PAD_LEFT);
        });

        static::updating(function ($request) {
            if ($request->isDirty('status') && $request->status === 'closed') {
                $request->completed_at = now();
            }
        });
    }

    // ========== Relationships ==========

    /**
     * Get the user who created this request
     */
    public function requester()
    {
        return $this->belongsTo(User::class, 'requester_id');
    }

    /**
     * Get the user assigned to handle this request
     */
    public function assignedUser()
    {
        return $this->belongsTo(User::class, 'assigned_to');
    }

    /**
     * Get the user who approved this request
     */
    public function approver()
    {
        return $this->belongsTo(User::class, 'approved_by');
    }

    /**
     * Get all attachments for this request
     */
    public function attachments()
    {
        return $this->hasMany(RequestAttachment::class, 'request_id');
    }

    /**
     * Get all communications for this request
     */
    public function communications()
    {
        return $this->hasMany(RequestCommunication::class, 'request_id')
            ->orderBy('created_at', 'desc');
    }

    /**
     * Get complete history of this request
     */
    public function history()
    {
        return $this->hasMany(RequestHistory::class, 'request_id')
            ->orderBy('created_at', 'desc');
    }

    // ========== Query Scopes ==========

    /**
     * Scope to filter requests by department
     */
    public function scopeByDepartment($query, $department)
    {
        return $query->where('receiving_department', $department);
    }

    /**
     * Scope to filter requests by status
     */
    public function scopeByStatus($query, $status)
    {
        return $query->where('status', $status);
    }

    /**
     * Scope to get late requests
     */
    public function scopeLate($query)
    {
        return $query->where('due_date', '<', now())
            ->whereNotIn('status', ['closed', 'rejected']);
    }

    /**
     * Scope to get requests created by specific user
     */
    public function scopeMyRequests($query, $userId)
    {
        return $query->where('requester_id', $userId);
    }

    /**
     * Scope to get requests assigned to specific user
     */
    public function scopeAssignedToMe($query, $userId)
    {
        return $query->where('assigned_to', $userId);
    }

    /**
     * Scope to get pending requests (not closed or rejected)
     */
    public function scopePending($query)
    {
        return $query->whereNotIn('status', ['closed', 'rejected']);
    }

    /**
     * Scope to get completed requests
     */
    public function scopeCompleted($query)
    {
        return $query->where('status', 'closed');
    }

    /**
     * Scope to get requests by priority
     */
    public function scopeByPriority($query, $priority)
    {
        return $query->where('priority', $priority);
    }

    // ========== Helper Methods ==========

    /**
     * Check if request is late
     */
    public function isLate()
    {
        return $this->due_date < now() && !in_array($this->status, ['closed', 'rejected']);
    }

    /**
     * Get processing time in days
     */
    public function getProcessingTime()
    {
        if ($this->completed_at) {
            return $this->created_at->diffInDays($this->completed_at);
        }
        return null;
    }

    /**
     * Get time remaining until due date (in days)
     */
    public function getTimeRemaining()
    {
        if ($this->due_date > now()) {
            return now()->diffInDays($this->due_date);
        }
        return 0;
    }

    /**
     * Get number of days overdue
     */
    public function getDaysOverdue()
    {
        if ($this->due_date < now() && !in_array($this->status, ['closed', 'rejected'])) {
            return $this->due_date->diffInDays(now());
        }
        return 0;
    }

    /**
     * Add entry to request history
     */
    public function addHistory($action, $oldStatus = null, $newStatus = null, $notes = null)
    {
        return $this->history()->create([
            'user_id' => auth()->id(),
            'action' => $action,
            'old_status' => $oldStatus,
            'new_status' => $newStatus,
            'notes' => $notes
        ]);
    }

    /**
     * Check if user can edit this request
     */
    public function canBeEditedBy($user)
    {
        if ($this->status === 'closed' || $this->status === 'rejected') {
            return false;
        }

        if ($user->hasPermission('cybersecurity_requests.edit_all')) {
            return true;
        }

        return $this->requester_id === $user->id &&
            $user->hasPermission('cybersecurity_requests.edit');
    }

    /**
     * Check if user can view this request
     */
    public function canBeViewedBy($user)
    {
        if ($user->hasPermission('cybersecurity_requests.view_all')) {
            return true;
        }

        return $this->requester_id === $user->id ||
            $this->assigned_to === $user->id;
    }

    /**
     * Get status color for UI
     */
    public function getStatusColor()
    {
        $colors = [
            'created' => 'info',
            'under management approval' => 'warning',
            'approved' => 'success',
            'under process' => 'primary',
            'closed' => 'secondary',
            'rejected' => 'danger',
            'planned' => 'info',
            'returned' => 'warning'
        ];

        return $colors[$this->status] ?? 'secondary';
    }

    /**
     * Get priority color for UI
     */
    public function getPriorityColor()
    {
        $colors = [
            'High' => 'danger',
            'Moderate' => 'warning',
            'Low' => 'success'
        ];

        return $colors[$this->priority] ?? 'secondary';
    }

    public function requestType()
    {
        return $this->belongsTo(RequestType::class);
    }

    public function requestReason()
    {
        return $this->belongsTo(RequestReason::class);
    }

    public function department()
    {
        return $this->belongsTo(Department::class, 'receiving_department');
    }

    public function requesterDepartment()
    {
        return $this->belongsTo(Department::class, 'requester_department');
    }
}
