<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RequestReason extends Model
{
    protected $fillable = ['name'];

    public function requests()
    {
        return $this->hasMany(CybersecurityRequest::class);
    }
}

