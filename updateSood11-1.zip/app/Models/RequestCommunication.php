<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RequestCommunication extends Model
{
    use HasFactory;

    protected $fillable = [
        'request_id',
        'user_id',
        'message'
    ];

    /**
     * Get the request this communication belongs to
     */
    public function request()
    {
        return $this->belongsTo(CybersecurityRequest::class, 'request_id');
    }

    /**
     * Get the user who created this communication
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get all attachments for this communication
     */
    public function attachments()
    {
        return $this->hasMany(RequestCommunicationAttachment::class, 'communication_id');
    }

    /**
     * Check if communication has attachments
     */
    public function hasAttachments()
    {
        return $this->attachments()->count() > 0;
    }

    /**
     * Get formatted time ago
     */
    public function getTimeAgo()
    {
        return $this->created_at->diffForHumans();
    }

    /**
     * Check if this communication was created by the requester
     */
    public function isFromRequester()
    {
        return $this->user_id === $this->request->requester_id;
    }

    /**
     * Check if this communication was created by the assigned operator
     */
    public function isFromOperator()
    {
        return $this->user_id === $this->request->assigned_to;
    }

    /**
     * Scope to get communications by specific user
     */
    public function scopeByUser($query, $userId)
    {
        return $query->where('user_id', $userId);
    }

    /**
     * Scope to get recent communications
     */
    public function scopeRecent($query, $limit = 10)
    {
        return $query->orderBy('created_at', 'desc')->limit($limit);
    }
}
