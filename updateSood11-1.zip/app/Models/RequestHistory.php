<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RequestHistory extends Model
{
    use HasFactory;

    protected $fillable = [
        'request_id',
        'user_id',
        'action',
        'old_status',
        'new_status',
        'notes'
    ];

    /**
     * Get the request this history entry belongs to
     */
    public function request()
    {
        return $this->belongsTo(CybersecurityRequest::class, 'request_id');
    }

    /**
     * Get the user who performed this action
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get formatted time ago
     */
    public function getTimeAgo()
    {
        return $this->created_at->diffForHumans();
    }

    /**
     * Check if this is a status change
     */
    public function isStatusChange()
    {
        return !is_null($this->old_status) && !is_null($this->new_status) && 
               $this->old_status !== $this->new_status;
    }

    /**
     * Get action icon based on action type
     */
    public function getActionIcon()
    {
        $icons = [
            'Request Created' => 'fa-plus-circle',
            'Request Updated' => 'fa-edit',
            'Request Approved' => 'fa-check-circle',
            'Request Rejected' => 'fa-times-circle',
            'Request Returned' => 'fa-undo',
            'Request Processing Started' => 'fa-play-circle',
            'Request Closed' => 'fa-check-double',
            'Request Refused by Operator' => 'fa-ban',
            'Request Marked as Late' => 'fa-clock',
        ];

        return $icons[$this->action] ?? 'fa-info-circle';
    }

    /**
     * Get action color based on action type
     */
    public function getActionColor()
    {
        $colors = [
            'Request Created' => 'info',
            'Request Updated' => 'primary',
            'Request Approved' => 'success',
            'Request Rejected' => 'danger',
            'Request Returned' => 'warning',
            'Request Processing Started' => 'primary',
            'Request Closed' => 'success',
            'Request Refused by Operator' => 'danger',
            'Request Marked as Late' => 'danger',
        ];

        return $colors[$this->action] ?? 'secondary';
    }

    /**
     * Scope to get history by action
     */
    public function scopeByAction($query, $action)
    {
        return $query->where('action', $action);
    }

    /**
     * Scope to get history by user
     */
    public function scopeByUser($query, $userId)
    {
        return $query->where('user_id', $userId);
    }

    /**
     * Scope to get status changes only
     */
    public function scopeStatusChanges($query)
    {
        return $query->whereNotNull('old_status')
                    ->whereNotNull('new_status');
    }

    /**
     * Scope to get recent history
     */
    public function scopeRecent($query, $limit = 10)
    {
        return $query->orderBy('created_at', 'desc')->limit($limit);
    }
}