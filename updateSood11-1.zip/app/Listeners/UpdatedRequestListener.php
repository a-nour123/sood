<?php

namespace App\Listeners;

use App\Events\UpdatedRequest;
use App\Http\Traits\NotificationHandlingTrait;
use App\Models\Action;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class UpdatedRequestListener
{
    use NotificationHandlingTrait;

    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  \App\Events\UpdatedRequest  $event
     * @return void
     */
    public function handle(UpdatedRequest $event)
    {
        // Action
        $action = Action::where('name', 'update_request')->first();
        $actionId1 = $action?->id;

        // Request
        $request = $event->cybersecurityRequest;

        $request->load([
            'requester',
            'assignedUser',
            'approver',
            'communications.user',
            'requestType',
            'requestReason',
            'department.manager',
            'requesterDepartment.manager',
        ]);

        // Roles
        $roles = [
            'requester' => [$request?->requester_id],
            'receiving_department_manager' => [$request?->department?->manager_id],
            'department_manager' => [$request?->requesterDepartment?->manager_id],
            'assigned' => [$request?->assigned_to],
            'approved_by' => [$request?->approved_by],

            'communication_users' => $request->communications
                ? $request->communications
                ->pluck('user_id')
                ->filter()
                ->unique()
                ->values()
                ->toArray()
                : [],
        ];

        // Link
        $link = [
            'link' => route('admin.cybersecurity_requests.index'),
        ];

        /*
    |--------------------------------------------------------------------------
    | Safe attributes (no $control, null-safe)
    |--------------------------------------------------------------------------
    */
        $request->requester_name = $request->requester?->name;
        $request->requester_department = $request->requesterDepartment?->manager?->name;
        $request->receiving_department = $request->department?->manager?->name;
        $request->type = $request->requestType?->name;
        $request->reason = $request->requestReason?->name;
        $request->assigne_name = $request->assignedUser?->name;
        $request->approver_name = $request->approver?->name;

        /*
    |--------------------------------------------------------------------------
    | Communications (implode users & messages)
    |--------------------------------------------------------------------------
    */
        $request->communication = $request->communications
            ?->pluck('message')
            ->filter()
            ->implode(' | ');

        $request->communication_by = $request->communications
            ?->pluck('user.name')
            ->filter()
            ->unique()
            ->implode(' , ');


        /*
    |--------------------------------------------------------------------------
    | Send notification
    |--------------------------------------------------------------------------
    */
        $this->sendNotificationForAction(
            $actionId1,
            null,               // actionId2
            $link,
            $request,            // updatedFrames
            $roles,
            null,               // nextDateNotify
            $request->id,        // modelId
            null, // modelType
            null                // process
        );
    }
}
