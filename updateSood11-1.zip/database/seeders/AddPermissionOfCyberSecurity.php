<?php

namespace Database\Seeders;

use App\Models\PermissionGroup;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\Subgroup;

class AddPermissionOfCyberSecurity extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        $permissionGroups  = PermissionGroup::pluck('id', 'name');
        $governanceId = $permissionGroups['Governance'];
        
        $subgroup= Subgroup::create([
            'name' => 'Cybersecurity Requests',
            "permission_group_id" => $governanceId
        ]);


        $subId = $subgroup->id;

        // Define all permissions needed for all controllers
        $permissions = [
            // ========== CybersecurityRequestController permissions ==========

            // View permissions
            [
                'key' => 'cybersecurity_requests.view',
                'name' => 'view cybersecurity request',
                'subgroup_id' => $subId,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'key' => 'cybersecurity_requests.view_all',
                'name' => 'view all cybersecurity requests',
                'subgroup_id' => $subId,
                'created_at' => now(),
                'updated_at' => now(),
            ],

            // CRUD permissions
            [
                'key' => 'cybersecurity_requests.create',
                'name' => 'create cybersecurity request',
                'subgroup_id' => $subId,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'key' => 'cybersecurity_requests.edit',
                'name' => 'edit cybersecurity request',
                'subgroup_id' => $subId,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'key' => 'cybersecurity_requests.edit_all',
                'name' => 'edit all cybersecurity requests',
                'subgroup_id' => $subId,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'key' => 'cybersecurity_requests.delete',
                'name' => 'delete cybersecurity request',
                'subgroup_id' => $subId,
                'created_at' => now(),
                'updated_at' => now(),
            ],

            // ========== RequestApprovalController permissions ==========

            // Approval workflow permissions
            [
                'key' => 'cybersecurity_requests.approve',
                'name' => 'approve cybersecurity request',
                'subgroup_id' => $subId,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'key' => 'cybersecurity_requests.operate',
                'name' => 'operate cybersecurity request',
                'subgroup_id' => $subId,
                'created_at' => now(),
                'updated_at' => now(),
            ],

            // Additional approval actions
            [
                'key' => 'cybersecurity_requests.reject',
                'name' => 'reject cybersecurity request',
                'subgroup_id' => $subId,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'key' => 'cybersecurity_requests.return',
                'name' => 'return cybersecurity request',
                'subgroup_id' => $subId,
                'created_at' => now(),
                'updated_at' => now(),
            ],

            // ========== RequestDashboardController permissions ==========

            // Dashboard permissions
            [
                'key' => 'cybersecurity_requests.dashboard',
                'name' => 'view cybersecurity dashboard',
                'subgroup_id' => $subId,
                'created_at' => now(),
                'updated_at' => now(),
            ],

            // Dashboard-specific permissions
            [
                'key' => 'cybersecurity_requests.dashboard.view_charts',
                'name' => 'view dashboard charts',
                'subgroup_id' => $subId,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'key' => 'cybersecurity_requests.dashboard.view_analytics',
                'name' => 'view dashboard analytics',
                'subgroup_id' => $subId,
                'created_at' => now(),
                'updated_at' => now(),
            ],

            // ========== RequestOperatorController permissions ==========

            // Operator-specific permissions
            [
                'key' => 'cybersecurity_requests.operator.confirm',
                'name' => 'confirm cybersecurity request',
                'subgroup_id' => $subId,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'key' => 'cybersecurity_requests.operator.refuse',
                'name' => 'refuse cybersecurity request',
                'subgroup_id' => $subId,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'key' => 'cybersecurity_requests.operator.close',
                'name' => 'close cybersecurity request',
                'subgroup_id' => $subId,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'key' => 'cybersecurity_requests.operator.add_communication',
                'name' => 'add communication to request',
                'subgroup_id' => $subId,
                'created_at' => now(),
                'updated_at' => now(),
            ],

            // ========== Shared/Additional permissions ==========

            // Management permissions
            [
                'key' => 'cybersecurity_requests.assign',
                'name' => 'assign cybersecurity request',
                'subgroup_id' => $subId,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'key' => 'cybersecurity_requests.update_status',
                'name' => 'update cybersecurity request status',
                'subgroup_id' => $subId,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'key' => 'cybersecurity_requests.add_communication',
                'name' => 'add communication to cybersecurity request',
                'subgroup_id' => $subId,
                'created_at' => now(),
                'updated_at' => now(),
            ],

            // Reports and analytics
            [
                'key' => 'cybersecurity_requests.reports',
                'name' => 'view cybersecurity reports',
                'subgroup_id' => $subId,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'key' => 'cybersecurity_requests.export',
                'name' => 'export cybersecurity data',
                'subgroup_id' => $subId,
                'created_at' => now(),
                'updated_at' => now(),
            ],

            // Notification permissions
            [
                'key' => 'cybersecurity_requests.notifications',
                'name' => 'receive cybersecurity notifications',
                'subgroup_id' => $subId,
                'created_at' => now(),
                'updated_at' => now(),
            ],

            // Audit/log permissions
            [
                'key' => 'cybersecurity_requests.audit_logs',
                'name' => 'view audit logs',
                'subgroup_id' => $subId,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ];

        // Insert permissions (skip duplicates)
        foreach ($permissions as $permission) {
            if (!DB::table('permissions')->where('key', $permission['key'])->exists()) {
                DB::table('permissions')->insert($permission);
            }
        }

        // ========== Assign permissions to roles ==========

        // 1. Super Admin (role_id = 1) - Gets ALL permissions
        $superAdminRoleId = 1;

        foreach ($permissions as $permission) {
            $permissionId = DB::table('permissions')
                ->where('key', $permission['key'])
                ->value('id');

            if ($permissionId) {
                // Check if already assigned
                $exists = DB::table('role_responsibilities')
                    ->where('role_id', $superAdminRoleId)
                    ->where('permission_id', $permissionId)
                    ->exists();

                if (!$exists) {
                    DB::table('role_responsibilities')->insert([
                        'role_id' => $superAdminRoleId,
                        'permission_id' => $permissionId,
                    ]);
                }
            }
        }



        $this->command->info('All cybersecurity permissions have been seeded successfully!');
    }
}
