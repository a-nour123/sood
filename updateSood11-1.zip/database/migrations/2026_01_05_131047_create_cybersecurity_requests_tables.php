<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('cybersecurity_requests', function (Blueprint $table) {
            $table->id();

            $table->string('request_number')->unique();

            $table->foreignId('requester_id')
                  ->constrained('users')
                  ->cascadeOnDelete();

            $table->string('requester_department');

            $table->foreignId('receiving_department')
                  ->constrained('departments')
                  ->cascadeOnDelete();

            // ✅ NEW: Request Type (FK)
            $table->foreignId('request_type_id')
                  ->constrained('request_types')
                  ->cascadeOnDelete();

            // ✅ NEW: Request Reason (FK)
            $table->foreignId('request_reason_id')
                  ->constrained('request_reasons')
                  ->cascadeOnDelete();

            $table->enum('priority', ['High', 'Moderate', 'Low']);

            $table->dateTime('due_date');

            $table->text('description');

            $table->enum('status', [
                'created',
                'under management approval',
                'approved',
                'under process',
                'closed',
                'rejected',
                'planned',
                'returned'
            ])->default('created');

            $table->string('final_status')->nullable();

            $table->foreignId('assigned_to')
                  ->nullable()
                  ->constrained('users')
                  ->nullOnDelete();

            $table->foreignId('approved_by')
                  ->nullable()
                  ->constrained('users')
                  ->nullOnDelete();

            $table->dateTime('approved_at')->nullable();

            $table->text('approval_notes')->nullable();

            $table->dateTime('completed_at')->nullable();

            $table->boolean('is_late')->default(false);

            $table->timestamps();
            $table->softDeletes();

            // Indexes
            $table->index(['status', 'receiving_department']);
            $table->index(['requester_id', 'created_at']);
            $table->index('due_date');
        });

        Schema::create('request_attachments', function (Blueprint $table) {
            $table->id();

            $table->foreignId('request_id')
                  ->constrained('cybersecurity_requests')
                  ->cascadeOnDelete();

            $table->string('file_name');
            $table->string('file_path');
            $table->string('file_type');
            $table->integer('file_size');

            $table->timestamps();
        });

        Schema::create('request_communications', function (Blueprint $table) {
            $table->id();

            $table->foreignId('request_id')
                  ->constrained('cybersecurity_requests')
                  ->cascadeOnDelete();

            $table->foreignId('user_id')
                  ->constrained('users')
                  ->cascadeOnDelete();

            $table->text('message');

            $table->timestamps();
        });

        Schema::create('request_communication_attachments', function (Blueprint $table) {
            $table->id();

            $table->foreignId('communication_id')
                  ->constrained('request_communications')
                  ->cascadeOnDelete();

            $table->string('file_name');
            $table->string('file_path');
            $table->string('file_type');
            $table->integer('file_size');

            $table->timestamps();
        });

        Schema::create('request_history', function (Blueprint $table) {
            $table->id();

            $table->foreignId('request_id')
                  ->constrained('cybersecurity_requests')
                  ->cascadeOnDelete();

            $table->foreignId('user_id')
                  ->constrained('users')
                  ->cascadeOnDelete();

            $table->string('action');
            $table->string('old_status')->nullable();
            $table->string('new_status')->nullable();
            $table->text('notes')->nullable();

            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('request_history');
        Schema::dropIfExists('request_communication_attachments');
        Schema::dropIfExists('request_communications');
        Schema::dropIfExists('request_attachments');
        Schema::dropIfExists('cybersecurity_requests');
    }
};
