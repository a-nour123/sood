<?php
// ============================================================
// FILE: routes/admin/cybersecurity_requests.php
// ============================================================

use App\Http\Controllers\admin\CyberSecurity\CybersecurityRequestController;
use App\Http\Controllers\admin\CyberSecurity\RequestApprovalController;
use App\Http\Controllers\admin\CyberSecurity\RequestDashboardController;
use App\Http\Controllers\admin\CyberSecurity\RequestOperatorController;
use Illuminate\Support\Facades\Route;

// ============================================================
// CYBERSECURITY REQUESTS MANAGEMENT ROUTES
// ============================================================

Route::prefix('cybersecurity-requests')->name('cybersecurity_requests.')->group(function () {

    // ========== Main Request Routes ==========
    Route::get('/configuration', [CybersecurityRequestController::class, 'configure'])->name('configuretion');
    Route::get('/notifications', [CybersecurityRequestController::class, 'notificationsSetting'])->name('notificationsSetting');

    Route::get('/', [CybersecurityRequestController::class, 'index'])->name('index');

    Route::get('/data', [CybersecurityRequestController::class, 'getData'])->name('data');

    Route::get('/create', [CybersecurityRequestController::class, 'create'])->name('create');

    Route::post('/store', [CybersecurityRequestController::class, 'store'])->name('store');

    Route::get('/{id}', [CybersecurityRequestController::class, 'show'])->name('show');

    Route::post('/edit-request', [CybersecurityRequestController::class, 'edit'])->name('edit');

    Route::put('/{id}', [CybersecurityRequestController::class, 'update'])->name('update');

    Route::delete('/{id}', [CybersecurityRequestController::class, 'destroy'])->name('destroy');

    // ========== Attachment Routes ==========

    Route::delete('/attachment/{id}', function ($id) {
        try {
            $attachment = \App\Models\RequestAttachment::findOrFail($id);

            \Storage::disk('public')->delete($attachment->file_path);
            $attachment->delete();

            return response()->json([
                'success' => true,
                'message' => 'Attachment deleted successfully'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error deleting attachment: ' . $e->getMessage()
            ], 500);
        }
    })->name('attachment.delete');

    // ========== Communication Routes ==========

    Route::post('/{id}/communication', [RequestOperatorController::class, 'addCommunication'])
        ->name('communication.add');
});

// ============================================================
// APPROVAL ROUTES
// ============================================================

Route::prefix('requests/approvals')->name('cybersecurity_requests.approvals.')->group(function () {

    Route::get('/', [RequestApprovalController::class, 'index'])->name('index');

    Route::get('/data', [RequestApprovalController::class, 'getData'])->name('data');

    Route::post('/approve', [RequestApprovalController::class, 'approve'])->name('approve');

    Route::post('/reject', [RequestApprovalController::class, 'reject'])->name('reject');

    Route::post('/return', [RequestApprovalController::class, 'return'])->name('return');

    Route::get('/operators', [RequestApprovalController::class, 'getOperators'])->name('operators');
});

// ============================================================
// OPERATOR ROUTES
// ============================================================

Route::prefix('requests/operator')->name('cybersecurity_requests.operator.')->group(function () {

    Route::get('/', [RequestOperatorController::class, 'index'])->name('index');

    Route::get('/data', [RequestOperatorController::class, 'getData'])->name('data');

    Route::post('/confirm', [RequestOperatorController::class, 'confirm'])->name('confirm');

    Route::post('/refuse', [RequestOperatorController::class, 'refuse'])->name('refuse');

    Route::post('/close', [RequestOperatorController::class, 'close'])->name('close');
});

// ============================================================
// DASHBOARD ROUTES
// ============================================================

Route::prefix('requests/dashboard')->name('cybersecurity_requests.dashboard.')->group(function () {

    Route::get('/', [RequestDashboardController::class, 'index'])->name('index');

    Route::get('/chart-data', [RequestDashboardController::class, 'getChartData'])->name('chart-data');
});

// ============================================================
// SIMPLIFIED ROUTE ALIASES
// ============================================================

Route::get('/requests/approvals', [RequestApprovalController::class, 'index'])
    ->name('cybersecurity_requests.approvals');

Route::get('/requests/operator', [RequestOperatorController::class, 'index'])
    ->name('cybersecurity_requests.operator');

Route::get('/requests/dashboard', [RequestDashboardController::class, 'index'])
    ->name('cybersecurity_requests.dashboard');
