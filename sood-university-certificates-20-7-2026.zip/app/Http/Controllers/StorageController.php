<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class StorageController extends Controller
{
    /**
     * Serve LMS Course files with authentication check
     *
     * This method ensures that only authenticated users can access
     * files in the storage/LMS/Courses directory
     *
     * @param Request $request
     * @param string $path
     * @return BinaryFileResponse|\Illuminate\Http\Response
     */
    public function serveLMSCourseFile(Request $request, $path = '')
    {
        // Check if user is authenticated (defensive check, though middleware already ensures this)
        if (!Auth::check()) {
            abort(401, 'Unauthorized. Authentication required.');
        }

        // Check if user has permission to access LMS courses
        // This ensures only authorized users can access course materials
        if (!Auth::user()->hasPermission('courses.list')) {
            abort(403, 'Forbidden. You do not have permission to access this resource.');
        }

        // Sanitize the path to prevent directory traversal attacks
        $path = ltrim($path, '/');
        $path = str_replace('..', '', $path); // Remove any directory traversal attempts

        // Ensure path is not empty
        if (empty($path)) {
            abort(404, 'File not found.');
        }

        // Construct the full file path
        $filePath = 'public/LMS/Courses/' . $path;

        // Check if file exists in storage
        if (!Storage::disk('local')->exists($filePath)) {
            abort(404, 'File not found.');
        }

        // Get the full path to the file
        $fullPath = Storage::disk('local')->path($filePath);

        // Verify the file is within the LMS/Courses directory (security check against path traversal)
        $realPath = realpath($fullPath);
        $storageBasePath = Storage::disk('local')->path('public/LMS/Courses');
        $storageRealPath = realpath($storageBasePath);

        // Ensure both paths resolve correctly
        if (!$realPath || !$storageRealPath) {
            abort(404, 'File not found.');
        }

        // Verify the resolved path is within the allowed directory
        if (strpos($realPath, $storageRealPath) !== 0) {
            abort(403, 'Access denied. Invalid file path.');
        }

        // Get MIME type for proper content type header
        $mimeType = Storage::mimeType($filePath);
        if (!$mimeType) {
            $mimeType = 'application/octet-stream';
        }

        // Return the file with appropriate headers
        return response()->file($realPath, [
            'Content-Type' => $mimeType,
            'Content-Disposition' => 'inline; filename="' . basename($path) . '"',
            'Cache-Control' => 'private, max-age=3600',
        ]);
    }
}
