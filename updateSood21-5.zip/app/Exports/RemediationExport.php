<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithColumnWidths;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithCustomStartCell;
use Maatwebsite\Excel\Events\AfterSheet;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Font;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;
use App\Models\AuditResponsible;
use App\Models\RemediationDetail;
use Carbon\Carbon;
use Illuminate\Support\Facades\App;

class RemediationExport implements FromArray, WithStyles, WithColumnWidths, WithEvents, WithCustomStartCell
{
    protected $frameworkId;
    protected $auditId;
    protected $remediationData = [];
    protected $companyName;
    protected $auditName;
    protected $frameworkName;
    protected $statistics = [];
    protected $isRTL = false;
    protected $drawings = [];

    public function __construct($frameworkId, $auditId, $companyName = "King Saud University")
    {
        $this->frameworkId = $frameworkId;
        $this->auditId = $auditId;
        $this->companyName = $companyName;

        // Check if current locale is Arabic (RTL)
        $this->isRTL = App::getLocale() == 'ar';

        $this->prepareData();
        $this->calculateStatistics();
    }

    protected function prepareData()
    {
        // Load AuditResponsible
        $audit = AuditResponsible::with(['frameworkaduit:id,name'])
            ->where('framework_id', $this->frameworkId)
            ->where('id', $this->auditId)
            ->first();

        if (!$audit) {
            $this->remediationData = [];
            return;
        }

        $this->auditName = $audit->audit_name;
        $this->frameworkName = $audit->frameworkaduit->name ?? '';

        // Load remediation details separately
        $remediationDetails = RemediationDetail::with([
            'user:id,name,department_id',
            'user.department:id,name',
            'controlTestAudit.frameworkControl:id,short_name',
            'controlTestAudit.auditResponsible:id,audit_name',
        ])
            ->whereHas('controlTestAudit', function ($query) use ($audit) {
                $query->where('audit_id', $audit->id);
            })
            ->get();

        $rows = collect();

        foreach ($remediationDetails as $remediation) {
            $controlTestAudit = $remediation->controlTestAudit;

            if (!$controlTestAudit) {
                continue;
            }

            $rows->push([
                __('report.Framework Name')          => $this->frameworkName,
                __('report.Audit Name')              => $this->auditName,
                __('report.Control Name')            => $controlTestAudit->frameworkControl->name ?? $controlTestAudit->name ?? '',
                __('report.Control Short Name')      => $controlTestAudit->frameworkControl->short_name ?? '',
                __('report.Responsible User')        => $remediation->user->name ?? '',
                __('report.Department')              => $remediation->user->department->name ?? '',
                __('report.Corrective Action Plan')  => strip_tags($remediation->corrective_action_plan ?? ''),
                __('report.Budgetary')               => $this->formatBudgetary($remediation->budgetary ?? ''),
                __('report.Status')                  => $this->getStatusText($remediation->status ?? ''),
                __('report.Due Date')                => $remediation?->due_date ? Carbon::parse($remediation->due_date)->format('Y-m-d') : '',
                __('report.Comments')                => $remediation->comments ?? '',
                'Is Overdue'                         => $this->isOverdue($remediation),
            ]);
        }

        $this->remediationData = $rows->toArray();
    }

    protected function calculateStatistics()
    {
        $totalRemediations = count($this->remediationData);

        // Count by status
        $approvedCount = 0;
        $rejectedCount = 0;
        $pendingCount = 0;
        $overdueCount = 0;
        $totalBudget = 0;

        foreach ($this->remediationData as $item) {
            switch ($item[__('report.Status')]) {
                case __('report.Approved'):
                    $approvedCount++;
                    break;
                case __('report.Rejected'):
                    $rejectedCount++;
                    break;
                case __('report.Pending'):
                    $pendingCount++;
                    break;
            }

            // Calculate overdue
            if ($item['Is Overdue']) {
                $overdueCount++;
            }

            // Calculate budget
            $budgetValue = $item[__('report.Budgetary')] ?? '';
            if (!empty($budgetValue) && is_numeric(str_replace(['$', ',', ' '], '', $budgetValue))) {
                $totalBudget += floatval(str_replace(['$', ',', ' '], '', $budgetValue));
            }
        }

        // Calculate percentages
        $completionRate = $totalRemediations > 0 ?
            round((($approvedCount + $rejectedCount) / $totalRemediations) * 100, 2) : 0;

        $approvalRate = $totalRemediations > 0 ?
            round(($approvedCount / $totalRemediations) * 100, 2) : 0;

        $this->statistics = [
            'total_remediations' => $totalRemediations,
            'approved_count' => $approvedCount,
            'rejected_count' => $rejectedCount,
            'pending_count' => $pendingCount,
            'overdue_count' => $overdueCount,
            'total_budget' => $totalBudget,
            'completion_rate' => $completionRate,
            'approval_rate' => $approvalRate,
        ];
    }

    public function drawings()
    {
        return $this->drawings;
    }

    protected function getStatusText($status)
    {
        return match ($status) {
            1 => __('report.Approved'),
            2 => __('report.Rejected'),
            default => __('report.Pending'),
        };
    }

    protected function formatBudgetary($budgetary)
    {
        if (empty($budgetary)) return '';

        // Format as currency if it's numeric
        if (is_numeric(str_replace(['$', ',', ' '], '', $budgetary))) {
            $value = floatval(str_replace(['$', ',', ' '], '', $budgetary));
            return '$' . number_format($value, 2);
        }

        return $budgetary;
    }

    protected function isOverdue($remediation)
    {
        if (!$remediation || empty($remediation->due_date)) {
            return false;
        }

        $dueDate = Carbon::parse($remediation->due_date);
        $status = $remediation->status;

        // Only pending items can be overdue
        return ($status != 1 && $status != 2) && $dueDate->isPast();
    }

    public function array(): array
    {
        // If no data, return empty with message
        if (empty($this->remediationData)) {
            return [
                [__('report.Remediation Plan Report')],
                [__('report.No remediation data found for the selected audit.')],
                [''],
                [__('report.Framework') . ': ' . $this->frameworkName],
                [__('report.Audit') . ': ' . $this->auditName],
                [__('report.Generated on') . ': ' . Carbon::now()->format('F j, Y H:i')],
            ];
        }

        // ── Row 1: Header ─────────────────────────────────────────────────────
        // Logo  → A1:B1 (merged)
        // Title → C1:D1 (merged, centered)
        $data = [];
        
        // Row 1: A1=empty (logo), B1=empty (part of logo merge), C1=Title, D1=empty (part of title merge)
        $data[0] = [
            '',                                      // A1 — logo (merged A:B)
            '',                                      // B1 — part of logo merge
            __('report.Remediation Plan Report'),    // C1 — title (merged C:D)
            '',                                      // D1 — part of title merge
            '',                                      // E1
            '',                                      // F1
            '',                                      // G1
            '',                                      // H1
            '',                                      // I1
            '',                                      // J1
            '',                                      // K1
        ];

        // Row 2: Spacer row (empty)
        $data[1] = array_fill(0, 11, '');

        // Row 3: Subtitle
        $data[2] = [__('report.Audit Remediation Details - Controls with Remediation Actions'), '', '', '', '', '', '', '', '', '', ''];

        // Row 4-5: Spacers
        $data[3] = array_fill(0, 11, '');
        $data[4] = array_fill(0, 11, '');

        // Row 6: Report Information header
        $data[5] = [__('report.Report Information'), '', '', '', '', '', '', '', '', '', ''];
        
        // Row 7: Report Information labels
        $data[6] = [
            __('report.Framework'),
            __('report.Audit'),
            __('report.Total Controls with Remediation'),
            __('report.Generated By'),
            __('report.Generation Date'),
            '', '', '', '', '', ''
        ];
        
        // Row 8: Report Information values
        $data[7] = [
            $this->frameworkName,
            $this->auditName,
            count($this->remediationData),
            auth()->user()->name ?? __('report.System'),
            Carbon::now()->format('d/m/Y H:i'),
            '', '', '', '', '', ''
        ];

        // Row 9-10: Spacers
        $data[8] = array_fill(0, 11, '');
        $data[9] = array_fill(0, 11, '');

        // Row 11: Report Purpose header
        $data[10] = [__('report.Report Purpose') . ':', '', '', '', '', '', '', '', '', '', ''];
        
        // Row 12: Report Purpose description line 1
        $data[11] = [__('report.This report provides detailed information about remediation plans and corrective actions for audit findings.'), '', '', '', '', '', '', '', '', '', ''];
        
        // Row 13: Report Purpose description line 2
        $data[12] = [__('report.It includes only controls that have remediation actions assigned, with assigned responsibilities, budgetary requirements, and implementation timelines.'), '', '', '', '', '', '', '', '', '', ''];

        // Row 14-16: Spacers
        $data[13] = array_fill(0, 11, '');
        $data[14] = array_fill(0, 11, '');
        $data[15] = array_fill(0, 11, '');

        // Row 17: Header Row
        $data[16] = [
            __('report.Framework Name'),
            __('report.Audit Name'),
            __('report.Control Name'),
            __('report.Control Short Name'),
            __('report.Responsible User'),
            __('report.Department'),
            __('report.Corrective Action Plan'),
            __('report.Budgetary'),
            __('report.Status'),
            __('report.Due Date'),
            __('report.Comments')
        ];

        // Data rows (starting from row 18)
        $rowIndex = 17;
        foreach ($this->remediationData as $item) {
            $data[$rowIndex] = [
                $item[__('report.Framework Name')],
                $item[__('report.Audit Name')],
                $item[__('report.Control Name')],
                $item[__('report.Control Short Name')],
                $item[__('report.Responsible User')],
                $item[__('report.Department')],
                $item[__('report.Corrective Action Plan')],
                $item[__('report.Budgetary')],
                $item[__('report.Status')],
                $item[__('report.Due Date')],
                $item[__('report.Comments')]
            ];
            $rowIndex++;
        }

        return $data;
    }

    public function startCell(): string
    {
        return 'A1';
    }

    public function styles(Worksheet $sheet)
    {
        $totalDataRows = count($this->remediationData);
        $horizontalAlignment = $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_LEFT;

        // If no data, style the message
        if ($totalDataRows === 0) {
            return [
                1 => [
                    'font' => ['bold' => true, 'size' => 18, 'color' => ['rgb' => '1B365D']],
                    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER]
                ],
                'A1:E5' => [
                    'alignment' => [
                        'horizontal' => $horizontalAlignment,
                        'vertical' => Alignment::VERTICAL_CENTER,
                    ]
                ],
            ];
        }

        $dataStartRow = 18; // After introduction (rows 1-16 are header/intro, row 17 is header row, data starts at row 18)

        return [
            // Main title (Row 1) - handled by styleMainTitle
            // Subtitle (Row 3)
            3 => [
                'font' => ['bold' => true, 'size' => 14, 'color' => ['rgb' => '2F75B5']],
                'alignment' => ['horizontal' => $horizontalAlignment]
            ],

            // Report Information header (Row 6)
            6 => [
                'font' => ['bold' => true, 'size' => 12],
                'alignment' => ['horizontal' => $horizontalAlignment]
            ],

            // Report Information column headers (Row 7)
            7 => [
                'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'color' => ['rgb' => '2F75B5']
                ],
                'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER]
            ],

            // Report Information data row (Row 8)
            8 => [
                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'color' => ['rgb' => 'F2F2F2']
                ],
                'alignment' => ['horizontal' => $horizontalAlignment]
            ],

            // Purpose header (Row 11)
            11 => [
                'font' => ['bold' => true, 'size' => 12],
                'alignment' => ['horizontal' => $horizontalAlignment]
            ],

            // Purpose descriptions (Rows 12-13)
            12 => [
                'alignment' => [
                    'wrapText' => true,
                    'horizontal' => $horizontalAlignment
                ]
            ],
            13 => [
                'alignment' => [
                    'wrapText' => true,
                    'horizontal' => $horizontalAlignment
                ]
            ],

            // Header row (Row 17)
            17 => [
                'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
                'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER, 'vertical' => Alignment::VERTICAL_CENTER],
                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'color' => ['rgb' => '1F4E78']
                ]
            ],

            // Data rows
            'A' . $dataStartRow . ':K' . ($totalDataRows + $dataStartRow - 1) => [
                'alignment' => [
                    'vertical' => Alignment::VERTICAL_CENTER,
                    'horizontal' => $horizontalAlignment,
                ],
                'borders' => [
                    'allBorders' => [
                        'borderStyle' => Border::BORDER_THIN,
                        'color' => ['rgb' => 'D9D9D9']
                    ]
                ]
            ],

            // Wrap text columns
            'F' . $dataStartRow . ':F' . ($totalDataRows + $dataStartRow - 1) => [
                'alignment' => [
                    'wrapText' => true,
                    'horizontal' => $horizontalAlignment
                ]
            ],
            'K' . $dataStartRow . ':K' . ($totalDataRows + $dataStartRow - 1) => [
                'alignment' => [
                    'wrapText' => true,
                    'horizontal' => $horizontalAlignment
                ]
            ],

            // Center align for specific columns
            'D' . $dataStartRow . ':D' . ($totalDataRows + $dataStartRow - 1) => [
                'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER]
            ],
            'H' . $dataStartRow . ':H' . ($totalDataRows + $dataStartRow - 1) => [
                'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER]
            ],
            'I' . $dataStartRow . ':I' . ($totalDataRows + $dataStartRow - 1) => [
                'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER]
            ],
            'J' . $dataStartRow . ':J' . ($totalDataRows + $dataStartRow - 1) => [
                'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER]
            ],

            // All introduction cells (Rows 1-16)
            'A1:K16' => [
                'alignment' => [
                    'vertical' => Alignment::VERTICAL_TOP,
                    'horizontal' => $horizontalAlignment
                ],
            ],
        ];
    }

    public function columnWidths(): array
    {
        if ($this->isRTL) {
            return [
                'A' => 25, // Framework Name
                'B' => 25, // Audit Name
                'C' => 35, // Control Name (wider for Arabic)
                'D' => 20, // Control Short Name
                'E' => 25, // Responsible User (wider for Arabic)
                'F' => 25, // Department (wider for Arabic)
                'G' => 45, // Corrective Action Plan (wider for Arabic)
                'H' => 15, // Budgetary
                'I' => 15, // Status
                'J' => 15, // Due Date
                'K' => 40, // Comments (wider for Arabic)
            ];
        }

        return [
            'A' => 25, // Framework Name
            'B' => 25, // Audit Name
            'C' => 30, // Control Name
            'D' => 20, // Control Short Name
            'E' => 20, // Responsible User
            'F' => 40, // Corrective Action Plan
            'G' => 15, // Budgetary
            'H' => 15, // Status
            'I' => 15, // Due Date
            'J' => 35, // Comments
        ];
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event) {
                $sheet = $event->sheet->getDelegate();
                $totalDataRows = count($this->remediationData);
                $horizontalAlignment = $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_LEFT;

                // Set sheet direction for RTL
                if ($this->isRTL) {
                    $sheet->setRightToLeft(true);
                }

                // If no data, just add logo and return
                if ($totalDataRows === 0) {
                    $this->addLogo($sheet);
                    $this->styleMainTitle($sheet);
                    return;
                }

                $dataStartRow = 18; // After introduction

                // Style main title (Row 1)
                $this->styleMainTitle($sheet);

                // Add logo
                $this->addLogo($sheet);

                // Add borders to report information section (rows 7-8)
                $sheet->getStyle('A7:E8')->applyFromArray([
                    'borders' => [
                        'allBorders' => [
                            'borderStyle' => Border::BORDER_THIN,
                            'color' => ['rgb' => '000000']
                        ]
                    ]
                ]);

                // Format report information header
                $sheet->getStyle('A7:E7')->applyFromArray([
                    'alignment' => [
                        'horizontal' => Alignment::HORIZONTAL_CENTER,
                    ]
                ]);

                // Format report information data
                $sheet->getStyle('A8:E8')->applyFromArray([
                    'alignment' => [
                        'horizontal' => $horizontalAlignment,
                    ]
                ]);

                // Apply zebra striping to data rows
                for ($i = $dataStartRow; $i < $totalDataRows + $dataStartRow; $i++) {
                    if ($i % 2 == 0) {
                        $sheet->getStyle('A' . $i . ':K' . $i)->applyFromArray([
                            'fill' => [
                                'fillType' => Fill::FILL_SOLID,
                                'color' => ['rgb' => 'F2F2F2']
                            ]
                        ]);
                    }
                }

                // Format date column
                $sheet->getStyle('J' . $dataStartRow . ':J' . ($totalDataRows + $dataStartRow - 1))->applyFromArray([
                    'alignment' => [
                        'horizontal' => Alignment::HORIZONTAL_CENTER
                    ],
                    'numberFormat' => [
                        'formatCode' => 'yyyy-mm-dd'
                    ]
                ]);

                // Format budgetary column as currency
                $sheet->getStyle('H' . $dataStartRow . ':H' . ($totalDataRows + $dataStartRow - 1))->applyFromArray([
                    'numberFormat' => [
                        'formatCode' => '#,##0.00"$"'
                    ]
                ]);

                // Color code status column
                $this->applyStatusColorCoding($sheet, $dataStartRow, $totalDataRows);

                // Add summary section with statistics
                $this->addSummarySection($sheet, $dataStartRow, $totalDataRows);

                // Freeze panes (header row stays visible when scrolling)
                $sheet->freezePane('A' . ($dataStartRow));

                // Set auto filter on header
                $sheet->setAutoFilter('A' . 17 . ':K' . 17);
            },
        ];
    }

    // -------------------------------------------------------------------------
    // Logo merged A1:B1 | Title merged C1:D1 centered
    // Same layout for both LTR and RTL
    // -------------------------------------------------------------------------
    private function styleMainTitle($sheet)
    {
        $borderNone = [
            'left'   => ['borderStyle' => Border::BORDER_NONE],
            'right'  => ['borderStyle' => Border::BORDER_NONE],
            'top'    => ['borderStyle' => Border::BORDER_NONE],
            'bottom' => ['borderStyle' => Border::BORDER_NONE],
        ];

        $titleStyle = [
            'font' => [
                'bold'  => true,
                'size'  => 18,
                'color' => ['rgb' => '1B365D'],
            ],
            'fill' => [
                'fillType'   => Fill::FILL_SOLID,
                'startColor' => ['rgb' => 'FFFFFF'],
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER,
                'vertical'   => Alignment::VERTICAL_CENTER,
            ],
            'borders' => $borderNone,
        ];

        $logoCellStyle = [
            'fill' => [
                'fillType'   => Fill::FILL_SOLID,
                'startColor' => ['rgb' => 'FFFFFF'],
            ],
            'borders' => $borderNone,
        ];

        // Logo → A1:B1 merged (both locales)
        $sheet->mergeCells('A1:B1');
        $sheet->getStyle('A1:B1')->applyFromArray($logoCellStyle);

        // Title → C1:D1 merged, centered (both locales)
        $sheet->mergeCells('C1:D1');
        $sheet->getStyle('C1:D1')->applyFromArray($titleStyle);

        // Clear any styling on remaining cells in row 1
        $sheet->getStyle('E1:K1')->applyFromArray($logoCellStyle);

        // Row 1 height for logo
        $sheet->getRowDimension(1)->setRowHeight(50);
        // Row 2 spacer
        $sheet->getRowDimension(2)->setRowHeight(20);
    }

    // -------------------------------------------------------------------------
    // Logo always placed in A1 (cell is merged A1:B1)
    // -------------------------------------------------------------------------
    protected function addLogo($sheet)
    {
        try {
            $logoPath = public_path('images/ksu-logo.png');

            if (!file_exists($logoPath)) {
                foreach ([
                    public_path('logo.png'),
                    public_path('images/logo.png'),
                    public_path('img/logo.png'),
                    public_path('assets/images/logo.png'),
                ] as $path) {
                    if (file_exists($path)) {
                        $logoPath = $path;
                        break;
                    }
                }
            }

            if (!file_exists($logoPath)) {
                return;
            }

            $drawing = new Drawing();
            $drawing->setName('Logo');
            $drawing->setDescription('Company Logo');
            $drawing->setPath($logoPath);
            $drawing->setHeight(60);
            $drawing->setResizeProportional(true);
            $drawing->setOffsetX(6);
            $drawing->setOffsetY(5);

            // Logo always anchored in A1 (spans A:B via merge)
            $drawing->setCoordinates('A1');

            $drawing->setWorksheet($sheet);

            $this->drawings[] = $drawing;

        } catch (\Exception $e) {
            // Logo error — continue without it
        }
    }

    protected function applyStatusColorCoding($sheet, $dataStartRow, $totalDataRows)
    {
        for ($i = $dataStartRow; $i <= $totalDataRows + $dataStartRow - 1; $i++) {
            $statusCell = 'I' . $i;
            $statusValue = $sheet->getCell($statusCell)->getValue();

            if ($statusValue === __('report.Approved')) {
                $sheet->getStyle($statusCell)->applyFromArray([
                    'fill' => [
                        'fillType' => Fill::FILL_SOLID,
                        'color' => ['rgb' => 'C6EFCE']
                    ],
                    'font' => [
                        'color' => ['rgb' => '006100']
                    ]
                ]);
            } elseif ($statusValue === __('report.Rejected')) {
                $sheet->getStyle($statusCell)->applyFromArray([
                    'fill' => [
                        'fillType' => Fill::FILL_SOLID,
                        'color' => ['rgb' => 'FFC7CE']
                    ],
                    'font' => [
                        'color' => ['rgb' => '9C0006']
                    ]
                ]);
            } elseif ($statusValue === __('report.Pending')) {
                $sheet->getStyle($statusCell)->applyFromArray([
                    'fill' => [
                        'fillType' => Fill::FILL_SOLID,
                        'color' => ['rgb' => 'FFEB9C']
                    ],
                    'font' => [
                        'color' => ['rgb' => '9C6500']
                    ]
                ]);
            }
        }
    }

    protected function addSummarySection($sheet, $dataStartRow, $totalDataRows)
    {
        $summaryRow = $totalDataRows + $dataStartRow + 2;
        $horizontalAlignment = $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_LEFT;

        // Summary title
        $sheet->setCellValue('A' . $summaryRow, __('report.Remediation Summary - Statistics'));
        $sheet->getStyle('A' . $summaryRow)->applyFromArray([
            'font' => ['bold' => true, 'size' => 14, 'color' => ['rgb' => '1F4E78']],
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'color' => ['rgb' => 'DDEBF7']
            ]
        ]);
        $sheet->mergeCells('A' . $summaryRow . ':K' . $summaryRow);
        $sheet->getStyle('A' . $summaryRow . ':K' . $summaryRow)->applyFromArray([
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER
            ],
            'borders' => [
                'outline' => [
                    'borderStyle' => Border::BORDER_MEDIUM,
                    'color' => ['rgb' => '1F4E78']
                ]
            ]
        ]);

        // Total Remediations
        $sheet->setCellValue('A' . ($summaryRow + 1), __('report.Total Remediation Items') . ':');
        $sheet->setCellValue('B' . ($summaryRow + 1), $this->statistics['total_remediations']);
        $sheet->getStyle('A' . ($summaryRow + 1) . ':B' . ($summaryRow + 1))->applyFromArray([
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'color' => ['rgb' => 'DDEBF7']
            ],
            'borders' => [
                'outline' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['rgb' => '5B9BD5']
                ]
            ],
            'alignment' => [
                'horizontal' => $horizontalAlignment
            ]
        ]);
        $sheet->getStyle('B' . ($summaryRow + 1))->applyFromArray([
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER
            ],
            'font' => ['bold' => true, 'size' => 12]
        ]);

        // Approved count
        $sheet->setCellValue('D' . ($summaryRow + 1), __('report.Approved Remediations') . ':');
        $sheet->setCellValue('E' . ($summaryRow + 1), $this->statistics['approved_count']);
        $sheet->getStyle('D' . ($summaryRow + 1) . ':E' . ($summaryRow + 1))->applyFromArray([
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'color' => ['rgb' => 'E2EFDA']
            ],
            'borders' => [
                'outline' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['rgb' => 'A9D08E']
                ]
            ],
            'alignment' => [
                'horizontal' => $horizontalAlignment
            ]
        ]);
        $sheet->getStyle('E' . ($summaryRow + 1))->applyFromArray([
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER
            ],
            'font' => ['bold' => true, 'size' => 12]
        ]);

        // Rejected count
        $sheet->setCellValue('G' . ($summaryRow + 1), __('report.Rejected Remediations') . ':');
        $sheet->setCellValue('H' . ($summaryRow + 1), $this->statistics['rejected_count']);
        $sheet->getStyle('G' . ($summaryRow + 1) . ':H' . ($summaryRow + 1))->applyFromArray([
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'color' => ['rgb' => 'FCE4D6']
            ],
            'borders' => [
                'outline' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['rgb' => 'FF7C80']
                ]
            ],
            'alignment' => [
                'horizontal' => $horizontalAlignment
            ]
        ]);
        $sheet->getStyle('H' . ($summaryRow + 1))->applyFromArray([
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER
            ],
            'font' => ['bold' => true, 'size' => 12]
        ]);

        // Pending count
        $sheet->setCellValue('A' . ($summaryRow + 2), __('report.Pending Remediations') . ':');
        $sheet->setCellValue('B' . ($summaryRow + 2), $this->statistics['pending_count']);
        $sheet->getStyle('A' . ($summaryRow + 2) . ':B' . ($summaryRow + 2))->applyFromArray([
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'color' => ['rgb' => 'FFF2CC']
            ],
            'borders' => [
                'outline' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['rgb' => 'FFD966']
                ]
            ],
            'alignment' => [
                'horizontal' => $horizontalAlignment
            ]
        ]);
        $sheet->getStyle('B' . ($summaryRow + 2))->applyFromArray([
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER
            ],
            'font' => ['bold' => true, 'size' => 12]
        ]);

        // Overdue count
        $sheet->setCellValue('D' . ($summaryRow + 2), __('report.Overdue Remediations') . ':');
        $sheet->setCellValue('E' . ($summaryRow + 2), $this->statistics['overdue_count']);
        $sheet->getStyle('D' . ($summaryRow + 2) . ':E' . ($summaryRow + 2))->applyFromArray([
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'color' => ['rgb' => 'FCE4D6']
            ],
            'borders' => [
                'outline' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['rgb' => 'FF7C80']
                ]
            ],
            'alignment' => [
                'horizontal' => $horizontalAlignment
            ]
        ]);
        $sheet->getStyle('E' . ($summaryRow + 2))->applyFromArray([
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER
            ],
            'font' => ['bold' => true, 'size' => 12, 'color' => ['rgb' => '9C0006']]
        ]);

        // Budget summary
        $sheet->setCellValue('G' . ($summaryRow + 2), __('report.Total Budget Required') . ':');
        $sheet->setCellValue('H' . ($summaryRow + 2), '$' . number_format($this->statistics['total_budget'], 2));
        $sheet->getStyle('G' . ($summaryRow + 2) . ':H' . ($summaryRow + 2))->applyFromArray([
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'color' => ['rgb' => 'E2EFDA']
            ],
            'borders' => [
                'outline' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['rgb' => '70AD47']
                ]
            ],
            'alignment' => [
                'horizontal' => $horizontalAlignment
            ]
        ]);
        $sheet->getStyle('H' . ($summaryRow + 2))->applyFromArray([
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER
            ],
            'font' => ['bold' => true, 'size' => 12],
            'numberFormat' => [
                'formatCode' => '#,##0.00"$"'
            ]
        ]);

        // Completion Rate
        $sheet->setCellValue('A' . ($summaryRow + 3), __('report.Completion Rate') . ':');
        $sheet->setCellValue('B' . ($summaryRow + 3), $this->statistics['completion_rate'] . '%');
        $sheet->getStyle('A' . ($summaryRow + 3) . ':B' . ($summaryRow + 3))->applyFromArray([
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'color' => ['rgb' => 'DDEBF7']
            ],
            'borders' => [
                'outline' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['rgb' => '5B9BD5']
                ]
            ],
            'alignment' => [
                'horizontal' => $horizontalAlignment
            ]
        ]);
        $sheet->getStyle('B' . ($summaryRow + 3))->applyFromArray([
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER
            ],
            'font' => ['bold' => true, 'size' => 12]
        ]);

        // Approval Rate
        $sheet->setCellValue('D' . ($summaryRow + 3), __('report.Approval Rate') . ':');
        $sheet->setCellValue('E' . ($summaryRow + 3), $this->statistics['approval_rate'] . '%');
        $sheet->getStyle('D' . ($summaryRow + 3) . ':E' . ($summaryRow + 3))->applyFromArray([
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'color' => ['rgb' => 'E2EFDA']
            ],
            'borders' => [
                'outline' => [
                    'borderStyle' => Border::BORDER_MEDIUM,
                    'color' => ['rgb' => '70AD47']
                ]
            ],
            'font' => ['bold' => true],
            'alignment' => [
                'horizontal' => $horizontalAlignment
            ]
        ]);
        $sheet->getStyle('E' . ($summaryRow + 3))->applyFromArray([
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER
            ]
        ]);

        // Report footer
        $footerRow = $summaryRow + 5;
        $sheet->setCellValue('A' . $footerRow, __('report.Report generated on') . ': ' . Carbon::now()->format('F j, Y H:i:s'));
        $sheet->getStyle('A' . $footerRow)->applyFromArray([
            'font' => ['italic' => true, 'size' => 10],
            'alignment' => ['horizontal' => $horizontalAlignment]
        ]);
        $sheet->mergeCells('A' . $footerRow . ':K' . $footerRow);
    }
}