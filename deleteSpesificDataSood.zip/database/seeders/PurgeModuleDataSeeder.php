<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Deletes the rows in the tables listed under $modules.
 *
 * php artisan db:seed --class=PurgeModuleDataSeeder
 */
class PurgeModuleDataSeeder extends Seeder
{
    /**
     * Child tables first, then the parent table.
     *
     * @var array<string, array<int, string>>
     */
    protected $modules = [
        'KPI' => [
            'kpi_files',
            'kpi_assessments',
            'kpis',
        ],
        'Change request' => [
            'change_requests',
        ],
        'Tasks' => [
            'task_categories',
            'task_note_files',
            'task_notes',
            'file_tasks',
            'tasks',
        ],
        'Exceptions' => [
            'exception_policy',
            'control_exception',
            'exception_risk',
            'document_exceptions',
            'exceptions',
        ],
        'NDA' => [
            'nda_results',
            'nda_receivers',
            'ndas',
        ],
        'Framework Compliance' => [
            'control_audits_evidences',
            'control_audits_objectives',
            'control_audit_policies',
            'framework_control_test_comments',
            'framework_control_test_results_to_risks',
            'framework_control_test_results',
            'remediation_details',
            'framework_control_test_audits',
            'audits_responsibles',
        ],
        'Policies Compliance' => [
            'document_policies',
            'policy_signatures',
            'policy_adoptions',
            'exception_policy',
            'audit_document_policy_assignees',
            'audit_document_policy_comments',
            'audit_document_policy_files',
            'audit_document_policy_policy_document',
            'audit_document_policy_statuses',
            'audit_document_total_statuses',
            'audit_document_policies',
            'center_policies'
        ],
        'Control Review' => [
            'control_compliance_documents',
            'mapped_controls_compliances',
        ],
        'Cross Requests' => [
            'request_communication_attachments',
            'request_communications',
            'request_attachments',
            'request_histories',
            'request_history',
            'cybersecurity_requests',
        ],
    ];


    public function run()
    {
        if ($this->command && !$this->command->confirm(
            'Delete KPI, change requests, tasks, exceptions, NDA, Framework Compliance, Policies Compliance, Control Review, and Cross Requests data, including related rows?',
            false
        )) {
            $this->command->warn('Cancelled.');
            return;
        }

        DB::statement('SET FOREIGN_KEY_CHECKS=0');
        try {
            foreach ($this->modules as $module => $tables) {
                if ($this->command) {
                    $this->command->info($module);
                }
                foreach ($tables as $table) {
                    $this->clearTable($table);
                }
            }
        } finally {
            DB::statement('SET FOREIGN_KEY_CHECKS=1');
        }

        if ($this->command) {
            $this->command->info('Done.');
        }
    }

    protected function clearTable(string $table): void
    {
        if (!Schema::hasTable($table)) {
            if ($this->command) {
                $this->command->line('  skip ' . $table . ' (table missing)');
            }
            return;
        }

        $count = DB::table($table)->count();
        DB::table($table)->delete();
        if ($this->command) {
            $this->command->line('  ' . $table . ': ' . $count);
        }
    }
}
