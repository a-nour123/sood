<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Safe to run more than once. Each step is skipped until the data it depends on exists,
 * so it can be called from migrations (existing databases) and from DatabaseSeeder (fresh installs).
 */
class KsuRiskManagementSeeder extends Seeder
{
    protected $treatmentPermissionKeys = [
        'riskmanagement.accept_risk',
        'riskmanagement.transfer_risk',
        'riskmanagement.avoid_risk',
        'riskmanagement.redo_assessment',
    ];

    protected $permissions = [
        'riskmanagement.accept_risk' => 'Accept Risk',
        'riskmanagement.transfer_risk' => 'Transfer Risk',
        'riskmanagement.avoid_risk' => 'Avoid Risk',
        'riskmanagement.redo_assessment' => 'Redo Assessment',
        'riskmanagement.risk_appetite' => 'Risk Appetite Statement',
        'riskmanagement.vulnerability_catalog' => 'Vulnerability Catalog',
        'riskmanagement.review_treatment' => 'Review Risk Treatment',
        'riskmanagement.review_assessment_request' => 'Review Assessment Request',
        'riskmanagement.on_demand_report' => 'On-Demand Risk Report',
    ];

    public function run()
    {
        $this->seedStatuses();
        $this->seedRiskLevels();
        $this->seedPermissions();
        $this->seedRoles();
        $this->seedReassessmentSetting();
    }

    protected function seedStatuses(): void
    {
        if (!Schema::hasTable('statuses')) {
            return;
        }

        $statuses = [
            8 => 'Mitigation',
            9 => 'Avoid',
            10 => 'Transfer',
            11 => 'Accept',
        ];
        foreach ($statuses as $id => $name) {
            if (!DB::table('statuses')->where('id', $id)->exists()) {
                DB::table('statuses')->insert(['id' => $id, 'name' => $name]);
            }
        }
    }

    protected function seedRiskLevels(): void
    {
        if (!Schema::hasTable('risk_levels') || !Schema::hasTable('review_levels')) {
            return;
        }
        if (DB::table('review_levels')->whereIn('id', [2, 3, 4, 5])->count() < 4) {
            return;
        }
        if (DB::table('risk_levels')->where('name', 'Catastrophic')->exists()) {
            return;
        }

        $ksuLevels = [
            ['value' => 0, 'name' => 'Very Low', 'color' => '#22c55e', 'display_name' => 'Very Low', 'review_level_id' => 2],
            ['value' => 3, 'name' => 'Low', 'color' => '#84cc16', 'display_name' => 'Low', 'review_level_id' => 2],
            ['value' => 8, 'name' => 'Medium', 'color' => '#eab308', 'display_name' => 'Medium', 'review_level_id' => 3],
            ['value' => 15, 'name' => 'High', 'color' => '#f97316', 'display_name' => 'High', 'review_level_id' => 4],
            ['value' => 20, 'name' => 'Catastrophic', 'color' => '#ef4444', 'display_name' => 'Catastrophic', 'review_level_id' => 5],
        ];

        $existing = DB::table('risk_levels')->orderBy('id')->get()->values();
        if ($existing->count() >= 4) {
            foreach ($ksuLevels as $idx => $level) {
                if (isset($existing[$idx])) {
                    DB::table('risk_levels')->where('id', $existing[$idx]->id)->update($level);
                } else {
                    DB::table('risk_levels')->insert($level);
                }
            }
            return;
        }

        DB::table('risk_levels')->delete();
        DB::table('risk_levels')->insert($ksuLevels);
    }

    protected function seedPermissions(): void
    {
        if (!Schema::hasTable('permissions') || !Schema::hasTable('subgroups')) {
            return;
        }
        $subGroupId = DB::table('subgroups')->where('name', 'Risks Management')->value('id');
        if (!$subGroupId) {
            return;
        }

        $adminExists = Schema::hasTable('roles') && DB::table('roles')->where('id', 1)->exists();

        foreach ($this->permissions as $key => $name) {
            $permissionId = DB::table('permissions')->where('key', $key)->value('id');
            if (!$permissionId) {
                $permissionId = DB::table('permissions')->insertGetId([
                    'key' => $key,
                    'name' => $name,
                    'subgroup_id' => $subGroupId,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
            if ($adminExists) {
                $this->attach(1, $permissionId);
            }
        }
    }

    protected function seedRoles(): void
    {
        if (!Schema::hasTable('roles') || !DB::table('roles')->where('id', 1)->exists()) {
            return;
        }

        $permissionIds = DB::table('permissions')
            ->whereIn('key', $this->treatmentPermissionKeys)
            ->pluck('id');

        foreach (['Asset Owner', 'Risk Assessment Team'] as $name) {
            if (DB::table('roles')->where('name', $name)->exists()) {
                continue;
            }
            $roleId = DB::table('roles')->insertGetId(['name' => $name]);
            foreach ($permissionIds as $permissionId) {
                $this->attach($roleId, $permissionId);
            }
        }
    }

    protected function seedReassessmentSetting(): void
    {
        if (!Schema::hasTable('risk_reassessment_settings') || DB::table('risk_reassessment_settings')->exists()) {
            return;
        }

        DB::table('risk_reassessment_settings')->insert([
            'is_active' => true,
            'normal_interval_days' => 365,
            'sensitive_interval_days' => 90,
            'notify_asset_owner' => true,
            'sensitive_rank_max' => 2,
            'recipient_user_ids' => json_encode([]),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    protected function attach(int $roleId, int $permissionId): void
    {
        $exists = DB::table('role_responsibilities')
            ->where('role_id', $roleId)
            ->where('permission_id', $permissionId)
            ->exists();
        if (!$exists) {
            DB::table('role_responsibilities')->insert([
                'role_id' => $roleId,
                'permission_id' => $permissionId,
            ]);
        }
    }
}
