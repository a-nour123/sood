<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        if (Schema::hasTable('risk_assessment_requests')) {
            return;
        }

        Schema::create('risk_assessment_requests', function (Blueprint $table) {
            $table->id();
            $table->string('request_type', 30); // asset_owner | open
            $table->unsignedBigInteger('asset_id')->nullable();
            $table->text('description')->nullable();
            $table->string('attachment_path')->nullable();
            $table->string('attachment_name')->nullable();
            $table->string('status', 20)->default('pending'); // pending | reviewed
            $table->unsignedBigInteger('requested_by');
            $table->unsignedBigInteger('reviewed_by')->nullable();
            $table->timestamp('reviewed_at')->nullable();
            $table->text('review_notes')->nullable();
            $table->string('review_attachment_path')->nullable();
            $table->string('review_attachment_name')->nullable();
            $table->timestamps();

            $table->index(['request_type', 'status']);
            $table->index('asset_id');
        });
    }

    public function down()
    {
        Schema::dropIfExists('risk_assessment_requests');
    }
};
