<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up()
    {
        $row = DB::table('actions')->where('name', 'Risk_Assessment_Request')->first();
        if (!$row) {
            DB::table('actions')->insert([
                'id' => 184,
                'name' => 'Risk_Assessment_Request',
            ]);
            return;
        }

        if ((int) $row->id === 184) {
            return;
        }

        if (!DB::table('actions')->where('id', 184)->exists()) {
            DB::table('actions')->where('id', $row->id)->update(['id' => 184]);
        }
    }

    public function down()
    {
        //
    }
};
