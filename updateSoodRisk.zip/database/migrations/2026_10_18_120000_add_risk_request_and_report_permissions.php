<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up()
    {
        $subGroupId = DB::table('subgroups')->where('name', 'Risks Management')->value('id');
        if (!$subGroupId) {
            return;
        }

        $sourceRoleIds = DB::table('role_responsibilities')
            ->join('permissions', 'permissions.id', '=', 'role_responsibilities.permission_id')
            ->where('permissions.key', 'riskmanagement.review_treatment')
            ->pluck('role_responsibilities.role_id')
            ->unique();

        $permissions = [
            'riskmanagement.review_assessment_request' => 'Review Assessment Request',
            'riskmanagement.on_demand_report' => 'On-Demand Risk Report',
        ];

        foreach ($permissions as $key => $name) {
            $permissionId = DB::table('permissions')->where('key', $key)->value('id');
            if (!$permissionId) {
                $permissionId = DB::table('permissions')->insertGetId([
                    'key' => $key,
                    'name' => $name,
                    'subgroup_id' => $subGroupId,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }

            foreach ($sourceRoleIds as $roleId) {
                $exists = DB::table('role_responsibilities')
                    ->where('role_id', $roleId)
                    ->where('permission_id', $permissionId)
                    ->exists();
                if (!$exists) {
                    DB::table('role_responsibilities')->insert([
                        'role_id' => $roleId,
                        'permission_id' => $permissionId,
                    ]);
                }
            }
        }
    }

    public function down()
    {
        $ids = DB::table('permissions')
            ->whereIn('key', ['riskmanagement.review_assessment_request', 'riskmanagement.on_demand_report'])
            ->pluck('id');
        DB::table('role_responsibilities')->whereIn('permission_id', $ids)->delete();
        DB::table('permissions')->whereIn('id', $ids)->delete();
    }
};
