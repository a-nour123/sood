<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        if (!Schema::hasTable('risk_redo_assessment_requests')) {
            Schema::create('risk_redo_assessment_requests', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('risk_id');
                $table->string('status', 40)->default('pending_risk_team'); // pending_risk_team|in_progress|completed|rejected
                $table->text('notes')->nullable();
                $table->unsignedBigInteger('started_by')->nullable();
                $table->unsignedBigInteger('reviewed_by')->nullable();
                $table->timestamp('reviewed_at')->nullable();
                $table->text('review_comments')->nullable();
                $table->timestamps();

                $table->foreign('risk_id')->references('id')->on('risks')->cascadeOnDelete();
                $table->foreign('started_by')->references('id')->on('users')->nullOnDelete();
                $table->foreign('reviewed_by')->references('id')->on('users')->nullOnDelete();
            });
        }

        if (!Schema::hasTable('risk_redo_assessment_evidences')) {
            Schema::create('risk_redo_assessment_evidences', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('redo_request_id');
                $table->unsignedBigInteger('action_plan_id')->nullable();
                $table->string('file_path')->nullable();
                $table->string('file_name')->nullable();
                $table->text('comment')->nullable();
                $table->timestamps();

                $table->foreign('redo_request_id', 'redo_ev_req_fk')
                    ->references('id')->on('risk_redo_assessment_requests')->cascadeOnDelete();
                $table->foreign('action_plan_id', 'redo_ev_ap_fk')
                    ->references('id')->on('mitigation_action_plans')->nullOnDelete();
            });
        }

        if (!Schema::hasTable('risk_report_schedules')) {
            Schema::create('risk_report_schedules', function (Blueprint $table) {
                $table->id();
                $table->string('frequency', 20); // weekly|monthly|quarterly
                $table->string('report_type', 50); // register|assessment_treatment|acceptance
                $table->json('recipient_roles')->nullable(); // risk_team|ciso|steering
                $table->boolean('is_active')->default(true);
                $table->timestamp('last_run_at')->nullable();
                $table->timestamps();
            });

            // Seed default schedules (KSU #6)
            \DB::table('risk_report_schedules')->insert([
                [
                    'frequency' => 'weekly',
                    'report_type' => 'register',
                    'recipient_roles' => json_encode(['risk_team']),
                    'is_active' => true,
                    'created_at' => now(),
                    'updated_at' => now(),
                ],
                [
                    'frequency' => 'monthly',
                    'report_type' => 'assessment_treatment',
                    'recipient_roles' => json_encode(['risk_team', 'ciso']),
                    'is_active' => true,
                    'created_at' => now(),
                    'updated_at' => now(),
                ],
                [
                    'frequency' => 'quarterly',
                    'report_type' => 'acceptance',
                    'recipient_roles' => json_encode(['risk_team', 'ciso', 'steering']),
                    'is_active' => true,
                    'created_at' => now(),
                    'updated_at' => now(),
                ],
            ]);
        }
    }

    public function down()
    {
        Schema::dropIfExists('risk_redo_assessment_evidences');
        Schema::dropIfExists('risk_redo_assessment_requests');
        Schema::dropIfExists('risk_report_schedules');
    }
};
