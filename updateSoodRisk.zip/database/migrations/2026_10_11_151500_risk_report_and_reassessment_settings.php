<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        if (Schema::hasTable('risk_report_schedules') && !Schema::hasColumn('risk_report_schedules', 'recipient_user_ids')) {
            Schema::table('risk_report_schedules', function (Blueprint $table) {
                $table->json('recipient_user_ids')->nullable()->after('recipient_roles');
            });
        }

        if (!Schema::hasTable('risk_reassessment_settings')) {
            Schema::create('risk_reassessment_settings', function (Blueprint $table) {
                $table->id();
                $table->boolean('is_active')->default(true);
                $table->unsignedSmallInteger('normal_interval_days')->default(365);
                $table->unsignedSmallInteger('sensitive_interval_days')->default(90);
                $table->boolean('notify_asset_owner')->default(true);
                $table->unsignedTinyInteger('sensitive_rank_max')->default(2);
                $table->json('recipient_user_ids')->nullable();
                $table->timestamps();
            });
        }

        if (Schema::hasTable('assets') && !Schema::hasColumn('assets', 'is_sensitive')) {
            Schema::table('assets', function (Blueprint $table) {
                $table->boolean('is_sensitive')->default(false)->after('rank');
            });
        }

        (new \Database\Seeders\KsuRiskManagementSeeder())->run();
    }

    public function down()
    {
        if (Schema::hasColumn('risk_report_schedules', 'recipient_user_ids')) {
            Schema::table('risk_report_schedules', function (Blueprint $table) {
                $table->dropColumn('recipient_user_ids');
            });
        }
        Schema::dropIfExists('risk_reassessment_settings');
        if (Schema::hasColumn('assets', 'is_sensitive')) {
            Schema::table('assets', function (Blueprint $table) {
                $table->dropColumn('is_sensitive');
            });
        }
    }
};
