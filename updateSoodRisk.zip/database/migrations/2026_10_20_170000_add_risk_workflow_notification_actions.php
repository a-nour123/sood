<?php

use App\Models\SystemNotificationSetting;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    private const NEW_ACTIONS = [
        185 => 'Risk_Treatment_Requested',
        186 => 'Risk_Treatment_Next_Approval',
        187 => 'Risk_Treatment_Approved',
        188 => 'Risk_Treatment_Rejected',
        189 => 'Risk_Redo_Assessment_Requested',
        190 => 'Risk_Redo_Assessment_Reviewed',
        191 => 'Risk_Comment_Added',
        192 => 'Risk_Scoring_Updated',
    ];

    private const BASE_ROLES = ['creator', 'Team-teams', 'Stakeholder-teams'];

    /**
     * Default system-notification message and receiver roles per action name.
     * Only applied when the action has no system-notification setting yet.
     */
    private function defaults(): array
    {
        return [
            'Risk_Add' => ['New risk "{subject}" was added.', [...self::BASE_ROLES, 'ciso']],
            'Risk_Update' => ['Risk "{subject}" was updated.', self::BASE_ROLES],
            'MgmtReview_Add' => ['A new review was performed on risk "{Subject}".', ['reviewer', 'creator', 'Team-teams']],
            'Risk_Close' => ['Risk "{subject}" was closed.', [...self::BASE_ROLES, 'ciso']],
            'Risk_Status' => ['Risk "{subject}" status changed to {status}.', self::BASE_ROLES],
            'Risk_Mitigation' => ['The mitigation plan of a risk was submitted / updated.', ['mit_owner', 'creator', 'Team-teams']],
            'Risk_Delete' => ['Risk "{subject}" was deleted.', [...self::BASE_ROLES, 'ciso']],
            'Risk_Reset_Reviews' => ['Reviews of risk "{subject}" were reset.', self::BASE_ROLES],
            'Risk_Reset_Mitigations' => ['Mitigations of risk "{subject}" were reset.', self::BASE_ROLES],
            'Risk_Reopen' => ['Risk "{subject}" was reopened.', [...self::BASE_ROLES, 'ciso']],
            'Risk_Update_Subject' => ['Risk subject was changed to "{subject}".', self::BASE_ROLES],
            'Mitigation_accept' => ['Mitigation of risk "{Risk_Name}" was accepted by {Mitigation_Acceptor}.', ['creator']],
            'Risk_Assessment_Request' => ['New risk assessment request from {Requester}.', ['creator']],
            'Risk_Treatment_Requested' => ['{actor} requested to {treatment} risk "{subject}". Waiting for: {next_step}.', ['next_approvers', 'creator', 'decision_owner']],
            'Risk_Treatment_Next_Approval' => ['{actor} approved the {treatment} request of risk "{subject}". It is now waiting for: {next_step}.', ['next_approvers', 'requester']],
            'Risk_Treatment_Approved' => ['The {treatment} request of risk "{subject}" was finally approved.', ['requester', 'creator', 'decision_owner', 'Team-teams', 'ciso']],
            'Risk_Treatment_Rejected' => ['{actor} rejected the {treatment} request of risk "{subject}". Comment: {comments}', ['requester', 'creator', 'decision_owner', 'ciso']],
            'Risk_Redo_Assessment_Requested' => ['{actor} submitted redo-assessment evidence for risk "{subject}" and it is waiting for the risk team review.', ['risk_team', 'creator']],
            'Risk_Redo_Assessment_Reviewed' => ['{actor} {decision} the redo assessment of risk "{subject}".', ['requester', 'creator']],
            'Risk_Comment_Added' => ['{actor} commented on risk "{subject}": {comment}', self::BASE_ROLES],
            'Risk_Scoring_Updated' => ['{actor} updated the scoring of risk "{subject}".', self::BASE_ROLES],
        ];
    }

    public function up()
    {
        foreach (self::NEW_ACTIONS as $id => $name) {
            if (DB::table('actions')->where('name', $name)->exists()) {
                continue;
            }
            DB::table('actions')->where('id', $id)->exists()
                ? DB::table('actions')->insert(['name' => $name])
                : DB::table('actions')->insert(['id' => $id, 'name' => $name]);
        }

        if (!Schema::hasColumn('risk_treatment_requests', 'rejected_by')) {
            Schema::table('risk_treatment_requests', function (Blueprint $table) {
                $table->unsignedBigInteger('rejected_by')->nullable()->after('steering_reviewed_at');
                $table->timestamp('rejected_at')->nullable()->after('rejected_by');
            });
        }

        $actionIds = DB::table('actions')->whereIn('name', array_keys($this->defaults()))->pluck('id', 'name');
        foreach ($this->defaults() as $name => [$message, $roles]) {
            $actionId = $actionIds[$name] ?? null;
            if (!$actionId || DB::table('system_notifications_settings')->where('action_id', $actionId)->exists()) {
                continue;
            }
            $settingId = DB::table('system_notifications_settings')->insertGetId([
                'action_id' => $actionId,
                'message' => $message,
                'status' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            foreach ($roles as $role) {
                DB::table('notifications_roles')->insert([
                    'role' => $role,
                    'notifiable_id' => $settingId,
                    'notifiable_type' => SystemNotificationSetting::class,
                ]);
            }
        }
    }

    public function down()
    {
        $ids = DB::table('actions')->whereIn('name', array_values(self::NEW_ACTIONS))->pluck('id');
        $settingIds = DB::table('system_notifications_settings')->whereIn('action_id', $ids)->pluck('id');
        DB::table('notifications_roles')
            ->where('notifiable_type', SystemNotificationSetting::class)
            ->whereIn('notifiable_id', $settingIds)
            ->delete();
        DB::table('system_notifications_settings')->whereIn('id', $settingIds)->delete();
        DB::table('actions')->whereIn('id', $ids)->delete();

        if (Schema::hasColumn('risk_treatment_requests', 'rejected_by')) {
            Schema::table('risk_treatment_requests', function (Blueprint $table) {
                $table->dropColumn(['rejected_by', 'rejected_at']);
            });
        }
    }
};
