<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up()
    {
        if (!DB::table('actions')->where('name', 'Risk_Assessment_Request')->exists()) {
            DB::table('actions')->insert([
                'id' => 184,
                'name' => 'Risk_Assessment_Request',
            ]);
        }
    }

    public function down()
    {
        DB::table('actions')->where('name', 'Risk_Assessment_Request')->delete();
    }
};
