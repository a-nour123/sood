@php
    $isRtl = app()->getLocale() === 'ar';
    $total = $rows->count();
    $highCount = ($levelCounts['Catastrophic'] ?? 0) + ($levelCounts['High'] ?? 0);
    $untreatedCount = $treatmentCounts['untreated'] ?? 0;
    $treatedCount = $total - $untreatedCount;
    $assessedCount = array_sum($levelCounts);
    $levelLabel = fn ($level) => __('risk.Level' . str_replace(' ', '', $level));
    $treatmentLabel = fn ($key) => $key === 'untreated' ? __('risk.Untreated') : __('risk.Treat' . ucfirst($key));
    $notSet = __('risk.NotSet');
    $riskAppetite = $riskAppetite ?? null;
    $appetiteAssessed = $rows->filter(fn ($row) => !empty($row['appetite']));
    $exceedingCount = $appetiteAssessed->filter(fn ($row) => !$row['appetite']['within'])->count();
@endphp
<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}" dir="{{ $isRtl ? 'rtl' : 'ltr' }}">

<head>
    <meta charset="utf-8">
    <title>{{ __('risk.RegisterReportTitle') }}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --ksu-navy: #0b3a5b;
            --ksu-blue: #1f6fa8;
            --ksu-sky: #e8f1f8;
            --ink: #1f2937;
            --muted: #6b7280;
            --line: #e5e7eb;
            --paper: #ffffff;
        }

        @page {
            size: A4 landscape;
            margin: 12mm 10mm 16mm;

            @bottom-left {
                content: "{{ addslashes(__('risk.RegisterReportSubtitle')) }} — King Saud University";
                font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif;
                font-size: 9px;
                color: #6b7280;
            }

            @bottom-right {
                content: {!! $isRtl ? 'counter(pages) " / " counter(page)' : 'counter(page) " / " counter(pages)' !!};
                font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif;
                font-size: 9px;
                color: #6b7280;
            }
        }

        * {
            box-sizing: border-box;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }

        body {
            margin: 0;
            font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif;
            font-size: 11px;
            color: var(--ink);
            background: #f3f4f6;
        }

        .sheet {
            max-width: 1180px;
            margin: 24px auto;
            background: var(--paper);
            padding: 28px 32px 40px;
            box-shadow: 0 10px 30px rgba(15, 23, 42, .08);
            border-radius: 10px;
        }

        .toolbar {
            max-width: 1180px;
            margin: 16px auto 0;
            display: flex;
            justify-content: flex-end;
        }

        .toolbar button {
            font-family: inherit;
            font-size: 13px;
            font-weight: 700;
            color: #fff;
            background: var(--ksu-navy);
            border: 0;
            border-radius: 8px;
            padding: 9px 18px;
            cursor: pointer;
        }

        /* Header */
        .report-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 24px;
            padding-bottom: 16px;
            border-bottom: 3px solid var(--ksu-navy);
        }

        .report-header img {
            height: 72px;
            object-fit: contain;
        }

        .report-title h1 {
            margin: 0;
            font-size: 22px;
            font-weight: 800;
            color: var(--ksu-navy);
        }

        .report-title p {
            margin: 2px 0 0;
            font-size: 13px;
            color: var(--ksu-blue);
            font-weight: 600;
        }

        .report-meta {
            text-align: {{ $isRtl ? 'left' : 'right' }};
            font-size: 11px;
            color: var(--muted);
            line-height: 1.8;
        }

        .report-meta strong {
            color: var(--ink);
        }

        .confidential {
            margin-top: 10px;
            display: inline-block;
            font-size: 10px;
            font-weight: 700;
            color: #b91c1c;
            background: #fef2f2;
            border: 1px solid #fecaca;
            border-radius: 999px;
            padding: 2px 10px;
        }

        /* Summary */
        .section-title {
            margin: 22px 0 10px;
            font-size: 14px;
            font-weight: 800;
            color: var(--ksu-navy);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .section-title::before {
            content: '';
            width: 4px;
            height: 16px;
            border-radius: 2px;
            background: var(--ksu-blue);
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
        }

        .stat {
            border: 1px solid var(--line);
            border-radius: 10px;
            padding: 12px 14px;
            background: linear-gradient(180deg, #fff, #fafbfc);
        }

        .stat .label {
            color: var(--muted);
            font-size: 11px;
        }

        .stat .value {
            font-size: 24px;
            font-weight: 800;
            color: var(--ksu-navy);
            line-height: 1.3;
        }

        .stat.danger .value {
            color: #dc2626;
        }

        .stat.ok .value {
            color: #16a34a;
        }

        .stat.warn .value {
            color: #d97706;
        }

        .distribution {
            display: grid;
            grid-template-columns: 3fr 2fr;
            gap: 16px;
            margin-top: 12px;
        }

        .panel {
            border: 1px solid var(--line);
            border-radius: 10px;
            padding: 12px 14px;
        }

        .panel h3 {
            margin: 0 0 10px;
            font-size: 12px;
            color: var(--ink);
        }

        .bar {
            display: flex;
            height: 14px;
            border-radius: 999px;
            overflow: hidden;
            background: #f3f4f6;
        }

        .bar span {
            display: block;
            height: 100%;
        }

        .legend {
            display: flex;
            flex-wrap: wrap;
            gap: 10px 18px;
            margin-top: 10px;
        }

        .legend-item {
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .dot {
            width: 10px;
            height: 10px;
            border-radius: 3px;
            display: inline-block;
        }

        .chips {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }

        .chip {
            border: 1px solid var(--line);
            background: var(--ksu-sky);
            color: var(--ksu-navy);
            border-radius: 999px;
            padding: 3px 12px;
            font-weight: 700;
        }

        .chip b {
            margin-inline-start: 6px;
            color: var(--ink);
        }

        .filters {
            margin-top: 10px;
            color: var(--muted);
        }

        .filters span {
            display: inline-block;
            margin-inline-end: 14px;
        }

        .filters strong {
            color: var(--ink);
        }

        /* Risk cards */
        .risk-card {
            border: 1px solid var(--line);
            border-radius: 10px;
            margin-top: 14px;
        }

        .risk-head,
        .fields,
        .text-block,
        .stats,
        .distribution {
            page-break-inside: avoid;
            break-inside: avoid;
        }

        .section-title,
        .risk-head {
            page-break-after: avoid;
            break-after: avoid;
        }

        .risk-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 10px 14px;
            background: var(--ksu-sky);
            border-bottom: 1px solid var(--line);
            border-inline-start: 5px solid var(--ksu-navy);
            border-radius: 10px 10px 0 0;
        }

        .risk-id {
            font-weight: 800;
            color: #fff;
            background: var(--ksu-navy);
            border-radius: 6px;
            padding: 2px 8px;
            margin-inline-end: 8px;
            white-space: nowrap;
        }

        .risk-subject {
            font-size: 13px;
            font-weight: 700;
        }

        .badges {
            display: flex;
            gap: 8px;
            flex-shrink: 0;
        }

        .badge {
            border-radius: 8px;
            padding: 4px 10px;
            color: #fff;
            font-weight: 700;
            text-align: center;
            min-width: 110px;
            line-height: 1.4;
        }

        .badge small {
            display: block;
            font-size: 9px;
            font-weight: 600;
            opacity: .9;
        }

        .badge.empty {
            background: #e5e7eb;
            color: var(--muted);
        }

        .fields {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            border-bottom: 1px solid var(--line);
        }

        .field {
            padding: 8px 12px;
            border-inline-end: 1px solid var(--line);
            border-top: 1px solid var(--line);
        }

        .field:nth-child(-n+5) {
            border-top: 0;
        }

        .field:nth-child(5n) {
            border-inline-end: 0;
        }

        .field .k {
            color: var(--muted);
            font-size: 10px;
        }

        .field .v {
            font-weight: 600;
            word-wrap: break-word;
        }

        .texts {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
        }

        .text-block {
            padding: 8px 12px;
            border-top: 1px solid var(--line);
        }

        .text-block:nth-child(odd) {
            border-inline-end: 1px solid var(--line);
        }

        .text-block:nth-child(-n+2) {
            border-top: 0;
        }

        .text-block .k {
            color: var(--ksu-blue);
            font-weight: 700;
            font-size: 10px;
            margin-bottom: 2px;
        }

        .text-block .v p {
            margin: 0;
        }

        .empty-state {
            text-align: center;
            color: var(--muted);
            padding: 40px 0;
            font-size: 13px;
        }

        .page-footer {
            margin-top: 24px;
            padding-top: 8px;
            border-top: 1px solid var(--line);
            display: flex;
            justify-content: space-between;
            color: var(--muted);
            font-size: 10px;
        }

        @media print {
            body {
                background: #fff;
            }

            .toolbar {
                display: none;
            }

            .sheet {
                max-width: none;
                margin: 0;
                padding: 0;
                box-shadow: none;
                border-radius: 0;
            }

            .page-footer {
                page-break-inside: avoid;
                break-inside: avoid;
            }
        }
    </style>
</head>

<body>
    <div class="toolbar">
        <button type="button" onclick="window.print()">{{ __('risk.PrintReport') }}</button>
    </div>

    <div class="sheet">
        <header class="report-header">
            <img src="{{ asset('images/ksu-logo.png') }}" alt="King Saud University">
            <div class="report-title">
                <h1>{{ __('risk.RegisterReportTitle') }}</h1>
                <p>{{ __('risk.RegisterReportSubtitle') }}</p>
                <span class="confidential">{{ __('risk.Confidential') }}</span>
            </div>
            <div class="report-meta">
                <div>{{ __('risk.ReportGeneratedAt') }}: <strong>{{ now()->format('Y-m-d H:i') }}</strong></div>
                <div>{{ __('risk.ReportGeneratedBy') }}: <strong>{{ optional(auth()->user())->name }}</strong></div>
                <div>{{ __('risk.TotalRisks') }}: <strong>{{ $total }}</strong></div>
            </div>
        </header>

        <div class="section-title">{{ __('risk.LevelDistribution') }}</div>
        <div class="stats">
            <div class="stat">
                <div class="label">{{ __('risk.TotalRisks') }}</div>
                <div class="value">{{ $total }}</div>
            </div>
            <div class="stat danger">
                <div class="label">{{ $levelLabel('Catastrophic') }} + {{ $levelLabel('High') }}</div>
                <div class="value">{{ $highCount }}</div>
            </div>
            <div class="stat ok">
                <div class="label">{{ __('risk.TreatedRisks') }}</div>
                <div class="value">{{ $treatedCount }}</div>
            </div>
            <div class="stat warn">
                <div class="label">{{ __('risk.Untreated') }}</div>
                <div class="value">{{ $untreatedCount }}</div>
            </div>
            @if ($appetiteAssessed->isNotEmpty())
                <div class="stat danger">
                    <div class="label">{{ __('risk.ExceedsAppetite') }}</div>
                    <div class="value">{{ $exceedingCount }}</div>
                </div>
            @endif
        </div>

        @if ($riskAppetite)
            <div class="filters">
                <strong>{{ __('risk.RiskAppetite') }}:</strong>
                @if ($riskAppetite['name'])
                    <span>{{ $riskAppetite['name'] }} ({{ __('risk.AppetiteMaxScore') }} {{ $riskAppetite['value'] }})</span>
                @endif
                @if ($riskAppetite['statement'])
                    <div style="white-space: pre-line; margin-top: 4px;">{{ $riskAppetite['statement'] }}</div>
                @endif
            </div>
        @endif

        <div class="distribution">
            <div class="panel">
                <h3>{{ __('risk.InherentRisk') }}</h3>
                <div class="bar">
                    @foreach ($levelCounts as $level => $count)
                        @if ($count > 0 && $assessedCount > 0)
                            <span style="width: {{ round($count / $assessedCount * 100, 2) }}%; background: {{ $levelColors[$level] ?? '#9ca3af' }};"></span>
                        @endif
                    @endforeach
                </div>
                <div class="legend">
                    @foreach ($levelCounts as $level => $count)
                        <div class="legend-item">
                            <span class="dot" style="background: {{ $levelColors[$level] ?? '#9ca3af' }};"></span>
                            {{ $levelLabel($level) }}: <strong>{{ $count }}</strong>
                        </div>
                    @endforeach
                </div>
            </div>
            <div class="panel">
                <h3>{{ __('risk.TreatmentDistribution') }}</h3>
                <div class="chips">
                    @forelse ($treatmentCounts as $key => $count)
                        <span class="chip">{{ $treatmentLabel($key) }}<b>{{ $count }}</b></span>
                    @empty
                        <span class="filters">{{ $notSet }}</span>
                    @endforelse
                </div>
            </div>
        </div>

        <div class="filters">
            <strong>{{ __('risk.AppliedFilters') }}:</strong>
            @forelse ($filters as $label => $value)
                <span>{{ $label }}: <strong>{{ $value }}</strong></span>
            @empty
                <span>{{ __('risk.NoFiltersApplied') }}</span>
            @endforelse
        </div>

        <div class="section-title">{{ __('risk.RiskDetails') }}</div>

        @forelse ($rows as $row)
            @php
                $risk = $row['risk'];
                $mitigation = $risk->mitigation;
            @endphp
            <article class="risk-card">
                <div class="risk-head">
                    <div>
                        <span class="risk-id">R-{{ $risk->id }}</span>
                        <span class="risk-subject">{{ $risk->subject }}</span>
                    </div>
                    <div class="badges">
                        @foreach (['inherent' => __('risk.InherentRisk'), 'residual' => __('risk.ResidualRiskLevel')] as $key => $title)
                            @if ($row[$key])
                                <div class="badge" style="background: {{ $row[$key]['color'] }};">
                                    <small>{{ $title }}</small>
                                    {{ $levelLabel($row[$key]['level']) }} ({{ $row[$key]['score'] }})
                                </div>
                            @else
                                <div class="badge empty">
                                    <small>{{ $title }}</small>
                                    {{ $notSet }}
                                </div>
                            @endif
                        @endforeach
                        @if (!empty($row['appetite']))
                            <div class="badge" style="background: {{ $row['appetite']['within'] ? '#28c76f' : '#ea5455' }};">
                                <small>{{ __('risk.RiskAppetite') }}</small>
                                {{ $row['appetite']['within'] ? __('risk.WithinAppetite') : __('risk.ExceedsAppetite') }}
                            </div>
                        @endif
                    </div>
                </div>

                <div class="fields">
                    <div class="field">
                        <div class="k">{{ __('risk.Category') }}</div>
                        <div class="v">{{ optional($risk->category)->name ?: $notSet }}</div>
                    </div>
                    <div class="field">
                        <div class="k">{{ __('locale.Source') }}</div>
                        <div class="v">{{ optional($risk->source)->name ?: $notSet }}</div>
                    </div>
                    <div class="field">
                        <div class="k">{{ __('risk.RiskOwner') }}</div>
                        <div class="v">{{ optional($risk->owner)->name ?: $notSet }}</div>
                    </div>
                    <div class="field">
                        <div class="k">{{ __('risk.RiskManager') }}</div>
                        <div class="v">{{ optional($risk->manager)->name ?: $notSet }}</div>
                    </div>
                    <div class="field">
                        <div class="k">{{ __('risk.ResponsibleDepartment') }}</div>
                        <div class="v">{{ optional($risk->responsibleDepartment)->name ?: $notSet }}</div>
                    </div>
                    <div class="field">
                        <div class="k">{{ __('locale.SubmissionDate') }}</div>
                        <div class="v">{{ $risk->submission_date ? \Carbon\Carbon::parse($risk->submission_date)->format('Y-m-d') : $notSet }}</div>
                    </div>
                    <div class="field">
                        <div class="k">{{ __('risk.TreatmentAction') }}</div>
                        <div class="v">{{ $treatmentLabel($row['treatment'] ?: 'untreated') }}</div>
                    </div>
                    <div class="field">
                        <div class="k">{{ __('locale.MitigationEffort') }}</div>
                        <div class="v">{{ optional(optional($mitigation)->mitigationEfforts)->name ?: $notSet }}</div>
                    </div>
                    <div class="field">
                        <div class="k">{{ __('locale.PlanningStrategy') }}</div>
                        <div class="v">{{ optional(optional($mitigation)->planningStrategies)->name ?: $notSet }}</div>
                    </div>
                    <div class="field">
                        <div class="k">{{ __('risk.LinkedAssets') }}</div>
                        <div class="v">{{ $risk->assets->pluck('name')->implode('، ') ?: $notSet }}</div>
                    </div>
                </div>

                <div class="texts">
                    <div class="text-block">
                        <div class="k">{{ __('locale.Description') }}</div>
                        <div class="v">{{ $risk->risk_description ?: $notSet }}</div>
                    </div>
                    <div class="text-block">
                        <div class="k">{{ __('risk.CurrentControl') }}</div>
                        <div class="v">{{ $risk->current_control ?: $notSet }}</div>
                    </div>
                    <div class="text-block">
                        <div class="k">{{ __('locale.CurrentSolution') }}</div>
                        <div class="v">{!! optional($mitigation)->current_solution ?: e($notSet) !!}</div>
                    </div>
                    <div class="text-block">
                        <div class="k">{{ __('locale.KRIs') }}</div>
                        <div class="v">{!! $risk->notes ?: e($notSet) !!}</div>
                    </div>
                </div>
            </article>
        @empty
            <div class="empty-state">{{ __('risk.NoRisksToExport') }}</div>
        @endforelse

        <footer class="page-footer">
            <span>{{ __('risk.RegisterReportSubtitle') }} — King Saud University</span>
            <span>{{ __('risk.Confidential') }}</span>
        </footer>
    </div>

    <script>
        window.addEventListener('load', function () {
            var print = function () { window.print(); };
            if (document.fonts && document.fonts.ready) {
                document.fonts.ready.then(print);
            } else {
                print();
            }
        });
    </script>
</body>

</html>
