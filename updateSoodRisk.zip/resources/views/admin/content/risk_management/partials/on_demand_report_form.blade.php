<div class="card mb-2">
    <div class="card-header">
        <h4 class="card-title mb-0">{{ __('risk.OnDemandReport') }}</h4>
    </div>
    <div class="card-body">
        <p class="text-muted">{{ __('risk.OnDemandReportHint') }}</p>
        <form method="get" action="{{ route('admin.risk_management.on_demand_report') }}" class="row align-items-end">
            <div class="col-md-3 mb-1">
                <label class="form-label">{{ __('risk.OnDemandReport') }}</label>
                <select class="form-select" name="report_type" required>
                    <option value="register">{{ __('risk.ReportRegister') }}</option>
                    <option value="assessment_treatment">{{ __('risk.ReportAssessmentTreatment') }}</option>
                    <option value="acceptance">{{ __('risk.ReportAcceptance') }}</option>
                </select>
            </div>
            <div class="col-md-2 mb-1">
                <label class="form-label">{{ __('risk.DateFrom') }}</label>
                <input type="date" class="form-control" name="date_from" required value="{{ old('date_from') }}">
            </div>
            <div class="col-md-2 mb-1">
                <label class="form-label">{{ __('risk.DateTo') }}</label>
                <input type="date" class="form-control" name="date_to" required value="{{ old('date_to') }}">
            </div>
            <div class="col-md-2 mb-1">
                <label class="form-label">{{ __('risk.FileFormat') }}</label>
                <select class="form-select" name="format" required>
                    <option value="word">Word</option>
                    <option value="excel">Excel</option>
                    <option value="pdf">PDF</option>
                </select>
            </div>
            <div class="col-md-3 mb-1">
                <button type="submit" class="btn btn-primary">{{ __('risk.DownloadReport') }}</button>
            </div>
        </form>
    </div>
</div>
