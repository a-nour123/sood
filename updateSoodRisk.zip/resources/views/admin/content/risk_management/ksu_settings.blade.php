@extends('admin/layouts/contentLayoutMaster')

@section('title', __('risk.KsuRiskSettings'))

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
@endsection

@section('content')
    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">
            <div class="row breadcrumbs-top">
                <div class="col-12">
                    <div class="page-title mt-2">
                        <div class="row">
                            <div class="col-sm-6 ps-0">
                                @if (@isset($breadcrumbs))
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item">
                                            <a href="{{ route('admin.dashboard') }}">{{ __('locale.Dashboard') }}</a>
                                        </li>
                                        @foreach ($breadcrumbs as $breadcrumb)
                                            <li class="breadcrumb-item">
                                                @if (isset($breadcrumb['link']))
                                                    <a href="{{ $breadcrumb['link'] }}">{{ $breadcrumb['name'] }}</a>
                                                @else
                                                    {{ $breadcrumb['name'] }}
                                                @endif
                                            </li>
                                        @endforeach
                                    </ol>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @if (auth()->user()->hasPermission('riskmanagement.on_demand_report'))
        @include('admin.content.risk_management.partials.on_demand_report_form')
    @endif

    @if (session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif
    @if ($errors->any())
        <div class="alert alert-danger">
            <ul class="mb-0">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form method="post" action="{{ route('admin.risk_management.ksu_settings.save') }}">
        @csrf
        <div class="card mb-2">
            <div class="card-header">
                <h4 class="card-title mb-0">{{ __('risk.ReportRecipients') }}</h4>
            </div>
            <div class="card-body">
                <p class="text-muted">{{ __('risk.ReportRecipientsHint') }}</p>
                @foreach ($schedules as $schedule)
                    <div class="border rounded p-2 mb-2">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <strong>{{ ucfirst($schedule->frequency) }} — {{ $schedule->report_type }}</strong>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox"
                                    name="schedules[{{ $schedule->id }}][is_active]" value="1"
                                    id="schedule_active_{{ $schedule->id }}"
                                    {{ $schedule->is_active ? 'checked' : '' }}>
                                <label class="form-check-label" for="schedule_active_{{ $schedule->id }}">{{ __('risk.Active') }}</label>
                            </div>
                        </div>
                        <label class="form-label">{{ __('risk.Recipients') }}</label>
                        <select class="select2 form-select" multiple
                            name="schedules[{{ $schedule->id }}][users][]">
                            @foreach ($users as $user)
                                <option value="{{ $user->id }}"
                                    {{ in_array($user->id, $schedule->recipient_user_ids ?? []) ? 'selected' : '' }}>
                                    {{ $user->name }} ({{ $user->email }})
                                </option>
                            @endforeach
                        </select>
                        @if ($schedule->last_run_at)
                            <small class="text-muted d-block mt-1">{{ $schedule->last_run_at }}</small>
                        @endif
                    </div>
                @endforeach
            </div>
        </div>

        <div class="card mb-2">
            <div class="card-header">
                <h4 class="card-title mb-0">{{ __('risk.ReassessmentNotifications') }}</h4>
            </div>
            <div class="card-body">
                <p class="text-muted">{{ __('risk.ReassessmentHint') }}</p>
                <div class="form-check mb-2">
                    <input class="form-check-input" type="checkbox" name="reassessment_active" value="1"
                        id="reassessment_active" {{ optional($reassessment)->is_active ? 'checked' : '' }}>
                    <label class="form-check-label" for="reassessment_active">{{ __('risk.EnableReassessment') }}</label>
                </div>
                <div class="row">
                    <div class="col-md-4 mb-1">
                        <label class="form-label">{{ __('risk.NormalIntervalDays') }}</label>
                        <input type="number" min="1" class="form-control" name="normal_interval_days"
                            value="{{ old('normal_interval_days', optional($reassessment)->normal_interval_days ?? 365) }}">
                    </div>
                    <div class="col-md-4 mb-1">
                        <label class="form-label">{{ __('risk.SensitiveIntervalDays') }}</label>
                        <input type="number" min="1" class="form-control" name="sensitive_interval_days"
                            value="{{ old('sensitive_interval_days', optional($reassessment)->sensitive_interval_days ?? 90) }}">
                    </div>
                    <div class="col-md-4 mb-1">
                        <label class="form-label">{{ __('risk.SensitiveRankMax') }}</label>
                        <input type="number" min="0" max="10" class="form-control" name="sensitive_rank_max"
                            value="{{ old('sensitive_rank_max', optional($reassessment)->sensitive_rank_max ?? 2) }}">
                    </div>
                </div>
                <div class="form-check mb-2">
                    <input class="form-check-input" type="checkbox" name="notify_asset_owner" value="1"
                        id="notify_asset_owner" {{ optional($reassessment)->notify_asset_owner ? 'checked' : '' }}>
                    <label class="form-check-label" for="notify_asset_owner">{{ __('risk.NotifyAssetOwner') }}</label>
                </div>
                <label class="form-label">{{ __('risk.Recipients') }}</label>
                <select class="select2 form-select" multiple name="reassessment_users[]">
                    @foreach ($users as $user)
                        <option value="{{ $user->id }}"
                            {{ in_array($user->id, optional($reassessment)->recipient_user_ids ?? []) ? 'selected' : '' }}>
                            {{ $user->name }} ({{ $user->email }})
                        </option>
                    @endforeach
                </select>
            </div>
        </div>

        <div class="card mb-2">
            <div class="card-header">
                <h4 class="card-title mb-0">{{ __('risk.ApprovalWorkflow') }}</h4>
            </div>
            <div class="card-body">
                <p class="text-muted">{{ __('risk.ApprovalWorkflowHint') }}</p>
                @foreach (['risk_team', 'ciso', 'steering'] as $stepKey)
                    <div class="mb-2">
                        <label class="form-label">{{ __('risk.ApprovalStep_' . $stepKey) }}</label>
                        <select class="select2 form-select" multiple name="approvers[{{ $stepKey }}][]">
                            @foreach ($users as $user)
                                <option value="{{ $user->id }}"
                                    {{ in_array($user->id, $approvers[$stepKey] ?? []) ? 'selected' : '' }}>
                                    {{ $user->name }} ({{ $user->email }})
                                </option>
                            @endforeach
                        </select>
                    </div>
                @endforeach
            </div>
        </div>

        <div class="card mb-2">
            <div class="card-header">
                <h4 class="card-title mb-0">{{ __('risk.RiskAppetite') }}</h4>
            </div>
            <div class="card-body">
                <p class="text-muted">{{ __('risk.RiskAppetiteSettingsHint') }}</p>
                <div class="row">
                    <div class="col-md-6 mb-2">
                        <label class="form-label">{{ __('risk.ApprovedRiskAppetite') }}</label>
                        <select class="select2 form-select" name="risk_appetite_id">
                            <option value="">{{ __('risk.NoAppetiteSelected') }}</option>
                            @foreach ($riskAppetites as $appetite)
                                <option value="{{ $appetite->id }}"
                                    {{ (string) old('risk_appetite_id', $appetiteSettings['appetite_id']) === (string) $appetite->id ? 'selected' : '' }}>
                                    {{ $appetite->name }} — {{ __('risk.AppetiteMaxScore') }}: {{ $appetite->value }}
                                </option>
                            @endforeach
                        </select>
                        @if ($riskAppetites->isEmpty())
                            <small class="text-warning d-block mt-50">{{ __('risk.NoAppetitesDefined') }}</small>
                        @endif
                    </div>
                    <div class="col-md-6 mb-2 d-flex align-items-center">
                        <div class="form-check form-switch">
                            <input type="hidden" name="appetite_requires_steering" value="0">
                            <input class="form-check-input" type="checkbox" id="appetite_requires_steering"
                                name="appetite_requires_steering" value="1"
                                {{ old('appetite_requires_steering', $appetiteSettings['requires_steering']) ? 'checked' : '' }}>
                            <label class="form-check-label" for="appetite_requires_steering">{{ __('risk.AppetiteRequiresSteering') }}</label>
                        </div>
                    </div>
                </div>
                <label class="form-label">{{ __('risk.RiskAppetiteStatement') }}</label>
                <div class="border rounded p-1 bg-light" style="white-space: pre-line;">{{ $appetiteSettings['statement'] ?: __('risk.NoAppetiteStatement') }}</div>
            </div>
        </div>

        <div class="card mb-2">
            <div class="card-header">
                <h4 class="card-title mb-0">{{ __('risk.DefaultPermissions') }}</h4>
            </div>
            <div class="card-body">
                <p class="text-muted">{{ __('risk.DefaultPermissionsHint') }}</p>
                @foreach ($permissions as $permission)
                    @php $selectedRoles = collect($assigned->get($permission->id, []))->all(); @endphp
                    <div class="mb-2">
                        <label class="form-label">{{ $permission->name }}</label>
                        <select class="select2 form-select" multiple name="permission_roles[{{ $permission->id }}][]">
                            @foreach ($roles as $role)
                                <option value="{{ $role->id }}" {{ in_array($role->id, $selectedRoles) ? 'selected' : '' }}>
                                    {{ $role->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                @endforeach
            </div>
        </div>

        <button type="submit" class="btn btn-primary">{{ __('risk.SaveSettings') }}</button>
    </form>

    <div class="mt-2">
        @foreach ($schedules as $schedule)
            <form class="d-inline" method="post" action="{{ route('admin.risk_management.ksu_settings.send', $schedule->id) }}">
                @csrf
                <button type="submit" class="btn btn-outline-primary mb-1">
                    {{ __('risk.SendNow') }} — {{ ucfirst($schedule->frequency) }}
                </button>
            </form>
        @endforeach
    </div>
@endsection

@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
@endsection

@section('page-script')
    <script src="{{ asset(mix('js/scripts/forms/form-select2.js')) }}"></script>
@endsection
