@extends('admin/layouts/contentLayoutMaster')

@section('title', __('risk.AssessmentRequests'))

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
@endsection

@section('content')
    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">{{ __('locale.Dashboard') }}</a></li>
                @foreach ($breadcrumbs as $breadcrumb)
                    <li class="breadcrumb-item">
                        @if (isset($breadcrumb['link']))
                            <a href="{{ $breadcrumb['link'] }}">{{ $breadcrumb['name'] }}</a>
                        @else
                            {{ $breadcrumb['name'] }}
                        @endif
                    </li>
                @endforeach
            </ol>
        </div>
    </div>

    @if (session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif
    @if ($errors->any())
        <div class="alert alert-danger">
            <ul class="mb-0">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @if ($canDownloadReport)
        @include('admin.content.risk_management.partials.on_demand_report_form')
    @endif

    <div class="row">
        <div class="col-md-6">
            <div class="card mb-2">
                <div class="card-header">
                    <h4 class="card-title mb-0">{{ __('risk.AssetOwnerAssessmentRequest') }}</h4>
                </div>
                <div class="card-body">
                    <p class="text-muted">{{ __('risk.AssetOwnerAssessmentHint') }}</p>
                    <form method="post" action="{{ route('admin.risk_management.assessment_requests.store') }}" enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" name="request_type" value="asset_owner">
                        <div class="mb-1">
                            <label class="form-label">{{ __('risk.SearchAsset') }}</label>
                            <select class="form-select" id="assessment_asset_id" name="asset_id" data-placeholder="{{ __('risk.SearchAssetPlaceholder') }}"></select>
                        </div>
                        <div class="mb-1">
                            <label class="form-label">{{ __('risk.RequestDescription') }}</label>
                            <textarea class="form-control" name="description" rows="3">{{ old('description') }}</textarea>
                        </div>
                        <div class="mb-1">
                            <label class="form-label">{{ __('risk.Attachment') }}</label>
                            <input type="file" class="form-control" name="attachment">
                        </div>
                        <button class="btn btn-primary" type="submit">{{ __('risk.SubmitRequest') }}</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card mb-2">
                <div class="card-header">
                    <h4 class="card-title mb-0">{{ __('risk.OpenAssessmentRequest') }}</h4>
                </div>
                <div class="card-body">
                    <p class="text-muted">{{ __('risk.OpenAssessmentHint') }}</p>
                    <form method="post" action="{{ route('admin.risk_management.assessment_requests.store') }}" enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" name="request_type" value="open">
                        <div class="mb-1">
                            <label class="form-label">{{ __('risk.RequestDescription') }}</label>
                            <textarea class="form-control" name="description" rows="3"></textarea>
                        </div>
                        <div class="mb-1">
                            <label class="form-label">{{ __('risk.Attachment') }}</label>
                            <input type="file" class="form-control" name="attachment">
                        </div>
                        <button class="btn btn-primary" type="submit">{{ __('risk.SubmitRequest') }}</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>{{ __('risk.OnDemandReport') }}</th>
                        <th>{{ __('risk.AssetName') }}</th>
                        <th>{{ __('risk.RequestedBy') }}</th>
                        <th>{{ __('risk.RequestDescription') }}</th>
                        <th>{{ __('locale.Status') }}</th>
                        <th>{{ __('risk.Attachment') }}</th>
                        @if ($canReview)
                            <th>{{ __('risk.ReviewRequest') }}</th>
                        @endif
                    </tr>
                </thead>
                <tbody>
                    @forelse ($requests as $row)
                        <tr>
                            <td>{{ $row->id }}</td>
                            <td>{{ $row->request_type === 'open' ? __('risk.OpenAssessmentRequest') : __('risk.AssetOwnerAssessmentRequest') }}</td>
                            <td>{{ optional($row->asset)->name }}</td>
                            <td>{{ optional($row->requester)->name }}</td>
                            <td>{{ $row->description }}</td>
                            <td>{{ $row->status === 'reviewed' ? __('risk.Reviewed') : __('risk.Pending') }}</td>
                            <td>
                                @if ($row->attachment_path)
                                    <a href="{{ route('admin.risk_management.assessment_requests.file', [$row->id, 'request']) }}">{{ $row->attachment_name }}</a>
                                @endif
                                @if ($row->review_attachment_path)
                                    <div>
                                        <a href="{{ route('admin.risk_management.assessment_requests.file', [$row->id, 'review']) }}">{{ $row->review_attachment_name }}</a>
                                    </div>
                                @endif
                            </td>
                            @if ($canReview)
                                <td>
                                    @if ($row->status === 'pending')
                                        <form method="post" action="{{ route('admin.risk_management.assessment_requests.review', $row->id) }}" enctype="multipart/form-data">
                                            @csrf
                                            <textarea class="form-control mb-1" name="review_notes" rows="2" placeholder="{{ __('risk.ReviewNotes') }}"></textarea>
                                            <input type="file" class="form-control mb-1" name="review_attachment">
                                            @if ($row->asset_id)
                                                <a class="d-block mb-1" href="{{ route('admin.risk_management.index') }}">{{ __('risk.AddRisksForAsset') }}</a>
                                            @endif
                                            <button class="btn btn-sm btn-primary" type="submit">{{ __('risk.MarkReviewed') }}</button>
                                        </form>
                                    @else
                                        {{ optional($row->reviewer)->name }}
                                        <div>{{ $row->review_notes }}</div>
                                    @endif
                                </td>
                            @endif
                        </tr>
                    @empty
                        <tr>
                            <td colspan="8">{{ __('risk.NoRequests') }}</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
            {{ $requests->links() }}
        </div>
    </div>
@endsection

@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
@endsection

@section('page-script')
    <script>
        $('#assessment_asset_id').select2({
            width: '100%',
            placeholder: $('#assessment_asset_id').data('placeholder'),
            minimumInputLength: 2,
            ajax: {
                url: "{{ route('admin.risk_management.ajax.search_missing_risk_assets') }}",
                dataType: 'json',
                delay: 300,
                data: function (params) {
                    return { q: params.term || '', page: params.page || 1 };
                },
                processResults: function (data) {
                    return {
                        results: (data.results || []).map(function (row) {
                            return { id: row.id, text: row.text || row.name };
                        }),
                        pagination: { more: !!(data.pagination && data.pagination.more) }
                    };
                }
            }
        });
    </script>
@endsection
