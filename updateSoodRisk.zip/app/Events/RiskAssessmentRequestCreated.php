<?php

namespace App\Events;

use App\Models\RiskAssessmentRequest;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class RiskAssessmentRequestCreated
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $request;

    public function __construct(RiskAssessmentRequest $request)
    {
        $this->request = $request;
    }

    public function broadcastOn()
    {
        return new PrivateChannel('channel-name');
    }
}
