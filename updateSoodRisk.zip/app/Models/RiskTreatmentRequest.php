<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RiskTreatmentRequest extends Model
{
    use HasFactory;

    protected $guarded = [];

    protected $casts = [
        'decision_date' => 'date',
        'reevaluate_date' => 'date',
        'transferred_action_plan_ids' => 'array',
        'risk_team_reviewed_at' => 'datetime',
        'ciso_reviewed_at' => 'datetime',
        'steering_reviewed_at' => 'datetime',
        'rejected_at' => 'datetime',
    ];

    public function risk()
    {
        return $this->belongsTo(Risk::class);
    }

    public function decisionOwner()
    {
        return $this->belongsTo(User::class, 'decision_owner_id');
    }

    public function startedBy()
    {
        return $this->belongsTo(User::class, 'started_by');
    }

    public function riskTeamReviewer()
    {
        return $this->belongsTo(User::class, 'risk_team_reviewed_by');
    }

    public function cisoReviewer()
    {
        return $this->belongsTo(User::class, 'ciso_reviewed_by');
    }

    public function steeringReviewer()
    {
        return $this->belongsTo(User::class, 'steering_reviewed_by');
    }

    public function rejectedBy()
    {
        return $this->belongsTo(User::class, 'rejected_by');
    }
}
