<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RiskReportSchedule extends Model
{
    use HasFactory;

    protected $guarded = [];

    protected $casts = [
        'recipient_roles' => 'array',
        'recipient_user_ids' => 'array',
        'is_active' => 'boolean',
        'last_run_at' => 'datetime',
    ];
}
