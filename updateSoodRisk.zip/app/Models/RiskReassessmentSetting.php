<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RiskReassessmentSetting extends Model
{
    protected $guarded = [];

    protected $casts = [
        'is_active' => 'boolean',
        'notify_asset_owner' => 'boolean',
        'recipient_user_ids' => 'array',
    ];
}
