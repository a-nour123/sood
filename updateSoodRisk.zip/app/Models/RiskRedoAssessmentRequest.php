<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RiskRedoAssessmentRequest extends Model
{
    use HasFactory;

    protected $guarded = [];

    protected $casts = [
        'reviewed_at' => 'datetime',
    ];

    public function risk()
    {
        return $this->belongsTo(Risk::class);
    }

    public function evidences()
    {
        return $this->hasMany(RiskRedoAssessmentEvidence::class, 'redo_request_id');
    }

    public function startedBy()
    {
        return $this->belongsTo(User::class, 'started_by');
    }
}
