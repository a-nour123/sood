<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MitigationActionPlan extends Model
{
    use HasFactory;

    protected $guarded = [];

    protected $casts = [
        'mitigation_nature' => 'array',
        'mitigation_function' => 'array',
        'likelihood_reduction' => 'float',
        'impact_reduction' => 'float',
        'due_date' => 'date',
    ];

    public function mitigation()
    {
        return $this->belongsTo(Mitigation::class);
    }

    public function risk()
    {
        return $this->belongsTo(Risk::class);
    }

    public function owner()
    {
        return $this->belongsTo(User::class, 'owner_id');
    }
}
