<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RiskRedoAssessmentEvidence extends Model
{
    use HasFactory;

    /**
     * "evidence" is uncountable, so Eloquent would look for
     * risk_redo_assessment_evidence. The migration creates the plural table.
     */
    protected $table = 'risk_redo_assessment_evidences';

    protected $guarded = [];

    public function request()
    {
        return $this->belongsTo(RiskRedoAssessmentRequest::class, 'redo_request_id');
    }

    public function actionPlan()
    {
        return $this->belongsTo(MitigationActionPlan::class, 'action_plan_id');
    }
}
