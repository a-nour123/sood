<?php

namespace App\Services;

use App\Models\CustomRiskModelValue;
use App\Models\Impact;
use App\Models\Likelihood;
use App\Models\Mitigation;
use App\Models\MitigationActionPlan;
use App\Models\Risk;
use App\Models\RiskAppetite;
use App\Models\RiskAppetiteStatement;
use App\Models\RiskLevel;
use App\Models\Setting;
use Illuminate\Support\Collection;

/**
 * KSU Cybersecurity Risk Management Methodology helpers.
 * Qualitative matrix + residual recalculation via action-plan % reductions.
 */
class KsuRiskMethodologyService
{
    /** Score 1..5 → internal max percentage of band (Fix Requests). */
    public const SCORE_TO_PERCENT = [
        1 => 20,
        2 => 40,
        3 => 60,
        4 => 80,
        5 => 100,
    ];

    public const APPETITE_SETTING = 'ksu_risk_appetite_id';
    public const APPETITE_STEERING_SETTING = 'ksu_appetite_exceed_requires_steering';

    protected ?array $config = null;
    protected array|false|null $appetite = null;

    /**
     * Risk formula + levels as configured in Configure > Risk Calculation.
     */
    protected function config(): array
    {
        return $this->config ??= [
            'model' => (int) get_setting('risk_model', 1),
            'impacts' => Impact::count(),
            'likelihoods' => Likelihood::count(),
            'levels' => RiskLevel::orderBy('value', 'desc')->get(),
        ];
    }

    /**
     * Score from the configured risk model (same values as the Risk Calculation matrix).
     */
    public function inherentScore(int $impact, int $likelihood): float
    {
        $config = $this->config();
        $impacts = $config['impacts'];
        $likelihoods = $config['likelihoods'];

        if (!$impacts || !$likelihoods || !$impact || !$likelihood) {
            return 0.0;
        }

        switch ($config['model']) {
            case 2:
                $max = ($likelihoods * $impacts) + $impacts;
                $risk = ($likelihood * $impact) + $impact;
                break;
            case 3:
                $max = 10;
                $risk = $likelihood * $impact;
                break;
            case 4:
                $max = ($likelihoods * $impacts) + $likelihoods;
                $risk = ($likelihood * $impact) + $likelihood;
                break;
            case 5:
                $max = ($likelihoods * $impacts) + (2 * $likelihoods);
                $risk = ($likelihood * $impact) + (2 * $likelihood);
                break;
            case 6:
                $max = 10;
                $risk = (float) CustomRiskModelValue::where('impact_id', $impact)
                    ->where('likelihood_id', $likelihood)
                    ->value('value');
                break;
            default:
                $max = ($likelihoods * $impacts) + (2 * $impacts);
                $risk = ($likelihood * $impact) + (2 * $impact);
        }

        return round($risk * (10 / $max), 1);
    }

    public function levelFromScore(float $score): string
    {
        $levels = $this->config()['levels'];
        $level = $levels->first(fn ($level) => $score >= (float) $level->value) ?? $levels->last();

        return $level->name ?? '—';
    }

    public function levelFromMatrix(int $impact, int $likelihood): string
    {
        return $this->levelFromScore($this->inherentScore($impact, $likelihood));
    }

    public function levelMeta(string $levelName): array
    {
        $level = $this->config()['levels']
            ->first(fn ($level) => $level->name === $levelName || $level->display_name === $levelName);

        return [
            'name' => $levelName,
            'color' => $level->color ?? '#999999',
            'display_name' => ($level->display_name ?? '') ?: $levelName,
        ];
    }

    /**
     * Full evaluation grid keyed [impact_id][likelihood_id] for client-side display.
     */
    public function matrix(): array
    {
        $matrix = [];
        $likelihoodIds = Likelihood::pluck('id');
        foreach (Impact::pluck('id') as $impactId) {
            foreach ($likelihoodIds as $likelihoodId) {
                $matrix[$impactId][$likelihoodId] = $this->evaluate((int) $impactId, (int) $likelihoodId);
            }
        }

        return $matrix;
    }

    public function maxScore(): float
    {
        $max = 0.0;
        foreach ($this->matrix() as $row) {
            foreach ($row as $cell) {
                $max = max($max, (float) $cell['score']);
            }
        }

        return $max > 0 ? $max : 10.0;
    }

    public function evaluate(int $impact, int $likelihood): array
    {
        $score = $this->inherentScore($impact, $likelihood);
        $level = $this->levelFromMatrix($impact, $likelihood);

        return array_merge([
            'impact' => $impact,
            'likelihood' => $likelihood,
            'score' => $score,
            'level' => $level,
        ], $this->levelMeta($level));
    }

    public function scoreToInternalPercent(int $score): int
    {
        $score = max(1, min(5, $score));

        return self::SCORE_TO_PERCENT[$score];
    }

    public function percentToScore(float $percent): int
    {
        $percent = max(0, min(100, $percent));
        if ($percent <= 20) {
            return 1;
        }
        if ($percent <= 40) {
            return 2;
        }
        if ($percent <= 60) {
            return 3;
        }
        if ($percent <= 80) {
            return 4;
        }

        return 5;
    }

    /**
     * Apply total % reductions to a 1–5 dimension (Fix Requests example).
     */
    public function applyReduction(int $inherentScore, float $totalReductionPercent): int
    {
        $totalReductionPercent = max(0, min(100, $totalReductionPercent));
        $internal = $this->scoreToInternalPercent($inherentScore);
        $newInternal = max(0, $internal - $totalReductionPercent);
        $residual = $this->percentToScore($newInternal);

        return max(1, $residual);
    }

    public function recalculateResidualFromActionPlans(Risk $risk, ?Mitigation $mitigation = null, ?Collection $plans = null): array
    {
        $mitigation = $mitigation ?: $risk->mitigation;
        $plans = $plans ?: ($mitigation
            ? MitigationActionPlan::where('mitigation_id', $mitigation->id)->get()
            : collect());

        $likelihoodReduction = min(100, (float) $plans->sum('likelihood_reduction'));
        $impactReduction = min(100, (float) $plans->sum('impact_reduction'));

        $inherentL = (int) ($risk->inherent_likelihood ?: optional($risk->riskScoring)->CLASSIC_likelihood ?: 1);
        $inherentI = (int) ($risk->inherent_impact ?: optional($risk->riskScoring)->CLASSIC_impact ?: 1);

        $residualL = $this->applyReduction($inherentL, $likelihoodReduction);
        $residualI = $this->applyReduction($inherentI, $impactReduction);
        $evaluation = $this->evaluate($residualI, $residualL);
        $inherentEval = $this->evaluate($inherentI, $inherentL);

        if ($mitigation) {
            $mitigation->total_likelihood_reduction = $likelihoodReduction;
            $mitigation->total_impact_reduction = $impactReduction;
            $mitigation->save();
        }

        $risk->inherent_likelihood = $inherentL;
        $risk->inherent_impact = $inherentI;
        $risk->residual_likelihood = $residualL;
        $risk->residual_impact = $residualI;
        $risk->save();

        // Keep classic scoring row aligned with KSU residual score for register/PDF displays
        if ($risk->riskScoring) {
            $risk->riskScoring->calculated_risk = $evaluation['score'];
            $risk->riskScoring->CLASSIC_likelihood = $residualL;
            $risk->riskScoring->CLASSIC_impact = $residualI;
            $risk->riskScoring->save();
        }

        return [
            'inherent' => $inherentEval,
            'residual' => $evaluation,
            'likelihood_reduction' => $likelihoodReduction,
            'impact_reduction' => $impactReduction,
            'risk_reduction_value' => max(0, $inherentEval['score'] - $evaluation['score']),
        ];
    }

    public function treatmentStatusLabel(string $treatmentAction): string
    {
        return match ($treatmentAction) {
            'mitigate' => 'Mitigation',
            'avoid' => 'Avoid',
            'transfer' => 'Transfer',
            'accept' => 'Accept',
            default => 'New',
        };
    }

    /**
     * Acceptance approval path by residual/inherent level (methodology Table 7 + Fix Requests #13).
     */
    public function acceptanceApprovalPath(string $level, bool $exceedsAppetite = false): array
    {
        if ($exceedsAppetite && $this->appetiteRequiresSteering()) {
            return ['steps' => ['ciso', 'steering'], 'auto_accept' => false];
        }

        $level = strtolower($level);
        if (in_array($level, ['very low', 'verylow'], true)) {
            return ['steps' => [], 'auto_accept' => true];
        }
        if (in_array($level, ['low', 'medium'], true)) {
            return ['steps' => ['ciso'], 'auto_accept' => false];
        }
        // high / catastrophic
        return ['steps' => ['ciso', 'steering'], 'auto_accept' => false];
    }

    /**
     * Approved risk appetite (selected in KSU settings) + the latest appetite statement.
     */
    public function appetite(): ?array
    {
        if ($this->appetite === null) {
            $appetiteId = Setting::where('name', self::APPETITE_SETTING)->value('value');
            $row = $appetiteId ? RiskAppetite::find($appetiteId) : null;
            if (!$row && RiskAppetite::count() === 1) {
                $row = RiskAppetite::first();
            }
            $statement = RiskAppetiteStatement::latest('id')->value('statement');

            $this->appetite = ($row || filled($statement)) ? [
                'id' => $row->id ?? null,
                'name' => $row->name ?? null,
                'description' => $row->description ?? null,
                'value' => $row ? (float) $row->value : null,
                'statement' => $statement,
            ] : false;
        }

        return $this->appetite ?: null;
    }

    public function appetiteRequiresSteering(): bool
    {
        return (bool) (Setting::where('name', self::APPETITE_STEERING_SETTING)->value('value') ?? 1);
    }

    /**
     * Residual score (falls back to inherent) of a risk on the configured risk model scale.
     */
    public function residualScore(Risk $risk): ?float
    {
        $impact = (int) ($risk->residual_impact ?: $risk->inherent_impact);
        $likelihood = (int) ($risk->residual_likelihood ?: $risk->inherent_likelihood);

        return ($impact && $likelihood) ? $this->inherentScore($impact, $likelihood) : null;
    }

    /**
     * Compare a score with the approved appetite: null when no appetite value is configured.
     */
    public function appetiteStatus(?float $score): ?array
    {
        $appetite = $this->appetite();
        if ($score === null || !$appetite || $appetite['value'] === null) {
            return null;
        }

        return [
            'within' => $score <= $appetite['value'],
            'score' => $score,
            'limit' => $appetite['value'],
            'name' => $appetite['name'],
        ];
    }

    public function riskAppetiteStatus(Risk $risk): ?array
    {
        return $this->appetiteStatus($this->residualScore($risk));
    }
}
