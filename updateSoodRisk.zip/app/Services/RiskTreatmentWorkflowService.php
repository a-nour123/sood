<?php

namespace App\Services;

use App\Events\RiskRedoAssessmentRequested;
use App\Events\RiskRedoAssessmentReviewed;
use App\Events\RiskTreatmentApproved;
use App\Events\RiskTreatmentNextApproval;
use App\Events\RiskTreatmentRejected;
use App\Events\RiskTreatmentRequested;
use App\Models\Ciso;
use App\Models\Mitigation;
use App\Models\MitigationActionPlan;
use App\Models\Risk;
use App\Models\RiskRedoAssessmentEvidence;
use App\Models\RiskRedoAssessmentRequest;
use App\Models\RiskTreatmentRequest;
use App\Models\Role;
use App\Models\Setting;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;

class RiskTreatmentWorkflowService
{
    public const RISK_TEAM_SETTING = 'ksu_risk_team_user_ids';
    public const STEERING_SETTING = 'ksu_steering_committee_user_ids';
    public const RISK_TEAM_ROLE = 'Risk Assessment Team';

    protected ?array $approverIds = null;
    protected ?array $approverNames = null;

    public function __construct(private KsuRiskMethodologyService $ksu)
    {
    }

    /**
     * Acceptance approval path of a risk: by its level, escalated when it exceeds the approved appetite.
     */
    public function acceptPath(Risk $risk): array
    {
        return $this->acceptContext($risk)['path'];
    }

    /**
     * Everything the Accept decision depends on: score, level, appetite comparison,
     * the level-only path and the final path, plus the scenario key explaining the result.
     */
    public function acceptContext(Risk $risk): array
    {
        $impact = (int) ($risk->residual_impact ?: $risk->inherent_impact ?: 1);
        $likelihood = (int) ($risk->residual_likelihood ?: $risk->inherent_likelihood ?: 1);
        $score = $this->ksu->inherentScore($impact, $likelihood);
        $level = $this->ksu->levelFromMatrix($impact, $likelihood);
        $appetite = $this->ksu->appetiteStatus($score);
        $exceeds = $appetite !== null && !$appetite['within'];
        $basePath = $this->ksu->acceptanceApprovalPath($level);
        $path = $this->ksu->acceptanceApprovalPath($level, $exceeds);
        $requiresSteering = $this->ksu->appetiteRequiresSteering();

        if ($appetite === null) {
            $scenario = 'no_appetite';
        } elseif (!$exceeds) {
            $scenario = 'within';
        } elseif (!$requiresSteering) {
            $scenario = 'exceeds_not_enforced';
        } elseif ($path['steps'] !== $basePath['steps'] || $path['auto_accept'] !== $basePath['auto_accept']) {
            $scenario = 'exceeds_escalated';
        } else {
            $scenario = 'exceeds_already_steering';
        }

        return [
            'impact' => $impact,
            'likelihood' => $likelihood,
            'score' => $score,
            'level' => $level,
            'appetite' => $appetite,
            'statement' => $this->ksu->appetite()['statement'] ?? null,
            'requires_steering' => $requiresSteering,
            'base_path' => $basePath,
            'path' => $path,
            'scenario' => $scenario,
        ];
    }

    /**
     * Step key (risk_team | ciso | steering) a pending request is waiting on.
     */
    public function pendingStep(RiskTreatmentRequest $request): ?string
    {
        return str_starts_with((string) $request->status, 'pending_')
            ? substr($request->status, strlen('pending_'))
            : null;
    }

    /**
     * Only the users assigned to the current step may act on it.
     * When nobody is assigned to that step yet, anyone with the review permission may act.
     */
    public function canActOn(RiskTreatmentRequest $request, ?int $userId): bool
    {
        $step = $this->pendingStep($request);
        if (!$step || !$userId) {
            return false;
        }
        $assigned = $this->approverIds()[$step] ?? [];

        return empty($assigned) || in_array($userId, $assigned, true);
    }

    public function canReviewRedo(?int $userId): bool
    {
        $assigned = $this->approverIds()['risk_team'] ?? [];

        return $userId && (empty($assigned) || in_array($userId, $assigned, true));
    }

    public function stepLabel(?string $step): string
    {
        if (!$step) {
            return '-';
        }
        $names = $this->approverNames()[$step] ?? [];

        return __('risk.ApprovalStep_' . $step) . ($names ? ' (' . implode(', ', $names) . ')' : '');
    }

    protected function log(Risk $risk, string $message, ?int $actorId = null): void
    {
        write_log($risk->id, $actorId ?? auth()->id(), $message);
    }

    /**
     * Audit-log and notify the people concerned by the request's current state.
     */
    protected function announceTreatment(RiskTreatmentRequest $request, string $event, ?int $actorId = null): void
    {
        $risk = $request->risk;
        $actor = optional(User::find($actorId ?? auth()->id()))->name ?? '-';
        $type = $request->treatment_type;
        $step = $this->pendingStep($request);
        $nextLabel = $this->stepLabel($step);
        $riskRef = '"' . ($risk->id + 1000) . '"';

        $messages = [
            'requested' => "Treatment request [{$type}] on risk ID {$riskRef} was submitted by \"{$actor}\". Next approval: {$nextLabel}.",
            'step' => "Treatment request [{$type}] on risk ID {$riskRef} was approved by \"{$actor}\" and moved to: {$nextLabel}.",
            'approved' => "Treatment request [{$type}] on risk ID {$riskRef} was finally approved" . ($actorId ? " by \"{$actor}\"" : ' automatically') . '.',
            'rejected' => "Treatment request [{$type}] on risk ID {$riskRef} was rejected by \"{$actor}\"." . ($request->review_comments ? " Comment: {$request->review_comments}" : ''),
        ];
        $this->log($risk, $messages[$event], $actorId);

        $events = [
            'requested' => RiskTreatmentRequested::class,
            'step' => RiskTreatmentNextApproval::class,
            'approved' => RiskTreatmentApproved::class,
            'rejected' => RiskTreatmentRejected::class,
        ];
        event(new $events[$event]($request));
    }

    /**
     * User ids assigned to each approval step: risk_team | ciso | steering.
     */
    public function approverIds(): array
    {
        if ($this->approverIds !== null) {
            return $this->approverIds;
        }

        $parse = fn ($csv) => array_values(array_filter(array_map('intval', explode(',', (string) $csv))));

        $riskTeam = $parse(Setting::where('name', self::RISK_TEAM_SETTING)->value('value'));
        if (!$riskTeam) {
            $roleId = Role::where('name', self::RISK_TEAM_ROLE)->value('id');
            $riskTeam = $roleId ? User::where('role_id', $roleId)->pluck('id')->all() : [];
        }

        return $this->approverIds = [
            'risk_team' => $riskTeam,
            'ciso' => $parse(optional(Ciso::first())->user_ids),
            'steering' => $parse(Setting::where('name', self::STEERING_SETTING)->value('value')),
        ];
    }

    /**
     * Notification roles for the approval-cycle members (risk_team | ciso | steering => user ids).
     */
    public function approvalCycleRoles(): array
    {
        return $this->approverIds();
    }

    /**
     * Names of the users assigned to each approval step.
     */
    public function approverNames(): array
    {
        if ($this->approverNames !== null) {
            return $this->approverNames;
        }

        $ids = $this->approverIds();
        $names = User::whereIn('id', array_merge(...array_values($ids)))->pluck('name', 'id');

        return $this->approverNames = array_map(
            fn ($stepIds) => collect($stepIds)->map(fn ($id) => $names[$id] ?? null)->filter()->values()->all(),
            $ids
        );
    }

    public function applyMitigate(Risk $risk, array $data, ?int $actorId = null): Mitigation
    {
        return DB::transaction(function () use ($risk, $data, $actorId) {
            $mitigation = $risk->mitigation;
            if (!$mitigation) {
                $mitigation = Mitigation::create([
                    'submission_date' => now(),
                    'last_update' => now(),
                    'planning_strategy' => 3, // Mitigated
                    'mitigation_effort' => $data['mitigation_effort'] ?? null,
                    'mitigation_cost' => $data['mitigation_cost'] ?? null,
                    'mitigation_owner' => $data['mitigation_owner_id'] ?? $risk->owner_id,
                    'current_solution' => $data['current_solution'] ?? null,
                    'security_requirements' => $data['security_requirements'] ?? null,
                    'security_recommendations' => $data['security_recommendations'] ?? null,
                    'submitted_by' => $actorId ?? auth()->id() ?? 1,
                    'planning_date' => $data['planned_mitigation_date'] ?? now()->toDateString(),
                    'mitigation_percent' => 0,
                    'risk_id' => $risk->id,
                    'treatment_due_date' => $data['treatment_due_date'] ?? null,
                    'mitigation_nature' => $data['mitigation_nature'] ?? null,
                    'mitigation_function' => $data['mitigation_function'] ?? null,
                    'expected_result' => $data['expected_result'] ?? null,
                ]);
                $risk->mitigation_id = $mitigation->id;
            } else {
                $mitigation->fill([
                    'last_update' => now(),
                    'planning_strategy' => 3,
                    'mitigation_effort' => $data['mitigation_effort'] ?? $mitigation->mitigation_effort,
                    'mitigation_cost' => $data['mitigation_cost'] ?? $mitigation->mitigation_cost,
                    'mitigation_owner' => $data['mitigation_owner_id'] ?? $mitigation->mitigation_owner,
                    'current_solution' => $data['current_solution'] ?? $mitigation->current_solution,
                    'planning_date' => $data['planned_mitigation_date'] ?? $mitigation->planning_date,
                    'treatment_due_date' => $data['treatment_due_date'] ?? $mitigation->treatment_due_date,
                    'mitigation_nature' => $data['mitigation_nature'] ?? $mitigation->mitigation_nature,
                    'mitigation_function' => $data['mitigation_function'] ?? $mitigation->mitigation_function,
                    'expected_result' => $data['expected_result'] ?? $mitigation->expected_result,
                ])->save();
            }

            if (!empty($data['action_plans']) && is_array($data['action_plans'])) {
                MitigationActionPlan::where('mitigation_id', $mitigation->id)->delete();
                foreach ($data['action_plans'] as $plan) {
                    if (empty($plan['title']) && empty($plan['description'])) {
                        continue;
                    }
                    MitigationActionPlan::create([
                        'mitigation_id' => $mitigation->id,
                        'risk_id' => $risk->id,
                        'title' => $plan['title'] ?? null,
                        'description' => $plan['description'] ?? null,
                        'mitigation_nature' => $plan['mitigation_nature'] ?? null,
                        'mitigation_function' => $plan['mitigation_function'] ?? null,
                        'likelihood_reduction' => min(100, max(0, (float) ($plan['likelihood_reduction'] ?? 0))),
                        'impact_reduction' => min(100, max(0, (float) ($plan['impact_reduction'] ?? 0))),
                        'due_date' => $plan['due_date'] ?? null,
                        'owner_id' => $plan['owner_id'] ?? null,
                        'status' => $plan['status'] ?? 'planned',
                    ]);
                }
            }

            $this->ksu->recalculateResidualFromActionPlans($risk->fresh(['riskScoring', 'mitigation']), $mitigation->fresh());

            $risk->treatment_action = 'mitigate';
            $risk->status = 'Mitigation';
            $risk->mitigation_id = $mitigation->id;
            $risk->save();

            return $mitigation;
        });
    }

    public function startTreatmentRequest(Risk $risk, string $type, array $data, ?int $actorId = null): RiskTreatmentRequest
    {
        if (!in_array($type, ['avoid', 'transfer', 'accept'], true)) {
            throw new InvalidArgumentException('Invalid treatment type');
        }

        $decisionDate = $data['decision_date'] ?? now()->toDateString();
        $reevaluate = $data['reevaluate_date'] ?? Carbon::parse($decisionDate)->addYear()->toDateString();

        $status = 'pending_risk_team';
        if ($type === 'accept') {
            $path = $this->acceptPath($risk);
            if ($path['auto_accept']) {
                $status = 'approved';
            } else {
                $status = in_array('ciso', $path['steps'], true) ? 'pending_ciso' : 'pending_risk_team';
            }
        }

        $request = RiskTreatmentRequest::create([
            'risk_id' => $risk->id,
            'treatment_type' => $type,
            'status' => $status,
            'reason_description' => $data['reason_description'] ?? null,
            'decision_owner_id' => $data['decision_owner_id'] ?? $risk->owner_id,
            'decision_date' => $decisionDate,
            'reevaluate_date' => $reevaluate,
            'strategy_description' => $data['strategy_description'] ?? null,
            'transfer_party_type' => $data['transfer_party_type'] ?? null,
            'transfer_party_description' => $data['transfer_party_description'] ?? null,
            'transferred_action_plan_ids' => $data['transferred_action_plan_ids'] ?? null,
            'started_by' => $actorId ?? auth()->id(),
        ]);

        $risk->treatment_action = $type;
        if ($status === 'approved') {
            $risk->status = $this->ksu->treatmentStatusLabel($type);
        } else {
            // keep pending visual status as requested treatment
            $risk->status = $this->ksu->treatmentStatusLabel($type);
        }
        $risk->save();

        $this->announceTreatment($request, 'requested', $actorId);
        if ($status === 'approved') {
            $this->announceTreatment($request, 'approved');
        }

        return $request;
    }

    public function actOnTreatmentRequest(RiskTreatmentRequest $request, string $decision, ?string $comments = null, ?int $actorId = null): RiskTreatmentRequest
    {
        $actorId = $actorId ?? auth()->id();

        if (!$this->pendingStep($request)) {
            throw new InvalidArgumentException('Request is not actionable');
        }
        if (!$this->canActOn($request, $actorId)) {
            throw new InvalidArgumentException(__('risk.NotYourApprovalStep', ['step' => $this->stepLabel($this->pendingStep($request))]));
        }

        $request->review_comments = $comments;

        if ($decision === 'rejected') {
            $request->status = 'rejected';
            $request->rejected_by = $actorId;
            $request->rejected_at = now();
            $request->save();
            $this->announceTreatment($request, 'rejected', $actorId);
            return $request->fresh();
        }

        if ($request->status === 'pending_risk_team') {
            $request->risk_team_reviewed_by = $actorId;
            $request->risk_team_reviewed_at = now();
            $request->status = 'pending_ciso';
            $request->save();
            $this->announceTreatment($request, 'step', $actorId);
            return $request->fresh();
        }

        if ($request->status === 'pending_ciso') {
            $request->ciso_reviewed_by = $actorId;
            $request->ciso_reviewed_at = now();
            if ($request->treatment_type === 'accept') {
                $path = $this->acceptPath($request->risk);
                if (in_array('steering', $path['steps'], true)) {
                    $request->status = 'pending_steering';
                    $request->save();
                    $this->announceTreatment($request, 'step', $actorId);
                    return $request->fresh();
                }
            }
            $request->status = 'approved';
            $request->save();
            $this->finalizeApproved($request);
            $this->announceTreatment($request, 'approved', $actorId);
            return $request->fresh();
        }

        if ($request->status === 'pending_steering') {
            $request->steering_reviewed_by = $actorId;
            $request->steering_reviewed_at = now();
            $request->status = 'approved';
            $request->save();
            $this->finalizeApproved($request);
            $this->announceTreatment($request, 'approved', $actorId);
            return $request->fresh();
        }

        throw new InvalidArgumentException('Request is not actionable');
    }

    /**
     * Ordered approval cycle for a request: each step has state done|current|upcoming|rejected|skipped.
     */
    public function approvalSteps(RiskTreatmentRequest $request): array
    {
        $reviewers = [
            'risk_team' => [$request->riskTeamReviewer, $request->risk_team_reviewed_at],
            'ciso' => [$request->cisoReviewer, $request->ciso_reviewed_at],
            'steering' => [$request->steeringReviewer, $request->steering_reviewed_at],
        ];

        if ($request->treatment_type === 'accept') {
            $path = $this->acceptPath($request->risk);
            $keys = $path['steps'];
            if ($request->risk_team_reviewed_at) {
                array_unshift($keys, 'risk_team');
            }
            if ($request->steering_reviewed_at && !in_array('steering', $keys, true)) {
                $keys[] = 'steering';
            }
        } else {
            $keys = ['risk_team', 'ciso'];
        }

        $assignees = $this->approverNames();
        $isFinal = in_array($request->status, ['approved', 'rejected'], true);
        $pendingKey = str_starts_with((string) $request->status, 'pending_')
            ? substr($request->status, strlen('pending_'))
            : null;
        $rejectedAssigned = false;

        $steps = [[
            'key' => 'submitted',
            'state' => 'done',
            'by' => optional($request->startedBy)->name,
            'at' => $request->created_at,
        ]];

        foreach ($keys as $key) {
            [$user, $at] = $reviewers[$key];
            if ($at) {
                $state = 'done';
            } elseif ($key === $pendingKey) {
                $state = 'current';
            } elseif ($request->status === 'rejected' && !$rejectedAssigned) {
                $state = 'rejected';
                $rejectedAssigned = true;
                [$user, $at] = [$request->rejectedBy, $request->rejected_at];
            } elseif ($isFinal) {
                $state = 'skipped';
            } else {
                $state = 'upcoming';
            }
            $steps[] = [
                'key' => $key,
                'state' => $state,
                'by' => optional($user)->name,
                'at' => $at,
                'assignees' => $assignees[$key] ?? [],
            ];
        }

        $steps[] = [
            'key' => $request->status === 'rejected' ? 'rejected' : 'approved',
            'state' => $isFinal ? ($request->status === 'rejected' ? 'rejected' : 'done') : 'upcoming',
            'by' => null,
            'at' => $isFinal ? $request->updated_at : null,
            'auto' => $request->status === 'approved' && empty($keys),
        ];

        return $steps;
    }

    protected function finalizeApproved(RiskTreatmentRequest $request): void
    {
        $risk = $request->risk;
        $risk->treatment_action = $request->treatment_type;
        $risk->status = $this->ksu->treatmentStatusLabel($request->treatment_type);
        $risk->save();
    }

    /**
     * Redo Assessment: asset owner submits evidence per action-plan item → risk team.
     */
    public function startRedoAssessment(Risk $risk, array $evidences, ?string $notes = null, ?int $actorId = null): RiskRedoAssessmentRequest
    {
        return DB::transaction(function () use ($risk, $evidences, $notes, $actorId) {
            $pending = RiskRedoAssessmentRequest::where('risk_id', $risk->id)
                ->whereIn('status', ['pending_risk_team', 'in_progress'])
                ->exists();
            if ($pending) {
                throw new InvalidArgumentException(__('risk.RedoAlreadyPending') ?: 'A redo assessment is already pending.');
            }

            $request = RiskRedoAssessmentRequest::create([
                'risk_id' => $risk->id,
                'status' => 'pending_risk_team',
                'notes' => $notes,
                'started_by' => $actorId ?? auth()->id(),
            ]);

            foreach ($evidences as $evidence) {
                $path = null;
                $fileName = null;
                if (!empty($evidence['file']) && $evidence['file'] instanceof UploadedFile) {
                    $path = $evidence['file']->store('risk/' . $risk->id . '/redo/' . $request->id, 'public');
                    $fileName = $evidence['file']->getClientOriginalName();
                }
                RiskRedoAssessmentEvidence::create([
                    'redo_request_id' => $request->id,
                    'action_plan_id' => $evidence['action_plan_id'] ?? null,
                    'file_path' => $path,
                    'file_name' => $fileName,
                    'comment' => $evidence['comment'] ?? null,
                ]);
            }

            $actor = optional(User::find($actorId ?? auth()->id()))->name ?? '-';
            $this->log($risk, "Redo assessment evidence (" . count($evidences) . " item(s)) for risk ID \"" . ($risk->id + 1000) . "\" was submitted by \"{$actor}\". Next: " . $this->stepLabel('risk_team') . '.', $actorId);
            event(new RiskRedoAssessmentRequested($request));

            return $request->load('evidences');
        });
    }

    public function actOnRedoAssessment(RiskRedoAssessmentRequest $request, string $decision, ?string $comments = null, ?int $actorId = null): RiskRedoAssessmentRequest
    {
        if (!in_array($request->status, ['pending_risk_team', 'in_progress'], true)) {
            throw new InvalidArgumentException('Redo request is not actionable');
        }
        if (!$this->canReviewRedo($actorId ?? auth()->id())) {
            throw new InvalidArgumentException(__('risk.NotYourApprovalStep', ['step' => $this->stepLabel('risk_team')]));
        }

        $request->reviewed_by = $actorId ?? auth()->id();
        $request->reviewed_at = now();
        $request->review_comments = $comments;

        if ($decision === 'rejected') {
            $request->status = 'rejected';
        } else {
            $request->status = 'completed';
            // Mark risk back to New so assessment can be redone
            $risk = $request->risk;
            $risk->status = 'New';
            $risk->save();
        }
        $request->save();

        $risk = $request->risk;
        $actor = optional(User::find($request->reviewed_by))->name ?? '-';
        $decisionText = $decision === 'rejected' ? 'rejected' : 'approved';
        $this->log($risk, "Redo assessment of risk ID \"" . ($risk->id + 1000) . "\" was {$decisionText} by \"{$actor}\"." . ($comments ? " Comment: {$comments}" : ''), $request->reviewed_by);
        event(new RiskRedoAssessmentReviewed($request));

        return $request->fresh();
    }
}
