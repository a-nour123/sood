<?php

namespace App\Services;

use App\Exports\KsuOnDemandRiskExport;
use App\Models\Risk;
use Carbon\Carbon;
use Dompdf\Dompdf;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Facades\Excel;
use PhpOffice\PhpWord\IOFactory;
use PhpOffice\PhpWord\PhpWord;
use Symfony\Component\HttpFoundation\Response;

class KsuOnDemandReportService
{
    public function download(string $type, string $from, string $to, string $format): Response
    {
        [$headings, $rows] = $this->build($type, $from, $to);
        $base = $type . '_' . $from . '_' . $to;
        $title = $this->title($type) . ' (' . $from . ' - ' . $to . ')';

        if ($format === 'excel') {
            return Excel::download(new KsuOnDemandRiskExport($headings, $rows, $title), $base . '.xlsx');
        }
        if ($format === 'word') {
            return $this->word($title, $headings, $rows, $base . '.docx');
        }

        return $this->pdf($title, $headings, $rows, $base . '.pdf');
    }

    public function title(string $type): string
    {
        return [
            'register' => __('risk.ReportRegister'),
            'assessment_treatment' => __('risk.ReportAssessmentTreatment'),
            'acceptance' => __('risk.ReportAcceptance'),
        ][$type] ?? $type;
    }

    public function build(string $type, string $from, string $to): array
    {
        $start = Carbon::parse($from)->startOfDay();
        $end = Carbon::parse($to)->endOfDay();

        $risks = Risk::with([
            'owner',
            'assets.Users',
            'mitigation.actionPlans',
            'riskScoring',
            'treatmentRequests.decisionOwner',
        ])->whereBetween('submission_date', [$start, $end]);

        if ($type === 'acceptance') {
            $risks->where(function ($query) use ($start, $end) {
                $query->where('treatment_action', 'accept')
                    ->orWhereHas('treatmentRequests', function ($treatment) use ($start, $end) {
                        $treatment->where('treatment_type', 'accept')
                            ->whereBetween('decision_date', [$start->toDateString(), $end->toDateString()]);
                    });
            });
        }

        $collection = $risks->orderBy('id')->get();
        $headings = $this->headings($type);
        $rows = $collection->map(function (Risk $risk) use ($type) {
            return $type === 'acceptance'
                ? $this->acceptanceRow($risk)
                : ($type === 'assessment_treatment' ? $this->treatmentRow($risk) : $this->registerRow($risk));
        })->all();

        return [$headings, $rows];
    }

    protected function headings(string $type): array
    {
        $base = [
            __('risk.Id'),
            __('locale.Subject'),
            __('locale.Status'),
            __('risk.RiskOwner'),
            __('risk.AssetName'),
            __('risk.AssetOwner'),
            __('risk.TreatmentAction'),
            __('risk.InherentScore'),
            __('risk.InherentLevel'),
        ];

        if ($type === 'register') {
            return array_merge($base, [
                __('risk.ResidualLikelihood'),
                __('risk.ResidualImpact'),
                __('locale.SubmissionDate'),
            ]);
        }

        if ($type === 'assessment_treatment') {
            return array_merge($base, [
                __('risk.CurrentControl'),
                __('risk.MitigationNature'),
                __('risk.MitigationFunction'),
                __('risk.ExpectedResult'),
                __('risk.ActionPlans'),
                __('risk.TreatmentDueDate'),
            ]);
        }

        return array_merge($base, [
            __('risk.ReasonDescription'),
            __('risk.DecisionOwner'),
            __('risk.DecisionDate'),
            __('risk.ReevaluateDate'),
            __('risk.OwnerApprovalStatement'),
            __('locale.Status'),
        ]);
    }

    protected function registerRow(Risk $risk): array
    {
        $eval = $this->evaluation($risk);

        return [
            $risk->id,
            $risk->subject,
            $risk->status,
            optional($risk->owner)->name,
            $risk->assets->pluck('name')->implode(', '),
            $risk->assets->map(fn ($asset) => optional($asset->Users)->name)->filter()->implode(', '),
            $risk->treatment_action,
            $eval['score'] ?? '',
            $eval['level'] ?? '',
            $risk->residual_likelihood,
            $risk->residual_impact,
            $risk->submission_date ? Carbon::parse($risk->submission_date)->format('Y-m-d') : '',
        ];
    }

    protected function treatmentRow(Risk $risk): array
    {
        $eval = $this->evaluation($risk);
        $mitigation = $risk->mitigation;
        $plans = $mitigation ? $mitigation->actionPlans : collect();

        return [
            $risk->id,
            $risk->subject,
            $risk->status,
            optional($risk->owner)->name,
            $risk->assets->pluck('name')->implode(', '),
            $risk->assets->map(fn ($asset) => optional($asset->Users)->name)->filter()->implode(', '),
            $risk->treatment_action,
            $eval['score'] ?? '',
            $eval['level'] ?? '',
            $risk->current_control,
            $mitigation ? $this->joinList($mitigation->mitigation_nature) : '',
            $mitigation ? $this->joinList($mitigation->mitigation_function) : '',
            $mitigation ? $this->joinList($mitigation->expected_result) : '',
            $plans->map(function ($plan) {
                return $plan->title . ' (L ' . $plan->likelihood_reduction . '% / I ' . $plan->impact_reduction . '%)';
            })->implode(' | '),
            optional(optional($mitigation)->treatment_due_date)->format('Y-m-d'),
        ];
    }

    protected function acceptanceRow(Risk $risk): array
    {
        $eval = $this->evaluation($risk);
        $request = $risk->treatmentRequests
            ->where('treatment_type', 'accept')
            ->sortByDesc('id')
            ->first();

        return [
            $risk->id,
            $risk->subject,
            $risk->status,
            optional($risk->owner)->name,
            $risk->assets->pluck('name')->implode(', '),
            $risk->assets->map(fn ($asset) => optional($asset->Users)->name)->filter()->implode(', '),
            $risk->treatment_action,
            $eval['score'] ?? '',
            $eval['level'] ?? '',
            optional($request)->reason_description,
            optional(optional($request)->decisionOwner)->name,
            optional(optional($request)->decision_date)->format('Y-m-d'),
            optional(optional($request)->reevaluate_date)->format('Y-m-d'),
            optional($request)->reason_description,
            optional($request)->status,
        ];
    }

    protected function evaluation(Risk $risk): ?array
    {
        $impact = (int) ($risk->inherent_impact ?: optional($risk->riskScoring)->CLASSIC_impact ?: 0);
        $likelihood = (int) ($risk->inherent_likelihood ?: optional($risk->riskScoring)->CLASSIC_likelihood ?: 0);
        if (!$impact || !$likelihood) {
            return null;
        }

        return app(KsuRiskMethodologyService::class)->evaluate($impact, $likelihood);
    }

    protected function joinList($value): string
    {
        if ($value instanceof Collection) {
            $value = $value->all();
        }
        if (is_string($value)) {
            return $value;
        }

        return is_array($value) ? implode(', ', $value) : '';
    }

    protected function word(string $title, array $headings, array $rows, string $filename): Response
    {
        $phpWord = new PhpWord();
        $section = $phpWord->addSection([
            'orientation' => 'landscape',
            'marginLeft' => 400,
            'marginRight' => 400,
        ]);
        $section->addText($title, ['bold' => true, 'size' => 14]);
        $table = $section->addTable(['borderSize' => 4, 'borderColor' => '999999']);
        $table->addRow();
        foreach ($headings as $heading) {
            $table->addCell(1600)->addText((string) $heading, ['bold' => true, 'size' => 8]);
        }
        foreach ($rows as $row) {
            $table->addRow();
            foreach ($row as $cell) {
                $table->addCell(1600)->addText((string) $cell, ['size' => 8]);
            }
        }

        $tmp = tempnam(sys_get_temp_dir(), 'ksu-risk');
        IOFactory::createWriter($phpWord, 'Word2007')->save($tmp);

        return response()->download($tmp, $filename)->deleteFileAfterSend(true);
    }

    protected function pdf(string $title, array $headings, array $rows, string $filename): Response
    {
        $html = view('admin.content.risk_management.on_demand_pdf', compact('title', 'headings', 'rows'))->render();
        $dompdf = new Dompdf(['isRemoteEnabled' => false]);
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'landscape');
        $dompdf->render();

        return response($dompdf->output(), 200, [
            'Content-Type' => 'application/pdf',
            'Content-Disposition' => 'attachment; filename="' . $filename . '"',
        ]);
    }
}
