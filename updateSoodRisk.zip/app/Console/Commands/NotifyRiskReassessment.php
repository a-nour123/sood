<?php

namespace App\Console\Commands;

use App\Jobs\SendEmailNotificationJob;
use App\Models\Asset;
use App\Models\RiskReassessmentSetting;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class NotifyRiskReassessment extends Command
{
    protected $signature = 'risk:notify-reassessment';

    protected $description = 'Notify configured users when assets are due for risk reassessment';

    public function handle(): int
    {
        $setting = RiskReassessmentSetting::query()->first();
        if (!$setting || !$setting->is_active) {
            $this->info('Reassessment notifications are disabled.');
            return self::SUCCESS;
        }

        $today = Carbon::today();
        $due = [];

        Asset::query()
            ->select('id', 'name', 'asset_owner', 'is_sensitive', 'rank')
            ->orderBy('id')
            ->chunk(200, function ($assets) use ($setting, $today, &$due) {
                foreach ($assets as $asset) {
                    $last = DB::table('risks')
                        ->join('risks_to_assets', 'risks.id', '=', 'risks_to_assets.risk_id')
                        ->where('risks_to_assets.asset_id', $asset->id)
                        ->max('risks.submission_date');

                    $rankMax = (int) ($setting->sensitive_rank_max ?? 0);
                    $isSensitive = (bool) $asset->is_sensitive
                        || ($rankMax > 0 && $asset->rank !== null && (int) $asset->rank <= $rankMax);
                    $interval = $isSensitive
                        ? (int) $setting->sensitive_interval_days
                        : (int) $setting->normal_interval_days;

                    $baseline = $last ? Carbon::parse($last) : null;
                    $isDue = !$baseline || $baseline->copy()->addDays($interval)->lte($today);
                    if (!$isDue) {
                        continue;
                    }

                    $due[] = [
                        'name' => $asset->name,
                        'owner_id' => $asset->asset_owner,
                        'sensitive' => $isSensitive,
                        'last' => $last,
                    ];
                }
            });

        if (empty($due)) {
            $this->info('No assets due for reassessment.');
            return self::SUCCESS;
        }

        $lines = collect($due)->take(50)->map(function ($row) {
            $flag = $row['sensitive'] ? 'sensitive' : 'normal';
            $last = $row['last'] ?: 'never';
            return e($row['name']) . ' (' . $flag . ', last: ' . e((string) $last) . ')';
        })->implode('<br>');

        $subject = 'Risk reassessment due (' . count($due) . ' assets)';
        $body = '<p>The following assets are due for cybersecurity risk reassessment:</p><p>' . $lines . '</p>';

        $userIds = array_map('intval', $setting->recipient_user_ids ?? []);
        if ($setting->notify_asset_owner) {
            foreach ($due as $row) {
                if (!empty($row['owner_id'])) {
                    $userIds[] = (int) $row['owner_id'];
                }
            }
        }
        $userIds = array_values(array_unique(array_filter($userIds)));

        foreach ($userIds as $userId) {
            if (!User::where('id', $userId)->whereNotNull('email')->exists()) {
                continue;
            }
            SendEmailNotificationJob::dispatch($userId, $subject, $body);
        }

        $this->info('Notified ' . count($userIds) . ' users about ' . count($due) . ' assets.');
        return self::SUCCESS;
    }
}