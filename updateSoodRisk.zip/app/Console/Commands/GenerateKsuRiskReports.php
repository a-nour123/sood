<?php

namespace App\Console\Commands;

use App\Jobs\SendEmailNotificationJob;
use App\Models\Risk;
use App\Models\RiskReportSchedule;
use App\Models\User;
use App\Services\KsuRiskMethodologyService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

/**
 * KSU #6 — Automated risk reports (weekly / monthly / quarterly).
 * Generates snapshot files under storage/app/risk-reports and logs recipients.
 */
class GenerateKsuRiskReports extends Command
{
    protected $signature = 'risk:generate-scheduled-reports {--frequency=}';

    protected $description = 'Generate scheduled KSU risk reports (register / assessment-treatment / acceptance)';

    public function handle(KsuRiskMethodologyService $ksu): int
    {
        $frequency = $this->option('frequency');
        $query = RiskReportSchedule::where('is_active', true);
        if ($frequency) {
            $query->where('frequency', $frequency);
        } else {
            // Auto-pick by day: weekly=Monday, monthly=1st, quarterly=1st of quarter months
            $day = now()->dayOfWeekIso; // 1=Mon
            $dayOfMonth = now()->day;
            $month = now()->month;
            $freqs = [];
            if ($day === 1) {
                $freqs[] = 'weekly';
            }
            if ($dayOfMonth === 1) {
                $freqs[] = 'monthly';
                if (in_array($month, [1, 4, 7, 10], true)) {
                    $freqs[] = 'quarterly';
                }
            }
            if (empty($freqs)) {
                $this->info('No schedule due today.');
                return self::SUCCESS;
            }
            $query->whereIn('frequency', $freqs);
        }

        $schedules = $query->get();
        if ($schedules->isEmpty()) {
            $this->info('No active schedules matched.');
            return self::SUCCESS;
        }

        foreach ($schedules as $schedule) {
            $risks = Risk::with(['owner', 'mitigation', 'assets', 'riskScoring', 'treatmentRequests'])
                ->orderBy('id')
                ->get();

            $rows = [];
            foreach ($risks as $risk) {
                $impact = (int) ($risk->inherent_impact ?: optional($risk->riskScoring)->CLASSIC_impact ?: 0);
                $likelihood = (int) ($risk->inherent_likelihood ?: optional($risk->riskScoring)->CLASSIC_likelihood ?: 0);
                $eval = ($impact && $likelihood) ? $ksu->evaluate($impact, $likelihood) : null;
                $rows[] = [
                    'id' => $risk->id,
                    'subject' => $risk->subject,
                    'status' => $risk->status,
                    'treatment_action' => $risk->treatment_action,
                    'owner' => optional($risk->owner)->name,
                    'assets' => $risk->assets->pluck('name')->implode('|'),
                    'inherent_score' => $eval['score'] ?? null,
                    'inherent_level' => $eval['level'] ?? null,
                    'residual_likelihood' => $risk->residual_likelihood,
                    'residual_impact' => $risk->residual_impact,
                    'acceptance_status' => optional($risk->treatmentRequests->where('treatment_type', 'accept')->sortByDesc('id')->first())->status,
                ];
            }

            $dir = 'risk-reports/' . now()->format('Y/m');
            Storage::makeDirectory($dir);
            $filename = sprintf(
                '%s/%s_%s_%s.json',
                $dir,
                $schedule->frequency,
                $schedule->report_type,
                now()->format('Ymd_His')
            );
            Storage::put($filename, json_encode([
                'generated_at' => now()->toDateTimeString(),
                'frequency' => $schedule->frequency,
                'report_type' => $schedule->report_type,
                'recipient_roles' => $schedule->recipient_roles,
                'count' => count($rows),
                'rows' => $rows,
            ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

            // Also write a simple CSV for Excel editability
            $csvName = preg_replace('/\.json$/', '.csv', $filename);
            $csv = fopen('php://temp', 'r+');
            if (!empty($rows)) {
                fputcsv($csv, array_keys($rows[0]));
                foreach ($rows as $row) {
                    fputcsv($csv, $row);
                }
            }
            rewind($csv);
            Storage::put($csvName, stream_get_contents($csv) ?: '');
            fclose($csv);

            $schedule->last_run_at = now();
            $schedule->save();

            $this->emailReport($schedule, $filename, $csvName, count($rows));

            Log::info('KSU risk report generated', [
                'schedule_id' => $schedule->id,
                'file' => $filename,
                'roles' => $schedule->recipient_roles,
                'users' => $schedule->recipient_user_ids,
            ]);

            $this->info("Generated {$filename} ({$schedule->frequency}/{$schedule->report_type})");
        }

        return self::SUCCESS;
    }

    protected function emailReport(RiskReportSchedule $schedule, string $jsonPath, string $csvPath, int $count): void
    {
        $userIds = array_filter(array_map('intval', $schedule->recipient_user_ids ?? []));
        if (empty($userIds)) {
            $this->warn('No recipients configured for ' . $schedule->frequency . '/' . $schedule->report_type);
            return;
        }

        $csv = Storage::exists($csvPath) ? Storage::get($csvPath) : '';
        $preview = e(mb_substr($csv, 0, 4000));
        $subject = 'KSU Risk Report — ' . ucfirst($schedule->frequency) . ' / ' . $schedule->report_type;
        $body = '<p>A scheduled cybersecurity risk report was generated.</p>'
            . '<p><strong>Frequency:</strong> ' . e($schedule->frequency) . '<br>'
            . '<strong>Type:</strong> ' . e($schedule->report_type) . '<br>'
            . '<strong>Risks:</strong> ' . $count . '</p>'
            . '<pre style="font-size:12px;white-space:pre-wrap;">' . $preview . '</pre>';

        foreach ($userIds as $userId) {
            if (!User::where('id', $userId)->whereNotNull('email')->exists()) {
                continue;
            }
            SendEmailNotificationJob::dispatch($userId, $subject, $body);
        }
    }
}
