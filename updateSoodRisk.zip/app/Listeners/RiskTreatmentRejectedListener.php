<?php

namespace App\Listeners;

use App\Events\RiskTreatmentRejected;
use App\Http\Traits\NotificationHandlingTrait;
use App\Models\Action;
use App\Services\RiskTreatmentWorkflowService;

class RiskTreatmentRejectedListener
{
    use NotificationHandlingTrait;

    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  \App\Events\RiskTreatmentRejected  $event
     * @return void
     */
    public function handle(RiskTreatmentRejected $event)
    {
        // Get the action ID for Risk_Treatment_Rejected
        $action1 = Action::where('name', 'Risk_Treatment_Rejected')->first();
        if (!$action1) {
            return;
        }
        $actionId1 = $action1['id'];

        // Get the treatment request and a copy of its risk (variables are set on the copy only)
        $treatmentRequest = $event->treatmentRequest;
        $risk = clone $treatmentRequest->risk;
        $workflow = app(RiskTreatmentWorkflowService::class);
        $nextStep = $workflow->pendingStep($treatmentRequest);

        // Define the roles array for notification
        $roles = [
            'creator' => [$risk->owner_id ?? null],
            'Team-teams' => $risk->teamsForRisk->pluck('id') ?? null,
            'Stakeholder-teams' => $risk->additionalStakeholders->pluck('user_id') ?? null,
            'next_approvers' => $nextStep ? ($workflow->approverIds()[$nextStep] ?? []) : [],
            'requester' => [$treatmentRequest->started_by ?? null],
            'decision_owner' => [$treatmentRequest->decision_owner_id ?? null],
        ];
        // Approval-cycle members (Risk Team / CISO / Steering Committee)
        $roles += $workflow->approvalCycleRoles();

        // Set the properties of the risk object for notification message
        $risk->risk_id = $risk->id + 1000;
        $risk->actor = auth()->user()->name ?? null;
        $risk->treatment = $treatmentRequest->treatment_type;
        $risk->next_step = $workflow->stepLabel($nextStep);
        $risk->comments = $treatmentRequest->review_comments ?: '-';

        // Define the link for redirection after clicking the system notification
        $link = ['link' => route('admin.risk_management.show', ['id' => $risk->id])];

        // handling different kinds of notifications using  "sendNotificationForAction" function from "NotificationHandlingTrait"
        $this->sendNotificationForAction($actionId1, $actionId2 = null, $link, $risk, $roles, $nextDateNotify = null, $modelId = null, $modelType = null, $proccess = null);
    }
}
