<?php

namespace App\Listeners;

use App\Events\RiskRedoAssessmentReviewed;
use App\Http\Traits\NotificationHandlingTrait;
use App\Models\Action;
use App\Services\RiskTreatmentWorkflowService;

class RiskRedoAssessmentReviewedListener
{
    use NotificationHandlingTrait;

    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  \App\Events\RiskRedoAssessmentReviewed  $event
     * @return void
     */
    public function handle(RiskRedoAssessmentReviewed $event)
    {
        // Get the action ID for Risk_Redo_Assessment_Reviewed
        $action1 = Action::where('name', 'Risk_Redo_Assessment_Reviewed')->first();
        if (!$action1) {
            return;
        }
        $actionId1 = $action1['id'];

        // Get the redo request and a copy of its risk (variables are set on the copy only)
        $redoRequest = $event->redoRequest;
        $risk = clone $redoRequest->risk;
        $workflow = app(RiskTreatmentWorkflowService::class);

        // Define the roles array for notification
        $roles = [
            'creator' => [$risk->owner_id ?? null],
            'Team-teams' => $risk->teamsForRisk->pluck('id') ?? null,
            'Stakeholder-teams' => $risk->additionalStakeholders->pluck('user_id') ?? null,
            'requester' => [$redoRequest->started_by ?? null],
        ];
        // Approval-cycle members (Risk Team / CISO / Steering Committee)
        $roles += $workflow->approvalCycleRoles();

        // Set the properties of the risk object for notification message
        $risk->risk_id = $risk->id + 1000;
        $risk->actor = auth()->user()->name ?? null;
        $risk->decision = $redoRequest->status === 'rejected' ? 'rejected' : 'approved';

        // Define the link for redirection after clicking the system notification
        $link = ['link' => route('admin.risk_management.show', ['id' => $risk->id])];

        // handling different kinds of notifications using  "sendNotificationForAction" function from "NotificationHandlingTrait"
        $this->sendNotificationForAction($actionId1, $actionId2 = null, $link, $risk, $roles, $nextDateNotify = null, $modelId = null, $modelType = null, $proccess = null);
    }
}
