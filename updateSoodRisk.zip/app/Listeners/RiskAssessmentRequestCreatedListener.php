<?php

namespace App\Listeners;

use App\Events\RiskAssessmentRequestCreated;
use App\Http\Traits\NotificationHandlingTrait;
use App\Models\Action;

class RiskAssessmentRequestCreatedListener
{
    use NotificationHandlingTrait;

    public function handle(RiskAssessmentRequestCreated $event)
    {
        $action1 = Action::where('name', 'Risk_Assessment_Request')->first();
        $actionId1 = $action1['id'];

        $requestRow = $event->request;
        $requestRow->load('asset');
        $requestRow->load('requester');
        $asset = $requestRow->asset;

        $teamIds = null;
        if ($asset && !empty($asset->teams)) {
            $teamIds = array_values(array_filter(array_map('intval', (array) $asset->teams)));
        }

        $roles = [
            'creator' => [$requestRow->requested_by ?? null],
            'Team-teams' => $teamIds,
            'Stakeholder-teams' => ($asset && $asset->asset_owner) ? [$asset->asset_owner] : null,
        ];
        // Approval-cycle members (Risk Team / CISO / Steering Committee)
        $roles += app(\App\Services\RiskTreatmentWorkflowService::class)->approvalCycleRoles();

        $requestRow->Requester = $requestRow->requester ? $requestRow->requester->name : null;
        $requestRow->Request_Type = $requestRow->request_type;
        $requestRow->Asset_Name = $asset ? $asset->name : null;
        $requestRow->Description = $requestRow->description;

        $link = ['link' => route('admin.risk_management.assessment_requests')];

        $actionId2 = null;
        $nextDateNotify = null;
        $modelId = null;
        $modelType = null;
        $proccess = null;
        $this->sendNotificationForAction($actionId1, $actionId2 = null, $link, $requestRow, $roles, $nextDateNotify = null, $modelId = null, $modelType = null, $proccess = null);
    }
}
