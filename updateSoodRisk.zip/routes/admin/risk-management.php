<?php

use App\Http\Controllers\admin\risk_management\RiskManagementController;
use App\Http\Controllers\admin\risk_management\RiskStatisticsController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register admin risk-management routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "admin" middleware group. Now create something great!
|
*/

Route::group(
    [
        'prefix' => 'risk-management', // Prefix applied on all `risk-management` group routes
        'middleware' => [], // Middlewares applied on all `risk-management` group routes
        'as' => 'risk_management.'
    ],
    function () {
        Route::get('/', [RiskManagementController::class, 'index'])->name('index');
        Route::get('/{id}', [RiskManagementController::class, 'show'])->whereNumber('id')->name('show');
        Route::get('notifications-settings', [App\Http\Controllers\admin\risk_management\RiskManagementController::class, 'notificationsSettingsRisk'])
        ->name('notificationsSettingsRisk');
        Route::get('ksu-settings', [RiskManagementController::class, 'ksuSettings'])->name('ksu_settings');
        Route::post('ksu-settings', [RiskManagementController::class, 'saveKsuSettings'])->name('ksu_settings.save');
        Route::post('ksu-settings/send/{id}', [RiskManagementController::class, 'sendKsuReportNow'])->name('ksu_settings.send');
        Route::get('on-demand-report', [RiskManagementController::class, 'downloadOnDemandReport'])->name('on_demand_report');
        Route::get('assessment-requests', [RiskManagementController::class, 'assessmentRequests'])->name('assessment_requests');
        Route::post('assessment-requests', [RiskManagementController::class, 'storeAssessmentRequest'])->name('assessment_requests.store');
        Route::post('assessment-requests/{id}/review', [RiskManagementController::class, 'reviewAssessmentRequest'])->name('assessment_requests.review');
        Route::get('assessment-requests/{id}/file/{kind}', [RiskManagementController::class, 'downloadAssessmentRequestFile'])->name('assessment_requests.file');
        Route::get('/import', [RiskManagementController::class, 'openImportForm'])->name('import');
        Route::get('/configuretion', [RiskManagementController::class, 'configure'])->name('configuretion');

        Route::group(
            [
                'prefix' => 'ajax', // Prefix applied on all `department` group routes
                'middleware' => [], // Middlewares applied on all `department` group routes
                'as' => 'ajax.'
            ],
            function () {
                Route::post('/download-file', [RiskManagementController::class, 'downloadFile'])->name('download_file');
                Route::delete('/delete-file', [RiskManagementController::class, 'deleteFile'])->name('delete_file');


                Route::post('/accept-reject-mitigation', [RiskManagementController::class, 'acceptOrRejectMitigation'])->name('accept_reject_mitigation');

                Route::post('/update-risk-mitigation', [RiskManagementController::class, 'updateRiskMitigation'])->name('update_risk_mitigation');

                Route::post('/add-risk-review', [RiskManagementController::class, 'addRiskReview'])->name('add_risk_review');

                Route::put('/risk-close-reason', [RiskManagementController::class, 'riskCloseReason'])->name('risk_close_reason');

                Route::put('/risk-reopen', [RiskManagementController::class, 'riskReopen'])->name('risk_reopen');

                Route::put('/risk-change-status', [RiskManagementController::class, 'riskChangeStatus'])->name('risk_Change_Status');

                Route::put('/reset-risk-mitigations', [RiskManagementController::class, 'resetRiskMitigations'])->name('reset_risk_mitigations');

                Route::put('/reset-risk-reviews', [RiskManagementController::class, 'resetRiskReviews'])->name('reset_risk_reviews');

                Route::post('/list', [RiskManagementController::class, 'ajaxGetList'])->name('index');
                Route::post('/', [RiskManagementController::class, 'store'])->name('store');

                Route::get('/risk-levels', [RiskManagementController::class, 'getRiskLevels'])->name('get_risk_levels');
                Route::get('/residual-scoring-history/{id}', [RiskManagementController::class, 'residualScoringHistory'])->name('residual_scoring_history');
                Route::get('/scoring-history/{id}', [RiskManagementController::class, 'scoringHistory'])->name('get_scoring_histories');

                // Route::get('edit/{id}', [RiskManagementController::class, 'ajaxGet'])->name('show');
                Route::put('/update-subject', [RiskManagementController::class, 'updateRiskSubject'])->name('update_subject');
                Route::put('/update-risk-scoring', [RiskManagementController::class, 'updateRiskScoring'])->name('update_risk_scoring');
                Route::put('/add-comment', [RiskManagementController::class, 'addRiskComment'])->name('add_comment');
                Route::put('/details', [RiskManagementController::class, 'update'])->name('update');
                Route::delete('/{id}', [RiskManagementController::class, 'destroy'])->name('destroy');

                Route::post('/export', [RiskManagementController::class, 'ajaxExport'])->name('export');
                Route::Post('/import-data', [RiskManagementController::class, 'importData'])->name('importData');
                Route::get('/export-pdf', [RiskManagementController::class, 'exportDataPdf'])->name('exportDataPdf');

                Route::get('/index/statistics', [RiskStatisticsController::class, 'index'])->name('statistics.risk');

                Route::post('/risk-appetite-statement', [RiskManagementController::class, 'saveRiskAppetiteStatement'])
                    ->name('risk_appetite_statement.save');
                Route::post('/treatment-request/start', [RiskManagementController::class, 'startTreatmentRequest'])
                    ->name('treatment_request.start');
                Route::post('/treatment-request/act', [RiskManagementController::class, 'actOnTreatmentRequest'])
                    ->name('treatment_request.act');
                Route::post('/redo-assessment/start', [RiskManagementController::class, 'startRedoAssessment'])
                    ->name('redo_assessment.start');
                Route::post('/redo-assessment/act', [RiskManagementController::class, 'actOnRedoAssessment'])
                    ->name('redo_assessment.act');
                Route::get('/search-assets', [RiskManagementController::class, 'searchAssets'])
                    ->name('search_assets');
                Route::get('/search-missing-risk-assets', [RiskManagementController::class, 'searchMissingRiskAssets'])
                    ->name('search_missing_risk_assets');
            }
        );
    }
);
