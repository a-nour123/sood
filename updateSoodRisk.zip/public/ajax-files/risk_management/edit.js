$('.multiple-select2').select2();

// Preventing submit forms
// $('form:not(#download-file-form):not(#delete-file-form)').on('submit', function (e) {
//   e.preventDefault();
// });

// function to show error validation 
function showError(data) {
  $('.error').empty();
  $.each(data, function (key, value) {
    $('.error-' + key).empty();
    $('.error-' + key).append(value);
  });
}

// status [warning, success, error]
function makeAlert($status, message, title) {
  // On load Toast
  if (title == 'Success')
    title = '👋' + title;
  toastr[$status](message, title,
    {
      closeButton: true,
      tapToDismiss: false,
    }
  );
}

// Collapse comment start
$('#show-comments-btn').on('click', function () {
  if (!$('#collapseComments').hasClass('show') && $('#add-comment-btn').hasClass('btn-danger')) {
    $('#add-comment').css('display', 'none');
    if ($('#add-comment-btn').hasClass('btn-success')) {
      $('#add-comment-btn').removeClass('btn-success');
      $('#add-comment-btn').addClass('btn-danger');
      $('#add-comment-btn').html($('#x-icon svg').clone(true));
    } else {
      $('#add-comment-btn').addClass('btn-success');
      $('#add-comment-btn').removeClass('btn-danger');
      $('#add-comment-btn').html($('#plus-icon svg').clone(true));
    }
  }
});
$('#add-comment-btn').on('click', function () {
  if ($(this).hasClass('btn-success')) {
    $('#add-comment').slideDown();
    // 1. collapse showed
    if ($('#collapseComments').hasClass('show')) { }
    // 2. collapse is not showed
    else {
      // $('#collapseComments').addClass('show');
      $('#show-comments-btn').trigger('click');
    }
    $(this).removeClass('btn-success');
    $(this).addClass('btn-danger');
    $(this).html($('#x-icon svg').clone(true));
  } else {
    $(this).addClass('btn-success');
    $(this).removeClass('btn-danger');
    // $('#add-comment').fadeIn('d-none');
    $('#add-comment').slideUp();
    $(this).html($('#plus-icon svg').clone(true));
  }
});
// Collapse comment end

// Show edit subject start
$('#edit-subject').on('click', function () {
  $('#static-subject').addClass('d-none');
  $('#edit-subject-container input[name="subject"]').val($('#edit-subject-container input').data('value'));
  $('#edit-subject-container').removeClass('d-none');
});
// Show edit subject End

// Cancel edit subject start
$('#cancel-edit-subject').on('click', function () {
  $('#static-subject').removeClass('d-none');
  $('#edit-subject-container').addClass('d-none');
});
// Cancel edit subject End

// Subject edit start
$('#submit-edit-subject').on('click', function () {
  const id = $('#edit-subject-container input[name="id"]').val(),
    value = $('#edit-subject-container input[name="subject"]').val();

  let url = URLs['updateSubject'];
  $.ajax({
    url: url
    , type: "PUT"
    , data: $('#edit-subject-form').serialize()
    , success: function (data) {
      if (data.status) {
        makeAlert(data.alert ? 'warning' : 'success', data.alert ? `${data.alert}<br>${data.message}` : `${data.message}`, lang['success']);
        $('#edit-subject-container input').data('value', data.data['subject']); // Update risk subject data value
        $('#subject-text').text(data.data['subject']);  // Update risk subject text
        $('#static-subject').removeClass('d-none');
        $('#edit-subject-container').addClass('d-none');
        if (data.reload)
          location.reload();
      } else {
        showError(data['errors']);
      }
    }
    , error: function (response, data) {
      responseData = response.responseJSON;
      makeAlert('error', responseData.message, lang['error']);
      showError(responseData.errors);
    }
  });
});
// Subject edit End

// Add comment start
$(document).on('click', '.js-submit-comment', function () {
  let url = URLs['addComment'];
  let form = $(this).closest('form');
  $.ajax({
    url: url
    , type: "PUT"
    , data: form.serialize()
    , success: function (data) {
      if (data.status) {
        form.trigger("reset");
        makeAlert('success', data.message, lang['success']);
        // Add new comment text
        $("#all-comments").prepend(`
        <p class="card-text mt-1">
            ${data.data.content}
        </p>
        <hr>
        `);
        if (data.reload)
          location.reload();
      } else {
        showError(data['errors']);
      }
    }
    , error: function (response, data) {
      responseData = response.responseJSON;
      makeAlert('error', responseData.message, lang['error']);
      showError(responseData.errors);
    }
  });
});
// Add comment End

// dataPickr custom for compliance
dateTimePickr = $('.flatpickr-date-time-compliance');
// Date & TIme
if (dateTimePickr.length) {
  dateTimePickr.flatpickr({
    enableTime: false,
    // dateFormat: "Y-m-d",
    dateFormat: dataFormat,
  });
}

$('#RiskScoringDetailsBtn').on('click', function () {
  if ($(this).data('showstatus')) {
    $(this).data('showstatus', 0);
    $(this).text($(this).data('showtext'));
  }
  else {
    $(this).data('showstatus', 1);
    $(this).text($(this).data('hidetext'));
  }
});

var riskHistoryChart = null;
var riskHistoryRequested = false;

$('#collapseOne').on('shown.bs.collapse', function () {
  if (riskHistoryChart) {
    riskHistoryChart.reflow();
    return;
  }
  if (riskHistoryRequested) {
    return;
  }
  riskHistoryRequested = true;
  loadRiskScoringHistory();
});

$('#impact-detail-btn').on('click', function () {
  $('#impact-detail').slideToggle();
  $('#likelihood-detail').css('display', 'none');
});

$('#likelihood-detail-btn').on('click', function () {
  $('#likelihood-detail').slideToggle();
  $('#impact-detail').css('display', 'none');
});

$('#UpdateClassicScoreShowBtn').on('click', function () {
  $(this).fadeOut();
  $('#edit-risk-scoring-form').slideDown();
  $('#edit-risk-scoring-form').prev().slideUp();
});

$('#cancel-edit-risk-scoring').on('click', function () {
  $('#UpdateClassicScoreShowBtn').fadeIn();
  $('#edit-risk-scoring-form').slideUp();
  $('#edit-risk-scoring-form').prev().slideDown();
});

// RiskScoring edit start
$('#update-edit-risk-scoring').on('click', function () {
  let url = URLs['updateRiskScoring'];
  $.ajax({
    url: url
    , type: "PUT"
    , data: $('#edit-risk-scoring-form').serialize()
    , success: function (data) {
      if (data.status) {
        makeAlert('success', `${data.message}`, lang['success']);
        if (data.reload)
          location.reload();
      } else {
        showError(data['errors']);
      }
    }
    , error: function (response, data) {
      responseData = response.responseJSON;
      makeAlert('error', responseData.message, lang['error']);
      showError(responseData.errors);
    }
  });
});
// RiskScoring edit End

/**
* Risk scoring history: summary tiles + inherent/residual step chart
*/
function loadRiskScoringHistory() {
  var container = $('#RiskScoreOverTime');
  container.html(`<div class="text-center py-5"><div class="spinner-border text-primary" role="status"></div></div>`);

  $.when(
    $.getJSON(URLs['getRiskLevels']),
    $.getJSON(URLs['getScoringHistories']),
    $.getJSON(URLs['residualScoringHistory'])
  ).done(function (levelsRes, inherentRes, residualRes) {
    var levels = ((levelsRes[0].data || {}).risk_levels || []).slice();
    var inherent = riskHistoryPoints(inherentRes[0].data, 'calculated_risk');
    var residual = riskHistoryPoints(residualRes[0].data, 'residual_risk');
    renderRiskScoringHistory(levels, inherent, residual);
  }).fail(function (xhr) {
    riskHistoryRequested = false;
    container.html('');
    var message = (xhr.responseJSON && xhr.responseJSON.message) ? xhr.responseJSON.message : lang['error'];
    makeAlert('error', message, lang['error']);
  });
}

function riskHistoryPoints(rows, key) {
  return (rows || [])
    .filter(function (row) {
      return row && row.last_update && row[key] !== undefined && row[key] !== null && !isNaN(Number(row[key]));
    })
    .map(function (row) {
      var time = moment(row.last_update, 'YYYY-MM-DD HH:mm:ss').valueOf();
      return [time, Number(row[key])];
    })
    .filter(function (point) {
      return !isNaN(point[0]);
    })
    .sort(function (a, b) {
      return a[0] - b[0];
    });
}

function riskHistoryLevelFor(levels, score) {
  var match = null;
  levels.forEach(function (level) {
    if (score >= Number(level.value)) {
      match = level;
    }
  });
  return match || levels[0] || null;
}

function riskHistoryLevelBadge(level) {
  if (!level) {
    return '';
  }
  var name = level.display_name || level.name;
  return `<span class="badge rounded-pill" style="background:${level.color}; color:#fff;">${name}</span>`;
}

function riskHistoryFormatScore(value) {
  return Number.isInteger(value) ? String(value) : Number(value).toFixed(1);
}

function riskHistoryCountChanges(points) {
  var changes = 0;
  for (var i = 1; i < points.length; i++) {
    if (points[i][1] !== points[i - 1][1]) {
      changes++;
    }
  }
  return changes;
}

function buildRiskHistoryTimeline(inherent, residual) {
  var valueAt = function (points, time) {
    var value = null;
    points.forEach(function (point) {
      if (point[0] <= time) {
        value = point[1];
      }
    });
    return value;
  };

  var times = inherent.concat(residual).map(function (p) { return p[0]; });
  times = Array.from(new Set(times)).sort(function (a, b) { return a - b; });

  var rows = [];
  times.forEach(function (time) {
    var row = { time: time, inherent: valueAt(inherent, time), residual: valueAt(residual, time), isNow: false };
    var previous = rows[rows.length - 1];
    if (previous && previous.inherent === row.inherent && previous.residual === row.residual) {
      return;
    }
    rows.push(row);
  });

  // The server appends a "now" point to each series; show it as the final "Now" step.
  var lastTime = times[times.length - 1];
  var lastRow = rows[rows.length - 1];
  if (lastRow && lastTime > lastRow.time) {
    rows.push({ time: lastTime, inherent: lastRow.inherent, residual: lastRow.residual, isNow: true });
  }

  return rows;
}

function riskHistoryDelta(current, previous) {
  if (current === null || previous === null || current === previous) {
    return '<span class="text-muted">—</span>';
  }
  var diff = current - previous;
  var up = diff > 0;
  return `<span class="fw-bold ${up ? 'text-danger' : 'text-success'}">${up ? '\u25B2' : '\u25BC'} ${riskHistoryFormatScore(Math.abs(diff))}</span>`;
}

function renderRiskHistoryLog(rows, levels, labels, appetite) {
  var target = $('#RiskScoreHistoryLog');
  var changes = rows.filter(function (row) { return !row.isNow; });
  if (!changes.length) {
    target.html('');
    return;
  }

  var scoreCell = function (value) {
    if (value === null) {
      return '<span class="text-muted">—</span>';
    }
    var level = riskHistoryLevelFor(levels, value);
    return `<b class="me-50">${riskHistoryFormatScore(value)}</b>${riskHistoryLevelBadge(level)}`;
  };

  var body = '';
  for (var i = changes.length - 1; i >= 0; i--) {
    var row = changes[i];
    var previous = changes[i - 1] || null;
    var overAppetite = appetite !== null && row.residual !== null && row.residual > appetite;
    body += `<tr>
      <td class="text-muted">${i + 1}</td>
      <td class="text-nowrap">${moment(row.time).format('DD MMM YYYY')} <small class="text-muted">${moment(row.time).format('HH:mm')}</small></td>
      <td>${scoreCell(row.inherent)}</td>
      <td>${riskHistoryDelta(row.inherent, previous ? previous.inherent : null)}</td>
      <td>${scoreCell(row.residual)}${overAppetite ? ` <span class="badge badge-light-danger ms-25">${labels.aboveAppetite || 'Above appetite'}</span>` : ''}</td>
      <td>${riskHistoryDelta(row.residual, previous ? previous.residual : null)}</td>
    </tr>`;
  }

  target.html(`
    <div class="d-flex align-items-center justify-content-between mt-1 mb-50">
      <h6 class="mb-0 fw-bolder">${labels.changeLog || 'Change log'}</h6>
      <small class="text-muted">${changes.length}</small>
    </div>
    <div class="table-responsive border rounded" style="max-height: 260px; overflow-y: auto;">
      <table class="table table-sm table-hover mb-0 align-middle">
        <thead class="table-light" style="position: sticky; top: 0; z-index: 1;">
          <tr>
            <th>#</th>
            <th>${labels.date || 'Date'}</th>
            <th>${labels.inherent || 'Inherent Risk'}</th>
            <th>${labels.change || 'Change'}</th>
            <th>${labels.residual || 'Residual Risk'}</th>
            <th>${labels.change || 'Change'}</th>
          </tr>
        </thead>
        <tbody>${body}</tbody>
      </table>
    </div>`);
}

function renderRiskScoringHistory(levels, inherent, residual) {
  var config = typeof riskHistoryConfig !== 'undefined' ? riskHistoryConfig : { maxScore: 10, appetite: null, labels: {} };
  var labels = config.labels || {};
  var container = $('#RiskScoreOverTime');
  var appetite = (config.appetite !== null && config.appetite !== undefined) ? Number(config.appetite) : null;

  levels.sort(function (a, b) {
    return Number(a.value) - Number(b.value);
  });

  if (!inherent.length && !residual.length) {
    container.html('').addClass('d-none');
    $('#RiskScoreOverTimeEmpty').removeClass('d-none');
    return;
  }

  var rows = buildRiskHistoryTimeline(inherent, residual);
  var values = [];
  rows.forEach(function (row) {
    if (row.inherent !== null) values.push(row.inherent);
    if (row.residual !== null) values.push(row.residual);
  });
  var maxScore = Math.max(Number(config.maxScore) || 10, Math.max.apply(null, values));

  // Summary tiles
  var setTile = function (selector, points, extra) {
    if (!points.length) {
      $(selector).html('—');
      return;
    }
    var value = points[points.length - 1][1];
    var level = riskHistoryLevelFor(levels, value);
    $(selector).html(`${riskHistoryFormatScore(value)} <div class="mt-25">${riskHistoryLevelBadge(level)}</div>${extra || ''}`);
  };
  setTile('#history-current-inherent', inherent);

  var reduction = '';
  if (inherent.length && residual.length) {
    var currentInherent = inherent[inherent.length - 1][1];
    var currentResidual = residual[residual.length - 1][1];
    if (currentInherent > 0 && currentResidual < currentInherent) {
      var percent = Math.round((1 - currentResidual / currentInherent) * 100);
      reduction = `<small class="d-block text-success fw-normal mt-25">\u25BC ${percent}% ${labels.reduction || 'reduction'}</small>`;
    }
  }
  setTile('#history-current-residual', residual, reduction);

  var changeRows = rows.filter(function (row) { return !row.isNow; });
  $('#history-changes').text(Math.max(changeRows.length - 1, 0));
  if (changeRows.length) {
    $('#history-first').text(moment(changeRows[0].time).format('DD MMM YYYY'));
    $('#history-last').text((labels.lastUpdate || 'Last change') + ': ' + moment(changeRows[changeRows.length - 1].time).format('DD MMM YYYY HH:mm'));
  }

  // Risk level bands
  var plotBands = levels.map(function (level, index) {
    var next = levels[index + 1];
    return {
      from: Number(level.value),
      to: next ? Number(next.value) : maxScore,
      color: Highcharts.color(level.color).setOpacity(0.10).get(),
      label: {
        text: level.display_name || level.name,
        align: 'left',
        x: 6,
        y: 12,
        style: { color: level.color, fontSize: '10px', fontWeight: '700', textTransform: 'uppercase' }
      }
    };
  }).filter(function (band) {
    return band.to > band.from;
  });

  var plotLines = [];
  if (appetite !== null && appetite < maxScore) {
    plotLines.push({
      value: appetite,
      color: '#ea5455',
      dashStyle: 'Dash',
      width: 2,
      zIndex: 5,
      label: {
        text: (labels.appetite || 'Risk appetite limit') + ': ' + riskHistoryFormatScore(appetite),
        align: 'right',
        x: -6,
        y: -6,
        style: { color: '#ea5455', fontSize: '11px', fontWeight: '700' }
      }
    });
  }

  var categories = rows.map(function (row) {
    return row.isNow ? (labels.now || 'Now') : moment(row.time).format('DD MMM, HH:mm');
  });
  var showDataLabels = rows.length <= 14;
  var residualZones = appetite !== null
    ? [{ value: appetite + 0.0001, color: '#00a5a8' }, { color: '#ea5455' }]
    : [];

  Highcharts.setOptions({ time: { useUTC: false } });

  container.html('');
  riskHistoryChart = Highcharts.chart('RiskScoreOverTime', {
    chart: {
      height: 360,
      backgroundColor: 'transparent',
      style: { fontFamily: 'inherit' },
      spacing: [16, 16, 10, 4]
    },
    title: { text: null },
    credits: { enabled: false },
    xAxis: {
      categories: categories,
      tickmarkPlacement: 'on',
      crosshair: { color: 'rgba(68, 34, 92, 0.08)' },
      labels: {
        rotation: rows.length > 8 ? -35 : 0,
        style: { color: '#6e6b7b', fontSize: '11px' }
      },
      lineColor: '#ebe9f1',
      tickColor: '#ebe9f1'
    },
    yAxis: {
      min: 0,
      max: maxScore,
      tickInterval: maxScore > 10 ? 5 : 1,
      endOnTick: false,
      title: { text: labels.score || 'Score', style: { color: '#6e6b7b' } },
      labels: { style: { color: '#6e6b7b' } },
      gridLineDashStyle: 'Dot',
      gridLineColor: '#e6e6e6',
      plotBands: plotBands,
      plotLines: plotLines
    },
    legend: {
      align: 'center',
      verticalAlign: 'top',
      itemStyle: { fontWeight: '600', color: '#5e5873' },
      symbolRadius: 6
    },
    tooltip: {
      shared: true,
      useHTML: true,
      outside: true,
      backgroundColor: '#fff',
      borderColor: '#ebe9f1',
      borderRadius: 8,
      shadow: true,
      formatter: function () {
        var row = rows[this.points[0].point.index];
        var title = row.isNow
          ? (labels.now || 'Now')
          : moment(row.time).format('DD MMM YYYY, HH:mm');
        var html = `<div class="fw-bold mb-50">${title}</div>`;
        this.points.forEach(function (point) {
          var level = riskHistoryLevelFor(levels, point.y);
          html += `<div class="d-flex align-items-center gap-50 mb-25">
            <span style="color:${point.series.color}">\u25CF</span>
            <span>${point.series.name}:</span>
            <b>${riskHistoryFormatScore(point.y)}</b>
            ${riskHistoryLevelBadge(level)}
          </div>`;
        });
        if (appetite !== null && row.residual !== null) {
          var within = row.residual <= appetite;
          html += `<div class="mt-50 small fw-bold ${within ? 'text-success' : 'text-danger'}">
            ${within ? (labels.withinAppetite || 'Within appetite') : (labels.aboveAppetite || 'Above appetite')}
          </div>`;
        }
        return html;
      }
    },
    plotOptions: {
      series: {
        connectNulls: true,
        marker: { enabled: true, radius: 5, symbol: 'circle', lineWidth: 2, lineColor: '#fff' },
        states: { hover: { lineWidthPlus: 1 } },
        dataLabels: {
          enabled: showDataLabels,
          formatter: function () {
            return riskHistoryFormatScore(this.y);
          },
          style: { fontSize: '10px', fontWeight: '700', textOutline: '2px #fff' }
        }
      }
    },
    series: [
      {
        type: 'line',
        name: labels.inherent || 'Inherent Risk',
        color: '#44225c',
        lineWidth: 2,
        dashStyle: 'ShortDash',
        data: rows.map(function (row) { return row.inherent; }),
        dataLabels: { y: -6, color: '#44225c' },
        zIndex: 3
      },
      {
        type: 'area',
        name: labels.residual || 'Residual Risk',
        color: '#00a5a8',
        lineWidth: 3,
        zones: residualZones,
        fillColor: {
          linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
          stops: [[0, 'rgba(0, 165, 168, 0.28)'], [1, 'rgba(0, 165, 168, 0.02)']]
        },
        data: rows.map(function (row) { return row.residual; }),
        dataLabels: { y: 18, color: '#00807f' },
        zIndex: 4
      }
    ]
  });

  renderRiskHistoryLog(rows, levels, labels, appetite);
}

// Load controls of framework
$("[name='framework_id']").on('change', function () {
  const frameworkControls = $(this).find('option:selected').data('controls');
  $("[name='control_id']").find('option:not(:first)').remove();
  $("[name='control_id']").find('option:first').attr('selected', true)
  if (frameworkControls)
    frameworkControls.forEach(frameworkControl => {
      $("[name='control_id']").append(`<option value="${frameworkControl.id}">${frameworkControl.short_name}</option>`);
    });
});

// Show edit detail start
$('#edit-details').on('click', function () {
  $('#static-details').addClass('d-none');
  $('#edit-details-form').removeClass('d-none');
});
// Show edit detail End

// Cancel edit details start
$('#cancel-edit-details').on('click', function () {
  $('#static-details').removeClass('d-none');
});
// Cancel edit details End

// Detail edit start
$('#submit-edit-details').on('click', function () {

  var formData = new FormData(document.querySelector('#edit-details-form'));
  formData.set('owner_id', $('#owner_id').val() || '');
  formData.set('owner_manager_id', $('#owner_manager_id').val() || '');
  var additionalNotes = quill.root.innerHTML;
  formData.append('additional_notes', additionalNotes);
  let url = URLs['updateDetails'];
  $.ajax({
    url: url
    , type: "POST"
    , data: formData
    , contentType: false
    , processData: false
    , success: function (data) {
      if (data.status) {
        makeAlert(data.alert ? 'warning' : 'success', data.alert ? `${data.alert}<br>${data.message}` : `${data.message}`, lang['success']);
        if (data.reload)
          location.reload();
      } else {
        showError(data['errors']);
      }
    }
    , error: function (response, data) {
      responseData = response.responseJSON;
      makeAlert('error', responseData.message, lang['error']);
      showError(responseData.errors);
    }
  });

});
// Detail edit End

// Detail edit start
$('#submit-edit-details2').on('click', function () {

  var formData = new FormData(document.querySelector('#edit-details-form2'));
  var additionalNotes = quill.root.innerHTML;
  formData.append('additional_notes', additionalNotes);
    var description = quillDescription.root.innerHTML;
  formData.append('risk_description', description);
  let url = URLs['updateDetails'];
  $.ajax({
    url: url
    , type: "POST"
    , data: formData
    , contentType: false
    , processData: false
    , success: function (data) {
      if (data.status) {
        makeAlert(data.alert ? 'warning' : 'success', data.alert ? `${data.alert}<br>${data.message}` : `${data.message}`, lang['success']);
        if (data.reload)
          location.reload();
      } else {
        showError(data['errors']);
      }
    }
    , error: function (response, data) {
      responseData = response.responseJSON;
      makeAlert('error', responseData.message, lang['error']);
      showError(responseData.errors);
    }
  });

});
// Detail edit End
// Download supporting documentation start
$('.supporting_documentation').on('click', function () {
  const form = $('#download-file-form');
  form.find('[name="id"').val($(this).data('id'));
  form.find('[name="risk_id"').val($(this).data('riskId'));

  form.trigger('submit');
});
// Download supporting documentation End

// Delete supporting documentation start
$('.delete_supporting_documentation').on('click', function () {
  showModalDeleteRisk($(this).data('id'), $(this).data('riskId'), this);
});

// Delete supporting documentation End

// Show delete alert modal Start
function showModalDeleteRisk(id, riskId, that) {
  Swal.fire({
    title: lang['confirmDeleteFileMessage']
    , text: lang['revert']
    , icon: 'question'
    , showCancelButton: true
    , confirmButtonText: lang['confirmDelete']
    , cancelButtonText: lang['cancel']
    , customClass: {
      confirmButton: 'btn btn-relief-success ms-1'
      , cancelButton: 'btn btn-outline-danger ms-1'
    }
    , buttonsStyling: false
  }).then(function (result) {
    if (result.value) {
      DeleteFile(id, riskId, that)
    }
  });
}
// Show delete alert modal End

// Delete supporting documentation start
function DeleteFile(id, riskId, that) {
  let url = URLs['deleteFile'];
  $.ajax({
    url: url
    , type: "DELETE"
    , data: {
      id: id,
      risk_id: riskId,
      mitigation: $(that).parent().hasClass('mitigation-files') ? 1 : 0
    }
    , headers: {
      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
    , success: function (response) {
      if (response.status) {
        makeAlert('success', response.message, lang['success']);
        $(that).parent().remove();
        appendLog(response.data.log);
      }
    }
    , error: function (response, data) {
      responseData = response.responseJSON;
      makeAlert('error', responseData.message, lang['error']);
    }
  });
}

// Delete supporting documentation End

// Append Log Start
function appendLog($log) {
  $('#collapseAuditTrail').prepend(`<p class="card-text mt-1">${$log}</p>`);
}
// Append Log End

// Accept or reject mitigation start
$('.acceptOrRejectStatus').on('click', function () {

  const data = {
    risk_id: $(this).data('id'),
    accept: $(this).data('value')
  };

  let url = URLs['acceptRejectMitigation'];
  $.ajax({
    url: url
    , type: "POST"
    , data: data
    , headers: {
      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
    , success: function (data) {
      if (data.status) {
        makeAlert(data.alert ? 'warning' : 'success', data.alert ? `${data.alert}<br>${data.message}` : `${data.message}`, lang['success']);
        if (data.reload)
          location.reload();
      } else {
        showError(data['errors']);
      }
    }
    , error: function (response, data) {
      responseData = response.responseJSON;
      makeAlert('error', responseData.message, lang['error']);
      showError(responseData.errors);
    }
  });

});
// Accept or reject mitigation End

 


// Mitigation edit start
$('#submit-edit-mitigation').on('click', function () {

  var formData = new FormData(document.querySelector('#edit-mitigation-form'));
  var currentSolution = quillriskSolution1.root.innerHTML;
  formData.append('current_solution', currentSolution);

  let url = URLs['updateRiskMitigation'];
  $.ajax({
    url: url
    , type: "POST"
    , data: formData
    , contentType: false
    , processData: false
    , success: function (data) {
      if (data.status) {
        makeAlert(data.alert ? 'warning' : 'success', data.alert ? `${data.alert}<br>${data.message}` : `${data.message}`, lang['success']);
        if (data.reload)
          location.reload();
      } else {
        showError(data['errors']);
      }
    }
    , error: function (response, data) {
      responseData = response.responseJSON;
      makeAlert('error', responseData.message, lang['error']);
      showError(responseData.errors);
    }
  });

});

// Mitigation edit End

// View all reviews start
$('#review-history-btn').on('click', function () {
  $(this).parents('.review-btn').hide();
  $('#last-review-btn').parents('.review-btn').show();
  $('#last-review').hide();
  $('#review-history').show();
});

// View all reviews End

// View last review start
$('#last-review-btn').on('click', function () {
  $(this).parents('.review-btn').hide();
  $('#review-history-btn').parents('.review-btn').show();
  $('#last-review').show();
  $('#review-history').hide();
});

// View last review End

// Start working on risk action
$('#risk-actions').on('change', function () {
  resetActions();

  if (["CloseRisk", "ChangeStatus", "ResetMitigations", "ResetReviews"].includes($(this).val())) {
    // $('.main-containers').addClass('d-none');




    // Start handle CloseRisk action
    if ($(this).val() == "CloseRisk") {
      // $('#change-risk-status-container').addClass('d-none');
      // $('#reset-risk-mitigations-container').addClass('d-none');
      // $('#reset-risk-reviews-container').addClass('d-none');

      $('#closeRiskModal').modal('show');

    }
    // End handle CloseRisk action

    // Start handle ChangeStatus action
    if ($(this).val() == "ChangeStatus") {
      // $('#close-risk-container').addClass('d-none');
      // $('#reset-risk-mitigations-container').addClass('d-none');
      // $('#reset-risk-reviews-container').addClass('d-none');

      $('#changeRiskStatusModal').modal('show'); // Open the modal
    }
    // End handle ChangeStatus action

    // Start handle ResetMitigations action
    if ($(this).val() == "ResetMitigations") {
      confirmResetRiskMitigations($(this).data('id'));
    }
    // End handle ResetMitigations action

    // Start handle ResetReviews action
    if ($(this).val() == "ResetReviews") {
      $('#reset-risk-reviews-container').removeClass('d-none');
    }
    // End handle ResetReviews action


  } else {

    $('.main-containers').removeClass('d-none');
    $('#close-risk-container').addClass('d-none');



    // Start handle ReopenRisk action
    if ($(this).val() == "ReopenRisk") {
      const data = {
        id: $(this).data('id'),
        _method: 'put'
      }

      let url = URLs['riskReopen'];
      $.ajax({
        url: url
        , type: "POST"
        , data: data
        , headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
        , success: function (data) {
          if (data.status) {
            makeAlert(data.alert ? 'warning' : 'success', data.alert ? `${data.alert}<br>${data.message}` : `${data.message}`, lang['success']);
            if (data.reload)
              location.reload();
          } else {
            showError(data['errors']);
          }
        }
        , error: function (response, data) {
          responseData = response.responseJSON;
          makeAlert('error', responseData.message, lang['error']);
          showError(responseData.errors);
        }
      });

    }
    // End handle ReopenRisk action

    // Start handle EditRisk action
    if ($(this).val() == "EditRisk") {
      $('#editRiskModal').modal('show');

    }
    if ($(this).val() == "EditRisk2") {
      $('#editRiskModal2').modal('show');

    }
    // End handle EditRisk action

    // Start handle PlanAMitigation action
    if ($(this).val() == "PlanAMitigation") {

      // Active tab link and tab container
      // activeTab('#mitigation-tab', '#mitigation');

      // Show edit mitigation
      $('#edit-mitigation').trigger('click');

    }
    // End handle PlanAMitigation action

    // Start handle PerformAReview action
    if ($(this).val() == "PerformAReview") {
      $('#addReviewModal').modal('show'); // Open the modal
    }
    // End handle PerformAReview action

    // Start handle AddAComment action
    if ($(this).val() == "AddAComment") {
      // Show add comment form (trigger the click for the "Add Comment" button)
      $('#add-comment-btn').trigger('click');

      // Open the modal
      $('#addCommentModal').modal('show'); // Show the modal
    }
    // End handle AddAComment action


    // Start handle PrintableView action
    if ($(this).val() == "PrintableView") {
      // TODO PrintableView: action
    }
    // End handle PrintableView action
  }

  // Reset to the placeholder so choosing the same action again fires "change"
  $(this).val('');
});

function activeTab(tabLinkReference, tabContainerReference) {
  // Remove al active from all nav-link classes
  $('.nav-tabs .nav-item .nav-link').removeClass('active');
  // Add active only for mitigation nav-link (tabLinkReference)
  $(`.nav-tabs .nav-item ${tabLinkReference}`).addClass('active');

  // Remove al active from all tab-pane classes
  $('.tab-pane').removeClass('active');
  // Add active only for mitigation tab-pane (tabContainerReference)
  $(`${tabContainerReference}`).addClass('active');
}

// Reset tab content for view static container and hide editable form
$('.nav-link').on('click', function () {
  containers = $(`${$(this).attr('href')} > .row`);
  containers.eq(0).removeClass('d-none');
  containers.eq(1).addClass('d-none');
});

function resetActions() {
  $('#add-comment-btn.btn-danger').trigger('click');
}

// Cancel add review start
$('#cancel-add-review').on('click', function () {
  $('#static-review').removeClass('d-none');
  $('#add-review-form').addClass('d-none');
});

// Add review start
$('#submit-add-review').on('click', function () {

  var formData = new FormData(document.querySelector('#add-review-form'));


  let url = URLs['addRiskReview'];
  $.ajax({
    url: url
    , type: "POST"
    , data: formData
    , contentType: false
    , processData: false
    , success: function (data) {
      if (data.status) {
        makeAlert(data.alert ? 'warning' : 'success', data.alert ? `${data.alert}<br>${data.message}` : `${data.message}`, lang['success']);
        if (data.reload)
          location.reload();
      } else {
        showError(data['errors']);
      }
    }
    , error: function (response, data) {
      responseData = response.responseJSON;
      makeAlert('error', responseData.message, lang['error']);
      showError(responseData.errors);
    }
  });

});
// Add review End

// Work on next step status Start
$('[name="next_step"]').on('change', function () {
  if ($(this).val() == 2) {
    $('#project-container').removeClass('d-none');
  } else {
    $('#project-container').addClass('d-none');
  }
});
// work on next step status End

// Close reason start
$('#submit-close-reason').on('click', function () {

  var formData = new FormData(document.querySelector('#close-reason-form'));


  let url = URLs['riskCloseReason'];
  $.ajax({
    url: url
    , type: "POST"
    , data: formData
    , contentType: false
    , processData: false
    , success: function (data) {
      if (data.status) {
        makeAlert(data.alert ? 'warning' : 'success', data.alert ? `${data.alert}<br>${data.message}` : `${data.message}`, lang['success']);
        if (data.reload)
          location.reload();
      } else {
        showError(data['errors']);
      }
    }
    , error: function (response, data) {
      responseData = response.responseJSON;
      makeAlert('error', responseData.message, lang['error']);
      showError(responseData.errors);
    }
  });

});
// Close reason End
// Close reason start
$('#submit-close-reason2').on('click', function () {

  var formData = new FormData(document.querySelector('#close-reason-form2'));


  let url = URLs['riskCloseReason'];
  $.ajax({
    url: url
    , type: "POST"
    , data: formData
    , contentType: false
    , processData: false
    , success: function (data) {
      if (data.status) {
        makeAlert(data.alert ? 'warning' : 'success', data.alert ? `${data.alert}<br>${data.message}` : `${data.message}`, lang['success']);
        if (data.reload)
          location.reload();
      } else {
        showError(data['errors']);
      }
    }
    , error: function (response, data) {
      responseData = response.responseJSON;
      makeAlert('error', responseData.message, lang['error']);
      showError(responseData.errors);
    }
  });

});
// Close reason End

// change risk status start
$('#submit-change-risk-status').on('click', function () {

  var formData = new FormData(document.querySelector('#change-risk-status-form'));


  let url = URLs['riskChangeStatus'];
  $.ajax({
    url: url
    , type: "POST"
    , data: formData
    , contentType: false
    , processData: false
    , success: function (data) {
      if (data.status) {
        makeAlert(data.alert ? 'warning' : 'success', data.alert ? `${data.alert}<br>${data.message}` : `${data.message}`, lang['success']);
        if (data.reload)
          location.reload();
      } else {
        showError(data['errors']);
      }
    }
    , error: function (response, data) {
      responseData = response.responseJSON;
      makeAlert('error', responseData.message, lang['error']);
      showError(responseData.errors);
    }
  });

});
// change risk status End

// Reset risk mitigations start
function confirmResetRiskMitigations(riskId) {
  Swal.fire({
    title: lang['resetMitigationsTitle'],
    text: lang['resetMitigationsText'],
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: lang['resetMitigationsConfirm'],
    cancelButtonText: lang['cancel'],
    customClass: {
      confirmButton: 'btn btn-danger ms-1',
      cancelButton: 'btn btn-outline-secondary ms-1'
    },
    buttonsStyling: false,
    showLoaderOnConfirm: true,
    allowOutsideClick: function () {
      return !Swal.isLoading();
    },
    preConfirm: function () {
      return resetRiskMitigations(riskId).then(function () { }, function () { });
    }
  });
}

function resetRiskMitigations(riskId) {
  let url = URLs['resetRiskMitigations'];
  const data = {
    id: riskId,
    _method: 'put'
  }

  return $.ajax({
    url: url
    , type: "POST"
    , data: data
    , headers: {
      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
    , success: function (data) {
      if (data.status) {
        makeAlert(data.alert ? 'warning' : 'success', data.alert ? `${data.alert}<br>${data.message}` : `${data.message}`, lang['success']);
        if (data.reload)
          location.reload();
      } else {
        showError(data['errors']);
      }
    }
    , error: function (response, data) {
      responseData = response.responseJSON;
      makeAlert('error', responseData.message, lang['error']);
      showError(responseData.errors);
    }
  });
}
// Reset risk mitigations End

// Reset risk reviews start
$('#submit-reset-risk-reviews').on('click', function () {

  let url = URLs['resetRiskReviews'];
  const data = {
    id: $(this).data('id'),
    _method: 'put'
  }

  $.ajax({
    url: url
    , type: "POST"
    , data: data
    , headers: {
      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
    , success: function (data) {
      if (data.status) {
        makeAlert(data.alert ? 'warning' : 'success', data.alert ? `${data.alert}<br>${data.message}` : `${data.message}`, lang['success']);
        if (data.reload)
          location.reload();
      } else {
        showError(data['errors']);
      }
    }
    , error: function (response, data) {
      responseData = response.responseJSON;
      makeAlert('error', responseData.message, lang['error']);
      showError(responseData.errors);
    }
  });

});
// Reset risk reviews End

var quill = new Quill('#risk_addational_notes', {
  theme: 'snow',
  modules: {
    toolbar: [
      [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
      ['bold', 'italic', 'underline', 'strike'],
      [{ 'list': 'ordered' }, { 'list': 'bullet' }],
      [{ 'indent': '-1' }, { 'indent': '+1' }],
      [{ 'direction': 'rtl' }], // Right-to-left direction
      ['clean'],
    ],
  },
});
var quillDescription = new Quill('#risk_description', {
  theme: 'snow',
  modules: {
    toolbar: [
      [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
      ['bold', 'italic', 'underline', 'strike'],
      [{ 'list': 'ordered' }, { 'list': 'bullet' }],
      [{ 'indent': '-1' }, { 'indent': '+1' }],
      [{ 'direction': 'rtl' }], // Right-to-left direction
      ['clean'],
    ],
  },
});
var readOnlyQuillOptions = {
  theme: 'snow',
  modules: {
    toolbar: [
      [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
      ['bold', 'italic', 'underline', 'strike'],
      [{ 'list': 'ordered' }, { 'list': 'bullet' }],
      [{ 'indent': '-1' }, { 'indent': '+1' }],
      [{ 'direction': 'rtl' }], // Right-to-left direction
      ['clean'],
    ],
  },
  readOnly: true
};
var quillriskAddationalNotes = document.getElementById('risk_addational_notes_show')
  ? new Quill('#risk_addational_notes_show', readOnlyQuillOptions)
  : null;
var quillriskAddationalDescription = document.getElementById('risk_description_editor')
  ? new Quill('#risk_description_editor', readOnlyQuillOptions)
  : null;

var quillriskSolution1 = new Quill('#risk_current_solution', {
  theme: 'snow',
  modules: {
    toolbar: [
      [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
      ['bold', 'italic', 'underline', 'strike'],
      [{ 'list': 'ordered' }, { 'list': 'bullet' }],
      [{ 'indent': '-1' }, { 'indent': '+1' }],
      [{ 'direction': 'rtl' }], // Right-to-left direction
      ['clean'],
    ],
  },
});
var quillriskCurrentSolution = document.getElementById('risk_current_solution_show')
  ? new Quill('#risk_current_solution_show', {
    theme: 'snow',
    modules: {
      toolbar: [
        [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
        ['bold', 'italic', 'underline', 'strike'],
        [{ 'list': 'ordered' }, { 'list': 'bullet' }],
        [{ 'indent': '-1' }, { 'indent': '+1' }],
        [{ 'direction': 'rtl' }], // Right-to-left direction
        ['clean'],
      ],
    },
    readOnly: true
  })
  : null;

