<?php

namespace App\Exports\Concerns;

use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

trait AppliesExportReportHeader
{
    protected function getExportLogoPath(): string
    {
        return public_path('images/ksu-logo.png');
    }

    protected function getExportLogoHeight(): int
    {
        return 58;
    }

    protected function getExportTitleRowHeight(): int
    {
        return 88;
    }

    /**
     * Apply title row + optional spacer row.
     * Returns the first content row number after the header block.
     */
    protected function applyExportReportHeader(
        Worksheet $sheet,
        string $lastColumn,
        string $title,
        bool $isRTL,
        ?string $logoColumn = null,
        bool $withSpacer = true
    ): int {
        $this->applyExportTitleRow($sheet, 1, $lastColumn, $title, $isRTL, $logoColumn);
        $this->applyExportTitleBorders($sheet, 1, $lastColumn);

        if ($withSpacer) {
            $this->applyExportHeaderSpacerRow($sheet, 2, $lastColumn);
            $this->clearExportHeaderBorders($sheet, 2, 2, $lastColumn);

            return 3;
        }

        return 2;
    }

    /**
     * Single merged title row + logo drawing (no split cells — avoids inner border line).
     */
    protected function applyExportTitleRow(
        Worksheet $sheet,
        int $row,
        string $lastColumn,
        string $title,
        bool $isRTL,
        ?string $logoColumn = null
    ): int {
        $titleRange = "A{$row}:{$lastColumn}{$row}";

        $sheet->mergeCells($titleRange);
        $sheet->setCellValue("A{$row}", $title);
        $this->applyTitleTextStyle($sheet, $titleRange);

        $sheet->getRowDimension($row)->setRowHeight($this->getExportTitleRowHeight());

        $this->placeExportLogo(
            $sheet,
            $row,
            $this->resolveLogoAnchorColumn($lastColumn, $isRTL, $logoColumn),
            $isRTL
        );

        return $row + 1;
    }

    /**
     * Re-apply title row styles after export-wide alignment passes (RTL safe).
     */
    protected function refreshExportTitleRowStyles(
        Worksheet $sheet,
        int $row,
        string $lastColumn,
        string $title,
        bool $isRTL,
        ?string $logoColumn = null
    ): void {
        $titleRange = "A{$row}:{$lastColumn}{$row}";

        $sheet->mergeCells($titleRange);
        $sheet->setCellValue("A{$row}", $title);
        $this->applyTitleTextStyle($sheet, $titleRange);

        $sheet->getRowDimension($row)->setRowHeight($this->getExportTitleRowHeight());
        $this->applyExportTitleBorders($sheet, $row, $lastColumn);
    }

    protected function applyTitleTextStyle(Worksheet $sheet, string $range): void
    {
        $sheet->getStyle($range)->applyFromArray([
            'font'      => [
                'bold'  => true,
                'size'  => 14,
                'color' => ['rgb' => '2F5496'],
                'name'  => 'Calibri',
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER,
                'vertical'   => Alignment::VERTICAL_CENTER,
                'wrapText'   => false,
            ],
        ]);
    }

    protected function resolveLogoAnchorColumn(
        string $lastColumn,
        bool $isRTL,
        ?string $logoColumn = null
    ): string {
        if ($isRTL) {
            return 'A';
        }

        return $logoColumn ?? $lastColumn;
    }

    protected function placeExportLogo(
        Worksheet $sheet,
        int $row,
        string $anchorCol,
        bool $isRTL
    ): void {
        $logoPath = $this->getExportLogoPath();

        if (!file_exists($logoPath)) {
            return;
        }

        $drawing = new Drawing();
        $drawing->setName('Logo');
        $drawing->setDescription('Logo');
        $drawing->setPath($logoPath);
        $drawing->setHeight($this->getExportLogoHeight());
        $drawing->setResizeProportional(true);
        $drawing->setCoordinates($anchorCol . $row);

        if ($isRTL) {
            $drawing->setOffsetX(18);
            $drawing->setOffsetY(4);
        } else {
            $drawing->setOffsetX(8);
            $drawing->setOffsetY(10);
        }

        $drawing->setWorksheet($sheet);
    }

    protected function applyExportTitleBorders(Worksheet $sheet, int $row, string $lastColumn): void
    {
        $sheet->getStyle("A{$row}:{$lastColumn}{$row}")->applyFromArray([
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'color'    => ['rgb' => 'E7E6E6'],
            ],
            'borders' => [
                'outline' => [
                    'borderStyle' => Border::BORDER_MEDIUM,
                    'color'       => ['rgb' => '000000'],
                ],
            ],
        ]);
    }

    protected function applyExportHeaderSpacerRow(Worksheet $sheet, int $row, string $lastColumn): int
    {
        $sheet->mergeCells("A{$row}:{$lastColumn}{$row}");
        $sheet->getRowDimension($row)->setRowHeight(20);

        return $row + 1;
    }

    protected function clearExportHeaderBorders(
        Worksheet $sheet,
        int $fromRow,
        int $toRow,
        string $lastColumn
    ): void {
        $sheet->getStyle("A{$fromRow}:{$lastColumn}{$toRow}")->applyFromArray([
            'borders' => [
                'left'   => ['borderStyle' => Border::BORDER_NONE],
                'right'  => ['borderStyle' => Border::BORDER_NONE],
                'top'    => ['borderStyle' => Border::BORDER_NONE],
                'bottom' => ['borderStyle' => Border::BORDER_NONE],
            ],
        ]);
    }

    protected function applyExportDescriptionRow(
        Worksheet $sheet,
        int $row,
        string $lastColumn,
        string $description
    ): int {
        $sheet->mergeCells("A{$row}:{$lastColumn}{$row}");
        $sheet->setCellValue("A{$row}", $description);
        $sheet->getStyle("A{$row}:{$lastColumn}{$row}")->applyFromArray([
            'font'      => [
                'size'   => 10,
                'italic' => true,
                'color'  => ['rgb' => '666666'],
                'name'   => 'Calibri',
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER,
                'vertical'   => Alignment::VERTICAL_CENTER,
            ],
        ]);
        $sheet->getRowDimension($row)->setRowHeight(25);

        return $row + 1;
    }
}
