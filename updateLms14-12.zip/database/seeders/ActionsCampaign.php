<?php

namespace Database\Seeders;

use App\Models\Action;
use Illuminate\Database\Seeder;

class ActionsCampaign extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Action::insert([
            ['id' => 160, 'name' => 'create_campaign'],
            ['id' => 161, 'name' => 'create_training'],
        ]);
    }
}
