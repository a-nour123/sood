@extends('admin/layouts/contentLayoutMaster')

@section('title', __('phishing.Groups'))

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/pickadate/pickadate.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/flatpickr/flatpickr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/dataTables.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/responsive.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/buttons.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/pickadate/pickadate.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/flatpickr/flatpickr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/animate/animate.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">

@endsection

@section('page-style')
    {{-- <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}"> --}}
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/base/plugins/forms/pickers/form-flat-pickr.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/forms/pickers/form-flat-pickr.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/forms/pickers/form-pickadate.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-sweet-alerts.css')) }}">
    <link rel="stylesheet" type="text/css" href="{{ asset(mix('vendors/css/forms/wizard/bs-stepper.min.css')) }}">
    <link rel="stylesheet" type="text/css" href="{{ asset(mix('css/base/plugins/forms/form-wizard.css')) }}">
@endsection
@section('content')

    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">

            <div class="row breadcrumbs-top  widget-grid">
                <div class="col-12">
                    <div class="page-title mt-2">
                        <div class="row">
                            <div class="col-sm-6 ps-0">
                                @if (@isset($breadcrumbs))
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}"
                                                style="display: flex;">
                                                <svg class="stroke-icon">
                                                    <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}">
                                                    </use>
                                                </svg></a></li>
                                        @foreach ($breadcrumbs as $breadcrumb)
                                            <li class="breadcrumb-item">
                                                @if (isset($breadcrumb['link']))
                                                    <a
                                                        href="{{ $breadcrumb['link'] == 'javascript:void(0)' ? $breadcrumb['link'] : url($breadcrumb['link']) }}">
                                                @endif
                                                {{ $breadcrumb['name'] }}
                                                @if (isset($breadcrumb['link']))
                                                    </a>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ol>
                                @endisset
                        </div>

                        @if(Route::currentRouteName() == 'admin.phishing.groups.getAll')
                            <div class="col-sm-6 pe-0" style="text-align: end;">
                                <div class="action-content">
                                    {{--  @if (auth()->user()->hasPermission('asset.create'))  --}}
                                        <button class=" btn btn-primary " type="button" data-bs-toggle="modal"
                                            data-bs-target="#add-new-group">
                                            <i class="fa fa-plus"></i>
                                        </button>
                                        {{-- <a href="{{ route('admin.asset_management.notificationsSettingsActiveAsset') }}"
                                            class=" btn btn-primary" target="_self">
                                            <i class="fa fa-regular fa-bell"></i>
                                        </a> --}}
                                        {{--  <a href="{{ route('admin.phishing.groups.getArchivedGroups') }}"
                                        class=" btn btn-primary" target="_self">
                                        <i class="fa  fa-trash"></i>
                                    </a>  --}}
                                    {{--  @endif  --}}
                                    {{--  <a class="btn btn-primary" href="http://"> <i class="fa fa-solid fa-gear"></i> </a>  --}}

                                    {{--  <x-export-import name=" {{ __('locale.Asset') }}" createPermissionKey='asset.create'
                                        exportPermissionKey='asset.export'
                                        exportRouteKey='admin.asset_management.ajax.export'
                                        importRouteKey='admin.asset_management.import' />

                                    <a class="btn btn-primary" href="http://"> <i class="fa-solid fa-file-invoice"></i></a>  --}}
                                </div>
                            </div>

                        @else
                            <div class="col-sm-6 pe-0" style="text-align: end;">
                                <div class="action-content">
                                    @if (auth()->user()->hasPermission('asset.create'))
                                        <a href="{{ route('admin.asset_management.notificationsSettingsActiveAsset') }}"
                                            class=" btn btn-primary" target="_self">
                                            <i class="fa fa-regular fa-bell"></i>
                                        </a>
                                    @endif
                                    <a class="btn btn-primary" href="http://"> <i class="fa fa-solid fa-gear"></i> </a>

                                    {{--  <x-export-import name=" {{ __('locale.Asset') }}" createPermissionKey='asset.create'
                                        exportPermissionKey='asset.export'
                                        exportRouteKey='admin.asset_management.ajax.export'
                                        importRouteKey='admin.asset_management.import' />

                                    <a class="btn btn-primary" href="http://"> <i class="fa-solid fa-file-invoice"></i></a>  --}}
                                </div>
                            </div>
                        @endif

                    </div>
                </div>
            </div>

        </div>
    </div>
    <div id="quill-service-content" class="d-none"></div>

</div>



<section id="advanced-search-datatable">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <hr class="my-0" />
                <div class="card-datatable table-responsive">
                    <table class="dt-advanced-server-search table">
                        <thead>
                            <tr>
                                <th>{{ __('locale.#') }}</th>
                                <th class="all">{{ __('locale.Name') }}</th>
                                <th class="all">{{ __('locale.Actions') }}</th>
                            </tr>
                        </thead>

                        <!-- <tfoot>
                            <tr>
                                <th>{{ __('locale.#') }}</th>
                                <th class="all">{{ __('locale.Name') }}</th>
                                <th class="all">{{ __('locale.Actions') }}</th>
                            </tr>
                        </tfoot> -->

                    </table>
                </div>
            </div>
        </div>
    </div>
</section>




<!-- Create Form -->
{{--  @if (auth()->user()->hasPermission('domains.create'))  --}}
<x-phishing-group-form id="add-new-group" title="{{ __('phishing.AddANewGroup') }}"/>
{{--  @endif  --}}
<!--/ Create Form -->

<!-- Update Form -->
{{--  @if (auth()->user()->hasPermission('asset.update'))  --}}
<x-phishing-group-form id="edit-regulator" title="{{ __('phishing.EditGroup') }}" />
{{--  @endif   --}}
<!--/ Update Form -->

<x-phishing-group-users-form id="add-users" title="{{ __('phishing.GroupUsers') }}" idValue="6"/>





@endsection

 @section('vendor-script')
<script src="{{ asset('js/scripts/components/components-dropdowns-font-awesome.js') }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/jquery.dataTables.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.bootstrap5.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.responsive.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/responsive.bootstrap5.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/pickers/flatpickr/flatpickr.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/buttons.print.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/pickers/pickadate/picker.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/pickers/pickadate/picker.date.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/pickers/pickadate/picker.time.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/pickers/pickadate/legacy.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>

<script>
    // ==============================================
    // DATATABLE INITIALIZATION
    // ==============================================
    var table = $('.dt-advanced-server-search').DataTable({
        lengthChange: true,
        processing: false,
        serverSide: true,
        ajax: {
            url: '{{ route('admin.phishing.groups.PhishingGroupeDatatable') }}'
        },
        language: {
            // your language settings
        },
        columns: [{
                name: "index",
                data: "DT_RowIndex",
                sortable: false,
                searchable: false,
                orderable: false
            },
            {
                name: "name",
                data: "name"
            },
            {
                name: "actions",
                data: "actions",
                searchable: false
            }
        ],
    });
</script>

<script>
$(document).ready(function() {
    
    // ==============================================
    // DEPARTMENT TOGGLE (Expand/Collapse)
    // ==============================================
    $(document).on("click", ".department-anchor", function(e) {
        e.preventDefault();
        let deptId = $(this).data("dept-id");
        let usersList = $("#users-dept-" + deptId);
        
        usersList.slideToggle(300);
    });

    // ==============================================
    // SELECT ALL IN DEPARTMENT
    // ==============================================
    $(document).on("change", ".select-all-dept", function() {
        let deptId = $(this).data("dept-id");
        let isChecked = $(this).is(":checked");
        
        $(".dept-" + deptId).prop("checked", isChecked);
        
        // Update global checkbox state
        let modal = $(this).closest('.modal');
        updateGlobalCheckbox(modal);
    });

    // ==============================================
    // GLOBAL SELECT ALL
    // ==============================================
    $(document).on("change", ".select-all-global", function() {
        let isChecked = $(this).is(":checked");
        let modal = $(this).closest('.modal');
        
        modal.find(".user-checkbox").prop("checked", isChecked);
        modal.find(".select-all-dept").prop("checked", isChecked);
    });

    // ==============================================
    // SEARCH FUNCTIONALITY
    // ==============================================
    $(document).on("input", ".user-search-input", function() {
        let searchTerm = $(this).val().toLowerCase().trim();
        let modal = $(this).closest('.modal');
        let treeContainer = modal.find('.tree');

        if (searchTerm === '') {
            // Reset view
            treeContainer.find('.department-item').show();
            treeContainer.find('.user-item').show();
            treeContainer.find('.users-list').hide();
        } else {
            treeContainer.find('.department-item').each(function() {
                let $deptItem = $(this);
                let deptName = $deptItem.data('dept-name') || '';
                let $usersList = $deptItem.find('.users-list');
                let hasVisibleUsers = false;

                // Check users
                $usersList.find('.user-item').each(function() {
                    let userName = $(this).data('user-name') || '';
                    if (userName.includes(searchTerm)) {
                        $(this).show();
                        hasVisibleUsers = true;
                    } else {
                        $(this).hide();
                    }
                });

                // Show/hide department
                if (deptName.includes(searchTerm) || hasVisibleUsers) {
                    $deptItem.show();
                    if (hasVisibleUsers) {
                        $usersList.show(); // Auto-expand when searching
                    }
                } else {
                    $deptItem.hide();
                }
            });
        }
    });

    // ==============================================
    // LOAD SELECTED USERS FOR GROUP (EDIT MODE)
    // ==============================================
    $(document).on('click', '.add-users', function() {
        let groupId = $(this).data('id');
        let modal = $('#add-users');
        let form = modal.find('form');
        
        // Set group ID
        form.find('.group-id-input').val(groupId);
        
        // Show loading
        modal.find('.users-loading').show();
        modal.find('.tree').hide();
        
        // Uncheck all checkboxes first
        form.find('.user-checkbox').prop('checked', false);
        form.find('.select-all-dept').prop('checked', false);
        form.find('.select-all-global').prop('checked', false);
        
        // Load selected users via AJAX
        $.ajax({
            url: "{{ route('admin.phishing.group.getUsersForGroup', ':id') }}".replace(':id', groupId),
            type: 'GET',
            success: function(response) {
                // Hide loading
                modal.find('.users-loading').hide();
                modal.find('.tree').show();
                
                // Check the selected users
                if (response.users && response.users.length > 0) {
                    response.users.forEach(function(userId) {
                        form.find('.user-checkbox[data-user-id="' + userId + '"]').prop('checked', true);
                    });
                    
                    // Update department checkboxes
                    updateDepartmentCheckboxes(modal);
                    updateGlobalCheckbox(modal);
                }
                
                // Show modal
                $('.dtr-bs-modal').modal('hide');
                modal.modal('show');
            },
            error: function(xhr) {
                // Hide loading
                modal.find('.users-loading').hide();
                modal.find('.tree').show();
                
                console.error('Failed to fetch users:', xhr.responseText);
                makeAlert('error', 'Failed to load users', "{{ __('locale.Error') }}");
                
                // Still show modal
                $('.dtr-bs-modal').modal('hide');
                modal.modal('show');
            }
        });
    });

    // ==============================================
    // UPDATE DEPARTMENT CHECKBOXES STATE
    // ==============================================
    function updateDepartmentCheckboxes(modal) {
        modal.find('.select-all-dept').each(function() {
            let deptId = $(this).data('dept-id');
            let deptCheckboxes = modal.find('.dept-' + deptId);
            let checkedCount = deptCheckboxes.filter(':checked').length;
            let totalCount = deptCheckboxes.length;
            
            if (checkedCount === totalCount && totalCount > 0) {
                $(this).prop('checked', true);
            } else {
                $(this).prop('checked', false);
            }
        });
    }

    // ==============================================
    // UPDATE GLOBAL CHECKBOX STATE
    // ==============================================
    function updateGlobalCheckbox(modal) {
        let totalUsers = modal.find('.user-checkbox').length;
        let checkedUsers = modal.find('.user-checkbox:checked').length;
        
        modal.find('.select-all-global').prop('checked', totalUsers === checkedUsers && totalUsers > 0);
    }

    // ==============================================
    // UPDATE CHECKBOXES ON USER CHECKBOX CHANGE
    // ==============================================
    $(document).on('change', '.user-checkbox', function() {
        let modal = $(this).closest('.modal');
        updateDepartmentCheckboxes(modal);
        updateGlobalCheckbox(modal);
    });

    // ==============================================
    // RESET FORM ON MODAL CLOSE
    // ==============================================
    $('.modal').on('hidden.bs.modal', function() {
        let form = $(this).find('form');
        resetFormData(form);
        form.find('.user-search-input').val('');
        form.find('.users-list').hide();
        form.find('.department-item').show();
        form.find('.user-item').show();
        form.find('.users-loading').hide();
        form.find('.tree').show();
    });

    // ==============================================
    // SUBMIT FORM - ADD NEW GROUP
    // ==============================================
    $('#add-new-group form').submit(function(e) {
        e.preventDefault();

        var formData = new FormData(this);

        $.ajax({
            url: $(this).attr('action'),
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function(data) {
                if (data.status) {
                    makeAlert('success', data.message, "{{ __('locale.Success') }}");
                    $('#add-new-group').modal('hide');
                    table.ajax.reload();
                } else {
                    showError(data['errors']);
                }
            },
            error: function(response, data) {
                var responseData = response.responseJSON;
                makeAlert('error', responseData.message, "{{ __('locale.Error') }}");
                showError(responseData.errors);
            }
        });
    });

    // ==============================================
    // SUBMIT FORM - ADD/UPDATE USERS TO GROUP
    // ==============================================
    $('#add-users form').submit(function(e) {
        e.preventDefault();
        
        var formData = new FormData(this);

        $.ajax({
            url: $(this).attr('action'),
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            beforeSend: function() {
                // Disable submit button
                $('#add-users').find('button[type="submit"]').prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Saving...');
            },
            success: function(data) {
                if (data.status) {
                    makeAlert('success', data.message, "{{ __('locale.Success') }}");
                    $('#add-users').modal('hide');
                    table.ajax.reload();
                } else {
                    showError(data['errors']);
                }
            },
            error: function(response, data) {
                var responseData = response.responseJSON;
                makeAlert('error', responseData.message, "{{ __('locale.Error') }}");
                showError(responseData.errors);
            },
            complete: function() {
                // Re-enable submit button
                $('#add-users').find('button[type="submit"]').prop('disabled', false).html("{{ __('locale.Submit') }}");
            }
        });
    });

    // ==============================================
    // SUBMIT FORM - EDIT GROUP
    // ==============================================
    $('#edit-regulator form').submit(function(e) {
        e.preventDefault();

        const id = $(this).find('input[name="id"]').val();
        let url = "{{ route('admin.phishing.group.update', ':id') }}";
        url = url.replace(':id', id);

        let formData = new FormData(this);

        $.ajax({
            url: url,
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function(data) {
                if (data.status) {
                    makeAlert('success', data.message, "{{ __('locale.Success') }}");
                    $('#edit-regulator').modal('hide');
                    table.ajax.reload();
                } else {
                    showError(data['errors']);
                }
            },
            error: function(response) {
                let responseData = response.responseJSON;
                makeAlert('error', responseData.message, "{{ __('locale.Error') }}");
                showError(responseData.errors);
            }
        });
    });

    // ==============================================
    // SHOW EDIT GROUP MODAL
    // ==============================================
    $(document).on('click', '.edit-regulator', function() {
        var id = $(this).data('id');
        var name = $(this).data('name');
        const editForm = $("#edit-regulator form");
        
        // Assign data to modal
        editForm.find('input[name="id"]').val(id);
        editForm.find("input[name='name']").val(name);
        
        $('.dtr-bs-modal').modal('hide');
        $('#edit-regulator').modal('show');
    });

    // ==============================================
    // TRASH GROUP FUNCTION
    // ==============================================
    function TrashGroup(id) {
        let url = "{{ route('admin.phishing.group.trash', ':id') }}";
        url = url.replace(':id', id);
        
        $.ajax({
            url: url,
            type: "POST",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(data) {
                if (data.status) {
                    makeAlert('success', data.message, "{{ __('locale.Success') }}");
                    table.ajax.reload();
                }
            },
            error: function(response, data) {
                responseData = response.responseJSON;
                makeAlert('error', responseData.message, "{{ __('locale.Error') }}");
            }
        });
    }

    // ==============================================
    // SHOW DELETE CONFIRMATION MODAL
    // ==============================================
    window.ShowModalTrashGroup = function(id) {
        $('.dtr-bs-modal').modal('hide');
        Swal.fire({
            title: "{{ __('locale.AreYouSureToTrashThisRecord') }}",
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: "{{ __('locale.ConfirmTrash') }}",
            cancelButtonText: "{{ __('locale.Cancel') }}",
            customClass: {
                confirmButton: 'btn btn-relief-success ms-1',
                cancelButton: 'btn btn-outline-danger ms-1'
            },
            buttonsStyling: false
        }).then(function(result) {
            if (result.value) {
                TrashGroup(id);
            }
        });
    };

    // ==============================================
    // RESET FORM DATA
    // ==============================================
    function resetFormData(form) {
        $('.error').empty();
        form.trigger("reset");
        form.find('input:not([name="_token"])').val('');
        form.find('select.multiple-select2 option[selected]').attr('selected', false);
        form.find('select.select2 option').attr('selected', false);
        form.find("select.select2").each(function(index) {
            $(this).find('option').first().attr('selected', true);
        });
        form.find('select').trigger('change');
    }

});
</script>
@endsection

@section('page-script')
<script>
    const verifiedTranslation = "{{ __('locale.Verified') }}",
        UnverifiedAssetsTranslation = "{{ __('asset.UnverifiedAssets') }}",
        customDay = "{{ trans_choice('locale.custom_days', 1) }}",
        customDays = "{{ trans_choice('locale.custom_days', 3) }}";

    var permission = [],
        lang = [],
        URLs = [];
        
    permission['edit'] = {{ auth()->user()->hasPermission('asset.update') ? 1 : 0 }};
    permission['delete'] = {{ auth()->user()->hasPermission('asset.delete') ? 1 : 0 }};

    lang['DetailsOfItem'] = "{{ __('locale.DetailsOfItem', ['item' => __('asset.asset')]) }}";

    URLs['ajax_list'] = "{{ route('admin.asset_management.ajax.index') }}";
</script>

<script src="{{ asset(mix('js/scripts/forms/form-select2.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/forms/wizard/bs-stepper.min.js')) }}"></script>
<script src="{{ asset(mix('js/scripts/forms/form-wizard.js')) }}"></script>
<script src="{{ asset('js/scripts/config.js') }}"></script>
<script src="{{ asset('ajax-files/asset_management/asset/index.js') }}"></script>
@endsection