@extends('admin/layouts/contentLayoutMaster')

@section('title', __('lms.Training Dashboard'))

@section('vendor-style')
<link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
<link rel="stylesheet" href="{{ asset(mix('vendors/css/charts/apexcharts.css')) }}">
<link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
@endsection

@section('page-style')
<link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
<style>
    .stats-card {
        border-radius: 10px;
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        transition: transform 0.3s ease;
    }

    .stats-card:hover {
        transform: translateY(-5px);
    }

    .stats-card .icon {
        font-size: 2.5rem;
        margin-bottom: 15px;
    }

    .stats-card h3 {
        font-size: 2rem;
        font-weight: bold;
        margin: 10px 0;
    }

    .stats-card p {
        color: #6c757d;
        margin: 0;
    }

    .training-item {
        border: 1px solid #e9ecef;
        border-radius: 8px;
        padding: 15px;
        margin-bottom: 15px;
        transition: all 0.3s ease;
    }

    .training-item:hover {
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    .progress-custom {
        height: 8px;
        border-radius: 4px;
    }

    .table-recent {
        font-size: 0.9rem;
    }

    .badge-status {
        padding: 5px 10px;
        border-radius: 15px;
        font-size: 0.85rem;
    }
</style>
@endsection

@section('content')

<!-- Breadcrumb -->
<div class="content-header row">
    <div class="content-header-left col-12 mb-2">
        <div class="row breadcrumbs-top">
            <div class="col-12">
                <div class="page-title mt-2">
                    <div class="row">
                        <div class="col-sm-6 ps-0">
                            @if(isset($breadcrumbs))
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="{{ route('admin.dashboard') }}" style="display: flex;">
                                        <svg class="stroke-icon">
                                            <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}"></use>
                                        </svg>
                                    </a>
                                </li>
                                @foreach($breadcrumbs as $breadcrumb)
                                <li class="breadcrumb-item">
                                    @if(isset($breadcrumb['link']))
                                    <a href="{{ $breadcrumb['link'] }}">
                                        @endif
                                        {{ $breadcrumb['name'] }}
                                        @if(isset($breadcrumb['link']))
                                    </a>
                                    @endif
                                </li>
                                @endforeach
                            </ol>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Statistics Cards -->
<section class="stats-section">
    <div class="row">
        <!-- Total Trainings -->
        <div class="col-xl-4 col-md-6">
            <div class="stats-card bg-primary text-white">
                <div class="icon">
                    <i class="fas fa-book"></i>
                </div>
                <h3 class="text-white">{{ $totalPublicTrainings }}</h3>
                <p class="text-white">{{ __('lms.Total Public Trainings') }}</p>
            </div>
        </div>

        <!-- Total Enrollments -->
        <div class="col-xl-4 col-md-6">
            <div class="stats-card bg-info text-white">
                <div class="icon">
                    <i class="fas fa-users"></i>
                </div>
                <h3 class="text-white">{{ $totalEnrollments }}</h3>
                <p class="text-white">{{ __('lms.Total Enrollments') }}</p>
            </div>
        </div>

        <!-- Completion Rate -->
        <div class="col-xl-4 col-md-6">
            <div class="stats-card bg-success text-white">
                <div class="icon">
                    <i class="fas fa-check-circle"></i>
                </div>
                <h3 class="text-white">{{ $completionRate }}%</h3>
                <p class="text-white">{{ __('lms.Success Rate') }}</p>
            </div>
        </div>

    </div>

    <!-- Secondary Stats -->
    <div class="row mt-3">
        <div class="col-xl-6 col-md-6">
            <div class="card">
                <div class="card-body text-center">
                    <i class="fas fa-check text-success" style="font-size: 2rem;"></i>
                    <h4 class="mt-2">{{ $totalCompleted }}</h4>
                    <p class="text-muted">{{ __('lms.Passed') }}</p>
                </div>
            </div>
        </div>
        <div class="col-xl-6 col-md-6">
            <div class="card">
                <div class="card-body text-center">
                    <i class="fas fa-times text-danger" style="font-size: 2rem;"></i>
                    <h4 class="mt-2">{{ $totalFailed }}</h4>
                    <p class="text-muted">{{ __('lms.Failed') }}</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Charts Section -->
<section class="charts-section mt-4">
    <div class="row">
        <!-- Monthly Trend Chart -->
        <div class="col-xl-8">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">{{ __('lms.Completion Trend (Last 12 Months)') }}</h4>
                </div>
                <div class="card-body">
                    <div id="monthly-trend-chart"></div>
                </div>
            </div>
        </div>

        <!-- Top Users -->
        <div class="col-xl-4">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">{{ __('lms.Top Performers') }}</h4>
                </div>
                <div class="card-body">
                    <div class="list-group">
                        @foreach($topUsers as $user)
                        <div class="list-group-item d-flex justify-content-between align-items-center">
                            <div>
                                <strong>{{ $user->name }}</strong>
                                <br>
                                <small class="text-muted">
                                    {{ $user->completed_trainings }} {{ __('lms.trainings') }} |
                                    {{ number_format($user->avg_score, 1) }}% {{ __('lms.avg score') }}
                                </small>
                            </div>
                            <span class="badge bg-success">
                                <i class="fas fa-trophy"></i>
                            </span>
                        </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Training Modules by Course -->
<section class="trainings-section mt-4">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">{{ __('lms.Trainings by Course') }}</h4>
        </div>
        <div class="card-body">
            @foreach($trainingsByCourse as $course)
            <div class="training-item">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <h5 class="mb-0">
                        <i class="fas fa-book-open text-primary"></i> {{ $course->title }}
                    </h5>
                </div>

                <div class="row mt-3">
                    @foreach($course->levels as $level)
                    @foreach($level->training_modules as $module)
                    <div class="col-md-6 mb-3">
                        <div class="card">
                            <div class="card-body">
                                <h6>{{ $module->name }}</h6>
                                <div class="d-flex justify-content-between mb-2">
                                    <small>{{ __('lms.Enrollments') }}: {{ $module->users_count }}</small>
                                    <small>{{ __('lms.Completed') }}: {{ $module->completed_users_count }}</small>
                                </div>
                                @php
                                $moduleCompletionRate = $module->users_count > 0
                                ? ($module->completed_users_count / $module->users_count) * 100
                                : 0;
                                @endphp
                                <div class="progress progress-custom">
                                    <div class="progress-bar bg-success" role="progressbar"
                                        style="width: {{ $moduleCompletionRate }}%"
                                        aria-valuenow="{{ $moduleCompletionRate }}"
                                        aria-valuemin="0" aria-valuemax="100">
                                    </div>
                                </div>
                                <small class="text-muted">{{ number_format($moduleCompletionRate, 1) }}% {{ __('lms.complete') }}</small>
                            </div>
                        </div>
                    </div>
                    @endforeach
                    @endforeach
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>

<!-- Recent Completions -->
<section class="recent-section mt-4">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">{{ __('lms.Recent Completions (Last 30 Days)') }}</h4>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-recent table-hover">
                    <thead>
                        <tr>
                            <th>{{ __('lms.User') }}</th>
                            <th>{{ __('lms.Training') }}</th>
                            <th>{{ __('lms.Score') }}</th>
                            <th>{{ __('lms.Status') }}</th>
                            <th>{{ __('lms.Completed At') }}</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($recentCompletions as $completion)
                        <tr>
                            <td>{{ $completion->user_name }}</td>
                            <td>{{ $completion->training_name }}</td>
                            <td>
                                <strong>{{ number_format($completion->score, 2) }}%</strong>
                            </td>
                            <td>
                                @if($completion->passed)
                                <span class="badge badge-status bg-success">
                                    <i class="fas fa-check"></i> {{ __('lms.Passed') }}
                                </span>
                                @else
                                <span class="badge badge-status bg-danger">
                                    <i class="fas fa-times"></i> {{ __('lms.Failed') }}
                                </span>
                                @endif
                            </td>
                            <td>{{ \Carbon\Carbon::parse($completion->completed_at)->format('Y-m-d H:i') }}</td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<!-- Average Scores -->
<section class="scores-section mt-4">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">{{ __('lms.Average Scores by Training') }}</h4>
        </div>
        <div class="card-body">
            <div id="average-scores-chart"></div>
        </div>
    </div>
</section>

@endsection

@section('vendor-script')
<script src="{{ asset(mix('vendors/js/charts/apexcharts.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
@endsection

@section('page-script')
<script>
    $(document).ready(function() {
        // Monthly Trend Chart
        var monthlyTrendData = @json($monthlyTrend);
        var months = monthlyTrendData.map(item => item.month);
        var completions = monthlyTrendData.map(item => item.completions);
        var passed = monthlyTrendData.map(item => item.passed);

        var monthlyTrendOptions = {
            series: [{
                name: '{{ __("lms.Total Completions") }}',
                data: completions
            }, {
                name: '{{ __("lms.Passed") }}',
                data: passed
            }],
            chart: {
                height: 350,
                type: 'bar',
                toolbar: {
                    show: false
                }
            },
            dataLabels: {
                enabled: false
            },
            stroke: {
                curve: 'smooth',
                width: 2
            },
            xaxis: {
                categories: months
            },
            colors: ['#7367f0', '#28c76f'],
            fill: {
                type: 'gradient',
                gradient: {
                    shadeIntensity: 1,
                    opacityFrom: 0.7,
                    opacityTo: 0.3,
                }
            }
        };

        var monthlyTrendChart = new ApexCharts(
            document.querySelector("#monthly-trend-chart"),
            monthlyTrendOptions
        );
        monthlyTrendChart.render();

        // Average Scores Chart
        var averageScoresData = @json($averageScores);
        var trainingNames = averageScoresData.map(item => item.name);
        var avgScores = averageScoresData.map(item => parseFloat(item.avg_score).toFixed(2));

        var avgScoresOptions = {
            series: [{
                name: '{{ __("lms.Average Score") }}',
                data: avgScores
            }],
            chart: {
                height: 350,
                type: 'bar',
                toolbar: {
                    show: false
                }
            },
            plotOptions: {
                bar: {
                    horizontal: true,
                    dataLabels: {
                        position: 'top'
                    }
                }
            },
            dataLabels: {
                enabled: true,
                formatter: function(val) {
                    return val + "%";
                },
                offsetX: -6,
                style: {
                    fontSize: '12px',
                    colors: ['#fff']
                }
            },
            xaxis: {
                categories: trainingNames,
                max: 100
            },
            colors: ['#00cfe8']
        };

        var avgScoresChart = new ApexCharts(
            document.querySelector("#average-scores-chart"),
            avgScoresOptions
        );
        avgScoresChart.render();
    });
</script>
@endsection
