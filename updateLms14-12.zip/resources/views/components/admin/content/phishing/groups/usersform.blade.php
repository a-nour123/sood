<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModal"
    aria-hidden="true" id="{{ $id }}">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myExtraLargeModal">{{ $title }}</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body dark-modal">
                <form action="{{ route('admin.phishing.group.AddUsersTogroup') }}" method="POST"
                    class="modal-content pt-4 p-3" enctype="multipart/form-data" id="users-form-{{ $id }}">
                    @csrf
                    <input type="hidden" name="id" class="group-id-input">

                    <!-- Select All Users (Global) -->
                    <div class="mb-2">
                        <input type="checkbox" id="select-all-global-{{ $id }}" class="select-all-global">
                        <label for="select-all-global-{{ $id }}"><strong>Select All Users in All Departments</strong></label>
                    </div>

                    <!-- Search Box -->
                    <div class="mb-3">
                        <input type="text" id="user-search-{{ $id }}" class="form-control user-search-input" 
                               placeholder="Search users or departments...">
                    </div>

                    <!-- Loading Indicator -->
                    <div class="text-center my-3 users-loading" style="display: none;">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                        <p class="mt-2">Loading users...</p>
                    </div>

                    <div class="tree tree-{{ $id }}">
                        @foreach ($departments as $department)
                            @php
                                $employeeCount = $department->employees->count();
                            @endphp
                            
                            @if($employeeCount > 0)
                                <ul class="department-item" data-dept-name="{{ strtolower($department->name) }}">
                                    <li style="margin-left: 20px;">
                                        <!-- Department Row -->
                                        <div style="display: flex; align-items: center; gap: 10px;">
                                            <input type="checkbox" class="select-all-dept"
                                                data-dept-id="{{ $department->id }}"
                                                id="dept-checkbox-{{ $department->id }}">
                                            <a href="javascript:void(0);"
                                                style="color:{{ $department->color?->value ?? '#000' }}; flex:1;"
                                                class="department-anchor" 
                                                data-dept-id="{{ $department->id }}">
                                                {{ $department->name }} ({{ $employeeCount }})
                                            </a>
                                        </div>

                                        <!-- Users List (Hidden by Default) -->
                                        <ul class="users-list" 
                                            id="users-dept-{{ $department->id }}"
                                            data-dept-id="{{ $department->id }}"
                                            style="display: none; margin-left: 30px; margin-top:5px;">
                                            @foreach ($department->employees as $user)
                                                <li class="user-item" data-user-name="{{ strtolower($user->name) }}">
                                                    <input type="checkbox" 
                                                        name="users[]" 
                                                        value="{{ $user->id }}"
                                                        class="user-checkbox dept-{{ $department->id }}"
                                                        id="user-{{ $user->id }}-{{ $id }}"
                                                        data-user-id="{{ $user->id }}">
                                                    <label for="user-{{ $user->id }}-{{ $id }}">{{ $user->name }}</label>
                                                </li>
                                            @endforeach
                                        </ul>
                                    </li>
                                </ul>
                            @endif
                        @endforeach
                    </div>

                    <button type="submit" class="btn btn-primary data-submit me-1">{{ __('locale.Submit') }}</button>
                </form>
            </div>
        </div>
    </div>
</div>