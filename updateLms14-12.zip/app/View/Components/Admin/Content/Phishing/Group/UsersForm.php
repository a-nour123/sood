<?php

namespace App\View\Components\Admin\Content\Phishing\Group;

use App\Models\Department;
use App\Models\PhishingGroup;
use Illuminate\View\Component;
use Illuminate\Support\Facades\Cache;

class UsersForm extends Component
{
    public $id;
    public $title;
    public $departments;
    public $idValue;

    public function __construct($id, $title, $idValue = null)
    {
        $this->id = $id;
        $this->title = $title;
        $this->idValue = $idValue;
        
        // Load departments with optimized eager loading
        $this->departments = $this->loadDepartments();
    }

    private function loadDepartments()
    {
        // Optimized query - only load departments with employees
        // Select only necessary columns to reduce memory usage
        return Department::with([
            'employees:id,name,department_id',
            'color:id,value'
        ])
        ->select('id', 'name', 'parent_id', 'color_id')
        ->has('employees') // Only departments with employees
        ->orderBy('name')
        ->get();
    }

    public function render()
    {
        return view('components.admin.content.phishing.groups.usersform');
    }
}