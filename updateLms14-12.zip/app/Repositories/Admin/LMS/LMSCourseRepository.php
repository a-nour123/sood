<?php


namespace App\Repositories\Admin\LMS;

use App\Events\LMSCourseCreated;
use App\Events\LMSCourseUpdated;
use App\Helpers\Helper;
use App\Interfaces\Admin\LMS\LMSCourseInterface;
use App\Interfaces\Admin\Phishing\PhishingDomainsInterface;
use App\Models\Action;
use App\Models\AwarenessSurvey;
use App\Models\FrameworkControl;
use App\Models\LMSCourse;
use App\Models\LMSLevel;
use App\Models\LMSTrainingModule;
use App\Models\PhishingDomains;
use App\Models\Role;
use App\Models\User;
use App\Traits\UpoladFileTrait;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Yajra\DataTables\Facades\DataTables;

class LMSCourseRepository implements LMSCourseInterface
{
    use UpoladFileTrait;
    public function index()
    {
        if (!auth()->user()->hasPermission('courses.list')) {
            abort(403, 'Unauthorized action.');
        }

        $breadcrumbs = [
            ['link' => route('admin.dashboard'), 'name' => __('locale.Dashboard')],
            ['name' => __('lms.lms_managment')],
            ['name' => __('lms.Courses')]
        ];

        $compliances = FrameworkControl::all();
        $surveys = AwarenessSurvey::get();
        $courses = LMSCourse::withoutTrashed()
            ->orderBy('created_at','desc')
            ->withCount('levels','training_modules')
            ->paginate(10);
        return view('admin.content.LMS.courses.list', get_defined_vars());
    }

    public function dashboard()
    {
        if (!auth()->user()->hasPermission('courses.list')) {
            abort(403, 'Unauthorized action.');
        }

        $breadcrumbs = [
            ['link' => route('admin.dashboard'), 'name' => __('locale.Dashboard')],
            ['name' => __('lms.lms_managment')],
            ['name' => __('lms.Training Dashboard')]
        ];

        // Get all public training modules with related data
        $publicTrainings = LMSTrainingModule::where('training_type', 'public')
            ->withoutTrashed()
            ->with(['level.course', 'questions', 'statements'])
            ->withCount([
                'users',
                'users as completed_users_count' => function ($query) {
                    $query->where('passed', 1);
                },
                'users as failed_users_count' => function ($query) {
                    $query->where('passed', 0)->whereNotNull('completed_at');
                },

            ])
            ->get();

        // Calculate overall statistics
        $totalPublicTrainings = $publicTrainings->count();
        $totalEnrollments = $publicTrainings->sum('users_count');
        $totalCompleted = $publicTrainings->sum('completed_users_count');
        $totalFailed = $publicTrainings->sum('failed_users_count');

        // Calculate average completion rate
        $completionRate = $totalEnrollments > 0
            ? round(($totalCompleted / $totalEnrollments) * 100, 2)
            : 0;

        // Get training modules by course
        $trainingsByCourse = LMSCourse::withoutTrashed()
            ->whereHas('training_modules', function ($query) {
                $query->where('training_type', 'public')->withoutTrashed();
            })
            ->with(['levels.training_modules' => function ($query) {
                $query->where('training_type', 'public')
                    ->withoutTrashed()
                    ->withCount([
                        'users',
                        'users as completed_users_count' => function ($q) {
                            $q->where('passed', 1);
                        }
                    ]);
            }])
            ->get();

        // Get recent completions (last 30 days)
        $recentCompletions = DB::table('l_m_s_user_training_modules as utm')
            ->join('l_m_s_training_modules as tm', 'utm.training_module_id', '=', 'tm.id')
            ->join('users', 'utm.user_id', '=', 'users.id')
            ->where('tm.training_type', 'public')
            ->whereNotNull('utm.completed_at')
            ->where('utm.completed_at', '>=', now()->subDays(30))
            ->select(
                'utm.id',
                'users.name as user_name',
                'tm.name as training_name',
                'utm.score',
                'utm.passed',
                'utm.completed_at'
            )
            ->orderBy('utm.completed_at', 'desc')
            ->limit(10)
            ->get();

        // Get average scores by training module
        $averageScores = DB::table('l_m_s_user_training_modules as utm')
            ->join('l_m_s_training_modules as tm', 'utm.training_module_id', '=', 'tm.id')
            ->where('tm.training_type', 'public')
            ->whereNotNull('utm.completed_at')
            ->select(
                'tm.id',
                'tm.name',
                DB::raw('AVG(utm.score) as avg_score'),
                DB::raw('COUNT(*) as attempts')
            )
            ->groupBy('tm.id', 'tm.name')
            ->orderBy('avg_score', 'desc')
            ->get();

        // Get monthly completion trend (last 12 months)
        $monthlyTrend = DB::table('l_m_s_user_training_modules as utm')
            ->join('l_m_s_training_modules as tm', 'utm.training_module_id', '=', 'tm.id')
            ->where('tm.training_type', 'public')
            ->whereNotNull('utm.completed_at')
            ->where('utm.completed_at', '>=', now()->subMonths(12))
            ->select(
                DB::raw('DATE_FORMAT(utm.completed_at, "%Y-%m") as month'),
                DB::raw('COUNT(*) as completions'),
                DB::raw('SUM(CASE WHEN utm.passed = 1 THEN 1 ELSE 0 END) as passed')
            )
            ->groupBy('month')
            ->orderBy('month', 'asc')
            ->get();

            // dd($monthlyTrend);
        // Get top performing users
        $topUsers = DB::table('l_m_s_user_training_modules as utm')
            ->join('l_m_s_training_modules as tm', 'utm.training_module_id', '=', 'tm.id')
            ->join('users', 'utm.user_id', '=', 'users.id')
            ->where('tm.training_type', 'public')
            ->whereNotNull('utm.completed_at')
            ->where('utm.passed', 1)
            ->select(
                'users.id',
                'users.name',
                DB::raw('COUNT(*) as completed_trainings'),
                DB::raw('AVG(utm.score) as avg_score')
            )
            ->groupBy('users.id', 'users.name')
            ->orderBy('completed_trainings', 'desc')
            ->orderBy('avg_score', 'desc')
            ->limit(10)
            ->get();

        return view('admin.content.LMS.courses.dashboard', compact(
            'breadcrumbs',
            'totalPublicTrainings',
            'totalEnrollments',
            'totalCompleted',
            'totalFailed',
            'completionRate',
            'publicTrainings',
            'trainingsByCourse',
            'recentCompletions',
            'averageScores',
            'monthlyTrend',
            'topUsers'
        ));
    }

    public function store(Request $request)
    {
        try {
            // dd($request->all());

            $validator = Validator::make($request->all(), [
                'title' => 'required|unique:l_m_s_courses,title',
                'description' => 'required',
            ]);

            if ($validator->fails()) {
                $errors = $validator->errors()->toArray();
                return response()->json(['status' => false,'errors' => $errors, 'message' => __('locale.ThereWasAProblemAddingCourse') . "<br>" . __('locale.Validation error')], 422);
            }

            $path = null;
            if($request->hasFile('image')) {
                $file = $request->file('image');
                // $path = $this->storeFile($file, 'LMS/Courses');
                $path = $this->storeFileInStorage($file, 'public/LMS/Courses');
            }
            $course = LMSCourse::create([
                'title' => $request->title,
                'description' => $request->description,
                'image' => $path ?? 'no path !',
            ]);

            event(new LMSCourseCreated($course));
            return response()->json(['status' => true,'message' => 'Course is Added Successfully'], 200);
        } catch (\Exception $ex) {
            return response()->json($ex->getMessage());
            return response()->json(['status' => false,'message' => __('locale.Error')], 502);
        }
    }

    public function show($id,Request $request)
    {
        try {
            $course = LMSCourse::with('levels.training_modules')->find($id);
            // $course = LMSCourse::with('levels.training_modules','questions','statements','training_modules')->find($id);
            $course->image =  asset('storage/'.$course->image);
            return response()->json(['course' => $course]);
        } catch (\Exception $e) {
            return response()->json(['success' => false,'message' => $e->getMessage()]);
        }
    }

    public function update($id, Request $request)
    {
        try {
            $Course = LMSCourse::find($id);
            $validator = Validator::make($request->all(), [
                'title' => ['required',Rule::unique('l_m_s_courses','title')->ignore($id),'min:5'],
                'description' => 'required|min:5',
            ]);

            if ($validator->fails()) {
                $errors = $validator->errors()->toArray();
                return response()->json(['status' => false,'errors' => $errors, 'message' => __('locale.ThereWasAProblemAddingCourse') . "<br>" . __('locale.Validation error')], 422);
            }

            $path =  $Course->image;
            if($request->hasFile('image')) {
                $file = $request->file('image');
                // $path = $this->storeFile($file, 'LMS/Courses');
                $path = $this->storeFileInStorage($file, 'public/LMS/Courses');
            }
            $Course->update([
                'title' => $request->title,
                'description' => $request->description,
                'image' => $path,
            ]);

            event(new LMSCourseUpdated($Course));
            return response()->json(['status' => true,'message' => 'Course is Updated Successfully'], 200);
        } catch (\Exception $ex) {
            // return response()->json($ex->getMessage());
            return response()->json(['status' => false,'message' => __('locale.Error')], 502);
        }
    }
    public function trash($course)
    {
        try {

            $course = LMSCourse::findOrFail($course);
            $course->update(['deleted_at' => now()]);
            return response()->json(['status' => true,'message' => __('phishing.CourseWasDeletedSuccessfully')], 200);
        } catch (\Exception $e) {
            return response()->json(['status' => false,'message' => __('locale.Error')], 502);
        }
    }

    public function restore($id,Request $request)
    {
        try {
            $domain = PhishingDomains::onlyTrashed()->findOrFail($id);
            $domain->restore();
            return response()->json(['status' => true,'message' => __('phishing.domainRestoreSuccessfully')], 200);
        } catch (\Exception $e) {
            return response()->json(['status' => false,'message' => __('locale.Error')], 502);
        }
    }
    public function delete($id)
    {
        try {
            $course = LMSCourse::findOrFail($id);
            if($course->levels()->exists()){
                return response()->json(['status' => false,'message' => __('lms.CourseCantBeDeletedItContainLevels')], 200);
            }
            $course->forceDelete();
            return response()->json(['status' => true,'message' => __('lms.CourseWasDeletedSuccessfully')], 200);
        } catch (\Exception $e) {
            return response()->json(['status' => false,'message' => __('locale.Error')], 502);
        }
    }
    public function getProfiles($id)
    {
        $domain = PhishingDomains::with('profiles')->findOrFail($id);
        $senderProfiles = $domain->profiles;
        $breadcrumbs = [
            ['link' => route('admin.dashboard'), 'name' => __('locale.Dashboard')],
            ['name' => __('Sender Profiles')]
        ];
        return view('admin.content.phishing.senderProfile.domain-profiles', get_defined_vars());
        // return view('admin.content.phishing.senderProfile.list', get_defined_vars());
    }

    public function getProfilesDataTable($id)
    {
        $domain = PhishingDomains::with('profiles')->findOrFail($id);
        $senderProfiles = $domain->profiles;
        return DataTables::of($senderProfiles)->setRowId(function ($row) {
            return $row->id;
        })->addColumn('actions', function ($row) {
                $data = '<div class="regulator-item">';
                $data = $data.'<button class="btn btn-secondary show-frame trash-domain" type="button" data-bs-toggle="modal"
                    data-id="'.$row->id.'" onclick="ShowModalRestoreDomain('.$row->id.')" data-name="'.$row->name.'">
                                               <i class="fa-solid fa-undo"></i>
                </button>';

                $data = $data.' <button class="btn btn-secondary show-frame trash-domain" type="button" data-bs-toggle="modal"
                    data-id="'.$row->id.'" onclick="ShowModalDeleteDomain('.$row->id.')" data-name="'.$row->name.'">
                                                <i class="fa-solid fa-trash"></i>
                </button>';

                $data = $data.'</div>';

            return $data;
        })->editColumn('created_at', function ($row) {
            $data = $row->created_at;

            return Carbon::parse($data)->format('Y-m-d g:ia');
        })->rawColumns(['actions'])
        ->make(true);
    }

    public function getArchivedDomains()
    {
        $breadcrumbs = [
            ['link' => route('admin.dashboard'), 'name' => __('locale.Dashboard')],
            ['name' => __('lms.lms_managment')],
            ['name' => __('lms.Courses_archive')]
        ];



        $archived_domains = PhishingDomains::onlyTrashed()->get();
        return view('admin.content.LMS.courses.archived', get_defined_vars());
    }

    public function getCourseLevels(Request $request)
    {
        try {

            if($request->course_id){
                $Levels = LMSLevel::where('course_id',$request->course_id)->get();
            }else{
                $Levels = LMSLevel::get();
            }
            return response()->json(['status' => true,'Levels' => $Levels], 200);
        } catch (\Exception $e) {
            return response()->json(['status' => false,'message' =>$e->getMessage()], 502);
        }
    }

    public function courseNotificationsSettings()
    {
        // defining the breadcrumbs that will be shown in page
        $breadcrumbs = [
            ['link' => route('admin.dashboard'), 'name' => __('locale.Dashboard')],
            ['link' => route('admin.lms.courses.index'), 'name' => __('lms.Courses')], // give it your own route
            ['name' => __('locale.NotificationsSettings')]
        ];
        $users = User::where('enabled', true)->get();  // getting all users to list them in select input of users
        $moduleActionsIds = [125,126,127,128,161];   // defining ids of actions modules in ActionSeeder (system notification part)
        $moduleActionsIdsAutoNotify = [129];  // defining ids of actions modules (auto notify part)

        // defining variables associated with each action "for the user to choose variables he wants to add to the message of notification" "each action id will be the array key of action's variables list"
        $actionsVariables = [
            125 => ['title', 'description'], // add new course
            126 => ['title', 'description'],// update existing course
            127 => ['name', 'passing_score', 'order', 'completion_time','course_name','course_level'], // add new training module
            128 => ['name', 'passing_score', 'order', 'completion_time','course_name','course_level'], // edit existing training module
            161 =>  ['name', 'passing_score', 'order', 'completion_time','course_name','course_level'], // edit existing training module
        ];
        // defining roles associated with each action "for the user to choose roles he wants to sent the notification to" "each action id will be the array key of action's roles list"
        $actionsRoles = [
            125 => [],
            126 => [],
            127 => [],
            128 => [],
            161 => ['system-users' => __('campaign.SystemUser')],

        ];


        /* static part below you will change nothing in it  */

        // getting actions with their system notifications settings, sms settings and mail settings to list them in tables
        $actionsWithSettings = Action::whereIn('actions.id', $moduleActionsIds)
            ->leftJoin('system_notifications_settings', 'actions.id', '=', 'system_notifications_settings.action_id')
            ->leftJoin('mail_settings', 'actions.id', '=', 'mail_settings.action_id')
            ->leftJoin('sms_settings', 'actions.id', '=', 'sms_settings.action_id')
            ->leftJoin('auto_notifies', 'actions.id', '=', 'auto_notifies.action_id')
            ->get([
                'actions.id as action_id',
                'actions.name as action_name',
                'system_notifications_settings.id as system_notification_setting_id',
                'system_notifications_settings.status as system_notification_setting_status',
                'mail_settings.id as mail_setting_id',
                'mail_settings.status as mail_setting_status',
                'sms_settings.id as sms_setting_id',
                'sms_settings.status as sms_setting_status',
                'auto_notifies.id as auto_notifies_id',
                'auto_notifies.status as auto_notifies_status',
            ]);
        $actionsWithSettingsAuto = Action::whereIn('actions.id', $moduleActionsIdsAutoNotify)
            ->leftJoin('auto_notifies', 'actions.id', '=', 'auto_notifies.action_id')
            ->get([
                'actions.id as action_id',
                'actions.name as action_name',
                'auto_notifies.id as auto_notifies_id',
                'auto_notifies.status as auto_notifies_status',
            ]);
        return view('admin.content.LMS.courses.notifications-settings.index', compact('breadcrumbs', 'users', 'actionsWithSettings', 'actionsVariables', 'actionsRoles', 'moduleActionsIdsAutoNotify', 'actionsWithSettingsAuto'));
    }
}
