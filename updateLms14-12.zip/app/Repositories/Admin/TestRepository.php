<?php


namespace App\Repositories\Admin;
use App\Interfaces\Admin\TestInterface;

class TestRepository implements TestInterface
{
    public function testRepositoryTechineqe()
    {
        try {

            dd('PhishingDomainsController is created successfuly again sdkjdnkaka !');

        }catch (\Exception $e)
        {

        }
    }
}
