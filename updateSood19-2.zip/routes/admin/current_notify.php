<?php

use App\Http\Controllers\admin\current_notify\CurrentNotifyController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register admin assessment routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "admin" middleware group. Now create something great!
|
*/

Route::group(
    [
        'prefix' => 'current-notify', // Prefix applied on all `control-objectives` group routes
        'middleware' => [], // Middlewares applied on all `control-objectives` group routes
        'as' => 'current_notify.'
    ],
    function () {

        Route::get('notifications-settings', [CurrentNotifyController::class, 'notificationsSettings'])
            ->name('notificationsSettings');
        Route::resource('/', CurrentNotifyController::class);
        Route::post('/send-notify/{type}', [CurrentNotifyController::class, 'sendCurrentNotify'])
            ->name('sendCurrentNotify');
    }
);
