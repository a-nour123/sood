@extends('admin/layouts/contentLayoutMaster')

@section('title', __('locale.CurrentNotify'))

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/dataTables.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/responsive.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/buttons.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/flatpickr/flatpickr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/spinner/jquery.bootstrap-touchspin.css')) }}">
@endsection

@section('page-style')
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-sweet-alerts.css')) }}">
    <style>
        .attachment-item {
            max-width: 300px;
            word-break: break-all;
        }

        .modal-xl {
            max-width: 1200px;
        }

        .request-details-table th {
            width: 30%;
            background-color: #f8f9fa;
        }

        .timeline-item {
            border-left: 2px solid #ddd;
            padding-left: 15px;
            margin-bottom: 15px;
            position: relative;
        }

        .timeline-item::before {
            content: '';
            position: absolute;
            left: -6px;
            top: 5px;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background-color: #666;
        }
    </style>
@endsection

@section('content')
    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">
            <div class="row breadcrumbs-top widget-grid">
                <div class="col-12">
                    <div class="page-title mt-2">
                        <div class="row">
                            <div class="col-md-6 ps-0">
                                @if (@isset($breadcrumbs))
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item">
                                            <a href="{{ route('admin.dashboard') }}" style="display: flex;">
                                                <svg class="stroke-icon">
                                                    <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}">
                                                    </use>
                                                </svg>
                                            </a>
                                        </li>
                                        @foreach ($breadcrumbs as $breadcrumb)
                                            <li class="breadcrumb-item">
                                                @if (isset($breadcrumb['link']))
                                                    <a
                                                        href="{{ $breadcrumb['link'] == 'javascript:void(0)' ? $breadcrumb['link'] : url($breadcrumb['link']) }}">
                                                @endif
                                                {{ __($breadcrumb['name']) }}
                                                @if (isset($breadcrumb['link']))
                                                    </a>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ol>
                                @endisset
                        </div>
                        <div class="col-md-6 pe-0" style="text-align: end;">
                            <div class="action-content">
                                @if (auth()->user()->hasPermission('configuration.current_notify'))
                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                        data-bs-target="#createRequestModal">
                                        <i class="fa fa-plus"></i>
                                    </button>
                                @endif

                                @if (auth()->user()->hasPermission('configuration.current_notify'))
                                    <a href="{{ route('admin.current_notify.notificationsSettings') }}"
                                        class=" btn btn-primary" target="_self">
                                        <i class="fa-regular fa-bell"></i>
                                    </a>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- CARD --}}
<div class="row">
    <div class="col-12">
        <div class="card shadow-sm">

            <div class="card-header">
                <h4 class="card-title mb-0">{{ __('locale.Selected CISOs') }}</h4>
            </div>

            <div class="card-body">

                @if (isset($selectedUsers) && count($selectedUsers))

                    <div class="row">

                        @foreach ($selectedUsers as $user)
                            <div class="col-md-4 mb-2">

                                <div
                                    class="border rounded p-2 d-flex align-items-center justify-content-between shadow-sm">

                                    <div>
                                        <strong>{{ $user->name }}</strong><br>
                                        <small class="text-muted">{{ $user->email }}</small>
                                    </div>

                                    <span class="badge bg-success">
                                        {{ __('locale.CISOs') }}
                                    </span>

                                </div>

                            </div>
                        @endforeach

                    </div>
                @else
                    <div class="text-center text-muted">
                        {{ __('locale.No CISO users selected') }}
                    </div>
                @endif

            </div>
        </div>
    </div>
</div>


{{-- MODAL --}}
<div class="modal fade" id="createRequestModal">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">

            <form method="POST" action="{{ route('admin.current_notify.store') }}">
                @csrf

                <div class="modal-header">
                    <h5 class="modal-title">{{ __('locale.Select CISO Users') }}</h5>
                    <button class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">

                    <label class="form-label">{{ __('locale.Choose Users') }}</label>

                    <select name="users[]" class="form-control select2" multiple required>

                        @foreach ($users as $user)
                            <option value="{{ $user->id }}" @if (isset($selectedIds) && in_array($user->id, $selectedIds)) selected @endif>
                                {{ $user->name }} — {{ $user->email }}
                            </option>
                        @endforeach

                    </select>

                </div>

                <div class="modal-footer">
                    <button class="btn btn-primary">
                        {{ isset($selectedIds) ? 'Update' : 'Save' }}
                    </button>
                </div>

            </form>

        </div>
    </div>
</div>


@endsection



@section('vendor-script')
<script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
@endsection


@section('page-script')
<script>

            function makeAlert($status, message, title) {
            // On load Toast
            if (title == 'Success')
                title = '👋' + title;
            toastr[$status](message, title, {
                closeButton: true,
                tapToDismiss: false,
            });
        }
    $(document).ready(function() {

        $('.select2').select2({
            dropdownParent: $('#createRequestModal'),
            width: '100%',
            placeholder: "Select users"
        });

    });
</script>
@endsection
