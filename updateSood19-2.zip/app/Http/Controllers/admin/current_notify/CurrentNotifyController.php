<?php

namespace App\Http\Controllers\admin\current_notify;

use App\Events\CurrentNotifyEvent;
use App\Http\Controllers\Controller;
use App\Models\Action;
use App\Models\Ciso;
use App\Models\CurrentNotify;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;


class CurrentNotifyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (auth()->user()->hasPermission('configuration.current_notify')) {
            $users = User::select('id', 'name', 'email')->get();

            $ciso = Ciso::first();

            $selectedIds = $ciso ? explode(',', $ciso->user_ids) : [];

            $selectedUsers = User::whereIn('id', $selectedIds)->get();

            $breadcrumbs = [['link' => route('admin.dashboard'), 'name' => __('locale.Dashboard')], ['name' => __('locale.CurrentNotify')]];
            return view('admin.content.current-notify.index', compact(
                'breadcrumbs',
                'users',
                'selectedIds',
                'selectedUsers'
            ));
        } else {
            return abort(403, 'unauthorized');
        }
    }


    public function store(Request $request)
    {
        $request->validate([
            'users' => 'required|array'
        ]);

        Ciso::updateOrCreate(
            ['id' => 1], // always target same record
            ['user_ids' => implode(',', $request->users)]
        );

        return back()->with('success', 'Saved successfully');
    }


    public function sendCurrentNotify($type)
    {
        try {

            // validate type manually
            $validator = Validator::make(
                ['type' => $type],
                ['type' => 'required|string|in:vuln_current_notify,incident_current_notify,phishing_current_notify']
            );

            if ($validator->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => $validator->errors()->first()
                ], 422);
            }

            // fire event
            event(new CurrentNotifyEvent($type));

            return response()->json([
                'status' => true,
                'message' => 'Notification sent successfully'
            ]);
        } catch (\Throwable $e) {

            Log::error('Current Notify Error: ' . $e->getMessage());

            return response()->json([
                'status' => false,
                'message' => 'Something went wrong'
            ], 500);
        }
    }



    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }


    /**
     * Display the specified resource.
     *
     * @param  \App\Models\CurrentNotify  $currentNotify
     * @return \Illuminate\Http\Response
     */
    public function show(CurrentNotify $currentNotify)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\CurrentNotify  $currentNotify
     * @return \Illuminate\Http\Response
     */
    public function edit(CurrentNotify $currentNotify)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\CurrentNotify  $currentNotify
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CurrentNotify $currentNotify)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\CurrentNotify  $currentNotify
     * @return \Illuminate\Http\Response
     */
    public function destroy(CurrentNotify $currentNotify)
    {
        //
    }

    public function notificationsSettings()
    {

        // defining the breadcrumbs that will be shown in page
        $breadcrumbs = [['link' => route('admin.dashboard'), 'name' => __('locale.Dashboard')], ['link' => route('admin.current_notify.index'), 'name' => __('locale.CurrentNotify')], ['name' => __('locale.NotificationsSettings')]];
        $users = User::select('id', 'name')->where('enabled', true)->get();  // getting all users to list them in select input of users
        $moduleActionsIds = [175, 176, 177];   // defining ids of actions modules
        $moduleActionsIdsAutoNotify = [];  // defining ids of actions modules

        // defining variables associated with each action "for the user to choose variables he wants to add to the message of notification" "each action id will be the array key of action's variables list"
        $actionsVariables = [
            175 => [],
            176 => [],
            177 => [],
        ];
        // defining roles associated with each action "for the user to choose roles he wants to sent the notification to" "each action id will be the array key of action's roles list"
        $actionsRoles = [
            175 => ['ciso' => __('locale.ciso')],
            176 => ['ciso' => __('locale.ciso')],
            177 => ['ciso' => __('locale.ciso')],
        ];
        // getting actions with their system notifications settings, sms settings and mail settings to list them in tables
        $actionsWithSettings = Action::whereIn('actions.id', $moduleActionsIds)
            ->leftJoin('system_notifications_settings', 'actions.id', '=', 'system_notifications_settings.action_id')
            ->leftJoin('mail_settings', 'actions.id', '=', 'mail_settings.action_id')
            ->leftJoin('sms_settings', 'actions.id', '=', 'sms_settings.action_id')
            ->get([
                'actions.id as action_id',
                'actions.name as action_name',
                'system_notifications_settings.id as system_notification_setting_id',
                'system_notifications_settings.status as system_notification_setting_status',
                'mail_settings.id as mail_setting_id',
                'mail_settings.status as mail_setting_status',
                'sms_settings.id as sms_setting_id',
                'sms_settings.status as sms_setting_status',
            ]);
        $actionsWithSettingsAuto = [];
        return view('admin.notifications-settings.index', compact('breadcrumbs', 'users', 'actionsWithSettings', 'actionsVariables', 'actionsRoles', 'moduleActionsIdsAutoNotify', 'actionsWithSettingsAuto'));
    }
}
