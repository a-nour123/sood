<?php

namespace App\Listeners;

use App\Events\DepartmentCreated;
use App\Models\Action;
use App\Http\Traits\NotificationHandlingTrait;
use App\Models\Ciso;

class CurrentNotifyListener
{
    use NotificationHandlingTrait;

    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  \App\Events\DepartmentCreated  $event
     * @return void
     */
    public function handle($event)
    {
        // Get the risk object from the event
        $data = $event;
        $action1 = Action::where('name', $data->type)->first();
        $actionId1 = $action1['id'];
        $users = Ciso::first();
        $userIds = explode(',', $users->user_ids);

        // Define the roles array for notification
        $roles = [
            'ciso' => $userIds ?? null,
        ];
        // Define the link for redirection after clicking the system notification
        $link = [];

        // parentDepartment
        $actionId2 = null;
        $nextDateNotify = null;
        $modelId = null;
        $modelType = null;
        $proccess = null;
        // Call the function to handle different kinds of notifications

        $this->sendNotificationForAction($actionId1, $actionId2 = null, $link, $data, $roles, $nextDateNotify = null, $modelId = null, $modelType = null, $proccess = null);
    }
}
