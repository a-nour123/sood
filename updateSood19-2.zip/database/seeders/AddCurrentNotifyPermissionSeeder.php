<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\PermissionGroup;
use App\Models\Subgroup;

class AddCurrentNotifyPermissionSeeder extends Seeder
{
    public function run()
    {
        // Get permission group id
        $permissionGroups = PermissionGroup::pluck('id', 'name');
        
        $groupId = $permissionGroups['Configuration'] ?? null;

        if (!$groupId) {
            $this->command->error('Permission group "configuration" not found.');
            return;
        }

        // Get subgroup
        $subgroup = Subgroup::where('permission_group_id', $groupId)->first();

        if (!$subgroup) {
            $this->command->error('Subgroup not found for configuration group.');
            return;
        }

        // Permission data
        $permission = [
            'key' => 'configuration.current_notify',
            'name' => 'current notify',
            'subgroup_id' => $subgroup->id,
            'created_at' => now(),
            'updated_at' => now(),
        ];

        // Insert permission if not exists
        $permissionId = DB::table('permissions')
            ->where('key', $permission['key'])
            ->value('id');

        if (!$permissionId) {
            $permissionId = DB::table('permissions')->insertGetId($permission);
            $this->command->info('Permission created.');
        } else {
            $this->command->info('Permission already exists.');
        }

        // Assign to Super Admin role (id = 1)
        $exists = DB::table('role_responsibilities')
            ->where('role_id', 1)
            ->where('permission_id', $permissionId)
            ->exists();

        if (!$exists) {
            DB::table('role_responsibilities')->insert([
                'role_id' => 1,
                'permission_id' => $permissionId,
            ]);

            $this->command->info('Permission assigned to Super Admin.');
        } else {
            $this->command->info('Permission already assigned to Super Admin.');
        }

        $this->command->info('Current Notify permission seeded successfully.');
    }
}
