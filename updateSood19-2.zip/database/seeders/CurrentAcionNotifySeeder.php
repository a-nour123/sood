<?php

namespace Database\Seeders;

use App\Models\Action;
use Illuminate\Database\Seeder;

class CurrentAcionNotifySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Action::insert([
            ['id' => 175, 'name' => 'vuln_current_notify'],
            ['id' => 176, 'name' => 'incident_current_notify'],
            ['id' => 177, 'name' => 'phishing_current_notify'],
        ]);
    }
}
