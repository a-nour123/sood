<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\QueryException;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::table('risks', function (Blueprint $table) {
            if (!Schema::hasColumn('risks', 'current_control')) {
                $table->mediumText('current_control')->nullable()->after('notes');
            }
            if (!Schema::hasColumn('risks', 'responsible_department_id')) {
                $table->unsignedBigInteger('responsible_department_id')->nullable()->after('manager_id');
            }
            if (!Schema::hasColumn('risks', 'treatment_action')) {
                $table->string('treatment_action', 30)->nullable()->after('status'); // mitigate|avoid|transfer|accept
            }
            if (!Schema::hasColumn('risks', 'inherent_likelihood')) {
                $table->unsignedTinyInteger('inherent_likelihood')->nullable();
            }
            if (!Schema::hasColumn('risks', 'inherent_impact')) {
                $table->unsignedTinyInteger('inherent_impact')->nullable();
            }
            if (!Schema::hasColumn('risks', 'residual_likelihood')) {
                $table->unsignedTinyInteger('residual_likelihood')->nullable();
            }
            if (!Schema::hasColumn('risks', 'residual_impact')) {
                $table->unsignedTinyInteger('residual_impact')->nullable();
            }
            if (!Schema::hasColumn('risks', 'asset_rank_snapshot')) {
                $table->integer('asset_rank_snapshot')->nullable();
            }
        });

        Schema::table('mitigations', function (Blueprint $table) {
            if (!Schema::hasColumn('mitigations', 'treatment_due_date')) {
                $table->date('treatment_due_date')->nullable()->after('planning_date');
            }
            if (!Schema::hasColumn('mitigations', 'mitigation_nature')) {
                $table->json('mitigation_nature')->nullable(); // technical, physical, administrative
            }
            if (!Schema::hasColumn('mitigations', 'mitigation_function')) {
                $table->json('mitigation_function')->nullable(); // preventive, detective, ...
            }
            if (!Schema::hasColumn('mitigations', 'expected_result')) {
                $table->json('expected_result')->nullable(); // reduce_impact, reduce_likelihood
            }
            if (!Schema::hasColumn('mitigations', 'total_likelihood_reduction')) {
                $table->decimal('total_likelihood_reduction', 5, 2)->default(0);
            }
            if (!Schema::hasColumn('mitigations', 'total_impact_reduction')) {
                $table->decimal('total_impact_reduction', 5, 2)->default(0);
            }
        });

        if (!Schema::hasTable('mitigation_action_plans')) {
            Schema::create('mitigation_action_plans', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('mitigation_id');
                $table->unsignedBigInteger('risk_id')->nullable();
                $table->string('title')->nullable();
                $table->text('description')->nullable();
                $table->json('mitigation_nature')->nullable();
                $table->json('mitigation_function')->nullable();
                $table->decimal('likelihood_reduction', 5, 2)->default(0);
                $table->decimal('impact_reduction', 5, 2)->default(0);
                $table->date('due_date')->nullable();
                $table->unsignedBigInteger('owner_id')->nullable();
                $table->string('status', 30)->default('planned');
                $table->timestamps();
            });
        }

        if (!Schema::hasTable('risk_treatment_requests')) {
            Schema::create('risk_treatment_requests', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('risk_id');
                $table->string('treatment_type', 30); // avoid|transfer|accept
                $table->string('status', 40)->default('pending_risk_team'); // pending_risk_team|pending_ciso|pending_steering|approved|rejected
                $table->text('reason_description')->nullable();
                $table->unsignedBigInteger('decision_owner_id')->nullable();
                $table->date('decision_date')->nullable();
                $table->date('reevaluate_date')->nullable();
                $table->text('strategy_description')->nullable(); // avoidance strategy / approval statement
                $table->string('transfer_party_type', 20)->nullable(); // internal|external
                $table->text('transfer_party_description')->nullable();
                $table->json('transferred_action_plan_ids')->nullable();
                $table->unsignedBigInteger('started_by')->nullable();
                $table->unsignedBigInteger('risk_team_reviewed_by')->nullable();
                $table->timestamp('risk_team_reviewed_at')->nullable();
                $table->unsignedBigInteger('ciso_reviewed_by')->nullable();
                $table->timestamp('ciso_reviewed_at')->nullable();
                $table->unsignedBigInteger('steering_reviewed_by')->nullable();
                $table->timestamp('steering_reviewed_at')->nullable();
                $table->text('review_comments')->nullable();
                $table->timestamps();

                $table->index(['risk_id', 'status']);
            });
        }

        if (!Schema::hasTable('risk_appetite_statements')) {
            Schema::create('risk_appetite_statements', function (Blueprint $table) {
                $table->id();
                $table->longText('statement')->nullable();
                $table->unsignedBigInteger('updated_by')->nullable();
                $table->timestamps();
            });
        }

        if (!Schema::hasTable('vulnerability_catalogs')) {
            Schema::create('vulnerability_catalogs', function (Blueprint $table) {
                $table->id();
                $table->string('number')->nullable();
                $table->string('name');
                $table->text('description')->nullable();
                $table->unsignedBigInteger('risk_catalog_id')->nullable();
                $table->unsignedBigInteger('grouping_id')->nullable();
                $table->boolean('is_active')->default(true);
                $table->timestamps();
            });
        }

        // Foreign keys need the REFERENCES privilege on the parent table.
        // Some client DB users can CREATE/ALTER but cannot add these constraints.
        $this->addForeignKeyIfPossible('mitigation_action_plans', 'mitigation_id', 'mitigations', 'cascade');
        $this->addForeignKeyIfPossible('mitigation_action_plans', 'risk_id', 'risks', 'set null');
        $this->addForeignKeyIfPossible('mitigation_action_plans', 'owner_id', 'users', 'set null');
        $this->addForeignKeyIfPossible('risk_treatment_requests', 'risk_id', 'risks', 'cascade');
        $this->addForeignKeyIfPossible('risk_treatment_requests', 'decision_owner_id', 'users', 'set null');
        $this->addForeignKeyIfPossible('risk_treatment_requests', 'started_by', 'users', 'set null');
        $this->addForeignKeyIfPossible('risk_appetite_statements', 'updated_by', 'users', 'set null');
        $this->addForeignKeyIfPossible('vulnerability_catalogs', 'risk_catalog_id', 'risk_catalogs', 'set null');

        (new \Database\Seeders\KsuRiskManagementSeeder())->run();
    }

    /**
     * Add one foreign key. Skip it when MySQL/MariaDB denies REFERENCES (error 1142)
     * so the migration can finish on a restricted client database user.
     */
    private function addForeignKeyIfPossible($table, $column, $referenced, $onDelete)
    {
        if (!Schema::hasTable($table) || !Schema::hasTable($referenced) || !Schema::hasColumn($table, $column)) {
            return;
        }

        if ($this->foreignKeyExists($table, $column)) {
            return;
        }

        try {
            Schema::table($table, function (Blueprint $blueprint) use ($column, $referenced, $onDelete) {
                $foreign = $blueprint->foreign($column)->references('id')->on($referenced);
                if ($onDelete === 'cascade') {
                    $foreign->cascadeOnDelete();
                } else {
                    $foreign->nullOnDelete();
                }
            });
        } catch (QueryException $e) {
            if (!$this->isReferencesDenied($e)) {
                throw $e;
            }

            Log::warning('Skipped foreign key because REFERENCES is denied.', [
                'table' => $table,
                'column' => $column,
                'references' => $referenced,
            ]);
        }
    }

    private function foreignKeyExists($table, $column)
    {
        $connection = Schema::getConnection();
        if ($connection->getDriverName() !== 'mysql') {
            return false;
        }

        $rows = $connection->select(
            'select CONSTRAINT_NAME from information_schema.KEY_COLUMN_USAGE
             where TABLE_SCHEMA = ? and TABLE_NAME = ? and COLUMN_NAME = ? and REFERENCED_TABLE_NAME is not null
             limit 1',
            [$connection->getDatabaseName(), $table, $column]
        );

        return !empty($rows);
    }

    private function isReferencesDenied(QueryException $e)
    {
        $code = isset($e->errorInfo[1]) ? (int) $e->errorInfo[1] : 0;

        return $code === 1142 || strpos($e->getMessage(), 'REFERENCES command denied') !== false;
    }

    public function down()
    {
        Schema::dropIfExists('mitigation_action_plans');
        Schema::dropIfExists('risk_treatment_requests');
        Schema::dropIfExists('risk_appetite_statements');
        Schema::dropIfExists('vulnerability_catalogs');

        Schema::table('risks', function (Blueprint $table) {
            foreach ([
                'current_control', 'responsible_department_id', 'treatment_action',
                'inherent_likelihood', 'inherent_impact', 'residual_likelihood',
                'residual_impact', 'asset_rank_snapshot',
            ] as $col) {
                if (Schema::hasColumn('risks', $col)) {
                    $table->dropColumn($col);
                }
            }
        });

        Schema::table('mitigations', function (Blueprint $table) {
            foreach ([
                'treatment_due_date', 'mitigation_nature', 'mitigation_function',
                'expected_result', 'total_likelihood_reduction', 'total_impact_reduction',
            ] as $col) {
                if (Schema::hasColumn('mitigations', $col)) {
                    $table->dropColumn($col);
                }
            }
        });
    }
};
