<div class="content-header row">
    <div class="content-header-left col-12 mb-2">
        <div class="row breadcrumbs-top widget-grid">
            <div class="col-12">
                <div class="page-title mt-2">
                    <div class="row">
                        <div class="col-sm-6 ps-0">
                            @if (@isset($breadcrumbs))
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}"><i data-feather="home"></i></a></li>
                                    @foreach ($breadcrumbs as $breadcrumb)
                                        <li class="breadcrumb-item">
                                            @if (isset($breadcrumb['link']))<a href="{{ $breadcrumb['link'] }}">@endif
                                            {{ $breadcrumb['name'] }}
                                            @if (isset($breadcrumb['link']))</a>@endif
                                        </li>
                                    @endforeach
                                </ol>
                            @endif
                        </div>
                        <div class="col-sm-6 pe-0" style="text-align: end;">
                            <div class="action-content">
                                @if (!empty($permission) && auth()->user()->hasPermission($permission))
                                    <button class="btn btn-primary governance-open-create" type="button" data-bs-toggle="modal" data-bs-target="#governance-modal" title="{{ __('governance.Add') }}">
                                        <i class="fa fa-plus"></i>
                                    </button>
                                @endif
                                @if (auth()->user()->hasPermission('committee_notification.create'))
                                    <a class="btn btn-primary" href="{{ route('admin.committee.settings.notifications') }}" title="{{ __('locale.NotificationsSettings') }}">
                                        <i class="fa fa-regular fa-bell"></i>
                                    </a>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
