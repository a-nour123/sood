@section('vendor-style')
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/dataTables.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/responsive.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
@endsection
@section('page-style')
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
@endsection
@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/tables/datatable/jquery.dataTables.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.bootstrap5.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
@endsection
@section('page-script')
    <script>
        window.GovernanceConfig = {
            listUrl: @json($screen['listUrl']),
            storeUrl: @json($screen['storeUrl']),
            updateUrl: @json($screen['updateUrl']),
            editUrl: @json($screen['editUrl']),
            deleteUrl: @json($screen['deleteUrl']),
            showUrl: @json($screen['showUrl'] ?? ''),
            permissions: {
                show: {{ !empty($screen['canShow']) ? 'true' : 'false' }},
                edit: {{ !empty($screen['canEdit']) ? 'true' : 'false' }},
                delete: {{ !empty($screen['canDelete']) ? 'true' : 'false' }}
            },
            labels: {
                view: @json(__('locale.View')),
                edit: @json(__('locale.Edit')),
                delete: @json(__('locale.Delete')),
                confirm: @json(__('locale.AreYouSureToDeleteThisRecord')),
                cancel: @json(__('locale.Cancel'))
            },
            columns: @json($screen['dataColumns'])
        };
    </script>
    <script>
{!! \Illuminate\Support\Facades\Blade::render(file_get_contents(public_path('ajax-files/committee/list.js'))) !!}
    </script>
@endsection
