@include('admin.content.committee.partials.heading', ['title' => $screen['title'], 'permission' => $screen['permission']])
<div class="card mb-1">
    <div class="card-body">
        <form id="governance-filters" class="governance-live-filter row g-1">
            @foreach ($screen['filters'] as $filter)
                <div class="col-md-3">
                    <label class="form-label">{{ $filter['label'] }}</label>
                    @if ($filter['type'] === 'select')
                        <select class="form-select" name="{{ $filter['name'] }}">
                            <option value="">{{ __('locale.SelectOption') }}</option>
                            @foreach ($filter['options'] as $value => $label)
                                <option value="{{ $value }}">{{ $label }}</option>
                            @endforeach
                        </select>
                    @else
                        <input class="form-control" type="{{ $filter['type'] }}" name="{{ $filter['name'] }}">
                    @endif
                </div>
            @endforeach
        </form>
    </div>
</div>
<div class="card">
    <div class="table-responsive">
        <table class="table" id="governance-table">
            <thead>
                <tr>
                    @foreach ($screen['columns'] as $column)
                        <th>{{ $column }}</th>
                    @endforeach
                </tr>
            </thead>
        </table>
    </div>
</div>
<div class="modal fade" id="governance-modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <form id="governance-form" class="modal-content">
            @csrf
            <input type="hidden" name="id">
            <input type="hidden" name="idempotency_key">
            <div class="modal-header"><h5 class="modal-title">{{ $screen['title'] }}</h5><button class="btn-close" type="button" data-bs-dismiss="modal"></button></div>
            <div class="modal-body row g-1">
                @foreach ($screen['fields'] as $field)
                    @if (($field['type'] ?? '') === 'hidden')
                        <input type="hidden" name="{{ $field['name'] }}" value="{{ $field['value'] ?? '' }}">
                        @continue
                    @endif
                    <div class="{{ $field['class'] ?? 'col-md-6' }}">
                        <label class="form-label">{{ $field['label'] }}</label>
                        @if (($field['type'] ?? 'text') === 'textarea')
                            <textarea class="form-control" name="{{ $field['name'] }}" rows="3"></textarea>
                        @elseif (($field['type'] ?? '') === 'select')
                            <select class="form-select" name="{{ $field['name'] }}">
                                <option value="">{{ __('locale.SelectOption') }}</option>
                                @foreach ($field['options'] as $value => $label)
                                    <option value="{{ $value }}" @if(isset($field['departments'][$value])) data-department="{{ $field['departments'][$value] }}" @endif>{{ $label }}</option>
                                @endforeach
                            </select>
                        @elseif (($field['type'] ?? '') === 'hidden')
                            <input type="hidden" name="{{ $field['name'] }}" value="{{ $field['value'] ?? '' }}">
                        @else
                            <input class="form-control" type="{{ $field['type'] ?? 'text' }}" name="{{ $field['name'] }}" value="{{ $field['default'] ?? '' }}">
                        @endif
                        <small class="text-danger governance-error governance-error-{{ $field['name'] }}"></small>
                    </div>
                @endforeach
            </div>
            <div class="modal-footer"><button class="btn btn-primary" type="submit">{{ __('locale.Save') }}</button></div>
        </form>
    </div>
</div>
