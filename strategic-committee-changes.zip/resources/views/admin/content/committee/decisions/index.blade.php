@extends('admin/layouts/contentLayoutMaster')
@section('title', __('locale.ApprovalHistory'))
@section('content')
    @include('admin.content.committee.partials.heading', ['permission' => null])
    <div class="card"><div class="table-responsive"><table class="table">
        <thead><tr><th>{{ __('governance.headings.Number') }}</th><th>{{ __('governance.headings.Request') }}</th><th>{{ __('governance.Decision') }}</th><th>{{ __('governance.headings.By') }}</th><th>{{ __('governance.Status') }}</th></tr></thead>
        <tbody>
        @forelse ($decisions as $decision)
            <tr>
                <td>{{ $decision->decision_number }}</td>
                <td><a href="{{ route('admin.committee.requests.show', $decision->governance_request_id) }}">{{ optional($decision->request)->request_number }}</a></td>
                <td>{{ __('governance.decisions.' . $decision->decision_type) }}</td>
                <td>{{ optional($decision->decider)->name }}</td>
                <td>{{ $decision->status }}</td>
            </tr>
        @empty
            <tr><td colspan="5">{{ __('governance.NotFound') }}</td></tr>
        @endforelse
        </tbody>
    </table></div></div>
@endsection
