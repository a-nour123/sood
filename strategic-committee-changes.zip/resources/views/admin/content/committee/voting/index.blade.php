@extends('admin/layouts/contentLayoutMaster')
@section('title', __('locale.VotingRecommendations'))
@section('content')
    @include('admin.content.committee.partials.heading', ['permission' => null])
    <div class="card"><div class="table-responsive"><table class="table">
        <thead><tr><th>{{ __('governance.headings.Request') }}</th><th>{{ __('governance.Committee') }}</th><th>{{ __('governance.Status') }}</th><th>{{ __('governance.DueDate') }}</th></tr></thead>
        <tbody>
        @forelse ($sessions as $session)
            <tr>
                <td><a href="{{ route('admin.committee.requests.show', $session->governance_request_id) }}">{{ optional($session->request)->request_number }}</a></td>
                <td>{{ optional($session->committee)->name }}</td>
                <td>{{ $session->status }}</td>
                <td>{{ optional($session->deadline)->toDateString() }}</td>
            </tr>
        @empty
            <tr><td colspan="4">{{ __('governance.NotFound') }}</td></tr>
        @endforelse
        </tbody>
    </table></div></div>
@endsection
