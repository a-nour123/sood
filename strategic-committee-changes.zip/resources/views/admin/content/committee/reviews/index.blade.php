@extends('admin/layouts/contentLayoutMaster')
@section('title', __('locale.ReviewsDecisions'))
@section('content')
    @include('admin.content.committee.partials.heading', ['permission' => null])
    <div class="card"><div class="card-body">
        <p>{{ __('governance.Reviews') }}</p>
        <a class="btn btn-primary" href="{{ route('admin.committee.reports.index', ['type' => 'reviews']) }}">{{ __('locale.GovernanceReports') }}</a>
        <a class="btn btn-outline-primary" href="{{ route('admin.committee.requests.index') }}">{{ __('locale.GovernanceRequests') }}</a>
    </div></div>
@endsection
