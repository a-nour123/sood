@extends('admin/layouts/contentLayoutMaster')
@section('title', __('locale.GovernanceDashboard'))
@section('content')
    @include('admin.content.committee.partials.heading', ['permission' => null])
    <form class="card mb-1" method="GET">
        <div class="card-body row g-1">
            <div class="col-md-3"><label class="form-label">{{ __('governance.Committee') }}</label><select class="form-select" name="committee_id"><option value="">{{ __('locale.SelectOption') }}</option>@foreach ($committees as $id => $name)<option value="{{ $id }}" {{ (string)($filters['committee_id'] ?? '') === (string)$id ? 'selected' : '' }}>{{ $name }}</option>@endforeach</select></div>
            <div class="col-md-3"><label class="form-label">{{ __('governance.Department') }}</label><select class="form-select" name="department_id"><option value="">{{ __('locale.SelectOption') }}</option>@foreach ($departments as $id => $name)<option value="{{ $id }}" {{ (string)($filters['department_id'] ?? '') === (string)$id ? 'selected' : '' }}>{{ $name }}</option>@endforeach</select></div>
            <div class="col-md-2"><label class="form-label">{{ __('governance.Type') }}</label><select class="form-select" name="request_type"><option value="">{{ __('locale.SelectOption') }}</option>@foreach (__('governance.request_types') as $key => $label)<option value="{{ $key }}" {{ ($filters['request_type'] ?? '') === $key ? 'selected' : '' }}>{{ $label }}</option>@endforeach</select></div>
            <div class="col-md-2"><label class="form-label">{{ __('governance.Status') }}</label><select class="form-select" name="status"><option value="">{{ __('locale.SelectOption') }}</option>@foreach (__('governance.statuses') as $key => $label)<option value="{{ $key }}" {{ ($filters['status'] ?? '') === $key ? 'selected' : '' }}>{{ $label }}</option>@endforeach</select></div>
            <div class="col-md-2"><label class="form-label">{{ __('governance.Priority') }}</label><select class="form-select" name="priority"><option value="">{{ __('locale.SelectOption') }}</option>@foreach (__('governance.priorities') as $key => $label)<option value="{{ $key }}" {{ ($filters['priority'] ?? '') === $key ? 'selected' : '' }}>{{ $label }}</option>@endforeach</select></div>
            <div class="col-md-2"><label class="form-label">{{ __('governance.DueDate') }}</label><input class="form-control" type="date" name="date_from" value="{{ $filters['date_from'] ?? '' }}"></div>
            <div class="col-md-2"><label class="form-label">{{ __('governance.EffectiveUntil') }}</label><input class="form-control" type="date" name="date_to" value="{{ $filters['date_to'] ?? '' }}"></div>
            <div class="col-md-2"><label class="form-label">{{ __('governance.Decision') }}</label><input class="form-control" type="date" name="decision_from" value="{{ $filters['decision_from'] ?? '' }}"></div>
            <div class="col-md-2"><label class="form-label">&nbsp;</label><input class="form-control" type="date" name="decision_to" value="{{ $filters['decision_to'] ?? '' }}"></div>
            <div class="col-md-2"><label class="form-label">{{ __('governance.Owner') }}</label><select class="form-select" name="owner_id"><option value="">{{ __('locale.SelectOption') }}</option>@foreach ($options['users'] as $user)<option value="{{ $user->id }}" {{ (string)($filters['owner_id'] ?? '') === (string)$user->id ? 'selected' : '' }}>{{ $user->name }}</option>@endforeach</select></div>
            <div class="col-md-2 d-flex align-items-end"><button class="btn btn-primary" type="submit">{{ __('locale.Search') }}</button></div>
        </div>
    </form>
    <div class="row">
        @foreach ($stats['cards'] as $key => $value)
            <div class="col-xl-3 col-md-4 col-sm-6 mb-1"><a class="card h-100" href="{{ route('admin.committee.requests.index') }}"><div class="card-body"><small class="text-muted">{{ __('governance.cards.' . $key) }}</small><h3 class="mb-0">{{ $value }}</h3></div></a></div>
        @endforeach
    </div>
    <div class="card mb-1"><div class="card-body"><strong>{{ __('governance.AverageDecisionHours') }}:</strong> {{ $stats['charts']['average_hours'] }}</div></div>
    <div class="row">
        @foreach (['types', 'statuses', 'decisions', 'workload', 'departments', 'risks'] as $chart)
            <div class="col-lg-4 mb-1"><div class="card"><div class="card-header">{{ __('governance.charts.' . $chart) }}</div><div class="card-body"><div id="chart-{{ $chart }}"></div></div></div></div>
        @endforeach
        <div class="col-lg-6 mb-1"><div class="card"><div class="card-header">{{ __('governance.charts.monthly') }}</div><div class="card-body"><div id="chart-monthly"></div></div></div></div>
        <div class="col-lg-6 mb-1"><div class="card"><div class="card-header">{{ __('governance.charts.expirations') }}</div><div class="card-body"><div id="chart-expirations"></div></div></div></div>
    </div>
@endsection
@section('page-script')
    <script src="{{ asset(mix('vendors/js/charts/apexcharts.min.js')) }}"></script>
    <script>
        const charts = @json($stats['charts']);
        const names = { committees: @json($committees), departments: @json($departments) };
        function labeled(source, dictionary) {
            const labels = []; const series = [];
            Object.keys(source || {}).forEach(function (key) {
                labels.push(dictionary && dictionary[key] ? dictionary[key] : key);
                series.push(Number(source[key]));
            });
            return { labels: labels, series: series };
        }
        function donut(id, pack) {
            if (!pack.series.length || !document.querySelector(id)) return;
            new ApexCharts(document.querySelector(id), { chart: { type: 'donut', height: 280 }, labels: pack.labels, series: pack.series, legend: { position: 'bottom' } }).render();
        }
        donut('#chart-types', labeled(charts.types, @json(__('governance.request_types'))));
        donut('#chart-statuses', labeled(charts.statuses, @json(__('governance.statuses'))));
        donut('#chart-decisions', labeled(charts.decisions, @json(__('governance.decisions'))));
        donut('#chart-workload', labeled(charts.workload, names.committees));
        donut('#chart-departments', labeled(charts.departments, names.departments));
        donut('#chart-risks', labeled(charts.risks, @json(__('governance.risk_outcomes'))));
        new ApexCharts(document.querySelector('#chart-monthly'), { chart: { type: 'bar', height: 280, toolbar: { show: false } }, series: [{ name: @json(__('governance.charts.monthly')), data: charts.monthly }], xaxis: { categories: ['1','2','3','4','5','6','7','8','9','10','11','12'] } }).render();
        new ApexCharts(document.querySelector('#chart-expirations'), { chart: { type: 'bar', height: 280, toolbar: { show: false } }, series: [{ name: @json(__('governance.charts.expirations')), data: charts.expirations }], xaxis: { categories: ['1','2','3','4','5','6','7','8','9','10','11','12'] } }).render();
    </script>
@endsection
