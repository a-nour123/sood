@extends('admin/layouts/contentLayoutMaster')
@section('title', __('locale.GovernanceReports'))
@section('content')
    @include('admin.content.committee.partials.heading', ['permission' => null])
    <form class="card mb-1" method="GET">
        <div class="card-body row g-1">
            <div class="col-md-3"><select class="form-select" name="type">@foreach (__('governance.report_types') as $key => $label)<option value="{{ $key }}" {{ $type === $key ? 'selected' : '' }}>{{ $label }}</option>@endforeach</select></div>
            <div class="col-md-2"><select class="form-select" name="status"><option value="">{{ __('locale.SelectOption') }}</option>@foreach (__('governance.statuses') as $key => $label)<option value="{{ $key }}" {{ ($filters['status'] ?? '') === $key ? 'selected' : '' }}>{{ $label }}</option>@endforeach</select></div>
            <div class="col-md-2"><button class="btn btn-primary" type="submit">{{ __('locale.Search') }}</button></div>
            @if (auth()->user()->hasPermission('export_governance_reports'))
                <div class="col-md-2"><a class="btn btn-outline-primary" href="{{ route('admin.committee.reports.excel', request()->query()) }}">Excel</a></div>
                <div class="col-md-2"><a class="btn btn-outline-primary" href="{{ route('admin.committee.reports.pdf', request()->query()) }}">PDF</a></div>
            @endif
        </div>
    </form>
    <div class="card"><div class="table-responsive"><table class="table">
        <thead><tr>@foreach ($headings as $heading)<th>{{ $heading }}</th>@endforeach</tr></thead>
        <tbody>
        @forelse ($rows as $row)
            <tr>@foreach ($row as $cell)<td>{{ $cell }}</td>@endforeach</tr>
        @empty
            <tr><td colspan="{{ count($headings) }}">{{ __('governance.NotFound') }}</td></tr>
        @endforelse
        </tbody>
    </table></div></div>
@endsection
