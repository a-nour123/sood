@extends('admin/layouts/contentLayoutMaster')
@section('title', $committee->name)
@section('content')
    @include('admin.content.committee.partials.heading', ['permission' => null])
    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <h4>{{ $committee->name }} <small class="text-muted">{{ $committee->code }}</small></h4>
                    <p>{{ $committee->description }}</p>
                    <p><strong>{{ __('governance.Type') }}:</strong> {{ optional($committee->type)->name }}</p>
                    <p><strong>{{ __('governance.Mode') }}:</strong> {{ __('governance.approval_modes.' . $committee->approval_mode) }}</p>
                    <p><strong>{{ __('governance.Status') }}:</strong> {{ __('governance.committee_statuses.' . $committee->status) }}</p>
                    <p>{{ $committee->responsibilities }}</p>
                </div>
            </div>
            <div class="card">
                <div class="card-header"><h4>{{ __('governance.Members') }}</h4></div>
                <div class="table-responsive">
                    <table class="table">
                        <thead><tr><th>{{ __('governance.Name') }}</th><th>{{ __('governance.Department') }}</th><th>{{ __('governance.headings.Role') }}</th><th>{{ __('governance.Status') }}</th><th></th></tr></thead>
                        <tbody>
                        @foreach ($committee->members as $member)
                            <tr>
                                <td>{{ optional($member->user)->name }}</td>
                                <td>{{ optional($member->department)->name }}</td>
                                <td>{{ __('governance.member_roles.' . $member->member_role) }}</td>
                                <td>{{ __('governance.member_statuses.' . $member->status) }}</td>
                                <td>
                                    @if ($canMembers)
                                        <button class="btn btn-sm btn-outline-danger member-remove" data-id="{{ $member->id }}" type="button">{{ __('locale.Delete') }}</button>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            @if ($canDepartments)
                <div class="card"><div class="card-body">
                    <h5>{{ __('governance.Departments') }}</h5>
                    <ul>
                        @foreach ($committee->departmentLinks->whereNull('removed_at') as $link)
                            <li>{{ optional($link->department)->name }}
                                <button class="btn btn-sm btn-link department-remove" data-id="{{ $link->department_id }}" type="button">{{ __('locale.Delete') }}</button>
                            </li>
                        @endforeach
                    </ul>
                    <form id="department-form" class="row g-1">
                        <div class="col-12">
                            <select class="form-select" name="department_id">
                                <option value="">{{ __('locale.SelectOption') }}</option>
                                @foreach ($options['departments'] as $department)
                                    <option value="{{ $department->id }}">{{ $department->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-12"><button class="btn btn-primary" type="submit">{{ __('governance.Add') }}</button></div>
                    </form>
                </div></div>
            @endif
            @if ($canMembers)
                <div class="card"><div class="card-body">
                    <h5>{{ __('governance.Add') }}</h5>
                    <form id="member-form" class="row g-1">
                        <div class="col-12">
                            <select class="form-select" name="department_id" id="member-department">
                                <option value="">{{ __('locale.SelectOption') }}</option>
                                @foreach ($committee->departmentLinks->whereNull('removed_at') as $link)
                                    <option value="{{ $link->department_id }}">{{ optional($link->department)->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-12">
                            <select class="form-select" name="user_id" id="member-user"><option value="">{{ __('locale.SelectOption') }}</option></select>
                        </div>
                        <div class="col-12">
                            <select class="form-select" name="member_role">
                                <option value="">{{ __('locale.SelectOption') }}</option>
                                @foreach ($roles as $role)
                                    <option value="{{ $role }}">{{ __('governance.member_roles.' . $role) }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-6"><input class="form-control" type="date" name="effective_from"></div>
                        <div class="col-6"><input class="form-control" type="date" name="effective_until"></div>
                        <div class="col-12"><button class="btn btn-primary" type="submit">{{ __('locale.Save') }}</button></div>
                    </form>
                </div></div>
            @endif
            @if ($canSettings)
                <div class="card"><div class="card-body">
                    <h5>{{ __('governance.RequestTypes') }}</h5>
                    <form id="types-form">
                        @foreach (['approval', 'exception', 'risk_acceptance'] as $requestType)
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="request_types[]" value="{{ $requestType }}" {{ $committee->requestTypes->contains('request_type', $requestType) ? 'checked' : '' }}>
                                <label class="form-check-label">{{ __('governance.request_types.' . $requestType) }}</label>
                            </div>
                        @endforeach
                        <button class="btn btn-primary mt-1" type="submit">{{ __('locale.Save') }}</button>
                    </form>
                </div></div>
            @endif
        </div>
    </div>
@endsection
@section('vendor-style')
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
@endsection
@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
@endsection
@section('page-script')
    <script>
        const token = $('meta[name="csrf-token"]').attr('content');
        function governanceDone(xhr, ok) {
            var responseData = (xhr && xhr.responseJSON) ? xhr.responseJSON : {};
            if (ok) {
                makeAlert('success', responseData.message, "{{ __('locale.Success') }}");
                window.setTimeout(function () { window.location.reload(); }, 600);
            } else {
                makeAlert('error', responseData.message, "{{ __('locale.Error') }}");
            }
        }
        $('#department-form').on('submit', function (event) {
            event.preventDefault();
            $.post(@json(route('admin.committee.committees.departments.store', $committee->id)), $(this).serialize() + '&_token=' + token)
                .done(function (response) { governanceDone({ responseJSON: response }, true); })
                .fail(function (xhr) { governanceDone(xhr, false); });
        });
        $('.department-remove').on('click', function () {
            $.ajax({ url: @json(route('admin.committee.committees.departments.destroy', ['id' => $committee->id, 'departmentId' => 0])).replace('/0', '/' + $(this).data('id')), type: 'DELETE', data: { _token: token } })
                .done(function (response) { governanceDone({ responseJSON: response }, true); })
                .fail(function (xhr) { governanceDone(xhr, false); });
        });
        $('#member-department').on('change', function () {
            $.get(@json(route('admin.committee.lookups.users')), { department_id: $(this).val() }, function (response) {
                const select = $('#member-user').empty().append($('<option>', { value: '', text: @json(__('locale.SelectOption')) }));
                (response.data || []).forEach(function (user) {
                    select.append($('<option>').val(user.id).text(user.name));
                });
            });
        });
        $('#member-form').on('submit', function (event) {
            event.preventDefault();
            $.post(@json(route('admin.committee.committees.members.store', $committee->id)), $(this).serialize() + '&_token=' + token)
                .done(function (response) { governanceDone({ responseJSON: response }, true); })
                .fail(function (xhr) { governanceDone(xhr, false); });
        });
        $('.member-remove').on('click', function () {
            $.ajax({ url: @json(route('admin.committee.committees.members.destroy', ['id' => $committee->id, 'memberId' => 0])).replace('/0', '/' + $(this).data('id')), type: 'DELETE', data: { _token: token } })
                .done(function (response) { governanceDone({ responseJSON: response }, true); })
                .fail(function (xhr) { governanceDone(xhr, false); });
        });
        $('#types-form').on('submit', function (event) {
            event.preventDefault();
            $.post(@json(route('admin.committee.committees.request-types', $committee->id)), $(this).serialize() + '&_token=' + token)
                .done(function (response) { governanceDone({ responseJSON: response }, true); })
                .fail(function (xhr) { governanceDone(xhr, false); });
        });
    </script>
@endsection
