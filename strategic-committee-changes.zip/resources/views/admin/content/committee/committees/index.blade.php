@extends('admin/layouts/contentLayoutMaster')
@section('title', __('locale.Committees'))
@php
    $types = [];
    foreach ($options['types'] as $type) { $types[$type->id] = $type->name; }
    $screen = [
        'title' => __('locale.Committees'),
        'permission' => 'create_committee',
        'canShow' => true,
        'canEdit' => auth()->user()->hasPermission('update_committee'),
        'canDelete' => auth()->user()->hasPermission('delete_committee'),
        'listUrl' => route('admin.committee.committees.ajax.index'),
        'storeUrl' => route('admin.committee.committees.ajax.store'),
        'updateUrl' => route('admin.committee.committees.ajax.update', ['id' => '__ID__']),
        'editUrl' => route('admin.committee.committees.ajax.edit', ['id' => '__ID__']),
        'deleteUrl' => route('admin.committee.committees.ajax.destroy', ['id' => '__ID__']),
        'showUrl' => route('admin.committee.committees.show', ['id' => '__ID__']),
        'filters' => [
            ['name' => 'status', 'label' => __('governance.Status'), 'type' => 'select', 'options' => __('governance.committee_statuses')],
        ],
        'columns' => [__('governance.Name'), __('governance.Code'), __('governance.Type'), __('governance.Status'), __('governance.Mode'), ''],
        'dataColumns' => [
            ['data' => 'name'], ['data' => 'code'], ['data' => 'type'], ['data' => 'status'], ['data' => 'mode'], ['data' => 'Actions'],
        ],
        'fields' => [
            ['name' => 'name', 'label' => __('governance.Name')],
            ['name' => 'code', 'label' => __('governance.Code')],
            ['name' => 'committee_type_id', 'label' => __('governance.Type'), 'type' => 'select', 'options' => $types],
            ['name' => 'status', 'label' => __('governance.Status'), 'type' => 'select', 'options' => __('governance.committee_statuses')],
            ['name' => 'approval_mode', 'label' => __('governance.Mode'), 'type' => 'select', 'options' => __('governance.approval_modes')],
            ['name' => 'minimum_approval_count', 'label' => __('governance.MinimumApprovals'), 'type' => 'number', 'default' => 1],
            ['name' => 'voting_threshold', 'label' => __('governance.Threshold'), 'type' => 'number', 'default' => 50],
            ['name' => 'quorum_count', 'label' => __('governance.Quorum'), 'type' => 'number', 'default' => 0],
            ['name' => 'allow_vote_change', 'label' => __('governance.VoteChange'), 'type' => 'select', 'options' => ['0' => __('governance.No'), '1' => __('governance.Yes')]],
            ['name' => 'effective_from', 'label' => __('governance.EffectiveFrom'), 'type' => 'date'],
            ['name' => 'effective_until', 'label' => __('governance.EffectiveUntil'), 'type' => 'date'],
            ['name' => 'description', 'label' => __('governance.Description'), 'type' => 'textarea', 'class' => 'col-12'],
            ['name' => 'responsibilities', 'label' => __('governance.Responsibilities'), 'type' => 'textarea', 'class' => 'col-12'],
        ],
    ];
@endphp
@section('content')
    @include('admin.content.committee.partials.crud')
@endsection
@include('admin.content.committee.partials.crud-assets')
