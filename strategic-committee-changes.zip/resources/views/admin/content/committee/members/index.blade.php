@extends('admin/layouts/contentLayoutMaster')
@section('title', __('locale.CommitteeMembers'))
@php
    $committees = [];
    foreach ($options['committees'] as $committee) { $committees[$committee->id] = $committee->name; }
    $screen = [
        'title' => __('locale.CommitteeMembers'),
        'permission' => null,
        'canShow' => true,
        'canEdit' => false,
        'canDelete' => false,
        'listUrl' => route('admin.committee.members.ajax.index'),
        'storeUrl' => route('admin.committee.members.ajax.index'),
        'updateUrl' => route('admin.committee.members.ajax.index'),
        'editUrl' => route('admin.committee.members.ajax.index'),
        'deleteUrl' => route('admin.committee.members.ajax.index'),
        'showUrl' => route('admin.committee.committees.show', ['id' => '__ID__']),
        'filters' => [
            ['name' => 'committee_id', 'label' => __('governance.Committee'), 'type' => 'select', 'options' => $committees],
            ['name' => 'status', 'label' => __('governance.Status'), 'type' => 'select', 'options' => __('governance.member_statuses')],
            ['name' => 'member_role', 'label' => __('governance.headings.Role'), 'type' => 'select', 'options' => __('governance.member_roles')],
        ],
        'columns' => [__('governance.Committee'), __('governance.headings.Member'), __('governance.Department'), __('governance.headings.Role'), __('governance.headings.Voting'), __('governance.Status'), ''],
        'dataColumns' => [
            ['data' => 'committee'], ['data' => 'member'], ['data' => 'department'], ['data' => 'role'], ['data' => 'voting'], ['data' => 'status'], ['data' => 'Actions'],
        ],
        'fields' => [],
    ];
@endphp
@section('content')
    @include('admin.content.committee.partials.crud')
@endsection
@include('admin.content.committee.partials.crud-assets')
