@extends('admin/layouts/contentLayoutMaster')
@section('title', $title)
@php
    $departments = [];
    foreach ($options['departments'] as $department) { $departments[$department->id] = $department->name; }
    $users = [];
    $userDepartments = [];
    foreach ($options['users'] as $user) { $users[$user->id] = $user->name; $userDepartments[$user->id] = $user->department_id; }
    $committees = [];
    foreach ($options['committees'] as $committee) { $committees[$committee->id] = $committee->name; }
    $categories = [];
    foreach ($options['categories'] as $category) {
        if (!$type || $category->request_type === $type) { $categories[$category->id] = $category->name; }
    }
    $documents = [];
    foreach ($options['documents'] as $document) { $documents[$document->id] = $document->document_name; }
    $frameworks = [];
    foreach ($options['frameworks'] as $framework) { $frameworks[$framework->id] = $framework->name; }
    $families = [];
    foreach ($options['families'] as $family) { $families[$family->id] = $family->name; }
    $controls = [];
    foreach ($options['controls'] as $control) { $controls[$control->id] = trim($control->control_number . ' ' . $control->short_name); }
    $exceptions = [];
    foreach ($options['exceptions'] as $exception) { $exceptions[$exception->id] = $exception->name; }
    $risks = [];
    foreach ($options['risks'] as $risk) { $risks[$risk->id] = trim(($risk->reference_id ? $risk->reference_id . ' - ' : '') . $risk->subject); }
    $permission = $type === 'approval' ? 'manage_approval_requests' : ($type === 'exception' ? 'manage_exception_requests' : ($type === 'risk_acceptance' ? 'manage_risk_acceptance_requests' : 'create_governance_request'));
    $fields = [
        $type
            ? ['name' => 'request_type', 'type' => 'hidden', 'value' => $type]
            : ['name' => 'request_type', 'label' => __('governance.Type'), 'type' => 'select', 'options' => __('governance.request_types')],
        ['name' => 'title', 'label' => __('governance.Title')],
        ['name' => 'category_id', 'label' => __('governance.Category'), 'type' => 'select', 'options' => $categories],
        ['name' => 'department_id', 'label' => __('governance.Department'), 'type' => 'select', 'options' => $departments],
        ['name' => 'assigned_committee_id', 'label' => __('governance.Committee'), 'type' => 'select', 'options' => $committees],
        ['name' => 'priority', 'label' => __('governance.Priority'), 'type' => 'select', 'options' => __('governance.priorities')],
        ['name' => 'due_date', 'label' => __('governance.DueDate'), 'type' => 'date'],
        ['name' => 'description', 'label' => __('governance.Description'), 'type' => 'textarea', 'class' => 'col-12'],
    ];
    if ($type === 'approval' || $type === null) {
        $fields[] = ['name' => 'business_justification', 'label' => __('governance.Reason'), 'type' => 'textarea', 'class' => 'col-12'];
        $fields[] = ['name' => 'requested_effective_date', 'label' => __('governance.EffectiveFrom'), 'type' => 'date'];
        $fields[] = ['name' => 'document_id', 'label' => __('governance.headings.Document'), 'type' => 'select', 'options' => $documents];
    }
    if ($type === 'exception') {
        $fields[] = ['name' => 'framework_id', 'label' => __('governance.headings.Framework'), 'type' => 'select', 'options' => $frameworks];
        $fields[] = ['name' => 'family_id', 'label' => __('governance.Type'), 'type' => 'select', 'options' => $families];
        $fields[] = ['name' => 'control_id', 'label' => __('governance.Code'), 'type' => 'select', 'options' => $controls];
        $fields[] = ['name' => 'policy_document_id', 'label' => __('governance.headings.Document'), 'type' => 'select', 'options' => $documents];
        $fields[] = ['name' => 'existing_exception_id', 'label' => __('locale.ExceptionRequests'), 'type' => 'select', 'options' => $exceptions];
        $fields[] = ['name' => 'justification', 'label' => __('governance.Reason'), 'type' => 'textarea', 'class' => 'col-12'];
        $fields[] = ['name' => 'business_impact', 'label' => __('governance.Description'), 'type' => 'textarea'];
        $fields[] = ['name' => 'technical_justification', 'label' => __('governance.Comment'), 'type' => 'textarea'];
        $fields[] = ['name' => 'compensating_controls', 'label' => __('governance.Conditions'), 'type' => 'textarea'];
        $fields[] = ['name' => 'risk_assessment', 'label' => __('governance.Risk'), 'type' => 'textarea'];
        $fields[] = ['name' => 'requested_start', 'label' => __('governance.EffectiveFrom'), 'type' => 'date'];
        $fields[] = ['name' => 'requested_expiration', 'label' => __('governance.EffectiveUntil'), 'type' => 'date'];
        $fields[] = ['name' => 'review_date', 'label' => __('governance.DueDate'), 'type' => 'date'];
        $fields[] = ['name' => 'owner_id', 'label' => __('governance.Owner'), 'type' => 'select', 'options' => $users, 'departments' => $userDepartments];
        $fields[] = ['name' => 'remediation_plan', 'label' => __('governance.ActionItems'), 'type' => 'textarea', 'class' => 'col-12'];
        $fields[] = ['name' => 'review_frequency', 'label' => __('governance.Quorum')];
    }
    if ($type === 'risk_acceptance') {
        $fields[] = ['name' => 'risk_id', 'label' => __('governance.Risk'), 'type' => 'select', 'options' => $risks];
        $fields[] = ['name' => 'acceptance_justification', 'label' => __('governance.Reason'), 'type' => 'textarea', 'class' => 'col-12'];
        $fields[] = ['name' => 'business_impact', 'label' => __('governance.Description'), 'type' => 'textarea'];
        $fields[] = ['name' => 'acceptance_period', 'label' => __('governance.EffectiveFrom')];
        $fields[] = ['name' => 'proposed_expiration', 'label' => __('governance.EffectiveUntil'), 'type' => 'date'];
        $fields[] = ['name' => 'compensating_controls', 'label' => __('governance.Conditions'), 'type' => 'textarea'];
        $fields[] = ['name' => 'monitoring_plan', 'label' => __('governance.Comment'), 'type' => 'textarea'];
        $fields[] = ['name' => 'owner_recommendation', 'label' => __('governance.Recommendation'), 'type' => 'textarea', 'class' => 'col-12'];
    }
    $listRoute = $type === 'approval' ? 'admin.committee.approvals.ajax.index' : ($type === 'exception' ? 'admin.committee.exceptions.ajax.index' : ($type === 'risk_acceptance' ? 'admin.committee.risks.ajax.index' : 'admin.committee.requests.ajax.index'));
    $screen = [
        'title' => $title,
        'permission' => $type ? $permission : null,
        'canShow' => true,
        'canEdit' => auth()->user()->hasPermission('update_governance_request'),
        'canDelete' => auth()->user()->hasPermission('delete_governance_request'),
        'listUrl' => route($listRoute),
        'storeUrl' => route('admin.committee.requests.ajax.store'),
        'updateUrl' => route('admin.committee.requests.ajax.update', ['id' => '__ID__']),
        'editUrl' => route('admin.committee.requests.ajax.edit', ['id' => '__ID__']),
        'deleteUrl' => route('admin.committee.requests.ajax.destroy', ['id' => '__ID__']),
        'showUrl' => route('admin.committee.requests.show', ['id' => '__ID__']),
        'filters' => [
            ['name' => 'status', 'label' => __('governance.Status'), 'type' => 'select', 'options' => __('governance.statuses')],
            ['name' => 'priority', 'label' => __('governance.Priority'), 'type' => 'select', 'options' => __('governance.priorities')],
            ['name' => 'assigned_committee_id', 'label' => __('governance.Committee'), 'type' => 'select', 'options' => $committees],
            ['name' => 'department_id', 'label' => __('governance.Department'), 'type' => 'select', 'options' => $departments],
        ],
        'columns' => [__('governance.headings.Number'), __('governance.Title'), __('governance.Type'), __('governance.Status'), __('governance.Priority'), __('governance.Committee'), __('governance.Department'), __('governance.DueDate'), ''],
        'dataColumns' => [
            ['data' => 'request_number'], ['data' => 'title'], ['data' => 'type'], ['data' => 'status'], ['data' => 'priority'],
            ['data' => 'committee'], ['data' => 'department'], ['data' => 'due_date'], ['data' => 'Actions'],
        ],
        'fields' => $fields,
    ];
@endphp
@section('content')
    <script>window.GovernanceFixedType = @json($type);</script>
    @if ($type === 'risk_acceptance')
        <div class="alert alert-warning">{{ __('governance.RiskUnchanged') }}</div>
    @endif
    @include('admin.content.committee.partials.crud')
@endsection
@include('admin.content.committee.partials.crud-assets')
@section('page-script')
    @parent
    <script>window.GovernanceConfig.fixedType = @json($type);</script>
@endsection
