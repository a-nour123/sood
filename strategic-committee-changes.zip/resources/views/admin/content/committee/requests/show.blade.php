@extends('admin/layouts/contentLayoutMaster')
@section('title', $request->request_number)
@section('vendor-style')
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
@endsection
@section('content')
    @include('admin.content.committee.partials.heading', ['permission' => null])
    <div class="row">
        <div class="col-lg-8">
            <div class="card"><div class="card-body">
                <h4>{{ $request->title }}</h4>
                <p class="mb-0"><strong>{{ $request->request_number }}</strong> · {{ __('governance.request_types.' . $request->request_type) }} · {{ __('governance.statuses.' . $request->status) }}</p>
                <p>{{ $request->description }}</p>
                <p>{{ __('governance.Committee') }}: {{ optional($request->committee)->name ?: '-' }} | {{ __('governance.Department') }}: {{ optional($request->department)->name ?: '-' }}</p>
                @if ($request->request_type === 'risk_acceptance' && $request->riskAcceptanceDetail)
                    @php $snap = $request->riskAcceptanceDetail->risk_snapshot ?: []; @endphp
                    <div class="alert alert-warning">{{ __('governance.RiskUnchanged') }}</div>
                    <ul>
                        <li>{{ __('governance.headings.Risk') }}: {{ $snap['code'] ?? '' }} {{ $snap['title'] ?? optional($request->riskAcceptanceDetail->risk)->subject }}</li>
                        <li>{{ __('governance.Owner') }}: {{ $snap['owner'] ?? '' }}</li>
                        <li>{{ __('governance.cards.pending') }}: {{ $snap['inherent_risk'] ?? '' }} / {{ $snap['residual_risk'] ?? '' }} / {{ $snap['level'] ?? '' }}</li>
                        <li>{{ $snap['treatment_status'] ?? '' }}</li>
                    </ul>
                    <p>{{ $request->riskAcceptanceDetail->acceptance_justification }}</p>
                @endif
                @if ($request->exceptionDetail)
                    <p>{{ optional($request->exceptionDetail->framework)->name }} / {{ optional($request->exceptionDetail->control)->short_name }}</p>
                    <p>{{ $request->exceptionDetail->justification }}</p>
                    <p>{{ __('governance.headings.Expiration') }}: {{ optional($request->exceptionDetail->expiration_date ?: $request->exceptionDetail->requested_expiration)->toDateString() }}</p>
                @endif
                @if ($request->approvalDetail)
                    <p>{{ optional($request->approvalDetail->document)->document_name }}</p>
                    @if ($request->approvalDetail->document_version_ref)
                        <pre class="small">{{ $request->approvalDetail->document_version_ref }}</pre>
                    @endif
                @endif
            </div></div>
            @if ($canReview)
            <div class="card"><div class="card-header"><h4>{{ __('governance.Reviews') }}</h4></div>
                <div class="table-responsive"><table class="table">
                    <thead><tr><th>{{ __('governance.headings.Reviewer') }}</th><th>{{ __('governance.Status') }}</th><th>{{ __('governance.Recommendation') }}</th><th>{{ __('governance.Comment') }}</th></tr></thead>
                    <tbody>
                    @foreach ($request->reviews as $review)
                        <tr>
                            <td>{{ optional($review->reviewer)->name }}</td>
                            <td>{{ __('governance.review_statuses.' . $review->review_status) }}</td>
                            <td>{{ $review->recommendation ? __('governance.recommendations.' . $review->recommendation) : '' }}</td>
                            <td>{{ $review->comments }}</td>
                        </tr>
                    @endforeach
                    </tbody>
                </table></div>
                <div class="card-body">
                    <form id="review-form" class="row g-1">
                        <div class="col-md-4"><select class="form-select" name="review_status">@foreach (__('governance.review_statuses') as $key => $label)<option value="{{ $key }}">{{ $label }}</option>@endforeach</select></div>
                        <div class="col-md-4"><select class="form-select" name="recommendation"><option value="">{{ __('locale.SelectOption') }}</option>@foreach (__('governance.recommendations') as $key => $label)<option value="{{ $key }}">{{ $label }}</option>@endforeach</select></div>
                        <div class="col-md-12"><textarea class="form-control" name="comments"></textarea></div>
                        <div class="col-md-12"><button class="btn btn-primary" type="submit">{{ __('locale.Save') }}</button></div>
                    </form>
                </div>
            </div>
            @endif
            <div class="card"><div class="card-header"><h4>{{ __('governance.Votes') }}</h4></div>
                <ul class="list-group list-group-flush">
                    @foreach ($request->votingSessions as $session)
                        <li class="list-group-item">{{ __('governance.statuses.' . $request->status) }} / {{ $session->status }} / {{ $session->result }}
                            <ul>@foreach ($session->votes as $vote)<li>{{ optional($vote->voter)->name }}: {{ __('governance.votes.' . $vote->vote) }} ({{ $vote->voting_weight }})</li>@endforeach</ul>
                        </li>
                    @endforeach
                </ul>
                @if ($canVote || $canCloseVote)
                <div class="card-body">
                    <form id="vote-form" class="row g-1">
                        <div class="col-md-4"><select class="form-select" name="vote">@foreach (__('governance.votes') as $key => $label)<option value="{{ $key }}">{{ $label }}</option>@endforeach</select></div>
                        <div class="col-md-8"><input class="form-control" name="comments" placeholder="{{ __('governance.Comment') }}"></div>
                        <div class="col-12">
                            @if ($canVote)<button class="btn btn-primary" type="submit">{{ __('locale.Save') }}</button>@endif
                            @if ($canCloseVote)<button class="btn btn-outline-primary" id="close-vote" type="button">{{ __('governance.actions.close') }}</button>@endif
                        </div>
                    </form>
                </div>
                @endif
            </div>
            <div class="card"><div class="card-header"><h4>{{ __('governance.Decision') }}</h4></div>
                <div class="card-body">
                    @foreach ($request->decisions as $decision)
                        <p><strong>{{ $decision->decision_number }}</strong> {{ __('governance.decisions.' . $decision->decision_type) }} — {{ optional($decision->decider)->name }} — {{ $decision->status }}</p>
                        <p>{{ $decision->decision_reason }} {{ $decision->decision_conditions }}</p>
                    @endforeach
                    @if ($canDecide)
                    <form id="decision-form" class="row g-1">
                        <div class="col-md-6"><select class="form-select" name="decision_type">@foreach (__('governance.decisions') as $key => $label)<option value="{{ $key }}">{{ $label }}</option>@endforeach</select></div>
                        @if ($request->request_type === 'risk_acceptance')
                            <div class="col-md-6"><select class="form-select" name="risk_outcome"><option value="">{{ __('locale.SelectOption') }}</option>@foreach (__('governance.risk_outcomes') as $key => $label)<option value="{{ $key }}">{{ $label }}</option>@endforeach</select></div>
                        @endif
                        <div class="col-md-6"><input class="form-control" type="date" name="effective_from"></div>
                        <div class="col-md-6"><input class="form-control" type="date" name="effective_until"></div>
                        <div class="col-12"><textarea class="form-control" name="decision_reason" placeholder="{{ __('governance.Reason') }}"></textarea></div>
                        <div class="col-12"><textarea class="form-control" name="decision_conditions" placeholder="{{ __('governance.Conditions') }}"></textarea></div>
                        <div class="col-12"><button class="btn btn-primary" type="submit">{{ __('locale.Save') }}</button></div>
                    </form>
                    @endif
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card"><div class="card-header"><h4>{{ __('governance.Workflow') }}</h4></div><div class="card-body">
                @foreach ($actions as $action => $meta)
                    <button class="btn btn-outline-primary mb-1 workflow-action" data-action="{{ $action }}" data-comment="{{ !empty($meta['comment']) ? '1' : '0' }}" type="button">{{ __('governance.actions.' . $action) }}</button>
                @endforeach
                @if (isset($actions['assign']) || isset($actions['reassign']))
                <div class="mt-1">
                    <select class="form-select" id="assign-committee">
                        <option value="">{{ __('locale.SelectOption') }}</option>
                        @foreach ($committees as $committee)
                            <option value="{{ $committee->id }}">{{ $committee->name }}</option>
                        @endforeach
                    </select>
                </div>
                @endif
            </div></div>
            <div class="card"><div class="card-header"><h4>{{ __('governance.Attachments') }}</h4></div><div class="card-body">
                <ul>@foreach ($request->attachments as $attachment)<li><a href="{{ route('admin.committee.requests.attachments.download', [$request->id, $attachment->id]) }}">{{ $attachment->original_name }}</a></li>@endforeach</ul>
                @if ($canUpdate)
                <form id="upload-form"><input type="file" name="file" required><button class="btn btn-primary mt-1" type="submit">{{ __('locale.Save') }}</button></form>
                @endif
            </div></div>
            <div class="card"><div class="card-header"><h4>{{ __('governance.History') }}</h4></div>
                <ul class="list-group list-group-flush">
                    @foreach ($request->statusHistories->sortByDesc('id') as $history)
                        <li class="list-group-item">{{ $history->from_status }} → {{ $history->to_status }} <small>{{ $history->comment }}</small></li>
                    @endforeach
                    @foreach ($request->activityLogs->sortByDesc('id') as $log)
                        <li class="list-group-item">{{ $log->action }} — {{ optional($log->actor)->name }} <small>{{ $log->description }}</small></li>
                    @endforeach
                </ul>
            </div>
        </div>
    </div>
@endsection
@section('page-script')
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
    <script>
        const token = $('meta[name="csrf-token"]').attr('content');
        function done(xhr, ok) {
            var responseData = xhr.responseJSON || {};
            if (ok) {
                makeAlert('success', responseData.message, "{{ __('locale.Success') }}");
                window.setTimeout(function () { window.location.reload(); }, 600);
            } else {
                makeAlert('error', responseData.message, "{{ __('locale.Error') }}");
            }
        }
        $('.workflow-action').on('click', function () {
            const action = $(this).data('action');
            const comment = $(this).data('comment') === 1 || $(this).data('comment') === '1' ? window.prompt(@json(__('governance.Reason'))) : '';
            if ($(this).data('comment') === 1 && !comment) { return; }
            $.post(@json(route('admin.committee.requests.act', $request->id)), { _token: token, action: action, comment: comment, committee_id: $('#assign-committee').val() })
                .done(function (response) { done({ responseJSON: response }, true); })
                .fail(function (xhr) { done(xhr, false); });
        });
        $('#review-form').on('submit', function (event) {
            event.preventDefault();
            $.post(@json(route('admin.committee.requests.reviews.store', $request->id)), $(this).serialize() + '&_token=' + token).done(function (r) { done({ responseJSON: r }, true); }).fail(function (xhr) { done(xhr, false); });
        });
        $('#vote-form').on('submit', function (event) {
            event.preventDefault();
            $.post(@json(route('admin.committee.requests.votes.store', $request->id)), $(this).serialize() + '&_token=' + token).done(function (r) { done({ responseJSON: r }, true); }).fail(function (xhr) { done(xhr, false); });
        });
        $('#close-vote').on('click', function () {
            $.post(@json(route('admin.committee.requests.votes.close', $request->id)), { _token: token }).done(function (r) { done({ responseJSON: r }, true); }).fail(function (xhr) { done(xhr, false); });
        });
        $('#decision-form').on('submit', function (event) {
            event.preventDefault();
            $.post(@json(route('admin.committee.requests.decisions.store', $request->id)), $(this).serialize() + '&_token=' + token).done(function (r) { done({ responseJSON: r }, true); }).fail(function (xhr) { done(xhr, false); });
        });
        $('#upload-form').on('submit', function (event) {
            event.preventDefault();
            const data = new FormData(this);
            data.append('_token', token);
            $.ajax({ url: @json(route('admin.committee.requests.attachments.store', $request->id)), type: 'POST', data: data, processData: false, contentType: false })
                .done(function (r) { done({ responseJSON: r }, true); }).fail(function (xhr) { done(xhr, false); });
        });
    </script>
@endsection
