@extends('admin/layouts/contentLayoutMaster')
@section('title', $meeting->title)
@section('content')
    @include('admin.content.committee.partials.heading', ['permission' => null])
    <div class="row">
        <div class="col-lg-7">
            <div class="card"><div class="card-body">
                <h4>{{ $meeting->title }}</h4>
                <p>{{ $meeting->meeting_number }} · {{ optional($meeting->meeting_date)->toDateString() }} · {{ __('governance.meeting_types.' . $meeting->meeting_type) }}</p>
                <p>{{ $meeting->location }} {{ $meeting->start_time }} - {{ $meeting->end_time }}</p>
                <p>{{ $meeting->description }}</p>
            </div></div>
            <div class="card"><div class="card-header"><h4>{{ __('governance.Agenda') }}</h4></div><div class="card-body">
                <ul>@foreach ($meeting->agendas as $agenda)<li>{{ $agenda->title }} @if($agenda->request) — {{ $agenda->request->request_number }} @endif</li>@endforeach</ul>
                @if ($canManageMeeting)
                <form id="agenda-form" class="row g-1">
                    <div class="col-md-6"><input class="form-control" name="title" required></div>
                    <div class="col-md-6"><select class="form-select" name="governance_request_id"><option value="">{{ __('locale.SelectOption') }}</option>@foreach ($requests as $row)<option value="{{ $row->id }}">{{ $row->request_number }}</option>@endforeach</select></div>
                    <div class="col-12"><button class="btn btn-primary" type="submit">{{ __('governance.Add') }}</button></div>
                </form>
                @endif
            </div></div>
            <div class="card"><div class="card-header"><h4>{{ __('governance.Minutes') }}</h4></div><div class="card-body">
                @if ($canMinutes)
                <form id="minutes-form" class="row g-1">
                    <div class="col-12"><textarea class="form-control" name="discussion" placeholder="{{ __('governance.Minutes') }}">{{ optional($meeting->minutes)->discussion }}</textarea></div>
                    <div class="col-12"><textarea class="form-control" name="recommendations" placeholder="{{ __('governance.Recommendation') }}">{{ optional($meeting->minutes)->recommendations }}</textarea></div>
                    <div class="col-12"><textarea class="form-control" name="resolutions" placeholder="{{ __('governance.Decision') }}">{{ optional($meeting->minutes)->resolutions }}</textarea></div>
                    <div class="col-12"><button class="btn btn-primary" type="submit">{{ __('locale.Save') }}</button></div>
                </form>
                @endif
            </div></div>
        </div>
        <div class="col-lg-5">
            <div class="card"><div class="card-header"><h4>{{ __('governance.Attendance') }}</h4></div><div class="card-body">
                <ul>
                    @foreach ($meeting->attendees as $attendee)
                        <li>{{ optional($attendee->user)->name }} — {{ $attendee->attendance }}
                            @if ($canManageMeeting)
                            <form class="d-inline attendance-form" data-id="{{ $attendee->id }}">
                                <select name="attendance"><option value="present">present</option><option value="absent">absent</option><option value="excused">excused</option></select>
                                <button type="submit">OK</button>
                            </form>
                            @endif
                        </li>
                    @endforeach
                </ul>
                @if ($canManageMeeting)
                <form id="attendee-form">
                    <select class="form-select" name="user_ids[]" multiple>
                        @foreach ($options['users'] as $user)
                            <option value="{{ $user->id }}">{{ $user->name }}</option>
                        @endforeach
                    </select>
                    <button class="btn btn-primary mt-1" type="submit">{{ __('governance.Add') }}</button>
                </form>
                @endif
            </div></div>
            <div class="card"><div class="card-header"><h4>{{ __('governance.ActionItems') }}</h4></div><div class="card-body">
                <ul>@foreach ($meeting->actions as $action)<li>{{ $action->title }} @if($action->task) #{{ $action->task->id }} {{ $action->task->status }} @endif</li>@endforeach</ul>
                @if ($canManageMeeting)
                <form id="action-form" class="row g-1">
                    <div class="col-12"><input class="form-control" name="title" required></div>
                    <div class="col-md-6"><select class="form-select" name="assignee_id">@foreach ($options['users'] as $user)<option value="{{ $user->id }}">{{ $user->name }}</option>@endforeach</select></div>
                    <div class="col-md-6"><input class="form-control" type="date" name="due_date"></div>
                    <div class="col-12"><button class="btn btn-primary" type="submit">{{ __('governance.Add') }}</button></div>
                </form>
                @endif
            </div></div>
        </div>
    </div>
@endsection
@section('vendor-style')
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
@endsection
@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
@endsection
@section('page-script')
<script>
    const token = $('meta[name="csrf-token"]').attr('content');
    function governanceDone(xhr, ok) {
        var responseData = (xhr && xhr.responseJSON) ? xhr.responseJSON : {};
        if (ok) {
            makeAlert('success', responseData.message, "{{ __('locale.Success') }}");
            window.setTimeout(function () { window.location.reload(); }, 600);
        } else {
            makeAlert('error', responseData.message, "{{ __('locale.Error') }}");
        }
    }
    $('#agenda-form').on('submit', function (e) { e.preventDefault(); $.post(@json(route('admin.committee.meetings.agendas.store', $meeting->id)), $(this).serialize()+'&_token='+token).done(function (r) { governanceDone({ responseJSON: r }, true); }).fail(function (xhr) { governanceDone(xhr, false); }); });
    $('#minutes-form').on('submit', function (e) { e.preventDefault(); $.post(@json(route('admin.committee.meetings.minutes', $meeting->id)), $(this).serialize()+'&_token='+token).done(function (r) { governanceDone({ responseJSON: r }, true); }).fail(function (xhr) { governanceDone(xhr, false); }); });
    $('#attendee-form').on('submit', function (e) { e.preventDefault(); $.post(@json(route('admin.committee.meetings.attendees', $meeting->id)), $(this).serialize()+'&_token='+token).done(function (r) { governanceDone({ responseJSON: r }, true); }).fail(function (xhr) { governanceDone(xhr, false); }); });
    $('#action-form').on('submit', function (e) { e.preventDefault(); $.post(@json(route('admin.committee.meetings.actions.store', $meeting->id)), $(this).serialize()+'&_token='+token).done(function (r) { governanceDone({ responseJSON: r }, true); }).fail(function (xhr) { governanceDone(xhr, false); }); });
    $('.attendance-form').on('submit', function (e) {
        e.preventDefault();
        $.post(@json(route('admin.committee.meetings.attendance', [$meeting->id, 0])).replace('/0', '/' + $(this).data('id')), $(this).serialize()+'&_token='+token).done(function (r) { governanceDone({ responseJSON: r }, true); }).fail(function (xhr) { governanceDone(xhr, false); });
    });
</script>
@endsection
