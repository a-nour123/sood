@extends('admin/layouts/contentLayoutMaster')
@section('title', __('locale.CommitteeMeetings'))
@php
    $committees = [];
    foreach ($options['committees'] as $committee) { $committees[$committee->id] = $committee->name; }
    $screen = [
        'title' => __('locale.CommitteeMeetings'),
        'permission' => 'manage_committee_meetings',
        'canShow' => true,
        'canEdit' => auth()->user()->hasPermission('manage_committee_meetings'),
        'canDelete' => auth()->user()->hasPermission('manage_committee_meetings'),
        'listUrl' => route('admin.committee.meetings.ajax.index'),
        'storeUrl' => route('admin.committee.meetings.ajax.store'),
        'updateUrl' => route('admin.committee.meetings.ajax.update', ['id' => '__ID__']),
        'editUrl' => route('admin.committee.meetings.ajax.edit', ['id' => '__ID__']),
        'deleteUrl' => route('admin.committee.meetings.ajax.destroy', ['id' => '__ID__']),
        'showUrl' => route('admin.committee.meetings.show', ['id' => '__ID__']),
        'filters' => [
            ['name' => 'committee_id', 'label' => __('governance.Committee'), 'type' => 'select', 'options' => $committees],
            ['name' => 'status', 'label' => __('governance.Status'), 'type' => 'select', 'options' => __('governance.meeting_statuses')],
            ['name' => 'meeting_type', 'label' => __('governance.Type'), 'type' => 'select', 'options' => __('governance.meeting_types')],
        ],
        'columns' => [__('governance.headings.Number'), __('governance.Title'), __('governance.Committee'), __('governance.headings.Date'), __('governance.Type'), __('governance.Status'), ''],
        'dataColumns' => [
            ['data' => 'meeting_number'], ['data' => 'title'], ['data' => 'committee'], ['data' => 'meeting_date'], ['data' => 'type'], ['data' => 'status'], ['data' => 'Actions'],
        ],
        'fields' => [
            ['name' => 'committee_id', 'label' => __('governance.Committee'), 'type' => 'select', 'options' => $committees],
            ['name' => 'meeting_number', 'label' => __('governance.headings.Number')],
            ['name' => 'title', 'label' => __('governance.Title')],
            ['name' => 'meeting_date', 'label' => __('governance.headings.Date'), 'type' => 'date'],
            ['name' => 'start_time', 'label' => __('governance.EffectiveFrom'), 'type' => 'time'],
            ['name' => 'end_time', 'label' => __('governance.EffectiveUntil'), 'type' => 'time'],
            ['name' => 'location', 'label' => __('governance.Department')],
            ['name' => 'meeting_type', 'label' => __('governance.Type'), 'type' => 'select', 'options' => __('governance.meeting_types')],
            ['name' => 'status', 'label' => __('governance.Status'), 'type' => 'select', 'options' => __('governance.meeting_statuses')],
            ['name' => 'description', 'label' => __('governance.Description'), 'type' => 'textarea', 'class' => 'col-12'],
        ],
    ];
@endphp
@section('content')
    @include('admin.content.committee.partials.crud')
@endsection
@include('admin.content.committee.partials.crud-assets')
