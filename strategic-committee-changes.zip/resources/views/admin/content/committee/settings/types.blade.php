@extends('admin/layouts/contentLayoutMaster')
@section('title', __('locale.CommitteeTypes'))
@php
    $screen = [
        'title' => __('locale.CommitteeTypes'),
        'permission' => 'manage_committee_settings',
        'canShow' => false,
        'canEdit' => true,
        'canDelete' => true,
        'listUrl' => route('admin.committee.settings.types.ajax.index'),
        'storeUrl' => route('admin.committee.settings.types.ajax.store'),
        'updateUrl' => route('admin.committee.settings.types.ajax.update', ['id' => '__ID__']),
        'editUrl' => route('admin.committee.settings.types.ajax.edit', ['id' => '__ID__']),
        'deleteUrl' => route('admin.committee.settings.types.ajax.destroy', ['id' => '__ID__']),
        'filters' => [],
        'columns' => [__('governance.Name'), __('governance.Code'), __('governance.Status'), ''],
        'dataColumns' => [['data' => 'name'], ['data' => 'code'], ['data' => 'status'], ['data' => 'Actions']],
        'fields' => [
            ['name' => 'name', 'label' => __('governance.Name')],
            ['name' => 'code', 'label' => __('governance.Code')],
            ['name' => 'description', 'label' => __('governance.Description'), 'type' => 'textarea', 'class' => 'col-12'],
            ['name' => 'is_active', 'label' => __('governance.Status'), 'type' => 'select', 'options' => ['1' => __('governance.Active'), '0' => __('governance.Inactive')]],
        ],
    ];
@endphp
@section('content')
    @include('admin.content.committee.partials.crud')
@endsection
@include('admin.content.committee.partials.crud-assets')
