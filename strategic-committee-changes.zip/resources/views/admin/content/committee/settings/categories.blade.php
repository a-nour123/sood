@extends('admin/layouts/contentLayoutMaster')
@section('title', __('locale.RequestCategories'))
@php
    $screen = [
        'title' => __('locale.RequestCategories'),
        'permission' => 'manage_committee_settings',
        'canShow' => false,
        'canEdit' => true,
        'canDelete' => true,
        'listUrl' => route('admin.committee.settings.categories.ajax.index'),
        'storeUrl' => route('admin.committee.settings.categories.ajax.store'),
        'updateUrl' => route('admin.committee.settings.categories.ajax.update', ['id' => '__ID__']),
        'editUrl' => route('admin.committee.settings.categories.ajax.edit', ['id' => '__ID__']),
        'deleteUrl' => route('admin.committee.settings.categories.ajax.destroy', ['id' => '__ID__']),
        'filters' => [],
        'columns' => [__('governance.Name'), __('governance.Code'), __('governance.Type'), __('governance.Status'), ''],
        'dataColumns' => [['data' => 'name'], ['data' => 'code'], ['data' => 'request_type'], ['data' => 'status'], ['data' => 'Actions']],
        'fields' => [
            ['name' => 'name', 'label' => __('governance.Name')],
            ['name' => 'code', 'label' => __('governance.Code')],
            ['name' => 'request_type', 'label' => __('governance.Type'), 'type' => 'select', 'options' => __('governance.request_types')],
            ['name' => 'is_active', 'label' => __('governance.Status'), 'type' => 'select', 'options' => ['1' => __('governance.Active'), '0' => __('governance.Inactive')]],
        ],
    ];
@endphp
@section('content')
    @include('admin.content.committee.partials.crud')
@endsection
@include('admin.content.committee.partials.crud-assets')
