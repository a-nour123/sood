@extends('admin/layouts/contentLayoutMaster')
@section('title', __('locale.AssignmentRules'))
@php
    $committees = [];
    foreach ($options['committees'] as $committee) { $committees[$committee->id] = $committee->name; }
    $departments = [];
    foreach ($options['departments'] as $department) { $departments[$department->id] = $department->name; }
    $categories = [];
    foreach ($options['categories'] as $category) { $categories[$category->id] = $category->name; }
    $screen = [
        'title' => __('locale.AssignmentRules'),
        'permission' => 'manage_committee_settings',
        'canShow' => false,
        'canEdit' => true,
        'canDelete' => true,
        'listUrl' => route('admin.committee.settings.rules.ajax.index'),
        'storeUrl' => route('admin.committee.settings.rules.ajax.store'),
        'updateUrl' => route('admin.committee.settings.rules.ajax.update', ['id' => '__ID__']),
        'editUrl' => route('admin.committee.settings.rules.ajax.edit', ['id' => '__ID__']),
        'deleteUrl' => route('admin.committee.settings.rules.ajax.destroy', ['id' => '__ID__']),
        'filters' => [],
        'columns' => [__('governance.Type'), __('governance.Category'), __('governance.Department'), __('governance.Committee'), __('governance.Priority'), __('governance.Status'), ''],
        'dataColumns' => [['data' => 'request_type'], ['data' => 'category'], ['data' => 'department'], ['data' => 'committee'], ['data' => 'priority'], ['data' => 'status'], ['data' => 'Actions']],
        'fields' => [
            ['name' => 'request_type', 'label' => __('governance.Type'), 'type' => 'select', 'options' => __('governance.request_types')],
            ['name' => 'category_id', 'label' => __('governance.Category'), 'type' => 'select', 'options' => $categories],
            ['name' => 'department_id', 'label' => __('governance.Department'), 'type' => 'select', 'options' => $departments],
            ['name' => 'committee_id', 'label' => __('governance.Committee'), 'type' => 'select', 'options' => $committees],
            ['name' => 'priority', 'label' => __('governance.Priority'), 'type' => 'number', 'default' => 100],
            ['name' => 'is_active', 'label' => __('governance.Status'), 'type' => 'select', 'options' => ['1' => __('governance.Active'), '0' => __('governance.Inactive')]],
        ],
    ];
@endphp
@section('content')
    @include('admin.content.committee.partials.crud')
@endsection
@include('admin.content.committee.partials.crud-assets')
