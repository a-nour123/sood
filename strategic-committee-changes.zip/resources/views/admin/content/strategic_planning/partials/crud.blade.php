@include('admin.content.strategic_planning.partials.heading', ['title' => $screen['title'], 'permission' => $screen['permission']])
<div class="card mb-1">
    <div class="card-body">
        <form id="strategic-filters" class="strategic-live-filter row g-1">
            @foreach ($screen['filters'] as $filter)
                <div class="col-md-3">
                    <label class="form-label">{{ $filter['label'] }}</label>
                    @if ($filter['type'] === 'select')
                        <select class="select2 form-select" name="{{ $filter['name'] }}">
                            <option value="">{{ __('locale.SelectOption') }}</option>
                            @foreach ($filter['options'] as $value => $label)
                                <option value="{{ $value }}">{{ $label }}</option>
                            @endforeach
                        </select>
                    @else
                        <input class="form-control" type="{{ $filter['type'] }}" name="{{ $filter['name'] }}">
                    @endif
                </div>
            @endforeach
        </form>
    </div>
</div>
<div class="card">
    <div class="table-responsive">
        <table class="table" id="strategic-table">
            <thead>
                <tr>
                    @foreach ($screen['columns'] as $column)
                        <th>{{ $column['label'] }}</th>
                    @endforeach
                </tr>
            </thead>
        </table>
    </div>
</div>
<div class="modal fade" id="strategic-modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <form id="strategic-form" class="modal-content">
            @csrf
            <input type="hidden" name="id">
            <div class="modal-header"><h5 class="modal-title">{{ $screen['title'] }}</h5><button class="btn-close" type="button" data-bs-dismiss="modal"></button></div>
            <div class="modal-body row g-1">
                @foreach ($screen['fields'] as $field)
                    <div class="col-md-6">
                        <label class="form-label">{{ $field['label'] }}</label>
                        @if (($field['type'] ?? 'text') === 'textarea')
                            <textarea class="form-control" name="{{ $field['name'] }}"></textarea>
                        @elseif (($field['type'] ?? '') === 'select')
                            <select class="select2 form-select" name="{{ $field['name'] }}" @if(!empty($field['required'])) required @endif>
                                <option value="">{{ __('locale.SelectOption') }}</option>
                                @foreach ($field['options'] as $value => $label)
                                    <option value="{{ $value }}">{{ $label }}</option>
                                @endforeach
                            </select>
                        @else
                            <input class="form-control" type="{{ $field['type'] ?? 'text' }}" name="{{ $field['name'] }}" value="{{ $field['default'] ?? '' }}" @if(!empty($field['required'])) required @endif>
                        @endif
                        <small class="text-danger strategic-error strategic-error-{{ $field['name'] }}"></small>
                    </div>
                @endforeach
            </div>
            <div class="modal-footer"><button class="btn btn-primary" type="submit">{{ __('locale.Save') }}</button></div>
        </form>
    </div>
</div>
