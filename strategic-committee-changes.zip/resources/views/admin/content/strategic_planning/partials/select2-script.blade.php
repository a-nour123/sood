<script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
<script src="{{ asset('ajax-files/strategic_planning/selects.js') }}"></script>
