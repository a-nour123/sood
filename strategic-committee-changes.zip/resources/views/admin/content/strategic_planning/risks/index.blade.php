@extends('admin/layouts/contentLayoutMaster')
@section('title', __('locale.StrategicRisks'))
@section('content')
    @include('admin.content.strategic_planning.partials.heading', ['title' => __('locale.StrategicRisks'), 'permission' => null])
    <div class="card table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>{{ __('strategic.Objective') }}</th>
                    <th>{{ __('strategic.Plan') }}</th>
                    <th>{{ __('strategic.Risk') }}</th>
                    <th>{{ __('strategic.InherentScore') }}</th>
                    <th>{{ __('strategic.Residual') }}</th>
                    <th>{{ __('strategic.Treatment') }}</th>
                    <th>{{ __('strategic.HighRisk') }}</th>
                </tr>
            </thead>
            <tbody>
            @foreach ($links as $link)
                @php $summary = $link->risk ? \App\Services\Strategic\StrategicRiskReader::summarize($link->risk) : ['subject' => $link->risk_snapshot, 'score' => $link->score_at_link, 'residual' => null, 'treatment' => null, 'band' => 'unknown']; @endphp
                <tr class="{{ in_array($summary['band'], ['high', 'critical'], true) ? 'table-danger' : '' }}">
                    <td><a href="{{ route('admin.strategic.objectives.show', $link->strategic_objective_id) }}">{{ optional($link->objective)->name }}</a></td>
                    <td>{{ optional(optional(optional($link->objective)->goal)->plan)->name }}</td>
                    <td>{{ $summary['subject'] }}</td>
                    <td>{{ $summary['score'] }}</td>
                    <td>{{ $summary['residual'] }}</td>
                    <td>{{ $summary['treatment'] }}</td>
                    <td>{{ in_array($summary['band'], ['high', 'critical'], true) ? __('strategic.Yes') : __('strategic.No') }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
    {{ $links->links() }}
@endsection
