@extends('admin/layouts/contentLayoutMaster')
@section('title', __('locale.StrategicDashboard'))
@section('vendor-style')
    @include('admin.content.strategic_planning.partials.select2-style')
@endsection
@section('content')
    @include('admin.content.strategic_planning.partials.heading', ['title' => __('locale.StrategicDashboard'), 'permission' => null])
    <form class="card mb-1 strategic-live-filter" method="GET">
        <div class="card-body row g-1">
            <div class="col-md-3">
                <label class="form-label">{{ __('strategic.Plan') }}</label>
                <select class="select2 form-select" name="plan_id">
                    <option value="">{{ __('locale.SelectOption') }}</option>
                    @foreach ($plans as $plan)
                        <option value="{{ $plan->id }}" {{ (string) ($filters['plan_id'] ?? '') === (string) $plan->id ? 'selected' : '' }}>{{ $plan->name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">{{ __('strategic.Department') }}</label>
                <select class="select2 form-select" name="department_id">
                    <option value="">{{ __('locale.SelectOption') }}</option>
                    @foreach ($departments as $id => $name)
                        <option value="{{ $id }}" {{ (string) ($filters['department_id'] ?? '') === (string) $id ? 'selected' : '' }}>{{ $name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-2"><label class="form-label">{{ __('strategic.Year') }}</label><input class="form-control" type="number" name="year" value="{{ $filters['year'] ?? '' }}"></div>
            <div class="col-md-2">
                <label class="form-label">{{ __('strategic.Status') }}</label>
                <select class="select2 form-select" name="status">
                    <option value="">{{ __('locale.SelectOption') }}</option>
                    @foreach (__('strategic.plan_statuses') as $key => $label)
                        <option value="{{ $key }}" {{ ($filters['status'] ?? '') === $key ? 'selected' : '' }}>{{ $label }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">{{ __('strategic.ReportingPeriod') }}</label>
                <select class="select2 form-select" name="period">
                    <option value="">{{ __('locale.SelectOption') }}</option>
                    @foreach (['all' => __('strategic.Year'), 'q1' => 'Q1', 'q2' => 'Q2', 'q3' => 'Q3', 'q4' => 'Q4'] as $key => $label)
                        <option value="{{ $key }}" {{ ($filters['period'] ?? 'all') === $key ? 'selected' : '' }}>{{ $label }}</option>
                    @endforeach
                </select>
            </div>
        </div>
    </form>
    <div class="row">
        @foreach ([
            'plans' => [__('strategic.TotalPlans'), route('admin.strategic.plans.index')],
            'active_plans' => [__('strategic.ActivePlans'), route('admin.strategic.plans.index')],
            'goals' => [__('strategic.TotalGoals'), route('admin.strategic.goals.index')],
            'objectives' => [__('strategic.TotalObjectives'), route('admin.strategic.objectives.index')],
            'active_initiatives' => [__('strategic.ActiveInitiatives'), route('admin.strategic.initiatives.index')],
            'achievement' => [__('strategic.OverallAchievement'), route('admin.strategic.reports.index', ['type' => 'plans'])],
            'at_risk_objectives' => [__('strategic.AtRiskObjectives'), route('admin.strategic.objectives.index')],
            'delayed_initiatives' => [__('strategic.DelayedInitiatives'), route('admin.strategic.initiatives.index')],
        ] as $key => $meta)
            <div class="col-xl-3 col-md-4 col-sm-6 mb-1">
                <a class="card h-100" href="{{ $meta[1] }}">
                    <div class="card-body">
                        <small class="text-muted">{{ $meta[0] }}</small>
                        <h3 class="mb-0">{{ $stats['cards'][$key] }}{{ $key === 'achievement' ? '%' : '' }}</h3>
                    </div>
                </a>
            </div>
        @endforeach
    </div>
    <div class="row">
        @foreach (['goals', 'objectives', 'kpis', 'initiatives', 'risks', 'departments'] as $chart)
            <div class="col-lg-4 mb-1"><div class="card"><div class="card-header">{{ __('strategic.charts.' . $chart) }}</div><div class="card-body"><div id="chart-{{ $chart }}"></div></div></div></div>
        @endforeach
        <div class="col-lg-6 mb-1"><div class="card"><div class="card-header">{{ __('strategic.charts.monthly') }}</div><div class="card-body"><div id="chart-monthly"></div></div></div></div>
        <div class="col-lg-6 mb-1"><div class="card"><div class="card-header">{{ __('strategic.charts.budget') }}</div><div class="card-body"><div id="chart-budget"></div><p class="mb-0">{{ $stats['charts']['budget']['utilization'] }}%</p></div></div></div>
    </div>
@endsection
@section('vendor-script')
    @include('admin.content.strategic_planning.partials.select2-script')
@endsection
@section('page-script')
    <script src="{{ asset(mix('vendors/js/charts/apexcharts.min.js')) }}"></script>
    <script>
        const stats = @json($stats['charts']);
        const departmentNames = @json($departments);
        function labeled(source, dictionary) {
            const labels = [];
            const series = [];
            Object.keys(source || {}).forEach(function (key) {
                labels.push(dictionary && dictionary[key] ? dictionary[key] : (key === '0' ? @json(__('strategic.Unassigned')) : (departmentNames[key] || key)));
                series.push(Number(source[key]));
            });
            return { labels: labels, series: series };
        }
        function donut(id, pack) {
            if (!pack.series.length || !document.querySelector(id)) return;
            new ApexCharts(document.querySelector(id), {
                chart: { type: 'donut', height: 280 },
                labels: pack.labels,
                series: pack.series,
                legend: { position: 'bottom' }
            }).render();
        }
        donut('#chart-goals', labeled(stats.goals, @json(__('strategic.perspectives'))));
        donut('#chart-objectives', labeled(stats.objectives, @json(__('strategic.work_statuses'))));
        donut('#chart-kpis', labeled(stats.kpis, @json(__('strategic.kpi_statuses'))));
        donut('#chart-initiatives', labeled(stats.initiatives, @json(__('strategic.work_statuses'))));
        donut('#chart-risks', labeled(stats.risks, { critical: @json(__('strategic.kri_levels.critical')), high: @json(__('strategic.priorities.high')), other: @json(__('strategic.Unassigned')) }));
        donut('#chart-departments', labeled(stats.departments, departmentNames));
        new ApexCharts(document.querySelector('#chart-monthly'), {
            chart: { type: 'bar', height: 280, toolbar: { show: false } },
            series: [{ name: @json(__('strategic.KpiAchievement')), data: stats.monthly }],
            xaxis: { categories: ['1','2','3','4','5','6','7','8','9','10','11','12'] }
        }).render();
        new ApexCharts(document.querySelector('#chart-budget'), {
            chart: { type: 'bar', height: 280, toolbar: { show: false } },
            series: [{ name: @json(__('strategic.Budget')), data: [stats.budget.estimated, stats.budget.actual] }],
            xaxis: { categories: [@json(__('strategic.EstimatedBudget')), @json(__('strategic.ActualBudget'))] }
        }).render();
    </script>
@endsection
