@extends('admin/layouts/contentLayoutMaster')
@section('title', $initiative->name)
@section('vendor-style')
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    @include('admin.content.strategic_planning.partials.select2-style')
@endsection
@section('content')
    @include('admin.content.strategic_planning.partials.heading', ['title' => $initiative->name, 'permission' => null])
    <div class="row">
        <div class="col-lg-8">
            <div class="card"><div class="card-body">
                <p><a href="{{ route('admin.strategic.objectives.show', $initiative->objective->id) }}">{{ $initiative->objective->name }}</a></p>
                <p><strong>{{ __('strategic.OperationalProgress') }}:</strong> {{ $initiative->displayedProgress() }}%</p>
                <p><strong>{{ __('strategic.TaskCompletion') }}:</strong> {{ $taskCompletion['completed'] }}/{{ $taskCompletion['total'] }} ({{ $taskCompletion['percentage'] }}%)</p>
                <p><strong>{{ __('strategic.Budget') }}:</strong> {{ $initiative->actual_budget }} / {{ $initiative->estimated_budget }}</p>
                <p><strong>{{ __('strategic.Delayed') }}:</strong> {{ $initiative->isDelayed() ? __('strategic.Yes') : __('strategic.No') }}</p>
                <p>{{ $initiative->expected_outcomes }}</p>
            </div></div>
            <div class="card"><div class="card-header"><h4>{{ __('locale.StrategicMilestones') }}</h4></div>
                <table class="table">
                    <thead><tr><th>{{ __('strategic.Name') }}</th><th>{{ __('strategic.PlannedDue') }}</th><th>{{ __('strategic.ActualCompletion') }}</th><th>{{ __('strategic.Completion') }}</th><th>{{ __('strategic.Overdue') }}</th></tr></thead>
                    <tbody>
                    @foreach ($initiative->milestones as $milestone)
                        <tr>
                            <td>{{ $milestone->name }}</td>
                            <td>{{ optional($milestone->planned_due_date)->toDateString() }}</td>
                            <td>{{ optional($milestone->actual_completion_date)->toDateString() }}</td>
                            <td>{{ $milestone->completion_percentage }}%</td>
                            <td>{{ $milestone->isOverdue() ? __('strategic.Yes') : __('strategic.No') }}</td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
            <div class="card"><div class="card-header"><h4>{{ __('strategic.Tasks') }}</h4></div>
                <table class="table">
                    @foreach ($initiative->taskLinks as $link)
                        <tr>
                            <td>{{ optional($link->task)->title ?: $link->task_snapshot }}</td>
                            <td>{{ optional($link->task)->status }}</td>
                            <td>{{ optional($link->task)->due_date }}</td>
                            <td>{{ $link->milestone ? $link->milestone->name : '' }}</td>
                        </tr>
                    @endforeach
                </table>
            </div>
        </div>
        <div class="col-lg-4">
            @if (\App\Services\Strategic\StrategicAccess::isAssigned(auth()->user(), $initiative) && auth()->user()->hasPermission('strategic_initiative.manage'))
                <div class="card"><div class="card-header"><h4>{{ __('strategic.CreateTask') }}</h4></div>
                    <form class="card-body" id="create-task">
                        @csrf
                        <input class="form-control mb-1" name="title" required placeholder="{{ __('strategic.Name') }}">
                        <textarea class="form-control mb-1" name="description"></textarea>
                        <select class="select2 form-select mb-1" name="assignee_id" required>
                            <option value="">{{ __('locale.SelectOption') }}</option>
                            @foreach ($options['users'] as $user)<option value="{{ $user->id }}">{{ $user->name }}</option>@endforeach
                        </select>
                        <select class="select2 form-select mb-1" name="strategic_milestone_id"><option value="">{{ __('locale.SelectOption') }}</option>@foreach ($initiative->milestones as $milestone)<option value="{{ $milestone->id }}">{{ $milestone->name }}</option>@endforeach</select>
                        <input class="form-control mb-1" type="date" name="start_date">
                        <input class="form-control mb-1" type="date" name="due_date">
                        <button class="btn btn-primary btn-sm" type="submit">{{ __('strategic.CreateTask') }}</button>
                    </form>
                </div>
                <div class="card"><div class="card-body">
                    <form id="link-task">@csrf
                        <input class="form-control mb-1" name="task_id" placeholder="{{ __('strategic.LinkTask') }}" required>
                        <button class="btn btn-outline-primary btn-sm" type="submit">{{ __('strategic.LinkTask') }}</button>
                    </form>
                </div></div>
            @endif
            <div class="card"><div class="card-header"><h4>{{ __('strategic.Activity') }}</h4></div>
                <ul class="list-group list-group-flush">
                    @foreach ($initiative->activity as $entry)
                        <li class="list-group-item"><strong>{{ $entry->action }}</strong> {{ $entry->description }}<div class="small text-muted">{{ $entry->created_at }}</div></li>
                    @endforeach
                </ul>
            </div>
        </div>
    </div>
@endsection
@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
    @include('admin.content.strategic_planning.partials.select2-script')
@endsection
@section('page-script')
    <script>
        function postForm(selector, url) {
            $(selector).on('submit', function (event) {
                event.preventDefault();
                $.post(url, $(this).serialize()).done(function (response) {
                    makeAlert('success', response.message, "{{ __('locale.Success') }}");
                    window.setTimeout(function () { window.location.reload(); }, 600);
                }).fail(function (xhr) {
                    var responseData = xhr.responseJSON || {};
                    makeAlert('error', responseData.message, "{{ __('locale.Error') }}");
                });
            });
        }
        postForm('#create-task', @json(route('admin.strategic.initiatives.tasks.store', $initiative->id)));
        postForm('#link-task', @json(route('admin.strategic.initiatives.tasks.link', $initiative->id)));
    </script>
@endsection
