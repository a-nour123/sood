@extends('admin/layouts/contentLayoutMaster')
@section('title', __('locale.StrategicInitiatives'))
@php
    $users = []; foreach ($options['users'] as $user) { $users[$user->id] = $user->name; }
    $departments = []; foreach ($options['departments'] as $department) { $departments[$department->id] = $department->name; }
    $objectives = []; foreach ($options['objectives'] as $objective) { $objectives[$objective->id] = $objective->name; }
    $screen = [
        'title' => __('locale.StrategicInitiatives'),
        'permission' => 'strategic_initiative.manage',
        'canShow' => true,
        'canEdit' => auth()->user()->hasPermission('strategic_initiative.manage'),
        'canDelete' => auth()->user()->hasPermission('strategic_initiative.manage'),
        'listUrl' => route('admin.strategic.initiatives.ajax.index'),
        'storeUrl' => route('admin.strategic.initiatives.ajax.store'),
        'updateUrl' => route('admin.strategic.initiatives.ajax.update', ['id' => '__ID__']),
        'editUrl' => route('admin.strategic.initiatives.ajax.edit', ['id' => '__ID__']),
        'deleteUrl' => route('admin.strategic.initiatives.ajax.destroy', ['id' => '__ID__']),
        'showUrl' => route('admin.strategic.initiatives.show', ['id' => '__ID__']),
        'filters' => [
            ['name' => 'strategic_objective_id', 'label' => __('strategic.Objective'), 'type' => 'select', 'options' => $objectives],
            ['name' => 'status', 'label' => __('strategic.Status'), 'type' => 'select', 'options' => __('strategic.work_statuses')],
            ['name' => 'department_id', 'label' => __('strategic.Department'), 'type' => 'select', 'options' => $departments],
        ],
        'columns' => [
            ['label' => __('strategic.Name')], ['label' => __('strategic.Code')], ['label' => __('strategic.Objective')],
            ['label' => __('strategic.Status')], ['label' => __('strategic.Progress')], ['label' => __('strategic.Budget')],
            ['label' => __('strategic.DueDate')], ['label' => __('strategic.Delayed')], ['label' => ''],
        ],
        'dataColumns' => [
            ['data' => 'name'], ['data' => 'code'], ['data' => 'objective'], ['data' => 'status'],
            ['data' => 'progress'], ['data' => 'budget'], ['data' => 'due_date'], ['data' => 'delayed'], ['data' => 'Actions'],
        ],
        'fields' => [
            ['name' => 'strategic_objective_id', 'label' => __('strategic.Objective'), 'type' => 'select', 'options' => $objectives, 'required' => true],
            ['name' => 'name', 'label' => __('strategic.Name'), 'required' => true],
            ['name' => 'code', 'label' => __('strategic.Code'), 'required' => true],
            ['name' => 'owner_id', 'label' => __('strategic.Owner'), 'type' => 'select', 'options' => $users],
            ['name' => 'department_id', 'label' => __('strategic.Department'), 'type' => 'select', 'options' => $departments],
            ['name' => 'priority', 'label' => __('strategic.Priority'), 'type' => 'select', 'options' => __('strategic.priorities'), 'required' => true],
            ['name' => 'weight', 'label' => __('strategic.Weight'), 'type' => 'number', 'required' => true, 'default' => 1],
            ['name' => 'estimated_budget', 'label' => __('strategic.EstimatedBudget'), 'type' => 'number'],
            ['name' => 'actual_budget', 'label' => __('strategic.ActualBudget'), 'type' => 'number'],
            ['name' => 'start_date', 'label' => __('strategic.StartDate'), 'type' => 'date'],
            ['name' => 'due_date', 'label' => __('strategic.DueDate'), 'type' => 'date'],
            ['name' => 'actual_end_date', 'label' => __('strategic.ActualCompletion'), 'type' => 'date'],
            ['name' => 'progress_percentage', 'label' => __('strategic.Progress'), 'type' => 'number'],
            ['name' => 'status', 'label' => __('strategic.Status'), 'type' => 'select', 'options' => __('strategic.work_statuses'), 'required' => true],
            ['name' => 'expected_outcomes', 'label' => __('strategic.ExpectedOutcomes'), 'type' => 'textarea'],
            ['name' => 'description', 'label' => __('strategic.Description'), 'type' => 'textarea'],
        ],
    ];
@endphp
@section('content')
    @include('admin.content.strategic_planning.partials.crud')
@endsection
@include('admin.content.strategic_planning.partials.crud-assets')
