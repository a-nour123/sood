@extends('admin/layouts/contentLayoutMaster')
@section('title', __('locale.StrategicGoals'))
@php
    $users = [];
    foreach ($options['users'] as $user) { $users[$user->id] = $user->name; }
    $departments = [];
    foreach ($options['departments'] as $department) { $departments[$department->id] = $department->name; }
    $plans = [];
    foreach ($options['plans'] as $plan) { $plans[$plan->id] = $plan->name; }
    $screen = [
        'title' => __('locale.StrategicGoals'),
        'permission' => 'strategic_goal.manage',
        'canShow' => false,
        'canEdit' => auth()->user()->hasPermission('strategic_goal.manage'),
        'canDelete' => auth()->user()->hasPermission('strategic_goal.manage'),
        'listUrl' => route('admin.strategic.goals.ajax.index'),
        'storeUrl' => route('admin.strategic.goals.ajax.store'),
        'updateUrl' => route('admin.strategic.goals.ajax.update', ['id' => '__ID__']),
        'editUrl' => route('admin.strategic.goals.ajax.edit', ['id' => '__ID__']),
        'deleteUrl' => route('admin.strategic.goals.ajax.destroy', ['id' => '__ID__']),
        'filters' => [
            ['name' => 'strategic_plan_id', 'label' => __('strategic.Plan'), 'type' => 'select', 'options' => $plans],
            ['name' => 'status', 'label' => __('strategic.Status'), 'type' => 'select', 'options' => __('strategic.work_statuses')],
            ['name' => 'perspective', 'label' => __('strategic.Perspective'), 'type' => 'select', 'options' => __('strategic.perspectives')],
            ['name' => 'department_id', 'label' => __('strategic.Department'), 'type' => 'select', 'options' => $departments],
        ],
        'columns' => [
            ['label' => __('strategic.Name')], ['label' => __('strategic.Code')], ['label' => __('strategic.Plan')],
            ['label' => __('strategic.Perspective')], ['label' => __('strategic.Status')], ['label' => __('strategic.Weight')],
            ['label' => __('strategic.Progress')], ['label' => __('strategic.DueDate')], ['label' => ''],
        ],
        'dataColumns' => [
            ['data' => 'name'], ['data' => 'code'], ['data' => 'plan'], ['data' => 'perspective'],
            ['data' => 'status'], ['data' => 'weight'], ['data' => 'progress'], ['data' => 'due_date'], ['data' => 'Actions'],
        ],
        'fields' => [
            ['name' => 'strategic_plan_id', 'label' => __('strategic.Plan'), 'type' => 'select', 'options' => $plans, 'required' => true],
            ['name' => 'name', 'label' => __('strategic.Name'), 'required' => true],
            ['name' => 'code', 'label' => __('strategic.Code'), 'required' => true],
            ['name' => 'perspective', 'label' => __('strategic.Perspective'), 'type' => 'select', 'options' => __('strategic.perspectives'), 'required' => true],
            ['name' => 'owner_id', 'label' => __('strategic.Owner'), 'type' => 'select', 'options' => $users],
            ['name' => 'department_id', 'label' => __('strategic.Department'), 'type' => 'select', 'options' => $departments],
            ['name' => 'priority', 'label' => __('strategic.Priority'), 'type' => 'select', 'options' => __('strategic.priorities'), 'required' => true],
            ['name' => 'weight', 'label' => __('strategic.Weight'), 'type' => 'number', 'required' => true, 'default' => 1],
            ['name' => 'start_date', 'label' => __('strategic.StartDate'), 'type' => 'date'],
            ['name' => 'due_date', 'label' => __('strategic.DueDate'), 'type' => 'date'],
            ['name' => 'status', 'label' => __('strategic.Status'), 'type' => 'select', 'options' => __('strategic.work_statuses'), 'required' => true],
            ['name' => 'sort_order', 'label' => '#', 'type' => 'number'],
            ['name' => 'description', 'label' => __('strategic.Description'), 'type' => 'textarea'],
        ],
    ];
@endphp
@section('content')
    @include('admin.content.strategic_planning.partials.crud')
@endsection
@include('admin.content.strategic_planning.partials.crud-assets')
