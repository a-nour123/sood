@extends('admin/layouts/contentLayoutMaster')
@section('title', __('locale.StrategicKris'))
@php
    $users = []; foreach ($options['users'] as $user) { $users[$user->id] = $user->name; }
    $departments = []; foreach ($options['departments'] as $department) { $departments[$department->id] = $department->name; }
    $screen = [
        'title' => __('locale.StrategicKris'),
        'permission' => 'strategic_kri.manage',
        'canShow' => true,
        'canEdit' => auth()->user()->hasPermission('strategic_kri.manage'),
        'canDelete' => auth()->user()->hasPermission('strategic_kri.manage'),
        'listUrl' => route('admin.strategic.kris.ajax.index'),
        'storeUrl' => route('admin.strategic.kris.ajax.store'),
        'updateUrl' => route('admin.strategic.kris.ajax.update', ['id' => '__ID__']),
        'editUrl' => route('admin.strategic.kris.ajax.edit', ['id' => '__ID__']),
        'deleteUrl' => route('admin.strategic.kris.ajax.destroy', ['id' => '__ID__']),
        'showUrl' => route('admin.strategic.kris.show', ['id' => '__ID__']),
        'filters' => [
            ['name' => 'status', 'label' => __('strategic.Status'), 'type' => 'select', 'options' => __('strategic.kri_levels')],
            ['name' => 'department_id', 'label' => __('strategic.Department'), 'type' => 'select', 'options' => $departments],
        ],
        'columns' => [
            ['label' => __('strategic.Name')], ['label' => __('strategic.Current')], ['label' => __('strategic.Warning')],
            ['label' => __('strategic.Critical')], ['label' => __('strategic.Status')], ['label' => __('strategic.Risk')], ['label' => ''],
        ],
        'dataColumns' => [
            ['data' => 'name'], ['data' => 'current_value'], ['data' => 'warning_threshold'],
            ['data' => 'critical_threshold'], ['data' => 'status'], ['data' => 'risk'], ['data' => 'Actions'],
        ],
        'fields' => [
            ['name' => 'name', 'label' => __('strategic.Name'), 'required' => true],
            ['name' => 'measurement_unit', 'label' => __('strategic.Unit')],
            ['name' => 'direction', 'label' => __('strategic.Direction'), 'type' => 'select', 'options' => __('strategic.directions'), 'required' => true],
            ['name' => 'measurement_frequency', 'label' => __('strategic.Frequency'), 'type' => 'select', 'options' => __('strategic.frequencies'), 'required' => true],
            ['name' => 'warning_threshold', 'label' => __('strategic.Warning'), 'type' => 'number'],
            ['name' => 'critical_threshold', 'label' => __('strategic.Critical'), 'type' => 'number'],
            ['name' => 'owner_id', 'label' => __('strategic.Owner'), 'type' => 'select', 'options' => $users],
            ['name' => 'department_id', 'label' => __('strategic.Department'), 'type' => 'select', 'options' => $departments],
            ['name' => 'risk_id', 'label' => __('strategic.Risk'), 'type' => 'number'],
            ['name' => 'description', 'label' => __('strategic.Description'), 'type' => 'textarea'],
        ],
    ];
@endphp
@section('content')
    @include('admin.content.strategic_planning.partials.crud')
@endsection
@include('admin.content.strategic_planning.partials.crud-assets')
