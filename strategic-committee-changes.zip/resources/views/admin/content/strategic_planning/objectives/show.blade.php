@extends('admin/layouts/contentLayoutMaster')
@section('title', $objective->name)
@section('vendor-style')
    @include('admin.content.strategic_planning.partials.select2-style')
@endsection
@section('vendor-script')
    @include('admin.content.strategic_planning.partials.select2-script')
@endsection
@section('content')
    @include('admin.content.strategic_planning.partials.heading', ['title' => $objective->name, 'permission' => null])
    <div class="row">
        <div class="col-lg-8">
            <div class="card"><div class="card-body">
                <p><a href="{{ route('admin.strategic.plans.show', $objective->goal->plan->id) }}">{{ $objective->goal->plan->name }}</a> / {{ $objective->goal->name }}</p>
                <p><strong>{{ __('strategic.OperationalProgress') }}:</strong> {{ $objective->displayedProgress() }}%</p>
                <p><strong>{{ __('strategic.KpiAchievement') }}:</strong> {{ $objective->kpi_achievement ?? __('strategic.NoData') }}</p>
                <p><strong>{{ __('strategic.ProgressBasis') }}:</strong> {{ __('strategic.basis.' . $objective->progress_basis) }}</p>
                <p><strong>{{ __('strategic.Delayed') }}:</strong> {{ $objective->isDelayed() ? __('strategic.Yes') : __('strategic.No') }}</p>
                <p>{{ $objective->description }}</p>
            </div></div>
            <div class="card"><div class="card-header d-flex justify-content-between"><h4>{{ __('locale.StrategicInitiatives') }}</h4></div>
                <table class="table"><tbody>
                    @foreach ($objective->initiatives as $initiative)
                        <tr><td><a href="{{ route('admin.strategic.initiatives.show', $initiative->id) }}">{{ $initiative->name }}</a></td><td>{{ $initiative->displayedProgress() }}%</td><td>{{ $initiative->isDelayed() ? __('strategic.Delayed') : '' }}</td></tr>
                    @endforeach
                </tbody></table>
            </div>
            <div class="card"><div class="card-header"><h4>{{ __('strategic.LinkedKpis') }}</h4></div>
                <div class="card-body">
                    @php $assigned = \App\Services\Strategic\StrategicAccess::isAssigned(auth()->user(), $objective); @endphp
                    @if ($assigned && auth()->user()->hasPermission('strategic_kpi.manage'))
                        <form method="POST" action="{{ route('admin.strategic.objectives.kpis.store', $objective->id) }}" class="row g-1">
                            @csrf
                            <div class="col-md-6"><select class="select2 form-select" name="strategic_kpi_id"><option value="">{{ __('locale.SelectOption') }}</option>@foreach ($kpis as $kpi)<option value="{{ $kpi->id }}">{{ $kpi->name }}</option>@endforeach</select></div>
                            <div class="col-md-3"><input class="form-control" type="number" step="0.01" name="weight" value="1"></div>
                            <div class="col-md-3"><button class="btn btn-primary" type="submit">{{ __('strategic.Add') }}</button></div>
                        </form>
                    @endif
                    <ul class="mt-1">
                        @foreach ($objective->kpis as $kpi)
                            <li><a href="{{ route('admin.strategic.kpis.show', $kpi->id) }}">{{ $kpi->name }}</a> — {{ $kpi->achievement }}% ({{ __('strategic.kpi_statuses.' . $kpi->status) }})</li>
                        @endforeach
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card"><div class="card-header"><h4>{{ __('strategic.LinkRisk') }}</h4></div>
                <div class="card-body">
                    @if ($assigned && auth()->user()->hasPermission('strategic_risk.manage'))
                        <form method="POST" action="{{ route('admin.strategic.objectives.risks.store', $objective->id) }}">
                            @csrf
                            <input class="form-control mb-1" name="risk_id" placeholder="ID" required>
                            <textarea class="form-control mb-1" name="notes" placeholder="{{ __('strategic.Comments') }}"></textarea>
                            <button class="btn btn-primary btn-sm" type="submit">{{ __('strategic.Add') }}</button>
                        </form>
                    @endif
                    @foreach ($objective->riskAssociations as $link)
                        @php $summary = $link->risk ? \App\Services\Strategic\StrategicRiskReader::summarize($link->risk) : ['subject' => $link->risk_snapshot, 'score' => $link->score_at_link, 'residual' => null, 'treatment' => null, 'band' => 'unknown', 'status' => null]; @endphp
                        <div class="border rounded p-1 mb-1 {{ $summary['band'] === 'critical' || $summary['band'] === 'high' ? 'border-danger' : '' }}">
                            <strong>{{ $summary['subject'] }}</strong>
                            <div>{{ __('strategic.InherentScore') }}: {{ $summary['score'] }}</div>
                            <div>{{ __('strategic.Residual') }}: {{ $summary['residual'] }}</div>
                            <div>{{ __('strategic.Treatment') }}: {{ $summary['treatment'] }}</div>
                            <div>{{ __('strategic.Status') }}: {{ $summary['status'] ?? ($link->unlinked_at ? __('strategic.HistoricalRisks') : '') }}</div>
                            @if (!$link->unlinked_at)
                                <div class="small">{{ __('strategic.HighRisk') }}: {{ in_array($summary['band'], ['high', 'critical'], true) ? __('strategic.Yes') : __('strategic.No') }}</div>
                            @else
                                <div class="small text-muted">{{ $link->unlinked_at }}</div>
                            @endif
                        </div>
                    @endforeach
                </div>
            </div>
            <div class="card"><div class="card-header"><h4>{{ __('strategic.LinkCompliance') }}</h4></div>
                <div class="card-body">
                    @if ($assigned && auth()->user()->hasPermission('strategic_objective.manage'))
                        <form method="POST" action="{{ route('admin.strategic.objectives.compliance.store', $objective->id) }}">
                            @csrf
                            <select class="select2 form-select mb-1" name="framework_id"><option value="">{{ __('locale.SelectOption') }}</option>@foreach ($frameworks as $framework)<option value="{{ $framework->id }}">{{ $framework->name }}</option>@endforeach</select>
                            <input class="form-control mb-1" name="family_id" placeholder="{{ __('strategic.Domain') }} ID">
                            <input class="form-control mb-1" name="framework_control_id" placeholder="{{ __('strategic.Control') }} ID">
                            <input class="form-control mb-1" name="framework_control_test_id" placeholder="{{ __('strategic.Assessment') }} ID">
                            <input class="form-control mb-1" name="framework_control_test_audit_id" placeholder="{{ __('strategic.Audit') }} ID">
                            <textarea class="form-control mb-1" name="gap_note" placeholder="{{ __('strategic.GapNote') }}"></textarea>
                            <button class="btn btn-primary btn-sm" type="submit">{{ __('strategic.Add') }}</button>
                        </form>
                    @endif
                    <ul class="mt-1">
                        @foreach ($objective->complianceLinks as $link)
                            <li>
                                {{ $link->framework_snapshot ?: optional($link->framework)->name }}
                                {{ optional($link->family)->name }}
                                {{ optional($link->control)->short_name }}
                                @if ($link->framework_control_test_id) {{ __('strategic.Assessment') }} #{{ $link->framework_control_test_id }} @endif
                                @if ($link->framework_control_test_audit_id) {{ __('strategic.Audit') }} #{{ $link->framework_control_test_audit_id }} @endif
                                <div class="small">{{ $link->gap_note }}</div>
                            </li>
                        @endforeach
                    </ul>
                </div>
            </div>
        </div>
    </div>
@endsection
