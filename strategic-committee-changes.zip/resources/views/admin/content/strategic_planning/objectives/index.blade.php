@extends('admin/layouts/contentLayoutMaster')
@section('title', __('locale.StrategicObjectives'))
@php
    $users = []; foreach ($options['users'] as $user) { $users[$user->id] = $user->name; }
    $departments = []; foreach ($options['departments'] as $department) { $departments[$department->id] = $department->name; }
    $goals = []; foreach ($options['goals'] as $goal) { $goals[$goal->id] = $goal->name; }
    $screen = [
        'title' => __('locale.StrategicObjectives'),
        'permission' => 'strategic_objective.manage',
        'canShow' => true,
        'canEdit' => auth()->user()->hasPermission('strategic_objective.manage'),
        'canDelete' => auth()->user()->hasPermission('strategic_objective.manage'),
        'listUrl' => route('admin.strategic.objectives.ajax.index'),
        'storeUrl' => route('admin.strategic.objectives.ajax.store'),
        'updateUrl' => route('admin.strategic.objectives.ajax.update', ['id' => '__ID__']),
        'editUrl' => route('admin.strategic.objectives.ajax.edit', ['id' => '__ID__']),
        'deleteUrl' => route('admin.strategic.objectives.ajax.destroy', ['id' => '__ID__']),
        'showUrl' => route('admin.strategic.objectives.show', ['id' => '__ID__']),
        'filters' => [
            ['name' => 'strategic_goal_id', 'label' => __('strategic.Goal'), 'type' => 'select', 'options' => $goals],
            ['name' => 'status', 'label' => __('strategic.Status'), 'type' => 'select', 'options' => __('strategic.work_statuses')],
            ['name' => 'department_id', 'label' => __('strategic.Department'), 'type' => 'select', 'options' => $departments],
        ],
        'columns' => [
            ['label' => __('strategic.Name')], ['label' => __('strategic.Code')], ['label' => __('strategic.Goal')],
            ['label' => __('strategic.Status')], ['label' => __('strategic.Progress')], ['label' => __('strategic.DueDate')],
            ['label' => __('strategic.Delayed')], ['label' => ''],
        ],
        'dataColumns' => [
            ['data' => 'name'], ['data' => 'code'], ['data' => 'goal'], ['data' => 'status'],
            ['data' => 'progress'], ['data' => 'due_date'], ['data' => 'delayed'], ['data' => 'Actions'],
        ],
        'fields' => [
            ['name' => 'strategic_goal_id', 'label' => __('strategic.Goal'), 'type' => 'select', 'options' => $goals, 'required' => true],
            ['name' => 'name', 'label' => __('strategic.Name'), 'required' => true],
            ['name' => 'code', 'label' => __('strategic.Code'), 'required' => true],
            ['name' => 'owner_id', 'label' => __('strategic.Owner'), 'type' => 'select', 'options' => $users],
            ['name' => 'department_id', 'label' => __('strategic.Department'), 'type' => 'select', 'options' => $departments],
            ['name' => 'priority', 'label' => __('strategic.Priority'), 'type' => 'select', 'options' => __('strategic.priorities'), 'required' => true],
            ['name' => 'weight', 'label' => __('strategic.Weight'), 'type' => 'number', 'required' => true, 'default' => 1],
            ['name' => 'progress_basis', 'label' => __('strategic.ProgressBasis'), 'type' => 'select', 'options' => __('strategic.basis'), 'required' => true],
            ['name' => 'target_value', 'label' => __('strategic.Target'), 'type' => 'number'],
            ['name' => 'measurement_unit', 'label' => __('strategic.Unit')],
            ['name' => 'start_date', 'label' => __('strategic.StartDate'), 'type' => 'date'],
            ['name' => 'due_date', 'label' => __('strategic.DueDate'), 'type' => 'date'],
            ['name' => 'status', 'label' => __('strategic.Status'), 'type' => 'select', 'options' => __('strategic.work_statuses'), 'required' => true],
            ['name' => 'description', 'label' => __('strategic.Description'), 'type' => 'textarea'],
        ],
    ];
@endphp
@section('content')
    @include('admin.content.strategic_planning.partials.crud')
@endsection
@include('admin.content.strategic_planning.partials.crud-assets')
