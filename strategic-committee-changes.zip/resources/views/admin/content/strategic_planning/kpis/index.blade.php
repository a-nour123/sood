@extends('admin/layouts/contentLayoutMaster')
@section('title', __('locale.StrategicKpis'))
@php
    $users = []; foreach ($options['users'] as $user) { $users[$user->id] = $user->name; }
    $departments = []; foreach ($options['departments'] as $department) { $departments[$department->id] = $department->name; }
    $objectives = []; foreach ($options['objectives'] as $objective) { $objectives[$objective->id] = $objective->name; }
    $screen = [
        'title' => __('locale.StrategicKpis'),
        'permission' => 'strategic_kpi.manage',
        'canShow' => true,
        'canEdit' => auth()->user()->hasPermission('strategic_kpi.manage'),
        'canDelete' => auth()->user()->hasPermission('strategic_kpi.manage'),
        'listUrl' => route('admin.strategic.kpis.ajax.index'),
        'storeUrl' => route('admin.strategic.kpis.ajax.store'),
        'updateUrl' => route('admin.strategic.kpis.ajax.update', ['id' => '__ID__']),
        'editUrl' => route('admin.strategic.kpis.ajax.edit', ['id' => '__ID__']),
        'deleteUrl' => route('admin.strategic.kpis.ajax.destroy', ['id' => '__ID__']),
        'showUrl' => route('admin.strategic.kpis.show', ['id' => '__ID__']),
        'filters' => [
            ['name' => 'status', 'label' => __('strategic.Status'), 'type' => 'select', 'options' => __('strategic.kpi_statuses')],
            ['name' => 'department_id', 'label' => __('strategic.Department'), 'type' => 'select', 'options' => $departments],
        ],
        'columns' => [
            ['label' => __('strategic.Name')], ['label' => __('strategic.Code')], ['label' => __('strategic.MeasurementType')],
            ['label' => __('strategic.Frequency')], ['label' => __('strategic.KpiAchievement')], ['label' => __('strategic.Status')], ['label' => ''],
        ],
        'dataColumns' => [
            ['data' => 'name'], ['data' => 'code'], ['data' => 'type'], ['data' => 'frequency'],
            ['data' => 'achievement'], ['data' => 'status'], ['data' => 'Actions'],
        ],
        'fields' => [
            ['name' => 'name', 'label' => __('strategic.Name'), 'required' => true],
            ['name' => 'code', 'label' => __('strategic.Code'), 'required' => true],
            ['name' => 'measurement_type', 'label' => __('strategic.MeasurementType'), 'type' => 'select', 'options' => __('strategic.measurement_types'), 'required' => true],
            ['name' => 'measurement_unit', 'label' => __('strategic.Unit')],
            ['name' => 'direction', 'label' => __('strategic.Direction'), 'type' => 'select', 'options' => __('strategic.directions'), 'required' => true],
            ['name' => 'frequency', 'label' => __('strategic.Frequency'), 'type' => 'select', 'options' => __('strategic.frequencies'), 'required' => true],
            ['name' => 'baseline_value', 'label' => __('strategic.Baseline'), 'type' => 'number'],
            ['name' => 'target_value', 'label' => __('strategic.Target'), 'type' => 'number'],
            ['name' => 'on_track_threshold', 'label' => __('strategic.OnTrackThreshold'), 'type' => 'number', 'required' => true, 'default' => 90],
            ['name' => 'at_risk_threshold', 'label' => __('strategic.AtRiskThreshold'), 'type' => 'number', 'required' => true, 'default' => 70],
            ['name' => 'owner_id', 'label' => __('strategic.Owner'), 'type' => 'select', 'options' => $users],
            ['name' => 'department_id', 'label' => __('strategic.Department'), 'type' => 'select', 'options' => $departments],
            ['name' => 'start_date', 'label' => __('strategic.StartDate'), 'type' => 'date'],
            ['name' => 'target_date', 'label' => __('strategic.DueDate'), 'type' => 'date'],
            ['name' => 'strategic_objective_id', 'label' => __('strategic.Objective'), 'type' => 'select', 'options' => $objectives],
            ['name' => 'link_weight', 'label' => __('strategic.Weight'), 'type' => 'number'],
            ['name' => 'description', 'label' => __('strategic.Description'), 'type' => 'textarea'],
        ],
    ];
@endphp
@section('content')
    @include('admin.content.strategic_planning.partials.crud')
    <p class="mt-1"><a href="{{ route('admin.strategic.kris.index') }}">{{ __('locale.StrategicKris') }}</a></p>
@endsection
@include('admin.content.strategic_planning.partials.crud-assets')
