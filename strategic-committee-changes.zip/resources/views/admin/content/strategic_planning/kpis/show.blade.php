@extends('admin/layouts/contentLayoutMaster')
@section('title', $kpi->name)
@section('vendor-style')
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
@endsection
@section('content')
    @include('admin.content.strategic_planning.partials.heading', ['title' => $kpi->name, 'permission' => null])
    <div class="row">
        <div class="col-lg-5">
            <div class="card"><div class="card-body">
                <p>{{ __('strategic.measurement_types.' . $kpi->measurement_type) }} · {{ __('strategic.directions.' . $kpi->direction) }}</p>
                <p>{{ __('strategic.Baseline') }}: {{ $kpi->baseline_value }} | {{ __('strategic.Target') }}: {{ $kpi->target_value }} | {{ __('strategic.Current') }}: {{ $kpi->current_value }}</p>
                <p>{{ __('strategic.KpiAchievement') }}: {{ $kpi->achievement }}% — {{ __('strategic.kpi_statuses.' . $kpi->status) }}</p>
                <p>{{ __('strategic.OnTrackThreshold') }}: {{ $kpi->on_track_threshold }} / {{ __('strategic.AtRiskThreshold') }}: {{ $kpi->at_risk_threshold }}</p>
                <ul>@foreach ($kpi->objectives as $objective)<li><a href="{{ route('admin.strategic.objectives.show', $objective->id) }}">{{ $objective->name }}</a></li>@endforeach</ul>
            </div></div>
            @php $assigned = \App\Services\Strategic\StrategicAccess::isAssigned(auth()->user(), $kpi); @endphp
            @if ($assigned && auth()->user()->hasPermission('strategic_kpi.manage'))
                <form id="measure-form" class="card"><div class="card-body">
                    @csrf
                    <h4>{{ __('strategic.RecordMeasurement') }}</h4>
                    <input class="form-control mb-1" type="number" step="0.0001" name="actual_value" required>
                    <input class="form-control mb-1" type="date" name="measurement_date" required value="{{ now()->toDateString() }}">
                    <input class="form-control mb-1" name="reporting_period" placeholder="{{ __('strategic.ReportingPeriod') }}">
                    <input class="form-control mb-1" name="evidence" placeholder="{{ __('strategic.Evidence') }}">
                    <textarea class="form-control mb-1" name="comments" placeholder="{{ __('strategic.Comments') }}"></textarea>
                    <button class="btn btn-primary" type="submit">{{ __('strategic.Saved') }}</button>
                </div></form>
            @endif
        </div>
        <div class="col-lg-7">
            <div class="card"><table class="table">
                <thead><tr><th>{{ __('strategic.DueDate') }}</th><th>{{ __('strategic.Current') }}</th><th>{{ __('strategic.KpiAchievement') }}</th><th>{{ __('strategic.Status') }}</th><th>{{ __('strategic.Comments') }}</th><th></th></tr></thead>
                <tbody>
                @foreach ($kpi->measurements as $measurement)
                    <tr>
                        <td>{{ optional($measurement->measurement_date)->toDateString() }}</td>
                        <td>{{ $measurement->actual_value }}</td>
                        <td>{{ $measurement->achievement }}</td>
                        <td>{{ $measurement->approval_status }}</td>
                        <td>{{ $measurement->comments }}</td>
                        <td>
                            @if ($assigned && $measurement->approval_status === 'pending' && auth()->user()->hasPermission('strategic_plan.approve'))
                                <button class="btn btn-sm btn-success decide" data-id="{{ $measurement->id }}" data-decision="approved">{{ __('strategic.action_labels.approve') }}</button>
                                <button class="btn btn-sm btn-danger decide" data-id="{{ $measurement->id }}" data-decision="rejected">{{ __('strategic.action_labels.reject') }}</button>
                            @endif
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table></div>
        </div>
    </div>
@endsection
@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
@endsection
@section('page-script')
    <script>
        $('#measure-form').on('submit', function (event) {
            event.preventDefault();
            $.post(@json(route('admin.strategic.kpis.measurements.store', $kpi->id)), $(this).serialize())
                .done(function (response) {
                    makeAlert('success', response.message, "{{ __('locale.Success') }}");
                    window.setTimeout(function () { window.location.reload(); }, 600);
                })
                .fail(function (xhr) {
                    var responseData = xhr.responseJSON || {};
                    makeAlert('error', responseData.message, "{{ __('locale.Error') }}");
                });
        });
        $('.decide').on('click', function () {
            $.post(@json(route('admin.strategic.kpis.measurements.decide', [$kpi->id, '__ID__'])).replace('__ID__', $(this).data('id')), {
                _token: $('meta[name="csrf-token"]').attr('content'),
                decision: $(this).data('decision')
            }).done(function (response) {
                makeAlert('success', response.message, "{{ __('locale.Success') }}");
                window.setTimeout(function () { window.location.reload(); }, 600);
            }).fail(function (xhr) {
                var responseData = xhr.responseJSON || {};
                makeAlert('error', responseData.message, "{{ __('locale.Error') }}");
            });
        });
    </script>
@endsection
