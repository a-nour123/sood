@extends('admin/layouts/contentLayoutMaster')
@section('title', $plan->name)
@section('vendor-style')
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">
@endsection
@section('content')
    @include('admin.content.strategic_planning.partials.heading', ['title' => $plan->name, 'permission' => null])
    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <p><strong>{{ __('strategic.Code') }}:</strong> {{ $plan->code }}</p>
                    <p><strong>{{ __('strategic.Status') }}:</strong> {{ __('strategic.plan_statuses.' . $plan->status) }}</p>
                    <p><strong>{{ __('strategic.Version') }}:</strong> {{ $plan->version_number }}</p>
                    <p><strong>{{ __('strategic.Owner') }}:</strong> {{ optional($plan->owner)->name }}</p>
                    <p><strong>{{ __('strategic.Department') }}:</strong> {{ optional($plan->department)->name }}</p>
                    <p><strong>{{ __('strategic.StartDate') }}:</strong> {{ optional($plan->start_date)->toDateString() }} — {{ optional($plan->end_date)->toDateString() }}</p>
                    <p><strong>{{ __('strategic.OperationalProgress') }}:</strong> {{ $plan->displayedProgress() }}%</p>
                    <p>{{ $plan->vision }}</p>
                    <p>{{ $plan->mission }}</p>
                    <p>{{ $plan->description }}</p>
                    @if ($plan->approved_at)
                        <p><strong>{{ __('strategic.ApprovedAt') }}:</strong> {{ $plan->approved_at }} — {{ optional($plan->approver)->name }}</p>
                    @endif
                </div>
            </div>
            <div class="card">
                <div class="card-header"><h4>{{ __('locale.StrategicGoals') }}</h4></div>
                <div class="table-responsive">
                    <table class="table">
                        <thead><tr><th>{{ __('strategic.Name') }}</th><th>{{ __('strategic.Perspective') }}</th><th>{{ __('strategic.Progress') }}</th><th></th></tr></thead>
                        <tbody>
                        @forelse ($plan->goals as $goal)
                            <tr>
                                <td>{{ $goal->name }}</td>
                                <td>{{ __('strategic.perspectives.' . $goal->perspective) }}</td>
                                <td>{{ $goal->displayedProgress() }}%</td>
                                <td><a href="{{ route('admin.strategic.objectives.index', ['strategic_goal_id' => $goal->id]) }}">{{ __('strategic.DrillDown') }}</a></td>
                            </tr>
                        @empty
                            <tr><td colspan="4">{{ __('strategic.NoData') }}</td></tr>
                        @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            @php $assigned = \App\Services\Strategic\StrategicAccess::isAssigned(auth()->user(), $plan); @endphp
            @if ($assigned && (auth()->user()->hasPermission('strategic_plan.submit') || auth()->user()->hasPermission('strategic_plan.approve') || auth()->user()->hasPermission('strategic_plan.reject') || auth()->user()->hasPermission('strategic_plan.update')))
                <div class="card">
                    <div class="card-header"><h4>{{ __('strategic.Workflow') }}</h4></div>
                    <div class="card-body">
                        <form id="workflow-form">
                            @csrf
                            <label class="form-label">{{ __('strategic.Comment') }}</label>
                            <textarea class="form-control mb-1" name="comment"></textarea>
                            @php
                                $workflowPermissions = [
                                    'submit' => 'strategic_plan.submit',
                                    'approve' => 'strategic_plan.approve',
                                    'reject' => 'strategic_plan.reject',
                                    'request_changes' => 'strategic_plan.approve',
                                    'activate' => 'strategic_plan.approve',
                                    'suspend' => 'strategic_plan.approve',
                                    'resume' => 'strategic_plan.approve',
                                    'complete' => 'strategic_plan.approve',
                                    'archive' => 'strategic_plan.approve',
                                    'revise' => 'strategic_plan.update',
                                ];
                            @endphp
                            @foreach ($workflowPermissions as $action => $permission)
                                @if ($assigned && auth()->user()->hasPermission($permission) && \App\Services\Strategic\PlanWorkflow::describe($plan->status, $action))
                                    <button class="btn btn-outline-primary btn-sm mb-50 me-50" type="button" data-action="{{ $action }}">{{ __('strategic.action_labels.' . $action) }}</button>
                                @endif
                            @endforeach
                        </form>
                    </div>
                </div>
            @endif
            <div class="card">
                <div class="card-header"><h4>{{ __('strategic.Attachments') }}</h4></div>
                <div class="card-body">
                    @if ($assigned && auth()->user()->hasPermission('strategic_plan.update'))
                        <form id="attachment-form" enctype="multipart/form-data">
                            @csrf
                            <input class="form-control mb-1" type="file" name="file" required>
                            <button class="btn btn-primary btn-sm" type="submit">{{ __('strategic.Add') }}</button>
                        </form>
                    @endif
                    <ul class="mt-1">
                        @foreach ($plan->attachments as $attachment)
                            <li><a href="{{ asset('storage/' . $attachment->path) }}" target="_blank" rel="noopener">{{ $attachment->original_name }}</a></li>
                        @endforeach
                    </ul>
                </div>
            </div>
            <div class="card">
                <div class="card-header"><h4>{{ __('strategic.ApprovalHistory') }}</h4></div>
                <ul class="list-group list-group-flush">
                    @foreach ($plan->approvals as $approval)
                        <li class="list-group-item">
                            <strong>{{ __('strategic.action_labels.' . $approval->action) }}</strong>
                            {{ $approval->from_status }} → {{ $approval->to_status }}
                            <div class="small text-muted">{{ optional($approval->actor)->name }} · {{ $approval->created_at }}</div>
                            <div>{{ $approval->comment }}</div>
                        </li>
                    @endforeach
                </ul>
            </div>
            <div class="card">
                <div class="card-header"><h4>{{ __('strategic.Versions') }}</h4></div>
                <ul class="list-group list-group-flush">
                    @foreach ($plan->versions as $version)
                        <li class="list-group-item">v{{ $version->version_number }} — {{ $version->reason }} <span class="small text-muted">{{ $version->created_at }}</span></li>
                    @endforeach
                </ul>
            </div>
        </div>
    </div>
@endsection
@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
@endsection
@section('page-script')
    <script>
        $('#workflow-form button').on('click', function () {
            $.post(@json(route('admin.strategic.plans.workflow', $plan->id)), {
                _token: $('meta[name="csrf-token"]').attr('content'),
                action: $(this).data('action'),
                comment: $('#workflow-form [name="comment"]').val()
            }).done(function (response) {
                makeAlert('success', response.message, "{{ __('locale.Success') }}");
                window.setTimeout(function () { window.location.reload(); }, 600);
            }).fail(function (xhr) {
                var responseData = xhr.responseJSON || {};
                makeAlert('error', responseData.message, "{{ __('locale.Error') }}");
            });
        });
        $('#attachment-form').on('submit', function (event) {
            event.preventDefault();
            const data = new FormData(this);
            $.ajax({
                url: @json(route('admin.strategic.plans.attachment.store', $plan->id)),
                type: 'POST',
                data: data,
                processData: false,
                contentType: false
            }).done(function (response) {
                makeAlert('success', response.message, "{{ __('locale.Success') }}");
                window.setTimeout(function () { window.location.reload(); }, 600);
            }).fail(function (xhr) {
                var responseData = xhr.responseJSON || {};
                makeAlert('error', responseData.message, "{{ __('locale.Error') }}");
            });
        });
    </script>
@endsection
