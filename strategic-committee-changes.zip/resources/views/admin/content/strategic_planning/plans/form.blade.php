<div class="modal fade" id="strategic-modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <form id="strategic-form" class="modal-content">
            @csrf
            <input type="hidden" name="id">
            <div class="modal-header">
                <h5 class="modal-title">{{ __('locale.StrategicPlans') }}</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body row g-1">
                @foreach ([
                    'name' => __('strategic.Name'),
                    'code' => __('strategic.Code'),
                ] as $field => $label)
                    <div class="col-md-6">
                        <label class="form-label">{{ $label }}</label>
                        <input class="form-control" name="{{ $field }}" required>
                        <small class="text-danger strategic-error strategic-error-{{ $field }}"></small>
                    </div>
                @endforeach
                <div class="col-md-6">
                    <label class="form-label">{{ __('strategic.Owner') }}</label>
                    <select class="select2 form-select" name="owner_id" required>
                        <option value="">{{ __('locale.SelectOption') }}</option>
                        @foreach ($options['users'] as $user)
                            <option value="{{ $user->id }}">{{ $user->name }}</option>
                        @endforeach
                    </select>
                    <small class="text-danger strategic-error strategic-error-owner_id"></small>
                </div>
                <div class="col-md-6">
                    <label class="form-label">{{ __('strategic.Department') }}</label>
                    <select class="select2 form-select" name="department_id">
                        <option value="">{{ __('locale.SelectOption') }}</option>
                        @foreach ($options['departments'] as $department)
                            <option value="{{ $department->id }}">{{ $department->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-6"><label class="form-label">{{ __('strategic.StartDate') }}</label><input class="form-control" type="date" name="start_date" required></div>
                <div class="col-md-6"><label class="form-label">{{ __('strategic.EndDate') }}</label><input class="form-control" type="date" name="end_date" required><small class="text-danger strategic-error strategic-error-end_date"></small></div>
                <div class="col-12"><label class="form-label">{{ __('strategic.Vision') }}</label><textarea class="form-control" name="vision"></textarea></div>
                <div class="col-12"><label class="form-label">{{ __('strategic.Mission') }}</label><textarea class="form-control" name="mission"></textarea></div>
                <div class="col-12"><label class="form-label">{{ __('strategic.Priorities') }}</label><textarea class="form-control" name="strategic_priorities"></textarea></div>
                <div class="col-12"><label class="form-label">{{ __('strategic.Description') }}</label><textarea class="form-control" name="description"></textarea></div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" type="submit">{{ __('locale.Save') ?? __('strategic.Saved') }}</button>
            </div>
        </form>
    </div>
</div>
