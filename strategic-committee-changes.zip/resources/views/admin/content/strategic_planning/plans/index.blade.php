@extends('admin/layouts/contentLayoutMaster')

@section('title', __('locale.StrategicPlans'))

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/dataTables.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/responsive.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">
    @include('admin.content.strategic_planning.partials.select2-style')
@endsection

@section('content')
    @include('admin.content.strategic_planning.partials.heading', ['title' => __('locale.StrategicPlans'), 'permission' => 'strategic_plan.create'])
    <div class="card mb-1">
        <div class="card-body">
            <form id="strategic-filters" class="strategic-live-filter row g-1">
                <div class="col-md-3">
                    <label class="form-label">{{ __('strategic.Status') }}</label>
                    <select class="select2 form-select" name="status">
                        <option value="">{{ __('locale.SelectOption') }}</option>
                        @foreach (__('strategic.plan_statuses') as $key => $label)
                            <option value="{{ $key }}">{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">{{ __('strategic.Department') }}</label>
                    <select class="select2 form-select" name="department_id">
                        <option value="">{{ __('locale.SelectOption') }}</option>
                        @foreach ($options['departments'] as $department)
                            <option value="{{ $department->id }}">{{ $department->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">{{ __('strategic.Owner') }}</label>
                    <select class="select2 form-select" name="owner_id">
                        <option value="">{{ __('locale.SelectOption') }}</option>
                        @foreach ($options['users'] as $user)
                            <option value="{{ $user->id }}">{{ $user->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2"><label class="form-label">{{ __('strategic.StartDate') }}</label><input class="form-control" type="date" name="date_from"><input type="hidden" name="date_column" value="start_date"></div>
            </form>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <table id="strategic-table" class="table table-striped">
                <thead>
                    <tr>
                        <th>{{ __('strategic.Name') }}</th>
                        <th>{{ __('strategic.Code') }}</th>
                        <th>{{ __('strategic.Status') }}</th>
                        <th>{{ __('strategic.Owner') }}</th>
                        <th>{{ __('strategic.Department') }}</th>
                        <th>{{ __('strategic.StartDate') }}</th>
                        <th>{{ __('strategic.EndDate') }}</th>
                        <th>{{ __('strategic.Progress') }}</th>
                        <th></th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
    @include('admin.content.strategic_planning.plans.form')
@endsection

@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/tables/datatable/jquery.dataTables.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.bootstrap5.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>
    @include('admin.content.strategic_planning.partials.select2-script')
@endsection

@section('page-script')
    <script>
        window.StrategicConfig = {
            listUrl: @json(route('admin.strategic.plans.ajax.index')),
            storeUrl: @json(route('admin.strategic.plans.ajax.store')),
            updateUrl: @json(route('admin.strategic.plans.ajax.update', ['id' => '__ID__'])),
            editUrl: @json(route('admin.strategic.plans.ajax.edit', ['id' => '__ID__'])),
            deleteUrl: @json(route('admin.strategic.plans.ajax.destroy', ['id' => '__ID__'])),
            showUrl: @json(route('admin.strategic.plans.show', ['id' => '__ID__'])),
            permissions: {
                show: {{ auth()->user()->hasPermission('strategic_plan.list') ? 'true' : 'false' }},
                edit: {{ auth()->user()->hasPermission('strategic_plan.update') ? 'true' : 'false' }},
                delete: {{ auth()->user()->hasPermission('strategic_plan.delete') ? 'true' : 'false' }}
            },
            labels: {
                view: @json(__('locale.View')),
                edit: @json(__('locale.Edit')),
                delete: @json(__('locale.Delete')),
                confirm: @json(__('locale.AreYouSureToDeleteThisRecord')),
                cancel: @json(__('locale.Cancel'))
            },
            columns: [
                { data: 'name' }, { data: 'code' }, { data: 'status' }, { data: 'owner' },
                { data: 'department' }, { data: 'start_date' }, { data: 'end_date' }, { data: 'progress' },
                { data: 'Actions' }
            ]
        };
    </script>
    <script>
{!! \Illuminate\Support\Facades\Blade::render(file_get_contents(public_path('ajax-files/strategic_planning/list.js'))) !!}
    </script>
@endsection
