@extends('admin/layouts/contentLayoutMaster')
@section('title', __('locale.StrategicReports'))
@section('vendor-style')
    @include('admin.content.strategic_planning.partials.select2-style')
@endsection
@section('vendor-script')
    @include('admin.content.strategic_planning.partials.select2-script')
@endsection
@section('content')
    @include('admin.content.strategic_planning.partials.heading', ['title' => __('locale.StrategicReports'), 'permission' => null])
    <form class="card mb-1 strategic-live-filter" method="GET">
        <div class="card-body row g-1">
            <div class="col-md-3">
                <label class="form-label">{{ __('strategic.ReportType') }}</label>
                <select class="select2 form-select" name="type">
                    <option value="">{{ __('locale.SelectOption') }}</option>
                    @foreach (__('strategic.report_types') as $key => $label)
                        <option value="{{ $key }}" {{ $type === $key ? 'selected' : '' }}>{{ $label }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">{{ __('strategic.Plan') }}</label>
                <select class="select2 form-select" name="plan_id"><option value="">{{ __('locale.SelectOption') }}</option>@foreach ($plans as $plan)<option value="{{ $plan->id }}" {{ (string) ($filters['plan_id'] ?? '') === (string) $plan->id ? 'selected' : '' }}>{{ $plan->name }}</option>@endforeach</select>
            </div>
            <div class="col-md-2">
                <label class="form-label">{{ __('strategic.Department') }}</label>
                <select class="select2 form-select" name="department_id"><option value="">{{ __('locale.SelectOption') }}</option>@foreach ($departments as $department)<option value="{{ $department->id }}" {{ (string) ($filters['department_id'] ?? '') === (string) $department->id ? 'selected' : '' }}>{{ $department->name }}</option>@endforeach</select>
            </div>
            <div class="col-md-2"><label class="form-label">{{ __('strategic.Year') }}</label><input class="form-control" type="number" name="year" value="{{ $filters['year'] ?? '' }}"></div>
        </div>
    </form>
    @if (auth()->user()->hasPermission('strategic_report.export'))
        <div class="mb-1">
            <a class="btn btn-outline-success" href="{{ route('admin.strategic.reports.excel', array_merge(['type' => $type], $filters)) }}">{{ __('strategic.ExportExcel') }}</a>
            <a class="btn btn-outline-danger" href="{{ route('admin.strategic.reports.pdf', array_merge(['type' => $type], $filters)) }}">{{ __('strategic.ExportPdf') }}</a>
        </div>
    @endif
    <div class="card table-responsive">
        <table class="table">
            <thead><tr>@foreach ($headings as $heading)<th>{{ __('strategic.headings.' . $heading) }}</th>@endforeach</tr></thead>
            <tbody>
            @forelse ($rows as $row)
                <tr>@foreach ($row as $cell)<td>{{ $cell }}</td>@endforeach</tr>
            @empty
                <tr><td colspan="{{ max(count($headings), 1) }}">{{ __('strategic.NoData') }}</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
@endsection
