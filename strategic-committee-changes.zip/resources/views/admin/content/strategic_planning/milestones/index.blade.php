@extends('admin/layouts/contentLayoutMaster')
@section('title', __('locale.StrategicMilestones'))
@php
    $users = []; foreach ($options['users'] as $user) { $users[$user->id] = $user->name; }
    $initiatives = []; foreach ($options['initiatives'] as $initiative) { $initiatives[$initiative->id] = $initiative->name; }
    $screen = [
        'title' => __('locale.StrategicMilestones'),
        'permission' => 'strategic_milestone.manage',
        'canShow' => false,
        'canEdit' => auth()->user()->hasPermission('strategic_milestone.manage'),
        'canDelete' => auth()->user()->hasPermission('strategic_milestone.manage'),
        'listUrl' => route('admin.strategic.milestones.ajax.index'),
        'storeUrl' => route('admin.strategic.milestones.ajax.store'),
        'updateUrl' => route('admin.strategic.milestones.ajax.update', ['id' => '__ID__']),
        'editUrl' => route('admin.strategic.milestones.ajax.edit', ['id' => '__ID__']),
        'deleteUrl' => route('admin.strategic.milestones.ajax.destroy', ['id' => '__ID__']),
        'filters' => [
            ['name' => 'strategic_initiative_id', 'label' => __('strategic.Initiative'), 'type' => 'select', 'options' => $initiatives],
            ['name' => 'status', 'label' => __('strategic.Status'), 'type' => 'select', 'options' => __('strategic.work_statuses')],
        ],
        'columns' => [
            ['label' => __('strategic.Name')], ['label' => __('strategic.Initiative')], ['label' => __('strategic.Status')],
            ['label' => __('strategic.PlannedDue')], ['label' => __('strategic.ActualCompletion')],
            ['label' => __('strategic.Completion')], ['label' => __('strategic.Overdue')], ['label' => ''],
        ],
        'dataColumns' => [
            ['data' => 'name'], ['data' => 'initiative'], ['data' => 'status'], ['data' => 'planned_due_date'],
            ['data' => 'actual_completion_date'], ['data' => 'completion'], ['data' => 'overdue'], ['data' => 'Actions'],
        ],
        'fields' => [
            ['name' => 'strategic_initiative_id', 'label' => __('strategic.Initiative'), 'type' => 'select', 'options' => $initiatives, 'required' => true],
            ['name' => 'name', 'label' => __('strategic.Name'), 'required' => true],
            ['name' => 'owner_id', 'label' => __('strategic.Owner'), 'type' => 'select', 'options' => $users],
            ['name' => 'planned_start_date', 'label' => __('strategic.StartDate'), 'type' => 'date'],
            ['name' => 'planned_due_date', 'label' => __('strategic.PlannedDue'), 'type' => 'date'],
            ['name' => 'actual_completion_date', 'label' => __('strategic.ActualCompletion'), 'type' => 'date'],
            ['name' => 'weight', 'label' => __('strategic.Weight'), 'type' => 'number', 'required' => true, 'default' => 1],
            ['name' => 'completion_percentage', 'label' => __('strategic.Completion'), 'type' => 'number', 'required' => true, 'default' => 0],
            ['name' => 'status', 'label' => __('strategic.Status'), 'type' => 'select', 'options' => __('strategic.work_statuses'), 'required' => true],
            ['name' => 'description', 'label' => __('strategic.Description'), 'type' => 'textarea'],
        ],
    ];
@endphp
@section('content')
    @include('admin.content.strategic_planning.partials.crud')
@endsection
@include('admin.content.strategic_planning.partials.crud-assets')
