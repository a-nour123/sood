@extends('admin/layouts/contentLayoutMaster')
@section('title', __('locale.StrategicApprovals'))
@section('content')
    @include('admin.content.strategic_planning.partials.heading', ['title' => __('locale.StrategicApprovals'), 'permission' => null])
    <div class="card table-responsive">
        <table class="table">
            <thead><tr><th>{{ __('strategic.Plan') }}</th><th>{{ __('strategic.Version') }}</th><th>{{ __('strategic.Workflow') }}</th><th>{{ __('strategic.Status') }}</th><th>{{ __('strategic.Comment') }}</th><th>{{ __('strategic.Owner') }}</th><th></th></tr></thead>
            <tbody>
            @foreach ($approvals as $approval)
                <tr>
                    <td><a href="{{ route('admin.strategic.plans.show', $approval->strategic_plan_id) }}">{{ optional($approval->plan)->name }}</a></td>
                    <td>{{ $approval->version_number }}</td>
                    <td>{{ __('strategic.action_labels.' . $approval->action) }}</td>
                    <td>{{ $approval->from_status }} → {{ $approval->to_status }}</td>
                    <td>{{ $approval->comment }}</td>
                    <td>{{ optional($approval->actor)->name }}</td>
                    <td>{{ $approval->created_at }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
    {{ $approvals->links() }}
@endsection
