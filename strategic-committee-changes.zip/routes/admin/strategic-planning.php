<?php

use App\Http\Controllers\admin\strategic_planning\StrategicApprovalController;
use App\Http\Controllers\admin\strategic_planning\StrategicDashboardController;
use App\Http\Controllers\admin\strategic_planning\StrategicGoalController;
use App\Http\Controllers\admin\strategic_planning\StrategicInitiativeController;
use App\Http\Controllers\admin\strategic_planning\StrategicKpiController;
use App\Http\Controllers\admin\strategic_planning\StrategicKriController;
use App\Http\Controllers\admin\strategic_planning\StrategicLookupController;
use App\Http\Controllers\admin\strategic_planning\StrategicMilestoneController;
use App\Http\Controllers\admin\strategic_planning\StrategicNotificationController;
use App\Http\Controllers\admin\strategic_planning\StrategicObjectiveController;
use App\Http\Controllers\admin\strategic_planning\StrategicPlanController;
use App\Http\Controllers\admin\strategic_planning\StrategicReportController;
use App\Http\Controllers\admin\strategic_planning\StrategicRiskPageController;
use Illuminate\Support\Facades\Route;

Route::group([
    'prefix' => 'strategic-planning',
    'as' => 'strategic.',
], function () {
    Route::get('/dashboard', [StrategicDashboardController::class, 'index'])->name('dashboard');
    Route::get('/notifications-settings', [StrategicNotificationController::class, 'index'])->name('notifications');
    Route::get('/dashboard/data', [StrategicDashboardController::class, 'data'])->name('dashboard.data');

    Route::get('/plans', [StrategicPlanController::class, 'index'])->name('plans.index');
    Route::get('/plans/{id}', [StrategicPlanController::class, 'show'])->name('plans.show');
    Route::post('/plans/{id}/workflow', [StrategicPlanController::class, 'workflow'])->name('plans.workflow');
    Route::post('/plans/{id}/override', [StrategicPlanController::class, 'override'])->name('plans.override');
    Route::post('/plans/{id}/attachments', [StrategicPlanController::class, 'upload'])->name('plans.attachment.store');
    Route::delete('/plans/{id}/attachments/{attachmentId}', [StrategicPlanController::class, 'deleteAttachment'])->name('plans.attachment.destroy');

    Route::get('/goals', [StrategicGoalController::class, 'index'])->name('goals.index');
    Route::post('/goals/{id}/override', [StrategicGoalController::class, 'override'])->name('goals.override');

    Route::get('/objectives', [StrategicObjectiveController::class, 'index'])->name('objectives.index');
    Route::get('/objectives/{id}', [StrategicObjectiveController::class, 'show'])->name('objectives.show');
    Route::post('/objectives/{id}/override', [StrategicObjectiveController::class, 'override'])->name('objectives.override');
    Route::post('/objectives/{id}/kpis', [StrategicObjectiveController::class, 'attachKpi'])->name('objectives.kpis.store');
    Route::delete('/objectives/{id}/kpis/{kpiId}', [StrategicObjectiveController::class, 'detachKpi'])->name('objectives.kpis.destroy');
    Route::post('/objectives/{id}/risks', [StrategicObjectiveController::class, 'linkRisk'])->name('objectives.risks.store');
    Route::delete('/objectives/{id}/risks/{linkId}', [StrategicObjectiveController::class, 'unlinkRisk'])->name('objectives.risks.destroy');
    Route::post('/objectives/{id}/compliance', [StrategicObjectiveController::class, 'linkCompliance'])->name('objectives.compliance.store');
    Route::delete('/objectives/{id}/compliance/{linkId}', [StrategicObjectiveController::class, 'unlinkCompliance'])->name('objectives.compliance.destroy');

    Route::get('/initiatives', [StrategicInitiativeController::class, 'index'])->name('initiatives.index');
    Route::get('/initiatives/{id}', [StrategicInitiativeController::class, 'show'])->name('initiatives.show');
    Route::post('/initiatives/{id}/tasks', [StrategicInitiativeController::class, 'createTask'])->name('initiatives.tasks.store');
    Route::post('/initiatives/{id}/tasks/link', [StrategicInitiativeController::class, 'linkTask'])->name('initiatives.tasks.link');
    Route::post('/initiatives/{id}/compliance', [StrategicInitiativeController::class, 'linkCompliance'])->name('initiatives.compliance.store');

    Route::get('/milestones', [StrategicMilestoneController::class, 'index'])->name('milestones.index');
    Route::post('/milestones/{id}/tasks', [StrategicMilestoneController::class, 'createTask'])->name('milestones.tasks.store');
    Route::post('/milestones/{id}/attachments', [StrategicMilestoneController::class, 'upload'])->name('milestones.attachment.store');
    Route::delete('/milestones/{id}/attachments/{attachmentId}', [StrategicMilestoneController::class, 'deleteAttachment'])->name('milestones.attachment.destroy');

    Route::get('/kpis', [StrategicKpiController::class, 'index'])->name('kpis.index');
    Route::get('/kpis/{id}', [StrategicKpiController::class, 'show'])->name('kpis.show');
    Route::post('/kpis/{id}/measurements', [StrategicKpiController::class, 'measure'])->name('kpis.measurements.store');
    Route::post('/kpis/{id}/measurements/{measurementId}', [StrategicKpiController::class, 'decideMeasurement'])->name('kpis.measurements.decide');

    Route::get('/kris', [StrategicKriController::class, 'index'])->name('kris.index');
    Route::get('/kris/{id}', [StrategicKriController::class, 'show'])->name('kris.show');
    Route::post('/kris/{id}/measurements', [StrategicKriController::class, 'measure'])->name('kris.measurements.store');

    Route::get('/risks', [StrategicRiskPageController::class, 'index'])->name('risks.index');
    Route::get('/approvals', [StrategicApprovalController::class, 'index'])->name('approvals.index');
    Route::get('/reports', [StrategicReportController::class, 'index'])->name('reports.index');
    Route::get('/reports/excel', [StrategicReportController::class, 'excel'])->name('reports.excel');
    Route::get('/reports/pdf', [StrategicReportController::class, 'pdf'])->name('reports.pdf');

    Route::group(['prefix' => 'lookups', 'as' => 'lookups.'], function () {
        Route::get('/risks', [StrategicLookupController::class, 'risks'])->name('risks');
        Route::get('/frameworks', [StrategicLookupController::class, 'frameworks'])->name('frameworks');
        Route::get('/families', [StrategicLookupController::class, 'families'])->name('families');
        Route::get('/controls', [StrategicLookupController::class, 'controls'])->name('controls');
        Route::get('/tests', [StrategicLookupController::class, 'tests'])->name('tests');
        Route::get('/audits', [StrategicLookupController::class, 'audits'])->name('audits');
        Route::get('/tasks', [StrategicLookupController::class, 'tasks'])->name('tasks');
        Route::get('/users', [StrategicLookupController::class, 'users'])->name('users');
    });

    foreach ([
        'plans' => StrategicPlanController::class,
        'goals' => StrategicGoalController::class,
        'objectives' => StrategicObjectiveController::class,
        'initiatives' => StrategicInitiativeController::class,
        'milestones' => StrategicMilestoneController::class,
        'kpis' => StrategicKpiController::class,
        'kris' => StrategicKriController::class,
    ] as $prefix => $controller) {
        Route::group(['prefix' => $prefix . '/ajax', 'as' => $prefix . '.ajax.'], function () use ($controller) {
            Route::post('/list', [$controller, 'ajaxList'])->name('index');
            Route::post('/', [$controller, 'store'])->name('store');
            Route::get('/{id}', [$controller, 'edit'])->name('edit');
            Route::put('/{id}', [$controller, 'update'])->name('update');
            Route::delete('/{id}', [$controller, 'destroy'])->name('destroy');
        });
    }
});
