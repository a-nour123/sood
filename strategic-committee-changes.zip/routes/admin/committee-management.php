<?php

use App\Http\Controllers\admin\committee\CommitteeController;
use App\Http\Controllers\admin\committee\DashboardController;
use App\Http\Controllers\admin\committee\DecisionController;
use App\Http\Controllers\admin\committee\GovernanceNotificationController;
use App\Http\Controllers\admin\committee\LookupController;
use App\Http\Controllers\admin\committee\MeetingController;
use App\Http\Controllers\admin\committee\MemberController;
use App\Http\Controllers\admin\committee\ReportController;
use App\Http\Controllers\admin\committee\RequestController;
use App\Http\Controllers\admin\committee\ReviewController;
use App\Http\Controllers\admin\committee\SettingController;
use App\Http\Controllers\admin\committee\VotingController;
use Illuminate\Support\Facades\Route;

Route::group([
    'prefix' => 'committee-management',
    'as' => 'committee.',
], function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/dashboard/data', [DashboardController::class, 'data'])->name('dashboard.data');

    Route::get('/committees', [CommitteeController::class, 'index'])->name('committees.index');
    Route::get('/committees/{id}', [CommitteeController::class, 'show'])->name('committees.show');
    Route::post('/committees/{id}/departments', [CommitteeController::class, 'department'])->name('committees.departments.store');
    Route::delete('/committees/{id}/departments/{departmentId}', [CommitteeController::class, 'removeDepartment'])->name('committees.departments.destroy');
    Route::post('/committees/{id}/members', [CommitteeController::class, 'member'])->name('committees.members.store');
    Route::delete('/committees/{id}/members/{memberId}', [CommitteeController::class, 'removeMember'])->name('committees.members.destroy');
    Route::post('/committees/{id}/request-types', [CommitteeController::class, 'requestTypes'])->name('committees.request-types');

    Route::get('/members', [MemberController::class, 'index'])->name('members.index');

    Route::get('/requests', [RequestController::class, 'index'])->name('requests.index');
    Route::get('/requests/{id}', [RequestController::class, 'show'])->name('requests.show');
    Route::post('/requests/{id}/actions', [RequestController::class, 'act'])->name('requests.act');
    Route::post('/requests/{id}/reviews', [ReviewController::class, 'store'])->name('requests.reviews.store');
    Route::post('/requests/{id}/reviews/{reviewId}/comments', [ReviewController::class, 'comment'])->name('requests.reviews.comment');
    Route::post('/requests/{id}/votes', [VotingController::class, 'cast'])->name('requests.votes.store');
    Route::post('/requests/{id}/votes/close', [VotingController::class, 'close'])->name('requests.votes.close');
    Route::post('/requests/{id}/decisions', [DecisionController::class, 'store'])->name('requests.decisions.store');
    Route::post('/requests/{id}/decisions/{decisionId}/correct', [DecisionController::class, 'correct'])->name('requests.decisions.correct');
    Route::post('/requests/{id}/attachments', [RequestController::class, 'upload'])->name('requests.attachments.store');
    Route::get('/requests/{id}/attachments/{attachmentId}', [RequestController::class, 'downloadAttachment'])->name('requests.attachments.download');

    Route::get('/approvals', [RequestController::class, 'approvals'])->name('approvals.index');
    Route::get('/exceptions', [RequestController::class, 'exceptions'])->name('exceptions.index');
    Route::get('/risk-acceptance', [RequestController::class, 'riskAcceptance'])->name('risks.index');
    Route::get('/reviews', [ReviewController::class, 'index'])->name('reviews.index');
    Route::get('/voting', [VotingController::class, 'index'])->name('voting.index');
    Route::get('/decisions', [DecisionController::class, 'index'])->name('decisions.index');

    Route::get('/meetings', [MeetingController::class, 'index'])->name('meetings.index');
    Route::get('/meetings/{id}', [MeetingController::class, 'show'])->name('meetings.show');
    Route::post('/meetings/{id}/attendees', [MeetingController::class, 'attendees'])->name('meetings.attendees');
    Route::post('/meetings/{id}/attendance/{memberId}', [MeetingController::class, 'attendance'])->name('meetings.attendance');
    Route::post('/meetings/{id}/agendas', [MeetingController::class, 'agenda'])->name('meetings.agendas.store');
    Route::post('/meetings/{id}/minutes', [MeetingController::class, 'minutes'])->name('meetings.minutes');
    Route::post('/meetings/{id}/actions', [MeetingController::class, 'actionItem'])->name('meetings.actions.store');
    Route::post('/meetings/{id}/attachments', [MeetingController::class, 'upload'])->name('meetings.attachments.store');

    Route::get('/reports', [ReportController::class, 'index'])->name('reports.index');
    Route::get('/reports/excel', [ReportController::class, 'excel'])->name('reports.excel');
    Route::get('/reports/pdf', [ReportController::class, 'pdf'])->name('reports.pdf');

    Route::get('/settings/types', [SettingController::class, 'types'])->name('settings.types.index');
    Route::get('/settings/categories', [SettingController::class, 'categories'])->name('settings.categories.index');
    Route::get('/settings/rules', [SettingController::class, 'rulesPage'])->name('settings.rules.index');
    Route::get('/settings/notifications', [GovernanceNotificationController::class, 'index'])->name('settings.notifications');

    Route::get('/lookups/users', [LookupController::class, 'users'])->name('lookups.users');
    Route::get('/lookups/risks', [LookupController::class, 'risks'])->name('lookups.risks');
    Route::get('/lookups/controls', [LookupController::class, 'controls'])->name('lookups.controls');
    Route::get('/lookups/risk/{id}', [RequestController::class, 'risk'])->name('lookups.risk');

    foreach ([
        'committees' => CommitteeController::class,
        'members' => MemberController::class,
        'requests' => RequestController::class,
        'approvals' => RequestController::class,
        'exceptions' => RequestController::class,
        'risks' => RequestController::class,
        'meetings' => MeetingController::class,
    ] as $prefix => $controller) {
        Route::group(['prefix' => $prefix . '/ajax', 'as' => $prefix . '.ajax.'], function () use ($controller, $prefix) {
            Route::post('/list', [$controller, 'ajaxList'])->name('index');
            if ($prefix !== 'members') {
                Route::post('/', [$controller, 'store'])->name('store');
                Route::get('/{id}', [$controller, 'edit'])->name('edit');
                Route::put('/{id}', [$controller, 'update'])->name('update');
                Route::delete('/{id}', [$controller, 'destroy'])->name('destroy');
            }
        });
    }

    Route::group(['prefix' => 'settings/types/ajax', 'as' => 'settings.types.ajax.'], function () {
        Route::post('/list', [SettingController::class, 'typeList'])->name('index');
        Route::post('/', [SettingController::class, 'storeType'])->name('store');
        Route::get('/{id}', [SettingController::class, 'editType'])->name('edit');
        Route::put('/{id}', [SettingController::class, 'storeType'])->name('update');
        Route::delete('/{id}', [SettingController::class, 'destroyType'])->name('destroy');
    });
    Route::group(['prefix' => 'settings/categories/ajax', 'as' => 'settings.categories.ajax.'], function () {
        Route::post('/list', [SettingController::class, 'categoryList'])->name('index');
        Route::post('/', [SettingController::class, 'storeCategory'])->name('store');
        Route::get('/{id}', [SettingController::class, 'editCategory'])->name('edit');
        Route::put('/{id}', [SettingController::class, 'storeCategory'])->name('update');
        Route::delete('/{id}', [SettingController::class, 'destroyCategory'])->name('destroy');
    });
    Route::group(['prefix' => 'settings/rules/ajax', 'as' => 'settings.rules.ajax.'], function () {
        Route::post('/list', [SettingController::class, 'ruleList'])->name('index');
        Route::post('/', [SettingController::class, 'storeRule'])->name('store');
        Route::get('/{id}', [SettingController::class, 'editRule'])->name('edit');
        Route::put('/{id}', [SettingController::class, 'storeRule'])->name('update');
        Route::delete('/{id}', [SettingController::class, 'destroyRule'])->name('destroy');
    });
});
