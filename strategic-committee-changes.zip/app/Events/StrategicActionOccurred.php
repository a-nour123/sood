<?php

namespace App\Events;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class StrategicActionOccurred
{
    use Dispatchable, SerializesModels;

    public $subject;

    public $action;

    public $properties;

    public function __construct(Model $subject, string $action, array $properties = [])
    {
        $this->subject = $subject;
        $this->action = $action;
        $this->properties = $properties;
    }
}
