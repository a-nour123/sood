<?php

namespace App\Services\Strategic;

use App\Models\StrategicApproval;
use App\Models\StrategicGoal;
use App\Models\StrategicInitiative;
use App\Models\StrategicMilestone;
use App\Models\StrategicObjective;
use App\Models\StrategicPlan;
use App\Models\StrategicPlanVersion;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class StrategicWorkflowService
{
    public static function act(StrategicPlan $plan, string $action, ?string $comment = null): array
    {
        $transition = PlanWorkflow::describe($plan->status, $action);
        if (!$transition) {
            return ['ok' => false, 'message' => __('strategic.InvalidTransition')];
        }
        if ($transition['comment'] && trim((string) $comment) === '') {
            return ['ok' => false, 'message' => __('strategic.CommentRequired')];
        }
        $user = Auth::user();
        if (!$user || !$user->hasPermission($transition['permission'])) {
            return ['ok' => false, 'message' => __('locale.YouDonotHavePermissionToDoThat'), 'code' => 403];
        }
        if (!StrategicAccess::isAssigned($user, $plan)) {
            return ['ok' => false, 'message' => __('locale.YouDonotHavePermissionToDoThat'), 'code' => 403];
        }

        DB::transaction(function () use ($plan, $action, $comment, $transition) {
            $from = $plan->status;
            if ($action === 'revise') {
                self::snapshot($plan, $comment);
                $plan->version_number = (int) $plan->version_number + 1;
            }
            $plan->status = $transition['to'];
            if ($action === 'approve') {
                $plan->approved_by = Auth::id();
                $plan->approved_at = now();
            }
            $plan->updated_by = Auth::id();
            $plan->save();

            StrategicApproval::create([
                'strategic_plan_id' => $plan->id,
                'version_number' => $plan->version_number,
                'action' => $action,
                'from_status' => $from,
                'to_status' => $plan->status,
                'comment' => $comment,
                'actor_id' => Auth::id(),
            ]);
            StrategicLogger::log($plan, $action, __('strategic.WorkflowRecorded'), [
                'from' => $from,
                'to' => $plan->status,
                'comment' => $comment,
            ]);
        });

        return ['ok' => true, 'message' => __('strategic.WorkflowSaved')];
    }

    public static function snapshot(StrategicPlan $plan, ?string $reason): void
    {
        $plan->load(['goals.objectives.initiatives.milestones', 'goals.objectives.kpis']);
        $exists = StrategicPlanVersion::where('strategic_plan_id', $plan->id)
            ->where('version_number', $plan->version_number)
            ->exists();
        if ($exists) {
            return;
        }

        StrategicPlanVersion::create([
            'strategic_plan_id' => $plan->id,
            'version_number' => $plan->version_number,
            'reason' => $reason,
            'created_by' => Auth::id(),
            'snapshot' => json_encode([
                'plan' => $plan->only([
                    'name', 'code', 'description', 'vision', 'mission', 'strategic_priorities',
                    'department_id', 'owner_id', 'start_date', 'end_date', 'status',
                    'approved_by', 'approved_at', 'calculated_progress',
                ]),
                'goals' => $plan->goals->map(function (StrategicGoal $goal) {
                    return [
                        'goal' => $goal->toArray(),
                        'objectives' => $goal->objectives->map(function (StrategicObjective $objective) {
                            return [
                                'objective' => $objective->toArray(),
                                'initiatives' => $objective->initiatives->map(function (StrategicInitiative $initiative) {
                                    return [
                                        'initiative' => $initiative->toArray(),
                                        'milestones' => $initiative->milestones->map(function (StrategicMilestone $milestone) {
                                            return $milestone->toArray();
                                        })->all(),
                                    ];
                                })->all(),
                                'kpi_ids' => $objective->kpis->pluck('id')->all(),
                            ];
                        })->all(),
                    ];
                })->all(),
            ]),
        ]);
    }
}
