<?php

namespace App\Services\Strategic;

use App\Models\Department;
use App\Models\StrategicGoal;
use App\Models\StrategicInitiative;
use App\Models\StrategicKpi;
use App\Models\StrategicKri;
use App\Models\StrategicMilestone;
use App\Models\StrategicObjective;
use App\Models\StrategicPlan;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class StrategicNotificationCatalog
{
    public static function definitions(): array
    {
        return [
            'Strategic_Plan_Created' => self::item('strategic_plan.create', '{actor} created strategic plan "{name}".'),
            'Strategic_Plan_Updated' => self::item('strategic_plan.update', '{actor} updated strategic plan "{name}".'),
            'Strategic_Plan_Deleted' => self::item('strategic_plan.delete', '{actor} deleted strategic plan "{name}".'),
            'Strategic_Plan_Attachment' => self::item('strategic_plan.update', '{actor} added an attachment to strategic plan "{name}".'),
            'Strategic_Plan_Submitted' => self::item('strategic_plan.approve', '{actor} submitted strategic plan "{name}" for approval.'),
            'Strategic_Plan_Approved' => self::item('strategic_plan.approve', '{actor} approved strategic plan "{name}".'),
            'Strategic_Plan_Rejected' => self::item('strategic_plan.reject', '{actor} rejected strategic plan "{name}". {comment}'),
            'Strategic_Plan_Changes_Requested' => self::item('strategic_plan.approve', '{actor} requested changes on strategic plan "{name}". {comment}'),
            'Strategic_Plan_Activated' => self::item('strategic_plan.approve', '{actor} activated strategic plan "{name}".'),
            'Strategic_Plan_Suspended' => self::item('strategic_plan.approve', '{actor} suspended strategic plan "{name}". {comment}'),
            'Strategic_Plan_Resumed' => self::item('strategic_plan.approve', '{actor} resumed strategic plan "{name}".'),
            'Strategic_Plan_Completed' => self::item('strategic_plan.approve', '{actor} completed strategic plan "{name}".'),
            'Strategic_Plan_Archived' => self::item('strategic_plan.approve', '{actor} archived strategic plan "{name}".'),
            'Strategic_Plan_Revised' => self::item('strategic_plan.update', '{actor} revised strategic plan "{name}". {comment}'),
            'Strategic_Goal_Created' => self::item('strategic_goal.manage', '{actor} created strategic goal "{name}".'),
            'Strategic_Goal_Updated' => self::item('strategic_goal.manage', '{actor} updated strategic goal "{name}".'),
            'Strategic_Goal_Deleted' => self::item('strategic_goal.manage', '{actor} deleted strategic goal "{name}".'),
            'Strategic_Objective_Created' => self::item('strategic_objective.manage', '{actor} created strategic objective "{name}".'),
            'Strategic_Objective_Updated' => self::item('strategic_objective.manage', '{actor} updated strategic objective "{name}".'),
            'Strategic_Objective_Deleted' => self::item('strategic_objective.manage', '{actor} deleted strategic objective "{name}".'),
            'Strategic_Initiative_Created' => self::item('strategic_initiative.manage', '{actor} created strategic initiative "{name}".'),
            'Strategic_Initiative_Updated' => self::item('strategic_initiative.manage', '{actor} updated strategic initiative "{name}".'),
            'Strategic_Initiative_Deleted' => self::item('strategic_initiative.manage', '{actor} deleted strategic initiative "{name}".'),
            'Strategic_Milestone_Created' => self::item('strategic_milestone.manage', '{actor} created milestone "{name}".'),
            'Strategic_Milestone_Updated' => self::item('strategic_milestone.manage', '{actor} updated milestone "{name}".'),
            'Strategic_Milestone_Deleted' => self::item('strategic_milestone.manage', '{actor} deleted milestone "{name}".'),
            'Strategic_Milestone_Attachment' => self::item('strategic_milestone.manage', '{actor} added evidence to milestone "{name}".'),
            'Strategic_Kpi_Created' => self::item('strategic_kpi.manage', '{actor} created KPI "{name}".'),
            'Strategic_Kpi_Updated' => self::item('strategic_kpi.manage', '{actor} updated KPI "{name}".'),
            'Strategic_Kpi_Deleted' => self::item('strategic_kpi.manage', '{actor} deleted KPI "{name}".'),
            'Strategic_Kpi_Measured' => self::item('strategic_kpi.manage', '{actor} recorded a measurement for KPI "{name}".'),
            'Strategic_Kpi_Decided' => self::item('strategic_plan.approve', '{actor} decided a measurement for KPI "{name}".'),
            'Strategic_Kpi_Below_Target' => self::item('strategic_kpi.manage', 'KPI "{name}" is below target.'),
            'Strategic_Kri_Created' => self::item('strategic_kri.manage', '{actor} created KRI "{name}".'),
            'Strategic_Kri_Updated' => self::item('strategic_kri.manage', '{actor} updated KRI "{name}".'),
            'Strategic_Kri_Deleted' => self::item('strategic_kri.manage', '{actor} deleted KRI "{name}".'),
            'Strategic_Kri_Measured' => self::item('strategic_kri.manage', '{actor} recorded a measurement for KRI "{name}".'),
            'Strategic_Kri_Threshold' => self::item('strategic_kri.manage', 'KRI "{name}" breached its threshold. Status: {status}.'),
            'Strategic_Risk_Linked' => self::item('strategic_risk.manage', '{actor} linked a risk to objective "{name}".'),
            'Strategic_Risk_Unlinked' => self::item('strategic_risk.manage', '{actor} unlinked a risk from objective "{name}".'),
            'Strategic_Risk_Critical' => self::item('strategic_risk.manage', 'Objective "{name}" is affected by a critical risk.'),
            'Strategic_Compliance_Linked' => self::item('strategic_objective.manage', '{actor} linked a compliance record to "{name}".'),
            'Strategic_Task_Created' => self::item('strategic_initiative.manage', '{actor} created a task for "{name}".'),
            'Strategic_Task_Linked' => self::item('strategic_initiative.manage', '{actor} linked a task to "{name}".'),
            'Strategic_Progress_Override' => self::item('strategic_plan.update', '{actor} overrode progress. {comment}'),
        ];
    }

    public static function roles(): array
    {
        return [
            'owner' => __('strategic.notify_roles.owner'),
            'creator' => __('strategic.notify_roles.creator'),
            'department_manager' => __('strategic.notify_roles.department_manager'),
            'assignee' => __('strategic.notify_roles.assignee'),
        ];
    }

    public static function dueDefinitions(): array
    {
        $item = [
            'message' => '"{name}" is due on {due_date}.',
            'variables' => ['name', 'due_date', 'code', 'status', 'actor'],
        ];

        return [
            'Strategic_Plan_Due_Date' => $item,
            'Strategic_Goal_Due_Date' => $item,
            'Strategic_Objective_Due_Date' => $item,
            'Strategic_Initiative_Due_Date' => $item,
            'Strategic_Milestone_Due_Date' => $item,
            'Strategic_Kpi_Due_Date' => $item,
        ];
    }

    public static function dueActionFor(Model $subject): ?string
    {
        $map = [
            StrategicPlan::class => 'Strategic_Plan_Due_Date',
            StrategicGoal::class => 'Strategic_Goal_Due_Date',
            StrategicObjective::class => 'Strategic_Objective_Due_Date',
            StrategicInitiative::class => 'Strategic_Initiative_Due_Date',
            StrategicMilestone::class => 'Strategic_Milestone_Due_Date',
            StrategicKpi::class => 'Strategic_Kpi_Due_Date',
        ];

        return $map[get_class($subject)] ?? null;
    }

    public static function dueDate(Model $subject): ?string
    {
        $value = $subject->due_date ?? $subject->end_date ?? $subject->planned_due_date ?? $subject->target_date ?? null;
        if ($value instanceof \DateTimeInterface) {
            return $value->format('Y-m-d');
        }
        if (!$value) {
            return null;
        }

        try {
            return Carbon::parse($value)->toDateString();
        } catch (\Throwable $exception) {
            return null;
        }
    }

    public static function datesBeforeDue(string $actionName, Model $subject): array
    {
        $due = self::dueDate($subject);
        if (!$due) {
            return [];
        }
        $raw = DB::table('auto_notifies')
            ->join('actions', 'auto_notifies.action_id', '=', 'actions.id')
            ->where('actions.name', $actionName)
            ->value('auto_notifies.date');
        $days = json_decode((string) $raw, true);
        if (!is_array($days)) {
            return [];
        }
        $dates = [];
        foreach ($days as $day) {
            $dates[] = Carbon::parse($due)->subDays((int) $day)->toDateString();
        }

        return array_values(array_unique($dates));
    }

    public static function canonical(Model $subject, string $action): ?string
    {
        if (isset(self::definitions()[$action])) {
            return $action;
        }

        $mapped = [
            'goal_created' => 'Strategic_Goal_Created',
            'objective_created' => 'Strategic_Objective_Created',
            'milestone_created' => 'Strategic_Milestone_Created',
            'risk_linked' => 'Strategic_Risk_Linked',
            'risk_unlinked' => 'Strategic_Risk_Unlinked',
            'compliance_linked' => 'Strategic_Compliance_Linked',
            'kri_measured' => 'Strategic_Kri_Measured',
            'measurement_recorded' => 'Strategic_Kpi_Measured',
            'measurement_approved' => 'Strategic_Kpi_Decided',
            'measurement_rejected' => 'Strategic_Kpi_Decided',
            'task_created' => 'Strategic_Task_Created',
            'task_linked' => 'Strategic_Task_Linked',
            'progress_override' => 'Strategic_Progress_Override',
            'submit' => 'Strategic_Plan_Submitted',
            'approve' => 'Strategic_Plan_Approved',
            'reject' => 'Strategic_Plan_Rejected',
            'request_changes' => 'Strategic_Plan_Changes_Requested',
            'activate' => 'Strategic_Plan_Activated',
            'suspend' => 'Strategic_Plan_Suspended',
            'resume' => 'Strategic_Plan_Resumed',
            'complete' => 'Strategic_Plan_Completed',
            'archive' => 'Strategic_Plan_Archived',
            'revise' => 'Strategic_Plan_Revised',
        ];
        if (isset($mapped[$action])) {
            return $mapped[$action];
        }
        if ($action === 'attachment_added') {
            return $subject instanceof StrategicMilestone ? 'Strategic_Milestone_Attachment' : 'Strategic_Plan_Attachment';
        }

        $byClass = [
            StrategicPlan::class => ['created' => 'Strategic_Plan_Created', 'updated' => 'Strategic_Plan_Updated', 'deleted' => 'Strategic_Plan_Deleted'],
            StrategicGoal::class => ['updated' => 'Strategic_Goal_Updated', 'deleted' => 'Strategic_Goal_Deleted'],
            StrategicObjective::class => ['updated' => 'Strategic_Objective_Updated', 'deleted' => 'Strategic_Objective_Deleted'],
            StrategicInitiative::class => ['created' => 'Strategic_Initiative_Created', 'updated' => 'Strategic_Initiative_Updated', 'deleted' => 'Strategic_Initiative_Deleted'],
            StrategicMilestone::class => ['updated' => 'Strategic_Milestone_Updated', 'deleted' => 'Strategic_Milestone_Deleted'],
            StrategicKpi::class => ['created' => 'Strategic_Kpi_Created', 'updated' => 'Strategic_Kpi_Updated', 'deleted' => 'Strategic_Kpi_Deleted'],
            StrategicKri::class => ['created' => 'Strategic_Kri_Created', 'updated' => 'Strategic_Kri_Updated', 'deleted' => 'Strategic_Kri_Deleted'],
        ];

        return $byClass[get_class($subject)][$action] ?? null;
    }

    public static function receivers(Model $subject, string $permission, array $properties): array
    {
        $managerId = null;
        if (!empty($subject->department_id)) {
            $managerId = Department::whereKey($subject->department_id)->value('manager_id');
        }
        return [
            'owner' => self::ids([$subject->owner_id ?? null, $properties['owner_id'] ?? null]),
            'creator' => self::ids([$subject->created_by ?? null, $properties['created_by'] ?? null]),
            'department_manager' => self::ids([$managerId]),
            'assignee' => self::ids([$properties['assignee_id'] ?? null, $properties['submitted_by'] ?? null]),
        ];
    }

    public static function payload(Model $subject, array $properties): Model
    {
        $copy = clone $subject;
        $copy->setAttribute('name', $subject->name ?? ($properties['description'] ?? ''));
        $copy->setAttribute('code', $subject->code ?? '');
        $copy->setAttribute('status', $subject->status ?? ($properties['status'] ?? ''));
        $copy->setAttribute('due_date', self::dueDate($subject) ?: '');
        $copy->setAttribute('actor', optional(auth()->user())->name ?: '');
        $copy->setAttribute('comment', (string) ($properties['comment'] ?? $properties['description'] ?? ''));

        return $copy;
    }

    public static function link(Model $subject, string $action): string
    {
        if (in_array($action, ['Strategic_Task_Created', 'Strategic_Task_Linked', 'Strategic_Task_Deadline'], true)) {
            return route('admin.task.assigned_to_me');
        }
        if ($subject instanceof StrategicPlan) {
            return route('admin.strategic.plans.show', $subject->id);
        }
        if ($subject instanceof StrategicGoal && $subject->strategic_plan_id) {
            return route('admin.strategic.plans.show', $subject->strategic_plan_id);
        }
        if ($subject instanceof StrategicObjective) {
            return route('admin.strategic.objectives.show', $subject->id);
        }
        if ($subject instanceof StrategicInitiative) {
            return route('admin.strategic.initiatives.show', $subject->id);
        }
        if ($subject instanceof StrategicMilestone) {
            return route('admin.strategic.milestones.index');
        }
        if ($subject instanceof StrategicKpi) {
            return route('admin.strategic.kpis.show', $subject->id);
        }
        if ($subject instanceof StrategicKri) {
            return route('admin.strategic.kris.show', $subject->id);
        }

        return route('admin.strategic.dashboard');
    }

    protected static function item(string $permission, string $message): array
    {
        return [
            'permission' => $permission,
            'message' => $message,
            'variables' => ['name', 'actor', 'code', 'status', 'comment'],
        ];
    }

    protected static function ids(array $values): array
    {
        return array_values(array_unique(array_filter(array_map('intval', $values))));
    }
}
