<?php

namespace App\Services\Strategic;

use App\Models\StrategicKpi;
use App\Models\StrategicKpiMeasurement;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class StrategicKpiService
{
    public static function record(StrategicKpi $kpi, array $data): StrategicKpiMeasurement
    {
        return DB::transaction(function () use ($kpi, $data) {
            $result = KpiAchievementCalculator::evaluate(
                $kpi->measurement_type,
                $kpi->direction,
                $kpi->baseline_value,
                $kpi->target_value,
                $data['actual_value'],
                $kpi->on_track_threshold,
                $kpi->at_risk_threshold
            );
            $autoApprove = Auth::user() && Auth::user()->hasPermission('strategic_plan.approve');
            $measurement = StrategicKpiMeasurement::create([
                'strategic_kpi_id' => $kpi->id,
                'actual_value' => $data['actual_value'],
                'measurement_date' => $data['measurement_date'],
                'reporting_period' => $data['reporting_period'] ?? null,
                'submitted_by' => Auth::id(),
                'evidence' => $data['evidence'] ?? null,
                'comments' => $data['comments'] ?? null,
                'approval_status' => $autoApprove ? 'approved' : 'pending',
                'approved_by' => $autoApprove ? Auth::id() : null,
                'approved_at' => $autoApprove ? now() : null,
                'achievement' => $result['achievement'],
            ]);

            if ($autoApprove) {
                StrategicProgressService::refreshKpi($kpi);
                if (in_array($kpi->fresh()->status, ['at_risk', 'off_track'], true)) {
                    event(new \App\Events\StrategicActionOccurred($kpi, 'Strategic_Kpi_Below_Target'));
                }
            }
            StrategicLogger::log($kpi, 'measurement_recorded', $kpi->name, ['measurement_id' => $measurement->id]);

            return $measurement;
        });
    }

    public static function decide(StrategicKpiMeasurement $measurement, string $decision): void
    {
        DB::transaction(function () use ($measurement, $decision) {
            $measurement->approval_status = $decision;
            $measurement->approved_by = Auth::id();
            $measurement->approved_at = now();
            $measurement->save();
            if ($decision === 'approved') {
                StrategicProgressService::refreshKpi($measurement->kpi);
                $kpi = $measurement->kpi->fresh();
                if (in_array($kpi->status, ['at_risk', 'off_track'], true)) {
                    event(new \App\Events\StrategicActionOccurred($kpi, 'Strategic_Kpi_Below_Target'));
                }
            }
            StrategicLogger::log($measurement->kpi, 'measurement_' . $decision, $measurement->kpi->name);
        });
    }
}
