<?php

namespace App\Services\Strategic;

class ProgressCalculator
{
    /**
     * Weighted average of child progress. Non-positive weights are ignored.
     * An empty or unweighted collection returns 0 and never divides by zero.
     */
    public static function weighted(array $items): float
    {
        $weightSum = 0.0;
        $score = 0.0;

        foreach ($items as $item) {
            $weight = (float) ($item['weight'] ?? 0);
            if ($weight <= 0) {
                continue;
            }
            $weightSum += $weight;
            $score += ((float) ($item['progress'] ?? 0)) * $weight;
        }

        if ($weightSum <= 0) {
            return 0.0;
        }

        return round($score / $weightSum, 2);
    }

    public static function displayed(?string $mode, $manualProgress, float $calculated): float
    {
        if ($mode === 'manual' && $manualProgress !== null && $manualProgress !== '') {
            return round((float) $manualProgress, 2);
        }

        return round($calculated, 2);
    }
}
