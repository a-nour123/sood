<?php

namespace App\Services\Strategic;

use App\Models\StrategicGoal;
use App\Models\StrategicInitiative;
use App\Models\StrategicKpi;
use App\Models\StrategicKpiMeasurement;
use App\Models\StrategicKri;
use App\Models\StrategicMilestone;
use App\Models\StrategicObjective;
use App\Models\StrategicObjectiveRisk;
use App\Models\StrategicPlan;
use App\Models\User;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;

class StrategicDashboardService
{
    public static function build(User $user, array $filters): array
    {
        return self::calculate($user, $filters);
    }

    public static function calculate(User $user, array $filters): array
    {
        $plans = self::plans($user, $filters);
        $goals = self::constrain(StrategicGoal::query(), $user, $filters, 'plan');
        $objectives = self::constrain(StrategicObjective::query(), $user, $filters, 'goal.plan');
        $initiatives = self::constrain(StrategicInitiative::query(), $user, $filters, 'objective.goal.plan');

        $high = StrategicRiskReader::highThreshold();
        $critical = StrategicRiskReader::criticalThreshold();

        $atRiskObjectives = (clone $objectives)->where(function (Builder $query) use ($high) {
            $query->where('status', 'at_risk')
                ->orWhere(function (Builder $delayed) {
                    $delayed->whereDate('due_date', '<', now()->toDateString())
                        ->where('calculated_progress', '<', 100)
                        ->whereNotIn('status', ['completed', 'cancelled']);
                })
                ->orWhereHas('risks.riskScoring', function (Builder $score) use ($high) {
                    $score->where('calculated_risk', '>=', $high);
                });
        });

        $delayedInitiatives = (clone $initiatives)
            ->whereDate('due_date', '<', now()->toDateString())
            ->where('progress_percentage', '<', 100)
            ->whereNotIn('status', ['completed', 'cancelled']);

        $activePlans = (clone $plans)->where('status', 'active');
        $achievement = round((float) (clone $activePlans)->avg(DB::raw(
            "CASE WHEN progress_mode = 'manual' THEN manual_progress ELSE calculated_progress END"
        )), 2);

        return [
            'cards' => [
                'plans' => (clone $plans)->count(),
                'active_plans' => (clone $activePlans)->count(),
                'goals' => (clone $goals)->count(),
                'objectives' => (clone $objectives)->count(),
                'active_initiatives' => (clone $initiatives)->where('status', 'in_progress')->count(),
                'achievement' => $achievement ?: 0,
                'at_risk_objectives' => (clone $atRiskObjectives)->count(),
                'delayed_initiatives' => (clone $delayedInitiatives)->count(),
            ],
            'charts' => [
                'goals' => self::grouped($goals, 'perspective'),
                'objectives' => self::grouped($objectives, 'status'),
                'kpis' => self::grouped(self::constrain(StrategicKpi::query(), $user, $filters, 'objectives.goal.plan'), 'status'),
                'monthly' => self::monthly($user, $filters, $filters['year'] ?? now()->year, $filters['period'] ?? 'all'),
                'initiatives' => self::grouped($initiatives, 'status'),
                'risks' => self::riskBands($user, $filters, $high, $critical),
                'budget' => self::budget($initiatives),
                'departments' => self::departments($goals),
            ],
        ];
    }

    public static function plans(User $user, array $filters): Builder
    {
        return self::applyPlanFilters(StrategicAccess::scopeAssignee(StrategicPlan::query(), $user), $filters);
    }

    public static function constrain(Builder $query, User $user, array $filters, ?string $planRelation = null): Builder
    {
        StrategicAccess::scopeAssignee($query, $user);
        if ($planRelation && self::hasPlanConstraint($filters)) {
            $query->whereHas($planRelation, function (Builder $plan) use ($filters) {
                self::applyPlanFilters($plan, $filters);
            });
        }

        return $query;
    }

    public static function filterPlans(User $user)
    {
        $query = StrategicPlan::query()->orderBy('name');
        if (StrategicAccess::isAdmin($user)) {
            return $query->get(['id', 'name']);
        }

        $ownerId = $user->id;

        return $query->where(function (Builder $inner) use ($ownerId) {
            $inner->where('owner_id', $ownerId)
                ->orWhereHas('goals', function (Builder $goal) use ($ownerId) {
                    $goal->where('owner_id', $ownerId);
                })
                ->orWhereHas('goals.objectives', function (Builder $objective) use ($ownerId) {
                    $objective->where('owner_id', $ownerId);
                })
                ->orWhereHas('goals.objectives.initiatives', function (Builder $initiative) use ($ownerId) {
                    $initiative->where('owner_id', $ownerId);
                })
                ->orWhereHas('goals.objectives.kpis', function (Builder $kpi) use ($ownerId) {
                    $kpi->where('owner_id', $ownerId);
                });
        })->get(['id', 'name']);
    }

    public static function applyPlanFilters(Builder $query, array $filters): Builder
    {
        if (!empty($filters['plan_id'])) {
            $query->where('id', $filters['plan_id']);
        }
        if (!empty($filters['department_id'])) {
            $query->where('department_id', $filters['department_id']);
        }
        if (!empty($filters['status'])) {
            $query->where('status', $filters['status']);
        }
        if (!empty($filters['year'])) {
            $year = (int) $filters['year'];
            $query->whereDate('start_date', '<=', $year . '-12-31')
                ->whereDate('end_date', '>=', $year . '-01-01');
        }

        return $query;
    }

    protected static function hasPlanConstraint(array $filters): bool
    {
        return !empty($filters['plan_id']) || !empty($filters['department_id']) || !empty($filters['status']) || !empty($filters['year']);
    }

    protected static function grouped(Builder $query, string $column): array
    {
        return (clone $query)
            ->select($column, DB::raw('COUNT(*) as total'))
            ->groupBy($column)
            ->pluck('total', $column)
            ->toArray();
    }

    protected static function monthly(User $user, array $filters, $year, $period = 'all'): array
    {
        $query = StrategicKpiMeasurement::query()
            ->where('approval_status', 'approved')
            ->whereYear('measurement_date', (int) $year)
            ->whereHas('kpi', function (Builder $kpi) use ($user, $filters) {
                self::constrain($kpi, $user, $filters, 'objectives.goal.plan');
            });
        $quarters = ['q1' => [1, 3], 'q2' => [4, 6], 'q3' => [7, 9], 'q4' => [10, 12]];
        if (isset($quarters[$period])) {
            $query->whereRaw('MONTH(measurement_date) between ? and ?', $quarters[$period]);
        }
        $rows = $query
            ->selectRaw('MONTH(measurement_date) as month_number, AVG(achievement) as average_achievement')
            ->groupBy(DB::raw('MONTH(measurement_date)'))
            ->pluck('average_achievement', 'month_number');

        $series = [];
        for ($month = 1; $month <= 12; $month++) {
            $series[] = round((float) ($rows[$month] ?? 0), 2);
        }

        return $series;
    }

    protected static function riskBands(User $user, array $filters, float $high, float $critical): array
    {
        $scores = StrategicObjectiveRisk::query()
            ->whereNull('unlinked_at')
            ->whereHas('objective', function (Builder $objective) use ($user, $filters) {
                self::constrain($objective, $user, $filters, 'goal.plan');
            })
            ->with('risk.riskScoring')
            ->get()
            ->map(function (StrategicObjectiveRisk $link) {
                return optional(optional($link->risk)->riskScoring)->calculated_risk;
            });

        return [
            'critical' => $scores->filter(function ($score) use ($critical) {
                return $score !== null && (float) $score >= $critical;
            })->count(),
            'high' => $scores->filter(function ($score) use ($high, $critical) {
                return $score !== null && (float) $score >= $high && (float) $score < $critical;
            })->count(),
            'other' => $scores->filter(function ($score) use ($high) {
                return $score === null || (float) $score < $high;
            })->count(),
        ];
    }

    protected static function budget(Builder $initiatives): array
    {
        $estimated = (float) (clone $initiatives)->sum('estimated_budget');
        $actual = (float) (clone $initiatives)->sum('actual_budget');

        return [
            'estimated' => round($estimated, 2),
            'actual' => round($actual, 2),
            'utilization' => $estimated > 0 ? round(($actual / $estimated) * 100, 2) : 0,
        ];
    }

    protected static function departments(Builder $goals): array
    {
        return (clone $goals)
            ->selectRaw("COALESCE(department_id, 0) as department_key, AVG(CASE WHEN progress_mode = 'manual' THEN manual_progress ELSE calculated_progress END) as achievement")
            ->groupBy(DB::raw('COALESCE(department_id, 0)'))
            ->pluck('achievement', 'department_key')
            ->map(function ($value) {
                return round((float) $value, 2);
            })
            ->toArray();
    }
}
