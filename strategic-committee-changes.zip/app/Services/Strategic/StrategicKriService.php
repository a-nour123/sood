<?php

namespace App\Services\Strategic;

use App\Models\StrategicKri;
use App\Models\StrategicKriMeasurement;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class StrategicKriService
{
    public static function record(StrategicKri $kri, array $data): StrategicKriMeasurement
    {
        return DB::transaction(function () use ($kri, $data) {
            $level = KriThresholdEvaluator::level(
                $data['actual_value'],
                $kri->warning_threshold,
                $kri->critical_threshold,
                $kri->direction
            );
            $measurement = StrategicKriMeasurement::create([
                'strategic_kri_id' => $kri->id,
                'actual_value' => $data['actual_value'],
                'measurement_date' => $data['measurement_date'],
                'submitted_by' => Auth::id(),
                'comments' => $data['comments'] ?? null,
                'breach_level' => $level,
            ]);
            $kri->current_value = $data['actual_value'];
            $kri->status = $level;
            $kri->updated_by = Auth::id();
            $kri->save();
            StrategicLogger::log($kri, 'kri_measured', $kri->name, ['level' => $level]);

            if (in_array($level, ['warning', 'critical'], true)) {
                event(new \App\Events\StrategicActionOccurred($kri, 'Strategic_Kri_Threshold', ['status' => $level]));
            }

            return $measurement;
        });
    }
}
