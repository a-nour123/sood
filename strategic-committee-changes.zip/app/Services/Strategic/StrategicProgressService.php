<?php

namespace App\Services\Strategic;

use App\Models\StrategicGoal;
use App\Models\StrategicInitiative;
use App\Models\StrategicKpi;
use App\Models\StrategicMilestone;
use App\Models\StrategicObjective;
use App\Models\StrategicPlan;
use App\Models\StrategicProgressHistory;
use App\Models\StrategicProgressOverride;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class StrategicProgressService
{
    public static function recalculateFromMilestone(StrategicMilestone $milestone): void
    {
        $initiative = $milestone->initiative()->first();
        if ($initiative) {
            self::recalculateInitiative($initiative);
        }
    }

    public static function recalculateInitiative(StrategicInitiative $initiative): void
    {
        $initiative->load('milestones');
        if ($initiative->progress_mode !== 'manual') {
            $items = [];
            foreach ($initiative->milestones as $milestone) {
                $items[] = [
                    'weight' => $milestone->weight,
                    'progress' => $milestone->completion_percentage,
                ];
            }
            $progress = $initiative->milestones->isEmpty()
                ? (float) $initiative->progress_percentage
                : ProgressCalculator::weighted($items);
            $initiative->progress_percentage = $progress;
            $initiative->save();
            self::history($initiative, $progress, 'milestones');
        }

        $objective = $initiative->objective()->first();
        if ($objective) {
            self::recalculateObjective($objective);
        }
    }

    public static function recalculateObjective(StrategicObjective $objective): void
    {
        $objective->load(['initiatives', 'kpis']);
        $kpiItems = [];
        foreach ($objective->kpis as $kpi) {
            $kpiItems[] = [
                'weight' => $kpi->pivot->weight ?? 1,
                'progress' => $kpi->achievement ?? 0,
            ];
        }
        $kpiAchievement = $objective->kpis->isEmpty() ? null : ProgressCalculator::weighted($kpiItems);

        $initiativeItems = [];
        foreach ($objective->initiatives as $initiative) {
            $initiativeItems[] = [
                'weight' => $initiative->weight,
                'progress' => $initiative->displayedProgress(),
            ];
        }
        $initiativeProgress = ProgressCalculator::weighted($initiativeItems);

        $basis = $objective->progress_basis === 'kpis' && $kpiAchievement !== null
            ? 'kpis'
            : 'initiatives';
        $calculated = $basis === 'kpis' ? $kpiAchievement : $initiativeProgress;

        if ($objective->progress_mode !== 'manual') {
            $objective->calculated_progress = $calculated;
        }
        $objective->kpi_achievement = $kpiAchievement;
        $objective->save();
        self::history($objective, $objective->displayedProgress(), $objective->progress_mode === 'manual' ? 'manual' : $basis);

        $goal = $objective->goal()->first();
        if ($goal) {
            self::recalculateGoal($goal);
        }
    }

    public static function recalculateGoal(StrategicGoal $goal): void
    {
        $goal->load('objectives');
        if ($goal->progress_mode !== 'manual') {
            $items = [];
            foreach ($goal->objectives as $objective) {
                $items[] = [
                    'weight' => $objective->weight,
                    'progress' => $objective->displayedProgress(),
                ];
            }
            $goal->calculated_progress = ProgressCalculator::weighted($items);
            $goal->save();
            self::history($goal, $goal->displayedProgress(), 'objectives');
        }

        $plan = $goal->plan()->first();
        if ($plan) {
            self::recalculatePlan($plan);
        }
    }

    public static function recalculatePlan(StrategicPlan $plan): void
    {
        $plan->load('goals');
        if ($plan->progress_mode === 'manual') {
            return;
        }
        $items = [];
        foreach ($plan->goals as $goal) {
            $items[] = [
                'weight' => $goal->weight,
                'progress' => $goal->displayedProgress(),
            ];
        }
        $plan->calculated_progress = ProgressCalculator::weighted($items);
        $plan->save();
        self::history($plan, $plan->displayedProgress(), 'goals');
    }

    public static function override(Model $model, float $value, string $reason): void
    {
        DB::transaction(function () use ($model, $value, $reason) {
            $previous = method_exists($model, 'displayedProgress') ? $model->displayedProgress() : null;
            $model->progress_mode = 'manual';
            $model->manual_progress = $value;
            if ($model instanceof StrategicInitiative) {
                $model->progress_percentage = $value;
            }
            $model->updated_by = Auth::id();
            $model->save();

            StrategicProgressOverride::create([
                'subject_type' => get_class($model),
                'subject_id' => $model->getKey(),
                'previous_value' => $previous,
                'override_value' => $value,
                'reason' => $reason,
                'user_id' => Auth::id(),
            ]);
            self::history($model, $value, 'manual');
            StrategicLogger::log($model, 'progress_override', $reason, ['value' => $value]);

            if ($model instanceof StrategicInitiative) {
                $objective = $model->objective()->first();
                if ($objective) {
                    self::recalculateObjective($objective);
                }
            } elseif ($model instanceof StrategicObjective) {
                $goal = $model->goal()->first();
                if ($goal) {
                    self::recalculateGoal($goal);
                }
            } elseif ($model instanceof StrategicGoal) {
                $plan = $model->plan()->first();
                if ($plan) {
                    self::recalculatePlan($plan);
                }
            }
        });
    }

    public static function refreshKpi(StrategicKpi $kpi): void
    {
        $latest = $kpi->measurements()->where('approval_status', 'approved')->first();
        if (!$latest) {
            $kpi->status = 'not_started';
            $kpi->achievement = null;
            $kpi->save();
        } else {
            $result = KpiAchievementCalculator::evaluate(
                $kpi->measurement_type,
                $kpi->direction,
                $kpi->baseline_value,
                $kpi->target_value,
                $latest->actual_value,
                $kpi->on_track_threshold,
                $kpi->at_risk_threshold
            );
            $kpi->current_value = $latest->actual_value;
            $kpi->achievement = $result['achievement'];
            $kpi->status = $result['status'];
            $kpi->save();
            $latest->achievement = $result['achievement'];
            $latest->save();
        }

        foreach ($kpi->objectives as $objective) {
            self::recalculateObjective($objective);
        }
    }

    protected static function history(Model $model, float $progress, string $source): void
    {
        StrategicProgressHistory::create([
            'subject_type' => get_class($model),
            'subject_id' => $model->getKey(),
            'progress' => $progress,
            'source' => $source,
            'user_id' => Auth::id(),
        ]);
    }
}
