<?php

namespace App\Services\Strategic;

use App\Events\StrategicActionOccurred;
use App\Models\StrategicActivityLog;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class StrategicLogger
{
    public static function log(Model $subject, string $action, string $description, array $properties = []): StrategicActivityLog
    {
        $entry = StrategicActivityLog::create([
            'subject_type' => get_class($subject),
            'subject_id' => $subject->getKey(),
            'action' => $action,
            'description' => $description,
            'properties' => $properties ? json_encode($properties) : null,
            'user_id' => Auth::id(),
        ]);

        if (function_exists('write_log') && Auth::id()) {
            write_log($subject->getKey(), Auth::id(), $description, 'strategic');
        }

        event(new StrategicActionOccurred($subject, $action, $properties + ['description' => $description]));

        return $entry;
    }
}
