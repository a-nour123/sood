<?php

namespace App\Services\Strategic;

use App\Models\ResidualRiskScoringHistory;
use Illuminate\Support\Facades\DB;

class StrategicRiskReader
{
    public static function criticalThreshold(): float
    {
        try {
            $value = DB::table('risk_levels')->orderByDesc('value')->value('value');
            if ($value !== null) {
                return (float) $value;
            }
        } catch (\Throwable $exception) {
        }

        return 8.0;
    }

    public static function highThreshold(): float
    {
        try {
            $values = DB::table('risk_levels')->orderByDesc('value')->pluck('value');
            if ($values->count() >= 2) {
                return (float) $values[1];
            }
            if ($values->count() === 1) {
                return (float) $values[0];
            }
        } catch (\Throwable $exception) {
        }

        return 6.0;
    }

    public static function summarize($risk): array
    {
        $score = optional($risk->riskScoring)->calculated_risk;
        $residual = ResidualRiskScoringHistory::where('risk_id', $risk->id)->orderByDesc('last_update')->value('residual_risk');
        $treatment = optional(optional($risk->mitigation)->planningStrategies)->name;

        return [
            'id' => $risk->id,
            'subject' => $risk->subject,
            'status' => $risk->status,
            'score' => $score,
            'residual' => $residual,
            'treatment' => $treatment,
            'band' => self::band($score),
        ];
    }

    public static function band($score): string
    {
        if ($score === null) {
            return 'unknown';
        }
        if ((float) $score >= self::criticalThreshold()) {
            return 'critical';
        }
        if ((float) $score >= self::highThreshold()) {
            return 'high';
        }

        return 'managed';
    }
}
