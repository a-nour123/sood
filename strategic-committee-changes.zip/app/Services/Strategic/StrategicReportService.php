<?php

namespace App\Services\Strategic;

use App\Models\Department;
use App\Models\StrategicApproval;
use App\Models\StrategicGoal;
use App\Models\StrategicInitiative;
use App\Models\StrategicKpi;
use App\Models\StrategicKri;
use App\Models\StrategicObjective;
use App\Models\StrategicObjectiveRisk;
use App\Models\StrategicPlan;
use App\Models\User;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class StrategicReportService
{
    public static function rows(User $user, string $type, array $filters): array
    {
        switch ($type) {
            case 'goals':
                return self::goals($user, $filters);
            case 'objectives':
                return self::objectives($user, $filters);
            case 'initiatives':
                return self::initiatives($user, $filters);
            case 'kpis':
                return self::kpis($user, $filters);
            case 'kris':
                return self::kris($user, $filters);
            case 'risks':
                return self::risks($user, $filters);
            case 'budget':
                return self::budget($user, $filters);
            case 'departments':
                return self::departments($user, $filters);
            case 'approvals':
                return self::approvals($user, $filters);
            default:
                return self::plans(StrategicDashboardService::plans($user, $filters)->get());
        }
    }

    public static function headings(string $type): array
    {
        $map = [
            'plans' => ['Name', 'Code', 'Status', 'Owner', 'Department', 'Start', 'End', 'Progress', 'Version'],
            'goals' => ['Plan', 'Goal', 'Perspective', 'Weight', 'Status', 'Progress'],
            'objectives' => ['Goal', 'Objective', 'Status', 'Due', 'Progress', 'KPI Achievement', 'Delayed'],
            'initiatives' => ['Objective', 'Initiative', 'Status', 'Progress', 'Estimated', 'Actual', 'Delayed'],
            'kpis' => ['KPI', 'Type', 'Direction', 'Current', 'Target', 'Achievement', 'Status'],
            'kris' => ['KRI', 'Current', 'Warning', 'Critical', 'Status', 'Risk'],
            'risks' => ['Objective', 'Risk', 'Score', 'Residual', 'Treatment', 'Band'],
            'budget' => ['Initiative', 'Department', 'Estimated', 'Actual', 'Variance'],
            'departments' => ['Department', 'Goals', 'Average Progress'],
            'approvals' => ['Plan', 'Version', 'Action', 'From', 'To', 'Actor', 'Comment', 'At'],
        ];

        return $map[$type] ?? $map['plans'];
    }

    protected static function plans(Collection $plans): array
    {
        $plans->load(['owner', 'department']);

        return $plans->map(function (StrategicPlan $plan) {
            return [
                $plan->name,
                $plan->code,
                $plan->status,
                optional($plan->owner)->name,
                optional($plan->department)->name,
                optional($plan->start_date)->toDateString(),
                optional($plan->end_date)->toDateString(),
                $plan->displayedProgress(),
                $plan->version_number,
            ];
        })->all();
    }

    protected static function goals(User $user, array $filters): array
    {
        return StrategicDashboardService::constrain(StrategicGoal::with('plan'), $user, $filters, 'plan')->get()->map(function (StrategicGoal $goal) {
            return [
                optional($goal->plan)->name,
                $goal->name,
                $goal->perspective,
                $goal->weight,
                $goal->status,
                $goal->displayedProgress(),
            ];
        })->all();
    }

    protected static function objectives(User $user, array $filters): array
    {
        return StrategicDashboardService::constrain(StrategicObjective::with('goal'), $user, $filters, 'goal.plan')->get()->map(function (StrategicObjective $objective) {
            return [
                optional($objective->goal)->name,
                $objective->name,
                $objective->status,
                optional($objective->due_date)->toDateString(),
                $objective->displayedProgress(),
                $objective->kpi_achievement,
                $objective->isDelayed() ? 'yes' : 'no',
            ];
        })->all();
    }

    protected static function initiatives(User $user, array $filters): array
    {
        return StrategicDashboardService::constrain(StrategicInitiative::with('objective'), $user, $filters, 'objective.goal.plan')->get()->map(function (StrategicInitiative $initiative) {
            return [
                optional($initiative->objective)->name,
                $initiative->name,
                $initiative->status,
                $initiative->displayedProgress(),
                $initiative->estimated_budget,
                $initiative->actual_budget,
                $initiative->isDelayed() ? 'yes' : 'no',
            ];
        })->all();
    }

    protected static function kpis(User $user, array $filters): array
    {
        return StrategicDashboardService::constrain(StrategicKpi::query(), $user, $filters, 'objectives.goal.plan')->get()->map(function (StrategicKpi $kpi) {
            return [
                $kpi->name,
                $kpi->measurement_type,
                $kpi->direction,
                $kpi->current_value,
                $kpi->target_value,
                $kpi->achievement,
                $kpi->status,
            ];
        })->all();
    }

    protected static function kris(User $user, array $filters): array
    {
        $query = StrategicAccess::scopeAssignee(StrategicKri::with('risk'), $user);
        if (!empty($filters['department_id'])) {
            $query->where('department_id', $filters['department_id']);
        }
        if (!empty($filters['status'])) {
            $query->where('status', $filters['status']);
        }

        return $query->get()->map(function (StrategicKri $kri) {
            return [
                $kri->name,
                $kri->current_value,
                $kri->warning_threshold,
                $kri->critical_threshold,
                $kri->status,
                $kri->risk_snapshot ?: optional($kri->risk)->subject,
            ];
        })->all();
    }

    protected static function risks(User $user, array $filters): array
    {
        return StrategicObjectiveRisk::with(['objective', 'risk.riskScoring', 'risk.mitigation.planningStrategies'])
            ->whereNull('unlinked_at')
            ->whereHas('objective', function ($objective) use ($user, $filters) {
                StrategicDashboardService::constrain($objective, $user, $filters, 'goal.plan');
            })->get()->map(function (StrategicObjectiveRisk $link) {
                $summary = $link->risk ? StrategicRiskReader::summarize($link->risk) : [
                    'subject' => $link->risk_snapshot,
                    'score' => $link->score_at_link,
                    'residual' => null,
                    'treatment' => null,
                    'band' => 'unknown',
                ];

                return [
                    optional($link->objective)->name,
                    $summary['subject'],
                    $summary['score'],
                    $summary['residual'],
                    $summary['treatment'],
                    $summary['band'],
                ];
            })->all();
    }

    protected static function budget(User $user, array $filters): array
    {
        return StrategicDashboardService::constrain(StrategicInitiative::with('department'), $user, $filters, 'objective.goal.plan')->get()->map(function (StrategicInitiative $initiative) {
            $estimated = (float) $initiative->estimated_budget;
            $actual = (float) $initiative->actual_budget;

            return [
                $initiative->name,
                optional($initiative->department)->name,
                $estimated,
                $actual,
                round($actual - $estimated, 2),
            ];
        })->all();
    }

    protected static function departments(User $user, array $filters): array
    {
        $departments = Department::all()->mapWithKeys(function (Department $department) {
            return [$department->id => $department->name];
        });
        $rows = StrategicDashboardService::constrain(StrategicGoal::query(), $user, $filters, 'plan')
            ->selectRaw("COALESCE(department_id, 0) as department_key, COUNT(*) as goal_count, AVG(CASE WHEN progress_mode = 'manual' THEN manual_progress ELSE calculated_progress END) as achievement")
            ->groupBy(DB::raw('COALESCE(department_id, 0)'))
            ->get();

        return $rows->map(function ($row) use ($departments) {
            $name = (int) $row->department_key === 0
                ? __('strategic.Unassigned')
                : ($departments[$row->department_key] ?? $row->department_key);

            return [$name, (int) $row->goal_count, round((float) $row->achievement, 2)];
        })->all();
    }

    protected static function approvals(User $user, array $filters): array
    {
        $planIds = StrategicDashboardService::plans($user, $filters)->pluck('id');

        return StrategicApproval::with(['plan', 'actor'])->whereIn('strategic_plan_id', $planIds)->orderByDesc('id')->get()
            ->map(function (StrategicApproval $approval) {
                return [
                    optional($approval->plan)->name,
                    $approval->version_number,
                    $approval->action,
                    $approval->from_status,
                    $approval->to_status,
                    optional($approval->actor)->name,
                    $approval->comment,
                    optional($approval->created_at)->toDateTimeString(),
                ];
            })->all();
    }
}
