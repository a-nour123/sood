<?php

namespace App\Services\Strategic;

use App\Models\StrategicGoal;
use App\Models\StrategicInitiative;
use App\Models\StrategicKpi;
use App\Models\StrategicKri;
use App\Models\StrategicMilestone;
use App\Models\StrategicObjective;
use App\Models\StrategicPlan;
use App\Models\User;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class StrategicAccess
{
    public static function isAdmin(?User $user): bool
    {
        return $user && (int) $user->role_id === 1;
    }

    public static function scopeAssignee(Builder $query, ?User $user): Builder
    {
        if (!$user || self::isAdmin($user)) {
            return $query;
        }

        return $query->where('owner_id', $user->id);
    }

    public static function scopePlans(Builder $query, User $user): Builder
    {
        if (self::isAdmin($user)) {
            return $query;
        }

        return $query->where(function (Builder $inner) use ($user) {
            $inner->where('owner_id', $user->id)
                ->orWhere('created_by', $user->id)
                ->orWhereNull('department_id');
            if ($user->department_id) {
                $inner->orWhere('department_id', $user->department_id);
            }
        });
    }

    public static function scopeByPlan(Builder $query, User $user, string $planRelation): Builder
    {
        if (self::isAdmin($user)) {
            return $query;
        }

        return $query->where(function (Builder $inner) use ($user, $planRelation) {
            $inner->where('owner_id', $user->id)->orWhere('created_by', $user->id);
            if ($user->department_id) {
                $inner->orWhere('department_id', $user->department_id);
            } else {
                $inner->orWhereNull('department_id');
            }
            $inner->orWhereHas($planRelation, function (Builder $plan) use ($user) {
                self::scopePlans($plan, $user);
            });
        });
    }

    public static function isAssigned(?User $user, Model $model): bool
    {
        if (!$user) {
            return false;
        }
        if (self::isAdmin($user)) {
            return true;
        }

        $records = [$model];
        $plan = self::planOf($model);
        if ($plan && $plan->getKey() !== $model->getKey()) {
            $records[] = $plan;
        }

        foreach ($records as $record) {
            if (!empty($record->owner_id) && (int) $record->owner_id === (int) $user->id) {
                return true;
            }
            if (!empty($record->created_by) && (int) $record->created_by === (int) $user->id) {
                return true;
            }
            if (!empty($record->department_id) && (int) $record->department_id === (int) $user->department_id) {
                return true;
            }
        }

        return false;
    }

    public static function canViewPlan(User $user, StrategicPlan $plan): bool
    {
        if (self::isAdmin($user)) {
            return true;
        }
        if ((int) $plan->owner_id === (int) $user->id || (int) $plan->created_by === (int) $user->id) {
            return true;
        }
        if (!$plan->department_id) {
            return true;
        }

        return (int) $plan->department_id === (int) $user->department_id;
    }

    public static function canView(User $user, Model $model): bool
    {
        $plan = self::planOf($model);
        if ($plan) {
            return self::canViewPlan($user, $plan);
        }
        if (self::isAdmin($user)) {
            return true;
        }
        $ownerId = $model->owner_id ?? null;
        $createdBy = $model->created_by ?? null;
        $departmentId = $model->department_id ?? null;
        if ($ownerId && (int) $ownerId === (int) $user->id) {
            return true;
        }
        if ($createdBy && (int) $createdBy === (int) $user->id) {
            return true;
        }
        if (!$departmentId) {
            return true;
        }

        return (int) $departmentId === (int) $user->department_id;
    }

    public static function planOf(Model $model): ?StrategicPlan
    {
        if ($model instanceof StrategicPlan) {
            return $model;
        }
        if ($model instanceof StrategicGoal) {
            return $model->relationLoaded('plan') ? $model->plan : $model->plan()->first();
        }
        if ($model instanceof StrategicObjective) {
            $goal = $model->relationLoaded('goal') ? $model->goal : $model->goal()->with('plan')->first();

            return $goal ? ($goal->relationLoaded('plan') ? $goal->plan : $goal->plan) : null;
        }
        if ($model instanceof StrategicInitiative) {
            $objective = $model->relationLoaded('objective') ? $model->objective : $model->objective()->with('goal.plan')->first();

            return $objective && $objective->goal ? $objective->goal->plan : null;
        }
        if ($model instanceof StrategicMilestone) {
            $initiative = $model->relationLoaded('initiative') ? $model->initiative : $model->initiative()->with('objective.goal.plan')->first();

            return $initiative && $initiative->objective && $initiative->objective->goal
                ? $initiative->objective->goal->plan
                : null;
        }
        if ($model instanceof StrategicKpi) {
            $objective = $model->objectives()->with('goal.plan')->first();

            return $objective && $objective->goal ? $objective->goal->plan : null;
        }
        if ($model instanceof StrategicKri) {
            return null;
        }

        return null;
    }
}
