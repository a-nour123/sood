<?php

namespace App\Services\Strategic;

class PlanWorkflow
{
    public static function transitions(): array
    {
        return [
            'submit' => ['from' => ['draft', 'rejected'], 'to' => 'under_review', 'comment' => false, 'permission' => 'strategic_plan.submit'],
            'approve' => ['from' => ['under_review'], 'to' => 'approved', 'comment' => false, 'permission' => 'strategic_plan.approve'],
            'reject' => ['from' => ['under_review'], 'to' => 'rejected', 'comment' => true, 'permission' => 'strategic_plan.reject'],
            'request_changes' => ['from' => ['under_review'], 'to' => 'draft', 'comment' => true, 'permission' => 'strategic_plan.approve'],
            'activate' => ['from' => ['approved'], 'to' => 'active', 'comment' => false, 'permission' => 'strategic_plan.approve'],
            'suspend' => ['from' => ['active'], 'to' => 'suspended', 'comment' => true, 'permission' => 'strategic_plan.approve'],
            'resume' => ['from' => ['suspended'], 'to' => 'active', 'comment' => false, 'permission' => 'strategic_plan.approve'],
            'complete' => ['from' => ['active', 'suspended'], 'to' => 'completed', 'comment' => false, 'permission' => 'strategic_plan.approve'],
            'archive' => ['from' => ['approved', 'active', 'suspended', 'completed', 'rejected'], 'to' => 'archived', 'comment' => false, 'permission' => 'strategic_plan.approve'],
            'revise' => ['from' => ['approved', 'active', 'suspended', 'completed', 'archived'], 'to' => 'draft', 'comment' => true, 'permission' => 'strategic_plan.update'],
        ];
    }

    public static function describe(string $status, string $action): ?array
    {
        $transitions = self::transitions();
        if (!isset($transitions[$action])) {
            return null;
        }
        if (!in_array($status, $transitions[$action]['from'], true)) {
            return null;
        }

        return $transitions[$action];
    }

    public static function structureEditable(string $status): bool
    {
        return in_array($status, ['draft', 'rejected'], true);
    }

    public static function executionAllowed(string $status): bool
    {
        return in_array($status, ['draft', 'rejected', 'active'], true);
    }
}
