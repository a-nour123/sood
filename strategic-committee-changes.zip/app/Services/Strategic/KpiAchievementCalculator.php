<?php

namespace App\Services\Strategic;

class KpiAchievementCalculator
{
    public static function evaluate(
        $measurementType,
        $direction,
        $baseline,
        $target,
        $current,
        $onTrackThreshold = 90,
        $atRiskThreshold = 70
    ): array {
        $hasValue = $current !== null && $current !== '';
        if (!$hasValue) {
            return ['achievement' => null, 'status' => 'not_started'];
        }

        $achievement = self::achievement($measurementType, $direction, $baseline, $target, $current);

        return [
            'achievement' => $achievement === null ? null : round($achievement, 2),
            'status' => self::status($achievement, $hasValue, (float) $onTrackThreshold, (float) $atRiskThreshold),
        ];
    }

    public static function achievement($measurementType, $direction, $baseline, $target, $current): ?float
    {
        $type = strtolower((string) $measurementType);
        $currentValue = (float) $current;

        if ($type === 'boolean') {
            $actual = $currentValue >= 1;
            $desired = $target === null || $target === '' ? true : ((float) $target) >= 1;

            return $actual === $desired ? 100.0 : 0.0;
        }

        if (strtolower((string) $direction) === 'lower') {
            return self::lowerIsBetter($baseline, $target, $currentValue);
        }

        return self::higherIsBetter($target, $currentValue);
    }

    public static function higherIsBetter($target, float $current): ?float
    {
        if ($target === null || $target === '' || abs((float) $target) < 0.0000001) {
            return null;
        }

        return ($current / (float) $target) * 100.0;
    }

    public static function lowerIsBetter($baseline, $target, float $current): ?float
    {
        if ($target === null || $target === '') {
            return null;
        }

        $targetValue = (float) $target;

        if ($baseline === null || $baseline === '') {
            if (abs($current) < 0.0000001) {
                return $targetValue >= 0 ? 100.0 : null;
            }
            if ($current <= $targetValue) {
                return 100.0;
            }

            return ($targetValue / $current) * 100.0;
        }

        $baselineValue = (float) $baseline;
        $span = $baselineValue - $targetValue;
        if (abs($span) < 0.0000001) {
            return $current <= $targetValue ? 100.0 : 0.0;
        }

        return (($baselineValue - $current) / $span) * 100.0;
    }

    public static function status(?float $achievement, bool $hasValue, float $onTrack, float $atRisk): string
    {
        if (!$hasValue) {
            return 'not_started';
        }
        if ($achievement === null) {
            return 'off_track';
        }
        if ($achievement >= 100) {
            return 'achieved';
        }
        if ($achievement >= $onTrack) {
            return 'on_track';
        }
        if ($achievement >= $atRisk) {
            return 'at_risk';
        }

        return 'off_track';
    }
}
