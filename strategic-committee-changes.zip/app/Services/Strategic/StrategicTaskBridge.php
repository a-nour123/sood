<?php

namespace App\Services\Strategic;

use App\Events\TaskCreated;
use App\Models\StrategicInitiative;
use App\Models\StrategicMilestone;
use App\Models\StrategicTaskLink;
use App\Models\Task;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class StrategicTaskBridge
{
    public static function create(StrategicInitiative $initiative, ?StrategicMilestone $milestone, array $data): Task
    {
        return DB::transaction(function () use ($initiative, $milestone, $data) {
            $assignee = User::findOrFail($data['assignee_id']);
            $task = Task::create([
                'title' => mb_substr($data['title'], 0, 100),
                'description' => $data['description'] ?: $initiative->name,
                'priority' => self::priority($data['priority'] ?? $initiative->priority),
                'status' => 'Open',
                'start_date' => $data['start_date'] ?? optional($initiative->start_date)->toDateString() ?? now()->toDateString(),
                'due_date' => $data['due_date'] ?? optional($initiative->due_date)->toDateString() ?? now()->addDays(7)->toDateString(),
                'assignable_id' => $assignee->id,
                'assignable_type' => User::class,
                'created_by' => Auth::id(),
            ]);

            StrategicTaskLink::create([
                'task_id' => $task->id,
                'strategic_initiative_id' => $initiative->id,
                'strategic_milestone_id' => $milestone ? $milestone->id : null,
                'task_snapshot' => $task->title,
                'created_by' => Auth::id(),
            ]);

            event(new TaskCreated($task, $assignee, null));
            StrategicLogger::log($initiative, 'task_created', $task->title, ['task_id' => $task->id, 'assignee_id' => $assignee->id]);

            return $task;
        });
    }

    public static function linkExisting(StrategicInitiative $initiative, ?StrategicMilestone $milestone, int $taskId): StrategicTaskLink
    {
        $task = Task::findOrFail($taskId);
        $link = StrategicTaskLink::firstOrCreate(
            [
                'task_id' => $task->id,
                'strategic_initiative_id' => $initiative->id,
                'strategic_milestone_id' => $milestone ? $milestone->id : null,
            ],
            [
                'task_snapshot' => $task->title,
                'created_by' => Auth::id(),
            ]
        );
        StrategicLogger::log($initiative, 'task_linked', $task->title, ['task_id' => $task->id]);

        return $link;
    }

    public static function completion(StrategicInitiative $initiative): array
    {
        $links = $initiative->taskLinks()->with('task')->get();
        $total = $links->count();
        $done = $links->filter(function (StrategicTaskLink $link) {
            $task = $link->task;
            if (!$task) {
                return false;
            }

            return (bool) $task->completed || in_array($task->status, ['Completed', 'Accepted', 'Closed'], true);
        })->count();

        return [
            'total' => $total,
            'completed' => $done,
            'percentage' => $total > 0 ? round(($done / $total) * 100, 2) : 0,
        ];
    }

    protected static function priority(?string $priority): string
    {
        $map = [
            'critical' => 'Urgent',
            'urgent' => 'Urgent',
            'high' => 'High',
            'medium' => 'Normal',
            'normal' => 'Normal',
            'low' => 'Low',
        ];

        return $map[strtolower((string) $priority)] ?? 'Normal';
    }
}
