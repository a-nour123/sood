<?php

namespace App\Services\Strategic;

class KriThresholdEvaluator
{
    public static function level($value, $warning, $critical, $direction = 'higher'): string
    {
        if ($value === null || $value === '') {
            return 'normal';
        }

        $actual = (float) $value;
        $worseWhenLower = strtolower((string) $direction) === 'lower';

        if ($critical !== null && $critical !== '') {
            $criticalValue = (float) $critical;
            if ($worseWhenLower ? $actual <= $criticalValue : $actual >= $criticalValue) {
                return 'critical';
            }
        }

        if ($warning !== null && $warning !== '') {
            $warningValue = (float) $warning;
            if ($worseWhenLower ? $actual <= $warningValue : $actual >= $warningValue) {
                return 'warning';
            }
        }

        return 'normal';
    }
}
