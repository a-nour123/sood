<?php

namespace App\Services\Strategic;

use App\Models\User;
use Illuminate\Support\Facades\Log;

class StrategicNotifier
{
    public static function users(array $userIds, string $message, string $link = ''): void
    {
        $ids = array_values(array_unique(array_filter(array_map('intval', $userIds))));
        foreach ($ids as $userId) {
            try {
                if (class_exists(\Notific::class)) {
                    \Notific::notify($userId, $message, 'notification', $link);
                }
            } catch (\Throwable $exception) {
                Log::warning('Strategic planning notification failed: ' . $exception->getMessage());
            }
        }
    }

    public static function approverIds(): array
    {
        return User::query()
            ->whereHas('role.rolePermissions', function ($query) {
                $query->where('key', 'strategic_plan.approve');
            })
            ->pluck('id')
            ->all();
    }
}
