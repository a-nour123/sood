<?php

namespace App\Services\Governance;

use App\Models\GovernanceCommittee;
use App\Models\GovernanceCommitteeMember;
use App\Models\GovernanceMeeting;
use App\Models\GovernanceRequest;
use App\Models\GovernanceReview;
use App\Models\User;
use Illuminate\Database\Eloquent\Builder;

class GovernanceAccess
{
    public static function isAdmin(?User $user): bool
    {
        return $user && (int) $user->role_id === 1;
    }

    public static function isModuleAdmin(?User $user): bool
    {
        return $user && (self::isAdmin($user) || ($user->role && $user->hasPermission('manage_committee_settings')));
    }

    public static function permits(?User $user, string $permission): bool
    {
        return $user && $user->role && $user->hasPermission($permission);
    }

    public static function allows(?User $user, string $permission, bool $assigned): bool
    {
        return self::permits($user, $permission) && $assigned;
    }

    public static function scopeCommittees(Builder $query, User $user): Builder
    {
        if (self::isModuleAdmin($user)) {
            return $query;
        }

        return $query->where(function (Builder $inner) use ($user) {
            $inner->whereHas('members', function (Builder $members) use ($user) {
                $members->where('user_id', $user->id)->where('status', 'active');
            });
            if ($user->department_id) {
                $inner->orWhereHas('departmentLinks', function (Builder $links) use ($user) {
                    $links->where('department_id', $user->department_id)->whereNull('removed_at');
                });
            }
        });
    }

    public static function scopeRequests(Builder $query, User $user): Builder
    {
        if (self::isModuleAdmin($user)) {
            return $query;
        }

        $committeeIds = self::committeeIds($user);

        return $query->where(function (Builder $inner) use ($user, $committeeIds) {
            $inner->where('requester_id', $user->id)->orWhere('created_by', $user->id);
            if ($user->department_id) {
                $inner->orWhere('department_id', $user->department_id);
            }
            if ($committeeIds) {
                $inner->orWhereIn('assigned_committee_id', $committeeIds);
            }
        });
    }

    public static function committeeIds(User $user): array
    {
        return GovernanceCommitteeMember::query()
            ->where('user_id', $user->id)
            ->where('status', 'active')
            ->pluck('committee_id')
            ->unique()
            ->values()
            ->all();
    }

    public static function canViewCommittee(User $user, GovernanceCommittee $committee): bool
    {
        if (self::isModuleAdmin($user)) {
            return true;
        }
        if (self::membership($user, $committee->id)) {
            return true;
        }
        if ($user->department_id && $committee->departmentLinks()->where('department_id', $user->department_id)->whereNull('removed_at')->exists()) {
            return true;
        }

        return false;
    }

    public static function canViewRequest(User $user, GovernanceRequest $request): bool
    {
        if (self::isModuleAdmin($user)) {
            return true;
        }
        if ((int) $request->requester_id === (int) $user->id || (int) $request->created_by === (int) $user->id) {
            return true;
        }
        if ($user->department_id && (int) $request->department_id === (int) $user->department_id) {
            return true;
        }
        if ($request->assigned_committee_id && self::membership($user, $request->assigned_committee_id)) {
            return true;
        }

        return false;
    }

    public static function membership(User $user, $committeeId): ?GovernanceCommitteeMember
    {
        if (!$committeeId) {
            return null;
        }

        return GovernanceCommitteeMember::query()
            ->where('committee_id', $committeeId)
            ->where('user_id', $user->id)
            ->where('status', 'active')
            ->first();
    }

    public static function assignedToCommittee(User $user, GovernanceCommittee $committee): bool
    {
        if ((int) $committee->created_by === (int) $user->id) {
            return true;
        }
        if ((int) $committee->chairman_id === (int) $user->id || (int) $committee->secretary_id === (int) $user->id) {
            return true;
        }

        return (bool) self::membership($user, $committee->id);
    }

    public static function assignedToRequest(User $user, GovernanceRequest $request): bool
    {
        if ((int) $request->requester_id === (int) $user->id || (int) $request->created_by === (int) $user->id) {
            return true;
        }
        $request->loadMissing('exceptionDetail');
        if ((int) optional($request->exceptionDetail)->owner_id === (int) $user->id) {
            return true;
        }
        if ($request->assigned_committee_id && self::membership($user, $request->assigned_committee_id)) {
            return true;
        }
        if ($request->relationLoaded('reviews')) {
            return $request->reviews->contains(function ($review) use ($user) {
                return (int) $review->reviewer_id === (int) $user->id;
            });
        }

        return GovernanceReview::query()
            ->where('governance_request_id', $request->id)
            ->where('reviewer_id', $user->id)
            ->exists();
    }

    public static function assignedToMeeting(User $user, GovernanceMeeting $meeting): bool
    {
        if ((int) $meeting->created_by === (int) $user->id) {
            return true;
        }
        if ((int) $meeting->chairman_id === (int) $user->id || (int) $meeting->secretary_id === (int) $user->id) {
            return true;
        }
        $meeting->loadMissing('attendees');
        if ($meeting->attendees->contains(function ($attendee) use ($user) {
            return (int) $attendee->user_id === (int) $user->id;
        })) {
            return true;
        }

        return (bool) self::membership($user, $meeting->committee_id);
    }

    public static function canViewReviews(User $user, GovernanceRequest $request): bool
    {
        if (!self::canViewRequest($user, $request)) {
            return false;
        }
        if (self::isAdmin($user) || self::permits($user, 'view_committee_reviews')) {
            return true;
        }

        return (bool) self::membership($user, $request->assigned_committee_id);
    }
}
