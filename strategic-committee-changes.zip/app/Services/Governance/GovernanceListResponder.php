<?php

namespace App\Services\Governance;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class GovernanceListResponder
{
    public static function respond(Builder $query, Request $request, array $searchColumns, array $sortable, callable $transform): JsonResponse
    {
        self::applyFilters($query, $request);
        $total = (clone $query)->count();
        $search = trim((string) $request->input('search.value', ''));
        if ($search !== '' && $searchColumns) {
            $query->where(function (Builder $inner) use ($searchColumns, $search) {
                foreach ($searchColumns as $column) {
                    $inner->orWhere($column, 'like', '%' . $search . '%');
                }
            });
        }
        $filtered = (clone $query)->count();
        $column = $request->input('columns.' . $request->input('order.0.column', 0) . '.data');
        $direction = $request->input('order.0.dir') === 'asc' ? 'asc' : 'desc';
        if ($column && in_array($column, $sortable, true)) {
            $query->orderBy($column, $direction);
        } else {
            $query->orderByDesc('id');
        }
        $length = (int) $request->input('length', 10);
        if ($length < 1 || $length > 200) {
            $length = 10;
        }
        $rows = $query->skip((int) $request->input('start', 0))->take($length)->get();

        return response()->json([
            'draw' => (int) $request->input('draw'),
            'recordsTotal' => $total,
            'recordsFiltered' => $filtered,
            'data' => $rows->map($transform)->values(),
        ]);
    }

    protected static function applyFilters(Builder $query, Request $request): void
    {
        foreach (['status', 'department_id', 'request_type', 'assigned_committee_id', 'priority', 'category_id', 'committee_id', 'member_role', 'meeting_type'] as $field) {
            if ($request->filled($field)) {
                $query->where($field, $request->input($field));
            }
        }
        if ($request->filled('owner_id')) {
            $query->where('requester_id', $request->input('owner_id'));
        }
        if ($request->filled('date_from')) {
            $column = in_array($request->input('date_column'), ['submission_date', 'due_date', 'decided_at', 'created_at', 'meeting_date'], true)
                ? $request->input('date_column') : 'created_at';
            $query->whereDate($column, '>=', $request->input('date_from'));
        }
        if ($request->filled('date_to')) {
            $column = in_array($request->input('date_column'), ['submission_date', 'due_date', 'decided_at', 'created_at', 'meeting_date'], true)
                ? $request->input('date_column') : 'created_at';
            $query->whereDate($column, '<=', $request->input('date_to'));
        }
    }
}
