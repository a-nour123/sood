<?php

namespace App\Services\Governance;

class GovernanceDecisionRules
{
    public static function types(): array
    {
        return [
            'approved',
            'rejected',
            'conditionally_approved',
            'request_changes',
            'request_additional_information',
            'deferred',
            'escalated',
        ];
    }

    public static function riskOutcomes(): array
    {
        return [
            'accept_risk',
            'reject_acceptance',
            'additional_treatment',
            'reassessment',
            'escalate',
        ];
    }

    public static function statusFor(string $decision): string
    {
        $map = [
            'approved' => 'approved',
            'rejected' => 'rejected',
            'conditionally_approved' => 'conditional_approval',
            'request_changes' => 'more_information',
            'request_additional_information' => 'more_information',
            'deferred' => 'deferred',
            'escalated' => 'escalated',
        ];

        return $map[$decision] ?? 'decision_pending';
    }

    public static function validateContent(string $decision, ?string $reason, ?string $conditions): ?string
    {
        if (!in_array($decision, self::types(), true)) {
            return 'invalid_decision';
        }
        if (in_array($decision, ['rejected', 'request_changes', 'request_additional_information', 'deferred', 'escalated'], true)
            && trim((string) $reason) === '') {
            return 'reason_required';
        }
        if ($decision === 'conditionally_approved' && trim((string) $conditions) === '') {
            return 'conditions_required';
        }

        return null;
    }

    public static function votingAllows(string $decision, array $tally, string $mode): ?string
    {
        $gated = ['approved', 'conditionally_approved', 'rejected'];
        if (!in_array($decision, $gated, true) || $mode === 'chairman') {
            return null;
        }
        if (empty($tally['closed'])) {
            return 'voting_open';
        }
        if (in_array($decision, ['approved', 'conditionally_approved'], true) && empty($tally['passed'])) {
            return 'vote_not_passed';
        }
        if ($decision === 'rejected' && empty($tally['failed'])) {
            return 'vote_not_failed';
        }

        return null;
    }

    public static function riskOutcomeAllows(string $decision, ?string $outcome): ?string
    {
        $outcome = (string) $outcome;
        if (!in_array($outcome, self::riskOutcomes(), true)) {
            return 'risk_outcome_required';
        }
        $expected = [
            'approved' => ['accept_risk'],
            'conditionally_approved' => ['accept_risk'],
            'rejected' => ['reject_acceptance'],
            'escalated' => ['escalate'],
            'request_changes' => ['additional_treatment', 'reassessment'],
            'request_additional_information' => ['additional_treatment', 'reassessment'],
        ];
        if (isset($expected[$decision]) && !in_array($outcome, $expected[$decision], true)) {
            return 'risk_outcome_mismatch';
        }

        return null;
    }
}
