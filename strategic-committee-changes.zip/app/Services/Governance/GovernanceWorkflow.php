<?php

namespace App\Services\Governance;

class GovernanceWorkflow
{
    public static function describe(string $status, string $action): ?array
    {
        $map = self::map();
        if (!isset($map[$status][$action])) {
            return null;
        }

        return $map[$status][$action];
    }

    public static function statuses(): array
    {
        return array_keys(self::map());
    }

    public static function editable(string $status): bool
    {
        return in_array($status, ['draft', 'more_information', 'reopened'], true);
    }

    public static function finalStatuses(): array
    {
        return ['approved', 'rejected', 'conditional_approval', 'closed', 'expired', 'cancelled'];
    }

    public static function map(): array
    {
        $cancel = ['to' => 'cancelled', 'permission' => 'update_governance_request', 'comment' => true];

        return [
            'draft' => [
                'submit' => ['to' => 'submitted', 'permission' => 'submit_governance_request', 'comment' => false],
                'cancel' => $cancel,
            ],
            'submitted' => [
                'assign' => ['to' => 'assigned', 'permission' => 'assign_governance_request', 'comment' => false],
                'cancel' => $cancel,
            ],
            'assigned' => [
                'start_review' => ['to' => 'under_review', 'permission' => 'review_governance_request', 'comment' => false],
                'reassign' => ['to' => 'assigned', 'permission' => 'assign_governance_request', 'comment' => true],
                'cancel' => $cancel,
            ],
            'under_review' => [
                'discuss' => ['to' => 'committee_discussion', 'permission' => 'manage_committee_meetings', 'comment' => false],
                'request_info' => ['to' => 'more_information', 'permission' => 'review_governance_request', 'comment' => true],
                'open_decision' => ['to' => 'decision_pending', 'permission' => 'manage_committee_voting', 'comment' => false],
                'cancel' => $cancel,
            ],
            'committee_discussion' => [
                'open_decision' => ['to' => 'decision_pending', 'permission' => 'manage_committee_voting', 'comment' => false],
                'request_info' => ['to' => 'more_information', 'permission' => 'review_governance_request', 'comment' => true],
                'defer' => ['to' => 'deferred', 'permission' => 'issue_governance_decision', 'comment' => true],
            ],
            'decision_pending' => [
                'defer' => ['to' => 'deferred', 'permission' => 'issue_governance_decision', 'comment' => true],
            ],
            'more_information' => [
                'resubmit' => ['to' => 'under_review', 'permission' => 'submit_governance_request', 'comment' => false],
                'cancel' => $cancel,
            ],
            'approved' => [
                'close' => ['to' => 'closed', 'permission' => 'issue_governance_decision', 'comment' => false],
                'reopen' => ['to' => 'reopened', 'permission' => 'reopen_governance_request', 'comment' => true],
            ],
            'conditional_approval' => [
                'close' => ['to' => 'closed', 'permission' => 'issue_governance_decision', 'comment' => false],
                'expire' => ['to' => 'expired', 'permission' => 'issue_governance_decision', 'comment' => false],
                'reopen' => ['to' => 'reopened', 'permission' => 'reopen_governance_request', 'comment' => true],
            ],
            'rejected' => [
                'close' => ['to' => 'closed', 'permission' => 'issue_governance_decision', 'comment' => false],
                'reopen' => ['to' => 'reopened', 'permission' => 'reopen_governance_request', 'comment' => true],
            ],
            'deferred' => [
                'resume' => ['to' => 'under_review', 'permission' => 'review_governance_request', 'comment' => false],
                'close' => ['to' => 'closed', 'permission' => 'issue_governance_decision', 'comment' => false],
            ],
            'escalated' => [
                'reassign' => ['to' => 'assigned', 'permission' => 'assign_governance_request', 'comment' => true],
                'close' => ['to' => 'closed', 'permission' => 'issue_governance_decision', 'comment' => false],
            ],
            'reopened' => [
                'start_review' => ['to' => 'under_review', 'permission' => 'review_governance_request', 'comment' => false],
            ],
            'expired' => [
                'close' => ['to' => 'closed', 'permission' => 'issue_governance_decision', 'comment' => false],
                'reopen' => ['to' => 'reopened', 'permission' => 'reopen_governance_request', 'comment' => true],
            ],
            'closed' => [],
            'cancelled' => [],
        ];
    }
}
