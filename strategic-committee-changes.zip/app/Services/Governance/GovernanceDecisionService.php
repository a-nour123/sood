<?php

namespace App\Services\Governance;

use App\Models\Document;
use App\Models\GovernanceDecision;
use App\Models\GovernanceRequest;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class GovernanceDecisionService
{
    public static function issue(User $actor, GovernanceRequest $request, array $data): array
    {
        return DB::transaction(function () use ($actor, $request, $data) {
            $request = GovernanceRequest::where('id', $request->id)->lockForUpdate()->first();
            if (!in_array($request->status, ['decision_pending', 'under_review', 'committee_discussion'], true)) {
                return self::fail(__('governance.DecisionNotReady'));
            }
            if (optional($request->committee)->approval_mode !== 'chairman' && $request->status !== 'decision_pending') {
                return self::fail(__('governance.DecisionNotReady'));
            }
            $decision = (string) ($data['decision_type'] ?? '');
            if ($error = GovernanceDecisionRules::validateContent($decision, $data['decision_reason'] ?? null, $data['decision_conditions'] ?? null)) {
                return self::fail(__('governance.errors.' . $error));
            }
            if ($error = self::authority($actor, $request, $decision)) {
                return self::fail($error, 403);
            }
            $tally = GovernanceVotingService::currentTally($request);
            if ($error = GovernanceDecisionRules::votingAllows($decision, $tally, optional($request->committee)->approval_mode ?: 'chairman')) {
                return self::fail(__('governance.errors.' . $error));
            }
            if ($request->request_type === 'risk_acceptance') {
                if ($error = GovernanceDecisionRules::riskOutcomeAllows($decision, $data['risk_outcome'] ?? null)) {
                    return self::fail(__('governance.errors.' . $error));
                }
            }
            if (!empty($data['effective_from']) && !empty($data['effective_until']) && $data['effective_until'] < $data['effective_from']) {
                return self::fail(__('governance.InvalidDates'));
            }

            GovernanceDecision::where('governance_request_id', $request->id)->where('is_current', true)->update(['is_current' => false]);
            $record = GovernanceDecision::create([
                'governance_request_id' => $request->id,
                'committee_id' => $request->assigned_committee_id,
                'decision_type' => $decision,
                'decision_number' => self::number($request),
                'decision_reason' => $data['decision_reason'] ?? null,
                'decision_conditions' => $data['decision_conditions'] ?? null,
                'decided_by' => $actor->id,
                'decided_at' => now(),
                'effective_from' => $data['effective_from'] ?: null,
                'effective_until' => $data['effective_until'] ?: null,
                'status' => 'finalized',
                'is_current' => true,
                'round' => $request->round,
            ]);
            $status = GovernanceDecisionRules::statusFor($decision);
            $from = $request->status;
            $request->update([
                'status' => $status,
                'final_decision' => $decision,
                'final_decision_reason' => $data['decision_reason'] ?? $data['decision_conditions'] ?? null,
                'decided_by' => $actor->id,
                'decided_at' => now(),
                'updated_by' => $actor->id,
            ]);
            self::applySideEffects($request, $record, $data, $actor);
            GovernanceLogger::status($request, $from, $status, $data['decision_reason'] ?? null, $actor);
            GovernanceLogger::log($request, 'decision_issued', $decision, [
                'decision_id' => $record->id,
                'decision' => $decision,
                'risk_record_unchanged' => $request->request_type === 'risk_acceptance',
            ], $request->assigned_committee_id, $actor);

            return ['ok' => true, 'message' => __('governance.Saved'), 'decision' => $record];
        });
    }

    public static function correct(User $actor, GovernanceDecision $decision, array $data): array
    {
        return DB::transaction(function () use ($actor, $decision, $data) {
            $decision = GovernanceDecision::where('id', $decision->id)->lockForUpdate()->first();
            if (!$decision || $decision->status !== 'finalized' || !$decision->is_current) {
                return self::fail(__('governance.DecisionImmutable'));
            }
            $request = GovernanceRequest::where('id', $decision->governance_request_id)->lockForUpdate()->first();
            $type = (string) ($data['decision_type'] ?? '');
            if ($error = GovernanceDecisionRules::validateContent($type, $data['decision_reason'] ?? null, $data['decision_conditions'] ?? null)) {
                return self::fail(__('governance.errors.' . $error));
            }
            if (trim((string) ($data['decision_reason'] ?? '')) === '') {
                return self::fail(__('governance.ReasonRequired'));
            }
            if ($error = self::authority($actor, $request, $type)) {
                return self::fail($error, 403);
            }
            if ($request->request_type === 'risk_acceptance') {
                if ($error = GovernanceDecisionRules::riskOutcomeAllows($type, $data['risk_outcome'] ?? null)) {
                    return self::fail(__('governance.errors.' . $error));
                }
            }
            $decision->update(['status' => 'corrected', 'is_current' => false]);
            $record = GovernanceDecision::create([
                'governance_request_id' => $request->id,
                'committee_id' => $request->assigned_committee_id,
                'decision_type' => $type,
                'decision_number' => self::number($request),
                'decision_reason' => $data['decision_reason'],
                'decision_conditions' => $data['decision_conditions'] ?? null,
                'decided_by' => $actor->id,
                'decided_at' => now(),
                'effective_from' => $data['effective_from'] ?: null,
                'effective_until' => $data['effective_until'] ?: null,
                'status' => 'finalized',
                'is_current' => true,
                'corrects_decision_id' => $decision->id,
                'round' => $request->round,
            ]);
            $status = GovernanceDecisionRules::statusFor($type);
            $from = $request->status;
            $request->update([
                'status' => $status,
                'final_decision' => $type,
                'final_decision_reason' => $data['decision_reason'],
                'decided_by' => $actor->id,
                'decided_at' => now(),
                'updated_by' => $actor->id,
            ]);
            self::applySideEffects($request, $record, $data, $actor);
            GovernanceLogger::status($request, $from, $status, $data['decision_reason'], $actor);
            GovernanceLogger::log($request, 'decision_corrected', $data['decision_reason'], [
                'from' => $decision->id,
                'decision_id' => $record->id,
                'decision' => $type,
            ], $request->assigned_committee_id, $actor);

            return ['ok' => true, 'message' => __('governance.Saved'), 'decision' => $record];
        });
    }

    protected static function authority(User $actor, GovernanceRequest $request, string $decision): ?string
    {
        $approve = in_array($decision, ['approved', 'conditionally_approved'], true);
        $reject = $decision === 'rejected';
        $allowed = false;
        if ($approve && GovernanceAccess::permits($actor, 'approve_governance_request')) {
            $allowed = true;
        }
        if ($reject && GovernanceAccess::permits($actor, 'reject_governance_request')) {
            $allowed = true;
        }
        if (GovernanceAccess::permits($actor, 'issue_governance_decision')) {
            $allowed = true;
        }
        if (!$allowed || !GovernanceAccess::assignedToRequest($actor, $request)) {
            return __('locale.YouDonotHavePermissionToDoThat');
        }
        $member = GovernanceAccess::membership($actor, $request->assigned_committee_id);
        if (!$member || !CommitteeMemberPolicy::allows($member->policyArray(), 'approve')) {
            return __('governance.DecisionNotAllowed');
        }

        return null;
    }

    protected static function applySideEffects(GovernanceRequest $request, GovernanceDecision $decision, array $data, User $actor): void
    {
        if ($request->request_type === 'approval' && $request->approvalDetail && $request->approvalDetail->document_id) {
            $document = Document::find($request->approvalDetail->document_id);
            $request->approvalDetail->update(['document_version_ref' => GovernanceRiskReader::documentRef($document)]);
        }
        if ($request->request_type === 'exception' && $request->exceptionDetail && in_array($decision->decision_type, ['approved', 'conditionally_approved'], true)) {
            $request->exceptionDetail->update([
                'approval_date' => now()->toDateString(),
                'expiration_date' => $data['effective_until'] ?: $request->exceptionDetail->requested_expiration,
                'approved_conditions' => $data['decision_conditions'] ?? null,
                'approving_committee_id' => $request->assigned_committee_id,
                'final_approver_id' => $actor->id,
            ]);
        }
        if ($request->request_type === 'risk_acceptance' && $request->riskAcceptanceDetail) {
            $request->riskAcceptanceDetail->update(['decision_outcome' => $data['risk_outcome'] ?? null]);
        }
    }

    protected static function number(GovernanceRequest $request): string
    {
        $count = GovernanceDecision::where('governance_request_id', $request->id)->count() + 1;

        return $request->request_number . '-D' . $count;
    }

    protected static function fail(string $message, int $code = 422): array
    {
        return ['ok' => false, 'message' => $message, 'code' => $code];
    }
}
