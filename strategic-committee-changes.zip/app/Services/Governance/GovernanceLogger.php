<?php

namespace App\Services\Governance;

use App\Events\GovernanceActionOccurred;
use App\Models\GovernanceActivityLog;
use App\Models\GovernanceCommittee;
use App\Models\GovernanceRequest;
use App\Models\GovernanceStatusHistory;
use App\Models\User;
use Illuminate\Support\Facades\Cache;

class GovernanceLogger
{
    public static function log(?GovernanceRequest $request, string $action, ?string $description = null, array $meta = [], $committeeId = null, ?User $actor = null): void
    {
        GovernanceActivityLog::create([
            'governance_request_id' => $request ? $request->id : null,
            'committee_id' => $committeeId ?: ($request ? $request->assigned_committee_id : null),
            'actor_id' => $actor ? $actor->id : (auth()->id() ?: null),
            'action' => $action,
            'description' => $description,
            'meta' => $meta ?: null,
        ]);
        Cache::forever('governance.version', (int) Cache::get('governance.version', 1) + 1);

        $subject = $request;
        if (!$subject && $committeeId) {
            $subject = GovernanceCommittee::find($committeeId);
        }
        if ($subject) {
            event(new GovernanceActionOccurred($subject, $action, array_merge($meta, [
                'description' => (string) $description,
                'committee_id' => $committeeId,
                'actor_name' => $actor ? $actor->name : (optional(auth()->user())->name ?: ''),
            ])));
        }
    }

    public static function status(GovernanceRequest $request, ?string $from, string $to, ?string $comment = null, ?User $actor = null): void
    {
        GovernanceStatusHistory::create([
            'governance_request_id' => $request->id,
            'from_status' => $from,
            'to_status' => $to,
            'actor_id' => $actor ? $actor->id : (auth()->id() ?: null),
            'comment' => $comment,
        ]);
    }

    public static function cacheKey(string $suffix): string
    {
        return 'governance.' . (int) Cache::get('governance.version', 1) . '.' . $suffix;
    }
}
