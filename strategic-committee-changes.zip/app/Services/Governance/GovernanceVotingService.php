<?php

namespace App\Services\Governance;

use App\Models\GovernanceCommitteeMember;
use App\Models\GovernanceRequest;
use App\Models\GovernanceVote;
use App\Models\GovernanceVoteHistory;
use App\Models\GovernanceVotingSession;
use App\Models\User;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

class GovernanceVotingService
{
    public static function open(User $actor, GovernanceRequest $request, $deadline = null): array
    {
        if (!$request->committee || $request->committee->approval_mode === 'chairman') {
            return ['ok' => true, 'message' => __('governance.ChairmanMode'), 'session' => null];
        }
        $existing = GovernanceVotingSession::where('governance_request_id', $request->id)->where('round', $request->round)->first();
        if ($existing) {
            return ['ok' => true, 'message' => __('governance.Saved'), 'session' => $existing];
        }
        $eligible = self::eligibleMembers($request);
        $session = GovernanceVotingSession::create([
            'governance_request_id' => $request->id,
            'committee_id' => $request->assigned_committee_id,
            'round' => $request->round,
            'status' => 'open',
            'opened_by' => $actor->id,
            'opened_at' => now(),
            'deadline' => $deadline,
            'result' => 'pending',
            'eligible_count' => $eligible->count(),
        ]);
        GovernanceLogger::log($request, 'voting_opened', $request->request_number, ['session_id' => $session->id], $request->assigned_committee_id, $actor);

        return ['ok' => true, 'message' => __('governance.Saved'), 'session' => $session];
    }

    public static function cast(User $actor, GovernanceRequest $request, array $data): array
    {
        $session = GovernanceVotingSession::where('governance_request_id', $request->id)->where('round', $request->round)->where('status', 'open')->first();
        if (!$session) {
            return self::fail(__('governance.VotingClosed'));
        }
        if (!in_array($data['vote'], ['approve', 'reject', 'abstain'], true)) {
            return self::fail(__('governance.InvalidVote'));
        }
        $member = GovernanceAccess::membership($actor, $request->assigned_committee_id);
        if (!$member || !CommitteeMemberPolicy::allows($member->policyArray(), 'vote')) {
            return self::fail(__('governance.VoteNotAllowed'), 403);
        }
        if (!GovernanceAccess::permits($actor, 'vote_on_governance_request') && !GovernanceAccess::isAdmin($actor)) {
            return self::fail(__('locale.YouDonotHavePermissionToDoThat'), 403);
        }

        try {
            DB::transaction(function () use ($actor, $request, $session, $member, $data) {
                $vote = GovernanceVote::where('voting_session_id', $session->id)->where('committee_member_id', $member->id)->lockForUpdate()->first();
                $weight = $request->committee && $request->committee->approval_mode === 'weighted' ? (float) $member->voting_weight : 1;
                if ($weight <= 0) {
                    $weight = 1;
                }
                if ($vote) {
                    if (!$request->committee || !$request->committee->allow_vote_change) {
                        throw new \RuntimeException('duplicate');
                    }
                    GovernanceVoteHistory::create([
                        'governance_vote_id' => $vote->id,
                        'previous_vote' => $vote->vote,
                        'previous_comments' => $vote->comments,
                        'previous_weight' => $vote->voting_weight,
                        'changed_by' => $actor->id,
                    ]);
                    $vote->update([
                        'vote' => $data['vote'],
                        'comments' => $data['comments'] ?? null,
                        'voting_weight' => $weight,
                        'voted_at' => now(),
                    ]);
                } else {
                    GovernanceVote::create([
                        'voting_session_id' => $session->id,
                        'governance_request_id' => $request->id,
                        'committee_id' => $request->assigned_committee_id,
                        'committee_member_id' => $member->id,
                        'voter_id' => $actor->id,
                        'vote' => $data['vote'],
                        'comments' => $data['comments'] ?? null,
                        'voting_weight' => $weight,
                        'voted_at' => now(),
                    ]);
                }
                GovernanceLogger::log($request, 'vote_cast', $data['vote'], ['session_id' => $session->id], $request->assigned_committee_id, $actor);
            });
        } catch (QueryException $exception) {
            return self::fail(__('governance.DuplicateVote'));
        } catch (\RuntimeException $exception) {
            return self::fail(__('governance.DuplicateVote'));
        }

        return ['ok' => true, 'message' => __('governance.Saved')];
    }

    public static function close(User $actor, GovernanceRequest $request): array
    {
        $session = GovernanceVotingSession::with('votes')->where('governance_request_id', $request->id)->where('round', $request->round)->first();
        if (!$session || $session->status !== 'open') {
            return self::fail(__('governance.VotingClosed'));
        }
        $canClose = GovernanceAccess::permits($actor, 'manage_committee_voting') || GovernanceAccess::permits($actor, 'finalize_committee_recommendation');
        if (!$canClose || !GovernanceAccess::assignedToRequest($actor, $request)) {
            return self::fail(__('locale.YouDonotHavePermissionToDoThat'), 403);
        }
        $tally = self::tally($request, $session);
        $session->update([
            'status' => 'closed',
            'closed_at' => now(),
            'result' => $tally['passed'] ? 'passed' : ($tally['failed'] ? 'failed' : 'pending'),
            'tally' => $tally,
        ]);
        GovernanceLogger::log($request, 'voting_closed', $session->result, $tally + ['status' => $session->result], $request->assigned_committee_id, $actor);

        return ['ok' => true, 'message' => __('governance.Saved'), 'tally' => $tally];
    }

    public static function tally(GovernanceRequest $request, GovernanceVotingSession $session): array
    {
        $committee = $request->committee;
        $votes = $session->votes->map(function (GovernanceVote $vote) {
            return ['vote' => $vote->vote, 'weight' => $vote->voting_weight];
        })->all();

        return GovernanceVotingRules::evaluate($votes, [
            'approval_mode' => $committee ? $committee->approval_mode : 'chairman',
            'eligible_count' => $session->eligible_count,
            'voting_threshold' => $committee ? $committee->voting_threshold : 50,
            'minimum_approval_count' => $committee ? $committee->minimum_approval_count : 1,
            'quorum_count' => $committee ? $committee->quorum_count : 0,
        ]);
    }

    public static function currentTally(GovernanceRequest $request): array
    {
        $session = GovernanceVotingSession::with('votes')->where('governance_request_id', $request->id)->where('round', $request->round)->first();
        if (!$session) {
            $mode = optional($request->committee)->approval_mode ?: 'chairman';

            return ['closed' => $mode === 'chairman', 'passed' => $mode === 'chairman', 'failed' => false, 'mode' => $mode];
        }
        $tally = $session->status === 'closed' && is_array($session->tally) ? $session->tally : self::tally($request, $session);
        $tally['closed'] = $session->status === 'closed';

        return $tally;
    }

    protected static function eligibleMembers(GovernanceRequest $request)
    {
        return GovernanceCommitteeMember::where('committee_id', $request->assigned_committee_id)->where('status', 'active')->get()
            ->filter(function (GovernanceCommitteeMember $member) {
                return CommitteeMemberPolicy::allows($member->policyArray(), 'vote');
            })->values();
    }

    protected static function fail(string $message, int $code = 422): array
    {
        return ['ok' => false, 'message' => $message, 'code' => $code];
    }
}
