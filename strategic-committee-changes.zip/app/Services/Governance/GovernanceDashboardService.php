<?php

namespace App\Services\Governance;

use App\Models\GovernanceCommittee;
use App\Models\GovernanceCommitteeMember;
use App\Models\GovernanceDecision;
use App\Models\GovernanceExceptionDetail;
use App\Models\GovernanceRequest;
use App\Models\User;
use Illuminate\Support\Facades\Cache;

class GovernanceDashboardService
{
    public static function stats(User $user, array $filters): array
    {
        $key = GovernanceLogger::cacheKey('dashboard.' . $user->id . '.' . md5(json_encode($filters)));

        return Cache::remember($key, 60, function () use ($user, $filters) {
            $requests = self::requests($user, $filters);
            $committees = GovernanceAccess::scopeCommittees(GovernanceCommittee::query(), $user);
            if (!empty($filters['committee_id'])) {
                $committees->where('id', $filters['committee_id']);
            }
            $committeeIds = (clone $committees)->pluck('id');
            $members = GovernanceCommitteeMember::whereIn('committee_id', $committeeIds)->where('status', 'active');
            $cards = [
                'committees' => (clone $committees)->count(),
                'active_committees' => (clone $committees)->where('status', 'active')->count(),
                'members' => (clone $members)->count(),
                'pending' => (clone $requests)->whereIn('status', ['submitted', 'assigned'])->count(),
                'under_review' => (clone $requests)->whereIn('status', ['under_review', 'committee_discussion'])->count(),
                'pending_decisions' => (clone $requests)->where('status', 'decision_pending')->count(),
                'approved' => (clone $requests)->whereIn('status', ['approved', 'conditional_approval'])->count(),
                'rejected' => (clone $requests)->where('status', 'rejected')->count(),
                'expired_exceptions' => (clone $requests)->where('request_type', 'exception')->where('status', 'expired')->count(),
                'pending_risk' => (clone $requests)->where('request_type', 'risk_acceptance')->whereNotIn('status', ['approved', 'rejected', 'closed', 'cancelled', 'expired'])->count(),
            ];
            $byType = (clone $requests)->selectRaw('request_type, COUNT(*) as total')->groupBy('request_type')->pluck('total', 'request_type');
            $byStatus = (clone $requests)->selectRaw('status, COUNT(*) as total')->groupBy('status')->pluck('total', 'status');
            $byDepartment = (clone $requests)->selectRaw('department_id, COUNT(*) as total')->groupBy('department_id')->pluck('total', 'department_id');
            $workload = (clone $requests)->whereNotNull('assigned_committee_id')->selectRaw('assigned_committee_id, COUNT(*) as total')->groupBy('assigned_committee_id')->pluck('total', 'assigned_committee_id');
            $decisions = GovernanceDecision::whereIn('governance_request_id', (clone $requests)->select('id'))->selectRaw('decision_type, COUNT(*) as total')->groupBy('decision_type')->pluck('total', 'decision_type');
            $monthly = array_fill(1, 12, 0);
            (clone $requests)->whereNotNull('decided_at')->whereYear('decided_at', $filters['year'] ?? date('Y'))
                ->selectRaw('MONTH(decided_at) as month, COUNT(*) as total')->groupBy('month')->get()
                ->each(function ($row) use (&$monthly) {
                    $monthly[(int) $row->month] = (int) $row->total;
                });
            $expirations = array_fill(1, 12, 0);
            GovernanceExceptionDetail::whereIn('governance_request_id', (clone $requests)->where('request_type', 'exception')->select('governance_requests.id'))
                ->whereNotNull('expiration_date')
                ->whereYear('expiration_date', $filters['year'] ?? date('Y'))
                ->selectRaw('MONTH(expiration_date) as month, COUNT(*) as total')->groupBy('month')->get()
                ->each(function ($row) use (&$expirations) {
                    $expirations[(int) $row->month] = (int) $row->total;
                });
            $riskOutcomes = \App\Models\GovernanceRiskAcceptanceDetail::whereIn('governance_request_id', (clone $requests)->where('request_type', 'risk_acceptance')->select('governance_requests.id'))
                ->selectRaw('decision_outcome, COUNT(*) as total')->groupBy('decision_outcome')->pluck('total', 'decision_outcome');
            $hours = (clone $requests)->whereNotNull('decided_at')->whereNotNull('submission_date')->get(['submission_date', 'decided_at']);
            $average = $hours->count() ? round($hours->avg(function (GovernanceRequest $row) {
                return $row->submission_date->diffInHours($row->decided_at);
            }), 1) : 0;

            return [
                'cards' => $cards,
                'charts' => [
                    'types' => $byType,
                    'statuses' => $byStatus,
                    'decisions' => $decisions,
                    'workload' => $workload,
                    'departments' => $byDepartment,
                    'monthly' => array_values($monthly),
                    'expirations' => array_values($expirations),
                    'risks' => $riskOutcomes,
                    'average_hours' => $average,
                ],
            ];
        });
    }

    public static function requests(User $user, array $filters)
    {
        $query = GovernanceAccess::scopeRequests(GovernanceRequest::query(), $user);
        foreach (['assigned_committee_id' => 'committee_id', 'department_id' => 'department_id', 'request_type' => 'request_type', 'status' => 'status', 'priority' => 'priority', 'requester_id' => 'owner_id'] as $column => $filter) {
            if (!empty($filters[$filter])) {
                $query->where($column, $filters[$filter]);
            }
        }
        if (!empty($filters['date_from'])) {
            $query->whereDate('submission_date', '>=', $filters['date_from']);
        }
        if (!empty($filters['date_to'])) {
            $query->whereDate('submission_date', '<=', $filters['date_to']);
        }
        if (!empty($filters['decision_from'])) {
            $query->whereDate('decided_at', '>=', $filters['decision_from']);
        }
        if (!empty($filters['decision_to'])) {
            $query->whereDate('decided_at', '<=', $filters['decision_to']);
        }

        return $query;
    }
}
