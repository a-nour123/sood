<?php

namespace App\Services\Governance;

use App\Models\Document;
use App\Models\Risk;
use Illuminate\Support\Facades\DB;

class GovernanceRiskReader
{
    public static function snapshot(Risk $risk): array
    {
        $risk->loadMissing(['owner:id,name', 'riskScoring', 'latestTreatmentRequest', 'responsibleDepartment', 'mitigation']);
        $residual = null;
        if (DB::getSchemaBuilder()->hasTable('residual_risk_scoring_histories')) {
            $residual = DB::table('residual_risk_scoring_histories')->where('risk_id', $risk->id)->orderByDesc('id')->value('residual_risk');
        }
        $level = null;
        $score = $risk->riskScoring ? $risk->riskScoring->calculated_risk : null;
        try {
            if (class_exists(\App\Services\KsuRiskMethodologyService::class)) {
                $service = app(\App\Services\KsuRiskMethodologyService::class);
                $impact = (int) ($risk->residual_impact ?: $risk->inherent_impact ?: 0);
                $likelihood = (int) ($risk->residual_likelihood ?: $risk->inherent_likelihood ?: 0);
                if ($impact && $likelihood) {
                    $level = $service->levelFromMatrix($impact, $likelihood);
                    $score = $score ?: $service->inherentScore($impact, $likelihood);
                }
            }
        } catch (\Throwable $exception) {
            $level = null;
        }

        return [
            'id' => $risk->id,
            'code' => $risk->reference_id,
            'title' => $risk->subject,
            'description' => $risk->assessment,
            'status' => $risk->status,
            'owner_id' => $risk->owner_id,
            'owner' => optional($risk->owner)->name,
            'department_id' => $risk->responsible_department_id,
            'department' => optional($risk->responsibleDepartment)->name,
            'inherent_risk' => $score,
            'residual_risk' => $residual,
            'inherent_impact' => $risk->inherent_impact,
            'inherent_likelihood' => $risk->inherent_likelihood,
            'residual_impact' => $risk->residual_impact,
            'residual_likelihood' => $risk->residual_likelihood,
            'level' => $level,
            'mitigation_id' => $risk->mitigation_id,
            'treatment' => optional($risk->mitigation)->name,
            'treatment_status' => optional($risk->latestTreatmentRequest)->status,
            'captured_at' => date('Y-m-d H:i:s'),
        ];
    }

    public static function documentRef(?Document $document): ?string
    {
        if (!$document) {
            return null;
        }

        return json_encode([
            'document_id' => $document->id,
            'document_name' => $document->document_name,
            'document_status' => $document->document_status,
            'approval_date' => $document->approval_date,
            'file_id' => $document->file_id,
            'last_review_date' => $document->last_review_date,
            'captured_at' => date('Y-m-d H:i:s'),
        ]);
    }
}
