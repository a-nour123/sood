<?php

namespace App\Services\Governance;

class GovernanceVotingRules
{
    public static function evaluate(array $votes, array $settings): array
    {
        $eligible = max(0, (int) ($settings['eligible_count'] ?? 0));
        $mode = (string) ($settings['approval_mode'] ?? 'chairman');
        $threshold = (float) ($settings['voting_threshold'] ?? 50);
        if ($threshold <= 0 || $threshold > 100) {
            $threshold = 50;
        }
        $minimum = max(1, (int) ($settings['minimum_approval_count'] ?? 1));
        $quorum = (int) ($settings['quorum_count'] ?? 0);
        if ($quorum < 1) {
            $quorum = (int) ceil($eligible * ($threshold / 100));
        }
        if ($quorum < 1) {
            $quorum = 1;
        }

        $approve = 0;
        $reject = 0;
        $abstain = 0;
        $approveWeight = 0.0;
        $rejectWeight = 0.0;
        $abstainWeight = 0.0;
        foreach ($votes as $vote) {
            $weight = (float) ($vote['weight'] ?? 1);
            if ($weight <= 0) {
                $weight = 1;
            }
            $choice = (string) ($vote['vote'] ?? 'abstain');
            if ($choice === 'approve') {
                $approve++;
                $approveWeight += $weight;
            } elseif ($choice === 'reject') {
                $reject++;
                $rejectWeight += $weight;
            } else {
                $abstain++;
                $abstainWeight += $weight;
            }
        }
        $cast = $approve + $reject + $abstain;
        $decisive = $approveWeight + $rejectWeight;
        $ratio = $decisive > 0 ? ($approveWeight / $decisive) * 100 : 0;
        $quorumMet = $cast >= $quorum;
        $passed = false;
        $failed = false;
        $reason = 'pending';

        if ($mode === 'chairman') {
            $quorumMet = true;
            $passed = true;
            $reason = 'chairman';
        } elseif (!$quorumMet) {
            $reason = 'no_quorum';
            $remaining = max(0, $eligible - $cast);
            $failed = ($cast + $remaining) < $quorum;
        } elseif ($mode === 'unanimous') {
            $passed = $eligible > 0 && $approve === $eligible && $reject === 0 && $abstain === 0;
            $failed = !$passed && ($reject > 0 || $abstain > 0 || $cast >= $eligible);
            $reason = $passed ? 'unanimous' : ($failed ? 'not_unanimous' : 'pending');
        } elseif ($mode === 'minimum') {
            $remaining = max(0, $eligible - $cast);
            $passed = $quorumMet && $approve >= $minimum;
            $failed = ($approve + $remaining) < $minimum;
            $reason = $passed ? 'minimum_met' : ($failed ? 'minimum_impossible' : 'pending');
        } else {
            $passed = $quorumMet && $decisive > 0 && $approveWeight > $rejectWeight && $ratio >= $threshold;
            $remainingWeight = 0;
            $failed = $cast >= $eligible && !$passed;
            if (!$failed && $cast < $eligible && $decisive > 0) {
                $failed = false;
            }
            $reason = $passed ? 'threshold_met' : ($failed ? 'threshold_failed' : 'pending');
            unset($remainingWeight);
        }

        return [
            'mode' => $mode,
            'eligible' => $eligible,
            'cast' => $cast,
            'approve' => $approve,
            'reject' => $reject,
            'abstain' => $abstain,
            'approve_weight' => $approveWeight,
            'reject_weight' => $rejectWeight,
            'abstain_weight' => $abstainWeight,
            'quorum' => $quorum,
            'quorum_met' => $quorumMet,
            'ratio' => round($ratio, 2),
            'passed' => $passed,
            'failed' => $failed,
            'pending' => !$passed && !$failed,
            'reason' => $reason,
            'closed' => $passed || $failed || $mode === 'chairman',
        ];
    }
}
