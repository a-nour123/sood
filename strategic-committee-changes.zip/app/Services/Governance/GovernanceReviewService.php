<?php

namespace App\Services\Governance;

use App\Models\GovernanceRequest;
use App\Models\GovernanceReview;
use App\Models\GovernanceReviewComment;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class GovernanceReviewService
{
    public static function statuses(): array
    {
        return ['pending', 'in_progress', 'reviewed', 'additional_information', 'conflict', 'abstained'];
    }

    public static function recommendations(): array
    {
        return ['approve', 'reject', 'conditional', 'further_assessment', 'escalation'];
    }

    public static function submit(User $actor, GovernanceRequest $request, array $data): array
    {
        if (!in_array($request->status, ['under_review', 'committee_discussion', 'reopened'], true)) {
            return self::fail(__('governance.ReviewClosed'));
        }
        $member = GovernanceAccess::membership($actor, $request->assigned_committee_id);
        if (!GovernanceAccess::allows($actor, 'review_governance_request', GovernanceAccess::assignedToRequest($actor, $request))) {
            return self::fail(__('locale.YouDonotHavePermissionToDoThat'), 403);
        }
        if (!$member || !CommitteeMemberPolicy::allows($member->policyArray(), 'review')) {
            return self::fail(__('governance.ReviewNotAllowed'), 403);
        }
        if (!in_array($data['review_status'], self::statuses(), true) || $data['review_status'] === 'pending') {
            return self::fail(__('governance.InvalidReview'));
        }
        if (!empty($data['recommendation']) && !in_array($data['recommendation'], self::recommendations(), true)) {
            return self::fail(__('governance.InvalidRecommendation'));
        }
        if (!empty($data['recommendation']) && !CommitteeMemberPolicy::allows($member->policyArray(), 'recommend')) {
            return self::fail(__('governance.RecommendationNotAllowed'), 403);
        }
        $review = GovernanceReview::where('governance_request_id', $request->id)
            ->where('committee_member_id', $member->id)
            ->where('round', $request->round)
            ->first();
        if ($review && !in_array($review->review_status, ['pending', 'in_progress'], true)) {
            return self::fail(__('governance.ReviewAlreadySubmitted'));
        }

        DB::transaction(function () use ($actor, $request, $member, $data, $review) {
            $payload = [
                'committee_id' => $request->assigned_committee_id,
                'reviewer_id' => $actor->id,
                'review_status' => $data['review_status'],
                'recommendation' => $data['recommendation'] ?: null,
                'comments' => $data['comments'] ?? null,
                'reviewed_at' => now(),
            ];
            if ($review) {
                $review->update($payload);
            } else {
                $review = GovernanceReview::create($payload + [
                    'governance_request_id' => $request->id,
                    'committee_member_id' => $member->id,
                    'round' => $request->round,
                ]);
            }
            if (!empty($data['comments'])) {
                GovernanceReviewComment::create([
                    'governance_review_id' => $review->id,
                    'user_id' => $actor->id,
                    'body' => $data['comments'],
                ]);
            }
            GovernanceLogger::log($request, 'review_submitted', $data['review_status'], ['review_id' => $review->id], $request->assigned_committee_id, $actor);
        });

        return ['ok' => true, 'message' => __('governance.Saved')];
    }

    public static function comment(User $actor, GovernanceReview $review, string $body): array
    {
        if (!GovernanceAccess::allows($actor, 'view_committee_reviews', GovernanceAccess::assignedToRequest($actor, $review->request))) {
            return self::fail(__('governance.Forbidden'), 403);
        }
        GovernanceReviewComment::create([
            'governance_review_id' => $review->id,
            'user_id' => $actor->id,
            'body' => $body,
        ]);
        GovernanceLogger::log($review->request, 'review_comment', $body, ['review_id' => $review->id], $review->committee_id, $actor);

        return ['ok' => true, 'message' => __('governance.Saved')];
    }

    protected static function fail(string $message, int $code = 422): array
    {
        return ['ok' => false, 'message' => $message, 'code' => $code];
    }
}
