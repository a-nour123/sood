<?php

namespace App\Services\Governance;

use App\Models\Document;
use App\Models\GovernanceAssignmentRule;
use App\Models\GovernanceCommittee;
use App\Models\GovernanceCommitteeMember;
use App\Models\GovernanceDecision;
use App\Models\GovernanceExceptionDetail;
use App\Models\GovernanceRequest;
use App\Models\GovernanceRequestAssignment;
use App\Models\GovernanceReview;
use App\Models\Risk;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class GovernanceRequestService
{
    public static function create(User $actor, string $type, array $data): array
    {
        if (!empty($data['idempotency_key'])) {
            $existing = GovernanceRequest::where('idempotency_key', $data['idempotency_key'])->first();
            if ($existing) {
                return ['ok' => true, 'message' => __('governance.Saved'), 'request' => $existing];
            }
        }
        if ($error = self::departmentAllowed($actor, $data['department_id'] ?? null)) {
            return self::fail($error);
        }
        if ($error = self::validateDetail($type, $data)) {
            return self::fail($error);
        }
        if (!empty($data['assigned_committee_id']) && !self::committeeAuthorized((int) $data['assigned_committee_id'], $type)) {
            return self::fail(__('governance.CommitteeNotAuthorized'));
        }

        $request = DB::transaction(function () use ($actor, $type, $data) {
            $request = GovernanceRequest::create([
                'request_number' => self::nextNumber(),
                'idempotency_key' => $data['idempotency_key'] ?: null,
                'request_type' => $type,
                'category_id' => $data['category_id'] ?: null,
                'title' => $data['title'],
                'description' => $data['description'] ?? null,
                'requester_id' => $actor->id,
                'department_id' => $data['department_id'] ?: $actor->department_id,
                'assigned_committee_id' => $data['assigned_committee_id'] ?: null,
                'priority' => $data['priority'] ?? 'medium',
                'status' => 'draft',
                'due_date' => $data['due_date'] ?: null,
                'created_by' => $actor->id,
                'updated_by' => $actor->id,
            ]);
            self::writeDetail($request, $type, $data);
            if ($request->assigned_committee_id) {
                self::recordAssignment($request, null, (int) $request->assigned_committee_id, 'initial', $actor);
            }
            GovernanceLogger::log($request, 'created', $request->title, [], $request->assigned_committee_id, $actor);
            GovernanceLogger::status($request, null, 'draft', null, $actor);

            return $request;
        });

        return ['ok' => true, 'message' => __('governance.Saved'), 'request' => $request];
    }

    public static function update(User $actor, GovernanceRequest $request, array $data): array
    {
        if (!GovernanceWorkflow::editable($request->status)) {
            return self::fail(__('governance.RequestLocked'));
        }
        if (!GovernanceAccess::canViewRequest($actor, $request)) {
            return self::fail(__('governance.Forbidden'), 403);
        }
        if ($error = self::validateDetail($request->request_type, $data, $request)) {
            return self::fail($error);
        }
        if (!empty($data['assigned_committee_id']) && !self::committeeAuthorized((int) $data['assigned_committee_id'], $request->request_type)) {
            return self::fail(__('governance.CommitteeNotAuthorized'));
        }
        DB::transaction(function () use ($actor, $request, $data) {
            $from = $request->assigned_committee_id;
            $request->update([
                'category_id' => $data['category_id'] ?: null,
                'title' => $data['title'],
                'description' => $data['description'] ?? null,
                'department_id' => $data['department_id'] ?: $request->department_id,
                'assigned_committee_id' => array_key_exists('assigned_committee_id', $data) ? ($data['assigned_committee_id'] ?: null) : $request->assigned_committee_id,
                'priority' => $data['priority'] ?? $request->priority,
                'due_date' => $data['due_date'] ?: null,
                'updated_by' => $actor->id,
            ]);
            self::writeDetail($request, $request->request_type, $data);
            if ((int) $from !== (int) $request->assigned_committee_id && $request->assigned_committee_id) {
                self::recordAssignment($request, $from, (int) $request->assigned_committee_id, 'updated', $actor);
            }
            GovernanceLogger::log($request, 'updated', $request->title, [], $request->assigned_committee_id, $actor);
        });

        return ['ok' => true, 'message' => __('governance.Saved'), 'request' => $request->fresh()];
    }

    public static function delete(User $actor, GovernanceRequest $request): array
    {
        if ($request->status !== 'draft' || $request->decisions()->exists()) {
            return self::fail(__('governance.DeleteOnlyDraft'));
        }
        DB::transaction(function () use ($actor, $request) {
            GovernanceLogger::log($request, 'deleted', $request->title, [], $request->assigned_committee_id, $actor);
            $request->delete();
        });

        return ['ok' => true, 'message' => __('governance.Deleted')];
    }

    public static function act(User $actor, GovernanceRequest $request, string $action, ?string $comment = null, array $extra = []): array
    {
        return DB::transaction(function () use ($actor, $request, $action, $comment, $extra) {
            $request = GovernanceRequest::where('id', $request->id)->lockForUpdate()->first();
            return self::actLocked($actor, $request, $action, $comment, $extra);
        });
    }

    protected static function actLocked(User $actor, GovernanceRequest $request, string $action, ?string $comment = null, array $extra = []): array
    {
        $transition = GovernanceWorkflow::describe($request->status, $action);
        if (!$transition) {
            return self::fail(__('governance.InvalidTransition'));
        }
        if (!empty($transition['comment']) && trim((string) $comment) === '') {
            return self::fail(__('governance.ReasonRequired'));
        }
        if (!GovernanceAccess::allows($actor, $transition['permission'], GovernanceAccess::assignedToRequest($actor, $request))) {
            return self::fail(__('locale.YouDonotHavePermissionToDoThat'), 403);
        }
        if (!GovernanceAccess::canViewRequest($actor, $request)) {
            return self::fail(__('governance.Forbidden'), 403);
        }
        if (in_array($action, ['assign', 'reassign'], true)) {
            $committeeId = (int) ($extra['committee_id'] ?? 0);
            if (!self::committeeAuthorized($committeeId, $request->request_type)) {
                return self::fail(__('governance.CommitteeNotAuthorized'));
            }
        }
        if ($action === 'start_review' && !$request->assigned_committee_id) {
            return self::fail(__('governance.CommitteeRequired'));
        }

        $from = $request->status;
        $to = $transition['to'];
            if ($action === 'submit') {
                $request->submission_date = $request->submission_date ?: now()->toDateString();
                $assigned = self::autoAssign($request, $actor);
                if ($assigned) {
                    $to = 'assigned';
                }
            }
            if (in_array($action, ['assign', 'reassign'], true)) {
                $previous = $request->assigned_committee_id;
                $request->assigned_committee_id = (int) $extra['committee_id'];
                self::recordAssignment($request, $previous, (int) $extra['committee_id'], $comment, $actor);
            }
            if ($action === 'reopen') {
                GovernanceDecision::where('governance_request_id', $request->id)->where('is_current', true)
                    ->update(['is_current' => false, 'status' => 'superseded']);
                $request->round = (int) $request->round + 1;
                $request->final_decision = null;
                $request->final_decision_reason = null;
                $request->decided_by = null;
                $request->decided_at = null;
            }
            $request->status = $to;
            $request->updated_by = $actor->id;
            $request->save();
            GovernanceLogger::status($request, $from, $to, $comment, $actor);
            GovernanceLogger::log($request, $action, $comment, [], $request->assigned_committee_id, $actor);
            if ($to === 'under_review') {
                self::openReviews($request);
            }
            if ($action === 'open_decision') {
                GovernanceVotingService::open($actor, $request->fresh(), $extra['deadline'] ?? $request->due_date);
            }

        return ['ok' => true, 'message' => __('governance.Saved'), 'request' => $request->fresh()];
    }

    public static function expireDueExceptions(): void
    {
        GovernanceExceptionDetail::with('request')
            ->whereNotNull('expiration_date')
            ->whereDate('expiration_date', '<', now()->toDateString())
            ->whereNull('expired_notice_sent_at')
            ->orderBy('id')
            ->chunkById(100, function ($details) {
                foreach ($details as $detail) {
                    if ($detail->request) {
                        self::markExpired($detail->request);
                    }
                }
            });
    }

    public static function markExpired(GovernanceRequest $request): void
    {
        if (!in_array($request->status, ['approved', 'conditional_approval'], true)) {
            return;
        }
        $from = $request->status;
        $request->status = 'expired';
        $request->save();
        GovernanceLogger::status($request, $from, 'expired', 'expiration');
        GovernanceLogger::log($request, 'expired', $request->request_number);
        $detail = $request->exceptionDetail;
        if ($detail && !$detail->expired_notice_sent_at) {
            $detail->update(['expired_notice_sent_at' => now()]);
        }
    }

    public static function committeeAuthorized(int $committeeId, string $type): bool
    {
        $committee = GovernanceCommittee::with('requestTypes')->find($committeeId);

        return $committee && GovernanceCommitteeService::committeeHandles($committee, $type);
    }

    protected static function autoAssign(GovernanceRequest $request, User $actor): bool
    {
        if ($request->assigned_committee_id && self::committeeAuthorized((int) $request->assigned_committee_id, $request->request_type)) {
            self::recordAssignment($request, null, (int) $request->assigned_committee_id, 'submit', $actor);

            return true;
        }
        $rules = GovernanceAssignmentRule::with('committee.requestTypes')->where('is_active', true)->where('request_type', $request->request_type)->get();
        $payload = [];
        foreach ($rules as $rule) {
            $payload[] = [
                'committee_id' => $rule->committee_id,
                'request_type' => $rule->request_type,
                'category_id' => $rule->category_id,
                'department_id' => $rule->department_id,
                'priority' => $rule->priority,
                'is_active' => $rule->is_active,
                'committee_active' => $rule->committee && $rule->committee->isActiveOn(),
                'handles_type' => $rule->committee && $rule->committee->requestTypes->contains('request_type', $request->request_type),
            ];
        }
        $match = GovernanceAssignmentMatcher::pick($payload, $request->request_type, $request->category_id, $request->department_id);
        if (!$match) {
            return false;
        }
        $request->assigned_committee_id = $match['committee_id'];
        self::recordAssignment($request, null, (int) $match['committee_id'], 'rule', $actor);

        return true;
    }

    protected static function openReviews(GovernanceRequest $request): void
    {
        $members = GovernanceCommitteeMember::where('committee_id', $request->assigned_committee_id)->where('status', 'active')->get();
        foreach ($members as $member) {
            if (!CommitteeMemberPolicy::allows($member->policyArray(), 'review')) {
                continue;
            }
            GovernanceReview::firstOrCreate(
                [
                    'governance_request_id' => $request->id,
                    'committee_member_id' => $member->id,
                    'round' => $request->round,
                ],
                [
                    'committee_id' => $request->assigned_committee_id,
                    'reviewer_id' => $member->user_id,
                    'review_status' => 'pending',
                ]
            );
        }
    }

    protected static function recordAssignment(GovernanceRequest $request, $from, int $to, ?string $reason, User $actor): void
    {
        GovernanceRequestAssignment::create([
            'governance_request_id' => $request->id,
            'from_committee_id' => $from,
            'to_committee_id' => $to,
            'reason' => $reason,
            'assigned_by' => $actor->id,
            'assigned_at' => now(),
        ]);
    }

    protected static function writeDetail(GovernanceRequest $request, string $type, array $data): void
    {
        if ($type === 'approval') {
            $document = !empty($data['document_id']) ? Document::find($data['document_id']) : null;
            $request->approvalDetail()->updateOrCreate(
                ['governance_request_id' => $request->id],
                [
                    'business_justification' => $data['business_justification'] ?? null,
                    'requested_effective_date' => $data['requested_effective_date'] ?: null,
                    'document_id' => $document ? $document->id : null,
                    'document_version_ref' => GovernanceRiskReader::documentRef($document),
                ]
            );
        }
        if ($type === 'exception') {
            $request->exceptionDetail()->updateOrCreate(
                ['governance_request_id' => $request->id],
                [
                    'framework_id' => $data['framework_id'] ?: null,
                    'family_id' => $data['family_id'] ?: null,
                    'control_id' => $data['control_id'] ?: null,
                    'regulatory_requirement' => $data['regulatory_requirement'] ?? null,
                    'policy_document_id' => $data['policy_document_id'] ?: null,
                    'existing_exception_id' => $data['existing_exception_id'] ?: null,
                    'justification' => $data['justification'] ?? null,
                    'business_impact' => $data['business_impact'] ?? null,
                    'technical_justification' => $data['technical_justification'] ?? null,
                    'compensating_controls' => $data['compensating_controls'] ?? null,
                    'risk_assessment' => $data['risk_assessment'] ?? null,
                    'requested_start' => $data['requested_start'] ?: null,
                    'requested_expiration' => $data['requested_expiration'] ?: null,
                    'review_date' => $data['review_date'] ?: null,
                    'owner_id' => $data['owner_id'] ?: $request->requester_id,
                    'remediation_plan' => $data['remediation_plan'] ?? null,
                    'review_frequency' => $data['review_frequency'] ?? null,
                ]
            );
        }
        if ($type === 'risk_acceptance') {
            $risk = Risk::findOrFail($data['risk_id']);
            $request->riskAcceptanceDetail()->updateOrCreate(
                ['governance_request_id' => $request->id],
                [
                    'risk_id' => $risk->id,
                    'acceptance_justification' => $data['acceptance_justification'] ?? null,
                    'business_impact' => $data['business_impact'] ?? null,
                    'acceptance_period' => $data['acceptance_period'] ?? null,
                    'proposed_expiration' => $data['proposed_expiration'] ?: null,
                    'compensating_controls' => $data['compensating_controls'] ?? null,
                    'monitoring_plan' => $data['monitoring_plan'] ?? null,
                    'owner_recommendation' => $data['owner_recommendation'] ?? null,
                    'risk_snapshot' => GovernanceRiskReader::snapshot($risk),
                ]
            );
        }
    }

    protected static function validateDetail(string $type, array $data, ?GovernanceRequest $request = null): ?string
    {
        if ($type === 'exception' && empty($data['justification'])) {
            return __('governance.JustificationRequired');
        }
        if ($type === 'exception' && !empty($data['requested_start']) && !empty($data['requested_expiration']) && $data['requested_expiration'] < $data['requested_start']) {
            return __('governance.InvalidDates');
        }
        if ($type === 'risk_acceptance') {
            if (empty($data['risk_id']) || !Risk::where('id', $data['risk_id'])->exists()) {
                return __('governance.RiskRequired');
            }
            if (empty($data['acceptance_justification'])) {
                return __('governance.JustificationRequired');
            }
            if ($request && $request->riskAcceptanceDetail && (int) $request->riskAcceptanceDetail->risk_id !== (int) $data['risk_id'] && !GovernanceWorkflow::editable($request->status)) {
                return __('governance.RequestLocked');
            }
        }

        return null;
    }

    protected static function departmentAllowed(User $actor, $departmentId): ?string
    {
        if (GovernanceAccess::isModuleAdmin($actor)) {
            return null;
        }
        if (!$actor->department_id || (int) $actor->department_id !== (int) $departmentId) {
            return __('governance.DepartmentRestricted');
        }

        return null;
    }

    protected static function nextNumber(): string
    {
        $year = (int) date('Y');
        $row = DB::table('governance_sequences')->where('year', $year)->lockForUpdate()->first();
        if (!$row) {
            DB::table('governance_sequences')->insert([
                'year' => $year,
                'last_number' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            return sprintf('GR-%d-%05d', $year, 1);
        }
        $number = (int) $row->last_number + 1;
        DB::table('governance_sequences')->where('id', $row->id)->update([
            'last_number' => $number,
            'updated_at' => now(),
        ]);

        return sprintf('GR-%d-%05d', $year, $number);
    }

    protected static function fail(string $message, int $code = 422): array
    {
        return ['ok' => false, 'message' => $message, 'code' => $code];
    }
}
