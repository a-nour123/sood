<?php

namespace App\Services\Governance;

class CommitteeMemberPolicy
{
    public static function roles(): array
    {
        return [
            'chairman',
            'vice_chairman',
            'secretary',
            'voting_member',
            'technical_reviewer',
            'observer',
            'advisor',
        ];
    }

    public static function defaults(string $role): array
    {
        $map = [
            'chairman' => ['voting_right' => true, 'can_recommend' => true, 'can_approve' => true, 'can_review' => true, 'voting_weight' => 1],
            'vice_chairman' => ['voting_right' => true, 'can_recommend' => true, 'can_approve' => false, 'can_review' => true, 'voting_weight' => 1],
            'secretary' => ['voting_right' => false, 'can_recommend' => true, 'can_approve' => false, 'can_review' => true, 'voting_weight' => 0],
            'voting_member' => ['voting_right' => true, 'can_recommend' => true, 'can_approve' => false, 'can_review' => true, 'voting_weight' => 1],
            'technical_reviewer' => ['voting_right' => false, 'can_recommend' => true, 'can_approve' => false, 'can_review' => true, 'voting_weight' => 0],
            'observer' => ['voting_right' => false, 'can_recommend' => false, 'can_approve' => false, 'can_review' => false, 'voting_weight' => 0],
            'advisor' => ['voting_right' => false, 'can_recommend' => true, 'can_approve' => false, 'can_review' => true, 'voting_weight' => 0],
        ];

        return $map[$role] ?? $map['observer'];
    }

    public static function datesValid(?string $from, ?string $until): bool
    {
        if ($from && $until && $until < $from) {
            return false;
        }

        return true;
    }

    public static function isCurrent(array $member, ?string $on = null): bool
    {
        $on = $on ?: date('Y-m-d');
        if (($member['status'] ?? 'inactive') !== 'active') {
            return false;
        }
        if (!empty($member['effective_from']) && $member['effective_from'] > $on) {
            return false;
        }
        if (!empty($member['effective_until']) && $member['effective_until'] < $on) {
            return false;
        }

        return true;
    }

    public static function allows(array $member, string $ability, ?string $on = null): bool
    {
        if (!self::isCurrent($member, $on)) {
            return false;
        }
        $flags = [
            'review' => 'can_review',
            'recommend' => 'can_recommend',
            'approve' => 'can_approve',
            'vote' => 'voting_right',
        ];
        $flag = $flags[$ability] ?? null;

        return $flag ? !empty($member[$flag]) : false;
    }

    public static function overlaps(?string $fromA, ?string $untilA, ?string $fromB, ?string $untilB): bool
    {
        $startA = $fromA ?: '0000-01-01';
        $endA = $untilA ?: '9999-12-31';
        $startB = $fromB ?: '0000-01-01';
        $endB = $untilB ?: '9999-12-31';

        return $startA <= $endB && $startB <= $endA;
    }

    public static function duplicate(array $memberships, int $userId, ?string $from, ?string $until, $ignoreId = null): bool
    {
        foreach ($memberships as $row) {
            if ($ignoreId && (int) ($row['id'] ?? 0) === (int) $ignoreId) {
                continue;
            }
            if ((int) ($row['user_id'] ?? 0) !== $userId) {
                continue;
            }
            if (($row['status'] ?? '') !== 'active') {
                continue;
            }
            if (self::overlaps($row['effective_from'] ?? null, $row['effective_until'] ?? null, $from, $until)) {
                return true;
            }
        }

        return false;
    }
}
