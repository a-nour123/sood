<?php

namespace App\Services\Governance;

use App\Models\User;
use Illuminate\Support\Facades\Log;

class GovernanceNotifier
{
    public static function send(array $userIds, string $message, string $link = ''): void
    {
        $actorId = auth()->id();
        $ids = [];
        foreach ($userIds as $userId) {
            $userId = (int) $userId;
            if ($userId > 0 && $userId !== (int) $actorId) {
                $ids[$userId] = $userId;
            }
        }
        foreach ($ids as $userId) {
            try {
                if (class_exists(\Notific::class)) {
                    \Notific::notify($userId, $message, 'notification', $link);
                }
            } catch (\Throwable $exception) {
                Log::warning('Governance notification failed: ' . $exception->getMessage());
            }
        }
    }

    public static function permissionHolders(string $permission): array
    {
        return User::query()
            ->whereHas('role.rolePermissions', function ($query) use ($permission) {
                $query->where('key', $permission);
            })
            ->pluck('id')
            ->all();
    }
}
