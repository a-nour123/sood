<?php

namespace App\Services\Governance;

class GovernanceAssignmentMatcher
{
    public static function pick(array $rules, string $type, $categoryId, $departmentId): ?array
    {
        $best = null;
        $bestScore = -1;
        foreach ($rules as $rule) {
            if (empty($rule['is_active']) || ($rule['request_type'] ?? '') !== $type) {
                continue;
            }
            if (array_key_exists('committee_active', $rule) && empty($rule['committee_active'])) {
                continue;
            }
            if (array_key_exists('handles_type', $rule) && empty($rule['handles_type'])) {
                continue;
            }
            $score = 1;
            if (!empty($rule['category_id'])) {
                if ((int) $rule['category_id'] !== (int) $categoryId) {
                    continue;
                }
                $score += 2;
            }
            if (!empty($rule['department_id'])) {
                if ((int) $rule['department_id'] !== (int) $departmentId) {
                    continue;
                }
                $score += 4;
            }
            $priority = (int) ($rule['priority'] ?? 100);
            $bestPriority = $best ? (int) ($best['priority'] ?? 100) : 9999;
            if ($score > $bestScore || ($score === $bestScore && $priority < $bestPriority)) {
                $bestScore = $score;
                $best = $rule;
                $best['priority'] = $priority;
            }
        }

        return $best;
    }
}
