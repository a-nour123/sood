<?php

namespace App\Services\Governance;

use App\Models\GovernanceCommittee;
use App\Models\GovernanceCommitteeMember;
use App\Models\GovernanceMeeting;
use App\Models\GovernanceRequest;
use App\Models\GovernanceVotingSession;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class GovernanceNotificationCatalog
{
    public static function definitions(): array
    {
        return [
            'Governance_Request_Created' => self::item('{actor} created governance request "{number}".'),
            'Governance_Request_Updated' => self::item('{actor} updated governance request "{number}".'),
            'Governance_Request_Deleted' => self::item('{actor} deleted governance request "{number}".'),
            'Governance_Request_Submitted' => self::item('{actor} submitted governance request "{number}".'),
            'Governance_Request_Assigned' => self::item('{actor} assigned governance request "{number}" to committee "{committee}".'),
            'Governance_Request_Cancelled' => self::item('{actor} cancelled governance request "{number}". {comment}'),
            'Governance_Request_Closed' => self::item('{actor} closed governance request "{number}".'),
            'Governance_Request_Reopened' => self::item('{actor} reopened governance request "{number}". {comment}'),
            'Governance_Request_Deferred' => self::item('{actor} deferred governance request "{number}". {comment}'),
            'Governance_Request_Discussion' => self::item('{actor} moved governance request "{number}" to committee discussion.'),
            'Governance_Decision_Pending' => self::item('{actor} opened the decision stage for "{number}".'),
            'Governance_Request_Rejected' => self::item('Governance request "{number}" was rejected. {comment}'),
            'Governance_Information_Requested' => self::item('{actor} requested more information for "{number}". {comment}'),
            'Governance_Member_Assigned' => self::item('{actor} assigned a member on committee "{name}".'),
            'Governance_Member_Removed' => self::item('{actor} removed a member from committee "{name}".'),
            'Governance_Review_Requested' => self::item('A review is requested for "{number}".'),
            'Governance_Review_Completed' => self::item('{actor} submitted a review for "{number}".'),
            'Governance_Review_Comment' => self::item('{actor} commented on the review for "{number}". {comment}'),
            'Governance_Review_Overdue' => self::item('The review for "{number}" is overdue.'),
            'Governance_Meeting_Scheduled' => self::item('{actor} scheduled meeting "{name}".'),
            'Governance_Meeting_Updated' => self::item('{actor} updated meeting "{name}".'),
            'Governance_Meeting_Deleted' => self::item('{actor} deleted meeting "{name}".'),
            'Governance_Meeting_Reminder' => self::item('Reminder: meeting "{name}" is today.'),
            'Governance_Meeting_Minutes' => self::item('{actor} recorded minutes for meeting "{name}".'),
            'Governance_Meeting_Agenda' => self::item('{actor} added an agenda item to meeting "{name}".'),
            'Governance_Meeting_Attendees' => self::item('{actor} updated the attendees of meeting "{name}".'),
            'Governance_Meeting_Attendance' => self::item('{actor} updated attendance for meeting "{name}".'),
            'Governance_Meeting_Action' => self::item('{actor} assigned a meeting action for "{name}".'),
            'Governance_Voting_Started' => self::item('Voting started for "{number}".'),
            'Governance_Voting_Deadline' => self::item('Voting for "{number}" is approaching its deadline.'),
            'Governance_Vote_Cast' => self::item('{actor} cast a vote on "{number}".'),
            'Governance_Voting_Closed' => self::item('Voting closed for "{number}". Result: {status}.'),
            'Governance_Decision_Finalized' => self::item('{actor} recorded decision "{decision}" for "{number}".'),
            'Governance_Decision_Corrected' => self::item('{actor} corrected the decision for "{number}". {comment}'),
            'Governance_Exception_Expiring' => self::item('Exception "{number}" is approaching expiration.'),
            'Governance_Exception_Expired' => self::item('Exception "{number}" has expired.'),
            'Governance_Risk_Accepted' => self::item('Risk acceptance "{number}" was approved. The risk record was not modified.'),
            'Governance_Risk_Rejected' => self::item('Risk acceptance "{number}" was rejected.'),
            'Governance_Committee_Created' => self::item('{actor} created committee "{name}".'),
            'Governance_Committee_Updated' => self::item('{actor} updated committee "{name}".'),
            'Governance_Committee_Deleted' => self::item('{actor} deleted committee "{name}".'),
            'Governance_Department_Assigned' => self::item('{actor} assigned a department to committee "{name}".'),
            'Governance_Department_Removed' => self::item('{actor} removed a department from committee "{name}".'),
            'Governance_Request_Types_Updated' => self::item('{actor} updated the request types of committee "{name}".'),
            'Governance_Attachment_Added' => self::item('{actor} added an attachment to "{name}".'),
        ];
    }

    public static function dueDefinitions(): array
    {
        return [
            'Governance_Request_Due_Date' => self::dueItem('"{number}" is due on {due_date}.'),
            'Governance_Voting_Due_Date' => self::dueItem('Voting for "{number}" is due on {due_date}.'),
            'Governance_Exception_Due_Date' => self::dueItem('Exception "{number}" expires on {due_date}.'),
            'Governance_Meeting_Due_Date' => self::dueItem('Meeting "{name}" is on {due_date}.'),
        ];
    }

    public static function datesBeforeDue(string $actionName, ?string $due): array
    {
        if (!$due) {
            return [];
        }
        $raw = DB::table('auto_notifies')
            ->join('actions', 'auto_notifies.action_id', '=', 'actions.id')
            ->where('actions.name', $actionName)
            ->value('auto_notifies.date');
        $days = json_decode((string) $raw, true);
        if (!is_array($days)) {
            return [];
        }
        $dates = [];
        foreach ($days as $day) {
            $dates[] = Carbon::parse($due)->subDays((int) $day)->toDateString();
        }

        return array_values(array_unique($dates));
    }

    public static function dueSchedules(Model $subject, string $action, array $properties): array
    {
        $schedules = [];
        if ($subject instanceof GovernanceRequest) {
            $terminal = in_array($action, ['deleted', 'close', 'cancel'], true)
                || in_array($subject->status, ['approved', 'rejected', 'conditional_approval', 'closed', 'expired', 'cancelled'], true);
            if ($terminal || $action === 'deleted') {
                $schedules[] = ['clear' => true, 'model_id' => $subject->id, 'model_type' => 'GovernanceRequest'];
            } else {
                $schedules[] = self::entry('Governance_Request_Due_Date', $subject->id, 'GovernanceRequest', self::dateString($subject->due_date));
            }
            $sessionIds = GovernanceVotingSession::where('governance_request_id', $subject->id)->pluck('id')->all();
            foreach ($sessionIds as $sessionId) {
                $schedules[] = ['clear' => true, 'model_id' => $sessionId, 'model_type' => 'GovernanceVotingSession'];
            }
            $open = GovernanceVotingSession::where('governance_request_id', $subject->id)->where('status', 'open')->latest('id')->first();
            if ($open && !$terminal) {
                $schedules[] = self::entry('Governance_Voting_Due_Date', $open->id, 'GovernanceVotingSession', self::dateString($open->deadline));
            }
            $subject->load('exceptionDetail');
            $detail = $subject->exceptionDetail;
            if ($detail) {
                $active = in_array($subject->status, ['approved', 'conditional_approval'], true);
                if ($active) {
                    $schedules[] = self::entry('Governance_Exception_Due_Date', $detail->id, 'GovernanceExceptionDetail', self::dateString($detail->expiration_date));
                } else {
                    $schedules[] = ['clear' => true, 'model_id' => $detail->id, 'model_type' => 'GovernanceExceptionDetail'];
                }
            }
        }

        $meeting = null;
        if (!empty($properties['meeting_id'])) {
            $meeting = GovernanceMeeting::find($properties['meeting_id']);
        }
        if ($meeting) {
            if ($action === 'meeting_deleted' || $meeting->status !== 'scheduled') {
                $schedules[] = ['clear' => true, 'model_id' => $meeting->id, 'model_type' => 'GovernanceMeeting'];
            } else {
                $schedules[] = self::entry('Governance_Meeting_Due_Date', $meeting->id, 'GovernanceMeeting', self::dateString($meeting->meeting_date));
            }
        }

        return $schedules;
    }

    public static function roles(): array
    {
        $roles = [];
        foreach (CommitteeMemberPolicy::roles() as $role) {
            $roles[$role] = __('governance.member_roles.' . $role);
        }
        $roles['committee_member'] = __('governance.notify_roles.committee_member');
        $roles['requester'] = __('governance.notify_roles.requester');
        $roles['owner'] = __('governance.notify_roles.owner');
        $roles['reviewer'] = __('governance.notify_roles.reviewer');
        $roles['assignee'] = __('governance.notify_roles.assignee');
        $roles['attendee'] = __('governance.notify_roles.attendee');

        return $roles;
    }

    public static function canonical(Model $subject, string $action, array $properties = []): ?string
    {
        if (isset(self::definitions()[$action])) {
            return $action;
        }
        if ($action === 'decision_issued') {
            $decision = (string) ($properties['decision'] ?? $properties['description'] ?? '');
            $type = $subject instanceof GovernanceRequest ? $subject->request_type : '';
            if ($type === 'risk_acceptance' && $decision === 'approved') {
                return 'Governance_Risk_Accepted';
            }
            if ($type === 'risk_acceptance' && $decision === 'rejected') {
                return 'Governance_Risk_Rejected';
            }
            if ($decision === 'rejected') {
                return 'Governance_Request_Rejected';
            }

            return 'Governance_Decision_Finalized';
        }

        $map = [
            'created' => 'Governance_Request_Created',
            'updated' => 'Governance_Request_Updated',
            'deleted' => 'Governance_Request_Deleted',
            'submit' => 'Governance_Request_Submitted',
            'assign' => 'Governance_Request_Assigned',
            'reassign' => 'Governance_Request_Assigned',
            'cancel' => 'Governance_Request_Cancelled',
            'close' => 'Governance_Request_Closed',
            'reopen' => 'Governance_Request_Reopened',
            'defer' => 'Governance_Request_Deferred',
            'discuss' => 'Governance_Request_Discussion',
            'open_decision' => 'Governance_Decision_Pending',
            'request_info' => 'Governance_Information_Requested',
            'start_review' => 'Governance_Review_Requested',
            'resubmit' => 'Governance_Review_Requested',
            'resume' => 'Governance_Review_Requested',
            'expired' => 'Governance_Exception_Expired',
            'expire' => 'Governance_Exception_Expired',
            'exception_expiring' => 'Governance_Exception_Expiring',
            'member_saved' => 'Governance_Member_Assigned',
            'member_removed' => 'Governance_Member_Removed',
            'review_submitted' => 'Governance_Review_Completed',
            'review_comment' => 'Governance_Review_Comment',
            'review_overdue' => 'Governance_Review_Overdue',
            'meeting_scheduled' => 'Governance_Meeting_Scheduled',
            'meeting_updated' => 'Governance_Meeting_Updated',
            'meeting_deleted' => 'Governance_Meeting_Deleted',
            'meeting_reminder' => 'Governance_Meeting_Reminder',
            'minutes_recorded' => 'Governance_Meeting_Minutes',
            'meeting_agenda' => 'Governance_Meeting_Agenda',
            'meeting_attendees' => 'Governance_Meeting_Attendees',
            'meeting_attendance' => 'Governance_Meeting_Attendance',
            'meeting_action' => 'Governance_Meeting_Action',
            'voting_opened' => 'Governance_Voting_Started',
            'voting_deadline' => 'Governance_Voting_Deadline',
            'vote_cast' => 'Governance_Vote_Cast',
            'voting_closed' => 'Governance_Voting_Closed',
            'decision_corrected' => 'Governance_Decision_Corrected',
            'committee_created' => 'Governance_Committee_Created',
            'committee_updated' => 'Governance_Committee_Updated',
            'committee_deleted' => 'Governance_Committee_Deleted',
            'department_assigned' => 'Governance_Department_Assigned',
            'department_removed' => 'Governance_Department_Removed',
            'request_types_updated' => 'Governance_Request_Types_Updated',
            'attachment_added' => 'Governance_Attachment_Added',
        ];

        return $map[$action] ?? null;
    }

    public static function receivers(Model $subject, array $properties = []): array
    {
        $committeeId = self::committeeId($subject, $properties);
        $today = date('Y-m-d');
        $members = $committeeId
            ? GovernanceCommitteeMember::query()
                ->where('committee_id', $committeeId)
                ->where('status', 'active')
                ->where(function ($query) use ($today) {
                    $query->whereNull('effective_from')->orWhereDate('effective_from', '<=', $today);
                })
                ->where(function ($query) use ($today) {
                    $query->whereNull('effective_until')->orWhereDate('effective_until', '>=', $today);
                })
                ->get(['user_id', 'member_role', 'can_review'])
            : collect();

        $byRole = [];
        foreach (CommitteeMemberPolicy::roles() as $role) {
            $byRole[$role] = [];
        }
        $all = [];
        $reviewers = [];
        foreach ($members as $member) {
            $byRole[$member->member_role][] = (int) $member->user_id;
            $all[] = (int) $member->user_id;
            if ($member->can_review) {
                $reviewers[] = (int) $member->user_id;
            }
        }

        $ownerId = $properties['owner_id'] ?? null;
        $requesterId = $properties['requester_id'] ?? null;
        if ($subject instanceof GovernanceRequest) {
            $subject->loadMissing('exceptionDetail');
            $requesterId = $requesterId ?: $subject->requester_id;
            $ownerId = $ownerId ?: optional($subject->exceptionDetail)->owner_id;
        }

        $attendees = [];
        if ($subject instanceof GovernanceMeeting) {
            $subject->loadMissing('attendees');
            $attendees = $subject->attendees->pluck('user_id')->all();
        }
        if (array_key_exists('attendee_ids', $properties)) {
            $attendees = $properties['attendee_ids'];
        }
        if (array_key_exists('reviewer_ids', $properties)) {
            $reviewers = $properties['reviewer_ids'];
        }

        $roles = [];
        foreach ($byRole as $role => $ids) {
            $roles[$role] = self::ids($ids);
        }
        $roles['committee_member'] = self::ids($all);
        $roles['requester'] = self::ids([$requesterId]);
        $roles['owner'] = self::ids([$ownerId]);
        $roles['reviewer'] = self::ids($reviewers);
        $roles['assignee'] = self::ids([$properties['assignee_id'] ?? null]);
        $roles['attendee'] = self::ids($attendees);

        return $roles;
    }

    public static function payload(Model $subject, array $properties = []): Model
    {
        $copy = clone $subject;
        $name = $subject->name ?? $subject->title ?? ($subject->request_number ?? '');
        $number = $subject->request_number ?? ($subject->code ?? $name);
        $copy->setAttribute('name', (string) $name);
        $copy->setAttribute('number', (string) $number);
        $copy->setAttribute('committee', self::committeeName($subject));
        $copy->setAttribute('status', (string) ($properties['status'] ?? $subject->status ?? ''));
        $copy->setAttribute('decision', (string) ($properties['decision'] ?? ''));
        $copy->setAttribute('comment', (string) ($properties['comment'] ?? $properties['description'] ?? ''));
        $copy->setAttribute('actor', (string) ($properties['actor_name'] ?? (optional(auth()->user())->name ?: '')));
        $copy->setAttribute('due_date', '');

        return $copy;
    }

    public static function link(Model $subject, array $properties = []): string
    {
        if ($subject instanceof GovernanceMeeting) {
            return route('admin.committee.meetings.show', $subject->id);
        }
        if (!empty($properties['meeting_id'])) {
            return route('admin.committee.meetings.show', $properties['meeting_id']);
        }
        if ($subject instanceof GovernanceRequest) {
            return route('admin.committee.requests.show', $subject->id);
        }
        if ($subject instanceof GovernanceCommittee) {
            return route('admin.committee.committees.show', $subject->id);
        }

        return route('admin.committee.dashboard');
    }

    protected static function item(string $message): array
    {
        return [
            'message' => $message,
            'variables' => ['name', 'number', 'committee', 'actor', 'comment', 'decision', 'status'],
        ];
    }

    protected static function dueItem(string $message): array
    {
        return [
            'message' => $message,
            'variables' => ['name', 'number', 'committee', 'due_date', 'status', 'actor'],
        ];
    }

    protected static function entry(string $name, $modelId, string $modelType, ?string $date): array
    {
        return [
            'name' => $name,
            'model_id' => $modelId,
            'model_type' => $modelType,
            'date' => $date,
        ];
    }

    protected static function dateString($value): ?string
    {
        if ($value instanceof \DateTimeInterface) {
            return $value->format('Y-m-d');
        }
        if (!$value) {
            return null;
        }
        try {
            return Carbon::parse($value)->toDateString();
        } catch (\Throwable $exception) {
            return null;
        }
    }

    protected static function committeeId(Model $subject, array $properties): ?int
    {
        if ($subject instanceof GovernanceCommittee) {
            return (int) $subject->id;
        }
        if ($subject instanceof GovernanceRequest) {
            return (int) ($subject->assigned_committee_id ?: ($properties['committee_id'] ?? 0)) ?: null;
        }
        if ($subject instanceof GovernanceMeeting) {
            return (int) $subject->committee_id;
        }
        $id = (int) ($properties['committee_id'] ?? 0);

        return $id > 0 ? $id : null;
    }

    protected static function committeeName(Model $subject): string
    {
        if ($subject instanceof GovernanceCommittee) {
            return (string) $subject->name;
        }
        if ($subject instanceof GovernanceRequest || $subject instanceof GovernanceMeeting) {
            $subject->loadMissing('committee');

            return (string) optional($subject->committee)->name;
        }

        return '';
    }

    protected static function ids($values): array
    {
        if ($values instanceof \Illuminate\Support\Collection) {
            $values = $values->all();
        }
        if (!is_array($values)) {
            $values = [$values];
        }

        return array_values(array_unique(array_filter(array_map('intval', $values))));
    }
}
