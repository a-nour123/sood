<?php

namespace App\Services\Governance;

use App\Models\GovernanceCommittee;
use App\Models\GovernanceCommitteeDepartment;
use App\Models\GovernanceCommitteeMember;
use App\Models\GovernanceCommitteeRequestType;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class GovernanceCommitteeService
{
    public static function save(User $actor, array $data, ?GovernanceCommittee $committee = null): array
    {
        if (!CommitteeMemberPolicy::datesValid($data['effective_from'] ?? null, $data['effective_until'] ?? null)) {
            return self::fail(__('governance.InvalidDates'));
        }
        $payload = [
            'name' => $data['name'],
            'code' => $data['code'],
            'description' => $data['description'] ?? null,
            'responsibilities' => $data['responsibilities'] ?? null,
            'committee_type_id' => $data['committee_type_id'] ?: null,
            'status' => $data['status'] ?? 'active',
            'effective_from' => $data['effective_from'] ?: null,
            'effective_until' => $data['effective_until'] ?: null,
            'approval_mode' => $data['approval_mode'] ?? 'chairman',
            'minimum_approval_count' => $data['minimum_approval_count'] ?? 1,
            'voting_threshold' => $data['voting_threshold'] ?? 50,
            'quorum_count' => $data['quorum_count'] ?? 0,
            'allow_vote_change' => !empty($data['allow_vote_change']),
            'updated_by' => $actor->id,
        ];
        $committee = DB::transaction(function () use ($committee, $payload, $actor) {
            if ($committee) {
                $committee->update($payload);
            } else {
                $committee = GovernanceCommittee::create($payload + ['created_by' => $actor->id]);
            }
            GovernanceLogger::log(null, $committee->wasRecentlyCreated ? 'committee_created' : 'committee_updated', $committee->name, [], $committee->id, $actor);

            return $committee;
        });

        return ['ok' => true, 'message' => __('governance.Saved'), 'committee' => $committee];
    }

    public static function remove(User $actor, GovernanceCommittee $committee): array
    {
        if ($committee->requests()->exists() || $committee->meetings()->exists() || $committee->decisions()->exists()) {
            return self::fail(__('governance.CommitteeHasHistory'));
        }
        DB::transaction(function () use ($committee, $actor) {
            GovernanceLogger::log(null, 'committee_deleted', $committee->name, [], $committee->id, $actor);
            $committee->delete();
        });

        return ['ok' => true, 'message' => __('governance.Deleted')];
    }

    public static function assignDepartment(User $actor, GovernanceCommittee $committee, int $departmentId): array
    {
        $active = GovernanceCommitteeDepartment::where('committee_id', $committee->id)
            ->where('department_id', $departmentId)
            ->whereNull('removed_at')
            ->exists();
        if ($active) {
            return self::fail(__('governance.DuplicateDepartment'));
        }
        DB::transaction(function () use ($actor, $committee, $departmentId) {
            GovernanceCommitteeDepartment::create([
                'committee_id' => $committee->id,
                'department_id' => $departmentId,
                'assigned_by' => $actor->id,
                'assigned_at' => now(),
            ]);
            GovernanceLogger::log(null, 'department_assigned', (string) $departmentId, [], $committee->id, $actor);
        });

        return ['ok' => true, 'message' => __('governance.Saved')];
    }

    public static function removeDepartment(User $actor, GovernanceCommittee $committee, int $departmentId): array
    {
        $link = GovernanceCommitteeDepartment::where('committee_id', $committee->id)
            ->where('department_id', $departmentId)
            ->whereNull('removed_at')
            ->first();
        if (!$link) {
            return self::fail(__('governance.NotFound'));
        }
        if ($committee->members()->where('department_id', $departmentId)->where('status', 'active')->exists()) {
            return self::fail(__('governance.DepartmentHasMembers'));
        }
        DB::transaction(function () use ($link, $actor, $committee, $departmentId) {
            $link->update(['removed_at' => now()]);
            GovernanceLogger::log(null, 'department_removed', (string) $departmentId, [], $committee->id, $actor);
        });

        return ['ok' => true, 'message' => __('governance.Deleted')];
    }

    public static function saveMember(User $actor, GovernanceCommittee $committee, array $data, ?GovernanceCommitteeMember $member = null): array
    {
        $user = User::find($data['user_id'] ?? 0);
        if (!$user || !$user->department_id) {
            return self::fail(__('governance.UserDepartmentRequired'));
        }
        $departmentId = (int) ($data['department_id'] ?: $user->department_id);
        if ((int) $user->department_id !== $departmentId) {
            return self::fail(__('governance.UserNotInDepartment'));
        }
        $assigned = GovernanceCommitteeDepartment::where('committee_id', $committee->id)
            ->where('department_id', $departmentId)
            ->whereNull('removed_at')
            ->exists();
        if (!$assigned) {
            return self::fail(__('governance.DepartmentNotOnCommittee'));
        }
        if (!in_array($data['member_role'], CommitteeMemberPolicy::roles(), true)) {
            return self::fail(__('governance.InvalidRole'));
        }
        $from = $data['effective_from'] ?: null;
        $until = $data['effective_until'] ?: null;
        if (!CommitteeMemberPolicy::datesValid($from, $until)) {
            return self::fail(__('governance.InvalidDates'));
        }
        $existing = $committee->members()->get(['id', 'user_id', 'status', 'effective_from', 'effective_until'])->map(function ($row) {
            return [
                'id' => $row->id,
                'user_id' => $row->user_id,
                'status' => $row->status,
                'effective_from' => optional($row->effective_from)->toDateString(),
                'effective_until' => optional($row->effective_until)->toDateString(),
            ];
        })->all();
        if (CommitteeMemberPolicy::duplicate($existing, (int) $user->id, $from, $until, $member ? $member->id : null)) {
            return self::fail(__('governance.DuplicateMember'));
        }
        $defaults = CommitteeMemberPolicy::defaults($data['member_role']);
        $payload = [
            'committee_id' => $committee->id,
            'user_id' => $user->id,
            'department_id' => $departmentId,
            'member_role' => $data['member_role'],
            'voting_right' => array_key_exists('voting_right', $data) ? (bool) $data['voting_right'] : $defaults['voting_right'],
            'voting_weight' => $data['voting_weight'] ?? $defaults['voting_weight'],
            'can_recommend' => array_key_exists('can_recommend', $data) ? (bool) $data['can_recommend'] : $defaults['can_recommend'],
            'can_approve' => array_key_exists('can_approve', $data) ? (bool) $data['can_approve'] : $defaults['can_approve'],
            'can_review' => array_key_exists('can_review', $data) ? (bool) $data['can_review'] : $defaults['can_review'],
            'effective_from' => $from,
            'effective_until' => $until,
            'status' => $data['status'] ?? 'active',
        ];
        if ($payload['member_role'] === 'observer') {
            $payload['voting_right'] = false;
            $payload['can_recommend'] = false;
            $payload['can_approve'] = false;
            $payload['can_review'] = false;
        }
        $member = DB::transaction(function () use ($member, $payload, $actor, $committee, $user) {
            if ($member) {
                $member->update($payload);
            } else {
                $member = GovernanceCommitteeMember::create($payload);
            }
            self::syncLeadership($committee, $member);
            GovernanceLogger::log(null, 'member_saved', $user->name, ['member_id' => $member->id, 'assignee_id' => $user->id], $committee->id, $actor);

            return $member;
        });

        return ['ok' => true, 'message' => __('governance.Saved'), 'member' => $member];
    }

    public static function removeMember(User $actor, GovernanceCommitteeMember $member): array
    {
        DB::transaction(function () use ($actor, $member) {
            if ($member->reviews()->exists() || $member->votes()->exists()) {
                $member->update(['status' => 'inactive', 'effective_until' => now()->toDateString()]);
            } else {
                $member->update(['status' => 'inactive', 'effective_until' => now()->toDateString()]);
                $member->delete();
            }
            $committee = $member->committee;
            if ($committee && (int) $committee->chairman_id === (int) $member->user_id) {
                $committee->update(['chairman_id' => null]);
            }
            if ($committee && (int) $committee->secretary_id === (int) $member->user_id) {
                $committee->update(['secretary_id' => null]);
            }
            GovernanceLogger::log(null, 'member_removed', (string) $member->user_id, [], $member->committee_id, $actor);
        });

        return ['ok' => true, 'message' => __('governance.Deleted')];
    }

    public static function syncRequestTypes(User $actor, GovernanceCommittee $committee, array $types): array
    {
        $allowed = ['approval', 'exception', 'risk_acceptance'];
        $types = array_values(array_unique(array_intersect($types, $allowed)));
        DB::transaction(function () use ($committee, $types, $actor) {
            GovernanceCommitteeRequestType::where('committee_id', $committee->id)->whereNotIn('request_type', $types ?: ['__none__'])->delete();
            foreach ($types as $type) {
                GovernanceCommitteeRequestType::firstOrCreate([
                    'committee_id' => $committee->id,
                    'request_type' => $type,
                ]);
            }
            GovernanceLogger::log(null, 'request_types_updated', implode(',', $types), [], $committee->id, $actor);
        });

        return ['ok' => true, 'message' => __('governance.Saved')];
    }

    public static function committeeHandles(GovernanceCommittee $committee, string $type): bool
    {
        return $committee->isActiveOn() && $committee->requestTypes()->where('request_type', $type)->exists();
    }

    protected static function syncLeadership(GovernanceCommittee $committee, GovernanceCommitteeMember $member): void
    {
        if ($member->member_role === 'chairman' && $member->status === 'active') {
            GovernanceCommitteeMember::where('committee_id', $committee->id)
                ->where('id', '!=', $member->id)
                ->where('member_role', 'chairman')
                ->update(array_merge(['member_role' => 'vice_chairman'], CommitteeMemberPolicy::defaults('vice_chairman')));
            $committee->update(['chairman_id' => $member->user_id]);
        }
        if ($member->member_role === 'secretary' && $member->status === 'active') {
            GovernanceCommitteeMember::where('committee_id', $committee->id)
                ->where('id', '!=', $member->id)
                ->where('member_role', 'secretary')
                ->update(array_merge(['member_role' => 'advisor'], CommitteeMemberPolicy::defaults('advisor')));
            $committee->update(['secretary_id' => $member->user_id]);
        }
    }

    protected static function fail(string $message): array
    {
        return ['ok' => false, 'message' => $message, 'code' => 422];
    }
}
