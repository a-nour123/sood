<?php

namespace App\Services\Governance;

use App\Models\GovernanceCommittee;
use App\Models\GovernanceCommitteeMember;
use App\Models\GovernanceDecision;
use App\Models\GovernanceExceptionDetail;
use App\Models\GovernanceMeeting;
use App\Models\GovernanceRequest;
use App\Models\GovernanceReview;
use App\Models\GovernanceVote;
use App\Models\User;
use Illuminate\Support\Collection;

class GovernanceReportService
{
    public static function types(): array
    {
        return [
            'committees', 'members', 'requests', 'approvals', 'exceptions', 'risk_acceptance',
            'reviews', 'decisions', 'votes', 'meetings', 'exception_expiration', 'activity',
        ];
    }

    public static function rows(User $user, string $type, array $filters): array
    {
        switch ($type) {
            case 'members':
                return self::members($user, $filters);
            case 'approvals':
                return self::requests($user, $filters, 'approval');
            case 'exceptions':
                return self::requests($user, $filters, 'exception');
            case 'risk_acceptance':
                return self::requests($user, $filters, 'risk_acceptance');
            case 'reviews':
                return self::reviews($user, $filters);
            case 'decisions':
                return self::decisions($user, $filters);
            case 'votes':
                return self::votes($user, $filters);
            case 'meetings':
                return self::meetings($user, $filters);
            case 'exception_expiration':
                return self::expirations($user, $filters);
            case 'activity':
                return self::activity($user, $filters);
            case 'requests':
                return self::requests($user, $filters, null);
            default:
                return self::committees($user, $filters);
        }
    }

    public static function headings(string $type): array
    {
        $map = [
            'committees' => ['Name', 'Code', 'Type', 'Status', 'Mode', 'Chairman'],
            'members' => ['Committee', 'Member', 'Department', 'Role', 'Voting', 'Status'],
            'requests' => ['Number', 'Type', 'Title', 'Status', 'Priority', 'Committee', 'Department', 'Due'],
            'approvals' => ['Number', 'Title', 'Status', 'Committee', 'Document', 'Due'],
            'exceptions' => ['Number', 'Title', 'Status', 'Framework', 'Expiration', 'Owner'],
            'risk_acceptance' => ['Number', 'Title', 'Status', 'Risk', 'Outcome', 'Committee'],
            'reviews' => ['Request', 'Reviewer', 'Status', 'Recommendation', 'Reviewed'],
            'decisions' => ['Number', 'Request', 'Decision', 'By', 'At', 'Status'],
            'votes' => ['Request', 'Voter', 'Vote', 'Weight', 'At'],
            'meetings' => ['Number', 'Committee', 'Title', 'Date', 'Type', 'Status'],
            'exception_expiration' => ['Request', 'Expiration', 'Status', 'Owner', 'Conditions'],
            'activity' => ['When', 'Action', 'Request', 'Actor', 'Description'],
        ];

        return $map[$type] ?? $map['committees'];
    }

    protected static function committees(User $user, array $filters): array
    {
        $query = GovernanceAccess::scopeCommittees(GovernanceCommittee::with(['type', 'chairman']), $user);
        if (!empty($filters['committee_id'])) {
            $query->where('id', $filters['committee_id']);
        }

        return $query->get()->map(function (GovernanceCommittee $committee) {
            return [$committee->name, $committee->code, optional($committee->type)->name, $committee->status, $committee->approval_mode, optional($committee->chairman)->name];
        })->all();
    }

    protected static function members(User $user, array $filters): array
    {
        $ids = GovernanceAccess::scopeCommittees(GovernanceCommittee::query(), $user)->pluck('id');
        $query = GovernanceCommitteeMember::with(['committee', 'user', 'department'])->whereIn('committee_id', $ids);
        if (!empty($filters['committee_id'])) {
            $query->where('committee_id', $filters['committee_id']);
        }

        return $query->get()->map(function (GovernanceCommitteeMember $member) {
            return [optional($member->committee)->name, optional($member->user)->name, optional($member->department)->name, $member->member_role, $member->voting_right ? 'yes' : 'no', $member->status];
        })->all();
    }

    protected static function requests(User $user, array $filters, ?string $type): array
    {
        $query = GovernanceDashboardService::requests($user, $filters)->with(['committee', 'department', 'approvalDetail.document', 'exceptionDetail.framework', 'exceptionDetail.owner', 'riskAcceptanceDetail.risk']);
        if ($type) {
            $query->where('request_type', $type);
        }

        return $query->orderByDesc('id')->limit(2000)->get()->map(function (GovernanceRequest $request) use ($type) {
            if ($type === 'approval') {
                return [$request->request_number, $request->title, $request->status, optional($request->committee)->name, optional(optional($request->approvalDetail)->document)->document_name, optional($request->due_date)->toDateString()];
            }
            if ($type === 'exception') {
                return [$request->request_number, $request->title, $request->status, optional(optional($request->exceptionDetail)->framework)->name, optional(optional($request->exceptionDetail)->expiration_date)->toDateString(), optional(optional($request->exceptionDetail)->owner)->name];
            }
            if ($type === 'risk_acceptance') {
                return [$request->request_number, $request->title, $request->status, optional(optional($request->riskAcceptanceDetail)->risk)->reference_id, optional($request->riskAcceptanceDetail)->decision_outcome, optional($request->committee)->name];
            }

            return [$request->request_number, $request->request_type, $request->title, $request->status, $request->priority, optional($request->committee)->name, optional($request->department)->name, optional($request->due_date)->toDateString()];
        })->all();
    }

    protected static function reviews(User $user, array $filters): array
    {
        $ids = GovernanceDashboardService::requests($user, $filters)->pluck('id');

        return GovernanceReview::with(['request', 'reviewer'])->whereIn('governance_request_id', $ids)->where('review_status', 'pending')->orderByDesc('id')->limit(2000)->get()
            ->map(function (GovernanceReview $review) {
                return [optional($review->request)->request_number, optional($review->reviewer)->name, $review->review_status, $review->recommendation, optional($review->reviewed_at)->toDateTimeString()];
            })->all();
    }

    protected static function decisions(User $user, array $filters): array
    {
        $ids = GovernanceDashboardService::requests($user, $filters)->pluck('id');

        return GovernanceDecision::with(['request', 'decider'])->whereIn('governance_request_id', $ids)->orderByDesc('id')->limit(2000)->get()
            ->map(function (GovernanceDecision $decision) {
                return [$decision->decision_number, optional($decision->request)->request_number, $decision->decision_type, optional($decision->decider)->name, optional($decision->decided_at)->toDateTimeString(), $decision->status];
            })->all();
    }

    protected static function votes(User $user, array $filters): array
    {
        $ids = GovernanceDashboardService::requests($user, $filters)->pluck('id');

        return GovernanceVote::with(['request', 'voter'])->whereIn('governance_request_id', $ids)->orderByDesc('id')->limit(2000)->get()
            ->map(function (GovernanceVote $vote) {
                return [optional($vote->request)->request_number, optional($vote->voter)->name, $vote->vote, $vote->voting_weight, optional($vote->voted_at)->toDateTimeString()];
            })->all();
    }

    protected static function meetings(User $user, array $filters): array
    {
        $committeeIds = GovernanceAccess::scopeCommittees(GovernanceCommittee::query(), $user)->pluck('id');
        $query = GovernanceMeeting::with('committee')->whereIn('committee_id', $committeeIds);
        if (!empty($filters['committee_id'])) {
            $query->where('committee_id', $filters['committee_id']);
        }

        return $query->orderByDesc('meeting_date')->limit(2000)->get()->map(function (GovernanceMeeting $meeting) {
            return [$meeting->meeting_number, optional($meeting->committee)->name, $meeting->title, optional($meeting->meeting_date)->toDateString(), $meeting->meeting_type, $meeting->status];
        })->all();
    }

    protected static function expirations(User $user, array $filters): array
    {
        $ids = GovernanceDashboardService::requests($user, $filters)->where('request_type', 'exception')->pluck('id');

        return GovernanceExceptionDetail::with(['request', 'owner'])->whereIn('governance_request_id', $ids)->whereNotNull('expiration_date')->orderBy('expiration_date')->limit(2000)->get()
            ->map(function (GovernanceExceptionDetail $detail) {
                return [optional($detail->request)->request_number, optional($detail->expiration_date)->toDateString(), optional($detail->request)->status, optional($detail->owner)->name, $detail->approved_conditions];
            })->all();
    }

    protected static function activity(User $user, array $filters): array
    {
        $ids = GovernanceDashboardService::requests($user, $filters)->pluck('id');

        return \App\Models\GovernanceActivityLog::with(['request', 'actor'])->whereIn('governance_request_id', $ids)->orderByDesc('id')->limit(2000)->get()
            ->map(function ($log) {
                return [optional($log->created_at)->toDateTimeString(), $log->action, optional($log->request)->request_number, optional($log->actor)->name, $log->description];
            })->all();
    }
}
