<?php

namespace App\Services\Governance;

use App\Events\TaskCreated;
use App\Models\GovernanceMeeting;
use App\Models\GovernanceMeetingAction;
use App\Models\GovernanceMeetingAgenda;
use App\Models\GovernanceMeetingMember;
use App\Models\GovernanceMeetingMinute;
use App\Models\Task;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class GovernanceMeetingService
{
    public static function save(User $actor, array $data, ?GovernanceMeeting $meeting = null): array
    {
        if (!empty($data['end_time']) && !empty($data['start_time']) && $data['end_time'] < $data['start_time']) {
            return self::fail(__('governance.InvalidDates'));
        }
        $committee = \App\Models\GovernanceCommittee::find($data['committee_id'] ?? ($meeting ? $meeting->committee_id : 0));
        $assigned = $meeting
            ? GovernanceAccess::assignedToMeeting($actor, $meeting)
            : ($committee && GovernanceAccess::assignedToCommittee($actor, $committee));
        if (!$committee || !GovernanceAccess::canViewCommittee($actor, $committee) || !GovernanceAccess::allows($actor, 'manage_committee_meetings', (bool) $assigned)) {
            return self::fail(__('governance.Forbidden'), 403);
        }
        $payload = [
            'committee_id' => $committee->id,
            'meeting_number' => $data['meeting_number'],
            'title' => $data['title'],
            'description' => $data['description'] ?? null,
            'meeting_date' => $data['meeting_date'],
            'start_time' => $data['start_time'] ?: null,
            'end_time' => $data['end_time'] ?: null,
            'location' => $data['location'] ?? null,
            'meeting_type' => $data['meeting_type'] ?? 'regular',
            'chairman_id' => $data['chairman_id'] ?: $committee->chairman_id,
            'secretary_id' => $data['secretary_id'] ?: $committee->secretary_id,
            'status' => $data['status'] ?? 'scheduled',
            'created_by' => $meeting ? $meeting->created_by : $actor->id,
        ];
        $created = false;
        $meeting = DB::transaction(function () use ($meeting, $payload, &$created) {
            if ($meeting) {
                $meeting->update($payload);
            } else {
                $meeting = GovernanceMeeting::create($payload);
                $created = true;
            }

            return $meeting;
        });
        GovernanceLogger::log(null, $created ? 'meeting_scheduled' : 'meeting_updated', $meeting->title, [
            'meeting_id' => $meeting->id,
            'attendee_ids' => array_filter([$meeting->chairman_id, $meeting->secretary_id]),
        ], $meeting->committee_id, $actor);

        return ['ok' => true, 'message' => __('governance.Saved'), 'meeting' => $meeting];
    }

    public static function attend(GovernanceMeeting $meeting, array $userIds): void
    {
        $keep = [];
        foreach ($userIds as $userId) {
            $userId = (int) $userId;
            if ($userId < 1) {
                continue;
            }
            $keep[] = $userId;
            GovernanceMeetingMember::firstOrCreate(
                ['governance_meeting_id' => $meeting->id, 'user_id' => $userId],
                ['attendance' => 'invited']
            );
        }
        if ($keep) {
            GovernanceMeetingMember::where('governance_meeting_id', $meeting->id)->whereNotIn('user_id', $keep)->delete();
        }
        GovernanceLogger::log(null, 'meeting_attendees', $meeting->title, [
            'meeting_id' => $meeting->id,
            'attendee_ids' => $keep,
        ], $meeting->committee_id, auth()->user());
    }

    public static function attendance(GovernanceMeetingMember $member, string $attendance): array
    {
        if (!in_array($attendance, ['invited', 'present', 'absent', 'excused'], true)) {
            return self::fail(__('governance.InvalidAttendance'));
        }
        $member->update(['attendance' => $attendance]);
        $meeting = $member->meeting;
        GovernanceLogger::log(null, 'meeting_attendance', optional($meeting)->title, [
            'meeting_id' => $member->governance_meeting_id,
            'attendee_ids' => [$member->user_id],
        ], optional($meeting)->committee_id, auth()->user());

        return ['ok' => true, 'message' => __('governance.Saved')];
    }

    public static function agenda(GovernanceMeeting $meeting, array $data): array
    {
        GovernanceMeetingAgenda::create([
            'governance_meeting_id' => $meeting->id,
            'governance_request_id' => $data['governance_request_id'] ?: null,
            'title' => $data['title'],
            'description' => $data['description'] ?? null,
            'sort_order' => $data['sort_order'] ?? 0,
        ]);
        GovernanceLogger::log(null, 'meeting_agenda', $meeting->title, ['meeting_id' => $meeting->id], $meeting->committee_id, auth()->user());

        return ['ok' => true, 'message' => __('governance.Saved')];
    }

    public static function minutes(User $actor, GovernanceMeeting $meeting, array $data): array
    {
        GovernanceMeetingMinute::updateOrCreate(
            ['governance_meeting_id' => $meeting->id],
            [
                'discussion' => $data['discussion'] ?? null,
                'recommendations' => $data['recommendations'] ?? null,
                'resolutions' => $data['resolutions'] ?? null,
                'recorded_by' => $actor->id,
            ]
        );
        $meeting->update(['status' => $data['status'] ?? $meeting->status]);
        GovernanceLogger::log(null, 'minutes_recorded', $meeting->title, ['meeting_id' => $meeting->id], $meeting->committee_id, $actor);

        return ['ok' => true, 'message' => __('governance.Saved')];
    }

    public static function actionItem(User $actor, GovernanceMeeting $meeting, array $data): array
    {
        $assignee = User::find($data['assignee_id'] ?? 0);
        if (!$assignee) {
            return self::fail(__('governance.AssigneeRequired'));
        }
        $task = DB::transaction(function () use ($actor, $meeting, $data, $assignee) {
            $task = Task::create([
                'title' => mb_substr($data['title'], 0, 100),
                'description' => $data['description'] ?: $data['title'],
                'priority' => 'Normal',
                'status' => 'Open',
                'start_date' => now()->toDateString(),
                'due_date' => $data['due_date'] ?: now()->addDays(7)->toDateString(),
                'assignable_id' => $assignee->id,
                'assignable_type' => User::class,
                'created_by' => $actor->id,
            ]);
            GovernanceMeetingAction::create([
                'governance_meeting_id' => $meeting->id,
                'governance_request_id' => $data['governance_request_id'] ?: null,
                'task_id' => $task->id,
                'title' => $data['title'],
            ]);
            event(new TaskCreated($task, $assignee, null));
            GovernanceLogger::log(null, 'meeting_action', $meeting->title, [
                'meeting_id' => $meeting->id,
                'assignee_id' => $assignee->id,
            ], $meeting->committee_id, $actor);

            return $task;
        });

        return ['ok' => true, 'message' => __('governance.Saved'), 'task' => $task];
    }

    protected static function fail(string $message, int $code = 422): array
    {
        return ['ok' => false, 'message' => $message, 'code' => $code];
    }
}
