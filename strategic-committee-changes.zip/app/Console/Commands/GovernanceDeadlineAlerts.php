<?php

namespace App\Console\Commands;

use App\Services\Governance\GovernanceRequestService;
use Illuminate\Console\Command;

class GovernanceDeadlineAlerts extends Command
{
    protected $signature = 'governance:deadline-alerts';

    protected $description = 'Mark approved exceptions expired after their expiration date';

    public function handle()
    {
        GovernanceRequestService::expireDueExceptions();
        $this->info('Governance exceptions past their expiration date were checked.');

        return 0;
    }
}
