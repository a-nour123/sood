<?php

namespace App\Listeners;

use App\Events\StrategicActionOccurred;
use App\Http\Traits\NotificationHandlingTrait;
use App\Models\Action;
use App\Models\NotifyAtDateModel;
use App\Services\Strategic\StrategicNotificationCatalog;
use Illuminate\Support\Facades\Log;

class StrategicActionListener
{
    use NotificationHandlingTrait;

    public function handle(StrategicActionOccurred $event)
    {
        try {
            $name = StrategicNotificationCatalog::canonical($event->subject, $event->action);
            if (!$name) {
                return;
            }
            $action = Action::where('name', $name)->first();
            if (!$action) {
                return;
            }
            $definition = StrategicNotificationCatalog::definitions()[$name];
            $roles = StrategicNotificationCatalog::receivers($event->subject, $definition['permission'], $event->properties);
            $payload = StrategicNotificationCatalog::payload($event->subject, $event->properties);
            $link = ['link' => StrategicNotificationCatalog::link($event->subject, $name)];
            $due = $this->dueSchedule($event->subject, $name);

            $this->sendNotificationForAction(
                $action->id,
                $due['action_id'],
                $link,
                $payload,
                $roles,
                $due['dates'],
                $due['model_id'],
                $due['model_type'],
                $due['process']
            );
        } catch (\Throwable $exception) {
            Log::warning('Strategic planning notification failed: ' . $exception->getMessage());
        }
    }

    protected function dueSchedule($subject, string $actionName): array
    {
        $empty = ['action_id' => null, 'dates' => null, 'model_id' => null, 'model_type' => null, 'process' => null];
        $dueName = StrategicNotificationCatalog::dueActionFor($subject);
        if (!$dueName) {
            return $empty;
        }
        $modelType = class_basename($subject);
        if (substr($actionName, -8) === '_Deleted') {
            NotifyAtDateModel::where('model_id', $subject->getKey())->where('model_type', $modelType)->delete();

            return $empty;
        }
        $dueAction = Action::where('name', $dueName)->first();
        $dates = StrategicNotificationCatalog::datesBeforeDue($dueName, $subject);
        if (!$dueAction || !$dates) {
            return $empty;
        }

        return [
            'action_id' => $dueAction->id,
            'dates' => $dates,
            'model_id' => $subject->getKey(),
            'model_type' => $modelType,
            'process' => 'create',
        ];
    }
}
