<?php

namespace App\Listeners;

use App\Events\GovernanceActionOccurred;
use App\Http\Traits\NotificationHandlingTrait;
use App\Models\Action;
use App\Models\NotifyAtDateModel;
use App\Services\Governance\GovernanceNotificationCatalog;
use Illuminate\Support\Facades\Log;

class GovernanceActionListener
{
    use NotificationHandlingTrait;

    public function handle(GovernanceActionOccurred $event)
    {
        try {
            $name = GovernanceNotificationCatalog::canonical($event->subject, $event->action, $event->properties);
            if (!$name) {
                return;
            }
            $action = Action::where('name', $name)->first();
            if (!$action) {
                return;
            }
            $roles = GovernanceNotificationCatalog::receivers($event->subject, $event->properties);
            $payload = GovernanceNotificationCatalog::payload($event->subject, $event->properties);
            $link = ['link' => GovernanceNotificationCatalog::link($event->subject, $event->properties)];

            $this->sendNotificationForAction(
                $action->id,
                null,
                $link,
                $payload,
                $roles,
                null,
                null,
                null,
                null
            );
            $this->scheduleDueDates($event, $link, $roles);
        } catch (\Throwable $exception) {
            Log::warning('Governance notification failed: ' . $exception->getMessage());
        }
    }

    protected function scheduleDueDates(GovernanceActionOccurred $event, array $link, array $roles): void
    {
        foreach (GovernanceNotificationCatalog::dueSchedules($event->subject, $event->action, $event->properties) as $due) {
            NotifyAtDateModel::where('model_id', $due['model_id'])->where('model_type', $due['model_type'])->delete();
            if (!empty($due['clear']) || empty($due['name']) || empty($due['date'])) {
                continue;
            }
            $dueAction = Action::where('name', $due['name'])->first();
            $dates = GovernanceNotificationCatalog::datesBeforeDue($due['name'], $due['date']);
            if (!$dueAction || !$dates) {
                continue;
            }
            $payload = GovernanceNotificationCatalog::payload($event->subject, $event->properties);
            $payload->setAttribute('due_date', $due['date']);
            $this->handleAutoNotifyBeforeDueDate(
                $dueAction->id,
                $link,
                $payload,
                $roles,
                $dates,
                $due['model_id'],
                $due['model_type'],
                'create'
            );
        }
    }
}
