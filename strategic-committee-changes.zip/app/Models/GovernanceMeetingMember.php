<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GovernanceMeetingMember extends Model
{
    protected $guarded = ['id'];

    public function meeting()
    {
        return $this->belongsTo(GovernanceMeeting::class, 'governance_meeting_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
