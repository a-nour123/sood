<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GovernanceStatusHistory extends Model
{
    protected $guarded = ['id'];

    public function request()
    {
        return $this->belongsTo(GovernanceRequest::class, 'governance_request_id');
    }

    public function actor()
    {
        return $this->belongsTo(User::class, 'actor_id');
    }
}
