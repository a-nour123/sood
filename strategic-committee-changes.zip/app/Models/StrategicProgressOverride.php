<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StrategicProgressOverride extends Model
{
    protected $fillable = [
        'subject_type', 'subject_id', 'previous_value', 'override_value', 'reason', 'user_id',
    ];

    public function subject()
    {
        return $this->morphTo();
    }
}
