<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GovernanceReview extends Model
{
    protected $guarded = ['id'];

    protected $casts = ['reviewed_at' => 'datetime'];

    public function request()
    {
        return $this->belongsTo(GovernanceRequest::class, 'governance_request_id');
    }

    public function committee()
    {
        return $this->belongsTo(GovernanceCommittee::class, 'committee_id');
    }

    public function member()
    {
        return $this->belongsTo(GovernanceCommitteeMember::class, 'committee_member_id');
    }

    public function reviewer()
    {
        return $this->belongsTo(User::class, 'reviewer_id');
    }

    public function comments()
    {
        return $this->hasMany(GovernanceReviewComment::class, 'governance_review_id');
    }

    public function attachments()
    {
        return $this->hasMany(GovernanceRequestAttachment::class, 'governance_review_id');
    }
}
