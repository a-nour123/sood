<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StrategicAttachment extends Model
{
    protected $fillable = [
        'attachable_type', 'attachable_id', 'original_name', 'path', 'mime', 'size', 'uploaded_by',
    ];

    public function attachable()
    {
        return $this->morphTo();
    }

    public function uploader()
    {
        return $this->belongsTo(User::class, 'uploaded_by');
    }
}
