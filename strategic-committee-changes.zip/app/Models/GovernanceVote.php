<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GovernanceVote extends Model
{
    protected $guarded = ['id'];

    protected $casts = [
        'voted_at' => 'datetime',
        'voting_weight' => 'float',
    ];

    public function session()
    {
        return $this->belongsTo(GovernanceVotingSession::class, 'voting_session_id');
    }

    public function request()
    {
        return $this->belongsTo(GovernanceRequest::class, 'governance_request_id');
    }

    public function member()
    {
        return $this->belongsTo(GovernanceCommitteeMember::class, 'committee_member_id');
    }

    public function voter()
    {
        return $this->belongsTo(User::class, 'voter_id');
    }

    public function history()
    {
        return $this->hasMany(GovernanceVoteHistory::class, 'governance_vote_id');
    }
}
