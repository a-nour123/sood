<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GovernanceExceptionDetail extends Model
{
    protected $guarded = ['id'];

    protected $casts = [
        'requested_start' => 'date',
        'requested_expiration' => 'date',
        'review_date' => 'date',
        'approval_date' => 'date',
        'expiration_date' => 'date',
        'expiration_notice_sent_at' => 'datetime',
        'expired_notice_sent_at' => 'datetime',
    ];

    public function request()
    {
        return $this->belongsTo(GovernanceRequest::class, 'governance_request_id');
    }

    public function framework()
    {
        return $this->belongsTo(Framework::class);
    }

    public function family()
    {
        return $this->belongsTo(Family::class);
    }

    public function control()
    {
        return $this->belongsTo(FrameworkControl::class, 'control_id');
    }

    public function policy()
    {
        return $this->belongsTo(Document::class, 'policy_document_id');
    }

    public function complianceException()
    {
        return $this->belongsTo(Exception::class, 'existing_exception_id');
    }

    public function owner()
    {
        return $this->belongsTo(User::class, 'owner_id');
    }

    public function approvingCommittee()
    {
        return $this->belongsTo(GovernanceCommittee::class, 'approving_committee_id');
    }

    public function finalApprover()
    {
        return $this->belongsTo(User::class, 'final_approver_id');
    }
}
