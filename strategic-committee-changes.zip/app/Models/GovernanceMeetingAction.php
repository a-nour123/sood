<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GovernanceMeetingAction extends Model
{
    protected $guarded = ['id'];

    public function meeting()
    {
        return $this->belongsTo(GovernanceMeeting::class, 'governance_meeting_id');
    }

    public function request()
    {
        return $this->belongsTo(GovernanceRequest::class, 'governance_request_id');
    }

    public function task()
    {
        return $this->belongsTo(Task::class);
    }
}
