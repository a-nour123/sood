<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GovernanceRiskAcceptanceDetail extends Model
{
    protected $guarded = ['id'];

    protected $casts = [
        'proposed_expiration' => 'date',
        'risk_snapshot' => 'array',
    ];

    public function request()
    {
        return $this->belongsTo(GovernanceRequest::class, 'governance_request_id');
    }

    public function risk()
    {
        return $this->belongsTo(Risk::class);
    }
}
