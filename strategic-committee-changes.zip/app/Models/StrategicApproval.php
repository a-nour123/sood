<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StrategicApproval extends Model
{
    protected $fillable = [
        'strategic_plan_id', 'version_number', 'action', 'from_status', 'to_status', 'comment', 'actor_id',
    ];

    public function plan()
    {
        return $this->belongsTo(StrategicPlan::class, 'strategic_plan_id');
    }

    public function actor()
    {
        return $this->belongsTo(User::class, 'actor_id');
    }
}
