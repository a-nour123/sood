<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class StrategicKpi extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'name', 'code', 'description', 'measurement_type', 'measurement_unit', 'baseline_value',
        'target_value', 'current_value', 'achievement', 'frequency', 'direction',
        'on_track_threshold', 'at_risk_threshold', 'owner_id', 'department_id', 'start_date',
        'target_date', 'status', 'created_by', 'updated_by',
    ];

    protected $casts = [
        'baseline_value' => 'float',
        'target_value' => 'float',
        'current_value' => 'float',
        'achievement' => 'float',
        'on_track_threshold' => 'float',
        'at_risk_threshold' => 'float',
        'start_date' => 'date',
        'target_date' => 'date',
    ];

    public function owner()
    {
        return $this->belongsTo(User::class, 'owner_id');
    }

    public function department()
    {
        return $this->belongsTo(Department::class);
    }

    public function objectives()
    {
        return $this->belongsToMany(StrategicObjective::class, 'strategic_objective_kpi')
            ->withPivot('weight')
            ->withTimestamps();
    }

    public function measurements()
    {
        return $this->hasMany(StrategicKpiMeasurement::class)->orderByDesc('measurement_date')->orderByDesc('id');
    }
}
