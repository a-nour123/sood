<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StrategicObjectiveRisk extends Model
{
    protected $fillable = [
        'strategic_objective_id', 'risk_id', 'risk_snapshot', 'score_at_link', 'notes',
        'linked_by', 'unlinked_at', 'unlinked_by',
    ];

    protected $casts = [
        'score_at_link' => 'float',
        'unlinked_at' => 'datetime',
    ];

    public function objective()
    {
        return $this->belongsTo(StrategicObjective::class, 'strategic_objective_id');
    }

    public function risk()
    {
        return $this->belongsTo(Risk::class);
    }

    public function linker()
    {
        return $this->belongsTo(User::class, 'linked_by');
    }
}
