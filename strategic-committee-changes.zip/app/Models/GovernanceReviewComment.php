<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GovernanceReviewComment extends Model
{
    protected $guarded = ['id'];

    public function review()
    {
        return $this->belongsTo(GovernanceReview::class, 'governance_review_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
