<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class GovernanceRequest extends Model
{
    use SoftDeletes;

    protected $guarded = ['id'];

    protected $casts = [
        'submission_date' => 'date',
        'due_date' => 'date',
        'decided_at' => 'datetime',
        'review_overdue_notified_at' => 'datetime',
    ];

    public function category()
    {
        return $this->belongsTo(GovernanceRequestCategory::class, 'category_id');
    }

    public function requester()
    {
        return $this->belongsTo(User::class, 'requester_id');
    }

    public function department()
    {
        return $this->belongsTo(Department::class);
    }

    public function committee()
    {
        return $this->belongsTo(GovernanceCommittee::class, 'assigned_committee_id');
    }

    public function approvalDetail()
    {
        return $this->hasOne(GovernanceApprovalDetail::class, 'governance_request_id');
    }

    public function exceptionDetail()
    {
        return $this->hasOne(GovernanceExceptionDetail::class, 'governance_request_id');
    }

    public function riskAcceptanceDetail()
    {
        return $this->hasOne(GovernanceRiskAcceptanceDetail::class, 'governance_request_id');
    }

    public function reviews()
    {
        return $this->hasMany(GovernanceReview::class, 'governance_request_id');
    }

    public function votingSessions()
    {
        return $this->hasMany(GovernanceVotingSession::class, 'governance_request_id');
    }

    public function decisions()
    {
        return $this->hasMany(GovernanceDecision::class, 'governance_request_id');
    }

    public function currentDecision()
    {
        return $this->hasOne(GovernanceDecision::class, 'governance_request_id')->where('is_current', true);
    }

    public function attachments()
    {
        return $this->hasMany(GovernanceRequestAttachment::class, 'governance_request_id');
    }

    public function activityLogs()
    {
        return $this->hasMany(GovernanceActivityLog::class, 'governance_request_id');
    }

    public function statusHistories()
    {
        return $this->hasMany(GovernanceStatusHistory::class, 'governance_request_id');
    }

    public function assignments()
    {
        return $this->hasMany(GovernanceRequestAssignment::class, 'governance_request_id');
    }

    public function decider()
    {
        return $this->belongsTo(User::class, 'decided_by');
    }
}
