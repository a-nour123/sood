<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StrategicComplianceLink extends Model
{
    protected $fillable = [
        'linkable_type', 'linkable_id', 'framework_id', 'family_id', 'framework_control_id',
        'framework_control_test_id', 'framework_control_test_audit_id', 'framework_snapshot',
        'gap_note', 'created_by',
    ];

    public function linkable()
    {
        return $this->morphTo();
    }

    public function framework()
    {
        return $this->belongsTo(Framework::class);
    }

    public function family()
    {
        return $this->belongsTo(Family::class);
    }

    public function control()
    {
        return $this->belongsTo(FrameworkControl::class, 'framework_control_id');
    }

    public function test()
    {
        return $this->belongsTo(FrameworkControlTest::class, 'framework_control_test_id');
    }

    public function audit()
    {
        return $this->belongsTo(FrameworkControlTestAudit::class, 'framework_control_test_audit_id');
    }
}
