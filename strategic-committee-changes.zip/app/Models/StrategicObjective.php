<?php

namespace App\Models;

use App\Services\Strategic\ProgressCalculator;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class StrategicObjective extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'strategic_goal_id', 'name', 'code', 'description', 'owner_id', 'department_id',
        'priority', 'weight', 'start_date', 'due_date', 'target_value', 'measurement_unit',
        'status', 'progress_basis', 'sort_order', 'calculated_progress', 'kpi_achievement',
        'progress_mode', 'manual_progress', 'created_by', 'updated_by',
    ];

    protected $attributes = [
        'progress_mode' => 'calculated',
        'progress_basis' => 'initiatives',
        'calculated_progress' => 0,
    ];

    protected $casts = [
        'start_date' => 'date',
        'due_date' => 'date',
        'weight' => 'float',
        'target_value' => 'float',
        'calculated_progress' => 'float',
        'kpi_achievement' => 'float',
        'manual_progress' => 'float',
    ];

    public function goal()
    {
        return $this->belongsTo(StrategicGoal::class, 'strategic_goal_id');
    }

    public function owner()
    {
        return $this->belongsTo(User::class, 'owner_id');
    }

    public function department()
    {
        return $this->belongsTo(Department::class);
    }

    public function initiatives()
    {
        return $this->hasMany(StrategicInitiative::class)->orderBy('id');
    }

    public function kpis()
    {
        return $this->belongsToMany(StrategicKpi::class, 'strategic_objective_kpi')
            ->withPivot('weight')
            ->withTimestamps();
    }

    public function risks()
    {
        return $this->belongsToMany(Risk::class, 'strategic_objective_risks', 'strategic_objective_id', 'risk_id')
            ->withPivot(['id', 'notes', 'linked_by', 'unlinked_at', 'risk_snapshot', 'score_at_link'])
            ->wherePivotNull('unlinked_at')
            ->withTimestamps();
    }

    public function riskAssociations()
    {
        return $this->hasMany(StrategicObjectiveRisk::class);
    }

    public function complianceLinks()
    {
        return $this->morphMany(StrategicComplianceLink::class, 'linkable');
    }

    public function progressHistories()
    {
        return $this->morphMany(StrategicProgressHistory::class, 'subject')->orderByDesc('id');
    }

    public function displayedProgress(): float
    {
        return ProgressCalculator::displayed($this->progress_mode, $this->manual_progress, (float) $this->calculated_progress);
    }

    public function isDelayed(): bool
    {
        return $this->due_date
            && $this->due_date->lt(now()->startOfDay())
            && !in_array($this->status, ['completed', 'cancelled'], true)
            && $this->displayedProgress() < 100;
    }
}
