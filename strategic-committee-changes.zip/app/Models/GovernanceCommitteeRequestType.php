<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GovernanceCommitteeRequestType extends Model
{
    protected $guarded = ['id'];

    public function committee()
    {
        return $this->belongsTo(GovernanceCommittee::class, 'committee_id');
    }
}
