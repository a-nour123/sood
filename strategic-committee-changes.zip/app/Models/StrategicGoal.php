<?php

namespace App\Models;

use App\Services\Strategic\ProgressCalculator;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class StrategicGoal extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'strategic_plan_id', 'name', 'code', 'description', 'perspective', 'owner_id',
        'department_id', 'priority', 'weight', 'start_date', 'due_date', 'status', 'sort_order',
        'calculated_progress', 'progress_mode', 'manual_progress', 'created_by', 'updated_by',
    ];

    protected $attributes = [
        'progress_mode' => 'calculated',
        'calculated_progress' => 0,
    ];

    protected $casts = [
        'start_date' => 'date',
        'due_date' => 'date',
        'weight' => 'float',
        'calculated_progress' => 'float',
        'manual_progress' => 'float',
    ];

    public function plan()
    {
        return $this->belongsTo(StrategicPlan::class, 'strategic_plan_id');
    }

    public function owner()
    {
        return $this->belongsTo(User::class, 'owner_id');
    }

    public function department()
    {
        return $this->belongsTo(Department::class);
    }

    public function objectives()
    {
        return $this->hasMany(StrategicObjective::class)->orderBy('sort_order')->orderBy('id');
    }

    public function displayedProgress(): float
    {
        return ProgressCalculator::displayed($this->progress_mode, $this->manual_progress, (float) $this->calculated_progress);
    }
}
