<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GovernanceApprovalDetail extends Model
{
    protected $guarded = ['id'];

    protected $casts = ['requested_effective_date' => 'date'];

    public function request()
    {
        return $this->belongsTo(GovernanceRequest::class, 'governance_request_id');
    }

    public function document()
    {
        return $this->belongsTo(Document::class, 'document_id');
    }
}
