<?php

namespace App\Models;

use App\Services\Strategic\ProgressCalculator;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class StrategicInitiative extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'strategic_objective_id', 'name', 'code', 'description', 'owner_id', 'department_id',
        'priority', 'weight', 'estimated_budget', 'actual_budget', 'start_date', 'due_date',
        'actual_end_date', 'progress_percentage', 'status', 'expected_outcomes', 'progress_mode',
        'manual_progress', 'created_by', 'updated_by',
    ];

    protected $attributes = [
        'progress_mode' => 'calculated',
        'progress_percentage' => 0,
    ];

    protected $casts = [
        'start_date' => 'date',
        'due_date' => 'date',
        'actual_end_date' => 'date',
        'weight' => 'float',
        'estimated_budget' => 'float',
        'actual_budget' => 'float',
        'progress_percentage' => 'float',
        'manual_progress' => 'float',
    ];

    public function objective()
    {
        return $this->belongsTo(StrategicObjective::class, 'strategic_objective_id');
    }

    public function owner()
    {
        return $this->belongsTo(User::class, 'owner_id');
    }

    public function department()
    {
        return $this->belongsTo(Department::class);
    }

    public function milestones()
    {
        return $this->hasMany(StrategicMilestone::class)->orderBy('sort_order')->orderBy('id');
    }

    public function taskLinks()
    {
        return $this->hasMany(StrategicTaskLink::class);
    }

    public function complianceLinks()
    {
        return $this->morphMany(StrategicComplianceLink::class, 'linkable');
    }

    public function activity()
    {
        return $this->morphMany(StrategicActivityLog::class, 'subject');
    }

    public function displayedProgress(): float
    {
        return ProgressCalculator::displayed($this->progress_mode, $this->manual_progress, (float) $this->progress_percentage);
    }

    public function isDelayed(): bool
    {
        return $this->due_date
            && $this->due_date->lt(now()->startOfDay())
            && !in_array($this->status, ['completed', 'cancelled'], true)
            && $this->displayedProgress() < 100;
    }
}
