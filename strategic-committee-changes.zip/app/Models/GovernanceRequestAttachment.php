<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GovernanceRequestAttachment extends Model
{
    protected $guarded = ['id'];

    public function request()
    {
        return $this->belongsTo(GovernanceRequest::class, 'governance_request_id');
    }

    public function review()
    {
        return $this->belongsTo(GovernanceReview::class, 'governance_review_id');
    }

    public function meeting()
    {
        return $this->belongsTo(GovernanceMeeting::class, 'governance_meeting_id');
    }

    public function uploader()
    {
        return $this->belongsTo(User::class, 'uploaded_by');
    }
}
