<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GovernanceDecision extends Model
{
    protected $guarded = ['id'];

    protected $casts = [
        'decided_at' => 'datetime',
        'effective_from' => 'date',
        'effective_until' => 'date',
        'is_current' => 'boolean',
    ];

    public function request()
    {
        return $this->belongsTo(GovernanceRequest::class, 'governance_request_id');
    }

    public function committee()
    {
        return $this->belongsTo(GovernanceCommittee::class, 'committee_id');
    }

    public function decider()
    {
        return $this->belongsTo(User::class, 'decided_by');
    }

    public function correctedDecision()
    {
        return $this->belongsTo(self::class, 'corrects_decision_id');
    }
}
