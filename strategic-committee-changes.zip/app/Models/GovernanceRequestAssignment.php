<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GovernanceRequestAssignment extends Model
{
    protected $guarded = ['id'];

    protected $casts = ['assigned_at' => 'datetime'];

    public function request()
    {
        return $this->belongsTo(GovernanceRequest::class, 'governance_request_id');
    }

    public function fromCommittee()
    {
        return $this->belongsTo(GovernanceCommittee::class, 'from_committee_id');
    }

    public function toCommittee()
    {
        return $this->belongsTo(GovernanceCommittee::class, 'to_committee_id');
    }

    public function assigner()
    {
        return $this->belongsTo(User::class, 'assigned_by');
    }
}
