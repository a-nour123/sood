<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GovernanceMeetingMinute extends Model
{
    protected $guarded = ['id'];

    public function meeting()
    {
        return $this->belongsTo(GovernanceMeeting::class, 'governance_meeting_id');
    }

    public function recorder()
    {
        return $this->belongsTo(User::class, 'recorded_by');
    }
}
