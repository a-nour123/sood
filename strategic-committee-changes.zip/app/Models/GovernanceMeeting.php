<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class GovernanceMeeting extends Model
{
    use SoftDeletes;

    protected $guarded = ['id'];

    protected $casts = [
        'meeting_date' => 'date',
        'reminder_sent_at' => 'datetime',
    ];

    public function committee()
    {
        return $this->belongsTo(GovernanceCommittee::class, 'committee_id');
    }

    public function chairman()
    {
        return $this->belongsTo(User::class, 'chairman_id');
    }

    public function secretary()
    {
        return $this->belongsTo(User::class, 'secretary_id');
    }

    public function attendees()
    {
        return $this->hasMany(GovernanceMeetingMember::class, 'governance_meeting_id');
    }

    public function agendas()
    {
        return $this->hasMany(GovernanceMeetingAgenda::class, 'governance_meeting_id');
    }

    public function minutes()
    {
        return $this->hasOne(GovernanceMeetingMinute::class, 'governance_meeting_id');
    }

    public function actions()
    {
        return $this->hasMany(GovernanceMeetingAction::class, 'governance_meeting_id');
    }

    public function attachments()
    {
        return $this->hasMany(GovernanceRequestAttachment::class, 'governance_meeting_id');
    }
}
