<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class StrategicPlan extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'name', 'code', 'description', 'vision', 'mission', 'strategic_priorities',
        'department_id', 'owner_id', 'start_date', 'end_date', 'status', 'version_number',
        'approved_by', 'approved_at', 'calculated_progress', 'progress_mode', 'manual_progress',
        'created_by', 'updated_by',
    ];

    protected $attributes = [
        'progress_mode' => 'calculated',
        'calculated_progress' => 0,
        'status' => 'draft',
        'version_number' => 1,
    ];

    protected $casts = [
        'start_date' => 'date',
        'end_date' => 'date',
        'approved_at' => 'datetime',
        'calculated_progress' => 'float',
        'manual_progress' => 'float',
    ];

    public function department()
    {
        return $this->belongsTo(Department::class);
    }

    public function owner()
    {
        return $this->belongsTo(User::class, 'owner_id');
    }

    public function approver()
    {
        return $this->belongsTo(User::class, 'approved_by');
    }

    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function goals()
    {
        return $this->hasMany(StrategicGoal::class)->orderBy('sort_order')->orderBy('id');
    }

    public function versions()
    {
        return $this->hasMany(StrategicPlanVersion::class)->orderByDesc('version_number');
    }

    public function approvals()
    {
        return $this->hasMany(StrategicApproval::class)->orderByDesc('id');
    }

    public function attachments()
    {
        return $this->morphMany(StrategicAttachment::class, 'attachable');
    }

    public function activity()
    {
        return $this->morphMany(StrategicActivityLog::class, 'subject');
    }

    public function displayedProgress(): float
    {
        return \App\Services\Strategic\ProgressCalculator::displayed(
            $this->progress_mode,
            $this->manual_progress,
            (float) $this->calculated_progress
        );
    }
}
