<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StrategicActivityLog extends Model
{
    protected $fillable = [
        'subject_type', 'subject_id', 'action', 'description', 'properties', 'user_id',
    ];

    public function subject()
    {
        return $this->morphTo();
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
