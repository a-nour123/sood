<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GovernanceCommitteeType extends Model
{
    protected $guarded = ['id'];

    protected $casts = ['is_active' => 'boolean'];

    public function committees()
    {
        return $this->hasMany(GovernanceCommittee::class, 'committee_type_id');
    }
}
