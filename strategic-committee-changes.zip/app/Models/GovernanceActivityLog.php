<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GovernanceActivityLog extends Model
{
    protected $guarded = ['id'];

    protected $casts = ['meta' => 'array'];

    public function request()
    {
        return $this->belongsTo(GovernanceRequest::class, 'governance_request_id');
    }

    public function committee()
    {
        return $this->belongsTo(GovernanceCommittee::class, 'committee_id');
    }

    public function actor()
    {
        return $this->belongsTo(User::class, 'actor_id');
    }
}
