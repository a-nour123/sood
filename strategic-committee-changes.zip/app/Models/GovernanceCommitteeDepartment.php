<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GovernanceCommitteeDepartment extends Model
{
    protected $guarded = ['id'];

    protected $casts = [
        'assigned_at' => 'datetime',
        'removed_at' => 'datetime',
    ];

    public function committee()
    {
        return $this->belongsTo(GovernanceCommittee::class, 'committee_id');
    }

    public function department()
    {
        return $this->belongsTo(Department::class);
    }
}
