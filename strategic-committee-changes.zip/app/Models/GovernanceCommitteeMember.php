<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class GovernanceCommitteeMember extends Model
{
    use SoftDeletes;

    protected $guarded = ['id'];

    protected $casts = [
        'voting_right' => 'boolean',
        'can_recommend' => 'boolean',
        'can_approve' => 'boolean',
        'can_review' => 'boolean',
        'effective_from' => 'date',
        'effective_until' => 'date',
        'voting_weight' => 'float',
    ];

    public function committee()
    {
        return $this->belongsTo(GovernanceCommittee::class, 'committee_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function department()
    {
        return $this->belongsTo(Department::class);
    }

    public function reviews()
    {
        return $this->hasMany(GovernanceReview::class, 'committee_member_id');
    }

    public function votes()
    {
        return $this->hasMany(GovernanceVote::class, 'committee_member_id');
    }

    public function policyArray(): array
    {
        return [
            'id' => $this->id,
            'user_id' => $this->user_id,
            'status' => $this->status,
            'member_role' => $this->member_role,
            'voting_right' => $this->voting_right,
            'can_recommend' => $this->can_recommend,
            'can_approve' => $this->can_approve,
            'can_review' => $this->can_review,
            'effective_from' => optional($this->effective_from)->toDateString(),
            'effective_until' => optional($this->effective_until)->toDateString(),
            'voting_weight' => $this->voting_weight,
        ];
    }
}
