<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StrategicKriMeasurement extends Model
{
    protected $fillable = [
        'strategic_kri_id', 'actual_value', 'measurement_date', 'submitted_by', 'comments', 'breach_level',
    ];

    protected $casts = [
        'actual_value' => 'float',
        'measurement_date' => 'date',
    ];

    public function kri()
    {
        return $this->belongsTo(StrategicKri::class, 'strategic_kri_id');
    }

    public function submitter()
    {
        return $this->belongsTo(User::class, 'submitted_by');
    }
}
