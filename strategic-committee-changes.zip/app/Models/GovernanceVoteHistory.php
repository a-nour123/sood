<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GovernanceVoteHistory extends Model
{
    protected $guarded = ['id'];

    public function vote()
    {
        return $this->belongsTo(GovernanceVote::class, 'governance_vote_id');
    }
}
