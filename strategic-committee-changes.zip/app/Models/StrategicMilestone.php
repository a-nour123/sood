<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class StrategicMilestone extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'strategic_initiative_id', 'name', 'description', 'owner_id', 'planned_start_date',
        'planned_due_date', 'actual_completion_date', 'weight', 'completion_percentage', 'status',
        'sort_order', 'created_by', 'updated_by',
    ];

    protected $casts = [
        'planned_start_date' => 'date',
        'planned_due_date' => 'date',
        'actual_completion_date' => 'date',
        'weight' => 'float',
        'completion_percentage' => 'float',
    ];

    public function initiative()
    {
        return $this->belongsTo(StrategicInitiative::class, 'strategic_initiative_id');
    }

    public function owner()
    {
        return $this->belongsTo(User::class, 'owner_id');
    }

    public function taskLinks()
    {
        return $this->hasMany(StrategicTaskLink::class);
    }

    public function attachments()
    {
        return $this->morphMany(StrategicAttachment::class, 'attachable');
    }

    public function isOverdue(): bool
    {
        return $this->planned_due_date
            && $this->planned_due_date->lt(now()->startOfDay())
            && (float) $this->completion_percentage < 100
            && $this->status !== 'completed';
    }
}
