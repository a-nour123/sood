<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class StrategicKri extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'name', 'description', 'measurement_unit', 'current_value', 'warning_threshold',
        'critical_threshold', 'measurement_frequency', 'direction', 'owner_id', 'department_id',
        'risk_id', 'risk_snapshot', 'status', 'created_by', 'updated_by',
    ];

    protected $casts = [
        'current_value' => 'float',
        'warning_threshold' => 'float',
        'critical_threshold' => 'float',
    ];

    public function owner()
    {
        return $this->belongsTo(User::class, 'owner_id');
    }

    public function department()
    {
        return $this->belongsTo(Department::class);
    }

    public function risk()
    {
        return $this->belongsTo(Risk::class);
    }

    public function measurements()
    {
        return $this->hasMany(StrategicKriMeasurement::class)->orderByDesc('measurement_date')->orderByDesc('id');
    }
}
