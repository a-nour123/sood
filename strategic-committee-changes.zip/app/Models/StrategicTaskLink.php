<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StrategicTaskLink extends Model
{
    protected $fillable = [
        'task_id', 'strategic_initiative_id', 'strategic_milestone_id', 'task_snapshot', 'created_by',
    ];

    public function task()
    {
        return $this->belongsTo(Task::class);
    }

    public function initiative()
    {
        return $this->belongsTo(StrategicInitiative::class, 'strategic_initiative_id');
    }

    public function milestone()
    {
        return $this->belongsTo(StrategicMilestone::class, 'strategic_milestone_id');
    }
}
