<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StrategicPlanVersion extends Model
{
    protected $fillable = [
        'strategic_plan_id', 'version_number', 'snapshot', 'reason', 'created_by',
    ];

    public function plan()
    {
        return $this->belongsTo(StrategicPlan::class, 'strategic_plan_id');
    }

    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}
