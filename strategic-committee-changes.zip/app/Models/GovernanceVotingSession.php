<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GovernanceVotingSession extends Model
{
    protected $guarded = ['id'];

    protected $casts = [
        'opened_at' => 'datetime',
        'closed_at' => 'datetime',
        'deadline' => 'date',
        'tally' => 'array',
    ];

    public function request()
    {
        return $this->belongsTo(GovernanceRequest::class, 'governance_request_id');
    }

    public function committee()
    {
        return $this->belongsTo(GovernanceCommittee::class, 'committee_id');
    }

    public function votes()
    {
        return $this->hasMany(GovernanceVote::class, 'voting_session_id');
    }

    public function opener()
    {
        return $this->belongsTo(User::class, 'opened_by');
    }
}
