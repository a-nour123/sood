<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GovernanceAssignmentRule extends Model
{
    protected $guarded = ['id'];

    protected $casts = ['is_active' => 'boolean'];

    public function committee()
    {
        return $this->belongsTo(GovernanceCommittee::class, 'committee_id');
    }

    public function category()
    {
        return $this->belongsTo(GovernanceRequestCategory::class, 'category_id');
    }

    public function department()
    {
        return $this->belongsTo(Department::class);
    }
}
