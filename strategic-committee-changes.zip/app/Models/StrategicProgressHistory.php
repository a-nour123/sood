<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StrategicProgressHistory extends Model
{
    protected $fillable = [
        'subject_type', 'subject_id', 'progress', 'source', 'user_id',
    ];

    public function subject()
    {
        return $this->morphTo();
    }
}
