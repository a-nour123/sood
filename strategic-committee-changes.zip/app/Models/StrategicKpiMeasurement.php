<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StrategicKpiMeasurement extends Model
{
    protected $fillable = [
        'strategic_kpi_id', 'actual_value', 'measurement_date', 'reporting_period', 'submitted_by',
        'evidence', 'comments', 'approval_status', 'approved_by', 'approved_at', 'achievement',
    ];

    protected $casts = [
        'actual_value' => 'float',
        'achievement' => 'float',
        'measurement_date' => 'date',
        'approved_at' => 'datetime',
    ];

    public function kpi()
    {
        return $this->belongsTo(StrategicKpi::class, 'strategic_kpi_id');
    }

    public function submitter()
    {
        return $this->belongsTo(User::class, 'submitted_by');
    }

    public function approver()
    {
        return $this->belongsTo(User::class, 'approved_by');
    }
}
