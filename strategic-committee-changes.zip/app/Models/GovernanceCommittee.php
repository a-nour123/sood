<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class GovernanceCommittee extends Model
{
    use SoftDeletes;

    protected $guarded = ['id'];

    protected $casts = [
        'effective_from' => 'date',
        'effective_until' => 'date',
        'allow_vote_change' => 'boolean',
        'voting_threshold' => 'float',
    ];

    public function type()
    {
        return $this->belongsTo(GovernanceCommitteeType::class, 'committee_type_id');
    }

    public function chairman()
    {
        return $this->belongsTo(User::class, 'chairman_id');
    }

    public function secretary()
    {
        return $this->belongsTo(User::class, 'secretary_id');
    }

    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function departments()
    {
        return $this->belongsToMany(Department::class, 'governance_committee_departments', 'committee_id', 'department_id')
            ->withPivot(['id', 'assigned_by', 'assigned_at', 'removed_at'])
            ->wherePivotNull('removed_at');
    }

    public function departmentLinks()
    {
        return $this->hasMany(GovernanceCommitteeDepartment::class, 'committee_id');
    }

    public function members()
    {
        return $this->hasMany(GovernanceCommitteeMember::class, 'committee_id');
    }

    public function users()
    {
        return $this->belongsToMany(User::class, 'governance_committee_members', 'committee_id', 'user_id')
            ->withPivot(['member_role', 'status', 'voting_right', 'can_approve']);
    }

    public function requestTypes()
    {
        return $this->hasMany(GovernanceCommitteeRequestType::class, 'committee_id');
    }

    public function requests()
    {
        return $this->hasMany(GovernanceRequest::class, 'assigned_committee_id');
    }

    public function meetings()
    {
        return $this->hasMany(GovernanceMeeting::class, 'committee_id');
    }

    public function decisions()
    {
        return $this->hasMany(GovernanceDecision::class, 'committee_id');
    }

    public function assignmentRules()
    {
        return $this->hasMany(GovernanceAssignmentRule::class, 'committee_id');
    }

    public function isActiveOn($date = null): bool
    {
        $date = $date ?: date('Y-m-d');
        if ($this->status !== 'active') {
            return false;
        }
        if ($this->effective_from && $this->effective_from->toDateString() > $date) {
            return false;
        }
        if ($this->effective_until && $this->effective_until->toDateString() < $date) {
            return false;
        }

        return true;
    }
}
