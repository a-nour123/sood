<?php

namespace App\Http\Controllers\admin\committee;

use App\Models\GovernanceRequest;
use App\Models\GovernanceVotingSession;
use App\Services\Governance\GovernanceAccess;
use App\Services\Governance\GovernanceVotingService;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class VotingController extends GovernanceController
{
    public function index()
    {
        $breadcrumbs = $this->crumbs([['name' => __('locale.VotingRecommendations')]]);
        $sessions = GovernanceVotingSession::with(['request', 'committee'])
            ->where('status', 'open')
            ->whereIn('governance_request_id', GovernanceAccess::scopeRequests(GovernanceRequest::query(), auth()->user())->select('id'))
            ->orderByDesc('id')
            ->limit(200)
            ->get();

        return view('admin.content.committee.voting.index', compact('breadcrumbs', 'sessions'));
    }

    public function cast(Request $request, $id)
    {
        $row = GovernanceRequest::findOrFail($id);
        $this->authorizeRecord($row);
        if ($failed = $this->validateJson($request, [
            'vote' => ['required', Rule::in(['approve', 'reject', 'abstain'])],
            'comments' => ['nullable', 'string'],
        ])) {
            return $failed;
        }

        return $this->result(GovernanceVotingService::cast(auth()->user(), $row, $request->all()));
    }

    public function close($id)
    {
        $row = GovernanceRequest::findOrFail($id);
        $this->authorizeRecord($row);

        return $this->result(GovernanceVotingService::close(auth()->user(), $row));
    }
}
