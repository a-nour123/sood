<?php

namespace App\Http\Controllers\admin\committee;

use App\Models\GovernanceCommittee;
use App\Models\GovernanceMeeting;
use App\Models\GovernanceMeetingMember;
use App\Models\GovernanceRequest;
use App\Services\Governance\GovernanceAccess;
use App\Services\Governance\GovernanceListResponder;
use App\Services\Governance\GovernanceLogger;
use App\Services\Governance\GovernanceMeetingService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;

class MeetingController extends GovernanceController
{
    public function index()
    {
        $options = $this->options();
        $breadcrumbs = $this->crumbs([['name' => __('locale.CommitteeMeetings')]]);

        return view('admin.content.committee.meetings.index', compact('options', 'breadcrumbs'));
    }

    public function show($id)
    {
        $meeting = GovernanceMeeting::with(['committee', 'chairman', 'secretary', 'attendees.user', 'agendas.request', 'minutes.recorder', 'actions.task', 'attachments'])->findOrFail($id);
        if (!GovernanceAccess::canViewCommittee(auth()->user(), $meeting->committee)) {
            abort(response()->json(['status' => false, 'message' => __('locale.YouDonotHavePermissionToDoThat')], 403));
        }
        $options = $this->options();
        $requests = GovernanceAccess::scopeRequests(GovernanceRequest::query(), auth()->user())->where('assigned_committee_id', $meeting->committee_id)->orderByDesc('id')->limit(200)->get();
        $breadcrumbs = $this->crumbs([
            ['link' => route('admin.committee.meetings.index'), 'name' => __('locale.CommitteeMeetings')],
            ['name' => $meeting->title],
        ]);

        $assigned = GovernanceAccess::assignedToMeeting(auth()->user(), $meeting);
        $canManageMeeting = GovernanceAccess::allows(auth()->user(), 'manage_committee_meetings', $assigned);
        $canMinutes = GovernanceAccess::allows(auth()->user(), 'manage_meeting_minutes', $assigned);

        return view('admin.content.committee.meetings.show', compact('meeting', 'options', 'requests', 'breadcrumbs', 'canManageMeeting', 'canMinutes'));
    }

    public function ajaxList(Request $request)
    {
        $ids = GovernanceAccess::scopeCommittees(GovernanceCommittee::query(), auth()->user())->pluck('id');
        $query = GovernanceMeeting::with('committee')->whereIn('committee_id', $ids);

        return GovernanceListResponder::respond($query, $request, ['title', 'meeting_number'], ['id', 'meeting_number', 'title', 'meeting_date', 'status'], function (GovernanceMeeting $meeting) {
            return [
                'id' => $meeting->id,
                'meeting_number' => $meeting->meeting_number,
                'title' => $meeting->title,
                'committee' => optional($meeting->committee)->name,
                'meeting_date' => optional($meeting->meeting_date)->toDateString(),
                'type' => __('governance.meeting_types.' . $meeting->meeting_type),
                'status' => __('governance.meeting_statuses.' . $meeting->status),
                'Actions' => ['id' => $meeting->id, 'assigned' => GovernanceAccess::assignedToMeeting(auth()->user(), $meeting)],
            ];
        });
    }

    public function store(Request $request)
    {
        if ($failed = $this->validateJson($request, $this->rules())) {
            return $failed;
        }

        return $this->result(GovernanceMeetingService::save(auth()->user(), $request->all()));
    }

    public function edit($id)
    {
        $meeting = GovernanceMeeting::findOrFail($id);
        if ($denied = $this->ensureAssigned(GovernanceAccess::assignedToMeeting(auth()->user(), $meeting))) {
            return $denied;
        }
        $data = $meeting->toArray();
        $data['meeting_date'] = optional($meeting->meeting_date)->toDateString();

        return $this->ok(__('governance.Loaded'), ['data' => $data]);
    }

    public function update(Request $request, $id)
    {
        $meeting = GovernanceMeeting::findOrFail($id);
        if ($denied = $this->ensureAssigned(GovernanceAccess::assignedToMeeting(auth()->user(), $meeting))) {
            return $denied;
        }
        if ($failed = $this->validateJson($request, $this->rules($meeting->id))) {
            return $failed;
        }

        return $this->result(GovernanceMeetingService::save(auth()->user(), $request->all(), $meeting));
    }

    public function destroy($id)
    {
        $meeting = GovernanceMeeting::findOrFail($id);
        if ($denied = $this->ensureAssigned(GovernanceAccess::assignedToMeeting(auth()->user(), $meeting))) {
            return $denied;
        }
        if ($meeting->actions()->exists() || $meeting->minutes()->exists()) {
            return $this->failMessage(__('governance.MeetingHasHistory'));
        }
        GovernanceLogger::log(null, 'meeting_deleted', $meeting->title, ['meeting_id' => $meeting->id], $meeting->committee_id, auth()->user());
        $meeting->delete();

        return $this->ok(__('governance.Deleted'));
    }

    public function attendees(Request $request, $id)
    {
        $meeting = GovernanceMeeting::findOrFail($id);
        if ($denied = $this->ensureAssigned(GovernanceAccess::assignedToMeeting(auth()->user(), $meeting))) {
            return $denied;
        }
        GovernanceMeetingService::attend($meeting, (array) $request->input('user_ids', []));

        return $this->ok(__('governance.Saved'));
    }

    public function attendance(Request $request, $id, $memberId)
    {
        $meeting = GovernanceMeeting::findOrFail($id);
        if ($denied = $this->ensureAssigned(GovernanceAccess::assignedToMeeting(auth()->user(), $meeting))) {
            return $denied;
        }
        $member = GovernanceMeetingMember::where('governance_meeting_id', $id)->findOrFail($memberId);

        return $this->result(GovernanceMeetingService::attendance($member, (string) $request->input('attendance')));
    }

    public function agenda(Request $request, $id)
    {
        $meeting = GovernanceMeeting::findOrFail($id);
        if ($denied = $this->ensureAssigned(GovernanceAccess::assignedToMeeting(auth()->user(), $meeting))) {
            return $denied;
        }
        if ($failed = $this->validateJson($request, ['title' => ['required', 'string', 'max:200']])) {
            return $failed;
        }

        return $this->result(GovernanceMeetingService::agenda($meeting, $request->all()));
    }

    public function minutes(Request $request, $id)
    {
        $meeting = GovernanceMeeting::findOrFail($id);
        if ($denied = $this->ensureAssigned(GovernanceAccess::assignedToMeeting(auth()->user(), $meeting))) {
            return $denied;
        }

        return $this->result(GovernanceMeetingService::minutes(auth()->user(), $meeting, $request->all()));
    }

    public function actionItem(Request $request, $id)
    {
        $meeting = GovernanceMeeting::findOrFail($id);
        if ($denied = $this->ensureAssigned(GovernanceAccess::assignedToMeeting(auth()->user(), $meeting))) {
            return $denied;
        }
        if ($failed = $this->validateJson($request, [
            'title' => ['required', 'string', 'max:200'],
            'assignee_id' => ['required', 'integer', 'exists:users,id'],
            'due_date' => ['nullable', 'date'],
        ])) {
            return $failed;
        }

        return $this->result(GovernanceMeetingService::actionItem(auth()->user(), $meeting, $request->all()));
    }

    public function upload(Request $request, $id)
    {
        $meeting = GovernanceMeeting::findOrFail($id);
        if ($denied = $this->ensureAssigned(GovernanceAccess::assignedToMeeting(auth()->user(), $meeting))) {
            return $denied;
        }
        if ($failed = $this->validateJson($request, ['file' => ['required', 'file', 'max:10240', 'mimes:pdf,doc,docx,xls,xlsx,png,jpg,jpeg,txt']])) {
            return $failed;
        }
        $file = $request->file('file');
        $path = $file->store('governance/meetings/' . $meeting->id, 'public');
        $meeting->attachments()->create([
            'governance_request_id' => $request->input('governance_request_id') ?: $meeting->agendas()->whereNotNull('governance_request_id')->value('governance_request_id'),
            'governance_meeting_id' => $meeting->id,
            'original_name' => $file->getClientOriginalName(),
            'path' => $path,
            'mime' => $file->getClientMimeType(),
            'size' => $file->getSize(),
            'uploaded_by' => auth()->id(),
        ]);
        GovernanceLogger::log(null, 'attachment_added', $meeting->title, ['meeting_id' => $meeting->id], $meeting->committee_id, auth()->user());

        return $this->ok(__('governance.Saved'));
    }

    protected function rules($id = null): array
    {
        return [
            'committee_id' => ['required', 'integer', 'exists:governance_committees,id'],
            'meeting_number' => ['required', 'string', 'max:40'],
            'title' => ['required', 'string', 'max:200'],
            'meeting_date' => ['required', 'date'],
            'meeting_type' => ['required', Rule::in(['regular', 'emergency', 'extraordinary', 'follow_up'])],
            'status' => ['nullable', Rule::in(['scheduled', 'held', 'cancelled'])],
        ];
    }

    protected function failMessage(string $message)
    {
        return response()->json(['status' => false, 'message' => $message], 422);
    }
}
