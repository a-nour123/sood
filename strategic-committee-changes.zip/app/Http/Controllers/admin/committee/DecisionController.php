<?php

namespace App\Http\Controllers\admin\committee;

use App\Models\GovernanceDecision;
use App\Models\GovernanceRequest;
use App\Services\Governance\GovernanceAccess;
use App\Services\Governance\GovernanceDecisionRules;
use App\Services\Governance\GovernanceDecisionService;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class DecisionController extends GovernanceController
{
    public function index()
    {
        $breadcrumbs = $this->crumbs([['name' => __('locale.ApprovalHistory')]]);
        $decisions = GovernanceDecision::with(['request', 'decider', 'committee'])
            ->whereIn('governance_request_id', GovernanceAccess::scopeRequests(GovernanceRequest::query(), auth()->user())->select('id'))
            ->orderByDesc('id')
            ->limit(300)
            ->get();

        return view('admin.content.committee.decisions.index', compact('breadcrumbs', 'decisions'));
    }

    public function store(Request $request, $id)
    {
        $row = GovernanceRequest::findOrFail($id);
        $this->authorizeRecord($row);
        if ($failed = $this->validateJson($request, $this->rules())) {
            return $failed;
        }

        return $this->result(GovernanceDecisionService::issue(auth()->user(), $row, $request->all()));
    }

    public function correct(Request $request, $id, $decisionId)
    {
        $row = GovernanceRequest::findOrFail($id);
        $this->authorizeRecord($row);
        $decision = GovernanceDecision::where('governance_request_id', $row->id)->findOrFail($decisionId);
        if ($failed = $this->validateJson($request, $this->rules())) {
            return $failed;
        }

        return $this->result(GovernanceDecisionService::correct(auth()->user(), $decision, $request->all()));
    }

    protected function rules(): array
    {
        return [
            'decision_type' => ['required', Rule::in(GovernanceDecisionRules::types())],
            'decision_reason' => ['nullable', 'string'],
            'decision_conditions' => ['nullable', 'string'],
            'effective_from' => ['nullable', 'date'],
            'effective_until' => ['nullable', 'date'],
            'risk_outcome' => ['nullable', Rule::in(GovernanceDecisionRules::riskOutcomes())],
        ];
    }
}
