<?php

namespace App\Http\Controllers\admin\committee;

use App\Models\GovernanceAssignmentRule;
use App\Models\GovernanceCommitteeType;
use App\Models\GovernanceRequestCategory;
use App\Services\Governance\GovernanceListResponder;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class SettingController extends GovernanceController
{
    public function types()
    {
        $breadcrumbs = $this->crumbs([['name' => __('locale.CommitteeTypes')]]);

        return view('admin.content.committee.settings.types', compact('breadcrumbs'));
    }

    public function typeList(Request $request)
    {
        return GovernanceListResponder::respond(GovernanceCommitteeType::query(), $request, ['name', 'code'], ['id', 'name', 'code'], function (GovernanceCommitteeType $type) {
            return [
                'id' => $type->id,
                'name' => $type->name,
                'code' => $type->code,
                'status' => $type->is_active ? __('governance.Active') : __('governance.Inactive'),
                'Actions' => ['id' => $type->id, 'assigned' => true],
            ];
        });
    }

    public function storeType(Request $request)
    {
        if ($failed = $this->validateJson($request, [
            'name' => ['required', 'string', 'max:150'],
            'code' => ['required', 'string', 'max:50', Rule::unique('governance_committee_types', 'code')->ignore($request->input('id') ?: null)],
        ])) {
            return $failed;
        }
        $type = $request->filled('id') ? GovernanceCommitteeType::findOrFail($request->id) : new GovernanceCommitteeType();
        $type->fill([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => $request->has('is_active') ? (bool) $request->is_active : true,
        ])->save();

        return $this->ok(__('governance.Saved'), ['id' => $type->id]);
    }

    public function editType($id)
    {
        $type = GovernanceCommitteeType::findOrFail($id);
        $data = $type->toArray();
        $data['is_active'] = $type->is_active ? 1 : 0;

        return $this->ok(__('governance.Loaded'), ['data' => $data]);
    }

    public function destroyType($id)
    {
        $type = GovernanceCommitteeType::findOrFail($id);
        if ($type->committees()->exists()) {
            $type->update(['is_active' => false]);
        } else {
            $type->delete();
        }

        return $this->ok(__('governance.Deleted'));
    }

    public function categories()
    {
        $breadcrumbs = $this->crumbs([['name' => __('locale.RequestCategories')]]);

        return view('admin.content.committee.settings.categories', compact('breadcrumbs'));
    }

    public function categoryList(Request $request)
    {
        return GovernanceListResponder::respond(GovernanceRequestCategory::query(), $request, ['name', 'code'], ['id', 'name', 'code', 'request_type'], function (GovernanceRequestCategory $category) {
            return [
                'id' => $category->id,
                'name' => $category->name,
                'code' => $category->code,
                'request_type' => __('governance.request_types.' . $category->request_type),
                'status' => $category->is_active ? __('governance.Active') : __('governance.Inactive'),
                'Actions' => ['id' => $category->id, 'assigned' => true],
            ];
        });
    }

    public function storeCategory(Request $request)
    {
        if ($failed = $this->validateJson($request, [
            'name' => ['required', 'string', 'max:150'],
            'code' => ['required', 'string', 'max:50'],
            'request_type' => ['required', Rule::in(['approval', 'exception', 'risk_acceptance'])],
        ])) {
            return $failed;
        }
        $category = $request->filled('id') ? GovernanceRequestCategory::findOrFail($request->id) : new GovernanceRequestCategory();
        $category->fill([
            'name' => $request->name,
            'code' => $request->code,
            'request_type' => $request->request_type,
            'is_active' => $request->has('is_active') ? (bool) $request->is_active : true,
        ])->save();

        return $this->ok(__('governance.Saved'));
    }

    public function editCategory($id)
    {
        return $this->ok(__('governance.Loaded'), ['data' => GovernanceRequestCategory::findOrFail($id)]);
    }

    public function destroyCategory($id)
    {
        GovernanceRequestCategory::findOrFail($id)->update(['is_active' => false]);

        return $this->ok(__('governance.Deleted'));
    }

    public function rulesPage()
    {
        $options = $this->options();
        $breadcrumbs = $this->crumbs([['name' => __('locale.AssignmentRules')]]);

        return view('admin.content.committee.settings.rules', compact('options', 'breadcrumbs'));
    }

    public function ruleList(Request $request)
    {
        $query = GovernanceAssignmentRule::with(['committee', 'category', 'department']);

        return GovernanceListResponder::respond($query, $request, [], ['id', 'priority'], function (GovernanceAssignmentRule $rule) {
            return [
                'id' => $rule->id,
                'request_type' => __('governance.request_types.' . $rule->request_type),
                'category' => optional($rule->category)->name,
                'department' => optional($rule->department)->name,
                'committee' => optional($rule->committee)->name,
                'priority' => $rule->priority,
                'status' => $rule->is_active ? __('governance.Active') : __('governance.Inactive'),
                'Actions' => ['id' => $rule->id, 'assigned' => true],
            ];
        });
    }

    public function storeRule(Request $request)
    {
        if ($failed = $this->validateJson($request, [
            'request_type' => ['required', Rule::in(['approval', 'exception', 'risk_acceptance'])],
            'committee_id' => ['required', 'integer', 'exists:governance_committees,id'],
            'priority' => ['nullable', 'integer', 'min:1'],
        ])) {
            return $failed;
        }
        $rule = $request->filled('id') ? GovernanceAssignmentRule::findOrFail($request->id) : new GovernanceAssignmentRule();
        $rule->fill([
            'request_type' => $request->request_type,
            'category_id' => $request->category_id ?: null,
            'department_id' => $request->department_id ?: null,
            'committee_id' => $request->committee_id,
            'priority' => $request->priority ?: 100,
            'is_active' => $request->has('is_active') ? (bool) $request->is_active : true,
            'created_by' => $rule->exists ? $rule->created_by : auth()->id(),
        ])->save();

        return $this->ok(__('governance.Saved'));
    }

    public function editRule($id)
    {
        return $this->ok(__('governance.Loaded'), ['data' => GovernanceAssignmentRule::findOrFail($id)]);
    }

    public function destroyRule($id)
    {
        GovernanceAssignmentRule::findOrFail($id)->delete();

        return $this->ok(__('governance.Deleted'));
    }
}
