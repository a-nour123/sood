<?php

namespace App\Http\Controllers\admin\committee;

use App\Models\Department;
use App\Services\Governance\GovernanceDashboardService;
use Illuminate\Http\Request;

class DashboardController extends GovernanceController
{
    public function index(Request $request)
    {
        $filters = $request->only(['committee_id', 'department_id', 'request_type', 'status', 'priority', 'date_from', 'date_to', 'decision_from', 'decision_to', 'owner_id', 'year']);
        $stats = GovernanceDashboardService::stats(auth()->user(), $filters);
        $options = $this->options();
        $departments = [];
        foreach ($options['departments'] as $department) {
            $departments[$department->id] = $department->name;
        }
        $committees = [];
        foreach ($options['committees'] as $committee) {
            $committees[$committee->id] = $committee->name;
        }
        $breadcrumbs = $this->crumbs([['name' => __('locale.GovernanceDashboard')]]);

        return view('admin.content.committee.dashboard', compact('stats', 'filters', 'options', 'departments', 'committees', 'breadcrumbs'));
    }

    public function data(Request $request)
    {
        return response()->json(GovernanceDashboardService::stats(auth()->user(), $request->all()));
    }
}
