<?php

namespace App\Http\Controllers\admin\committee;

use App\Models\GovernanceRequest;
use App\Models\GovernanceReview;
use App\Services\Governance\GovernanceReviewService;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class ReviewController extends GovernanceController
{
    public function index()
    {
        $breadcrumbs = $this->crumbs([['name' => __('locale.ReviewsDecisions')]]);

        return view('admin.content.committee.reviews.index', compact('breadcrumbs'));
    }

    public function store(Request $request, $id)
    {
        $row = GovernanceRequest::findOrFail($id);
        $this->authorizeRecord($row);
        if ($failed = $this->validateJson($request, [
            'review_status' => ['required', Rule::in(GovernanceReviewService::statuses())],
            'recommendation' => ['nullable', Rule::in(GovernanceReviewService::recommendations())],
            'comments' => ['nullable', 'string'],
        ])) {
            return $failed;
        }

        return $this->result(GovernanceReviewService::submit(auth()->user(), $row, $request->all()));
    }

    public function comment(Request $request, $id, $reviewId)
    {
        $row = GovernanceRequest::findOrFail($id);
        $this->authorizeRecord($row);
        $review = GovernanceReview::where('governance_request_id', $row->id)->findOrFail($reviewId);
        if ($failed = $this->validateJson($request, ['body' => ['required', 'string']])) {
            return $failed;
        }

        return $this->result(GovernanceReviewService::comment(auth()->user(), $review, $request->input('body')));
    }
}
