<?php

namespace App\Http\Controllers\admin\committee;

use App\Http\Controllers\Controller;
use App\Models\Department;
use App\Models\GovernanceCommittee;
use App\Models\GovernanceCommitteeType;
use App\Models\GovernanceRequestCategory;
use App\Models\User;
use App\Services\Governance\GovernanceAccess;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class GovernanceController extends Controller
{
    protected function validateJson(Request $request, array $rules)
    {
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()->toArray(),
                'message' => __('governance.ValidationFailed'),
            ], 422);
        }

        return null;
    }

    protected function ok(string $message, array $data = [])
    {
        return response()->json(array_merge(['status' => true, 'message' => $message], $data));
    }

    protected function result(array $result)
    {
        if (empty($result['ok'])) {
            return response()->json(['status' => false, 'message' => $result['message']], $result['code'] ?? 422);
        }
        $payload = ['status' => true, 'message' => $result['message']];
        if (!empty($result['request'])) {
            $payload['id'] = $result['request']->id;
        }
        if (!empty($result['committee'])) {
            $payload['id'] = $result['committee']->id;
        }

        return response()->json($payload);
    }

    protected function ensureAssigned(bool $assigned)
    {
        if ($assigned) {
            return null;
        }

        return response()->json(['status' => false, 'message' => __('locale.YouDonotHavePermissionToDoThat')], 403);
    }

    protected function authorizeRecord(Model $model): void
    {
        $user = auth()->user();
        $allowed = $model instanceof GovernanceCommittee
            ? GovernanceAccess::canViewCommittee($user, $model)
            : GovernanceAccess::canViewRequest($user, $model);
        if (!$allowed) {
            abort(response()->json(['status' => false, 'message' => __('locale.YouDonotHavePermissionToDoThat')], 403));
        }
    }

    protected function options(): array
    {
        $user = auth()->user();

        return [
            'departments' => Department::orderBy('id')->get(),
            'users' => User::orderBy('name')->get(['id', 'name', 'department_id']),
            'committees' => GovernanceAccess::scopeCommittees(GovernanceCommittee::query(), $user)->orderBy('name')->get(),
            'types' => GovernanceCommitteeType::where('is_active', true)->orderBy('name')->get(),
            'categories' => GovernanceRequestCategory::where('is_active', true)->orderBy('name')->get(),
        ];
    }

    protected function crumbs(array $extra = []): array
    {
        return array_merge([
            ['link' => route('admin.dashboard'), 'name' => __('locale.Dashboard')],
            ['link' => route('admin.committee.dashboard'), 'name' => __('locale.GovernanceCommitteeManagement')],
        ], $extra);
    }
}
