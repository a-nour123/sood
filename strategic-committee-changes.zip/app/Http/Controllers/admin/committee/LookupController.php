<?php

namespace App\Http\Controllers\admin\committee;

use App\Models\FrameworkControl;
use App\Models\Risk;
use App\Models\User;
use Illuminate\Http\Request;

class LookupController extends GovernanceController
{
    public function users(Request $request)
    {
        $query = User::query()->orderBy('name');
        if ($request->filled('department_id')) {
            $query->where('department_id', $request->department_id);
        }

        return $this->ok(__('governance.Loaded'), ['data' => $query->get(['id', 'name', 'department_id'])]);
    }

    public function risks(Request $request)
    {
        $query = Risk::query()->orderByDesc('id');
        if ($request->filled('q')) {
            $term = $request->input('q');
            $query->where(function ($inner) use ($term) {
                $inner->where('subject', 'like', '%' . $term . '%')->orWhere('reference_id', 'like', '%' . $term . '%');
            });
        }

        return $this->ok(__('governance.Loaded'), [
            'data' => $query->limit(30)->get(['id', 'subject', 'reference_id'])->map(function (Risk $risk) {
                return ['id' => $risk->id, 'text' => trim(($risk->reference_id ? $risk->reference_id . ' - ' : '') . $risk->subject)];
            }),
        ]);
    }

    public function controls(Request $request)
    {
        $query = FrameworkControl::query()->orderBy('short_name');
        if ($request->filled('family_id')) {
            $query->where('family', $request->family_id);
        }
        if ($request->filled('q')) {
            $query->where('short_name', 'like', '%' . $request->input('q') . '%');
        }

        return $this->ok(__('governance.Loaded'), [
            'data' => $query->limit(30)->get(['id', 'short_name', 'control_number'])->map(function (FrameworkControl $control) {
                return ['id' => $control->id, 'text' => trim($control->control_number . ' ' . $control->short_name)];
            }),
        ]);
    }
}
