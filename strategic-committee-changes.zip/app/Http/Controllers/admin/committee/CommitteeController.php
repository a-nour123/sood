<?php

namespace App\Http\Controllers\admin\committee;

use App\Models\GovernanceCommittee;
use App\Models\GovernanceCommitteeDepartment;
use App\Models\GovernanceCommitteeMember;
use App\Services\Governance\CommitteeMemberPolicy;
use App\Services\Governance\GovernanceAccess;
use App\Services\Governance\GovernanceCommitteeService;
use App\Services\Governance\GovernanceListResponder;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class CommitteeController extends GovernanceController
{
    public function index()
    {
        $options = $this->options();
        $breadcrumbs = $this->crumbs([['name' => __('locale.Committees')]]);

        return view('admin.content.committee.committees.index', compact('options', 'breadcrumbs'));
    }

    public function show($id)
    {
        $committee = GovernanceCommittee::with([
            'type', 'chairman', 'secretary', 'departmentLinks.department', 'members.user', 'members.department', 'requestTypes',
        ])->findOrFail($id);
        $this->authorizeRecord($committee);
        $options = $this->options();
        $breadcrumbs = $this->crumbs([
            ['link' => route('admin.committee.committees.index'), 'name' => __('locale.Committees')],
            ['name' => $committee->name],
        ]);
        $roles = CommitteeMemberPolicy::roles();
        $assigned = GovernanceAccess::assignedToCommittee(auth()->user(), $committee);
        $canMembers = GovernanceAccess::allows(auth()->user(), 'manage_committee_members', $assigned);
        $canDepartments = GovernanceAccess::allows(auth()->user(), 'manage_committee_departments', $assigned);
        $canSettings = GovernanceAccess::allows(auth()->user(), 'manage_committee_settings', $assigned);

        return view('admin.content.committee.committees.show', compact('committee', 'options', 'breadcrumbs', 'roles', 'canMembers', 'canDepartments', 'canSettings'));
    }

    public function ajaxList(Request $request)
    {
        $query = GovernanceAccess::scopeCommittees(GovernanceCommittee::query(), auth()->user())->with(['type', 'chairman']);

        return GovernanceListResponder::respond($query, $request, ['name', 'code', 'description'], ['id', 'name', 'code', 'status'], function (GovernanceCommittee $committee) {
            return [
                'id' => $committee->id,
                'name' => $committee->name,
                'code' => $committee->code,
                'type' => optional($committee->type)->name,
                'status' => __('governance.committee_statuses.' . $committee->status),
                'mode' => __('governance.approval_modes.' . $committee->approval_mode),
                'Actions' => ['id' => $committee->id, 'assigned' => GovernanceAccess::assignedToCommittee(auth()->user(), $committee)],
            ];
        });
    }

    public function store(Request $request)
    {
        if ($failed = $this->validateJson($request, $this->rules())) {
            return $failed;
        }

        return $this->result(GovernanceCommitteeService::save(auth()->user(), $request->all()));
    }

    public function edit($id)
    {
        $committee = GovernanceCommittee::findOrFail($id);
        $this->authorizeRecord($committee);
        if ($denied = $this->ensureAssigned(GovernanceAccess::assignedToCommittee(auth()->user(), $committee))) {
            return $denied;
        }
        $data = $committee->toArray();
        $data['effective_from'] = optional($committee->effective_from)->toDateString();
        $data['effective_until'] = optional($committee->effective_until)->toDateString();
        $data['allow_vote_change'] = $committee->allow_vote_change ? 1 : 0;

        return $this->ok(__('governance.Loaded'), ['data' => $data]);
    }

    public function update(Request $request, $id)
    {
        $committee = GovernanceCommittee::findOrFail($id);
        $this->authorizeRecord($committee);
        if ($denied = $this->ensureAssigned(GovernanceAccess::assignedToCommittee(auth()->user(), $committee))) {
            return $denied;
        }
        if ($failed = $this->validateJson($request, $this->rules($committee->id))) {
            return $failed;
        }

        return $this->result(GovernanceCommitteeService::save(auth()->user(), $request->all(), $committee));
    }

    public function destroy($id)
    {
        $committee = GovernanceCommittee::findOrFail($id);
        $this->authorizeRecord($committee);
        if ($denied = $this->ensureAssigned(GovernanceAccess::assignedToCommittee(auth()->user(), $committee))) {
            return $denied;
        }

        return $this->result(GovernanceCommitteeService::remove(auth()->user(), $committee));
    }

    public function department(Request $request, $id)
    {
        $committee = GovernanceCommittee::findOrFail($id);
        $this->authorizeRecord($committee);
        if ($denied = $this->ensureAssigned(GovernanceAccess::assignedToCommittee(auth()->user(), $committee))) {
            return $denied;
        }
        if ($failed = $this->validateJson($request, ['department_id' => ['required', 'integer', 'exists:departments,id']])) {
            return $failed;
        }

        return $this->result(GovernanceCommitteeService::assignDepartment(auth()->user(), $committee, (int) $request->department_id));
    }

    public function removeDepartment($id, $departmentId)
    {
        $committee = GovernanceCommittee::findOrFail($id);
        $this->authorizeRecord($committee);
        if ($denied = $this->ensureAssigned(GovernanceAccess::assignedToCommittee(auth()->user(), $committee))) {
            return $denied;
        }

        return $this->result(GovernanceCommitteeService::removeDepartment(auth()->user(), $committee, (int) $departmentId));
    }

    public function member(Request $request, $id)
    {
        $committee = GovernanceCommittee::findOrFail($id);
        $this->authorizeRecord($committee);
        if ($denied = $this->ensureAssigned(GovernanceAccess::assignedToCommittee(auth()->user(), $committee))) {
            return $denied;
        }
        if ($failed = $this->validateJson($request, $this->memberRules())) {
            return $failed;
        }
        $member = $request->filled('member_id') ? GovernanceCommitteeMember::where('committee_id', $committee->id)->findOrFail($request->member_id) : null;

        return $this->result(GovernanceCommitteeService::saveMember(auth()->user(), $committee, $request->all(), $member));
    }

    public function removeMember($id, $memberId)
    {
        $committee = GovernanceCommittee::findOrFail($id);
        $this->authorizeRecord($committee);
        if ($denied = $this->ensureAssigned(GovernanceAccess::assignedToCommittee(auth()->user(), $committee))) {
            return $denied;
        }
        $member = GovernanceCommitteeMember::where('committee_id', $committee->id)->findOrFail($memberId);

        return $this->result(GovernanceCommitteeService::removeMember(auth()->user(), $member));
    }

    public function requestTypes(Request $request, $id)
    {
        $committee = GovernanceCommittee::findOrFail($id);
        $this->authorizeRecord($committee);
        if ($denied = $this->ensureAssigned(GovernanceAccess::assignedToCommittee(auth()->user(), $committee))) {
            return $denied;
        }

        return $this->result(GovernanceCommitteeService::syncRequestTypes(auth()->user(), $committee, (array) $request->input('request_types', [])));
    }

    protected function rules($id = null): array
    {
        return [
            'name' => ['required', 'string', 'max:200'],
            'code' => ['required', 'string', 'max:50', Rule::unique('governance_committees', 'code')->ignore($id)],
            'committee_type_id' => ['nullable', 'integer', 'exists:governance_committee_types,id'],
            'status' => ['required', Rule::in(['active', 'inactive'])],
            'approval_mode' => ['required', Rule::in(['chairman', 'majority', 'unanimous', 'minimum', 'weighted'])],
            'minimum_approval_count' => ['nullable', 'integer', 'min:1'],
            'voting_threshold' => ['nullable', 'numeric', 'min:1', 'max:100'],
            'quorum_count' => ['nullable', 'integer', 'min:0'],
            'effective_from' => ['nullable', 'date'],
            'effective_until' => ['nullable', 'date'],
        ];
    }

    protected function memberRules(): array
    {
        return [
            'user_id' => ['required', 'integer', 'exists:users,id'],
            'department_id' => ['required', 'integer', 'exists:departments,id'],
            'member_role' => ['required', Rule::in(CommitteeMemberPolicy::roles())],
            'effective_from' => ['nullable', 'date'],
            'effective_until' => ['nullable', 'date'],
            'status' => ['nullable', Rule::in(['active', 'inactive'])],
        ];
    }
}
