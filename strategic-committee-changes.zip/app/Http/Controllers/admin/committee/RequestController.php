<?php

namespace App\Http\Controllers\admin\committee;

use App\Models\Document;
use App\Models\Exception;
use App\Models\Family;
use App\Models\Framework;
use App\Models\FrameworkControl;
use App\Models\GovernanceRequest;
use App\Models\GovernanceRequestAttachment;
use App\Models\Risk;
use App\Services\Governance\CommitteeMemberPolicy;
use App\Services\Governance\GovernanceAccess;
use App\Services\Governance\GovernanceListResponder;
use App\Services\Governance\GovernanceLogger;
use App\Services\Governance\GovernanceRequestService;
use App\Services\Governance\GovernanceRiskReader;
use App\Services\Governance\GovernanceWorkflow;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;

class RequestController extends GovernanceController
{
    public function index()
    {
        return $this->screen(null, __('locale.GovernanceRequests'), 'admin.committee.requests.index');
    }

    public function approvals()
    {
        return $this->screen('approval', __('locale.ApprovalRequests'), 'admin.committee.approvals.index');
    }

    public function exceptions()
    {
        return $this->screen('exception', __('locale.ExceptionRequests'), 'admin.committee.exceptions.index');
    }

    public function riskAcceptance()
    {
        return $this->screen('risk_acceptance', __('locale.RiskAcceptanceRequests'), 'admin.committee.risks.index');
    }

    public function show($id)
    {
        $request = GovernanceRequest::with([
            'category', 'requester', 'department', 'committee.type', 'committee.members.user',
            'approvalDetail.document', 'exceptionDetail.framework', 'exceptionDetail.family', 'exceptionDetail.control',
            'exceptionDetail.policy', 'exceptionDetail.owner', 'riskAcceptanceDetail.risk.owner', 'riskAcceptanceDetail.risk.riskScoring',
            'reviews.reviewer', 'reviews.comments.user', 'reviews.attachments', 'votingSessions.votes.voter',
            'decisions.decider', 'attachments.uploader', 'activityLogs.actor', 'statusHistories.actor', 'assignments.toCommittee',
        ])->findOrFail($id);
        $this->authorizeRecord($request);
        $breadcrumbs = $this->crumbs([
            ['link' => route('admin.committee.requests.index'), 'name' => __('locale.GovernanceRequests')],
            ['name' => $request->request_number],
        ]);
        $user = auth()->user();
        $assigned = GovernanceAccess::assignedToRequest($user, $request);
        $member = GovernanceAccess::membership($user, $request->assigned_committee_id);
        $actions = [];
        foreach (GovernanceWorkflow::map()[$request->status] ?? [] as $action => $meta) {
            if (GovernanceAccess::allows($user, $meta['permission'], $assigned)) {
                $actions[$action] = $meta;
            }
        }
        $committees = $this->options()['committees'];
        $canReview = $member && CommitteeMemberPolicy::allows($member->policyArray(), 'review')
            && GovernanceAccess::allows($user, 'review_governance_request', $assigned);
        $canVote = $member && CommitteeMemberPolicy::allows($member->policyArray(), 'vote')
            && GovernanceAccess::allows($user, 'vote_on_governance_request', $assigned);
        $canCloseVote = $member && (
            GovernanceAccess::allows($user, 'manage_committee_voting', $assigned)
            || GovernanceAccess::allows($user, 'finalize_committee_recommendation', $assigned)
        );
        $canDecide = $member && CommitteeMemberPolicy::allows($member->policyArray(), 'approve') && (
            GovernanceAccess::allows($user, 'approve_governance_request', $assigned)
            || GovernanceAccess::allows($user, 'reject_governance_request', $assigned)
            || GovernanceAccess::allows($user, 'issue_governance_decision', $assigned)
        );
        $canUpdate = GovernanceAccess::allows($user, 'update_governance_request', $assigned);

        return view('admin.content.committee.requests.show', compact(
            'request', 'breadcrumbs', 'actions', 'committees', 'canReview', 'canVote', 'canCloseVote', 'canDecide', 'canUpdate'
        ));
    }

    public function ajaxList(Request $request)
    {
        $query = GovernanceAccess::scopeRequests(GovernanceRequest::query(), auth()->user())->with(['committee', 'department', 'requester']);
        if ($request->filled('fixed_type')) {
            $query->where('request_type', $request->input('fixed_type'));
        }

        return GovernanceListResponder::respond($query, $request, ['request_number', 'title', 'description'], ['id', 'request_number', 'title', 'status', 'priority', 'due_date'], function (GovernanceRequest $row) {
            return [
                'id' => $row->id,
                'request_number' => $row->request_number,
                'title' => $row->title,
                'type' => __('governance.request_types.' . $row->request_type),
                'status' => __('governance.statuses.' . $row->status),
                'priority' => __('governance.priorities.' . $row->priority),
                'committee' => optional($row->committee)->name,
                'department' => optional($row->department)->name,
                'due_date' => optional($row->due_date)->toDateString(),
                'Actions' => ['id' => $row->id, 'assigned' => GovernanceAccess::assignedToRequest(auth()->user(), $row)],
            ];
        });
    }

    public function store(Request $request)
    {
        $type = $request->input('request_type');
        if (!$this->canManageType($type, 'create_governance_request')) {
            return response()->json(['status' => false, 'message' => __('locale.YouDonotHavePermissionToDoThat')], 403);
        }
        if ($failed = $this->validateJson($request, $this->rules($type))) {
            return $failed;
        }

        return $this->result(GovernanceRequestService::create(auth()->user(), $type, $request->all()));
    }

    public function edit($id)
    {
        $row = GovernanceRequest::with(['approvalDetail', 'exceptionDetail', 'riskAcceptanceDetail'])->findOrFail($id);
        $this->authorizeRecord($row);
        if ($denied = $this->ensureAssigned(GovernanceAccess::assignedToRequest(auth()->user(), $row))) {
            return $denied;
        }
        $data = $row->toArray();
        $detail = $row->approvalDetail ?: $row->exceptionDetail ?: $row->riskAcceptanceDetail;
        if ($detail) {
            $data = array_merge($detail->toArray(), $data);
        }
        foreach (['due_date', 'submission_date', 'requested_effective_date', 'requested_start', 'requested_expiration', 'review_date', 'proposed_expiration'] as $date) {
            if (!empty($data[$date])) {
                $data[$date] = substr((string) $data[$date], 0, 10);
            }
        }

        return $this->ok(__('governance.Loaded'), ['data' => $data]);
    }

    public function update(Request $request, $id)
    {
        $row = GovernanceRequest::findOrFail($id);
        $this->authorizeRecord($row);
        if ($denied = $this->ensureAssigned(GovernanceAccess::assignedToRequest(auth()->user(), $row))) {
            return $denied;
        }
        if (!$this->canManageType($row->request_type, 'update_governance_request')) {
            return response()->json(['status' => false, 'message' => __('locale.YouDonotHavePermissionToDoThat')], 403);
        }
        if ($failed = $this->validateJson($request, $this->rules($row->request_type, $row->id))) {
            return $failed;
        }

        return $this->result(GovernanceRequestService::update(auth()->user(), $row, $request->all()));
    }

    public function destroy($id)
    {
        $row = GovernanceRequest::findOrFail($id);
        $this->authorizeRecord($row);
        if ($denied = $this->ensureAssigned(GovernanceAccess::assignedToRequest(auth()->user(), $row))) {
            return $denied;
        }
        if (!$this->canManageType($row->request_type, 'delete_governance_request')) {
            return response()->json(['status' => false, 'message' => __('locale.YouDonotHavePermissionToDoThat')], 403);
        }

        return $this->result(GovernanceRequestService::delete(auth()->user(), $row));
    }

    public function act(Request $request, $id)
    {
        $row = GovernanceRequest::findOrFail($id);
        $this->authorizeRecord($row);
        if ($denied = $this->ensureAssigned(GovernanceAccess::assignedToRequest(auth()->user(), $row))) {
            return $denied;
        }

        return $this->result(GovernanceRequestService::act(
            auth()->user(),
            $row,
            (string) $request->input('action'),
            $request->input('comment'),
            $request->only(['committee_id', 'deadline'])
        ));
    }

    public function upload(Request $request, $id)
    {
        $row = GovernanceRequest::findOrFail($id);
        $this->authorizeRecord($row);
        if ($denied = $this->ensureAssigned(GovernanceAccess::assignedToRequest(auth()->user(), $row))) {
            return $denied;
        }
        if ($failed = $this->validateJson($request, [
            'file' => ['required', 'file', 'max:10240', 'mimes:pdf,doc,docx,xls,xlsx,png,jpg,jpeg,txt'],
            'governance_review_id' => ['nullable', 'integer'],
        ])) {
            return $failed;
        }
        $file = $request->file('file');
        $path = $file->store('governance/requests/' . $row->id, 'public');
        GovernanceRequestAttachment::create([
            'governance_request_id' => $row->id,
            'governance_review_id' => $request->input('governance_review_id') ?: null,
            'original_name' => $file->getClientOriginalName(),
            'path' => $path,
            'mime' => $file->getClientMimeType(),
            'size' => $file->getSize(),
            'uploaded_by' => auth()->id(),
        ]);
        GovernanceLogger::log($row, 'attachment_added', $file->getClientOriginalName(), [], $row->assigned_committee_id, auth()->user());

        return $this->ok(__('governance.Saved'));
    }

    public function downloadAttachment($id, $attachmentId)
    {
        $row = GovernanceRequest::findOrFail($id);
        $this->authorizeRecord($row);
        $attachment = GovernanceRequestAttachment::where('governance_request_id', $row->id)->findOrFail($attachmentId);

        return Storage::disk('public')->download($attachment->path, $attachment->original_name);
    }

    public function risk($id)
    {
        $risk = Risk::with(['owner:id,name', 'riskScoring', 'responsibleDepartment', 'mitigation', 'latestTreatmentRequest'])->findOrFail($id);

        return $this->ok(__('governance.Loaded'), ['data' => GovernanceRiskReader::snapshot($risk)]);
    }

    protected function screen(?string $type, string $title, string $routeName)
    {
        $options = $this->options();
        $options['frameworks'] = Framework::orderBy('name')->get(['id', 'name']);
        $options['families'] = Family::orderBy('id')->limit(500)->get();
        $options['controls'] = FrameworkControl::orderBy('id')->limit(500)->get(['id', 'short_name', 'control_number']);
        $options['documents'] = Document::orderByDesc('id')->limit(300)->get(['id', 'document_name']);
        $options['exceptions'] = Exception::orderByDesc('id')->limit(200)->get(['id', 'name']);
        $options['risks'] = Risk::orderByDesc('id')->limit(300)->get(['id', 'subject', 'reference_id']);
        $breadcrumbs = $this->crumbs([['name' => $title]]);

        return view('admin.content.committee.requests.index', compact('options', 'breadcrumbs', 'type', 'title', 'routeName'));
    }

    protected function canManageType(?string $type, string $generic): bool
    {
        $user = auth()->user();
        if (GovernanceAccess::isAdmin($user) || GovernanceAccess::permits($user, $generic)) {
            return true;
        }
        $map = [
            'approval' => 'manage_approval_requests',
            'exception' => 'manage_exception_requests',
            'risk_acceptance' => 'manage_risk_acceptance_requests',
        ];

        return isset($map[$type]) && GovernanceAccess::permits($user, $map[$type]);
    }

    protected function rules(?string $type, $id = null): array
    {
        $rules = [
            'request_type' => ['required', Rule::in(['approval', 'exception', 'risk_acceptance'])],
            'title' => ['required', 'string', 'max:250'],
            'category_id' => ['nullable', 'integer', 'exists:governance_request_categories,id'],
            'department_id' => ['nullable', 'integer', 'exists:departments,id'],
            'assigned_committee_id' => ['nullable', 'integer', 'exists:governance_committees,id'],
            'priority' => ['required', Rule::in(['low', 'medium', 'high', 'critical'])],
            'due_date' => ['nullable', 'date'],
            'description' => ['nullable', 'string'],
            'idempotency_key' => ['nullable', 'string', 'max:64'],
        ];
        if ($type === 'approval') {
            $rules['document_id'] = ['nullable', 'integer', 'exists:documents,id'];
            $rules['requested_effective_date'] = ['nullable', 'date'];
        }
        if ($type === 'exception') {
            $rules['justification'] = ['required', 'string'];
            $rules['framework_id'] = ['nullable', 'integer', 'exists:frameworks,id'];
            $rules['family_id'] = ['nullable', 'integer', 'exists:families,id'];
            $rules['control_id'] = ['nullable', 'integer', 'exists:framework_controls,id'];
            $rules['policy_document_id'] = ['nullable', 'integer', 'exists:documents,id'];
            $rules['existing_exception_id'] = ['nullable', 'integer', 'exists:exceptions,id'];
            $rules['requested_start'] = ['nullable', 'date'];
            $rules['requested_expiration'] = ['nullable', 'date'];
        }
        if ($type === 'risk_acceptance') {
            $rules['risk_id'] = ['required', 'integer', 'exists:risks,id'];
            $rules['acceptance_justification'] = ['required', 'string'];
            $rules['proposed_expiration'] = ['nullable', 'date'];
        }

        return $rules;
    }
}
