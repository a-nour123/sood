<?php

namespace App\Http\Controllers\admin\committee;

use App\Models\GovernanceCommittee;
use App\Models\GovernanceCommitteeMember;
use App\Services\Governance\GovernanceAccess;
use App\Services\Governance\GovernanceListResponder;
use Illuminate\Http\Request;

class MemberController extends GovernanceController
{
    public function index()
    {
        $options = $this->options();
        $breadcrumbs = $this->crumbs([['name' => __('locale.CommitteeMembers')]]);

        return view('admin.content.committee.members.index', compact('options', 'breadcrumbs'));
    }

    public function ajaxList(Request $request)
    {
        $ids = GovernanceAccess::scopeCommittees(GovernanceCommittee::query(), auth()->user())->pluck('id');
        $query = GovernanceCommitteeMember::with(['committee', 'user', 'department'])->whereIn('committee_id', $ids);

        return GovernanceListResponder::respond($query, $request, [], ['id', 'member_role', 'status'], function (GovernanceCommitteeMember $member) {
            return [
                'id' => $member->id,
                'committee' => optional($member->committee)->name,
                'member' => optional($member->user)->name,
                'department' => optional($member->department)->name,
                'role' => __('governance.member_roles.' . $member->member_role),
                'voting' => $member->voting_right ? __('governance.Yes') : __('governance.No'),
                'status' => __('governance.member_statuses.' . $member->status),
                'Actions' => ['id' => $member->committee_id, 'assigned' => true],
            ];
        });
    }
}
