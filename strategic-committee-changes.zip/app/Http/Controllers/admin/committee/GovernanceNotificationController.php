<?php

namespace App\Http\Controllers\admin\committee;

use App\Models\Action;
use App\Models\User;
use App\Services\Governance\GovernanceNotificationCatalog;

class GovernanceNotificationController extends GovernanceController
{
    public function index()
    {
        $breadcrumbs = $this->crumbs([['name' => __('locale.NotificationsSettings')]]);
        $users = User::select('id', 'name')->get();
        $moduleActionsIds = [];
        $moduleActionsIdsAutoNotify = [];
        $actionsVariables = [];
        $actionsRoles = [];
        $roles = GovernanceNotificationCatalog::roles();

        foreach (GovernanceNotificationCatalog::definitions() as $name => $definition) {
            $id = Action::where('name', $name)->value('id');
            if (!$id) {
                continue;
            }
            $moduleActionsIds[] = $id;
            $actionsVariables[$id] = $definition['variables'];
            $actionsRoles[$id] = $roles;
        }
        foreach (GovernanceNotificationCatalog::dueDefinitions() as $name => $definition) {
            $id = Action::where('name', $name)->value('id');
            if (!$id) {
                continue;
            }
            $moduleActionsIdsAutoNotify[] = $id;
            $actionsVariables[$id] = $definition['variables'];
            $actionsRoles[$id] = $roles;
        }

        $actionsWithSettings = Action::whereIn('actions.id', $moduleActionsIds)
            ->leftJoin('system_notifications_settings', 'actions.id', '=', 'system_notifications_settings.action_id')
            ->leftJoin('mail_settings', 'actions.id', '=', 'mail_settings.action_id')
            ->leftJoin('sms_settings', 'actions.id', '=', 'sms_settings.action_id')
            ->get([
                'actions.id as action_id',
                'actions.name as action_name',
                'system_notifications_settings.id as system_notification_setting_id',
                'system_notifications_settings.status as system_notification_setting_status',
                'mail_settings.id as mail_setting_id',
                'mail_settings.status as mail_setting_status',
                'sms_settings.id as sms_setting_id',
                'sms_settings.status as sms_setting_status',
            ]);
        $actionsWithSettingsAuto = Action::whereIn('actions.id', $moduleActionsIdsAutoNotify)
            ->leftJoin('auto_notifies', 'actions.id', '=', 'auto_notifies.action_id')
            ->get([
                'actions.id as action_id',
                'actions.name as action_name',
                'auto_notifies.id as auto_notifies_id',
                'auto_notifies.status as auto_notifies_status',
            ]);

        return view('admin.notifications-settings.index', compact(
            'breadcrumbs',
            'users',
            'actionsWithSettings',
            'actionsVariables',
            'actionsRoles',
            'moduleActionsIdsAutoNotify',
            'actionsWithSettingsAuto'
        ));
    }
}
