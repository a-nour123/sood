<?php

namespace App\Http\Controllers\admin\committee;

use App\Exports\GovernanceTabularExport;
use App\Services\Governance\GovernanceReportService;
use Dompdf\Dompdf;
use Dompdf\Options;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;

class ReportController extends GovernanceController
{
    public function index(Request $request)
    {
        $type = in_array($request->input('type'), GovernanceReportService::types(), true) ? $request->input('type') : 'committees';
        $filters = $request->only(['committee_id', 'department_id', 'request_type', 'status', 'priority', 'date_from', 'date_to', 'owner_id']);
        $rows = GovernanceReportService::rows(auth()->user(), $type, $filters);
        $headings = array_map(function ($heading) {
            return __('governance.headings.' . $heading);
        }, GovernanceReportService::headings($type));
        $options = $this->options();
        $breadcrumbs = $this->crumbs([['name' => __('locale.GovernanceReports')]]);

        return view('admin.content.committee.reports.index', compact('type', 'filters', 'rows', 'headings', 'options', 'breadcrumbs'));
    }

    public function excel(Request $request)
    {
        $type = in_array($request->input('type'), GovernanceReportService::types(), true) ? $request->input('type') : 'committees';
        $rows = GovernanceReportService::rows(auth()->user(), $type, $request->only(['committee_id', 'department_id', 'request_type', 'status', 'priority', 'date_from', 'date_to', 'owner_id']));
        $headings = array_map(function ($heading) {
            return __('governance.headings.' . $heading);
        }, GovernanceReportService::headings($type));

        return Excel::download(new GovernanceTabularExport($headings, $rows), 'governance-' . $type . '.xlsx');
    }

    public function pdf(Request $request)
    {
        $type = in_array($request->input('type'), GovernanceReportService::types(), true) ? $request->input('type') : 'committees';
        $rows = GovernanceReportService::rows(auth()->user(), $type, $request->only(['committee_id', 'department_id', 'request_type', 'status', 'priority', 'date_from', 'date_to', 'owner_id']));
        $headings = array_map(function ($heading) {
            return __('governance.headings.' . $heading);
        }, GovernanceReportService::headings($type));
        $html = view('admin.content.committee.reports.pdf', [
            'title' => __('governance.report_types.' . $type),
            'headings' => $headings,
            'rows' => $rows,
        ])->render();
        $options = new Options();
        $options->set('defaultFont', 'DejaVu Sans');
        $options->set('isRemoteEnabled', false);
        $dompdf = new Dompdf($options);
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'landscape');
        $dompdf->render();

        return response($dompdf->output(), 200, [
            'Content-Type' => 'application/pdf',
            'Content-Disposition' => 'attachment; filename="governance-' . $type . '.pdf"',
        ]);
    }
}
