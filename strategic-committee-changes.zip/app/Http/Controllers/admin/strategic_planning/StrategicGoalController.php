<?php

namespace App\Http\Controllers\admin\strategic_planning;

use App\Models\StrategicGoal;
use App\Models\StrategicPlan;
use App\Services\Strategic\StrategicAccess;
use App\Services\Strategic\StrategicListResponder;
use App\Services\Strategic\StrategicLogger;
use App\Services\Strategic\StrategicProgressService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class StrategicGoalController extends StrategicController
{
    public function index()
    {
        $options = $this->options();
        $breadcrumbs = $this->crumbs([['name' => __('locale.StrategicGoals')]]);

        return view('admin.content.strategic_planning.goals.index', compact('options', 'breadcrumbs'));
    }

    public function ajaxList(Request $request)
    {
        $query = StrategicAccess::scopeByPlan(StrategicGoal::query(), auth()->user(), 'plan')
            ->with(['plan:id,name', 'owner:id,name', 'department']);

        return StrategicListResponder::respond(
            $query,
            $request,
            ['name', 'code', 'description', 'perspective', 'status'],
            ['id', 'name', 'code', 'perspective', 'status', 'weight', 'due_date', 'calculated_progress'],
            function (StrategicGoal $goal) {
                return [
                    'id' => $goal->id,
                    'name' => $goal->name,
                    'code' => $goal->code,
                    'plan' => optional($goal->plan)->name,
                    'perspective' => __('strategic.perspectives.' . $goal->perspective),
                    'status' => __('strategic.work_statuses.' . $goal->status),
                    'weight' => $goal->weight,
                    'progress' => $goal->displayedProgress(),
                    'due_date' => optional($goal->due_date)->toDateString(),
                    'Actions' => $this->rowActions($goal),
                ];
            }
        );
    }

    public function store(Request $request)
    {
        $plan = StrategicPlan::findOrFail($request->input('strategic_plan_id'));
        $this->authorizeRecord($plan);
        if ($locked = $this->structureLock($plan)) {
            return $locked;
        }
        if ($failed = $this->validateJson($request, $this->rules($plan->id))) {
            return $failed;
        }
        $goal = DB::transaction(function () use ($request) {
            $goal = StrategicGoal::create($request->only([
                'strategic_plan_id', 'name', 'code', 'description', 'perspective', 'owner_id',
                'department_id', 'priority', 'weight', 'start_date', 'due_date', 'status', 'sort_order',
            ]) + ['created_by' => auth()->id(), 'updated_by' => auth()->id()]);
            StrategicProgressService::recalculateGoal($goal);
            StrategicLogger::log($goal->plan, 'goal_created', $goal->name);

            return $goal;
        });

        return $this->ok(__('strategic.Saved'), ['id' => $goal->id]);
    }

    public function edit($id)
    {
        $goal = StrategicGoal::findOrFail($id);
        $this->authorizeRecord($goal);

        return $this->ok(__('strategic.Loaded'), ['data' => $goal]);
    }

    public function update(Request $request, $id)
    {
        $goal = StrategicGoal::findOrFail($id);
        $this->authorizeRecord($goal);
        $plan = $goal->plan;
        if ($locked = $this->structureLock($plan)) {
            return $locked;
        }
        if ($failed = $this->validateJson($request, $this->rules($plan->id, $goal->id))) {
            return $failed;
        }
        DB::transaction(function () use ($request, $goal) {
            $goal->update($request->only([
                'name', 'code', 'description', 'perspective', 'owner_id', 'department_id', 'priority',
                'weight', 'start_date', 'due_date', 'status', 'sort_order',
            ]) + ['updated_by' => auth()->id()]);
            StrategicProgressService::recalculateGoal($goal);
            StrategicLogger::log($goal, 'updated', $goal->name);
        });

        return $this->ok(__('strategic.Saved'));
    }

    public function destroy($id)
    {
        $goal = StrategicGoal::findOrFail($id);
        $this->authorizeRecord($goal);
        if ($locked = $this->structureLock($goal->plan)) {
            return $locked;
        }
        DB::transaction(function () use ($goal) {
            $plan = $goal->plan;
            $goal->load('objectives.initiatives.milestones');
            foreach ($goal->objectives as $objective) {
                foreach ($objective->initiatives as $initiative) {
                    foreach ($initiative->milestones as $milestone) {
                        $milestone->delete();
                    }
                    $initiative->delete();
                }
                $objective->delete();
            }
            StrategicLogger::log($goal, 'deleted', $goal->name);
            $goal->delete();
            StrategicProgressService::recalculatePlan($plan);
        });

        return $this->ok(__('strategic.Deleted'));
    }

    public function override(Request $request, $id)
    {
        $goal = StrategicGoal::findOrFail($id);
        $this->authorizeRecord($goal);
        if ($failed = $this->validateJson($request, [
            'manual_progress' => ['required', 'numeric', 'min:0', 'max:100'],
            'reason' => ['required', 'string', 'max:1000'],
        ])) {
            return $failed;
        }
        StrategicProgressService::override($goal, (float) $request->manual_progress, $request->reason);

        return $this->ok(__('strategic.Saved'));
    }

    protected function rules(int $planId, $id = null): array
    {
        return [
            'strategic_plan_id' => ['required', 'exists:strategic_plans,id'],
            'name' => ['required', 'string', 'max:200'],
            'code' => ['required', 'string', 'max:50', Rule::unique('strategic_goals', 'code')->ignore($id)->where(function ($query) use ($planId) {
                return $query->where('strategic_plan_id', $planId)->whereNull('deleted_at');
            })],
            'description' => ['nullable', 'string'],
            'perspective' => ['required', Rule::in(['financial', 'customer', 'internal', 'learning'])],
            'owner_id' => ['nullable', 'exists:users,id'],
            'department_id' => ['nullable', 'exists:departments,id'],
            'priority' => ['required', Rule::in(['low', 'medium', 'high', 'critical'])],
            'weight' => ['required', 'numeric', 'min:0.01', 'max:100'],
            'start_date' => ['nullable', 'date'],
            'due_date' => ['nullable', 'date', 'after_or_equal:start_date'],
            'status' => ['required', Rule::in(['not_started', 'in_progress', 'at_risk', 'delayed', 'completed', 'cancelled'])],
            'sort_order' => ['nullable', 'integer', 'min:0'],
        ];
    }
}
