<?php

namespace App\Http\Controllers\admin\strategic_planning;

use App\Models\StrategicKpi;
use App\Models\StrategicKpiMeasurement;
use App\Models\StrategicObjective;
use App\Services\Strategic\StrategicAccess;
use App\Services\Strategic\StrategicKpiService;
use App\Services\Strategic\StrategicListResponder;
use App\Services\Strategic\StrategicLogger;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class StrategicKpiController extends StrategicController
{
    public function index()
    {
        $options = $this->options();
        $options['objectives'] = StrategicObjective::orderBy('name')->get(['id', 'name']);
        $breadcrumbs = $this->crumbs([['name' => __('locale.StrategicKpis')]]);

        return view('admin.content.strategic_planning.kpis.index', compact('options', 'breadcrumbs'));
    }

    public function show($id)
    {
        $kpi = StrategicKpi::with(['owner', 'department', 'objectives.goal.plan', 'measurements.submitter'])->findOrFail($id);
        $this->authorizeRecord($kpi);
        $breadcrumbs = $this->crumbs([
            ['link' => route('admin.strategic.kpis.index'), 'name' => __('locale.StrategicKpis')],
            ['name' => $kpi->name],
        ]);

        return view('admin.content.strategic_planning.kpis.show', compact('kpi', 'breadcrumbs'));
    }

    public function ajaxList(Request $request)
    {
        $query = StrategicKpi::query()->with('owner:id,name');
        if (!StrategicAccess::isAdmin(auth()->user())) {
            $user = auth()->user();
            $query->where(function ($inner) use ($user) {
                $inner->where('owner_id', $user->id)->orWhere('created_by', $user->id);
                if ($user->department_id) {
                    $inner->orWhere('department_id', $user->department_id)->orWhereNull('department_id');
                }
                $inner->orWhereHas('objectives.goal.plan', function ($plan) use ($user) {
                    StrategicAccess::scopePlans($plan, $user);
                });
            });
        }

        return StrategicListResponder::respond(
            $query,
            $request,
            ['name', 'code', 'description', 'status'],
            ['id', 'name', 'code', 'status', 'frequency', 'achievement', 'target_date'],
            function (StrategicKpi $kpi) {
                return [
                    'id' => $kpi->id,
                    'name' => $kpi->name,
                    'code' => $kpi->code,
                    'type' => __('strategic.measurement_types.' . $kpi->measurement_type),
                    'frequency' => __('strategic.frequencies.' . $kpi->frequency),
                    'achievement' => $kpi->achievement,
                    'status' => __('strategic.kpi_statuses.' . $kpi->status),
                    'Actions' => $this->rowActions($kpi),
                ];
            }
        );
    }

    public function store(Request $request)
    {
        if ($failed = $this->validateJson($request, $this->rules())) {
            return $failed;
        }
        $kpi = DB::transaction(function () use ($request) {
            $kpi = StrategicKpi::create($this->payload($request) + [
                'created_by' => auth()->id(),
                'updated_by' => auth()->id(),
                'status' => 'not_started',
            ]);
            if ($request->filled('strategic_objective_id')) {
                $objective = StrategicObjective::findOrFail($request->strategic_objective_id);
                $this->authorizeRecord($objective);
                $kpi->objectives()->syncWithoutDetaching([$objective->id => ['weight' => $request->input('link_weight', 1)]]);
            }
            StrategicLogger::log($kpi, 'created', $kpi->name);

            return $kpi;
        });

        return $this->ok(__('strategic.Saved'), ['id' => $kpi->id]);
    }

    public function edit($id)
    {
        $kpi = StrategicKpi::findOrFail($id);
        $this->authorizeRecord($kpi);

        return $this->ok(__('strategic.Loaded'), ['data' => $kpi]);
    }

    public function update(Request $request, $id)
    {
        $kpi = StrategicKpi::findOrFail($id);
        $this->authorizeRecord($kpi);
        if ($failed = $this->validateJson($request, $this->rules($kpi->id))) {
            return $failed;
        }
        $kpi->update($this->payload($request) + ['updated_by' => auth()->id()]);
        StrategicLogger::log($kpi, 'updated', $kpi->name);

        return $this->ok(__('strategic.Saved'));
    }

    public function destroy($id)
    {
        $kpi = StrategicKpi::findOrFail($id);
        $this->authorizeRecord($kpi);
        if ($kpi->measurements()->exists()) {
            return $this->fail(__('strategic.HistoryPreventsDelete'), 423);
        }
        $kpi->objectives()->detach();
        StrategicLogger::log($kpi, 'deleted', $kpi->name);
        $kpi->delete();

        return $this->ok(__('strategic.Deleted'));
    }

    public function measure(Request $request, $id)
    {
        $kpi = StrategicKpi::findOrFail($id);
        $this->authorizeRecord($kpi);
        if ($failed = $this->validateJson($request, [
            'actual_value' => ['required', 'numeric'],
            'measurement_date' => ['required', 'date'],
            'reporting_period' => ['nullable', 'string', 'max:40'],
            'evidence' => ['nullable', 'string', 'max:500'],
            'comments' => ['nullable', 'string', 'max:5000'],
        ])) {
            return $failed;
        }
        StrategicKpiService::record($kpi, $request->only([
            'actual_value', 'measurement_date', 'reporting_period', 'evidence', 'comments',
        ]));

        return $this->ok(__('strategic.Saved'));
    }

    public function decideMeasurement(Request $request, $id, $measurementId)
    {
        if (!auth()->user()->hasPermission('strategic_plan.approve')) {
            return $this->fail(__('locale.YouDonotHavePermissionToDoThat'), 403);
        }
        $measurement = StrategicKpiMeasurement::where('strategic_kpi_id', $id)->findOrFail($measurementId);
        $this->authorizeRecord($measurement->kpi);
        if ($failed = $this->validateJson($request, [
            'decision' => ['required', Rule::in(['approved', 'rejected'])],
        ])) {
            return $failed;
        }
        StrategicKpiService::decide($measurement, $request->decision);

        return $this->ok(__('strategic.Saved'));
    }

    protected function rules($id = null): array
    {
        return [
            'name' => ['required', 'string', 'max:200'],
            'code' => ['required', 'string', 'max:50', Rule::unique('strategic_kpis', 'code')->ignore($id)->whereNull('deleted_at')],
            'description' => ['nullable', 'string'],
            'measurement_type' => ['required', Rule::in(['percentage', 'numeric', 'currency', 'boolean', 'rating', 'custom'])],
            'measurement_unit' => ['nullable', 'string', 'max:50'],
            'baseline_value' => ['nullable', 'numeric'],
            'target_value' => ['nullable', 'numeric'],
            'frequency' => ['required', Rule::in(['daily', 'weekly', 'monthly', 'quarterly', 'semiannually', 'annually'])],
            'direction' => ['required', Rule::in(['higher', 'lower'])],
            'on_track_threshold' => ['required', 'numeric', 'min:0', 'max:100'],
            'at_risk_threshold' => ['required', 'numeric', 'min:0', 'max:100', 'lte:on_track_threshold'],
            'owner_id' => ['nullable', 'exists:users,id'],
            'department_id' => ['nullable', 'exists:departments,id'],
            'start_date' => ['nullable', 'date'],
            'target_date' => ['nullable', 'date', 'after_or_equal:start_date'],
            'strategic_objective_id' => ['nullable', 'exists:strategic_objectives,id'],
            'link_weight' => ['nullable', 'numeric', 'min:0.01', 'max:100'],
        ];
    }

    protected function payload(Request $request): array
    {
        return $request->only([
            'name', 'code', 'description', 'measurement_type', 'measurement_unit', 'baseline_value',
            'target_value', 'frequency', 'direction', 'on_track_threshold', 'at_risk_threshold',
            'owner_id', 'department_id', 'start_date', 'target_date',
        ]);
    }
}
