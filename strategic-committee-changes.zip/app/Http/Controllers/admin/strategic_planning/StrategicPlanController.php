<?php

namespace App\Http\Controllers\admin\strategic_planning;

use App\Models\StrategicAttachment;
use App\Models\StrategicPlan;
use App\Services\Strategic\StrategicAccess;
use App\Services\Strategic\StrategicListResponder;
use App\Services\Strategic\StrategicLogger;
use App\Services\Strategic\StrategicProgressService;
use App\Services\Strategic\StrategicWorkflowService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;

class StrategicPlanController extends StrategicController
{
    public function index()
    {
        $options = $this->options();
        $breadcrumbs = $this->crumbs([['name' => __('locale.StrategicPlans')]]);

        return view('admin.content.strategic_planning.plans.index', compact('options', 'breadcrumbs'));
    }

    public function show($id)
    {
        $plan = StrategicPlan::with([
            'department', 'owner', 'approver', 'goals.objectives', 'versions.creator', 'approvals.actor', 'attachments.uploader',
        ])->findOrFail($id);
        $this->authorizeRecord($plan);
        $breadcrumbs = $this->crumbs([
            ['link' => route('admin.strategic.plans.index'), 'name' => __('locale.StrategicPlans')],
            ['name' => $plan->name],
        ]);
        $options = $this->options();

        return view('admin.content.strategic_planning.plans.show', compact('plan', 'breadcrumbs', 'options'));
    }

    public function ajaxList(Request $request)
    {
        $query = StrategicAccess::scopePlans(StrategicPlan::query(), auth()->user())->with(['owner:id,name', 'department']);

        return StrategicListResponder::respond(
            $query,
            $request,
            ['name', 'code', 'description', 'status'],
            ['id', 'name', 'code', 'status', 'start_date', 'end_date', 'calculated_progress'],
            function (StrategicPlan $plan) {
                return [
                    'id' => $plan->id,
                    'name' => $plan->name,
                    'code' => $plan->code,
                    'status' => __('strategic.plan_statuses.' . $plan->status),
                    'owner' => optional($plan->owner)->name,
                    'department' => optional($plan->department)->name,
                    'start_date' => optional($plan->start_date)->toDateString(),
                    'end_date' => optional($plan->end_date)->toDateString(),
                    'progress' => $plan->displayedProgress(),
                    'Actions' => $this->rowActions($plan),
                ];
            }
        );
    }

    public function store(Request $request)
    {
        if ($failed = $this->validateJson($request, $this->rules())) {
            return $failed;
        }

        $plan = DB::transaction(function () use ($request) {
            $plan = StrategicPlan::create($this->payload($request) + [
                'status' => 'draft',
                'version_number' => 1,
                'created_by' => auth()->id(),
                'updated_by' => auth()->id(),
            ]);
            StrategicLogger::log($plan, 'created', $plan->name);

            return $plan;
        });

        return $this->ok(__('strategic.Saved'), ['id' => $plan->id]);
    }

    public function edit($id)
    {
        $plan = StrategicPlan::findOrFail($id);
        $this->authorizeRecord($plan);

        return $this->ok(__('strategic.Loaded'), ['data' => $plan]);
    }

    public function update(Request $request, $id)
    {
        $plan = StrategicPlan::findOrFail($id);
        $this->authorizeRecord($plan);
        if ($locked = $this->structureLock($plan)) {
            return $locked;
        }
        if ($failed = $this->validateJson($request, $this->rules($plan->id))) {
            return $failed;
        }

        DB::transaction(function () use ($request, $plan) {
            $plan->update($this->payload($request) + ['updated_by' => auth()->id()]);
            StrategicLogger::log($plan, 'updated', $plan->name);
        });

        return $this->ok(__('strategic.Saved'));
    }

    public function destroy($id)
    {
        $plan = StrategicPlan::findOrFail($id);
        $this->authorizeRecord($plan);
        if (!in_array($plan->status, ['draft', 'rejected'], true)) {
            return $this->fail(__('strategic.DeleteOnlyDraft'), 423);
        }
        DB::transaction(function () use ($plan) {
            $plan->load('goals.objectives.initiatives.milestones');
            foreach ($plan->goals as $goal) {
                foreach ($goal->objectives as $objective) {
                    foreach ($objective->initiatives as $initiative) {
                        foreach ($initiative->milestones as $milestone) {
                            $milestone->delete();
                        }
                        $initiative->delete();
                    }
                    $objective->delete();
                }
                $goal->delete();
            }
            StrategicLogger::log($plan, 'deleted', $plan->name);
            $plan->delete();
        });

        return $this->ok(__('strategic.Deleted'));
    }

    public function workflow(Request $request, $id)
    {
        $plan = StrategicPlan::with('department')->findOrFail($id);
        $this->authorizeRecord($plan);
        $result = StrategicWorkflowService::act($plan, (string) $request->input('action'), $request->input('comment'));
        if (!$result['ok']) {
            return $this->fail($result['message'], $result['code'] ?? 422);
        }

        return $this->ok($result['message']);
    }

    public function override(Request $request, $id)
    {
        $plan = StrategicPlan::findOrFail($id);
        $this->authorizeRecord($plan);
        if ($failed = $this->validateJson($request, [
            'manual_progress' => ['required', 'numeric', 'min:0', 'max:100'],
            'reason' => ['required', 'string', 'max:1000'],
        ])) {
            return $failed;
        }
        if (!auth()->user()->hasPermission('strategic_plan.update')) {
            return $this->fail(__('locale.YouDonotHavePermissionToDoThat'), 403);
        }
        StrategicProgressService::override($plan, (float) $request->manual_progress, $request->reason);

        return $this->ok(__('strategic.Saved'));
    }

    public function upload(Request $request, $id)
    {
        $plan = StrategicPlan::findOrFail($id);
        $this->authorizeRecord($plan);
        if ($locked = $this->structureLock($plan)) {
            return $locked;
        }
        if ($failed = $this->validateJson($request, [
            'file' => ['required', 'file', 'max:10240', 'mimes:pdf,doc,docx,xls,xlsx,png,jpg,jpeg,txt'],
        ])) {
            return $failed;
        }
        $file = $request->file('file');
        $path = $file->store('strategic-planning/plans/' . $plan->id, 'public');
        $attachment = StrategicAttachment::create([
            'attachable_type' => StrategicPlan::class,
            'attachable_id' => $plan->id,
            'original_name' => $file->getClientOriginalName(),
            'path' => $path,
            'mime' => $file->getClientMimeType(),
            'size' => $file->getSize(),
            'uploaded_by' => auth()->id(),
        ]);
        StrategicLogger::log($plan, 'attachment_added', $attachment->original_name);

        return $this->ok(__('strategic.Saved'));
    }

    public function deleteAttachment($id, $attachmentId)
    {
        $plan = StrategicPlan::findOrFail($id);
        $this->authorizeRecord($plan);
        if ($locked = $this->structureLock($plan)) {
            return $locked;
        }
        $attachment = StrategicAttachment::where('attachable_type', StrategicPlan::class)
            ->where('attachable_id', $plan->id)
            ->findOrFail($attachmentId);
        Storage::disk('public')->delete($attachment->path);
        $attachment->delete();

        return $this->ok(__('strategic.Deleted'));
    }

    protected function rules($id = null): array
    {
        return [
            'name' => ['required', 'string', 'max:200'],
            'code' => ['required', 'string', 'max:50', Rule::unique('strategic_plans', 'code')->ignore($id)->whereNull('deleted_at')],
            'description' => ['nullable', 'string'],
            'vision' => ['nullable', 'string'],
            'mission' => ['nullable', 'string'],
            'strategic_priorities' => ['nullable', 'string'],
            'department_id' => ['nullable', 'exists:departments,id'],
            'owner_id' => ['required', 'exists:users,id'],
            'start_date' => ['required', 'date'],
            'end_date' => ['required', 'date', 'after_or_equal:start_date'],
        ];
    }

    protected function payload(Request $request): array
    {
        return $request->only([
            'name', 'code', 'description', 'vision', 'mission', 'strategic_priorities',
            'department_id', 'owner_id', 'start_date', 'end_date',
        ]);
    }
}
