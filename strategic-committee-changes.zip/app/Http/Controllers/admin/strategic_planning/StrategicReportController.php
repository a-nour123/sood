<?php

namespace App\Http\Controllers\admin\strategic_planning;

use App\Exports\StrategicTabularExport;
use App\Models\Department;
use App\Services\Strategic\StrategicDashboardService;
use App\Services\Strategic\StrategicReportService;
use Dompdf\Dompdf;
use Dompdf\Options;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;

class StrategicReportController extends StrategicController
{
    public function index(Request $request)
    {
        $type = $request->input('type') ?: 'plans';
        $filters = $request->only(['plan_id', 'department_id', 'year', 'status']);
        $rows = StrategicReportService::rows(auth()->user(), $type, $filters);
        $headings = StrategicReportService::headings($type);
        $plans = StrategicDashboardService::filterPlans(auth()->user());
        $departments = Department::orderBy('id')->get();
        $breadcrumbs = $this->crumbs([['name' => __('locale.StrategicReports')]]);

        return view('admin.content.strategic_planning.reports.index', compact(
            'type', 'filters', 'rows', 'headings', 'plans', 'departments', 'breadcrumbs'
        ));
    }

    public function excel(Request $request)
    {
        $type = $request->input('type') ?: 'plans';
        $rows = StrategicReportService::rows(auth()->user(), $type, $request->only(['plan_id', 'department_id', 'year', 'status']));
        $headings = array_map(function ($heading) {
            return __('strategic.headings.' . $heading);
        }, StrategicReportService::headings($type));

        return Excel::download(new StrategicTabularExport($headings, $rows), 'strategic-' . $type . '.xlsx');
    }

    public function pdf(Request $request)
    {
        $type = $request->input('type') ?: 'plans';
        $rows = StrategicReportService::rows(auth()->user(), $type, $request->only(['plan_id', 'department_id', 'year', 'status']));
        $headings = array_map(function ($heading) {
            return __('strategic.headings.' . $heading);
        }, StrategicReportService::headings($type));
        $html = view('admin.content.strategic_planning.reports.pdf', [
            'title' => __('strategic.report_types.' . $type),
            'headings' => $headings,
            'rows' => $rows,
        ])->render();
        $options = new Options();
        $options->set('defaultFont', 'DejaVu Sans');
        $options->set('isRemoteEnabled', false);
        $dompdf = new Dompdf($options);
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'landscape');
        $dompdf->render();

        return response($dompdf->output(), 200, [
            'Content-Type' => 'application/pdf',
            'Content-Disposition' => 'attachment; filename="strategic-' . $type . '.pdf"',
        ]);
    }
}
