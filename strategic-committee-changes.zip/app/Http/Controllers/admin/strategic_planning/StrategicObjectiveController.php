<?php

namespace App\Http\Controllers\admin\strategic_planning;

use App\Models\Framework;
use App\Models\FrameworkControl;
use App\Models\FrameworkControlTest;
use App\Models\FrameworkControlTestAudit;
use App\Models\Risk;
use App\Models\StrategicComplianceLink;
use App\Models\StrategicGoal;
use App\Models\StrategicKpi;
use App\Models\StrategicObjective;
use App\Models\StrategicObjectiveRisk;
use App\Services\Strategic\StrategicAccess;
use App\Services\Strategic\StrategicListResponder;
use App\Services\Strategic\StrategicLogger;
use App\Services\Strategic\StrategicProgressService;
use App\Services\Strategic\StrategicRiskReader;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class StrategicObjectiveController extends StrategicController
{
    public function index()
    {
        $options = $this->options();
        $options['goals'] = StrategicGoal::with('plan:id,name')->orderBy('name')->get();
        $breadcrumbs = $this->crumbs([['name' => __('locale.StrategicObjectives')]]);

        return view('admin.content.strategic_planning.objectives.index', compact('options', 'breadcrumbs'));
    }

    public function show($id)
    {
        $objective = StrategicObjective::with([
            'goal.plan', 'owner', 'department', 'initiatives', 'kpis',
            'riskAssociations.risk.riskScoring', 'riskAssociations.risk.mitigation.planningStrategies',
            'complianceLinks.framework', 'complianceLinks.family', 'complianceLinks.control', 'complianceLinks.test', 'complianceLinks.audit',
            'progressHistories.subject',
        ])->findOrFail($id);
        $this->authorizeRecord($objective);
        $breadcrumbs = $this->crumbs([
            ['link' => route('admin.strategic.objectives.index'), 'name' => __('locale.StrategicObjectives')],
            ['name' => $objective->name],
        ]);
        $frameworks = Framework::orderBy('name')->get(['id', 'name']);
        $kpis = StrategicKpi::orderBy('name')->get(['id', 'name', 'code']);

        return view('admin.content.strategic_planning.objectives.show', compact('objective', 'breadcrumbs', 'frameworks', 'kpis'));
    }

    public function ajaxList(Request $request)
    {
        $query = StrategicAccess::scopeByPlan(StrategicObjective::query(), auth()->user(), 'goal.plan')
            ->with(['goal.plan', 'owner:id,name']);

        return StrategicListResponder::respond(
            $query,
            $request,
            ['name', 'code', 'description', 'status'],
            ['id', 'name', 'code', 'status', 'due_date', 'weight', 'calculated_progress'],
            function (StrategicObjective $objective) {
                return [
                    'id' => $objective->id,
                    'name' => $objective->name,
                    'code' => $objective->code,
                    'goal' => optional($objective->goal)->name,
                    'status' => __('strategic.work_statuses.' . $objective->status),
                    'progress' => $objective->displayedProgress(),
                    'due_date' => optional($objective->due_date)->toDateString(),
                    'delayed' => $objective->isDelayed() ? __('strategic.Yes') : __('strategic.No'),
                    'Actions' => $this->rowActions($objective),
                ];
            }
        );
    }

    public function store(Request $request)
    {
        $goal = StrategicGoal::with('plan')->findOrFail($request->input('strategic_goal_id'));
        $this->authorizeRecord($goal);
        if ($locked = $this->structureLock($goal->plan)) {
            return $locked;
        }
        if ($failed = $this->validateJson($request, $this->rules($goal->id))) {
            return $failed;
        }
        $objective = DB::transaction(function () use ($request, $goal) {
            $objective = StrategicObjective::create($request->only([
                'strategic_goal_id', 'name', 'code', 'description', 'owner_id', 'department_id',
                'priority', 'weight', 'start_date', 'due_date', 'target_value', 'measurement_unit',
                'status', 'progress_basis', 'sort_order',
            ]) + ['created_by' => auth()->id(), 'updated_by' => auth()->id()]);
            StrategicProgressService::recalculateObjective($objective);
            StrategicLogger::log($goal->plan, 'objective_created', $objective->name);

            return $objective;
        });

        return $this->ok(__('strategic.Saved'), ['id' => $objective->id]);
    }

    public function edit($id)
    {
        $objective = StrategicObjective::findOrFail($id);
        $this->authorizeRecord($objective);

        return $this->ok(__('strategic.Loaded'), ['data' => $objective]);
    }

    public function update(Request $request, $id)
    {
        $objective = StrategicObjective::with('goal.plan')->findOrFail($id);
        $this->authorizeRecord($objective);
        if ($locked = $this->structureLock($objective->goal->plan)) {
            return $locked;
        }
        if ($failed = $this->validateJson($request, $this->rules($objective->strategic_goal_id, $objective->id))) {
            return $failed;
        }
        DB::transaction(function () use ($request, $objective) {
            $objective->update($request->only([
                'name', 'code', 'description', 'owner_id', 'department_id', 'priority', 'weight',
                'start_date', 'due_date', 'target_value', 'measurement_unit', 'status', 'progress_basis', 'sort_order',
            ]) + ['updated_by' => auth()->id()]);
            StrategicProgressService::recalculateObjective($objective);
            StrategicLogger::log($objective, 'updated', $objective->name);
        });

        return $this->ok(__('strategic.Saved'));
    }

    public function destroy($id)
    {
        $objective = StrategicObjective::with('goal.plan')->findOrFail($id);
        $this->authorizeRecord($objective);
        if ($locked = $this->structureLock($objective->goal->plan)) {
            return $locked;
        }
        DB::transaction(function () use ($objective) {
            $goal = $objective->goal;
            $objective->load('initiatives.milestones');
            foreach ($objective->initiatives as $initiative) {
                foreach ($initiative->milestones as $milestone) {
                    $milestone->delete();
                }
                $initiative->delete();
            }
            StrategicLogger::log($objective, 'deleted', $objective->name);
            $objective->delete();
            StrategicProgressService::recalculateGoal($goal);
        });

        return $this->ok(__('strategic.Deleted'));
    }

    public function override(Request $request, $id)
    {
        $objective = StrategicObjective::findOrFail($id);
        $this->authorizeRecord($objective);
        if ($failed = $this->validateJson($request, [
            'manual_progress' => ['required', 'numeric', 'min:0', 'max:100'],
            'reason' => ['required', 'string', 'max:1000'],
        ])) {
            return $failed;
        }
        StrategicProgressService::override($objective, (float) $request->manual_progress, $request->reason);

        return $this->ok(__('strategic.Saved'));
    }

    public function attachKpi(Request $request, $id)
    {
        $objective = StrategicObjective::with('goal.plan')->findOrFail($id);
        $this->authorizeRecord($objective);
        if ($locked = $this->structureLock($objective->goal->plan)) {
            return $locked;
        }
        if ($failed = $this->validateJson($request, [
            'strategic_kpi_id' => ['required', 'exists:strategic_kpis,id'],
            'weight' => ['required', 'numeric', 'min:0.01', 'max:100'],
        ])) {
            return $failed;
        }
        $objective->kpis()->syncWithoutDetaching([
            $request->strategic_kpi_id => ['weight' => $request->weight],
        ]);
        StrategicProgressService::recalculateObjective($objective);

        return $this->ok(__('strategic.Saved'));
    }

    public function detachKpi($id, $kpiId)
    {
        $objective = StrategicObjective::with('goal.plan')->findOrFail($id);
        $this->authorizeRecord($objective);
        if ($locked = $this->structureLock($objective->goal->plan)) {
            return $locked;
        }
        $objective->kpis()->detach($kpiId);
        StrategicProgressService::recalculateObjective($objective);

        return $this->ok(__('strategic.Deleted'));
    }

    public function linkRisk(Request $request, $id)
    {
        $objective = StrategicObjective::with('goal.plan')->findOrFail($id);
        $this->authorizeRecord($objective);
        if ($failed = $this->validateJson($request, [
            'risk_id' => ['required', 'exists:risks,id'],
            'notes' => ['nullable', 'string', 'max:2000'],
        ])) {
            return $failed;
        }
        $risk = Risk::with('riskScoring')->findOrFail($request->risk_id);
        $existing = StrategicObjectiveRisk::where('strategic_objective_id', $objective->id)
            ->where('risk_id', $risk->id)
            ->whereNull('unlinked_at')
            ->first();
        if ($existing) {
            return $this->fail(__('strategic.AlreadyLinked'));
        }
        $score = optional($risk->riskScoring)->calculated_risk;
        StrategicObjectiveRisk::create([
            'strategic_objective_id' => $objective->id,
            'risk_id' => $risk->id,
            'risk_snapshot' => mb_substr(strip_tags((string) $risk->subject), 0, 500),
            'score_at_link' => $score,
            'notes' => $request->notes,
            'linked_by' => auth()->id(),
        ]);
        StrategicLogger::log($objective, 'risk_linked', (string) $risk->id, ['risk_id' => $risk->id]);
        if (function_exists('write_log')) {
            write_log($risk->id, auth()->id(), __('strategic.RiskLinkedToObjective', ['objective' => $objective->name]), 'risk');
        }
        if ($score !== null && (float) $score >= StrategicRiskReader::criticalThreshold()) {
            event(new \App\Events\StrategicActionOccurred($objective, 'Strategic_Risk_Critical', [
                'owner_id' => $risk->owner_id,
            ]));
        }

        return $this->ok(__('strategic.Saved'));
    }

    public function unlinkRisk($id, $linkId)
    {
        $objective = StrategicObjective::findOrFail($id);
        $this->authorizeRecord($objective);
        $link = StrategicObjectiveRisk::where('strategic_objective_id', $objective->id)->findOrFail($linkId);
        $link->unlinked_at = now();
        $link->unlinked_by = auth()->id();
        $link->save();
        StrategicLogger::log($objective, 'risk_unlinked', (string) $link->risk_id);

        return $this->ok(__('strategic.Deleted'));
    }

    public function linkCompliance(Request $request, $id)
    {
        $objective = StrategicObjective::with('goal.plan')->findOrFail($id);
        $this->authorizeRecord($objective);
        if ($failed = $this->validateJson($request, [
            'framework_id' => ['nullable', 'exists:frameworks,id'],
            'family_id' => ['nullable', 'exists:families,id'],
            'framework_control_id' => ['nullable', 'exists:framework_controls,id'],
            'framework_control_test_id' => ['nullable', 'exists:framework_control_tests,id'],
            'framework_control_test_audit_id' => ['nullable', 'exists:framework_control_test_audits,id'],
            'gap_note' => ['nullable', 'string', 'max:5000'],
        ])) {
            return $failed;
        }
        if (!$request->framework_id && !$request->family_id && !$request->framework_control_id && !$request->framework_control_test_id && !$request->framework_control_test_audit_id && !$request->gap_note) {
            return $this->fail(__('strategic.ComplianceTargetRequired'));
        }
        $framework = $request->framework_id ? Framework::find($request->framework_id) : null;
        StrategicComplianceLink::create([
            'linkable_type' => StrategicObjective::class,
            'linkable_id' => $objective->id,
            'framework_id' => $request->framework_id,
            'family_id' => $request->family_id,
            'framework_control_id' => $request->framework_control_id,
            'framework_control_test_id' => $request->framework_control_test_id,
            'framework_control_test_audit_id' => $request->framework_control_test_audit_id,
            'framework_snapshot' => $framework ? $framework->name : null,
            'gap_note' => $request->gap_note,
            'created_by' => auth()->id(),
        ]);
        StrategicLogger::log($objective, 'compliance_linked', $objective->name);

        return $this->ok(__('strategic.Saved'));
    }

    public function unlinkCompliance($id, $linkId)
    {
        $objective = StrategicObjective::findOrFail($id);
        $this->authorizeRecord($objective);
        StrategicComplianceLink::where('linkable_type', StrategicObjective::class)
            ->where('linkable_id', $objective->id)
            ->where('id', $linkId)
            ->delete();

        return $this->ok(__('strategic.Deleted'));
    }

    protected function rules(int $goalId, $id = null): array
    {
        return [
            'strategic_goal_id' => ['required', 'exists:strategic_goals,id'],
            'name' => ['required', 'string', 'max:200'],
            'code' => ['required', 'string', 'max:50', Rule::unique('strategic_objectives', 'code')->ignore($id)->where(function ($query) use ($goalId) {
                return $query->where('strategic_goal_id', $goalId)->whereNull('deleted_at');
            })],
            'description' => ['nullable', 'string'],
            'owner_id' => ['nullable', 'exists:users,id'],
            'department_id' => ['nullable', 'exists:departments,id'],
            'priority' => ['required', Rule::in(['low', 'medium', 'high', 'critical'])],
            'weight' => ['required', 'numeric', 'min:0.01', 'max:100'],
            'start_date' => ['nullable', 'date'],
            'due_date' => ['nullable', 'date', 'after_or_equal:start_date'],
            'target_value' => ['nullable', 'numeric'],
            'measurement_unit' => ['nullable', 'string', 'max:50'],
            'status' => ['required', Rule::in(['not_started', 'in_progress', 'at_risk', 'delayed', 'completed', 'cancelled'])],
            'progress_basis' => ['required', Rule::in(['initiatives', 'kpis'])],
            'sort_order' => ['nullable', 'integer', 'min:0'],
        ];
    }
}
