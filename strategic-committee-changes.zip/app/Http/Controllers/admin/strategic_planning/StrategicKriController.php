<?php

namespace App\Http\Controllers\admin\strategic_planning;

use App\Models\Risk;
use App\Models\StrategicKri;
use App\Services\Strategic\StrategicAccess;
use App\Services\Strategic\StrategicKriService;
use App\Services\Strategic\StrategicListResponder;
use App\Services\Strategic\StrategicLogger;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class StrategicKriController extends StrategicController
{
    public function index()
    {
        $options = $this->options();
        $breadcrumbs = $this->crumbs([['name' => __('locale.StrategicKris')]]);

        return view('admin.content.strategic_planning.kris.index', compact('options', 'breadcrumbs'));
    }

    public function show($id)
    {
        $kri = StrategicKri::with(['owner', 'department', 'risk.riskScoring', 'measurements.submitter'])->findOrFail($id);
        $this->authorizeRecord($kri);
        $breadcrumbs = $this->crumbs([
            ['link' => route('admin.strategic.kris.index'), 'name' => __('locale.StrategicKris')],
            ['name' => $kri->name],
        ]);

        return view('admin.content.strategic_planning.kris.show', compact('kri', 'breadcrumbs'));
    }

    public function ajaxList(Request $request)
    {
        $query = StrategicKri::query()->with(['owner:id,name', 'risk:id,subject']);
        if (!StrategicAccess::isAdmin(auth()->user())) {
            $user = auth()->user();
            $query->where(function ($inner) use ($user) {
                $inner->where('owner_id', $user->id)->orWhere('created_by', $user->id);
                if ($user->department_id) {
                    $inner->orWhere('department_id', $user->department_id)->orWhereNull('department_id');
                }
            });
        }

        return StrategicListResponder::respond(
            $query,
            $request,
            ['name', 'description', 'status'],
            ['id', 'name', 'status', 'current_value'],
            function (StrategicKri $kri) {
                return [
                    'id' => $kri->id,
                    'name' => $kri->name,
                    'current_value' => $kri->current_value,
                    'warning_threshold' => $kri->warning_threshold,
                    'critical_threshold' => $kri->critical_threshold,
                    'status' => __('strategic.kri_levels.' . $kri->status),
                    'risk' => $kri->risk_snapshot ?: optional($kri->risk)->subject,
                    'Actions' => $this->rowActions($kri),
                ];
            }
        );
    }

    public function store(Request $request)
    {
        if ($failed = $this->validateJson($request, $this->rules())) {
            return $failed;
        }
        $kri = DB::transaction(function () use ($request) {
            $risk = $request->risk_id ? Risk::find($request->risk_id) : null;
            $kri = StrategicKri::create($this->payload($request) + [
                'risk_snapshot' => $risk ? mb_substr(strip_tags((string) $risk->subject), 0, 500) : null,
                'created_by' => auth()->id(),
                'updated_by' => auth()->id(),
            ]);
            StrategicLogger::log($kri, 'created', $kri->name);

            return $kri;
        });

        return $this->ok(__('strategic.Saved'), ['id' => $kri->id]);
    }

    public function edit($id)
    {
        $kri = StrategicKri::findOrFail($id);
        $this->authorizeRecord($kri);

        return $this->ok(__('strategic.Loaded'), ['data' => $kri]);
    }

    public function update(Request $request, $id)
    {
        $kri = StrategicKri::findOrFail($id);
        $this->authorizeRecord($kri);
        if ($failed = $this->validateJson($request, $this->rules())) {
            return $failed;
        }
        $payload = $this->payload($request);
        if ($request->risk_id) {
            $risk = Risk::find($request->risk_id);
            $payload['risk_snapshot'] = $risk ? mb_substr(strip_tags((string) $risk->subject), 0, 500) : $kri->risk_snapshot;
        }
        $kri->update($payload + ['updated_by' => auth()->id()]);
        StrategicLogger::log($kri, 'updated', $kri->name);

        return $this->ok(__('strategic.Saved'));
    }

    public function destroy($id)
    {
        $kri = StrategicKri::findOrFail($id);
        $this->authorizeRecord($kri);
        if ($kri->measurements()->exists()) {
            return $this->fail(__('strategic.HistoryPreventsDelete'), 423);
        }
        StrategicLogger::log($kri, 'deleted', $kri->name);
        $kri->delete();

        return $this->ok(__('strategic.Deleted'));
    }

    public function measure(Request $request, $id)
    {
        $kri = StrategicKri::findOrFail($id);
        $this->authorizeRecord($kri);
        if ($failed = $this->validateJson($request, [
            'actual_value' => ['required', 'numeric'],
            'measurement_date' => ['required', 'date'],
            'comments' => ['nullable', 'string', 'max:5000'],
        ])) {
            return $failed;
        }
        StrategicKriService::record($kri, $request->only(['actual_value', 'measurement_date', 'comments']));

        return $this->ok(__('strategic.Saved'));
    }

    protected function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:200'],
            'description' => ['nullable', 'string'],
            'measurement_unit' => ['nullable', 'string', 'max:50'],
            'warning_threshold' => ['nullable', 'numeric'],
            'critical_threshold' => ['nullable', 'numeric'],
            'measurement_frequency' => ['required', Rule::in(['daily', 'weekly', 'monthly', 'quarterly', 'semiannually', 'annually'])],
            'direction' => ['required', Rule::in(['higher', 'lower'])],
            'owner_id' => ['nullable', 'exists:users,id'],
            'department_id' => ['nullable', 'exists:departments,id'],
            'risk_id' => ['nullable', 'exists:risks,id'],
        ];
    }

    protected function payload(Request $request): array
    {
        return $request->only([
            'name', 'description', 'measurement_unit', 'warning_threshold', 'critical_threshold',
            'measurement_frequency', 'direction', 'owner_id', 'department_id', 'risk_id',
        ]);
    }
}
