<?php

namespace App\Http\Controllers\admin\strategic_planning;

use App\Models\StrategicAttachment;
use App\Models\StrategicInitiative;
use App\Models\StrategicMilestone;
use App\Services\Strategic\PlanWorkflow;
use App\Services\Strategic\StrategicListResponder;
use App\Services\Strategic\StrategicLogger;
use App\Services\Strategic\StrategicProgressService;
use App\Services\Strategic\StrategicTaskBridge;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;

class StrategicMilestoneController extends StrategicController
{
    public function index()
    {
        $options = $this->options();
        $options['initiatives'] = StrategicInitiative::orderBy('name')->get(['id', 'name']);
        $breadcrumbs = $this->crumbs([['name' => __('locale.StrategicMilestones')]]);

        return view('admin.content.strategic_planning.milestones.index', compact('options', 'breadcrumbs'));
    }

    public function ajaxList(Request $request)
    {
        $query = StrategicMilestone::query()->whereHas('initiative.objective.goal.plan', function ($plan) {
            \App\Services\Strategic\StrategicAccess::scopePlans($plan, auth()->user());
        })->with(['initiative:id,name', 'owner:id,name']);

        return StrategicListResponder::respond(
            $query,
            $request,
            ['name', 'description', 'status'],
            ['id', 'name', 'status', 'planned_due_date', 'completion_percentage', 'weight'],
            function (StrategicMilestone $milestone) {
                return [
                    'id' => $milestone->id,
                    'name' => $milestone->name,
                    'initiative' => optional($milestone->initiative)->name,
                    'status' => __('strategic.work_statuses.' . $milestone->status),
                    'planned_due_date' => optional($milestone->planned_due_date)->toDateString(),
                    'actual_completion_date' => optional($milestone->actual_completion_date)->toDateString(),
                    'completion' => $milestone->completion_percentage,
                    'overdue' => $milestone->isOverdue() ? __('strategic.Yes') : __('strategic.No'),
                    'Actions' => $this->rowActions($milestone),
                ];
            }
        );
    }

    public function store(Request $request)
    {
        $initiative = StrategicInitiative::with('objective.goal.plan')->findOrFail($request->strategic_initiative_id);
        $this->authorizeRecord($initiative);
        if ($locked = $this->structureLock($initiative->objective->goal->plan)) {
            return $locked;
        }
        if ($failed = $this->validateJson($request, $this->rules())) {
            return $failed;
        }
        DB::transaction(function () use ($request) {
            $milestone = StrategicMilestone::create($request->only([
                'strategic_initiative_id', 'name', 'description', 'owner_id', 'planned_start_date',
                'planned_due_date', 'weight', 'completion_percentage', 'status', 'sort_order',
            ]) + ['created_by' => auth()->id(), 'updated_by' => auth()->id()]);
            StrategicProgressService::recalculateFromMilestone($milestone);
            StrategicLogger::log($milestone->initiative, 'milestone_created', $milestone->name);
        });

        return $this->ok(__('strategic.Saved'));
    }

    public function edit($id)
    {
        $milestone = StrategicMilestone::findOrFail($id);
        $this->authorizeRecord($milestone);

        return $this->ok(__('strategic.Loaded'), ['data' => $milestone]);
    }

    public function update(Request $request, $id)
    {
        $milestone = StrategicMilestone::with('initiative.objective.goal.plan')->findOrFail($id);
        $this->authorizeRecord($milestone);
        $plan = $milestone->initiative->objective->goal->plan;
        $editable = PlanWorkflow::structureEditable($plan->status);
        if (!$editable && ($locked = $this->executionLock($plan))) {
            return $locked;
        }
        if ($failed = $this->validateJson($request, $this->rules())) {
            return $failed;
        }
        DB::transaction(function () use ($request, $milestone, $editable) {
            $fields = $editable
                ? ['name', 'description', 'owner_id', 'planned_start_date', 'planned_due_date', 'weight', 'completion_percentage', 'actual_completion_date', 'status', 'sort_order']
                : ['completion_percentage', 'actual_completion_date', 'status'];
            $milestone->update($request->only($fields) + ['updated_by' => auth()->id()]);
            if ((float) $milestone->completion_percentage >= 100 && !$milestone->actual_completion_date) {
                $milestone->actual_completion_date = now()->toDateString();
                $milestone->status = 'completed';
                $milestone->save();
            }
            StrategicProgressService::recalculateFromMilestone($milestone);
            StrategicLogger::log($milestone, 'updated', $milestone->name);
        });

        return $this->ok(__('strategic.Saved'));
    }

    public function destroy($id)
    {
        $milestone = StrategicMilestone::with('initiative.objective.goal.plan')->findOrFail($id);
        $this->authorizeRecord($milestone);
        if ($locked = $this->structureLock($milestone->initiative->objective->goal->plan)) {
            return $locked;
        }
        DB::transaction(function () use ($milestone) {
            $initiative = $milestone->initiative;
            StrategicLogger::log($milestone, 'deleted', $milestone->name);
            $milestone->delete();
            StrategicProgressService::recalculateInitiative($initiative);
        });

        return $this->ok(__('strategic.Deleted'));
    }

    public function upload(Request $request, $id)
    {
        $milestone = StrategicMilestone::with('initiative.objective.goal.plan')->findOrFail($id);
        $this->authorizeRecord($milestone);
        if ($locked = $this->executionLock($milestone->initiative->objective->goal->plan)) {
            return $locked;
        }
        if ($failed = $this->validateJson($request, [
            'file' => ['required', 'file', 'max:10240', 'mimes:pdf,doc,docx,xls,xlsx,png,jpg,jpeg,txt'],
        ])) {
            return $failed;
        }
        $file = $request->file('file');
        $path = $file->store('strategic-planning/milestones/' . $milestone->id, 'public');
        StrategicAttachment::create([
            'attachable_type' => StrategicMilestone::class,
            'attachable_id' => $milestone->id,
            'original_name' => $file->getClientOriginalName(),
            'path' => $path,
            'mime' => $file->getClientMimeType(),
            'size' => $file->getSize(),
            'uploaded_by' => auth()->id(),
        ]);
        StrategicLogger::log($milestone, 'attachment_added', $milestone->name);

        return $this->ok(__('strategic.Saved'));
    }

    public function deleteAttachment($id, $attachmentId)
    {
        $milestone = StrategicMilestone::findOrFail($id);
        $this->authorizeRecord($milestone);
        $attachment = $milestone->attachments()->findOrFail($attachmentId);
        Storage::disk('public')->delete($attachment->path);
        $attachment->delete();

        return $this->ok(__('strategic.Deleted'));
    }

    public function createTask(Request $request, $id)
    {
        $milestone = StrategicMilestone::with('initiative.objective.goal.plan')->findOrFail($id);
        $this->authorizeRecord($milestone);
        if ($locked = $this->executionLock($milestone->initiative->objective->goal->plan)) {
            return $locked;
        }
        if ($failed = $this->validateJson($request, [
            'title' => ['required', 'string', 'max:100'],
            'description' => ['nullable', 'string'],
            'assignee_id' => ['required', 'exists:users,id'],
            'due_date' => ['nullable', 'date'],
            'start_date' => ['nullable', 'date'],
        ])) {
            return $failed;
        }
        StrategicTaskBridge::create($milestone->initiative, $milestone, $request->only([
            'title', 'description', 'assignee_id', 'start_date', 'due_date',
        ]));

        return $this->ok(__('strategic.Saved'));
    }

    protected function rules(): array
    {
        return [
            'strategic_initiative_id' => ['required', 'exists:strategic_initiatives,id'],
            'name' => ['required', 'string', 'max:200'],
            'description' => ['nullable', 'string'],
            'owner_id' => ['nullable', 'exists:users,id'],
            'planned_start_date' => ['nullable', 'date'],
            'planned_due_date' => ['nullable', 'date', 'after_or_equal:planned_start_date'],
            'actual_completion_date' => ['nullable', 'date'],
            'weight' => ['required', 'numeric', 'min:0.01', 'max:100'],
            'completion_percentage' => ['required', 'numeric', 'min:0', 'max:100'],
            'status' => ['required', Rule::in(['not_started', 'in_progress', 'at_risk', 'delayed', 'completed', 'cancelled'])],
            'sort_order' => ['nullable', 'integer', 'min:0'],
        ];
    }
}
