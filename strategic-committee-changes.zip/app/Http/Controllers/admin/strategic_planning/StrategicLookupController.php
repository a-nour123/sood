<?php

namespace App\Http\Controllers\admin\strategic_planning;

use App\Models\Family;
use App\Models\Framework;
use App\Models\FrameworkControl;
use App\Models\FrameworkControlTest;
use App\Models\FrameworkControlTestAudit;
use App\Models\Risk;
use App\Models\Task;
use App\Models\User;
use Illuminate\Http\Request;

class StrategicLookupController extends StrategicController
{
    public function risks(Request $request)
    {
        $term = trim((string) $request->input('q', ''));
        $risks = Risk::query()
            ->when($term !== '', function ($query) use ($term) {
                $query->where('subject', 'like', '%' . $term . '%')->orWhere('id', $term);
            })
            ->orderByDesc('id')
            ->limit(30)
            ->get(['id', 'subject', 'status']);

        return $this->ok(__('strategic.Loaded'), ['data' => $risks]);
    }

    public function frameworks()
    {
        return $this->ok(__('strategic.Loaded'), [
            'data' => Framework::orderBy('name')->get(['id', 'name']),
        ]);
    }

    public function families(Request $request)
    {
        if ($request->filled('framework_id')) {
            $framework = Framework::with('families')->find($request->framework_id);
            $families = $framework ? $framework->families : collect();
        } else {
            $families = Family::query()->orderBy('id')->limit(200)->get();
        }

        return $this->ok(__('strategic.Loaded'), [
            'data' => $families->map(function (Family $family) {
                return ['id' => $family->id, 'name' => $family->name];
            })->values(),
        ]);
    }

    public function controls(Request $request)
    {
        $query = FrameworkControl::query()->orderBy('id');
        if ($request->filled('framework_id')) {
            $query->whereHas('Frameworks', function ($frameworks) use ($request) {
                $frameworks->where('frameworks.id', $request->framework_id);
            });
        }
        if ($request->filled('family_id')) {
            $query->where('family', $request->family_id);
        }

        return $this->ok(__('strategic.Loaded'), [
            'data' => $query->limit(200)->get(['id', 'short_name', 'control_number'])->map(function ($control) {
                return [
                    'id' => $control->id,
                    'name' => trim(($control->control_number ? $control->control_number . ' ' : '') . $control->short_name),
                ];
            }),
        ]);
    }

    public function tests(Request $request)
    {
        $query = FrameworkControlTest::query()->orderBy('id');
        if ($request->filled('framework_control_id')) {
            $query->where('framework_control_id', $request->framework_control_id);
        }

        return $this->ok(__('strategic.Loaded'), [
            'data' => $query->limit(100)->get(['id', 'name']),
        ]);
    }

    public function audits(Request $request)
    {
        $query = FrameworkControlTestAudit::query()->orderByDesc('id');
        if ($request->filled('framework_control_test_id')) {
            $query->where('test_id', $request->framework_control_test_id);
        }

        return $this->ok(__('strategic.Loaded'), [
            'data' => $query->limit(100)->get(['id']),
        ]);
    }

    public function tasks(Request $request)
    {
        $term = trim((string) $request->input('q', ''));
        $tasks = Task::query()
            ->when($term !== '', function ($query) use ($term) {
                $query->where('title', 'like', '%' . $term . '%');
            })
            ->orderByDesc('id')
            ->limit(30)
            ->get(['id', 'title', 'status', 'due_date']);

        return $this->ok(__('strategic.Loaded'), ['data' => $tasks]);
    }

    public function users(Request $request)
    {
        $users = User::query()
            ->when($request->filled('department_id'), function ($query) use ($request) {
                $query->where('department_id', $request->department_id);
            })
            ->orderBy('name')
            ->get(['id', 'name', 'department_id']);

        return $this->ok(__('strategic.Loaded'), ['data' => $users]);
    }
}
