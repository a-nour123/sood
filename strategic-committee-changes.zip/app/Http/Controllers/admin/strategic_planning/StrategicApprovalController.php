<?php

namespace App\Http\Controllers\admin\strategic_planning;

use App\Models\StrategicApproval;
use App\Models\StrategicPlan;
use App\Services\Strategic\StrategicAccess;

class StrategicApprovalController extends StrategicController
{
    public function index()
    {
        $planIds = StrategicAccess::scopePlans(StrategicPlan::query(), auth()->user())->pluck('id');
        $approvals = StrategicApproval::with(['plan', 'actor'])
            ->whereIn('strategic_plan_id', $planIds)
            ->orderByDesc('id')
            ->paginate(25);
        $breadcrumbs = $this->crumbs([['name' => __('locale.StrategicApprovals')]]);

        return view('admin.content.strategic_planning.approvals.index', compact('approvals', 'breadcrumbs'));
    }
}
