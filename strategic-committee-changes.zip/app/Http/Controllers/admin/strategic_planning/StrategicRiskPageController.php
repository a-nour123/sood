<?php

namespace App\Http\Controllers\admin\strategic_planning;

use App\Models\StrategicObjectiveRisk;
use App\Models\StrategicPlan;
use App\Services\Strategic\StrategicAccess;
use App\Services\Strategic\StrategicRiskReader;

class StrategicRiskPageController extends StrategicController
{
    public function index()
    {
        $planIds = StrategicAccess::scopePlans(StrategicPlan::query(), auth()->user())->pluck('id');
        $links = StrategicObjectiveRisk::with(['objective.goal.plan', 'risk.riskScoring', 'risk.mitigation.planningStrategies'])
            ->whereNull('unlinked_at')
            ->whereHas('objective.goal', function ($query) use ($planIds) {
                $query->whereIn('strategic_plan_id', $planIds);
            })
            ->orderByDesc('id')
            ->paginate(25);
        $high = StrategicRiskReader::highThreshold();
        $breadcrumbs = $this->crumbs([['name' => __('locale.StrategicRisks')]]);

        return view('admin.content.strategic_planning.risks.index', compact('links', 'high', 'breadcrumbs'));
    }
}
