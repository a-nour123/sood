<?php

namespace App\Http\Controllers\admin\strategic_planning;

use App\Models\StrategicComplianceLink;
use App\Models\StrategicInitiative;
use App\Models\StrategicObjective;
use App\Services\Strategic\PlanWorkflow;
use App\Services\Strategic\StrategicAccess;
use App\Services\Strategic\StrategicListResponder;
use App\Services\Strategic\StrategicLogger;
use App\Services\Strategic\StrategicProgressService;
use App\Services\Strategic\StrategicTaskBridge;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class StrategicInitiativeController extends StrategicController
{
    public function index()
    {
        $options = $this->options();
        $options['objectives'] = StrategicObjective::with('goal:id,name')->orderBy('name')->get();
        $breadcrumbs = $this->crumbs([['name' => __('locale.StrategicInitiatives')]]);

        return view('admin.content.strategic_planning.initiatives.index', compact('options', 'breadcrumbs'));
    }

    public function show($id)
    {
        $initiative = StrategicInitiative::with([
            'objective.goal.plan', 'owner', 'department', 'milestones.owner', 'milestones.attachments',
            'taskLinks.task.assignable', 'complianceLinks.framework', 'complianceLinks.control', 'activity.user',
        ])->findOrFail($id);
        $this->authorizeRecord($initiative);
        $taskCompletion = StrategicTaskBridge::completion($initiative);
        $breadcrumbs = $this->crumbs([
            ['link' => route('admin.strategic.initiatives.index'), 'name' => __('locale.StrategicInitiatives')],
            ['name' => $initiative->name],
        ]);
        $options = $this->options();

        return view('admin.content.strategic_planning.initiatives.show', compact('initiative', 'breadcrumbs', 'taskCompletion', 'options'));
    }

    public function ajaxList(Request $request)
    {
        $query = StrategicAccess::scopeByPlan(StrategicInitiative::query(), auth()->user(), 'objective.goal.plan')
            ->with(['objective:id,name', 'owner:id,name', 'department']);

        return StrategicListResponder::respond(
            $query,
            $request,
            ['name', 'code', 'description', 'status'],
            ['id', 'name', 'code', 'status', 'due_date', 'progress_percentage', 'estimated_budget'],
            function (StrategicInitiative $initiative) {
                return [
                    'id' => $initiative->id,
                    'name' => $initiative->name,
                    'code' => $initiative->code,
                    'objective' => optional($initiative->objective)->name,
                    'status' => __('strategic.work_statuses.' . $initiative->status),
                    'progress' => $initiative->displayedProgress(),
                    'budget' => $initiative->actual_budget . ' / ' . $initiative->estimated_budget,
                    'due_date' => optional($initiative->due_date)->toDateString(),
                    'delayed' => $initiative->isDelayed() ? __('strategic.Yes') : __('strategic.No'),
                    'Actions' => $this->rowActions($initiative),
                ];
            }
        );
    }

    public function store(Request $request)
    {
        $objective = StrategicObjective::with('goal.plan')->findOrFail($request->input('strategic_objective_id'));
        $this->authorizeRecord($objective);
        if ($locked = $this->structureLock($objective->goal->plan)) {
            return $locked;
        }
        if ($failed = $this->validateJson($request, $this->rules($objective->id))) {
            return $failed;
        }
        $initiative = DB::transaction(function () use ($request) {
            $initiative = StrategicInitiative::create($this->attributes($request) + [
                'created_by' => auth()->id(),
                'updated_by' => auth()->id(),
            ]);
            StrategicProgressService::recalculateInitiative($initiative);
            StrategicLogger::log($initiative, 'created', $initiative->name);

            return $initiative;
        });

        return $this->ok(__('strategic.Saved'), ['id' => $initiative->id]);
    }

    public function edit($id)
    {
        $initiative = StrategicInitiative::findOrFail($id);
        $this->authorizeRecord($initiative);

        return $this->ok(__('strategic.Loaded'), ['data' => $initiative]);
    }

    public function update(Request $request, $id)
    {
        $initiative = StrategicInitiative::with('objective.goal.plan')->findOrFail($id);
        $this->authorizeRecord($initiative);
        $plan = $initiative->objective->goal->plan;
        $editable = PlanWorkflow::structureEditable($plan->status);
        if (!$editable && ($locked = $this->executionLock($plan))) {
            return $locked;
        }
        if ($failed = $this->validateJson($request, $this->rules($initiative->strategic_objective_id, $initiative->id))) {
            return $failed;
        }
        DB::transaction(function () use ($request, $initiative, $editable) {
            $fields = $editable
                ? ['name', 'code', 'description', 'owner_id', 'department_id', 'priority', 'weight', 'estimated_budget', 'actual_budget', 'start_date', 'due_date', 'actual_end_date', 'status', 'expected_outcomes', 'progress_percentage']
                : ['actual_budget', 'actual_end_date', 'status', 'progress_percentage'];
            $initiative->update($request->only($fields) + ['updated_by' => auth()->id()]);
            StrategicProgressService::recalculateInitiative($initiative->fresh());
            StrategicLogger::log($initiative, 'updated', $initiative->name);
        });

        return $this->ok(__('strategic.Saved'));
    }

    public function destroy($id)
    {
        $initiative = StrategicInitiative::with('objective.goal.plan')->findOrFail($id);
        $this->authorizeRecord($initiative);
        if ($locked = $this->structureLock($initiative->objective->goal->plan)) {
            return $locked;
        }
        DB::transaction(function () use ($initiative) {
            $objective = $initiative->objective;
            foreach ($initiative->milestones as $milestone) {
                $milestone->delete();
            }
            StrategicLogger::log($initiative, 'deleted', $initiative->name);
            $initiative->delete();
            StrategicProgressService::recalculateObjective($objective);
        });

        return $this->ok(__('strategic.Deleted'));
    }

    public function createTask(Request $request, $id)
    {
        $initiative = StrategicInitiative::with('objective.goal.plan')->findOrFail($id);
        $this->authorizeRecord($initiative);
        if ($locked = $this->executionLock($initiative->objective->goal->plan)) {
            return $locked;
        }
        if ($failed = $this->validateJson($request, [
            'title' => ['required', 'string', 'max:100'],
            'description' => ['nullable', 'string'],
            'assignee_id' => ['required', 'exists:users,id'],
            'priority' => ['nullable', 'string'],
            'start_date' => ['nullable', 'date'],
            'due_date' => ['nullable', 'date', 'after_or_equal:start_date'],
            'strategic_milestone_id' => ['nullable', 'exists:strategic_milestones,id'],
        ])) {
            return $failed;
        }
        $milestone = null;
        if ($request->strategic_milestone_id) {
            $milestone = $initiative->milestones()->findOrFail($request->strategic_milestone_id);
        }
        $task = StrategicTaskBridge::create($initiative, $milestone, $request->only([
            'title', 'description', 'assignee_id', 'priority', 'start_date', 'due_date',
        ]));

        return $this->ok(__('strategic.Saved'), ['id' => $task->id]);
    }

    public function linkTask(Request $request, $id)
    {
        $initiative = StrategicInitiative::with('objective.goal.plan')->findOrFail($id);
        $this->authorizeRecord($initiative);
        if ($failed = $this->validateJson($request, [
            'task_id' => ['required', 'exists:tasks,id'],
            'strategic_milestone_id' => ['nullable', 'exists:strategic_milestones,id'],
        ])) {
            return $failed;
        }
        $milestone = $request->strategic_milestone_id
            ? $initiative->milestones()->findOrFail($request->strategic_milestone_id)
            : null;
        StrategicTaskBridge::linkExisting($initiative, $milestone, (int) $request->task_id);

        return $this->ok(__('strategic.Saved'));
    }

    public function linkCompliance(Request $request, $id)
    {
        $initiative = StrategicInitiative::findOrFail($id);
        $this->authorizeRecord($initiative);
        if ($failed = $this->validateJson($request, [
            'framework_id' => ['nullable', 'exists:frameworks,id'],
            'family_id' => ['nullable', 'exists:families,id'],
            'framework_control_id' => ['nullable', 'exists:framework_controls,id'],
            'gap_note' => ['nullable', 'string', 'max:5000'],
        ])) {
            return $failed;
        }
        StrategicComplianceLink::create([
            'linkable_type' => StrategicInitiative::class,
            'linkable_id' => $initiative->id,
            'framework_id' => $request->framework_id,
            'family_id' => $request->family_id,
            'framework_control_id' => $request->framework_control_id,
            'gap_note' => $request->gap_note,
            'created_by' => auth()->id(),
        ]);

        return $this->ok(__('strategic.Saved'));
    }

    protected function rules(int $objectiveId, $id = null): array
    {
        return [
            'strategic_objective_id' => ['required', 'exists:strategic_objectives,id'],
            'name' => ['required', 'string', 'max:200'],
            'code' => ['required', 'string', 'max:50', Rule::unique('strategic_initiatives', 'code')->ignore($id)->where(function ($query) use ($objectiveId) {
                return $query->where('strategic_objective_id', $objectiveId)->whereNull('deleted_at');
            })],
            'description' => ['nullable', 'string'],
            'owner_id' => ['nullable', 'exists:users,id'],
            'department_id' => ['nullable', 'exists:departments,id'],
            'priority' => ['required', Rule::in(['low', 'medium', 'high', 'critical'])],
            'weight' => ['required', 'numeric', 'min:0.01', 'max:100'],
            'estimated_budget' => ['nullable', 'numeric', 'min:0'],
            'actual_budget' => ['nullable', 'numeric', 'min:0'],
            'start_date' => ['nullable', 'date'],
            'due_date' => ['nullable', 'date', 'after_or_equal:start_date'],
            'actual_end_date' => ['nullable', 'date'],
            'progress_percentage' => ['nullable', 'numeric', 'min:0', 'max:100'],
            'status' => ['required', Rule::in(['not_started', 'in_progress', 'at_risk', 'delayed', 'completed', 'cancelled'])],
            'expected_outcomes' => ['nullable', 'string'],
        ];
    }

    protected function attributes(Request $request): array
    {
        return $request->only([
            'strategic_objective_id', 'name', 'code', 'description', 'owner_id', 'department_id',
            'priority', 'weight', 'estimated_budget', 'actual_budget', 'start_date', 'due_date',
            'actual_end_date', 'progress_percentage', 'status', 'expected_outcomes',
        ]);
    }
}
