<?php

namespace App\Http\Controllers\admin\strategic_planning;

use App\Http\Controllers\Controller;
use App\Models\Department;
use App\Models\StrategicPlan;
use App\Models\User;
use App\Services\Strategic\PlanWorkflow;
use App\Services\Strategic\StrategicAccess;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class StrategicController extends Controller
{
    protected function validateJson(Request $request, array $rules)
    {
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()->toArray(),
                'message' => __('strategic.ValidationFailed'),
            ], 422);
        }

        return null;
    }

    protected function ok(string $message, array $data = [])
    {
        return response()->json(array_merge(['status' => true, 'message' => $message], $data));
    }

    protected function fail(string $message, int $code = 422)
    {
        return response()->json(['status' => false, 'message' => $message], $code);
    }

    protected function authorizeRecord(Model $model): void
    {
        if (!StrategicAccess::isAssigned(auth()->user(), $model)) {
            abort(response()->json([
                'status' => false,
                'message' => __('locale.YouDonotHavePermissionToDoThat'),
            ], 403));
        }
    }

    protected function structureLock(StrategicPlan $plan)
    {
        if (!PlanWorkflow::structureEditable($plan->status)) {
            return $this->fail(__('strategic.PlanLocked'), 423);
        }

        return null;
    }

    protected function executionLock(StrategicPlan $plan)
    {
        if (!PlanWorkflow::executionAllowed($plan->status)) {
            return $this->fail(__('strategic.ExecutionLocked'), 423);
        }

        return null;
    }

    protected function options(): array
    {
        return [
            'departments' => Department::orderBy('id')->get(),
            'users' => User::orderBy('name')->get(['id', 'name', 'department_id']),
            'plans' => StrategicAccess::scopePlans(StrategicPlan::query(), auth()->user())->orderBy('name')->get(),
        ];
    }

    protected function crumbs(array $extra = []): array
    {
        $crumbs = [
            ['link' => route('admin.dashboard'), 'name' => __('locale.Dashboard')],
            ['link' => route('admin.strategic.dashboard'), 'name' => __('locale.StrategicPlanning')],
        ];

        return array_merge($crumbs, $extra);
    }

    protected function rowActions(Model $model): array
    {
        return [
            'id' => $model->getKey(),
            'assigned' => StrategicAccess::isAssigned(auth()->user(), $model),
        ];
    }
}
