<?php

namespace App\Http\Controllers\admin\strategic_planning;

use App\Models\Department;
use App\Services\Strategic\StrategicDashboardService;
use Illuminate\Http\Request;

class StrategicDashboardController extends StrategicController
{
    public function index(Request $request)
    {
        $filters = $this->filters($request);
        $stats = StrategicDashboardService::build(auth()->user(), $filters);
        $departments = Department::all()->mapWithKeys(function (Department $department) {
            return [$department->id => $department->name];
        });
        $plans = StrategicDashboardService::filterPlans(auth()->user());
        $breadcrumbs = $this->crumbs([['name' => __('locale.StrategicDashboard')]]);

        return view('admin.content.strategic_planning.dashboard', compact('stats', 'filters', 'departments', 'plans', 'breadcrumbs'));
    }

    public function data(Request $request)
    {
        $stats = StrategicDashboardService::build(auth()->user(), $this->filters($request));

        return $this->ok(__('strategic.Loaded'), ['stats' => $stats]);
    }

    protected function filters(Request $request): array
    {
        return [
            'plan_id' => $request->input('plan_id'),
            'department_id' => $request->input('department_id'),
            'year' => $request->input('year'),
            'status' => $request->input('status'),
            'period' => $request->input('period'),
        ];
    }
}
