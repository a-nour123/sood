<?php

namespace Database\Seeders;

use App\Models\Permission;
use App\Models\PermissionGroup;
use App\Models\Role;
use App\Models\RoleResponsibility;
use App\Models\Subgroup;
use Illuminate\Database\Seeder;

class AddGovernanceCommitteePermissionSeeder extends Seeder
{
    public static function permissionMap(): array
    {
        return [
            'view_committees' => 'view committees',
            'create_committee' => 'create committee',
            'update_committee' => 'update committee',
            'delete_committee' => 'delete committee',
            'manage_committee_members' => 'manage committee members',
            'manage_committee_departments' => 'manage committee departments',
            'manage_committee_settings' => 'manage committee settings',
            'committee_notification.create' => 'create committee notification',
            'view_governance_requests' => 'view governance requests',
            'create_governance_request' => 'create governance request',
            'update_governance_request' => 'update governance request',
            'delete_governance_request' => 'delete governance request',
            'submit_governance_request' => 'submit governance request',
            'assign_governance_request' => 'assign governance request',
            'review_governance_request' => 'review governance request',
            'submit_committee_recommendation' => 'submit committee recommendation',
            'view_committee_reviews' => 'view committee reviews',
            'vote_on_governance_request' => 'vote on governance request',
            'manage_committee_voting' => 'manage committee voting',
            'finalize_committee_recommendation' => 'finalize committee recommendation',
            'approve_governance_request' => 'approve governance request',
            'reject_governance_request' => 'reject governance request',
            'issue_governance_decision' => 'issue governance decision',
            'reopen_governance_request' => 'reopen governance request',
            'manage_approval_requests' => 'manage approval requests',
            'manage_exception_requests' => 'manage exception requests',
            'manage_risk_acceptance_requests' => 'manage risk acceptance requests',
            'manage_committee_meetings' => 'manage committee meetings',
            'manage_meeting_minutes' => 'manage meeting minutes',
            'view_governance_reports' => 'view governance reports',
            'export_governance_reports' => 'export governance reports',
        ];
    }

    public function run()
    {
        $permissionGroups = PermissionGroup::pluck('id', 'name');
        $governanceId = $permissionGroups['Governance'] ?? null;
        if (!$governanceId) {
            if (isset($this->command)) {
                $this->command->error('Governance permission group was not found. Committee permissions were not seeded.');
            }
            return;
        }

        $subgroup = Subgroup::firstOrCreate(
            ['name' => 'Committee Management'],
            ['permission_group_id' => $governanceId]
        );

        $adminRoleExists = Role::where('id', 1)->exists();
        foreach (self::permissionMap() as $key => $name) {
            $permission = Permission::firstOrCreate(
                ['key' => $key],
                ['name' => $name, 'subgroup_id' => $subgroup->id]
            );
            if ($adminRoleExists) {
                RoleResponsibility::firstOrCreate([
                    'role_id' => 1,
                    'permission_id' => $permission->id,
                ]);
            }
        }
    }
}
