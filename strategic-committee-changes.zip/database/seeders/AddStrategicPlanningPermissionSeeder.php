<?php

namespace Database\Seeders;

use App\Models\Permission;
use App\Models\PermissionGroup;
use App\Models\Role;
use App\Models\RoleResponsibility;
use App\Models\Subgroup;
use Illuminate\Database\Seeder;

class AddStrategicPlanningPermissionSeeder extends Seeder
{
    public static function permissionMap(): array
    {
        return [
            'strategic_plan.list' => 'list',
            'strategic_plan.create' => 'create',
            'strategic_plan.update' => 'update',
            'strategic_plan.delete' => 'delete',
            'strategic_plan.submit' => 'submit',
            'strategic_plan.approve' => 'approve',
            'strategic_plan.reject' => 'reject',
            'strategic_goal.manage' => 'manage goals',
            'strategic_objective.manage' => 'manage objectives',
            'strategic_initiative.manage' => 'manage initiatives',
            'strategic_milestone.manage' => 'manage milestones',
            'strategic_kpi.manage' => 'manage kpis',
            'strategic_kri.manage' => 'manage kris',
            'strategic_risk.manage' => 'manage risks',
            'strategic_report.list' => 'view reports',
            'strategic_report.export' => 'export reports',
        ];
    }

    public function run()
    {
        $permissionGroups = PermissionGroup::pluck('id', 'name');
        $governanceId = $permissionGroups['Governance'] ?? null;
        if (!$governanceId) {
            if (isset($this->command)) {
                $this->command->error('Governance permission group was not found. Strategic Planning permissions were not seeded.');
            }
            return;
        }

        $subgroup = Subgroup::firstOrCreate(
            ['name' => 'Strategic Planning'],
            ['permission_group_id' => $governanceId]
        );

        $adminRoleExists = Role::where('id', 1)->exists();

        foreach (self::permissionMap() as $key => $name) {
            $permission = Permission::firstOrCreate(
                ['key' => $key],
                [
                    'name' => $name,
                    'subgroup_id' => $subgroup->id,
                ]
            );

            if ($adminRoleExists) {
                RoleResponsibility::firstOrCreate([
                    'role_id' => 1,
                    'permission_id' => $permission->id,
                ]);
            }
        }

        if (isset($this->command)) {
            $this->command->info('Strategic Planning permissions seeded successfully.');
        }
    }
}
