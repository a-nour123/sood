<?php

use Database\Seeders\AddGovernanceCommitteePermissionSeeder;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('governance_committee_types', function (Blueprint $table) {
            $table->id();
            $table->string('name', 150);
            $table->string('code', 50);
            $table->text('description')->nullable();
            $table->boolean('is_active')->default(true)->index();
            $table->timestamps();
            $table->unique('code', 'gov_committee_types_code_uq');
        });

        Schema::create('governance_request_categories', function (Blueprint $table) {
            $table->id();
            $table->string('request_type', 40)->index();
            $table->string('name', 150);
            $table->string('code', 50);
            $table->boolean('is_active')->default(true)->index();
            $table->timestamps();
            $table->unique(['request_type', 'code'], 'gov_req_categories_type_code_uq');
        });

        Schema::create('governance_committees', function (Blueprint $table) {
            $table->id();
            $table->string('name', 200);
            $table->string('code', 50);
            $table->text('description')->nullable();
            $table->text('responsibilities')->nullable();
            $table->foreignId('committee_type_id')->nullable()->constrained('governance_committee_types')->nullOnDelete();
            $table->foreignId('chairman_id')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('secretary_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('status', 20)->default('active')->index();
            $table->date('effective_from')->nullable();
            $table->date('effective_until')->nullable();
            $table->string('approval_mode', 20)->default('chairman');
            $table->unsignedInteger('minimum_approval_count')->default(1);
            $table->decimal('voting_threshold', 8, 2)->default(50);
            $table->unsignedInteger('quorum_count')->default(0);
            $table->boolean('allow_vote_change')->default(false);
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('updated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->softDeletes();
            $table->unique('code', 'gov_committees_code_uq');
        });

        Schema::create('governance_committee_departments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('committee_id')->constrained('governance_committees')->restrictOnDelete();
            $table->foreignId('department_id')->constrained('departments')->restrictOnDelete();
            $table->foreignId('assigned_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('assigned_at')->nullable();
            $table->timestamp('removed_at')->nullable()->index();
            $table->timestamps();
            $table->index(['committee_id', 'department_id'], 'gov_comm_dept_idx');
        });

        Schema::create('governance_committee_members', function (Blueprint $table) {
            $table->id();
            $table->foreignId('committee_id')->constrained('governance_committees')->restrictOnDelete();
            $table->foreignId('user_id')->constrained('users')->restrictOnDelete();
            $table->foreignId('department_id')->nullable()->constrained('departments')->nullOnDelete();
            $table->string('member_role', 40)->index();
            $table->boolean('voting_right')->default(false);
            $table->decimal('voting_weight', 8, 2)->default(1);
            $table->boolean('can_recommend')->default(false);
            $table->boolean('can_approve')->default(false);
            $table->boolean('can_review')->default(false);
            $table->date('effective_from')->nullable();
            $table->date('effective_until')->nullable();
            $table->string('status', 20)->default('active')->index();
            $table->timestamps();
            $table->softDeletes();
            $table->index(['committee_id', 'user_id', 'status'], 'gov_comm_members_user_idx');
        });

        Schema::create('governance_committee_request_types', function (Blueprint $table) {
            $table->id();
            $table->foreignId('committee_id')->constrained('governance_committees')->cascadeOnDelete();
            $table->string('request_type', 40);
            $table->timestamps();
            $table->unique(['committee_id', 'request_type'], 'gov_comm_req_types_uq');
        });

        Schema::create('governance_assignment_rules', function (Blueprint $table) {
            $table->id();
            $table->string('request_type', 40)->index();
            $table->foreignId('category_id')->nullable()->constrained('governance_request_categories')->nullOnDelete();
            $table->foreignId('department_id')->nullable()->constrained('departments')->nullOnDelete();
            $table->foreignId('committee_id')->constrained('governance_committees')->restrictOnDelete();
            $table->unsignedInteger('priority')->default(100);
            $table->boolean('is_active')->default(true)->index();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
        });

        Schema::create('governance_sequences', function (Blueprint $table) {
            $table->id();
            $table->unsignedSmallInteger('year');
            $table->unsignedInteger('last_number')->default(0);
            $table->timestamps();
            $table->unique('year', 'gov_sequences_year_uq');
        });

        Schema::create('governance_requests', function (Blueprint $table) {
            $table->id();
            $table->string('request_number', 30);
            $table->string('idempotency_key', 64)->nullable();
            $table->string('request_type', 40)->index();
            $table->foreignId('category_id')->nullable()->constrained('governance_request_categories')->nullOnDelete();
            $table->string('title', 250);
            $table->text('description')->nullable();
            $table->foreignId('requester_id')->constrained('users')->restrictOnDelete();
            $table->foreignId('department_id')->nullable()->constrained('departments')->nullOnDelete();
            $table->foreignId('assigned_committee_id')->nullable()->constrained('governance_committees')->nullOnDelete();
            $table->string('priority', 20)->default('medium')->index();
            $table->string('status', 40)->default('draft')->index();
            $table->unsignedInteger('round')->default(1);
            $table->date('submission_date')->nullable()->index();
            $table->date('due_date')->nullable()->index();
            $table->string('final_decision', 40)->nullable();
            $table->text('final_decision_reason')->nullable();
            $table->foreignId('decided_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('decided_at')->nullable()->index();
            $table->timestamp('review_overdue_notified_at')->nullable();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('updated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->softDeletes();
            $table->unique('request_number', 'gov_requests_number_uq');
            $table->unique('idempotency_key', 'gov_requests_idem_uq');
            $table->index(['request_type', 'status'], 'gov_requests_type_status_idx');
            $table->index(['department_id', 'status'], 'gov_requests_dept_status_idx');
            $table->index(['assigned_committee_id', 'status'], 'gov_requests_comm_status_idx');
        });

        Schema::create('governance_approval_details', function (Blueprint $table) {
            $table->id();
            $table->foreignId('governance_request_id')->constrained('governance_requests')->restrictOnDelete();
            $table->text('business_justification')->nullable();
            $table->date('requested_effective_date')->nullable();
            $table->foreignId('document_id')->nullable()->constrained('documents')->nullOnDelete();
            $table->text('document_version_ref')->nullable();
            $table->timestamps();
            $table->unique('governance_request_id', 'gov_approval_details_req_uq');
        });

        Schema::create('governance_exception_details', function (Blueprint $table) {
            $table->id();
            $table->foreignId('governance_request_id')->constrained('governance_requests')->restrictOnDelete();
            $table->foreignId('framework_id')->nullable()->constrained('frameworks')->nullOnDelete();
            $table->foreignId('family_id')->nullable()->constrained('families')->nullOnDelete();
            $table->foreignId('control_id')->nullable()->constrained('framework_controls')->nullOnDelete();
            $table->text('regulatory_requirement')->nullable();
            $table->foreignId('policy_document_id')->nullable()->constrained('documents')->nullOnDelete();
            $table->foreignId('existing_exception_id')->nullable()->constrained('exceptions')->nullOnDelete();
            $table->text('justification')->nullable();
            $table->text('business_impact')->nullable();
            $table->text('technical_justification')->nullable();
            $table->text('compensating_controls')->nullable();
            $table->text('risk_assessment')->nullable();
            $table->date('requested_start')->nullable();
            $table->date('requested_expiration')->nullable();
            $table->date('review_date')->nullable();
            $table->foreignId('owner_id')->nullable()->constrained('users')->nullOnDelete();
            $table->text('remediation_plan')->nullable();
            $table->date('approval_date')->nullable();
            $table->date('expiration_date')->nullable()->index();
            $table->text('approved_conditions')->nullable();
            $table->string('review_frequency', 40)->nullable();
            $table->foreignId('approving_committee_id')->nullable()->constrained('governance_committees')->nullOnDelete();
            $table->foreignId('final_approver_id')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('expiration_notice_sent_at')->nullable();
            $table->timestamp('expired_notice_sent_at')->nullable();
            $table->timestamps();
            $table->unique('governance_request_id', 'gov_exception_details_req_uq');
        });

        Schema::create('governance_risk_acceptance_details', function (Blueprint $table) {
            $table->id();
            $table->foreignId('governance_request_id')->constrained('governance_requests')->restrictOnDelete();
            $table->foreignId('risk_id')->constrained('risks')->restrictOnDelete();
            $table->text('acceptance_justification')->nullable();
            $table->text('business_impact')->nullable();
            $table->string('acceptance_period', 80)->nullable();
            $table->date('proposed_expiration')->nullable();
            $table->text('compensating_controls')->nullable();
            $table->text('monitoring_plan')->nullable();
            $table->text('owner_recommendation')->nullable();
            $table->string('decision_outcome', 40)->nullable();
            $table->longText('risk_snapshot')->nullable();
            $table->timestamps();
            $table->unique('governance_request_id', 'gov_risk_details_req_uq');
            $table->index('risk_id', 'gov_risk_details_risk_idx');
        });

        Schema::create('governance_reviews', function (Blueprint $table) {
            $table->id();
            $table->foreignId('governance_request_id')->constrained('governance_requests')->restrictOnDelete();
            $table->foreignId('committee_id')->constrained('governance_committees')->restrictOnDelete();
            $table->foreignId('committee_member_id')->constrained('governance_committee_members')->restrictOnDelete();
            $table->foreignId('reviewer_id')->constrained('users')->restrictOnDelete();
            $table->unsignedInteger('round')->default(1);
            $table->string('review_status', 40)->default('pending')->index();
            $table->string('recommendation', 40)->nullable();
            $table->text('comments')->nullable();
            $table->timestamp('reviewed_at')->nullable();
            $table->timestamps();
            $table->unique(['governance_request_id', 'committee_member_id', 'round'], 'gov_reviews_member_round_uq');
        });

        Schema::create('governance_review_comments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('governance_review_id')->constrained('governance_reviews')->restrictOnDelete();
            $table->foreignId('user_id')->constrained('users')->restrictOnDelete();
            $table->text('body');
            $table->timestamps();
        });

        Schema::create('governance_voting_sessions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('governance_request_id')->constrained('governance_requests')->restrictOnDelete();
            $table->foreignId('committee_id')->constrained('governance_committees')->restrictOnDelete();
            $table->unsignedInteger('round')->default(1);
            $table->string('status', 20)->default('open')->index();
            $table->foreignId('opened_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('opened_at')->nullable();
            $table->date('deadline')->nullable();
            $table->timestamp('closed_at')->nullable();
            $table->string('result', 30)->default('pending');
            $table->text('tally')->nullable();
            $table->unsignedInteger('eligible_count')->default(0);
            $table->timestamps();
            $table->unique(['governance_request_id', 'round'], 'gov_vote_sessions_round_uq');
        });

        Schema::create('governance_votes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('voting_session_id')->constrained('governance_voting_sessions')->restrictOnDelete();
            $table->foreignId('governance_request_id')->constrained('governance_requests')->restrictOnDelete();
            $table->foreignId('committee_id')->constrained('governance_committees')->restrictOnDelete();
            $table->foreignId('committee_member_id')->constrained('governance_committee_members')->restrictOnDelete();
            $table->foreignId('voter_id')->constrained('users')->restrictOnDelete();
            $table->string('vote', 20);
            $table->text('comments')->nullable();
            $table->decimal('voting_weight', 8, 2)->default(1);
            $table->timestamp('voted_at')->nullable();
            $table->timestamps();
            $table->unique(['voting_session_id', 'committee_member_id'], 'gov_votes_member_uq');
        });

        Schema::create('governance_vote_histories', function (Blueprint $table) {
            $table->id();
            $table->foreignId('governance_vote_id')->constrained('governance_votes')->restrictOnDelete();
            $table->string('previous_vote', 20);
            $table->text('previous_comments')->nullable();
            $table->decimal('previous_weight', 8, 2)->default(1);
            $table->foreignId('changed_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
        });

        Schema::create('governance_meetings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('committee_id')->constrained('governance_committees')->restrictOnDelete();
            $table->string('meeting_number', 40);
            $table->string('title', 200);
            $table->text('description')->nullable();
            $table->date('meeting_date')->index();
            $table->time('start_time')->nullable();
            $table->time('end_time')->nullable();
            $table->string('location', 200)->nullable();
            $table->string('meeting_type', 30)->default('regular');
            $table->foreignId('chairman_id')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('secretary_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('status', 20)->default('scheduled')->index();
            $table->timestamp('reminder_sent_at')->nullable();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->softDeletes();
            $table->unique(['committee_id', 'meeting_number'], 'gov_meetings_number_uq');
        });

        Schema::create('governance_request_attachments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('governance_request_id')->nullable()->constrained('governance_requests')->nullOnDelete();
            $table->foreignId('governance_review_id')->nullable()->constrained('governance_reviews')->nullOnDelete();
            $table->foreignId('governance_meeting_id')->nullable()->constrained('governance_meetings')->nullOnDelete();
            $table->string('original_name', 255);
            $table->string('path', 500);
            $table->string('mime', 120)->nullable();
            $table->unsignedBigInteger('size')->default(0);
            $table->foreignId('uploaded_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->index('governance_request_id', 'gov_attachments_req_idx');
        });

        Schema::create('governance_meeting_members', function (Blueprint $table) {
            $table->id();
            $table->foreignId('governance_meeting_id')->constrained('governance_meetings')->cascadeOnDelete();
            $table->foreignId('user_id')->constrained('users')->restrictOnDelete();
            $table->string('attendance', 20)->default('invited');
            $table->string('member_role', 40)->nullable();
            $table->timestamps();
            $table->unique(['governance_meeting_id', 'user_id'], 'gov_meeting_members_uq');
        });

        Schema::create('governance_meeting_agendas', function (Blueprint $table) {
            $table->id();
            $table->foreignId('governance_meeting_id')->constrained('governance_meetings')->cascadeOnDelete();
            $table->foreignId('governance_request_id')->nullable()->constrained('governance_requests')->nullOnDelete();
            $table->string('title', 200);
            $table->text('description')->nullable();
            $table->unsignedInteger('sort_order')->default(0);
            $table->timestamps();
        });

        Schema::create('governance_meeting_minutes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('governance_meeting_id')->constrained('governance_meetings')->cascadeOnDelete();
            $table->text('discussion')->nullable();
            $table->text('recommendations')->nullable();
            $table->text('resolutions')->nullable();
            $table->foreignId('recorded_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
        });

        Schema::create('governance_meeting_actions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('governance_meeting_id')->constrained('governance_meetings')->restrictOnDelete();
            $table->foreignId('governance_request_id')->nullable()->constrained('governance_requests')->nullOnDelete();
            $table->foreignId('task_id')->nullable()->constrained('tasks')->nullOnDelete();
            $table->string('title', 200);
            $table->timestamps();
        });

        Schema::create('governance_decisions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('governance_request_id')->constrained('governance_requests')->restrictOnDelete();
            $table->foreignId('committee_id')->nullable()->constrained('governance_committees')->nullOnDelete();
            $table->string('decision_type', 40)->index();
            $table->string('decision_number', 40);
            $table->text('decision_reason')->nullable();
            $table->text('decision_conditions')->nullable();
            $table->foreignId('decided_by')->constrained('users')->restrictOnDelete();
            $table->timestamp('decided_at');
            $table->date('effective_from')->nullable();
            $table->date('effective_until')->nullable();
            $table->string('status', 20)->default('finalized')->index();
            $table->boolean('is_current')->default(true)->index();
            $table->foreignId('corrects_decision_id')->nullable()->constrained('governance_decisions')->nullOnDelete();
            $table->unsignedInteger('round')->default(1);
            $table->timestamps();
            $table->unique('decision_number', 'gov_decisions_number_uq');
            $table->index(['governance_request_id', 'is_current'], 'gov_decisions_current_idx');
        });

        Schema::create('governance_request_assignments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('governance_request_id')->constrained('governance_requests')->restrictOnDelete();
            $table->foreignId('from_committee_id')->nullable()->constrained('governance_committees')->nullOnDelete();
            $table->foreignId('to_committee_id')->nullable()->constrained('governance_committees')->nullOnDelete();
            $table->string('reason', 1000)->nullable();
            $table->foreignId('assigned_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('assigned_at')->nullable();
            $table->timestamps();
            $table->index('governance_request_id', 'gov_assignments_req_idx');
        });

        Schema::create('governance_activity_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('governance_request_id')->nullable()->constrained('governance_requests')->nullOnDelete();
            $table->foreignId('committee_id')->nullable()->constrained('governance_committees')->nullOnDelete();
            $table->foreignId('actor_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('action', 60)->index();
            $table->string('description', 1000)->nullable();
            $table->text('meta')->nullable();
            $table->timestamps();
            $table->index(['governance_request_id', 'created_at'], 'gov_activity_req_idx');
        });

        Schema::create('governance_status_histories', function (Blueprint $table) {
            $table->id();
            $table->foreignId('governance_request_id')->constrained('governance_requests')->restrictOnDelete();
            $table->string('from_status', 40)->nullable();
            $table->string('to_status', 40)->index();
            $table->foreignId('actor_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('comment', 1000)->nullable();
            $table->timestamps();
            $table->index('governance_request_id', 'gov_status_hist_req_idx');
        });

        $this->seedCatalog();
        (new AddGovernanceCommitteePermissionSeeder())->run();
        $this->seedNotifications();
    }

    protected function seedCatalog()
    {
        $now = now();
        $types = [
            ['risk', 'Risk Committee'],
            ['compliance', 'Compliance Committee'],
            ['cybersecurity', 'Cybersecurity Committee'],
            ['governance', 'Governance Committee'],
            ['exception_review', 'Exception Review Committee'],
            ['executive', 'Executive Committee'],
            ['technical', 'Technical Committee'],
        ];
        foreach ($types as $type) {
            DB::table('governance_committee_types')->updateOrInsert(
                ['code' => $type[0]],
                ['name' => $type[1], 'is_active' => 1, 'created_at' => $now, 'updated_at' => $now]
            );
        }
        $categories = [
            'approval' => [
                ['policy', 'Policy Approval'],
                ['procedure', 'Procedure Approval'],
                ['security_document', 'Security Document Approval'],
                ['governance_decision', 'Governance Decision Approval'],
                ['change', 'Change Approval'],
                ['other', 'Other Approval'],
            ],
            'exception' => [
                ['policy', 'Policy Exception'],
                ['security_control', 'Security Control Exception'],
                ['regulatory', 'Regulatory Requirement Exception'],
                ['temporary_compliance', 'Temporary Compliance Exception'],
                ['other', 'Other Exception'],
            ],
            'risk_acceptance' => [
                ['accept_existing', 'Accept Existing Risk'],
                ['extend', 'Extend Risk Acceptance'],
                ['review', 'Review Risk Acceptance'],
                ['reconsider_treatment', 'Reconsider Risk Treatment'],
            ],
        ];
        foreach ($categories as $requestType => $rows) {
            foreach ($rows as $row) {
                DB::table('governance_request_categories')->updateOrInsert(
                    ['request_type' => $requestType, 'code' => $row[0]],
                    ['name' => $row[1], 'is_active' => 1, 'created_at' => $now, 'updated_at' => $now]
                );
            }
        }
    }

    protected function seedNotifications()
    {
        if (!Schema::hasTable('actions') || !Schema::hasTable('system_notifications_settings')) {
            return;
        }
        $messages = [
            'Governance_Request_Submitted' => 'A governance request was submitted.',
            'Governance_Request_Assigned' => 'A governance request was assigned to a committee.',
            'Governance_Member_Assigned' => 'You were assigned to a committee.',
            'Governance_Review_Requested' => 'A committee review was requested.',
            'Governance_Review_Completed' => 'A committee review was completed.',
            'Governance_Review_Overdue' => 'A committee review is overdue.',
            'Governance_Meeting_Scheduled' => 'A committee meeting was scheduled.',
            'Governance_Meeting_Updated' => 'A committee meeting was updated.',
            'Governance_Meeting_Reminder' => 'A committee meeting reminder.',
            'Governance_Voting_Started' => 'Committee voting has started.',
            'Governance_Voting_Deadline' => 'A committee voting deadline is approaching.',
            'Governance_Decision_Finalized' => 'A governance decision was finalized.',
            'Governance_Request_Rejected' => 'A governance request was rejected.',
            'Governance_Information_Requested' => 'Additional information was requested.',
            'Governance_Exception_Expiring' => 'An approved exception is approaching expiration.',
            'Governance_Exception_Expired' => 'An approved exception has expired.',
            'Governance_Risk_Accepted' => 'A risk acceptance request was approved.',
            'Governance_Risk_Rejected' => 'A risk acceptance request was rejected.',
        ];
        $roles = ['requester', 'committee_member', 'chairman', 'secretary', 'reviewer', 'owner'];
        foreach ($messages as $name => $message) {
            $actionId = DB::table('actions')->where('name', $name)->value('id');
            if (!$actionId) {
                $actionId = DB::table('actions')->insertGetId(['name' => $name]);
            }
            if (DB::table('system_notifications_settings')->where('action_id', $actionId)->exists()) {
                continue;
            }
            $settingId = DB::table('system_notifications_settings')->insertGetId([
                'action_id' => $actionId,
                'message' => $message,
                'status' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            if (Schema::hasTable('notifications_roles')) {
                foreach ($roles as $role) {
                    DB::table('notifications_roles')->insert([
                        'role' => $role,
                        'notifiable_id' => $settingId,
                        'notifiable_type' => \App\Models\SystemNotificationSetting::class,
                    ]);
                }
            }
        }
    }

    public function down()
    {
        Schema::dropIfExists('governance_status_histories');
        Schema::dropIfExists('governance_activity_logs');
        Schema::dropIfExists('governance_request_assignments');
        Schema::dropIfExists('governance_decisions');
        Schema::dropIfExists('governance_meeting_actions');
        Schema::dropIfExists('governance_meeting_minutes');
        Schema::dropIfExists('governance_meeting_agendas');
        Schema::dropIfExists('governance_meeting_members');
        Schema::dropIfExists('governance_vote_histories');
        Schema::dropIfExists('governance_votes');
        Schema::dropIfExists('governance_voting_sessions');
        Schema::dropIfExists('governance_review_comments');
        Schema::dropIfExists('governance_request_attachments');
        Schema::dropIfExists('governance_reviews');
        Schema::dropIfExists('governance_risk_acceptance_details');
        Schema::dropIfExists('governance_exception_details');
        Schema::dropIfExists('governance_approval_details');
        Schema::dropIfExists('governance_requests');
        Schema::dropIfExists('governance_sequences');
        Schema::dropIfExists('governance_assignment_rules');
        Schema::dropIfExists('governance_committee_request_types');
        Schema::dropIfExists('governance_committee_members');
        Schema::dropIfExists('governance_committee_departments');
        Schema::dropIfExists('governance_meetings');
        Schema::dropIfExists('governance_committees');
        Schema::dropIfExists('governance_request_categories');
        Schema::dropIfExists('governance_committee_types');

        $keys = array_keys(AddGovernanceCommitteePermissionSeeder::permissionMap());
        $permissionIds = \App\Models\Permission::whereIn('key', $keys)->pluck('id');
        if ($permissionIds->isNotEmpty()) {
            \App\Models\RoleResponsibility::whereIn('permission_id', $permissionIds)->delete();
            \App\Models\Permission::whereIn('id', $permissionIds)->delete();
        }
        $subgroup = \App\Models\Subgroup::where('name', 'Committee Management')->first();
        if ($subgroup && $subgroup->permissions()->count() === 0) {
            $subgroup->delete();
        }

        if (Schema::hasTable('actions')) {
            $ids = DB::table('actions')->where('name', 'like', 'Governance_%')->pluck('id');
            if ($ids->isNotEmpty() && Schema::hasTable('system_notifications_settings')) {
                $settingIds = DB::table('system_notifications_settings')->whereIn('action_id', $ids)->pluck('id');
                if (Schema::hasTable('notifications_roles')) {
                    DB::table('notifications_roles')->whereIn('notifiable_id', $settingIds)
                        ->where('notifiable_type', \App\Models\SystemNotificationSetting::class)
                        ->delete();
                }
                DB::table('system_notifications_settings')->whereIn('id', $settingIds)->delete();
            }
            DB::table('actions')->whereIn('id', $ids)->delete();
        }
    }
};
