<?php

use App\Models\Permission;
use App\Models\RoleResponsibility;
use Database\Seeders\AddGovernanceCommitteePermissionSeeder;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    public function up()
    {
        (new AddGovernanceCommitteePermissionSeeder())->run();
    }

    public function down()
    {
        $permission = Permission::where('key', 'committee_notification.create')->first();
        if (!$permission) {
            return;
        }
        RoleResponsibility::where('permission_id', $permission->id)->delete();
        $permission->delete();
    }
};
