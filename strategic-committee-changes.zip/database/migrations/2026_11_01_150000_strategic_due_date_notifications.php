<?php

use App\Models\AutoNotify;
use App\Models\SystemNotificationSetting;
use App\Services\Strategic\StrategicNotificationCatalog;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up()
    {
        $removed = [
            'Strategic_Objective_Due',
            'Strategic_Objective_Overdue',
            'Strategic_Initiative_Delayed',
            'Strategic_Milestone_Overdue',
            'Strategic_Kpi_Measurement_Missing',
            'Strategic_Task_Deadline',
        ];
        $removedIds = DB::table('actions')->whereIn('name', $removed)->pluck('id');
        $removedSettings = DB::table('system_notifications_settings')->whereIn('action_id', $removedIds)->pluck('id');
        DB::table('notifications_roles')
            ->where('notifiable_type', SystemNotificationSetting::class)
            ->whereIn('notifiable_id', $removedSettings)
            ->delete();
        DB::table('system_notifications_settings')->whereIn('id', $removedSettings)->delete();
        DB::table('actions')->whereIn('id', $removedIds)->delete();

        $settingIds = DB::table('system_notifications_settings')
            ->whereIn('action_id', DB::table('actions')->where('name', 'like', 'Strategic_%')->pluck('id'))
            ->pluck('id');
        DB::table('notifications_roles')
            ->where('role', 'module_users')
            ->where('notifiable_type', SystemNotificationSetting::class)
            ->whereIn('notifiable_id', $settingIds)
            ->delete();

        $roles = array_keys(StrategicNotificationCatalog::roles());
        foreach (StrategicNotificationCatalog::dueDefinitions() as $name => $definition) {
            $actionId = DB::table('actions')->where('name', $name)->value('id');
            if (!$actionId) {
                $actionId = DB::table('actions')->insertGetId(['name' => $name]);
            }
            if (DB::table('auto_notifies')->where('action_id', $actionId)->exists()) {
                continue;
            }
            $autoId = DB::table('auto_notifies')->insertGetId([
                'action_id' => $actionId,
                'message' => $definition['message'],
                'date' => json_encode([7, 3, 1]),
                'status' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            foreach ($roles as $role) {
                DB::table('notifications_roles')->insert([
                    'role' => $role,
                    'notifiable_id' => $autoId,
                    'notifiable_type' => AutoNotify::class,
                ]);
            }
        }
    }

    public function down()
    {
        $names = array_keys(StrategicNotificationCatalog::dueDefinitions());
        $ids = DB::table('actions')->whereIn('name', $names)->pluck('id');
        $autoIds = DB::table('auto_notifies')->whereIn('action_id', $ids)->pluck('id');
        DB::table('notifications_roles')
            ->where('notifiable_type', AutoNotify::class)
            ->whereIn('notifiable_id', $autoIds)
            ->delete();
        DB::table('auto_notifies')->whereIn('id', $autoIds)->delete();
        DB::table('actions')->whereIn('id', $ids)->delete();
    }
};
