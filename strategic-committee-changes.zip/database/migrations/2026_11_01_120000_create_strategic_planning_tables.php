<?php

use Database\Seeders\AddStrategicPlanningPermissionSeeder;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('strategic_plans', function (Blueprint $table) {
            $table->id();
            $table->string('name', 200);
            $table->string('code', 50);
            $table->text('description')->nullable();
            $table->text('vision')->nullable();
            $table->text('mission')->nullable();
            $table->text('strategic_priorities')->nullable();
            $table->foreignId('department_id')->nullable()->constrained('departments')->nullOnDelete();
            $table->foreignId('owner_id')->constrained('users')->restrictOnDelete();
            $table->date('start_date');
            $table->date('end_date');
            $table->string('status', 30)->default('draft')->index();
            $table->unsignedInteger('version_number')->default(1);
            $table->foreignId('approved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('approved_at')->nullable();
            $table->decimal('calculated_progress', 8, 2)->default(0);
            $table->string('progress_mode', 20)->default('calculated');
            $table->decimal('manual_progress', 8, 2)->nullable();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('updated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->softDeletes();
            $table->unique('code');
            $table->index(['department_id', 'status']);
            $table->index(['owner_id', 'start_date', 'end_date']);
        });

        Schema::create('strategic_plan_versions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('strategic_plan_id')->constrained('strategic_plans')->restrictOnDelete();
            $table->unsignedInteger('version_number');
            $table->longText('snapshot');
            $table->string('reason', 1000)->nullable();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->unique(['strategic_plan_id', 'version_number'], 'strategic_plan_versions_unique');
        });

        Schema::create('strategic_goals', function (Blueprint $table) {
            $table->id();
            $table->foreignId('strategic_plan_id')->constrained('strategic_plans')->restrictOnDelete();
            $table->string('name', 200);
            $table->string('code', 50);
            $table->text('description')->nullable();
            $table->string('perspective', 40);
            $table->foreignId('owner_id')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('department_id')->nullable()->constrained('departments')->nullOnDelete();
            $table->string('priority', 20)->default('medium');
            $table->decimal('weight', 8, 2)->default(1);
            $table->date('start_date')->nullable();
            $table->date('due_date')->nullable();
            $table->string('status', 30)->default('not_started')->index();
            $table->unsignedInteger('sort_order')->default(0);
            $table->decimal('calculated_progress', 8, 2)->default(0);
            $table->string('progress_mode', 20)->default('calculated');
            $table->decimal('manual_progress', 8, 2)->nullable();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('updated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->softDeletes();
            $table->unique(['strategic_plan_id', 'code'], 'strategic_goals_plan_code_unique');
            $table->index(['perspective', 'status']);
        });

        Schema::create('strategic_objectives', function (Blueprint $table) {
            $table->id();
            $table->foreignId('strategic_goal_id')->constrained('strategic_goals')->restrictOnDelete();
            $table->string('name', 200);
            $table->string('code', 50);
            $table->text('description')->nullable();
            $table->foreignId('owner_id')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('department_id')->nullable()->constrained('departments')->nullOnDelete();
            $table->string('priority', 20)->default('medium');
            $table->decimal('weight', 8, 2)->default(1);
            $table->date('start_date')->nullable();
            $table->date('due_date')->nullable();
            $table->decimal('target_value', 16, 4)->nullable();
            $table->string('measurement_unit', 50)->nullable();
            $table->string('status', 30)->default('not_started')->index();
            $table->string('progress_basis', 20)->default('initiatives');
            $table->unsignedInteger('sort_order')->default(0);
            $table->decimal('calculated_progress', 8, 2)->default(0);
            $table->decimal('kpi_achievement', 8, 2)->nullable();
            $table->string('progress_mode', 20)->default('calculated');
            $table->decimal('manual_progress', 8, 2)->nullable();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('updated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->softDeletes();
            $table->unique(['strategic_goal_id', 'code'], 'strategic_objectives_goal_code_unique');
            $table->index(['department_id', 'due_date']);
        });

        Schema::create('strategic_initiatives', function (Blueprint $table) {
            $table->id();
            $table->foreignId('strategic_objective_id')->constrained('strategic_objectives')->restrictOnDelete();
            $table->string('name', 200);
            $table->string('code', 50);
            $table->text('description')->nullable();
            $table->foreignId('owner_id')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('department_id')->nullable()->constrained('departments')->nullOnDelete();
            $table->string('priority', 20)->default('medium');
            $table->decimal('weight', 8, 2)->default(1);
            $table->decimal('estimated_budget', 16, 2)->nullable();
            $table->decimal('actual_budget', 16, 2)->nullable();
            $table->date('start_date')->nullable();
            $table->date('due_date')->nullable();
            $table->date('actual_end_date')->nullable();
            $table->decimal('progress_percentage', 8, 2)->default(0);
            $table->string('status', 30)->default('not_started')->index();
            $table->text('expected_outcomes')->nullable();
            $table->string('progress_mode', 20)->default('calculated');
            $table->decimal('manual_progress', 8, 2)->nullable();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('updated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->softDeletes();
            $table->unique(['strategic_objective_id', 'code'], 'strategic_initiatives_objective_code_unique');
            $table->index(['department_id', 'due_date']);
        });

        Schema::create('strategic_milestones', function (Blueprint $table) {
            $table->id();
            $table->foreignId('strategic_initiative_id')->constrained('strategic_initiatives')->restrictOnDelete();
            $table->string('name', 200);
            $table->text('description')->nullable();
            $table->foreignId('owner_id')->nullable()->constrained('users')->nullOnDelete();
            $table->date('planned_start_date')->nullable();
            $table->date('planned_due_date')->nullable();
            $table->date('actual_completion_date')->nullable();
            $table->decimal('weight', 8, 2)->default(1);
            $table->decimal('completion_percentage', 8, 2)->default(0);
            $table->string('status', 30)->default('not_started')->index();
            $table->unsignedInteger('sort_order')->default(0);
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('updated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->softDeletes();
            $table->index(['strategic_initiative_id', 'planned_due_date'], 'strategic_milestones_due_idx');
        });

        Schema::create('strategic_kpis', function (Blueprint $table) {
            $table->id();
            $table->string('name', 200);
            $table->string('code', 50);
            $table->text('description')->nullable();
            $table->string('measurement_type', 30)->default('numeric');
            $table->string('measurement_unit', 50)->nullable();
            $table->decimal('baseline_value', 16, 4)->nullable();
            $table->decimal('target_value', 16, 4)->nullable();
            $table->decimal('current_value', 16, 4)->nullable();
            $table->decimal('achievement', 8, 2)->nullable();
            $table->string('frequency', 30)->default('monthly');
            $table->string('direction', 20)->default('higher');
            $table->decimal('on_track_threshold', 8, 2)->default(90);
            $table->decimal('at_risk_threshold', 8, 2)->default(70);
            $table->foreignId('owner_id')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('department_id')->nullable()->constrained('departments')->nullOnDelete();
            $table->date('start_date')->nullable();
            $table->date('target_date')->nullable();
            $table->string('status', 30)->default('not_started')->index();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('updated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->softDeletes();
            $table->unique('code');
        });

        Schema::create('strategic_objective_kpi', function (Blueprint $table) {
            $table->id();
            $table->foreignId('strategic_objective_id')->constrained('strategic_objectives')->cascadeOnDelete();
            $table->foreignId('strategic_kpi_id')->constrained('strategic_kpis')->restrictOnDelete();
            $table->decimal('weight', 8, 2)->default(1);
            $table->timestamps();
            $table->unique(['strategic_objective_id', 'strategic_kpi_id'], 'strategic_objective_kpi_unique');
        });

        Schema::create('strategic_kpi_measurements', function (Blueprint $table) {
            $table->id();
            $table->foreignId('strategic_kpi_id')->constrained('strategic_kpis')->restrictOnDelete();
            $table->decimal('actual_value', 16, 4);
            $table->date('measurement_date');
            $table->string('reporting_period', 40)->nullable();
            $table->foreignId('submitted_by')->nullable()->constrained('users')->nullOnDelete();
            $table->string('evidence', 500)->nullable();
            $table->text('comments')->nullable();
            $table->string('approval_status', 20)->default('pending')->index();
            $table->foreignId('approved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('approved_at')->nullable();
            $table->decimal('achievement', 8, 2)->nullable();
            $table->timestamps();
            $table->index(['strategic_kpi_id', 'measurement_date'], 'strategic_kpi_measurements_date_idx');
        });

        Schema::create('strategic_kris', function (Blueprint $table) {
            $table->id();
            $table->string('name', 200);
            $table->text('description')->nullable();
            $table->string('measurement_unit', 50)->nullable();
            $table->decimal('current_value', 16, 4)->nullable();
            $table->decimal('warning_threshold', 16, 4)->nullable();
            $table->decimal('critical_threshold', 16, 4)->nullable();
            $table->string('measurement_frequency', 30)->default('monthly');
            $table->string('direction', 20)->default('higher');
            $table->foreignId('owner_id')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('department_id')->nullable()->constrained('departments')->nullOnDelete();
            $table->foreignId('risk_id')->nullable()->constrained('risks')->nullOnDelete();
            $table->string('risk_snapshot', 500)->nullable();
            $table->string('status', 30)->default('normal')->index();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('updated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::create('strategic_kri_measurements', function (Blueprint $table) {
            $table->id();
            $table->foreignId('strategic_kri_id')->constrained('strategic_kris')->restrictOnDelete();
            $table->decimal('actual_value', 16, 4);
            $table->date('measurement_date');
            $table->foreignId('submitted_by')->nullable()->constrained('users')->nullOnDelete();
            $table->text('comments')->nullable();
            $table->string('breach_level', 20)->default('normal')->index();
            $table->timestamps();
        });

        Schema::create('strategic_objective_risks', function (Blueprint $table) {
            $table->id();
            $table->foreignId('strategic_objective_id')->constrained('strategic_objectives')->restrictOnDelete();
            $table->foreignId('risk_id')->nullable()->constrained('risks')->nullOnDelete();
            $table->string('risk_snapshot', 500)->nullable();
            $table->decimal('score_at_link', 8, 2)->nullable();
            $table->text('notes')->nullable();
            $table->foreignId('linked_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('unlinked_at')->nullable();
            $table->foreignId('unlinked_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->index(['strategic_objective_id', 'unlinked_at'], 'strategic_objective_risks_active_idx');
        });

        Schema::create('strategic_compliance_links', function (Blueprint $table) {
            $table->id();
            $table->string('linkable_type', 120);
            $table->unsignedBigInteger('linkable_id');
            $table->foreignId('framework_id')->nullable()->constrained('frameworks')->nullOnDelete();
            $table->foreignId('family_id')->nullable()->constrained('families')->nullOnDelete();
            $table->unsignedBigInteger('framework_control_id')->nullable();
            $table->unsignedBigInteger('framework_control_test_id')->nullable();
            $table->unsignedBigInteger('framework_control_test_audit_id')->nullable();
            $table->foreign('framework_control_id', 'sp_link_control_fk')->references('id')->on('framework_controls')->nullOnDelete();
            $table->foreign('framework_control_test_id', 'sp_link_test_fk')->references('id')->on('framework_control_tests')->nullOnDelete();
            $table->foreign('framework_control_test_audit_id', 'sp_link_audit_fk')->references('id')->on('framework_control_test_audits')->nullOnDelete();
            $table->string('framework_snapshot', 500)->nullable();
            $table->text('gap_note')->nullable();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->index(['linkable_type', 'linkable_id'], 'strategic_compliance_links_target_idx');
        });

        Schema::create('strategic_task_links', function (Blueprint $table) {
            $table->id();
            $table->foreignId('task_id')->nullable()->constrained('tasks')->nullOnDelete();
            $table->foreignId('strategic_initiative_id')->nullable()->constrained('strategic_initiatives')->nullOnDelete();
            $table->foreignId('strategic_milestone_id')->nullable()->constrained('strategic_milestones')->nullOnDelete();
            $table->string('task_snapshot', 200)->nullable();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->index(['strategic_initiative_id', 'strategic_milestone_id'], 'strategic_task_links_parent_idx');
        });

        Schema::create('strategic_approvals', function (Blueprint $table) {
            $table->id();
            $table->foreignId('strategic_plan_id')->constrained('strategic_plans')->restrictOnDelete();
            $table->unsignedInteger('version_number')->default(1);
            $table->string('action', 40);
            $table->string('from_status', 30)->nullable();
            $table->string('to_status', 30)->nullable();
            $table->text('comment')->nullable();
            $table->foreignId('actor_id')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->index(['strategic_plan_id', 'created_at'], 'strategic_approvals_plan_idx');
        });

        Schema::create('strategic_activity_logs', function (Blueprint $table) {
            $table->id();
            $table->string('subject_type', 120);
            $table->unsignedBigInteger('subject_id');
            $table->string('action', 60);
            $table->text('description')->nullable();
            $table->longText('properties')->nullable();
            $table->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->index(['subject_type', 'subject_id'], 'strategic_activity_logs_subject_idx');
        });

        Schema::create('strategic_attachments', function (Blueprint $table) {
            $table->id();
            $table->string('attachable_type', 120);
            $table->unsignedBigInteger('attachable_id');
            $table->string('original_name', 255);
            $table->string('path', 500);
            $table->string('mime', 120)->nullable();
            $table->unsignedBigInteger('size')->default(0);
            $table->foreignId('uploaded_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->index(['attachable_type', 'attachable_id'], 'strategic_attachments_target_idx');
        });

        Schema::create('strategic_progress_overrides', function (Blueprint $table) {
            $table->id();
            $table->string('subject_type', 120);
            $table->unsignedBigInteger('subject_id');
            $table->decimal('previous_value', 8, 2)->nullable();
            $table->decimal('override_value', 8, 2);
            $table->string('reason', 1000);
            $table->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->index(['subject_type', 'subject_id'], 'strategic_progress_overrides_subject_idx');
        });

        Schema::create('strategic_progress_histories', function (Blueprint $table) {
            $table->id();
            $table->string('subject_type', 120);
            $table->unsignedBigInteger('subject_id');
            $table->decimal('progress', 8, 2);
            $table->string('source', 30);
            $table->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->index(['subject_type', 'subject_id'], 'strategic_progress_histories_subject_idx');
        });

        (new AddStrategicPlanningPermissionSeeder())->run();
    }

    public function down()
    {
        Schema::dropIfExists('strategic_progress_histories');
        Schema::dropIfExists('strategic_progress_overrides');
        Schema::dropIfExists('strategic_attachments');
        Schema::dropIfExists('strategic_activity_logs');
        Schema::dropIfExists('strategic_approvals');
        Schema::dropIfExists('strategic_task_links');
        Schema::dropIfExists('strategic_compliance_links');
        Schema::dropIfExists('strategic_objective_risks');
        Schema::dropIfExists('strategic_kri_measurements');
        Schema::dropIfExists('strategic_kris');
        Schema::dropIfExists('strategic_kpi_measurements');
        Schema::dropIfExists('strategic_objective_kpi');
        Schema::dropIfExists('strategic_kpis');
        Schema::dropIfExists('strategic_milestones');
        Schema::dropIfExists('strategic_initiatives');
        Schema::dropIfExists('strategic_objectives');
        Schema::dropIfExists('strategic_goals');
        Schema::dropIfExists('strategic_plan_versions');
        Schema::dropIfExists('strategic_plans');

        $keys = array_keys(AddStrategicPlanningPermissionSeeder::permissionMap());
        $permissionIds = \App\Models\Permission::whereIn('key', $keys)->pluck('id');
        if ($permissionIds->isNotEmpty()) {
            \App\Models\RoleResponsibility::whereIn('permission_id', $permissionIds)->delete();
            \App\Models\Permission::whereIn('id', $permissionIds)->delete();
        }
        $subgroup = \App\Models\Subgroup::where('name', 'Strategic Planning')->first();
        if ($subgroup && $subgroup->permissions()->count() === 0) {
            $subgroup->delete();
        }
    }
};
