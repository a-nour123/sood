<?php

use App\Models\SystemNotificationSetting;
use App\Services\Governance\GovernanceNotificationCatalog;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        if (!Schema::hasTable('actions') || !Schema::hasTable('system_notifications_settings')) {
            return;
        }

        $roles = array_keys(GovernanceNotificationCatalog::roles());
        $previous = [
            'Governance_Request_Submitted' => 'A governance request was submitted.',
            'Governance_Request_Assigned' => 'A governance request was assigned to a committee.',
            'Governance_Member_Assigned' => 'You were assigned to a committee.',
            'Governance_Review_Requested' => 'A committee review was requested.',
            'Governance_Review_Completed' => 'A committee review was completed.',
            'Governance_Review_Overdue' => 'A committee review is overdue.',
            'Governance_Meeting_Scheduled' => 'A committee meeting was scheduled.',
            'Governance_Meeting_Updated' => 'A committee meeting was updated.',
            'Governance_Meeting_Reminder' => 'A committee meeting reminder.',
            'Governance_Voting_Started' => 'Committee voting has started.',
            'Governance_Voting_Deadline' => 'A committee voting deadline is approaching.',
            'Governance_Decision_Finalized' => 'A governance decision was finalized.',
            'Governance_Request_Rejected' => 'A governance request was rejected.',
            'Governance_Information_Requested' => 'Additional information was requested.',
            'Governance_Exception_Expiring' => 'An approved exception is approaching expiration.',
            'Governance_Exception_Expired' => 'An approved exception has expired.',
            'Governance_Risk_Accepted' => 'A risk acceptance request was approved.',
            'Governance_Risk_Rejected' => 'A risk acceptance request was rejected.',
        ];

        foreach (GovernanceNotificationCatalog::definitions() as $name => $definition) {
            $actionId = DB::table('actions')->where('name', $name)->value('id');
            if (!$actionId) {
                $actionId = DB::table('actions')->insertGetId(['name' => $name]);
            }
            $settingId = DB::table('system_notifications_settings')->where('action_id', $actionId)->value('id');
            if (!$settingId) {
                $settingId = DB::table('system_notifications_settings')->insertGetId([
                    'action_id' => $actionId,
                    'message' => $definition['message'],
                    'status' => 1,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            } elseif (isset($previous[$name])) {
                DB::table('system_notifications_settings')
                    ->where('id', $settingId)
                    ->where('message', $previous[$name])
                    ->update(['message' => $definition['message'], 'updated_at' => now()]);
            }

            if (!Schema::hasTable('notifications_roles')) {
                continue;
            }
            foreach ($roles as $role) {
                $exists = DB::table('notifications_roles')
                    ->where('role', $role)
                    ->where('notifiable_id', $settingId)
                    ->where('notifiable_type', SystemNotificationSetting::class)
                    ->exists();
                if ($exists) {
                    continue;
                }
                DB::table('notifications_roles')->insert([
                    'role' => $role,
                    'notifiable_id' => $settingId,
                    'notifiable_type' => SystemNotificationSetting::class,
                ]);
            }
        }
    }

    public function down()
    {
        $original = [
            'Governance_Request_Submitted', 'Governance_Request_Assigned', 'Governance_Member_Assigned',
            'Governance_Review_Requested', 'Governance_Review_Completed', 'Governance_Review_Overdue',
            'Governance_Meeting_Scheduled', 'Governance_Meeting_Updated', 'Governance_Meeting_Reminder',
            'Governance_Voting_Started', 'Governance_Voting_Deadline', 'Governance_Decision_Finalized',
            'Governance_Request_Rejected', 'Governance_Information_Requested', 'Governance_Exception_Expiring',
            'Governance_Exception_Expired', 'Governance_Risk_Accepted', 'Governance_Risk_Rejected',
        ];
        $names = array_values(array_diff(array_keys(GovernanceNotificationCatalog::definitions()), $original));
        $ids = DB::table('actions')->whereIn('name', $names)->pluck('id');
        if ($ids->isEmpty()) {
            return;
        }
        $settingIds = DB::table('system_notifications_settings')->whereIn('action_id', $ids)->pluck('id');
        if (Schema::hasTable('notifications_roles') && $settingIds->isNotEmpty()) {
            DB::table('notifications_roles')
                ->where('notifiable_type', SystemNotificationSetting::class)
                ->whereIn('notifiable_id', $settingIds)
                ->delete();
        }
        DB::table('system_notifications_settings')->whereIn('id', $settingIds)->delete();
        DB::table('actions')->whereIn('id', $ids)->delete();
    }
};
