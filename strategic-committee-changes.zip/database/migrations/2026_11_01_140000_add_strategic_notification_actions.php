<?php

use App\Models\SystemNotificationSetting;
use App\Services\Strategic\StrategicNotificationCatalog;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up()
    {
        $roles = array_keys(StrategicNotificationCatalog::roles());
        foreach (StrategicNotificationCatalog::definitions() as $name => $definition) {
            $actionId = DB::table('actions')->where('name', $name)->value('id');
            if (!$actionId) {
                $actionId = DB::table('actions')->insertGetId(['name' => $name]);
            }
            if (DB::table('system_notifications_settings')->where('action_id', $actionId)->exists()) {
                continue;
            }
            $settingId = DB::table('system_notifications_settings')->insertGetId([
                'action_id' => $actionId,
                'message' => $definition['message'],
                'status' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            foreach ($roles as $role) {
                DB::table('notifications_roles')->insert([
                    'role' => $role,
                    'notifiable_id' => $settingId,
                    'notifiable_type' => SystemNotificationSetting::class,
                ]);
            }
        }
    }

    public function down()
    {
        $names = array_keys(StrategicNotificationCatalog::definitions());
        $ids = DB::table('actions')->whereIn('name', $names)->pluck('id');
        $settingIds = DB::table('system_notifications_settings')->whereIn('action_id', $ids)->pluck('id');
        DB::table('notifications_roles')
            ->where('notifiable_type', SystemNotificationSetting::class)
            ->whereIn('notifiable_id', $settingIds)
            ->delete();
        DB::table('system_notifications_settings')->whereIn('id', $settingIds)->delete();
        DB::table('actions')->whereIn('id', $ids)->delete();
    }
};
