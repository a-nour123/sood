function governanceErrors(errors) {
  $('.governance-error').text('');
  $.each(errors || {}, function (key, value) {
    $('.governance-error-' + key).text(Array.isArray(value) ? value[0] : value);
  });
}

function governanceFilters() {
  const data = {};
  $('#governance-filters').find('input, select').each(function () {
    if (this.name && $(this).val()) {
      data[this.name] = $(this).val();
    }
  });
  if (window.GovernanceFixedType) {
    data.fixed_type = window.GovernanceFixedType;
  } else if (window.GovernanceConfig && window.GovernanceConfig.fixedType) {
    data.fixed_type = window.GovernanceConfig.fixedType;
  }
  return data;
}

function governanceToken() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

$(function () {
  const config = window.GovernanceConfig || null;
  $('select.form-select').each(function () {
    if ($.fn.select2 && !$(this).data('select2')) {
      const placeholder = $.trim($(this).find('option[value=""]').first().text()) || ' ';
      $(this).select2({ width: '100%', allowClear: true, placeholder: placeholder, dir: $('html').attr('data-textdirection') === 'rtl' ? 'rtl' : 'ltr' });
    }
  });
  if (!config || !$('#governance-table').length) {
    return;
  }
  const table = $('#governance-table').DataTable({
    processing: true,
    serverSide: true,
    ajax: {
      url: config.listUrl,
      type: 'POST',
      data: function (payload) {
        payload._token = $('meta[name="csrf-token"]').attr('content');
        $.extend(payload, governanceFilters());
      }
    },
    columns: config.columns,
    columnDefs: [{
      targets: -1,
      orderable: false,
      searchable: false,
      render: function (actions) {
        const id = actions && typeof actions === 'object' ? actions.id : actions;
        const assigned = !!(actions && actions.assigned);
        let html = '<div class="dropdown"><a class="pe-1 dropdown-toggle hide-arrow text-primary" data-bs-toggle="dropdown" href="#"><i data-feather="more-vertical"></i></a><div class="dropdown-menu dropdown-menu-end">';
        if (config.permissions.show && config.showUrl) {
          html += '<a class="dropdown-item" href="' + config.showUrl.replace('__ID__', id) + '">' + config.labels.view + '</a>';
        }
        if (config.permissions.edit && assigned) {
          html += '<a class="dropdown-item governance-edit" href="#" data-id="' + id + '">' + config.labels.edit + '</a>';
        }
        if (config.permissions.delete && assigned) {
          html += '<a class="dropdown-item governance-delete" href="#" data-id="' + id + '">' + config.labels.delete + '</a>';
        }
        html += '</div></div>';
        return html;
      }
    }],
    drawCallback: function () {
      if (window.feather) {
        feather.replace();
      }
    }
  });

  $('#governance-filters').on('change', 'select, input', function () {
    table.ajax.reload();
  });

  $('#governance-form').on('submit', function (event) {
    event.preventDefault();
    const form = $(this);
    const id = form.find('[name="id"]').val();
    $.ajax({
      url: id ? config.updateUrl.replace('__ID__', id) : config.storeUrl,
      type: id ? 'PUT' : 'POST',
      data: form.serialize(),
      success: function (response) {
        makeAlert('success', response.message, "{{ __('locale.Success') }}");
        $('#governance-modal').modal('hide');
        form[0].reset();
        form.find('[name="id"]').val('');
        table.ajax.reload();
      },
      error: function (xhr) {
        var responseData = xhr.responseJSON || {};
        governanceErrors(responseData.errors);
        makeAlert('error', responseData.message, "{{ __('locale.Error') }}");
      }
    });
  });

  $('#governance-table').on('click', '.governance-edit', function (event) {
    event.preventDefault();
    const id = $(this).data('id');
    $.get(config.editUrl.replace('__ID__', id), function (response) {
      const data = response.data || {};
      const form = $('#governance-form');
      form.find('[name="id"]').val(data.id || id);
      $.each(data, function (key, value) {
        const field = form.find('[name="' + key + '"]');
        if (!field.length || value === null || typeof value === 'object') {
          return;
        }
        field.val(String(value).indexOf('T') > 0 && key.indexOf('date') >= 0 ? String(value).substring(0, 10) : value);
      });
      form.find('select').trigger('change');
      $('#governance-modal').modal('show');
    });
  });

  $('#governance-table').on('click', '.governance-delete', function (event) {
    event.preventDefault();
    const id = $(this).data('id');
    Swal.fire({
      title: config.labels.confirm,
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: config.labels.delete,
      cancelButtonText: config.labels.cancel
    }).then(function (result) {
      if (!result.isConfirmed) {
        return;
      }
      $.ajax({
        url: config.deleteUrl.replace('__ID__', id),
        type: 'DELETE',
        data: { _token: $('meta[name="csrf-token"]').attr('content') },
        success: function (response) {
          makeAlert('success', response.message, "{{ __('locale.Success') }}");
          table.ajax.reload();
        },
        error: function (xhr) {
          var responseData = xhr.responseJSON || {};
          makeAlert('error', responseData.message, "{{ __('locale.Error') }}");
        }
      });
    });
  });

  $('.governance-open-create').on('click', function () {
    const form = $('#governance-form');
    form[0].reset();
    form.find('[name="id"]').val('');
    form.find('[name="idempotency_key"]').val(governanceToken());
    form.find('select').trigger('change');
    governanceErrors({});
  });

  $(document).on('change', '#governance-form [name="department_id"]', function () {
    const department = String($(this).val() || '');
    const users = $('#governance-form [name="user_id"]');
    users.find('option').each(function () {
      const dep = $(this).attr('data-department');
      if (!this.value || !dep) {
        return;
      }
      $(this).prop('disabled', department !== '' && dep !== department);
    });
    users.trigger('change');
  });
});
