function strategicErrors(errors) {
  $('.strategic-error').text('');
  $.each(errors || {}, function (key, value) {
    $('.strategic-error-' + key).text(Array.isArray(value) ? value[0] : value);
  });
}

function strategicFilters() {
  const data = {};
  $('#strategic-filters').find('input, select').each(function () {
    if (this.name && $(this).val()) {
      data[this.name] = $(this).val();
    }
  });
  return data;
}

$(function () {
  const config = window.StrategicConfig || null;
  if (!config || !$('#strategic-table').length) {
    return;
  }

  const table = $('#strategic-table').DataTable({
    processing: true,
    serverSide: true,
    ajax: {
      url: config.listUrl,
      type: 'POST',
      data: function (payload) {
        payload._token = $('meta[name="csrf-token"]').attr('content');
        $.extend(payload, strategicFilters());
      }
    },
    columns: config.columns,
    columnDefs: [{
      targets: -1,
      orderable: false,
      searchable: false,
      render: function (actions) {
        const id = actions && typeof actions === 'object' ? actions.id : actions;
        const assigned = !actions || typeof actions !== 'object' || actions.assigned !== false;
        const canShow = assigned && config.showUrl && config.permissions.show;
        const canEdit = assigned && config.permissions.edit;
        const canDelete = assigned && config.permissions.delete;
        if (!canShow && !canEdit && !canDelete) {
          return '';
        }
        let html = '<div class="d-inline-flex"><div class="dropdown"><a class="pe-1 dropdown-toggle hide-arrow text-primary" data-bs-toggle="dropdown" href="#"><i data-feather="more-vertical"></i></a><div class="dropdown-menu dropdown-menu-end">';
        if (canShow) {
          html += '<a class="dropdown-item" href="' + config.showUrl.replace('__ID__', id) + '">' + config.labels.view + '</a>';
        }
        if (canEdit) {
          html += '<a class="dropdown-item strategic-edit" href="#" data-id="' + id + '">' + config.labels.edit + '</a>';
        }
        if (canDelete) {
          html += '<a class="dropdown-item strategic-delete" href="#" data-id="' + id + '">' + config.labels.delete + '</a>';
        }
        html += '</div></div></div>';
        return html;
      }
    }],
    order: [[1, 'desc']],
    drawCallback: function () {
      if (window.feather) {
        feather.replace();
      }
    }
  });

  $('#strategic-form').on('submit', function (event) {
    event.preventDefault();
    const form = $(this);
    const id = form.find('[name="id"]').val();
    const url = id ? config.updateUrl.replace('__ID__', id) : config.storeUrl;
    $.ajax({
      url: url,
      type: id ? 'PUT' : 'POST',
      data: form.serialize(),
      success: function (response) {
        makeAlert('success', response.message, "{{ __('locale.Success') }}");
        $('#strategic-modal').modal('hide');
        form[0].reset();
        form.find('[name="id"]').val('');
        form.find('select').val('').trigger('change');
        table.ajax.reload();
      },
      error: function (xhr) {
        var responseData = xhr.responseJSON || {};
        strategicErrors(responseData.errors);
        makeAlert('error', responseData.message, "{{ __('locale.Error') }}");
      }
    });
  });

  $('#strategic-table').on('click', '.strategic-edit', function (event) {
    event.preventDefault();
    const id = $(this).data('id');
    $.get(config.editUrl.replace('__ID__', id), function (response) {
      const data = response.data || {};
      const form = $('#strategic-form');
      form.find('[name="id"]').val(data.id || id);
      $.each(data, function (key, value) {
        const field = form.find('[name="' + key + '"]');
        if (!field.length) {
          return;
        }
        if (typeof value === 'string' && value.indexOf('T') > 0 && key.indexOf('date') >= 0) {
          field.val(value.substring(0, 10));
        } else if (value && typeof value === 'object' && value.date) {
          field.val(String(value.date).substring(0, 10));
        } else {
          field.val(value === null ? '' : value);
        }
      });
      form.find('select').trigger('change');
      $('#strategic-modal').modal('show');
    });
  });

  $('#strategic-table').on('click', '.strategic-delete', function (event) {
    event.preventDefault();
    const id = $(this).data('id');
    Swal.fire({
      title: config.labels.confirm,
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: config.labels.delete,
      cancelButtonText: config.labels.cancel
    }).then(function (result) {
      if (!result.isConfirmed) {
        return;
      }
      $.ajax({
        url: config.deleteUrl.replace('__ID__', id),
        type: 'DELETE',
        data: { _token: $('meta[name="csrf-token"]').attr('content') },
        success: function (response) {
          makeAlert('success', response.message, "{{ __('locale.Success') }}");
          table.ajax.reload();
        },
        error: function (xhr) {
          var responseData = xhr.responseJSON || {};
          makeAlert('error', responseData.message, "{{ __('locale.Error') }}");
        }
      });
    });
  });

  $('.strategic-open-create').on('click', function () {
    const form = $('#strategic-form');
    form[0].reset();
    form.find('[name="id"]').val('');
    form.find('select').val('').trigger('change');
    strategicErrors({});
  });
});
