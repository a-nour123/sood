# Strategic Planning

Strategic Planning is a native CyberMode GRC V3 module. It uses the existing Laravel 8 monolith, Blade, Eloquent, the custom permission tables, DataTables, Dompdf, and Maatwebsite Excel. It does not add a frontend framework or a second risk, task, or compliance engine.

## Navigation

The sidebar entry is **Strategic Planning**. It is rendered from `resources/data/menu-data/horizontalMenu.json` and is visible when the user has `strategic_plan.list` or, for reports, `strategic_report.list`.

## Data

New tables are created by `database/migrations/2026_11_01_120000_create_strategic_planning_tables.php`.

Plans, goals, objectives, initiatives, milestones, KPIs, and KRIs use soft deletes. Measurements, approvals, versions, activity, and link rows are retained so historical evidence is not removed when a parent is edited. Child foreign keys use `restrictOnDelete` so a hard delete of a referenced plan or risk association cannot silently erase history. Links to existing risks, tasks, frameworks, controls, tests, and audits store a snapshot and use `nullOnDelete`, so deleting a source record in its own module does not destroy the strategic history.

There is no organization table in this project, so plans are scoped by department and owner rather than `organization_id`.

## Progress

`ProgressCalculator` rolls progress up one level at a time:

- Initiative progress is the weighted average of milestone completion. Direct initiative progress is used only when the initiative has no milestones.
- Objective progress uses weighted initiative progress, or weighted KPI achievement when the objective basis is `kpis`. The two sources are not averaged together.
- Goal progress is the weighted average of objective progress.
- Plan progress is the weighted average of goal progress.

Zero or negative weights are ignored. An empty child set returns 0. A manual override requires a reason and is stored in `strategic_progress_overrides` and `strategic_progress_histories`. The stored operational value and the KPI achievement remain separate columns.

## KPI and KRI

KPI achievement is type-specific. Higher-is-better uses current / target. Lower-is-better uses the baseline span `(baseline - current) / (baseline - target)`. A zero target or zero span does not divide by zero. Boolean KPIs compare the desired state instead of using the ratio. On-track and at-risk thresholds are columns on each KPI.

KRI warning and critical checks are independent and support higher-is-worse and lower-is-worse directions.

## Integrations

- Risks use the existing `risks`, `risk_scorings`, `residual_risk_scoring_histories`, and `mitigations` records through `strategic_objective_risks`.
- Frameworks, families (domains), controls, control tests, and control-test audits are linked through `strategic_compliance_links`. Gap text is stored on the link because this project has no separate compliance-gap table.
- Tasks are created with the existing `Task` model and `TaskCreated` event, then linked through `strategic_task_links`.

## Authorization

Route permissions are registered in `getRoutesToPermission()`. The workflow endpoint checks the permission for the specific action in `PlanWorkflow`, because submit, approve, and reject are different permissions on one URL. Record access is limited to role 1, the owner, the creator, or the record department. Department-wide records with a null department are visible to users who already passed the route permission.

Approved plans cannot be edited in place. `revise` stores a JSON snapshot in `strategic_plan_versions`, increments the version, and returns the plan to draft.

## Notifications and scheduling

`StrategicNotifier` sends through the existing `Notific` facade. `php artisan strategic:alerts` runs daily at 08:00 and notifies owners about deadlines, missing KPI measurements, KRI breaches, critical linked risks, and linked task deadlines. A per-day cache key prevents repeat alerts.

## Reports

Reports read the same tables as the dashboard. Excel uses `StrategicTabularExport`. PDF uses Dompdf with DejaVu Sans so Arabic text can render. Export routes require `strategic_report.export`.

## Tests

Unit tests in `tests/Unit/Strategic` cover KPI math, weighted progress, KRI thresholds, and the approval state machine. They do not boot the application database. Run:

```bash
php vendor/bin/phpunit tests/Unit/Strategic
```

Apply the schema with the new migration only:

```bash
php artisan migrate --path=database/migrations/2026_11_01_120000_create_strategic_planning_tables.php
```

Do not run `migrate:fresh` against this database.
