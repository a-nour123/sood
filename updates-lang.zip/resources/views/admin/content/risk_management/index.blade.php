@extends('admin/layouts/contentLayoutMaster')

@section('title', __('risk.Submit Risk'))

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/dataTables.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/responsive.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/flatpickr/flatpickr.min.css')) }}">

    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/buttons.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/animate/animate.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">
@endsection
<style>
    #risk_addational_notes_submit {
        height: 93px;

    }

    .ql-spanblock:after {
        content: "<sb/>";
    }

    .spanblock {
        background-color: #f2f2f2;
        border: 1px solid #CCC;
        line-height: 19px;
        padding: 6px 10px;
        border-radius: 3px;
        margin: 15px 0;
    }

    .tab {
        display: none;
    }

    .tab:first-of-type {
        display: block;
        /* Show the first step by default */
    }

    .basic-wizard .stepper-horizontal {
        overflow: auto !important;
    }

    .wizard-fields {
        padding: 10px;
    }
</style>

@section('page-style')
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-sweet-alerts.css')) }}">
    <style>
        .risk-stat-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
            gap: 1rem;
            padding: 0 1.25rem 1.25rem;
        }
        .risk-stat {
            position: relative;
            display: flex;
            flex-direction: column;
            min-height: 148px;
            padding: 1rem 1rem .95rem;
            background: #fff;
            border: 1px solid #ebe9f1;
            border-radius: 14px;
            box-shadow: 0 8px 20px rgba(68, 34, 92, .04);
        }
        .risk-stat-top {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: .5rem;
            margin-bottom: .85rem;
        }
        .risk-stat-icon {
            width: 40px;
            height: 40px;
            flex: 0 0 40px;
            border-radius: 12px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: var(--accent-soft);
            color: var(--accent);
        }
        .risk-stat-icon svg {
            width: 18px;
            height: 18px;
            display: block;
        }
        .risk-stat-menu {
            width: 28px;
            height: 28px;
            border: 0;
            border-radius: 8px;
            background: transparent;
            color: #b9b9c3;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0;
        }
        .risk-stat-menu:hover {
            background: #f4f3f7;
            color: #44225c;
        }
        .risk-stat-menu svg {
            width: 16px;
            height: 16px;
        }
        .risk-stat-value {
            font-size: 1.7rem;
            font-weight: 800;
            line-height: 1;
            color: #2f2b3d;
        }
        .risk-stat-label {
            margin-top: .4rem;
            color: #6e6b7b;
            font-size: .85rem;
            font-weight: 600;
            line-height: 1.35;
        }
        .risk-stat-percent {
            margin-top: auto;
            padding-top: .7rem;
            color: var(--accent);
            font-size: .8rem;
            font-weight: 700;
        }
    </style>
@endsection

@section('content')
    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">

            <div class="row breadcrumbs-top  widget-grid">
                <div class="col-12">
                    <div class="page-title mt-2">
                        <div class="row">
                            <div class="col-md-6 ps-0">
                                @if (@isset($breadcrumbs))
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}"
                                                style="display: flex;">
                                                <svg class="stroke-icon">
                                                    <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}">
                                                    </use>
                                                </svg></a></li>
                                        @foreach ($breadcrumbs as $breadcrumb)
                                            <li class="breadcrumb-item">
                                                @if (isset($breadcrumb['link']))
                                                    <a
                                                        href="{{ $breadcrumb['link'] == 'javascript:void(0)' ? $breadcrumb['link'] : url($breadcrumb['link']) }}">
                                                @endif
                                                {{ $breadcrumb['name'] }}
                                                @if (isset($breadcrumb['link']))
                                                    </a>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ol>
                                @endisset
                        </div>
                        <div class="col-md-6 pe-0" style="text-align: end;">

                            <div class="action-content">

                                @if (auth()->user()->hasPermission('riskmanagement.create'))
                                    <button class=" btn btn-primary " type="button" data-bs-toggle="modal"
                                        data-bs-target="#add-new-risk">
                                        <i class="fa fa-plus"></i>
                                    </button>
                                    <a href="{{ route('admin.risk_management.notificationsSettingsRisk') }}"
                                        class=" btn btn-primary " target="_self">
                                        <i class="fa fa-regular fa-bell"></i>
                                    </a>
                                @endif
                                <a href="{{ route('admin.risk_management.assessment_requests') }}"
                                    class=" btn btn-primary " title="{{ __('risk.AssessmentRequests') }}">
                                    <i class="fa fa-solid fa-file-lines"></i>
                                </a>
                                @if (auth()->user()->hasPermission('riskmanagement.configuration'))
                                    <a href="{{ route('admin.risk_management.ksu_settings') }}"
                                        class=" btn btn-primary " title="{{ __('risk.KsuRiskSettings') }}">
                                        <i class="fa fa-solid fa-sliders"></i>
                                    </a>
                                @endif
                                @if (auth()->user()->hasPermission('riskmanagement.configuration') ||
                                        auth()->user()->hasPermission('classic_risk_formula.list'))
                                    <div class="btn-group dropdown dropdown-icon-wrapper ">
                                        <button type="button"
                                            class="btn btn-primary dropdown-toggle dropdown-toggle-split"
                                            data-bs-toggle="dropdown" aria-expanded="false"
                                            style="border-radius: 8px !important;
                                        width: 40px;
                                        text-align: center;
                                        color: #FFF !important;
                                        height: 28px;
                                        line-height: 19px;">
                                            <i class="fa fa-solid fa-gear"></i>
                                        </button>
                                        <div class="dropdown-menu dropdown-menu-end export-types">
                                            @if (auth()->user()->hasPermission('classic_risk_formula.list'))
                                                <span class="dropdown-item" data-type="excel">
                                                    <i class="fa fa-solid fa-gear"></i>
                                                    <span class="px-1 text-start">
                                                        <a href="{{ route('admin.configure.riskmodels.show') }}">
                                                            {{ __('locale.ClassicRiskFormula') }}
                                                        </a>
                                                    </span>
                                                </span>
                                            @endif
                                            @if (auth()->user()->hasPermission('riskmanagement.configuration'))
                                                <span class="dropdown-item" data-type="excel">
                                                    <i class="fa fa-solid fa-gear"></i>
                                                    <span class="px-1 text-start">
                                                        <a
                                                            href="{{ route('admin.risk_management.configuretion') }}">{{ __('locale.configuretion') }}</a>
                                                    </span>
                                                </span>
                                            @endif
                                        </div>

                                    </div>
                                @endif
                                <x-export-import name="{{ __('risk.Risk') }}"
                                    createPermissionKey='vulnerability_management.create'
                                    exportPermissionKey='riskmanagement.export'
                                    exportRouteKey='admin.risk_management.ajax.export'
                                    importRouteKey='admin.risk_management.import' />

                                @if (auth()->user()->hasPermission('riskmanagement.Risk Dashboard'))
                                    <a class="btn btn-primary"
                                        href="{{ route('admin.risk_management.ajax.statistics.risk') }}"> <i
                                            class="fa-solid fa-file-invoice"></i></a>
                                @endif
                                @if (auth()->user()->hasPermission('riskmanagement.export'))

                                    <a title="{{ __('locale.Export') }} {{ __('locale.PDF') }}" href="#" id="exportAsPdfButton"
                                        class="dt-button btn btn-primary " onclick="exportAsPdf()">
                                        <i class="fas fa-file-pdf"></i> <!-- Replace with your desired icon class -->
                                    </a>
                                @endif

                                @if (!empty($missingRiskAssetsCount) && $missingRiskAssetsCount > 0)
                                    <button type="button"
                                        class="btn btn-warning position-relative"
                                        data-bs-toggle="modal"
                                        data-bs-target="#missingRiskAssetsModal"
                                        title="{{ __('risk.MissingRiskAlert') }}"
                                        style="border-radius: 8px; min-width: 40px; height: 28px; line-height: 1; padding: 0 10px;">
                                        <i class="fas fa-exclamation-triangle"></i>
                                        <span
                                            class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger"
                                            style="font-size: 0.65rem;">
                                            {{ $missingRiskAssetsCount }}
                                        </span>
                                    </button>
                                @endif

                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <div id="quill-service-content" class="d-none"></div>

</div>

<div class="card">
    <div class="card-header mb-3">
        <div class="head-label">
            <h4 class="card-title">{{ __('locale.Risk Management') }}
        </div>
    </div>


    <div class="risk-stat-grid">
            <div class="risk-stat" style="--accent:#5e5873; --accent-soft:#f3f2f7;">
                <div class="risk-stat-top">
                    <span class="risk-stat-icon" aria-hidden="true">
                        <i data-feather="minus-circle"></i>
                    </span>
                    @if (auth()->user()->hasPermission('riskmanagement.Risks and Assets') ||
                            auth()->user()->hasPermission('riskmanagement.Risks and Controls'))
                        <div class="dropdown">
                            <button type="button" class="risk-stat-menu dropdown-toggle hide-arrow"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                <i data-feather="more-vertical"></i>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end">
                                @if (auth()->user()->hasPermission('riskmanagement.Risks and Assets'))
                                    <li>
                                        <button class="dropdown-item open-modal" data-id="RiskByAsset"
                                            onclick="navigateToRiskByAssetReport()">
                                            {{ __('locale.risk_by_asset') }}
                                        </button>
                                    </li>
                                @endif
                                @if (auth()->user()->hasPermission('riskmanagement.Risks and Controls'))
                                    <li>
                                        <button class="dropdown-item open-modal" data-id="RiskByControl"
                                            onclick="navigateToRiskByControlReport(0)">
                                            {{ __('locale.risk_by_control') }}
                                        </button>
                                    </li>
                                @endif
                                @if (auth()->user()->hasPermission('riskmanagement.Risks and Controls') ||
                                        auth()->user()->hasPermission('riskmanagement.Risks and Assets'))
                                    <li>
                                        <a class="dropdown-item" href="{{ route('admin.reporting.GetRiskCenter') }}">
                                            {{ __('locale.risk_center') }}
                                        </a>
                                    </li>
                                @endif
                            </ul>
                        </div>
                    @endif
                </div>
                <div class="risk-stat-value">{{ $riskInfo['overview'] ?? 0 }}</div>
                <div class="risk-stat-label">{{ __('locale.overview_risks') }}</div>
                <div class="risk-stat-percent">+{{ $riskInfo['overview_percentage'] ?? 0 }}%</div>
            </div>

            <div class="risk-stat" style="--accent:#28c76f; --accent-soft:#e9f8ef;">
                <div class="risk-stat-top">
                    <span class="risk-stat-icon" aria-hidden="true">
                        <i data-feather="check-circle"></i>
                    </span>
                </div>
                <div class="risk-stat-value">{{ $riskInfo['closedRisk']['count'] ?? 0 }}</div>
                <div class="risk-stat-label">{{ __('locale.closed_risks') }}</div>
                <div class="risk-stat-percent">+{{ $riskInfo['closedRisk']['percentage'] ?? 0 }}%</div>
            </div>

            <div class="risk-stat" style="--accent:#ea5455; --accent-soft:#fff1f1;">
                <div class="risk-stat-top">
                    <span class="risk-stat-icon" aria-hidden="true">
                        <i data-feather="x-circle"></i>
                    </span>
                </div>
                <div class="risk-stat-value">{{ $riskInfo['openRisk']['count'] ?? 0 }}</div>
                <div class="risk-stat-label">{{ __('locale.open_risks') }}</div>
                <div class="risk-stat-percent">+{{ $riskInfo['openRisk']['percentage'] ?? 0 }}%</div>
            </div>

            <div class="risk-stat" style="--accent:#7367f0; --accent-soft:#f3f1ff;">
                <div class="risk-stat-top">
                    <span class="risk-stat-icon" aria-hidden="true">
                        <i data-feather="archive"></i>
                    </span>
                </div>
                <div class="risk-stat-value">{{ $riskInfo['MitigatedRisk']['count'] ?? 0 }}</div>
                <div class="risk-stat-label">{{ __('locale.mitigated_risks') }}</div>
                <div class="risk-stat-percent">+{{ $riskInfo['MitigatedRisk']['percentage'] ?? 0 }}%</div>
            </div>

            @if ($appetiteSummary)
                <div class="risk-stat" style="--accent:#ea5455; --accent-soft:#fff1f1;"
                    title="{{ __('risk.RiskAppetite') }}: {{ $appetiteSummary['name'] }} ({{ __('risk.AppetiteMaxScore') }} {{ $appetiteSummary['limit'] }})">
                    <div class="risk-stat-top">
                        <span class="risk-stat-icon" aria-hidden="true">
                            <i data-feather="target"></i>
                        </span>
                    </div>
                    <div class="risk-stat-value">{{ $appetiteSummary['exceeding'] }} / {{ $appetiteSummary['open'] }}</div>
                    <div class="risk-stat-label">{{ __('risk.OpenRisksExceedingAppetite') }}</div>
                    <div class="risk-stat-percent">{{ $appetiteSummary['percentage'] }}%</div>
                </div>
            @endif
    </div>



</div>

<!-- Advanced Search -->
<x-submit-risk-search id="advanced-search-datatable" createModalID="add-new-risk" :statuses="$statuses" />
<!--/ Advanced Search -->

<!-- Create Form -->
@if (auth()->user()->hasPermission('riskmanagement.create'))
    <x-submit-risk-form id="add-new-risk" title="{{ __('risk.AddANewRisk') }}" :riskGroupings="$riskGroupings" :threatGroupings="$threatGroupings"
        :locations="$locations" :frameworks="$frameworks" :assets="$assets" :assetGroups="$assetGroups" :categories="$categories" :technologies="$technologies"
        :teams="$teams" :enabledUsers="$enabledUsers" :riskSources="$riskSources" :riskScoringMethods="$riskScoringMethods" :riskLikelihoods="$riskLikelihoods" :impacts="$impacts"
        :tags="$tags" :owners="$owners" :reviewers="$reviewers" :projects="$projects" :mitigationEfforts="$mitigationEfforts"
        :mitigationCosts="$mitigationCosts" :planningStrategies="$planningStrategies" :reviews="$reviews" :nextSteps="$nextSteps"
        :departments="$departments" />
@endif

<!--/ Create Form -->

{{-- Missing risk assets: searchable AJAX modal (no full list fetch) --}}
@if (!empty($missingRiskAssetsCount) && $missingRiskAssetsCount > 0)
    <div class="modal fade" id="missingRiskAssetsModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-bottom">
                    <div>
                        <h5 class="modal-title mb-0">{{ __('risk.MissingRiskAlert') }}</h5>
                        <small class="text-muted">{{ __('risk.MissingRiskSearchHint') }}
                            ({{ $missingRiskAssetsCount }})</small>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="{{ __('locale.Close') }}"></button>
                </div>
                <div class="modal-body">
                    <label class="form-label">{{ __('risk.SearchAsset') }}</label>
                    <select id="missing-risk-assets-select" class="form-select"
                        data-placeholder="{{ __('risk.SearchAssetPlaceholder') }}" style="width:100%;">
                        <option value="">{{ __('locale.SelectOption') }}</option>
                    </select>
                    <div id="missing-asset-selected-info" class="mt-3 p-3 rounded border bg-light d-none">
                        <div class="small text-muted mb-1">{{ __('risk.SelectedAsset') }}</div>
                        <div id="missing-asset-name" style="color:black" class="fw-semibold"></div>
                        <div class="small mt-1"><span class="text-muted">{{ __('risk.AssetRank') }}:</span>
                            <span id="missing-asset-rank">—</span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">{{ __('locale.Cancel') }}</button>
                    <button type="button" class="btn btn-primary" id="create-risk-from-missing-asset" disabled>
                        {{ __('risk.AddANewRisk') }}
                    </button>
                </div>
            </div>
        </div>
    </div>
@endif

<!-- Update Form -->
{{-- <x-submit-risk-form id="edit-risk" title="{{ __('locale.EditRisk') }}" :riskGroupings = "$riskGroupings" :threatGroupings = "$threatGroupings" :locations = "$locations" :frameworks = "$frameworks" :categories = "$categories" :technologies = "$technologies" :teams = "$teams" :enabledUsers = "$enabledUsers" :riskSources = "$riskSources" :riskScoringMethods = "$riskScoringMethods" :riskLikelihoods = "$riskLikelihoods" :impacts = "$impacts" :tags = "$tags" /> --}}
<!--/ Update Form -->

@endsection

@section('vendor-script')
<script src="{{ asset(mix('vendors/js/tables/datatable/jquery.dataTables.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.bootstrap5.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.responsive.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/responsive.bootstrap5.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/buttons.print.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/datatables.buttons.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>
@endsection

@section('page-script')
<script src="{{ asset(mix('js/scripts/forms/form-select2.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
<script src="{{ asset('cdn/ckeditor.js') }}"></script>
<script src="{{ asset(mix('vendors/js/pickers/flatpickr/flatpickr.min.js')) }}"></script>

{{-- Add Verification translation --}}
<script>
    let URLs = [],
        lang = [];
    lang['confirmDelete'] = "{{ __('locale.ConfirmDelete') }}";
    lang['cancel'] = "{{ __('locale.Cancel') }}";
    lang['View'] = "{{ __('locale.View') }}";
    lang['Delete'] = "{{ __('locale.Delete') }}";
    lang['success'] = "{{ __('locale.Success') }}";
    lang['error'] = "{{ __('locale.Error') }}";
    lang['confirmDeleteMessage'] = "{{ __('locale.AreYouSureToDeleteThisRecord') }}";
    lang['revert'] = "{{ __('locale.YouWontBeAbleToRevertThis') }}";
    lang['DetailsOfItem'] = "{{ __('locale.DetailsOfItem', ['item' => __('locale.risk')]) }}";
    permission = [];
    permission['show'] = {{ auth()->user()->hasPermission('riskmanagement.list') ? 1 : 0 }};
    permission['delete'] = {{ auth()->user()->hasPermission('riskmanagement.delete') ? 1 : 0 }};
    permission['avoid_risk'] = {{ auth()->user()->hasPermission('riskmanagement.avoid_risk') ? 1 : 0 }};
    permission['transfer_risk'] = {{ auth()->user()->hasPermission('riskmanagement.transfer_risk') ? 1 : 0 }};
    permission['accept_risk'] = {{ auth()->user()->hasPermission('riskmanagement.accept_risk') ? 1 : 0 }};
    permission['redo_assessment'] = {{ auth()->user()->hasPermission('riskmanagement.redo_assessment') ? 1 : 0 }};
    lang['AvoidRisk'] = "{{ __('risk.AvoidRisk') }}";
    lang['TransferRisk'] = "{{ __('risk.TransferRisk') }}";
    lang['AcceptRisk'] = "{{ __('risk.AcceptRisk') }}";
    lang['RedoAssessment'] = "{{ __('risk.RedoAssessment') }}";
    URLs['ajax_list'] = "{{ route('admin.risk_management.ajax.index') }}";
    URLs['show'] = "{{ route('admin.risk_management.show', ':id') }}";
    URLs['create'] = "{{ route('admin.risk_management.ajax.store') }}";
    URLs['delete'] = "{{ route('admin.risk_management.ajax.destroy', ':id') }}";
    URLs['search_assets'] = "{{ route('admin.risk_management.ajax.search_assets') }}";
    URLs['search_missing_risk_assets'] = "{{ route('admin.risk_management.ajax.search_missing_risk_assets') }}";
</script>
<script src="{{ asset('ajax-files/risk_management/index.js') }}?v={{ filemtime(public_path('ajax-files/risk_management/index.js')) }}"></script>
<script>
    function initAssetAjaxSelect($el, url, extra) {
        if (!$el.length) return;
        $el.select2($.extend(true, {
            width: '100%',
            allowClear: true,
            placeholder: $el.data('placeholder') || '',
            minimumInputLength: 2,
            ajax: {
                url: url,
                dataType: 'json',
                delay: 300,
                data: function(params) {
                    return { q: params.term || '', page: params.page || 1 };
                },
                processResults: function(data, params) {
                    params.page = params.page || 1;
                    return {
                        results: data.results || [],
                        pagination: { more: !!(data.pagination && data.pagination.more) }
                    };
                },
                cache: true
            },
            dropdownParent: $el.closest('.modal').length ? $el.closest('.modal') : $(document.body)
        }, extra || {}));
    }

    $(document).ready(function() {
        // Create-risk modal: related asset search
        initAssetAjaxSelect($('.select-affected-asset-ajax'), URLs['search_assets']);

        $('.select-affected-asset-ajax').on('select2:select', function(e) {
            const d = e.params.data || {};
            $('#asset_owner_display').val(d.owner_name || '—');
            $('#asset_rank_display').val(d.rank || '—');
            $('#asset_rank_snapshot').val(d.rank || '');
        });
        $('.select-affected-asset-ajax').on('select2:clear', function() {
            $('#asset_owner_display').val('—');
            $('#asset_rank_display').val('—');
            $('#asset_rank_snapshot').val('');
        });

        // Missing-risk assets modal
        let missingSelectInited = false;
        $('#missingRiskAssetsModal').on('shown.bs.modal', function() {
            if (!missingSelectInited) {
                initAssetAjaxSelect($('#missing-risk-assets-select'), URLs['search_missing_risk_assets']);
                missingSelectInited = true;
            }
            $('#missing-risk-assets-select').val(null).trigger('change');
            $('#missing-asset-selected-info').addClass('d-none');
            $('#create-risk-from-missing-asset').prop('disabled', true);
        });

        $('#missing-risk-assets-select').on('select2:select', function(e) {
            const d = e.params.data || {};
            $('#missing-asset-name').text(d.name || d.text || '');
            $('#missing-asset-rank').text(d.rank || '—');
            $('#missing-asset-selected-info').removeClass('d-none');
            $('#create-risk-from-missing-asset').prop('disabled', false).data('asset', d);
        });
        $('#missing-risk-assets-select').on('select2:clear', function() {
            $('#missing-asset-selected-info').addClass('d-none');
            $('#create-risk-from-missing-asset').prop('disabled', true);
        });

        $('#create-risk-from-missing-asset').on('click', function() {
            const d = $(this).data('asset') || {};
            $('#missingRiskAssetsModal').modal('hide');
            $('#add-new-risk').modal('show');
            const $assetSelect = $('.select-affected-asset-ajax');
            if (d.id && $assetSelect.length) {
                const option = new Option(d.name || d.text, d.id + '_asset', true, true);
                $assetSelect.append(option).trigger('change');
                $assetSelect.trigger({
                    type: 'select2:select',
                    params: { data: {
                        id: d.id + '_asset',
                        text: d.name || d.text,
                        owner_id: d.owner_id,
                        owner_name: d.owner_name,
                        manager_id: d.manager_id,
                        rank: d.rank
                    }}
                });
            }
        });
    });
</script>
<script>
    function navigateToRiskByAssetReport() {
        // Construct the URL with query parameters for RiskByAsset
        var url = '{{ route('admin.reporting.GetRiskByAsset') }}' + '?type=2&asset=0&risk=0';

        // Navigate to the constructed URL
        window.location.href = url;
    }

    function navigateToRiskByControlReport(type) {
        // Construct the URL with the framework ID and type
        var url = '{{ route('admin.reporting.GetRiskByControl') }}' + '?type=' + type;

        // Navigate to the constructed URL
        window.location.href = url;
    }

    // Initialize flatpickr on the specified input field
    document.addEventListener('DOMContentLoaded', function() {
        flatpickr(".flatpickr-date-time-compliance", {
            enableTime: true, // Enable time selection if you want to pick both date and time
            dateFormat: "Y-m-d H:i", // Format to display the selected date (e.g., 2024-11-18 15:30)
            minDate: "today", // Optional: Disable past dates
        });
    });
</script>
<script>
    $(document).ready(function() {
        let currentStep = 0; // Track current step
        const steps = $(".tab"); // All steps
        const totalSteps = steps.length;
        const form = $("#wizard-form"); // Form reference

        // Function to style step circles dynamically based on the current step
        function styleStepCircles() {
            const activeColor = '#4CAF50'; // Green for active step
            const inactiveColor = '#CCCCCC'; // Light gray for inactive steps
            const activeTextColor = 'white'; // White text color for active circle
            const inactiveTextColor = '#555555'; // Dark gray text color for inactive circles

            const totalSteps = $(".step").length;

            for (let i = 0; i < totalSteps; i++) {
                const stepCircle = $(`.stepper-${i + 1} .step-circle`);
                const stepText = $(`.stepper-${i + 1} .step-title`);

                if (i === currentStep) {
                    stepCircle.css('background-color', activeColor);
                    stepCircle.css('color', activeTextColor);
                    stepText.css('color', activeColor);
                } else {
                    stepCircle.css('background-color', inactiveColor);
                    stepCircle.css('color', inactiveTextColor);
                    stepText.css('color', inactiveTextColor);
                }
            }
        }

        // Function to hide all steps and show the current one
        function showStep(step) {
            currentStep = step;
            styleStepCircles();

            steps.hide();
            $(steps[step]).show();

            if (step === 0) {
                $("#backbtn").hide();
            } else {
                $("#backbtn").show();
            }

            if (step === totalSteps - 1) {
                $("#nextbtn").text(@json(__('locale.Submit')));
            } else {
                $("#nextbtn").text(@json(__('locale.Next')));
            }
        }

        function validateStep() {
            const currentTab = $(steps[currentStep]);

            const invalidFields = currentTab.find(":input").filter(function() {
                return !this.validity.valid;
            });

            if (invalidFields.length > 0) {
                invalidFields.each(function() {
                    $(this).addClass('is-invalid');
                    if ($(this).hasClass('select2-hidden-accessible')) {
                        $(this).next('.select2-container').find('.select2-selection').addClass('border-danger');
                        $(this).siblings('.error').text("{{ __('locale.Required') }}").addClass('text-danger');
                    }
                });
                const $first = invalidFields.first();
                const $target = $first.hasClass('select2-hidden-accessible') ? $first.next('.select2-container') : $first;
                if ($target.length) {
                    $target[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
                return false;
            }

            return true;
        }

        $(document).on('change', '#wizard-form select', function() {
            if (this.validity.valid) {
                $(this).removeClass('is-invalid');
                $(this).next('.select2-container').find('.select2-selection').removeClass('border-danger');
                $(this).siblings('.error').empty();
            }
        });

        function nextStep() {
            if (validateStep()) {
                if (currentStep === totalSteps - 1) {
                    form.submit();
                } else {
                    currentStep++;
                    showStep(currentStep);
                }
            }
        }

        function backStep() {
            if (currentStep > 0) {
                currentStep--;
                showStep(currentStep);
            }
        }

        $(document).on("click", "#nextbtn", function(event) {
            nextStep();
        });

        $("#backbtn").on("click", function() {
            backStep();
        });

        // Initially show the first step
        showStep(currentStep);

        // Reset to the first step when the modal is closed and clear validation errors
        $('.wizardModal').on('hidden.bs.modal', function() {
            currentStep = 0; // Reset current step
            showStep(currentStep); // Show the first step

            // Clear any validation errors
            $("input").removeClass('is-invalid'); // Remove invalid class from all inputs
        });

        // Remove validation error when the user starts typing
        $("input").on("input", function() {
            $(this).removeClass('is-invalid'); // Remove invalid class as user types
        });
    });


    // Configured risk matrix (Configure > Risk Calculation): [impact_id][likelihood_id] → {score, level, color, display_name}
    const RISK_MATRIX = @json(app(\App\Services\KsuRiskMethodologyService::class)->matrix());

    function updateKsuRiskEvaluation() {
        const impact = parseInt($("[name='current_impact_id']").val(), 10);
        const likelihood = parseInt($("[name='current_likelihood_id']").val(), 10);
        const cell = impact && likelihood && RISK_MATRIX[impact] ? RISK_MATRIX[impact][likelihood] : null;
        if (!cell) {
            $('#risk_evaluation_text, #treatment_eval_text').text('—');
            $('#risk_evaluation_badge').hide();
            return;
        }
        const label = cell.display_name || cell.level;
        $('#risk_evaluation_text').text(cell.score + ' / ' + label);
        $('#treatment_eval_text').text(cell.score + ' — ' + label);
        $('#risk_evaluation_score').val(cell.score);
        $('#risk_evaluation_level').val(cell.level);
        $('#risk_evaluation_badge').css({display:'inline-block', background: cell.color || '#999', color:'#111'}).text(label);
    }

    function toggleTreatmentPanels() {
        const v = $('#planMitigationOption').val();
        $('#planMitigationInputs, #avoidTreatmentInputs, #transferTreatmentInputs, #acceptTreatmentInputs').hide();
        if (v === 'mitigate' || v === 'PlanAMitigation') $('#planMitigationInputs').show();
        else if (v === 'avoid') $('#avoidTreatmentInputs').show();
        else if (v === 'transfer') $('#transferTreatmentInputs').show();
        else if (v === 'accept') $('#acceptTreatmentInputs').show();
    }

    let actionPlanIndex = 0;
    function addActionPlanRow(data = {}) {
        const i = actionPlanIndex++;
        const html = `<div class="border rounded p-2 mb-2 action-plan-row" data-index="${i}">
            <div class="row g-1">
                <div class="col-md-3"><input class="form-control" name="action_plans[${i}][title]" placeholder="{{ __('risk.ActionTitle') }}" value="${data.title||''}"></div>
                <div class="col-md-3"><input type="number" min="0" max="100" step="0.01" class="form-control ap-likelihood" name="action_plans[${i}][likelihood_reduction]" placeholder="{{ __('risk.LikelihoodReduction') }}" value="${data.likelihood_reduction||0}"></div>
                <div class="col-md-3"><input type="number" min="0" max="100" step="0.01" class="form-control ap-impact" name="action_plans[${i}][impact_reduction]" placeholder="{{ __('risk.ImpactReduction') }}" value="${data.impact_reduction||0}"></div>
                <div class="col-md-2"><input type="date" class="form-control" name="action_plans[${i}][due_date]" value="${data.due_date||''}"></div>
                <div class="col-md-1"><button type="button" class="btn btn-sm btn-outline-danger remove-action-plan">×</button></div>
            </div>
        </div>`;
        $('#action_plans_container').append(html);
        updateActionPlanTotals();
    }
    function updateActionPlanTotals() {
        let l = 0, i = 0;
        $('.ap-likelihood').each(function(){ l += parseFloat($(this).val())||0; });
        $('.ap-impact').each(function(){ i += parseFloat($(this).val())||0; });
        if (l > 100) l = 100; if (i > 100) i = 100;
        $('#action_plans_totals').text(l.toFixed(1) + '% / ' + i.toFixed(1) + '%');
    }

    $(document).ready(function() {
        toggleTreatmentPanels();
        $('#planMitigationOption').on('change', toggleTreatmentPanels);
        $("[name='current_impact_id'], [name='current_likelihood_id']").on('change', updateKsuRiskEvaluation);
        $('#add_action_plan_row').on('click', function(){ addActionPlanRow(); });
        $(document).on('click', '.remove-action-plan', function(){ $(this).closest('.action-plan-row').remove(); updateActionPlanTotals(); });
        $(document).on('input', '.ap-likelihood, .ap-impact', updateActionPlanTotals);
        $('#responsible_department_id').on('change', function(){
            $('#risk_assessment_hidden').val($(this).find('option:selected').text());
        });
        $('.treatment-decision-date').on('change', function(){
            const pair = $(this).data('pair');
            if (!pair || !this.value) return;
            const d = new Date(this.value);
            d.setFullYear(d.getFullYear() + 1);
            $(`[name='${pair}']`).val(d.toISOString().slice(0,10));
        });
        if ($('#action_plans_container').length && !$('.action-plan-row').length) {
            addActionPlanRow();
        }
    });
    $(document).ready(function() {
        $('#performReviewOption').on('change', function() {
            if ($(this).val() === 'PerformAReview') {
                $('#planReviewInputs').slideDown();
            } else {
                $('#planReviewInputs').slideUp();
            }
        });
    });

    $('#owner_id').on('change', function() {
        const deptManager = $(this).find('option:selected').data('department-manager');
        if (deptManager) {
            $('#owner_manager_id').val(deptManager).trigger('change');
        }
    });

</script>

@endsection
