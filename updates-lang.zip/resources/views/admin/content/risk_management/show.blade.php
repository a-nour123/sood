@extends('admin/layouts/contentLayoutMaster')

@section('title', __('risk.ViewRisk'))
@section('vendor-style')
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/pickadate/pickadate.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/flatpickr/flatpickr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">
@endsection

@section('page-style')
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/forms/pickers/form-pickadate.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/forms/pickers/form-flat-pickr.css')) }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        @media (max-width: 576px) {
            .text-sm-only-center {
                text-align: center
            }



        }

        .basic-wizard .stepper-horizontal {
            overflow: hidden !important;
        }

        .text-label {
            font-size: 1.1rem;
            font-weight: 900;
        }


        .cursor-pointer {
            cursor: pointer;
        }

        #impact-detail-btn svg,
        #likelihood-detail-btn svg,
        .delete_supporting_documentation svg {
            width: 25px;
            height: 25px;
        }

        .highcharts-credits {
            display: none;
        }

        #editRiskModal .modal-row>div {
            position: initial !important;
        }

        <style>.nav-pills {
            display: flex;
            justify-content: space-between;
            width: 100%;
        }

        .main-color {
            color: #44225c;

        }

        .nav-pills .nav-item {
            flex: 1;
            text-align: center;
            background-color: #f2f2f2;
            border-inline: 1px solid white;
        }

        .feather,
        [data-feather] {
            height: 1.5rem;
            width: 1.5rem;
        }

        .nav-pills .nav-link {
            width: 100%;
            border-radius: 0;


        }

        .container-tab {

            margin: 25px 1px 10px;
            border-radius: 10px;
        }


        .dropdown-toggle::after {

            vertical-align: 0px !important;
            margin-inline: 7px
        }

        .custom-span {
            padding: 0px 8px;
            font-size: 9px;
            font-weight: 800;
            position: relative;
            display: inline-flex;
            align-items: center;
        }

        .span-red {
            color: #c96f62;
            border: 1px solid #c96f62;
            background: #fff2ea;
        }

        .span-yellow {
            color: #ebc204;
            border: 1px solid #ebc204;
            background: #fcf9f8;
            margin-left: 0.5rem;
        }

        .custom-span::before {
            content: "•";
            color: currentColor;
            font-size: 14px;
            margin-right: 5px;
            display: inline-block;
        }

        .custom-p {
            color: #44225c;
            font-weight: 900;
            font-size: 18px;
        }

        .card.risk-session {
            padding: 14px;
        }

        .nav-link:hover {
            color: #44225c !important;
        }

        .nav-link.active:hover {
            color: #fff !important;
        }

        .accordion-button {
            background: #44225c !important;
            color: #fff !important;
            border: none;
        }

        .fas.fa-chevron-down {
            right: 0;
            margin-inline: 20px
        }

        .accordion-button:not(.collapsed) {
            background: #44225c !important;
            color: #fff !important;
            box-shadow: none;
        }

        .accordion-button:focus,
        .accordion-button:hover {
            background: #44225c !important;
            color: #fff !important;
            box-shadow: none;
        }

        .nav-pills .nav-link {
            padding: 0.786rem 1.5rem;
            font-size: 1rem;
            line-height: 1rem;
            border: 1px solid transparent;
            color: #5e5873;
            height: 75px;
        }

        .nav-pills .nav-link {

            height: 50px;
        }

        .rt-collapsible > .rt-card-header {
            cursor: pointer;
            user-select: none;
        }

        .rt-collapsible:not(.is-open) > .rt-card-header {
            border-bottom-color: transparent;
        }

        .rt-collapsible > .rt-card-header > .rt-card-title {
            margin-inline-end: auto;
        }

        .rt-collapsible.is-open > .rt-card-header .rt-collapse-chevron {
            transform: rotate(180deg);
        }

        #RiskScoreOverTimeBtn .history-chevron,
        .rt-collapse-btn .history-chevron {
            transition: transform 0.3s ease;
        }

        #RiskScoreOverTimeBtn:not(.collapsed) .history-chevron,
        .rt-collapse-btn:not(.collapsed) .history-chevron {
            transform: rotate(180deg);
        }

        /* Rotate the icon when the accordion is expanded */
        .accordion-button:not(.collapsed) #chevronIcon {
            transform: rotate(180deg);
            transition: transform 0.3s ease;
            /* Smooth transition */
        }

        /* Default state (collapsed) */
        /* Default state: Icon is up (collapsed) */
        #chevronIcon {
            transform: rotate(180deg);
            /* Rotate up by default */
            transition: transform 0.3s ease;
            /* Smooth transition */
        }

        /* Expanded state: Icon is down */
        .accordion-button:not(.collapsed) #chevronIcon {
            transform: rotate(0deg);
            /* Rotate down when expanded */
        }

        /* Ensure the icon is positioned at the end of the button */
        .accordion-button {
            position: relative;
            /* Required for absolute positioning of the icon */
        }

        #chevronIcon {
            position: absolute;
            /* Position the icon at the end */
            right: 1rem;
            /* Adjust spacing from the right */
        }

        .ql-toolbar.ql-snow+.ql-container.ql-snow {
            border-top: 0px;
            height: 150px;
        }

        .btn-green {
            background-color: #03781d !important;
            border-color: #03781d !important;
            color: #fff !important;
        }

        .ql-toolbar.ql-snow {
            width: 600px;
        }

        .ql-toolbar.ql-snow+.ql-container.ql-snow {

            width: 600px;
        }

        .badge-step {
            background-color: #c30c0c;
            color: white;
            border-radius: 50%;
            width: 40px;
            height: 40px;


        }

        .bg-custom {
            background: #f2f2f2;
            padding: 12px;
        }

        .rounded-p {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 50px;
            height: 50px;
            color: #93312b;
            background: #fff2ea;
            font-weight: 800;
            margin: 0 !important;
        }

        @media (max-width: 768px) {
            .nav-pills .nav-link {
                height: 70px;
            }
        }
    </style>
@endsection
@section('content')
    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">

            <div class="row breadcrumbs-top  widget-grid">
                <div class="col-12">
                    <div class="page-title mt-2">
                        <div class="row">
                            <div class="col-sm-6 ps-0">
                                @if (@isset($breadcrumbs))
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}"
                                                style="display: flex;">
                                                <svg class="stroke-icon">
                                                    <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}">
                                                    </use>
                                                </svg></a></li>
                                        @foreach ($breadcrumbs as $breadcrumb)
                                            <li class="breadcrumb-item">
                                                @if (isset($breadcrumb['link']))
                                                    <a
                                                        href="{{ $breadcrumb['link'] == 'javascript:void(0)' ? $breadcrumb['link'] : url($breadcrumb['link']) }}">
                                                @endif
                                                {{ $breadcrumb['name'] }}
                                                @if (isset($breadcrumb['link']))
                                                    </a>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ol>
                                @endisset
                        </div>

                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- start tab -->
    <div class="container-tab">
        <div class="row">
            <div class="col-12">
                <div class=" risk-session">
                    <!-- start tab -->
                    <div class="card p-4">
                        <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                            <li class="nav-item mb-2 mb-md-0" role="presentation">
                                <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill"
                                    data-bs-target="#pills-home" type="button" role="tab"
                                    aria-controls="pills-home" aria-selected="true">{{ __('risk.Identification') }}</button>
                            </li>
                            <li class="nav-item mb-2 mb-md-0" role="presentation">
                                <button class="nav-link" id="pills-analysis-tab" data-bs-toggle="pill"
                                    data-bs-target="#pills-analysis" type="button" role="tab"
                                    aria-controls="pills-home" aria-selected="true">{{ __('risk.RiskAnalysis') }}</button>
                            </li>

                            <li class="nav-item mb-2 mb-md-0" role="presentation">
                                <button class="nav-link" id="pills-evalution-tab" data-bs-toggle="pill"
                                    data-bs-target="#pills-evalution" type="button" role="tab"
                                    aria-controls="pills-evalution" aria-selected="false">{{ __('risk.RiskEvaulationAndTreatment') }}</button>
                            </li>
                            <li class="nav-item mb-2 mb-md-0" role="presentation">
                                <button class="nav-link" id="pills-review-tab" data-bs-toggle="pill"
                                    data-bs-target="#pills-review" type="button" role="tab"
                                    aria-controls="pills-review" aria-selected="false">{{ __('risk.RiskReviewingAndMonitoring') }}</button>
                            </li>
                            <li class="nav-item mb-2 mb-md-0" role="presentation">

                                <button class="nav-link" id="pills-comment-trail-tab" data-bs-toggle="pill"
                                    data-bs-target="#pills-comment-trail" type="button" role="tab"
                                    aria-controls="pills-comment-trail" aria-selected="false">
                                    <div class="d-flex justify-content-center align-items-center">
                                        <p class="badge-step d-flex justify-content-center align-items-center mb-0">
                                            {{ count($data['comments']) }}</p>
                                        <p class="mb-0 ms-2">{{ __('risk.CommentAndTrail') }}</p>
                                    </div>
                                </button>
                            </li>
                        </ul>
                        <div class="row align-items-center">
                            <!-- Left Side: ID, Subject, Status -->
                            <div class="col-12 col-md-7 col-lg-8 d-flex justify-content-start align-items-center">
                                <div class="col-2 col-lg-4">{{ __('locale.ID') }} #: {{ __($data['id']) }}</div>
                                <div class="col-4 col-lg-4">{{ __('locale.ScenarioDescription') }}:
                                    {{ $data['subject'] }}</div>
                                <div class="col-6 col-lg-4">
                                    {{ __('locale.Status') }}:
                                    <span class="custom-span span-red rounded-pill">{{ __($data['status']) }}</span>
                                </div>
                            </div>

                            <!-- Right Side: Edit Subject, Change Status Button, Dropdown -->
                            <div class="col-12 col-md-5 col-lg-4 d-flex justify-content-end align-items-center">
                                <!-- Edit Subject Icon and Form -->
                                @if (auth()->user()->hasPermission('riskmanagement.update'))
                                    {{-- <span id="edit-subject" class="display-9 me-2" style="cursor: pointer">
                                        <i data-feather="edit" style="width: 20px; color: #44225c; height: 20px;"></i>
                                    </span> --}}
                                    <form id="edit-subject-form" method="post" action="/" class="px-0 d-none"
                                        id="edit-subject-container">
                                        @csrf
                                        <div class="row align-items-center">
                                            <div class="col-8">
                                                <input type="text" class="form-control"
                                                    value="{{ $data['subject'] }}" name="subject">
                                                <span class="error error-subject"></span>
                                                <input type="hidden" name="id" value="{{ $data['id'] }}">
                                            </div>
                                            <div class="col-4">
                                                <button id="cancel-edit-subject" class="btn btn-danger btn-sm"
                                                    type="button">
                                                    {{ __('locale.Cancel') }}
                                                </button>
                                                <button id="submit-edit-subject" class="btn btn-success btn-sm"
                                                    type="button">
                                                    {{ __('locale.Submit') }}
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                @endif

                                <!-- Change Status Button -->
                                <button type="button" class="btn btn-outline-primary me-2" data-bs-toggle="modal"
                                    data-bs-target="#changeRiskStatusModal">
                                    {{ __('locale.ChangeStatus') }}
                                </button>


                                <!-- Actions Dropdown -->
                                <div class="btn-group">
                                    <select class="form-control dt-input dt-select select20" id="risk-actions"
                                        data-column="3" data-column-index="2" data-id="{{ $data['id'] }}">
                                        <option class="step-default-option" selected value="">
                                            {{ __('locale.Actions') }}
                                        </option>
                                        @if ($data['status'] == 'Closed')
                                            <option class="step-1-option" value="ReopenRisk" style="display: none;">
                                                {{ __('risk.ReopenRisk') }}</option>
                                        @else
                                            @if (auth()->user()->hasPermission('riskmanagement.AbleToCloseRisks'))
                                                <option class="step-1-option" value="CloseRisk"
                                                    style="display: none;">{{ __('risk.CloseRisk') }}</option>
                                            @endif
                                        @endif
                                        @if (auth()->user()->hasPermission('riskmanagement.update'))
                                            <option class="step-1-option" value="EditRisk" style="display: none;">
                                                {{ __('risk.EditRisk') }}</option>
                                        @endif
                                        @if (auth()->user()->hasPermission('riskmanagement.update'))
                                            <option class="step-2-option" value="EditRisk2" style="display: none;">
                                                {{ __('risk.EditRisk') }}</option>
                                        @endif

                                        {{-- <option class="step-1-option" value="ChangeStatus" style="display: none;">
                                            {{ __('locale.ChangeStatus') }}</option> --}}
                                        @if (auth()->user()->hasPermission('plan_mitigation.create'))
                                            <option class="step-3-option" value="ResetMitigations"
                                                style="display: none;">{{ __('risk.ResetMitigations') }}</option>
                                        @endif
                                        @if (auth()->user()->hasPermission('perform_reviews.create'))
                                            <option class="step-4-option" value="PerformAReview"
                                                style="display: none;">{{ __('risk.PerformAReview') }}</option>
                                            <option class="step-4-option" value="ResetReviews"
                                                style="display: none;">{{ __('risk.ResetReviews') }}</option>
                                        @endif

                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <style>
                        .rt-tab { --rt-border: #e8e8ef; --rt-muted: #8a8a99; --rt-soft: #f7f7fb; }
                        .rt-card { background: #fff; border: 1px solid var(--rt-border); border-radius: 10px; margin-bottom: 1rem; }
                        .rt-card-header { display: flex; flex-wrap: wrap; gap: .5rem; justify-content: space-between; align-items: center; padding: .9rem 1.1rem; border-bottom: 1px solid var(--rt-border); }
                        .rt-card-title { margin: 0; font-size: 1rem; font-weight: 700; }
                        .rt-card-body { padding: 1.1rem; }
                        .rt-label { font-size: .75rem; color: var(--rt-muted); text-transform: uppercase; letter-spacing: .02em; margin-bottom: .2rem; }
                        .rt-value { font-weight: 600; word-break: break-word; }
                        .rt-tile { background: var(--rt-soft); border-radius: 8px; padding: .7rem .9rem; height: 100%; }
                        .rt-text-box { background: var(--rt-soft); border-radius: 8px; padding: .8rem .9rem; min-height: 90px; max-height: 180px; overflow: auto; white-space: pre-line; }
                        .rt-text-box.rt-html { white-space: normal; }
                        .rt-score { border-radius: 10px; padding: 1rem; text-align: center; height: 100%; }
                        .rt-score-value { font-size: 2rem; font-weight: 800; line-height: 1.1; }
                        .rt-arrow { font-size: 1.8rem; color: var(--rt-muted); }
                        .rt-bar { height: 6px; background: #eee; border-radius: 3px; overflow: hidden; min-width: 80px; }
                        .rt-bar > span { display: block; height: 100%; }
                        .rt-request { border: 1px solid var(--rt-border); border-left-width: 5px; border-radius: 8px; padding: 1rem; margin-top: 1rem; }
                        .rt-request.is-approved { border-left-color: #28c76f; }
                        .rt-request.is-rejected { border-left-color: #ea5455; }
                        .rt-request.is-pending { border-left-color: #ff9f43; }
                        .approval-cycle { display: flex; align-items: flex-start; overflow-x: auto; padding: .5rem 0 .25rem; }
                        .approval-step { flex: 0 0 auto; width: 150px; text-align: center; }
                        .approval-dot { width: 34px; height: 34px; line-height: 34px; font-weight: 700; border-radius: 50%; margin: 0 auto; }
                        .approval-line { flex: 1 1 auto; height: 3px; min-width: 30px; margin-top: 16px; border-radius: 2px; }
                        .rt-empty { color: var(--rt-muted); font-style: italic; }
                        .rt-avatar { width: 38px; height: 38px; border-radius: 50%; background: #44225c; color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 700; flex: 0 0 38px; }
                        .rt-timeline-item { position: relative; padding: 0 0 1rem 1.2rem; border-left: 2px solid var(--rt-border); margin-left: .4rem; }
                        .rt-timeline-item::before { content: ''; position: absolute; left: -7px; top: 3px; width: 12px; height: 12px; border-radius: 50%; background: #44225c; }
                        .rt-timeline-item:last-child { padding-bottom: 0; }
                        .rt-modal .modal-content { border: 0; border-radius: 14px; overflow: hidden; }
                        .rt-modal .modal-header { background: #f8f7fb; border-bottom: 1px solid #ebe9f1; padding: 1rem 1.5rem; }
                        .rt-modal .modal-title { font-weight: 700; color: #44225c; }
                        .rt-modal .modal-body { background: #fbfafd; padding: 1.25rem 1.5rem 0; }
                        .rt-modal .form-label, .rt-modal .text-label { font-weight: 600; font-size: .8rem; color: #5e5873; margin-bottom: .3rem; }
                        .rt-form-section { background: #fff; border: 1px solid #ebe9f1; border-radius: 12px; padding: 1rem 1.1rem .9rem; margin-bottom: 1rem; }
                        .rt-form-section-title { display: flex; align-items: center; gap: .45rem; font-weight: 700; color: #44225c; font-size: .9rem; margin-bottom: .85rem; padding-bottom: .6rem; border-bottom: 1px dashed #ebe9f1; }
                        .rt-form-section-title svg { width: 16px; height: 16px; }
                        .rt-form-section .row > [class*="col-"] { margin-bottom: .5rem; }
                        .rt-editor { height: 130px; background: #fff; }
                        .rt-file-chip { display: inline-flex; align-items: center; gap: .35rem; background: #f3f2f7; border: 1px solid #ebe9f1; border-radius: 20px; padding: .25rem .65rem; font-size: .8rem; }
                        .rt-file-chip svg { width: 14px; height: 14px; }
                        .rt-modal-actions { position: sticky; bottom: 0; display: flex; justify-content: flex-end; gap: .5rem; padding: .9rem 0 1.1rem; background: #fbfafd; border-top: 1px solid #ebe9f1; margin-top: .25rem; z-index: 2; }
                        .rt-section-title { font-size: .75rem; font-weight: 700; text-transform: uppercase; letter-spacing: .04em; color: #44225c; margin: .25rem 0 .6rem; padding-bottom: .35rem; border-bottom: 1px dashed #ebe9f1; }
                        .rt-appetite { overflow: visible; }
                        .rt-appetite .rt-card-body { padding-block: .85rem; padding-inline: 1rem 1.1rem; }
                        .rt-appetite-icon {
                            display: inline-flex;
                            align-items: center;
                            justify-content: center;
                            flex: 0 0 34px;
                            width: 34px;
                            height: 34px;
                            border-radius: 8px;
                            background: #f3eef7;
                            color: #44225c;
                        }
                        .rt-appetite-icon svg {
                            width: 16px;
                            height: 16px;
                            display: block;
                        }
                    </style>
                    <div class="tab-content" id="pills-tabContent">
                        <!-- step 1 -->
                        <div class="tab-pane fade show active" id="pills-home" role="tabpanel"
                            aria-labelledby="pills-home-tab">



                            @php
                                $inh = $data['ksu_inherent'] ?? null;
                                $res = $data['ksu_residual'] ?? null;
                                $inhImpactName = $inh ? optional($impacts->firstWhere('id', $inh['impact']))->name : null;
                                $inhLikelihoodName = $inh ? optional($riskLikelihoods->firstWhere('id', $inh['likelihood']))->name : null;
                                $catalogLabels = fn ($items) => collect($items ?? [])->map(fn ($c) => trim(($c['number'] ?? '') . ' - ' . ($c['name'] ?? ''), ' -'))->all();
                                $names = fn ($items, $key = 'name') => collect($items ?? [])->pluck($key)->filter()->values()->all();
                                $identificationSections = [
                                    __('risk.SectionMapping') => [
                                        [
                                            [__('risk.VulnerabilityMapping'), $catalogLabels($data['riskCatalogs']), 'badges'],
                                            [__('risk.ThreatMapping'), $catalogLabels($data['threatCatalogs']), 'badges'],
                                        ],
                                    ],
                                    __('risk.SectionGeneral') => [
                                        [
                                            [__('locale.SubmissionDate'), format_date($data['submission_date'], '—'), 'text'],
                                            [__('risk.Category'), $data['category']['name'] ?? null, 'text'],
                                            [__('locale.ExternalReferenceId'), $data['reference_id'] ?? null, 'text'],
                                            [__('locale.SubmittedBy'), $data['submitted_by']['name'] ?? null, 'text'],
                                        ],
                                    ],
                                    __('risk.SectionOwnership') => [
                                        [
                                            [__('risk.RiskOwner'), $data['owner']['name'] ?? null, 'text'],
                                            [__('locale.OwnersManager'), $data['owner_manager']['name'] ?? null, 'text'],
                                        ],
                                    ],
                                    __('risk.SectionScope') => [
                                        [
                                            [__('locale.SiteLocation'), $names($data['locations']), 'badges'],
                                            [__('risk.AffectedAssets'), array_merge($names($data['assets']), $names($data['assetGroups'])), 'badges'],
                                        ],
                                        [
                                            [__('risk.AssetOwner'), collect($assets)->whereIn('id', $data['asset_ids'])->pluck('owner_name')->filter()->unique()->implode(', ') ?: null, 'text'],
                                            [__('risk.AssetRank'), $data['asset_rank_snapshot'] ?? null, 'text'],
                                        ],
                                        [
                                            [__('locale.Team'), $names($data['teams']), 'badges'],
                                            [__('locale.AdditionalStakeholders'), $names($data['additional_stakeholders']), 'badges'],
                                        ],
                                        [
                                            [__('risk.Tags'), $names($data['tags'], 'tag'), 'badges', 12],
                                        ],
                                    ],
                                ];
                            @endphp

                            <div class="rt-tab">
                                @if (!empty($data['risk_appetite']))
                                    @php $appetiteStatus = $data['appetite_status'] ?? null; @endphp
                                    <div class="rt-card rt-appetite mb-1" style="border-inline-start: 4px solid {{ $appetiteStatus ? ($appetiteStatus['within'] ? '#28c76f' : '#ea5455') : '#44225c' }};">
                                        <div class="rt-card-body">
                                            <div class="d-flex align-items-start justify-content-between gap-1">
                                                <div class="d-flex align-items-start gap-1 min-w-0">
                                                    <span class="rt-appetite-icon" aria-hidden="true">
                                                        <i data-feather="target"></i>
                                                    </span>
                                                    <div class="min-w-0">
                                                        <div class="fw-bold">
                                                            {{ __('risk.RiskAppetite') }}
                                                            @if ($data['risk_appetite']['name'])
                                                                : {{ $data['risk_appetite']['name'] }}
                                                                <span class="text-muted">({{ __('risk.AppetiteMaxScore') }} {{ $data['risk_appetite']['value'] }})</span>
                                                            @endif
                                                        </div>
                                                        @if ($data['risk_appetite']['statement'])
                                                            <div class="text-muted small mt-50" style="white-space: pre-line;">{{ $data['risk_appetite']['statement'] }}</div>
                                                        @endif
                                                    </div>
                                                </div>
                                                @if ($appetiteStatus)
                                                    <span class="badge {{ $appetiteStatus['within'] ? 'bg-success' : 'bg-danger' }} flex-shrink-0">
                                                        {{ $appetiteStatus['within'] ? __('risk.WithinAppetite') : __('risk.ExceedsAppetite') }}
                                                    </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                @endif

                                {{-- Scores --}}
                                <div class="row g-2 mb-1">
                                    <div class="col-md-6 col-lg-3">
                                        <div class="rt-score h-100" style="background: {{ $inh['color'] ?? '#999' }}1f;">
                                            <div class="rt-label"><i data-feather="alert-triangle"></i> {{ __('risk.InherentRisk') }}</div>
                                            <div class="rt-score-value" id="inherent_risk_score" style="color: {{ $inh['color'] ?? '#555' }};">
                                                {{ $inh['score'] ?? $data['calculated_risk'] }}
                                            </div>
                                            <div class="fw-bold" style="color: {{ $inh['color'] ?? '#555' }};">
                                                {{ $inh['display_name'] ?? $data['calculated_risk_data']['name'] }}
                                            </div>
                                            @if ($inh)
                                                <small class="text-muted">L{{ $inh['likelihood'] }} × I{{ $inh['impact'] }}</small>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-3">
                                        <div class="rt-score h-100" style="background: {{ $res['color'] ?? '#999' }}1f;">
                                            <div class="rt-label"><i data-feather="check-circle"></i> {{ __('risk.ResidualRisk') }}</div>
                                            <div class="rt-score-value" id="residual_risk_score" style="color: {{ $res['color'] ?? '#555' }};">
                                                {{ $res['score'] ?? $data['residual_risk'] }}
                                            </div>
                                            <div class="fw-bold" style="color: {{ $res['color'] ?? '#555' }};">
                                                {{ $res['display_name'] ?? $data['residual_risk_data']['name'] }}
                                            </div>
                                            @if ($res)
                                                <small class="text-muted">L{{ $res['likelihood'] }} × I{{ $res['impact'] }}</small>
                                            @endif
                                            @if (!empty($data['appetite_status']))
                                                <div class="mt-50">
                                                    <span class="badge {{ $data['appetite_status']['within'] ? 'bg-success' : 'bg-danger' }}">
                                                        {{ $data['appetite_status']['within'] ? __('risk.WithinAppetite') : __('risk.ExceedsAppetite') }}
                                                        ({{ $data['appetite_status']['score'] }} / {{ $data['appetite_status']['limit'] }})
                                                    </span>
                                                </div>
                                            @endif
                                        </div>
                                    </div>

                                    {{-- Classic risk scoring --}}
                                    <div class="col-lg-6">
                                        <div class="rt-card h-100 mb-0">
                                            <div class="rt-card-header">
                                                <h5 class="rt-card-title">{{ __('risk.ClassicRiskScoring') }}</h5>
                                                @if (auth()->user()->hasPermission('riskmanagement.update'))
                                                    <span id="UpdateClassicScoreShowBtn" class="cursor-pointer" title="{{ __('locale.Edit') }}">
                                                        <i data-feather="edit" style="width: 18px; height: 18px; color: #44225c;"></i>
                                                    </span>
                                                @endif
                                            </div>
                                            <div class="rt-card-body">
                                                <div class="row g-2">
                                                    <div class="col-6">
                                                        <div class="rt-tile">
                                                            <div class="rt-label">{{ __('risk.CurrentImpact') }}</div>
                                                            <div class="rt-value">{{ $inh ? '[' . $inh['impact'] . '] ' . $inhImpactName : '[' . $data['impact']['id'] . '] ' . $data['impact']['name'] }}</div>
                                                        </div>
                                                    </div>
                                                    <div class="col-6">
                                                        <div class="rt-tile">
                                                            <div class="rt-label">{{ __('risk.CurrentLikelihood') }}</div>
                                                            <div class="rt-value">{{ $inh ? '[' . $inh['likelihood'] . '] ' . $inhLikelihoodName : '[' . $data['likelihood']['id'] . '] ' . $data['likelihood']['name'] }}</div>
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="rt-tile">
                                                            <div class="rt-label">{{ __('risk.RiskFormula') }}</div>
                                                            <div class="rt-value">{{ $data['currentRiskModel'] ?: '—' }} = {{ $inh['score'] ?? $data['calculated_risk'] }}</div>
                                                        </div>
                                                    </div>
                                                </div>

                                                @if (auth()->user()->hasPermission('riskmanagement.update'))
                                                    <form class="row px-0 mt-2" id="edit-risk-scoring-form" method="post" action="/" style="display: none">
                                                        @csrf
                                                        <input type="hidden" name="id" value="{{ $data['id'] }}">
                                                        <div class="col-12 col-md-6">
                                                            <div class="mb-1 d-flex align-items-end gap-1">
                                                                <div class="flex-grow-1">
                                                                    <label class="form-label">{{ __('risk.CurrentLikelihood') }}</label>
                                                                    <select class="select2 form-select" name="current_likelihood_id">
                                                                        <option value="" disabled hidden selected>{{ __('locale.select-option') }}</option>
                                                                        @foreach ($riskLikelihoods as $riskLikelihood)
                                                                            <option value="{{ $riskLikelihood->id }}" {{ $data['likelihood']['id'] == $riskLikelihood->id ? 'selected' : '' }}>
                                                                                {{ $riskLikelihood->name }}
                                                                            </option>
                                                                        @endforeach
                                                                    </select>
                                                                </div>
                                                                <div id="likelihood-detail-btn" class="cursor-pointer pb-50">
                                                                    <i data-feather='info' class="text-danger"></i>
                                                                </div>
                                                            </div>
                                                            <span class="error error-current_likelihood_id"></span>
                                                            <div class="mb-1 d-flex align-items-end gap-1">
                                                                <div class="flex-grow-1">
                                                                    <label class="form-label">{{ __('risk.CurrentImpact') }}</label>
                                                                    <select class="select2 form-select" name="current_impact_id">
                                                                        <option value="" disabled hidden selected>{{ __('locale.select-option') }}</option>
                                                                        @foreach ($impacts as $impact)
                                                                            <option value="{{ $impact->id }}" {{ $data['impact']['id'] == $impact->id ? 'selected' : '' }}>
                                                                                {{ $impact->name }}
                                                                            </option>
                                                                        @endforeach
                                                                    </select>
                                                                </div>
                                                                <div id="impact-detail-btn" class="cursor-pointer pb-50">
                                                                    <i data-feather='info' class="text-danger"></i>
                                                                </div>
                                                            </div>
                                                            <span class="error error-current_impact_id"></span>
                                                            <div class="d-flex gap-1">
                                                                <button id="update-edit-risk-scoring" type="button" class="btn btn-sm btn-success">{{ __('locale.Update') }}</button>
                                                                <button id="cancel-edit-risk-scoring" class="btn btn-sm btn-outline-danger" type="button">{{ __('locale.Cancel') }}</button>
                                                            </div>
                                                        </div>
                                                        <div class="col-12 col-md-6">
                                                            <div id="impact-detail" style="display: none"></div>
                                                            <div id="likelihood-detail" style="display: none"></div>
                                                        </div>
                                                    </form>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {{-- Risk scoring history --}}
                                <div class="rt-card mt-3">
                                    <div class="rt-card-header p-0 height-50">
                                        <button class="btn w-100 d-flex justify-content-between align-items-center px-1 py-1 collapsed" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false"
                                            aria-controls="collapseOne" id="RiskScoreOverTimeBtn">
                                            <span class="rt-card-title"><i data-feather="trending-up"></i> {{ __('risk.RiskScoringHistory') }}</span>
                                            <i data-feather="chevron-down" class="history-chevron"></i>
                                        </button>
                                    </div>
                                    <div id="collapseOne" class="collapse">
                                        <div class="rt-card-body">
                                            <div class="row g-1 mb-1" id="risk-history-summary">
                                                <div class="col-6 col-md-3">
                                                    <div class="rt-tile text-center">
                                                        <div class="rt-label">{{ __('risk.InherentRisk') }}</div>
                                                        <div class="rt-value fs-4" id="history-current-inherent" style="color: #44225c;">—</div>
                                                    </div>
                                                </div>
                                                <div class="col-6 col-md-3">
                                                    <div class="rt-tile text-center">
                                                        <div class="rt-label">{{ __('risk.ResidualRisk') }}</div>
                                                        <div class="rt-value fs-4" id="history-current-residual" style="color: #00a5a8;">—</div>
                                                    </div>
                                                </div>
                                                <div class="col-6 col-md-3">
                                                    <div class="rt-tile text-center">
                                                        <div class="rt-label">{{ __('risk.ScoreChanges') }}</div>
                                                        <div class="rt-value fs-4" id="history-changes">—</div>
                                                    </div>
                                                </div>
                                                <div class="col-6 col-md-3">
                                                    <div class="rt-tile text-center">
                                                        <div class="rt-label">{{ __('risk.FirstRecorded') }}</div>
                                                        <div class="rt-value" id="history-first">—</div>
                                                        <small class="text-muted" id="history-last"></small>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="border rounded p-50">
                                                <div id="RiskScoreOverTime" style="min-height: 360px;"></div>
                                            </div>
                                            <div id="RiskScoreHistoryLog"></div>
                                            <div id="RiskScoreOverTimeEmpty" class="text-center text-muted py-3 d-none">{{ __('risk.NoScoringHistory') }}</div>
                                        </div>
                                    </div>
                                </div>

                                {{-- Risk details --}}
                                <div class="rt-card mt-1">
                                    <div class="rt-card-header p-0 height-50">
                                        <button class="btn w-100 d-flex justify-content-between align-items-center px-1 py-1 collapsed rt-collapse-btn" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#riskDetailsCollapse" aria-expanded="false"
                                            aria-controls="riskDetailsCollapse">
                                            <span class="rt-card-title"><i data-feather="file-text"></i> {{ __('risk.RiskDetails') }}</span>
                                            <i data-feather="chevron-down" class="history-chevron"></i>
                                        </button>
                                    </div>
                                    <div id="riskDetailsCollapse" class="collapse">
                                    <div class="rt-card-body">
                                        @foreach ($identificationSections as $sectionTitle => $rows)
                                            <div class="rt-section-title">{{ $sectionTitle }}</div>
                                        @foreach ($rows as $row)
                                            <div class="row g-2 mb-2">
                                                @foreach ($row as $field)
                                                    @php [$label, $value, $type] = $field; @endphp
                                                    <div class="col-md-{{ $field[3] ?? intdiv(12, max(count($row), 2)) }}">
                                                        @if ($type === 'html')
                                                            <div class="rt-label">{{ $label }}</div>
                                                            <div class="rt-text-box rt-html">{!! strip_tags((string) $value) !== '' ? $value : '—' !!}</div>
                                                        @elseif ($type === 'textarea')
                                                            <div class="rt-label">{{ $label }}</div>
                                                            <div class="rt-text-box">{{ $value ?: '—' }}</div>
                                                        @else
                                                            <div class="rt-tile h-100">
                                                                <div class="rt-label">{{ $label }}</div>
                                                                @if ($type === 'badges')
                                                                    @forelse ($value as $item)
                                                                        <span class="badge bg-light-primary text-primary border me-25 mb-25">{{ $item }}</span>
                                                                    @empty
                                                                        <span class="rt-empty">—</span>
                                                                    @endforelse
                                                                @else
                                                                    <div class="rt-value">{{ $value ?: '—' }}</div>
                                                                @endif
                                                            </div>
                                                        @endif
                                                    </div>
                                                @endforeach
                                            </div>
                                        @endforeach
                                        @endforeach
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Change Status Modal -->
                        <div class="modal fade" id="changeRiskStatusModal" tabindex="-1"
                            aria-labelledby="changeRiskStatusModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="changeRiskStatusModalLabel">
                                            {{ __('locale.SetRiskStatusTo') }}
                                        </h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="{{ __('locale.Close') }}"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form class="row px-0" id="change-risk-status-form" method="post"
                                            action="{{ route('admin.risk_management.ajax.update') }}">
                                            @csrf
                                            @method('put')
                                            <input type="hidden" name="id" value="{{ $data['id'] }}">
                                            <div class="col-12">
                                                <select class="select2 form-select" name="status">
                                                    <option value="" selected>{{ __('locale.select-option') }}
                                                    </option>
                                                    @foreach ($statuses as $status)
                                                        @if ($status->name == 'Closed')
                                                            @if (auth()->user()->hasPermission('riskmanagement.AbleToCloseRisks'))
                                                                <option value="{{ $status->id }}">
                                                                    {{ __('risk.CloseRisk') }}
                                                                </option>
                                                            @endif
                                                        @else
                                                            <option value="{{ $status->id }}">{{ $status->name }}
                                                            </option>
                                                        @endif
                                                    @endforeach
                                                </select>
                                                <span class="error error-status"></span>
                                            </div>
                                            <div class="col-12 text-center mt-2">
                                                <button id="submit-change-risk-status" type="button"
                                                    class="btn btn-primary me-1">
                                                    {{ __('locale.Update') }}
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="pills-analysis" role="tabpanel"
                            aria-labelledby="pills-analysis-tab">

                            <!-- Content for Step 2 -->
                            <div class="rt-tab">
                                @php
                                    $analysisSections = [
                                        __('risk.SectionControlMapping') => [
                                            [
                                                [__('risk.ControlRegulation'), $data['framework']['name'] ?? null, 'text'],
                                                [__('risk.ControlNumber'), $data['control']['short_name'] ?? null, 'text'],
                                            ],
                                            [
                                                [__('locale.Technology'), collect($data['technologies'] ?? [])->pluck('name')->all(), 'badges', 12],
                                            ],
                                        ],
                                        __('risk.SectionScoring') => [
                                            [
                                                [__('risk.ImpactScope'), $data['source']['name'] ?? null, 'text'],
                                                [__('risk.RiskScoringMethod'), $data['risk_scoring']['name'] ?? null, 'text'],
                                                [__('risk.CurrentLikelihood'), $data['likelihood']['name'] ?? null, 'text'],
                                                [__('risk.CurrentImpact'), $data['impact']['name'] ?? null, 'text'],
                                            ],
                                        ],
                                        __('risk.SectionAnalysis') => [
                                            [
                                                [__('risk.ResponsiblePart'), ($data['responsible_department'] ?? null) ?: ($data['assessment'] ?? null), 'textarea', 12],
                                            ],
                                            [
                                                [__('risk.CurrentControl'), $data['current_control'] ?? null, 'textarea', 12],
                                            ],
                                            [
                                                [__("locale.KRI'S"), $data['notes'] ?? null, 'html'],
                                                [__('locale.Description'), $data['risk_description'] ?? null, 'html'],
                                            ],
                                        ],
                                    ];
                                @endphp
                                <div class="rt-card rt-collapsible" id="static-details">
                                    <div class="rt-card-header">
                                        <h5 class="rt-card-title">{{ __('risk.RiskAnalysis') }}</h5>
                                    </div>
                                    <div class="rt-card-body">
                                        @foreach ($analysisSections as $sectionTitle => $rows)
                                            <div class="rt-section-title">{{ $sectionTitle }}</div>
                                        @foreach ($rows as $row)
                                            <div class="row g-2 mb-2">
                                                @foreach ($row as $field)
                                                    @php [$label, $value, $type] = $field; @endphp
                                                    <div class="col-md-{{ $field[3] ?? intdiv(12, max(count($row), 2)) }}">
                                                        @if ($type === 'html')
                                                            <div class="rt-label">{{ $label }}</div>
                                                            <div class="rt-text-box rt-html">{!! strip_tags((string) $value) !== '' ? $value : '—' !!}</div>
                                                        @elseif ($type === 'textarea')
                                                            <div class="rt-label">{{ $label }}</div>
                                                            <div class="rt-text-box">{{ $value ?: '—' }}</div>
                                                        @else
                                                            <div class="rt-tile h-100">
                                                                <div class="rt-label">{{ $label }}</div>
                                                                @if ($type === 'badges')
                                                                    @forelse ($value as $item)
                                                                        <span class="badge bg-light-primary text-primary border me-25 mb-25">{{ $item }}</span>
                                                                    @empty
                                                                        <span class="rt-empty">—</span>
                                                                    @endforelse
                                                                @else
                                                                    <div class="rt-value">{{ $value ?: '—' }}</div>
                                                                @endif
                                                            </div>
                                                        @endif
                                                    </div>
                                                @endforeach
                                            </div>
                                        @endforeach
                                        @endforeach
                                        <div class="rt-section-title">{{ __('risk.SupportingDocumentation') }}</div>
                                        <div class="rt-tile supporting_documentation_container">
                                            @forelse ($data['files'] ?? [] as $file)
                                                <span class="badge bg-secondary supporting_documentation cursor-pointer me-25 mb-25"
                                                    data-id="{{ $file['id'] }}" data-risk-id="{{ $data['id'] }}">{{ $file['name'] }}</span>
                                            @empty
                                                <span class="rt-empty">{{ __('locale.NONE') }}</span>
                                            @endforelse
                                        </div>
                                        <input type="hidden" name="risk_description_hidden" id="risk_description_hidden">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="pills-evalution" role="tabpanel"
                            aria-labelledby="pills-evalution-tab">

                            <!-- Content for Step 3 -->

                            @php
                                $inh = $data['ksu_inherent'] ?? null;
                                $res = $data['ksu_residual'] ?? null;
                                $plans = $data['action_plans'] ?? collect();
                                $totalLikelihoodReduction = min(100, (float) $plans->sum('likelihood_reduction'));
                                $totalImpactReduction = min(100, (float) $plans->sum('impact_reduction'));
                                $riskReduction = ($inh && $res) ? round($inh['score'] - $res['score'], 1) : null;
                                $riskReductionPercent = ($inh && $res && $inh['score'] > 0) ? round(($inh['score'] - $res['score']) / $inh['score'] * 100) : null;
                                $hasMitigation = !empty($data['has_mitigation_plan']);
                                $mitigation = $data['mitigation'];
                            @endphp

                            <div class="tab-pane rt-tab" id="mitigation" aria-labelledby="mitigation-tab" role="tabpanel">

                                {{-- 1. Summary: inherent → residual --}}
                                <div class="rt-card">
                                    <div class="rt-card-body">
                                        <div class="row g-2 align-items-stretch">
                                            <div class="col-md-3">
                                                <div class="rt-score" style="background: {{ ($inh['color'] ?? '#999') }}1f;">
                                                    <div class="rt-label">{{ __('risk.InherentRisk') }}</div>
                                                    <div class="rt-score-value" style="color: {{ $inh['color'] ?? '#555' }};">{{ $inh['score'] ?? '—' }}</div>
                                                    <div class="fw-bold" style="color: {{ $inh['color'] ?? '#555' }};">{{ $inh['display_name'] ?? '' }}</div>
                                                    @if ($inh)
                                                        <small class="text-muted">L{{ $inh['likelihood'] }} × I{{ $inh['impact'] }}</small>
                                                    @endif
                                                </div>
                                            </div>
                                            <div class="col-md-1 d-flex align-items-center justify-content-center">
                                                <span class="rt-arrow">&#10140;</span>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="rt-score" style="background: {{ ($res['color'] ?? '#999') }}1f;">
                                                    <div class="rt-label">{{ __('risk.ResidualRisk') }}</div>
                                                    <div class="rt-score-value" style="color: {{ $res['color'] ?? '#555' }};">{{ $res['score'] ?? '—' }}</div>
                                                    <div class="fw-bold" style="color: {{ $res['color'] ?? '#555' }};">{{ $res['display_name'] ?? '' }}</div>
                                                    @if ($res)
                                                        <small class="text-muted">L{{ $res['likelihood'] }} × I{{ $res['impact'] }}</small>
                                                    @endif
                                                </div>
                                            </div>
                                            <div class="col-md-5">
                                                <div class="rt-tile">
                                                    <div class="row g-2">
                                                        <div class="col-6">
                                                            <div class="rt-label">{{ __('risk.RiskReduction') }}</div>
                                                            <div class="rt-value fs-4">
                                                                {{ $riskReduction ?? '—' }}
                                                                @if ($riskReductionPercent !== null)
                                                                    <small class="text-success">({{ $riskReductionPercent }}%)</small>
                                                                @endif
                                                            </div>
                                                        </div>
                                                        <div class="col-6">
                                                            <div class="rt-label">{{ __('risk.TreatmentOption') }}</div>
                                                            <div class="rt-value">
                                                                @if (!empty($data['treatment_action']))
                                                                    <span class="badge bg-primary">{{ __('risk.Treat' . ucfirst($data['treatment_action'])) }}</span>
                                                                @else
                                                                    <span class="rt-empty">{{ __('risk.Untreated') }}</span>
                                                                @endif
                                                            </div>
                                                        </div>
                                                        <div class="col-6">
                                                            <div class="rt-label">{{ __('risk.LikelihoodReduction') }}</div>
                                                            <div class="rt-value">{{ $totalLikelihoodReduction }}%</div>
                                                            <div class="rt-bar mt-1"><span class="bg-info" style="width: {{ $totalLikelihoodReduction }}%"></span></div>
                                                        </div>
                                                        <div class="col-6">
                                                            <div class="rt-label">{{ __('risk.ImpactReduction') }}</div>
                                                            <div class="rt-value">{{ $totalImpactReduction }}%</div>
                                                            <div class="rt-bar mt-1"><span class="bg-primary" style="width: {{ $totalImpactReduction }}%"></span></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {{-- 2. Mitigation plan --}}
                                <div class="rt-card rt-collapsible" id="static-mitigation">
                                    <div class="rt-card-header">
                                        <h5 class="rt-card-title">{{ __('risk.MitigationPlan') }}</h5>
                                        <div class="d-flex gap-1">
                                            @if (auth()->user()->hasPermission('plan_mitigation.create'))
                                                <button id="edit-mitigation" type="button" class="btn btn-sm btn-outline-primary"
                                                    data-bs-toggle="modal" data-bs-target="#editMitigationModal">
                                                    {{ __('locale.EditMitigation') }}
                                                </button>
                                            @endif
                                            @if ($mitigation['mitigation_id'])
                                                @if ($mitigation['user_accepted_mitigations'])
                                                    <button id="accept-mitigation" type="button"
                                                        class="btn btn-sm btn-danger acceptOrRejectStatus" data-value='0'
                                                        data-id="{{ $data['id'] }}">{{ __('risk.RejectMitigation') }}</button>
                                                @else
                                                    <button id="reject-mitigation" type="button"
                                                        class="btn btn-sm btn-green acceptOrRejectStatus" data-value='1'
                                                        data-id="{{ $data['id'] }}">{{ __('risk.AcceptMitigation') }}</button>
                                                @endif
                                            @endif
                                        </div>
                                    </div>
                                    <div class="rt-card-body">
                                        @php
                                            $tiles = [
                                                __('risk.MitigationDate') => format_date($mitigation['mitigation_date'], __('locale.N/A')),
                                                __('risk.MitigationPlanning') => $mitigation['planning_date'] ?? '',
                                                __('risk.TreatmentDueDate') => $mitigation['treatment_due_date'] ?? '',
                                                __('risk.PlanningStrategy') => $mitigation['planning_strategy'] ?? '',
                                                __('risk.MitigationEffort') => $mitigation['mitigation_effort'] ?? '',
                                                __('risk.MitigationCost') => $mitigation['mitigation_cost'] ?? '',
                                                __('risk.MitigationOwner') => $mitigation['mitigation_owner'] ?? '',
                                                __('risk.MitigationPercent') => ((isset($mitigation['mitigation_percent']) && $mitigation['mitigation_percent'] >= 0 && $mitigation['mitigation_percent'] <= 100) ? $mitigation['mitigation_percent'] : 0) . ' %',
                                            ];
                                            $badgeGroups = [
                                                __('risk.MitigationTeam') => collect($mitigation['mitigation_team'] ?? [])->pluck('name')->all(),
                                                __('locale.MitigationControls') => $mitigation['mitigation_control_names'] ?? [],
                                                __('risk.MitigationNature') => collect($mitigation['mitigation_nature'] ?? [])->map(fn ($v) => __('risk.Nature' . ucfirst($v)))->all(),
                                                __('risk.MitigationFunction') => collect($mitigation['mitigation_function'] ?? [])->map(fn ($v) => __('risk.Func' . ucfirst($v)))->all(),
                                                __('risk.ExpectedResult') => collect($mitigation['expected_result'] ?? [])->map(fn ($v) => __('risk.' . \Illuminate\Support\Str::studly($v)))->all(),
                                            ];
                                        @endphp

                                        <div class="row g-2 mb-2">
                                            @foreach ($tiles as $label => $value)
                                                <div class="col-6 col-md-3">
                                                    <div class="rt-tile">
                                                        <div class="rt-label">{{ $label }}</div>
                                                        <div class="rt-value">{{ $value !== '' && $value !== null ? $value : '—' }}</div>
                                                    </div>
                                                </div>
                                            @endforeach
                                        </div>

                                        <div class="row g-2 mb-2">
                                            @foreach ($badgeGroups as $label => $items)
                                                <div class="col-md {{ $loop->first || $loop->iteration === 2 ? 'col-md-6' : 'col-md-4' }}">
                                                    <div class="rt-tile">
                                                        <div class="rt-label">{{ $label }}</div>
                                                        @forelse ($items as $item)
                                                            <span class="badge bg-light-primary text-primary border me-25 mb-25">{{ $item }}</span>
                                                        @empty
                                                            <span class="rt-empty">—</span>
                                                        @endforelse
                                                    </div>
                                                </div>
                                            @endforeach
                                        </div>

                                        <div class="row g-2">
                                            <div class="col-md-4">
                                                <div class="rt-label">{{ __('risk.SecurityRequirements') }}</div>
                                                <div class="rt-text-box">{{ $mitigation['security_requirements'] ?: '—' }}</div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="rt-label">{{ __('risk.SecurityRecommendations') }}</div>
                                                <div class="rt-text-box">{{ $mitigation['security_recommendations'] ?: '—' }}</div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="rt-label">{{ __('risk.CurrentSolution') }}</div>
                                                <div class="rt-text-box rt-html">{!! strip_tags((string) $mitigation['current_solution']) !== '' ? $mitigation['current_solution'] : '—' !!}</div>
                                            </div>
                                        </div>

                                        @if (auth()->user()->hasPermission('plan_mitigation.accept') && count($mitigation['accepted_mitigations'] ?? []))
                                            <div class="mt-2 pt-2 border-top small text-muted">
                                                @foreach ($mitigation['accepted_mitigations'] as $accepted_mitigation)
                                                    <div>&#10003; {{ __('risk.MitigationAcceptedByUserOnTime', ['name' => $accepted_mitigation['name'], 'date' => $accepted_mitigation['date'], 'time' => $accepted_mitigation['time']]) }}</div>
                                                @endforeach
                                            </div>
                                        @endif
                                    </div>
                                </div>

                                {{-- 3. Action plans --}}
                                <div class="rt-card rt-collapsible">
                                    <div class="rt-card-header">
                                        <h5 class="rt-card-title">{{ __('risk.ActionPlans') }}</h5>
                                        <span class="badge bg-light-secondary text-secondary">{{ $plans->count() }}</span>
                                    </div>
                                    <div class="rt-card-body p-0">
                                        @if ($plans->count())
                                            <div class="table-responsive">
                                                <table class="table table-hover mb-0 align-middle">
                                                    <thead class="table-light">
                                                        <tr>
                                                            <th>#</th>
                                                            <th>{{ __('risk.ActionTitle') }}</th>
                                                            <th style="width: 22%">{{ __('risk.LikelihoodReduction') }}</th>
                                                            <th style="width: 22%">{{ __('risk.ImpactReduction') }}</th>
                                                            <th>{{ __('risk.TreatmentDueDate') }}</th>
                                                            <th>{{ __('locale.Status') }}</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @foreach ($plans as $plan)
                                                            <tr>
                                                                <td class="text-muted">{{ $loop->iteration }}</td>
                                                                <td class="fw-bold">{{ $plan->title ?: '—' }}</td>
                                                                <td>
                                                                    <div class="d-flex align-items-center gap-1">
                                                                        <div class="rt-bar flex-grow-1"><span class="bg-info" style="width: {{ min(100, $plan->likelihood_reduction) }}%"></span></div>
                                                                        <small>{{ $plan->likelihood_reduction }}%</small>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="d-flex align-items-center gap-1">
                                                                        <div class="rt-bar flex-grow-1"><span class="bg-primary" style="width: {{ min(100, $plan->impact_reduction) }}%"></span></div>
                                                                        <small>{{ $plan->impact_reduction }}%</small>
                                                                    </div>
                                                                </td>
                                                                <td>{{ $plan->due_date ? \Carbon\Carbon::parse($plan->due_date)->format('Y-m-d') : '—' }}</td>
                                                                <td><span class="badge bg-light-secondary text-secondary">{{ ($plan->status ?? 'planned') === 'planned' ? __('risk.PlanStatusPlanned') : ucfirst($plan->status) }}</span></td>
                                                            </tr>
                                                        @endforeach
                                                    </tbody>
                                                    <tfoot class="table-light">
                                                        <tr class="fw-bold">
                                                            <td></td>
                                                            <td>{{ __('risk.Total') }}</td>
                                                            <td>{{ $totalLikelihoodReduction }}%</td>
                                                            <td>{{ $totalImpactReduction }}%</td>
                                                            <td colspan="2"></td>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            </div>
                                        @else
                                            <div class="p-2 rt-empty">{{ __('locale.NONE') }}</div>
                                        @endif
                                    </div>
                                </div>

                                {{-- 4. Treatment decisions --}}
                                <div class="rt-card rt-collapsible" id="ksu-treatment-panel">
                                    <div class="rt-card-header">
                                        <h5 class="rt-card-title">{{ __('risk.TreatmentDecisions') }}</h5>
                                        <div class="d-flex flex-wrap gap-1">
                                            @if (auth()->user()->hasPermission('riskmanagement.avoid_risk'))
                                                <button type="button" class="btn btn-sm btn-outline-secondary open-treatment-modal"
                                                    data-type="avoid" {{ !$hasMitigation ? 'disabled' : '' }}>{{ __('risk.AvoidRisk') }}</button>
                                            @endif
                                            @if (auth()->user()->hasPermission('riskmanagement.transfer_risk'))
                                                <button type="button" class="btn btn-sm btn-outline-info open-treatment-modal"
                                                    data-type="transfer" {{ !$hasMitigation ? 'disabled' : '' }}>{{ __('risk.TransferRisk') }}</button>
                                            @endif
                                            @if (auth()->user()->hasPermission('riskmanagement.accept_risk'))
                                                <button type="button" class="btn btn-sm btn-outline-warning open-treatment-modal"
                                                    data-type="accept" {{ !$hasMitigation ? 'disabled' : '' }}>{{ __('risk.AcceptRisk') }}</button>
                                            @endif
                                            @if (auth()->user()->hasPermission('riskmanagement.redo_assessment'))
                                                <button type="button" class="btn btn-sm btn-primary"
                                                    data-bs-toggle="modal" data-bs-target="#redoAssessmentModal"
                                                    {{ !$hasMitigation ? 'disabled' : '' }}>{{ __('risk.RedoAssessment') }}</button>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="rt-card-body pt-0">
                                        @unless ($hasMitigation)
                                            <div class="alert alert-warning mt-1 mb-0 p-1">{{ __('risk.NeedMitigationBeforeOtherTreatments') }}</div>
                                        @endunless

                                        @if (empty($data['treatment_requests']) || !count($data['treatment_requests']))
                                            @if (empty($data['latest_redo']))
                                                <div class="pt-2 rt-empty">{{ __('risk.NoTreatmentRequests') }}</div>
                                            @endif
                                        @endif

                                        @foreach ($data['treatment_requests'] ?? [] as $tr)
                                            @php
                                                [$stateClass, $statusClass] = match ($tr->status) {
                                                    'approved' => ['is-approved', 'bg-success'],
                                                    'rejected' => ['is-rejected', 'bg-danger'],
                                                    default => ['is-pending', 'bg-warning text-dark'],
                                                };
                                                $currentStep = collect($tr->approval_steps)->firstWhere('state', 'current');
                                                $details = [
                                                    __('risk.DecisionOwner') => optional($tr->decisionOwner)->name,
                                                    __('risk.DecisionDate') => optional($tr->decision_date)->format('Y-m-d'),
                                                    __('risk.ReevaluateDate') => optional($tr->reevaluate_date)->format('Y-m-d'),
                                                    __('risk.StartedBy') => optional($tr->startedBy)->name,
                                                ];
                                                if ($tr->treatment_type === 'transfer') {
                                                    $details[__('risk.TransferPartyType')] = $tr->transfer_party_type ? __('risk.' . ucfirst($tr->transfer_party_type)) : null;
                                                    $details[__('risk.TransferredActionPlans')] = $tr->transferred_plan_titles->implode('، ');
                                                }
                                            @endphp
                                            <div class="rt-request {{ $stateClass }}">
                                                <div class="d-flex flex-wrap justify-content-between align-items-center gap-1">
                                                    <div class="d-flex align-items-center gap-1">
                                                        <h6 class="mb-0 fw-bolder">{{ __('risk.Treat' . ucfirst($tr->treatment_type)) }}</h6>
                                                        <span class="badge {{ $statusClass }}">{{ __('risk.TreatmentStatus_' . $tr->status) }}</span>
                                                    </div>
                                                    <small class="text-muted">#{{ $tr->id }} · {{ optional($tr->created_at)->format('Y-m-d H:i') }}</small>
                                                </div>

                                                {{-- Approval cycle --}}
                                                <div class="approval-cycle my-1">
                                                    @foreach ($tr->approval_steps as $step)
                                                        @php
                                                            [$dotClass, $icon] = match ($step['state']) {
                                                                'done' => ['bg-success text-white', '✓'],
                                                                'current' => ['bg-warning text-dark', '…'],
                                                                'rejected' => ['bg-danger text-white', '✕'],
                                                                'skipped' => ['bg-light text-muted border', '–'],
                                                                default => ['bg-light text-muted border', $loop->iteration],
                                                            };
                                                            $people = $step['by'] ? [$step['by']] : ($step['assignees'] ?? null);
                                                        @endphp
                                                        <div class="approval-step {{ $step['state'] === 'current' ? 'fw-bold' : '' }}">
                                                            <div class="approval-dot {{ $dotClass }}">{{ $icon }}</div>
                                                            <div class="small mt-50">
                                                                {{ __('risk.ApprovalStep_' . $step['key']) }}
                                                                @if (is_array($people))
                                                                    @if (count($people))
                                                                        <div class="text-primary">({{ implode('، ', $people) }})</div>
                                                                    @else
                                                                        <div class="text-danger">({{ __('risk.NotAssigned') }})</div>
                                                                    @endif
                                                                @endif
                                                            </div>
                                                            <div class="text-muted" style="font-size: 11px;">
                                                                @if (!empty($step['auto']))
                                                                    {{ __('risk.AutoApproved') }}
                                                                @elseif ($step['state'] === 'current')
                                                                    <span class="text-warning">{{ __('risk.WaitingHere') }}</span>
                                                                @elseif ($step['state'] === 'upcoming')
                                                                    {{ __('risk.UpcomingStep') }}
                                                                @endif
                                                                @if ($step['at'])
                                                                    <div>{{ \Carbon\Carbon::parse($step['at'])->format('Y-m-d H:i') }}</div>
                                                                @endif
                                                            </div>
                                                        </div>
                                                        @unless ($loop->last)
                                                            <div class="approval-line {{ $step['state'] === 'done' ? 'bg-success' : 'bg-secondary opacity-25' }}"></div>
                                                        @endunless
                                                    @endforeach
                                                </div>

                                                {{-- Entered data --}}
                                                <div class="row g-2">
                                                    <div class="col-md-6">
                                                        <div class="rt-label">{{ __('risk.ReasonDescription') }}</div>
                                                        <div class="rt-text-box" style="min-height: 60px;">{{ $tr->reason_description ?: '—' }}</div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        @if ($tr->treatment_type === 'transfer')
                                                            <div class="rt-label">{{ __('risk.TransferPartyDescription') }}</div>
                                                            <div class="rt-text-box" style="min-height: 60px;">{{ $tr->transfer_party_description ?: '—' }}</div>
                                                        @else
                                                            <div class="rt-label">{{ $tr->treatment_type === 'accept' ? __('risk.OwnerApprovalStatement') : __('risk.AvoidanceStrategy') }}</div>
                                                            <div class="rt-text-box" style="min-height: 60px;">{{ $tr->strategy_description ?: '—' }}</div>
                                                        @endif
                                                    </div>
                                                    @foreach ($details as $label => $value)
                                                        <div class="col-6 col-md-3">
                                                            <div class="rt-label">{{ $label }}</div>
                                                            <div class="rt-value small">{{ $value ?: '—' }}</div>
                                                        </div>
                                                    @endforeach
                                                    @if ($tr->review_comments)
                                                        <div class="col-12">
                                                            <div class="rt-label">{{ __('risk.ReviewComments') }}</div>
                                                            <div class="rt-value small">{{ $tr->review_comments }}</div>
                                                        </div>
                                                    @endif
                                                </div>

                                                @if ($currentStep && auth()->user()->hasPermission('riskmanagement.review_treatment'))
                                                    <div class="mt-2 pt-1 border-top d-flex flex-wrap gap-1 align-items-center justify-content-end">
                                                        <small class="text-muted me-auto">
                                                            {{ __('risk.ApprovalStep_' . $currentStep['key']) }}
                                                            @if (!empty($currentStep['assignees']))
                                                                ({{ implode('، ', $currentStep['assignees']) }})
                                                            @endif
                                                        </small>
                                                        @if ($tr->can_act)
                                                            <button type="button" class="btn btn-sm btn-success act-treatment-btn"
                                                                data-id="{{ $tr->id }}" data-decision="approved">{{ __('locale.Approve') }}</button>
                                                            <button type="button" class="btn btn-sm btn-outline-danger act-treatment-btn"
                                                                data-id="{{ $tr->id }}" data-decision="rejected">{{ __('locale.Reject') }}</button>
                                                        @else
                                                            <span class="badge bg-light-warning text-warning">{{ __('risk.WaitingForAssignedApprover') }}</span>
                                                        @endif
                                                    </div>
                                                @endif
                                            </div>
                                        @endforeach

                                        @if (!empty($data['latest_redo']))
                                            @php
                                                $redo = $data['latest_redo'];
                                                $redoClass = match ($redo->status) {
                                                    'completed' => 'is-approved',
                                                    'rejected' => 'is-rejected',
                                                    default => 'is-pending',
                                                };
                                            @endphp
                                            <div class="rt-request {{ $redoClass }}">
                                                <div class="d-flex flex-wrap justify-content-between align-items-center gap-1 mb-1">
                                                    <div class="d-flex align-items-center gap-1">
                                                        <h6 class="mb-0 fw-bolder">{{ __('risk.RedoAssessment') }}</h6>
                                                        <span class="badge {{ $redoClass === 'is-approved' ? 'bg-success' : ($redoClass === 'is-rejected' ? 'bg-danger' : 'bg-warning text-dark') }}">
                                                            {{ __('risk.RedoStatus_' . $redo->status) }}
                                                        </span>
                                                    </div>
                                                    <small class="text-muted">#{{ $redo->id }} · {{ optional($redo->created_at)->format('Y-m-d H:i') }}</small>
                                                </div>
                                                @if ($redo->notes)
                                                    <div class="small mb-1">{{ $redo->notes }}</div>
                                                @endif
                                                <div class="table-responsive">
                                                    <table class="table table-sm mb-0">
                                                        <thead class="table-light">
                                                            <tr>
                                                                <th>{{ __('risk.ActionTitle') }}</th>
                                                                <th>{{ __('locale.Comment') }}</th>
                                                                <th>{{ __('risk.Evidence') }}</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            @foreach ($redo->evidences as $ev)
                                                                <tr>
                                                                    <td>{{ optional($ev->actionPlan)->title ?? '—' }}</td>
                                                                    <td>{{ $ev->comment ?: '—' }}</td>
                                                                    <td>
                                                                        @if ($ev->file_path)
                                                                            <a href="{{ asset('storage/' . $ev->file_path) }}" target="_blank">{{ $ev->file_name }}</a>
                                                                        @else
                                                                            —
                                                                        @endif
                                                                    </td>
                                                                </tr>
                                                            @endforeach
                                                        </tbody>
                                                    </table>
                                                </div>
                                                @if (auth()->user()->hasPermission('riskmanagement.review_treatment')
                                                    && $data['can_review_redo']
                                                    && in_array($redo->status, ['pending_risk_team', 'in_progress'], true))
                                                    <div class="mt-2 pt-1 border-top d-flex gap-1 justify-content-end">
                                                        <button type="button" class="btn btn-sm btn-success act-redo-btn"
                                                            data-id="{{ $redo->id }}" data-decision="approved">{{ __('locale.Approve') }}</button>
                                                        <button type="button" class="btn btn-sm btn-outline-danger act-redo-btn"
                                                            data-id="{{ $redo->id }}" data-decision="rejected">{{ __('locale.Reject') }}</button>
                                                    </div>
                                                @endif
                                            </div>
                                        @endif
                                    </div>
                                </div>
                            </div>


                        </div>

                        {{-- Treatment request modal --}}
                        <div class="modal fade" id="treatmentRequestModal" tabindex="-1">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <form id="treatment-request-form">
                                        @csrf
                                        <input type="hidden" name="risk_id" value="{{ $data['id'] }}">
                                        <input type="hidden" name="treatment_type" id="treatment_type_input">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="treatment_modal_title">{{ __('risk.TreatmentOption') }}</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body row g-2">
                                            @php
                                                $ac = $data['accept_context'];
                                                $acScenario = $ac['scenario'];
                                                $acAppetite = $ac['appetite'];
                                                $acExceeds = in_array($acScenario, ['exceeds_escalated', 'exceeds_already_steering', 'exceeds_not_enforced'], true);
                                                $acColor = $acScenario === 'no_appetite' ? '#82868b' : ($acExceeds ? '#ea5455' : '#28c76f');
                                                $acLevelLabel = __('risk.Level' . str_replace(' ', '', $ac['level']));
                                                $acParams = ['score' => $ac['score'], 'limit' => $acAppetite['limit'] ?? '—', 'level' => $acLevelLabel];
                                                $acDiff = $acAppetite ? round(abs($ac['score'] - $acAppetite['limit']), 1) : null;
                                                $acBaseSteps = $ac['base_path']['steps'];
                                                $acSteps = $ac['path']['auto_accept'] ? [] : $ac['path']['steps'];
                                            @endphp
                                            <div class="col-12 treatment-extra appetite-extra d-none">
                                                <div class="rt-card mb-0" style="border-inline-start: 4px solid {{ $acColor }};">
                                                    <div class="rt-card-header">
                                                        <h5 class="rt-card-title"><i data-feather="target"></i> {{ __('risk.AppetiteCheck') }}</h5>
                                                        <span class="badge" style="background: {{ $acColor }};">
                                                            {{ $acScenario === 'no_appetite' ? __('risk.AppetiteNotConfigured') : ($acExceeds ? __('risk.ExceedsAppetite') : __('risk.WithinAppetite')) }}
                                                        </span>
                                                    </div>
                                                    <div class="rt-card-body">
                                                        <div class="row g-1 mb-1">
                                                            <div class="col-4">
                                                                <div class="rt-tile text-center">
                                                                    <div class="rt-label">{{ __('risk.ResidualRisk') }}</div>
                                                                    <div class="rt-value fs-4">{{ $ac['score'] }}</div>
                                                                    <small class="text-muted">L{{ $ac['likelihood'] }} × I{{ $ac['impact'] }} · {{ $acLevelLabel }}</small>
                                                                </div>
                                                            </div>
                                                            <div class="col-4">
                                                                <div class="rt-tile text-center">
                                                                    <div class="rt-label">{{ __('risk.AppetiteMaxScore') }}</div>
                                                                    <div class="rt-value fs-4">{{ $acAppetite['limit'] ?? '—' }}</div>
                                                                    <small class="text-muted">{{ $acAppetite['name'] ?? __('risk.AppetiteNotConfigured') }}</small>
                                                                </div>
                                                            </div>
                                                            <div class="col-4">
                                                                <div class="rt-tile text-center">
                                                                    <div class="rt-label">{{ __('risk.AppetiteDifference') }}</div>
                                                                    <div class="rt-value fs-4" style="color: {{ $acColor }};">
                                                                        {{ $acDiff === null ? '—' : ($acExceeds ? '+' : '−') . $acDiff }}
                                                                    </div>
                                                                    <small class="text-muted">
                                                                        {{ $acDiff === null ? '' : ($acExceeds ? __('risk.AboveTheLimit') : __('risk.BelowTheLimit')) }}
                                                                    </small>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="rt-label">{{ __('risk.WhatThisMeans') }}</div>
                                                        <p class="mb-1">{{ __('risk.AppetiteScenario_' . $acScenario, $acParams) }}</p>

                                                        <div class="rt-label">{{ __('risk.ApprovalPathAfterSave') }}</div>
                                                        <div class="d-flex flex-wrap align-items-center gap-50 mb-50">
                                                            <span class="badge bg-light-secondary">{{ __('risk.ApprovalStep_submitted') }}</span>
                                                            @foreach ($acSteps as $step)
                                                                <i data-feather="chevron-right" class="text-muted"></i>
                                                                <span class="badge {{ in_array($step, $acBaseSteps, true) ? 'bg-light-primary' : 'bg-danger' }}">
                                                                    {{ __('risk.ApprovalStep_' . $step) }}
                                                                    @unless (in_array($step, $acBaseSteps, true))
                                                                        · {{ __('risk.AddedByAppetite') }}
                                                                    @endunless
                                                                </span>
                                                            @endforeach
                                                            <i data-feather="chevron-right" class="text-muted"></i>
                                                            <span class="badge bg-light-success">{{ $ac['path']['auto_accept'] ? __('risk.AutoAccepted') : __('risk.ApprovalStep_approved') }}</span>
                                                        </div>
                                                        @if ($acScenario === 'exceeds_escalated')
                                                            <small class="text-muted d-block mb-1">
                                                                {{ __('risk.PathByLevelOnly') }}:
                                                                {{ $ac['base_path']['auto_accept'] ? __('risk.AutoAccepted') : collect($acBaseSteps)->map(fn ($step) => __('risk.ApprovalStep_' . $step))->implode(' → ') }}
                                                            </small>
                                                        @endif

                                                        <div class="rt-label">{{ __('risk.WhatToDo') }}</div>
                                                        <p class="mb-0">{{ $acExceeds ? __('risk.AppetiteGuidance_exceeds') : __('risk.AppetiteGuidance_within') }}</p>
                                                        @if ($acScenario === 'no_appetite' && auth()->user()->hasPermission('riskmanagement.configuration'))
                                                            <small class="d-block mt-50">
                                                                <a href="{{ route('admin.risk_management.ksu_settings') }}" target="_blank">{{ __('risk.ConfigureAppetiteHint') }}</a>
                                                            </small>
                                                        @endif

                                                        @if ($ac['statement'])
                                                            <details class="mt-1">
                                                                <summary class="fw-bold cursor-pointer">{{ __('risk.RiskAppetiteStatement') }}</summary>
                                                                <div class="small text-muted mt-50" style="white-space: pre-line;">{{ $ac['statement'] }}</div>
                                                            </details>
                                                        @endif
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <label>{{ __('risk.ReasonDescription') }}</label>
                                                <textarea class="form-control" name="reason_description" required rows="3"></textarea>
                                            </div>
                                            <div class="col-md-6">
                                                <label>{{ __('risk.DecisionOwner') }}</label>
                                                <select class="form-select" name="decision_owner_id">
                                                    @foreach ($owners as $owner)
                                                        <option value="{{ $owner->id }}" {{ ($owner->id == ($data['owner']['id'] ?? null)) ? 'selected' : '' }}>{{ $owner->name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="col-md-6">
                                                <label>{{ __('risk.DecisionDate') }}</label>
                                                <input type="date" class="form-control" name="decision_date"
                                                    id="treatment_decision_date" value="{{ date('Y-m-d') }}">
                                            </div>
                                            <div class="col-md-6">
                                                <label>{{ __('risk.ReevaluateDate') }}</label>
                                                <input type="date" class="form-control" name="reevaluate_date"
                                                    id="treatment_reevaluate_date"
                                                    value="{{ date('Y-m-d', strtotime('+1 year')) }}">
                                            </div>
                                            <div class="col-12 treatment-extra accept-extra avoid-extra">
                                                <label>{{ __('risk.AvoidanceStrategy') }} / {{ __('risk.OwnerApprovalStatement') }}</label>
                                                <textarea class="form-control" name="strategy_description" rows="2"></textarea>
                                            </div>
                                            <div class="col-md-6 treatment-extra transfer-extra d-none">
                                                <label>{{ __('risk.TransferPartyType') }}</label>
                                                <select class="form-select" name="transfer_party_type">
                                                    <option value="internal">{{ __('risk.Internal') }}</option>
                                                    <option value="external">{{ __('risk.External') }}</option>
                                                </select>
                                            </div>
                                            <div class="col-md-6 treatment-extra transfer-extra d-none">
                                                <label>{{ __('risk.TransferPartyDescription') }}</label>
                                                <textarea class="form-control" name="transfer_party_description" rows="2"></textarea>
                                            </div>
                                            @if (($data['action_plans'] ?? collect())->count())
                                                <div class="col-12 treatment-extra transfer-extra d-none">
                                                    <label>{{ __('risk.ActionPlans') }}</label>
                                                    @foreach ($data['action_plans'] as $plan)
                                                        <div class="form-check">
                                                            <input class="form-check-input" type="checkbox"
                                                                name="transferred_action_plan_ids[]"
                                                                value="{{ $plan->id }}" id="tap{{ $plan->id }}">
                                                            <label class="form-check-label" for="tap{{ $plan->id }}">{{ $plan->title }}</label>
                                                        </div>
                                                    @endforeach
                                                </div>
                                            @endif
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">{{ __('locale.Cancel') }}</button>
                                            <button type="submit" class="btn btn-primary">{{ __('locale.Save') }}</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        {{-- Redo Assessment modal --}}
                        <div class="modal fade" id="redoAssessmentModal" tabindex="-1">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <form id="redo-assessment-form" enctype="multipart/form-data">
                                        @csrf
                                        <input type="hidden" name="risk_id" value="{{ $data['id'] }}">
                                        <div class="modal-header">
                                            <h5 class="modal-title">{{ __('risk.RedoAssessment') }}</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="mb-2">
                                                <label>{{ __('locale.Comment') }}</label>
                                                <textarea class="form-control" name="notes" rows="2"></textarea>
                                            </div>
                                            <p class="small text-muted">{{ __('risk.RedoEvidenceHint') }}</p>
                                            @forelse (($data['action_plans'] ?? collect()) as $idx => $plan)
                                                <div class="border rounded p-2 mb-2">
                                                    <strong>{{ $plan->title }}</strong>
                                                    <input type="hidden" name="evidences[{{ $idx }}][action_plan_id]" value="{{ $plan->id }}">
                                                    <textarea class="form-control mt-1" name="evidences[{{ $idx }}][comment]"
                                                        rows="2" placeholder="{{ __('risk.EvidenceComment') }}"></textarea>
                                                    <input type="file" class="form-control mt-1"
                                                        name="evidences[{{ $idx }}][file]">
                                                </div>
                                            @empty
                                                <div class="border rounded p-2 mb-2">
                                                    <input type="hidden" name="evidences[0][action_plan_id]" value="">
                                                    <textarea class="form-control" name="evidences[0][comment]" rows="2" required></textarea>
                                                    <input type="file" class="form-control mt-1" name="evidences[0][file]">
                                                </div>
                                            @endforelse
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">{{ __('locale.Cancel') }}</button>
                                            <button type="submit" class="btn btn-primary">{{ __('locale.Submit') }}</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="pills-review" role="tabpanel"
                            aria-labelledby="pills-review-tab">
                            <div class="rt-tab" id="static-review">
                                @php
                                    $riskReviewHistory = array_values($data['mgmtReviews'] ?? []);
                                    $latestReview = count($riskReviewHistory) ? end($riskReviewHistory) : null;
                                @endphp

                                {{-- Last review --}}
                                <div class="rt-card rt-collapsible">
                                    <div class="rt-card-header">
                                        <h5 class="rt-card-title">{{ __('locale.LastReview') }}</h5>
                                        <span class="badge bg-light-secondary text-secondary">{{ count($riskReviewHistory) }}</span>
                                    </div>
                                    <div class="rt-card-body">
                                        @if ($latestReview)
                                            <div class="row g-2">
                                                @foreach ([
                                                    __('locale.ReviewDate') => $latestReview['review_date'] ?? null,
                                                    __('locale.Reviewer') => $latestReview['reviewer'] ?? null,
                                                    __('locale.Review') => $latestReview['review'] ?? null,
                                                    __('locale.NextStep') => $latestReview['next_step'] ?? null,
                                                    __('locale.NextReviewDate') => $latestReview['next_review'] ?? null,
                                                    __('locale.Project') => $latestReview['project'] ?? null,
                                                ] as $label => $value)
                                                    <div class="col-6 col-md-4 col-lg-2">
                                                        <div class="rt-tile">
                                                            <div class="rt-label">{{ $label }}</div>
                                                            <div class="rt-value">{{ $value ?: '—' }}</div>
                                                        </div>
                                                    </div>
                                                @endforeach
                                                <div class="col-12">
                                                    <div class="rt-label">{{ __('locale.Comment') }}</div>
                                                    <div class="rt-text-box" style="min-height: 60px;">{{ $latestReview['comments'] ?: '—' }}</div>
                                                </div>
                                            </div>
                                        @else
                                            <div class="rt-empty">{{ __('risk.NoReviewsYet') }}</div>
                                        @endif
                                    </div>
                                </div>

                                {{-- All reviews --}}
                                <div class="rt-card rt-collapsible">
                                    <div class="rt-card-header">
                                        <h5 class="rt-card-title">{{ __('locale.ViewAllReview') }}</h5>
                                    </div>
                                    <div class="rt-card-body p-0">
                                        @if (count($riskReviewHistory))
                                            <div class="table-responsive">
                                                <table class="table table-hover mb-0 align-middle">
                                                    <thead class="table-light">
                                                        <tr>
                                                            <th>{{ __('locale.ReviewDate') }}</th>
                                                            <th>{{ __('locale.Reviewer') }}</th>
                                                            <th>{{ __('locale.Review') }}</th>
                                                            <th>{{ __('locale.NextStep') }}</th>
                                                            <th>{{ __('locale.NextReviewDate') }}</th>
                                                            <th>{{ __('locale.Comment') }}</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @foreach (array_reverse($riskReviewHistory) as $reviewRow)
                                                            <tr>
                                                                <td class="text-nowrap">{{ $reviewRow['review_date'] ?? '—' }}</td>
                                                                <td>{{ $reviewRow['reviewer'] ?: '—' }}</td>
                                                                <td><span class="badge bg-light-primary text-primary">{{ $reviewRow['review'] ?: '—' }}</span></td>
                                                                <td>{{ $reviewRow['next_step'] ?: '—' }}</td>
                                                                <td class="text-nowrap">{{ $reviewRow['next_review'] ?: '—' }}</td>
                                                                <td style="max-width: 320px;">{{ $reviewRow['comments'] ?: '—' }}</td>
                                                            </tr>
                                                        @endforeach
                                                    </tbody>
                                                </table>
                                            </div>
                                        @else
                                            <div class="p-2 rt-empty">{{ __('risk.NoReviewsYet') }}</div>
                                        @endif
                                    </div>
                                </div>

                                <!-- Reset Reviews Section -->
                                <section class="d-none" id="reset-risk-reviews-container">
                                    <div class="rt-card">
                                        <div class="rt-card-body text-center">
                                            <button type="button" id="submit-reset-risk-reviews"
                                                class="btn btn-primary" data-id="{{ $data['id'] }}">
                                                {{ __('risk.ResetReviews') }}
                                            </button>
                                        </div>
                                    </div>
                                </section>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="pills-comment-trail" role="tabpanel"
                            aria-labelledby="pills-comment-trail-tab">
                            <div class="rt-tab">
                                <div class="row g-2">
                                    {{-- Comments --}}
                                    <div class="col-lg-6">
                                        <div class="rt-card h-100">
                                            <div class="rt-card-header">
                                                <h5 class="rt-card-title">{{ __('locale.Comments') }}</h5>
                                                <span class="badge bg-light-secondary text-secondary">{{ count($data['comments']) }}</span>
                                            </div>
                                            <div class="rt-card-body">
                                                @if (auth()->user()->hasPermission('riskmanagement.AbleToCommentRiskManagement'))
                                                    <form id="add-comment-form" method="post" action="/" class="d-flex gap-1 mb-2">
                                                        @csrf
                                                        <input type="hidden" name="id" value="{{ $data['id'] }}">
                                                        <div class="flex-grow-1">
                                                            <input type="text" class="form-control" name="comment"
                                                                placeholder="{{ __('risk.TypeYourComment') }}">
                                                            <span class="error error-comment"></span>
                                                        </div>
                                                        <button class="btn btn-primary js-submit-comment" type="button" id="submit-add-comment">{{ __('risk.Publish') }}</button>
                                                    </form>
                                                @endif
                                                <div id="all-comments" style="max-height: 520px; overflow: auto;">
                                                    @forelse ($data['comments'] as $comment)
                                                        @php
                                                            $commenter = $comment['user']['name'] ?? '—';
                                                            $initials = collect(preg_split('/\s+/u', trim($commenter)))->filter()->take(2)
                                                                ->map(fn ($part) => mb_substr($part, 0, 1))->implode('');
                                                        @endphp
                                                        <div class="d-flex gap-1 mb-2">
                                                            <div class="rt-avatar">{{ mb_strtoupper($initials ?: '?') }}</div>
                                                            <div class="flex-grow-1">
                                                                <div class="d-flex justify-content-between">
                                                                    <span class="fw-bold text-primary">{{ $commenter }}</span>
                                                                    <small class="text-muted">{{ \Carbon\Carbon::parse($comment['date'])->diffForHumans() }}</small>
                                                                </div>
                                                                <div class="rt-text-box mt-25" style="min-height: auto;">{{ $comment['comment'] }}</div>
                                                            </div>
                                                        </div>
                                                    @empty
                                                        <div class="rt-empty">{{ __('risk.NoCommentsYet') }}</div>
                                                    @endforelse
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    {{-- Audit trail --}}
                                    <div class="col-lg-6">
                                        <div class="rt-card h-100">
                                            <div class="rt-card-header">
                                                <h5 class="rt-card-title">{{ __('risk.AuditTrail') }}</h5>
                                                <span class="badge bg-light-secondary text-secondary">{{ count($data['logs']) }}</span>
                                            </div>
                                            <div class="rt-card-body" style="max-height: 600px; overflow: auto;">
                                                @forelse ($data['logs'] as $log)
                                                    <div class="rt-timeline-item">
                                                        <div class="small text-muted mb-25">
                                                            {{ date('d/m/Y', strtotime($log['timestamp'])) }} · {{ date('g:i A', strtotime($log['timestamp'])) }}
                                                        </div>
                                                        <div>{{ $log['message'] }}</div>
                                                    </div>
                                                @empty
                                                    <div class="rt-empty">{{ __('locale.NONE') }}</div>
                                                @endforelse
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- modals --}}

        @if (auth()->user()->hasPermission('riskmanagement.update'))
            <!-- Modal Structure -->
            <div class="modal fade rt-modal" tabindex="-1" role="dialog" id="editRiskModal"
                aria-labelledby="editRiskModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-xl modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editRiskModalLabel">
                                {{ __('locale.EditRisk') }}
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="{{ __('locale.Close') }}"></button>
                        </div>
                        <div class="modal-body">
                            <!-- Form Inside Modal -->
                            <form id="edit-details-form" method="post"
                                action="{{ route('admin.risk_management.ajax.update') }}">
                                @csrf
                                @method('put')
                                <input type="hidden" name="id" value="{{ $data['id'] }}">
                                <input type="hidden" name="first_edit" value="1">

                                <div class="rt-form-section">
                                    <div class="rt-form-section-title"><i data-feather="link"></i> {{ __('risk.SectionMapping') }}</div>
                                    <div class="row g-1">
                                        <div class="col-md-6">
                                            <label class="form-label">{{ __('risk.VulnerabilityMapping') }}</label>
                                            <select name="risk_catalog_mapping_id[]" class="form-select multiple-select2" multiple="multiple">
                                                @foreach ($riskGroupings as $riskGrouping)
                                                    <optgroup label="{{ $riskGrouping->name }}">
                                                        @foreach ($riskGrouping->RiskCatalogs as $riskCatalog)
                                                            <option value="{{ $riskCatalog->id }}"
                                                                {{ in_array($riskCatalog->id, explode(',', $data['risk_catalog_mapping'] ?? '')) ? 'selected' : '' }}>
                                                                {{ $riskCatalog->number . ' - ' . $riskCatalog->name }}
                                                            </option>
                                                        @endforeach
                                                    </optgroup>
                                                @endforeach
                                            </select>
                                            <span class="error error-risk_catalog_mapping_id"></span>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">{{ __('risk.ThreatMapping') }}</label>
                                            <select name="threat_catalog_mapping_id[]" class="form-select multiple-select2" multiple="multiple">
                                                @foreach ($threatGroupings as $threatGrouping)
                                                    <optgroup label="{{ $threatGrouping->name }}">
                                                        @foreach ($threatGrouping->ThreatCatalogs as $ThreatCatalog)
                                                            <option value="{{ $ThreatCatalog->id }}"
                                                                {{ in_array($ThreatCatalog->id, explode(',', $data['threat_catalog_mapping'] ?? '')) ? 'selected' : '' }}>
                                                                {{ $ThreatCatalog->number . ' - ' . $ThreatCatalog->name }}
                                                            </option>
                                                        @endforeach
                                                    </optgroup>
                                                @endforeach
                                            </select>
                                            <span class="error error-threat_catalog_mapping_id"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="rt-form-section">
                                    <div class="rt-form-section-title"><i data-feather="info"></i> {{ __('risk.SectionGeneral') }}</div>
                                    <div class="row g-1">
                                        <div class="col-md-4">
                                            <label class="form-label">{{ __('locale.SubmissionDate') }}</label>
                                            <input name="submission_date" class="form-control flatpickr-date-time-compliance"
                                                value="{{ format_date($data['submission_date'], __('locale.N/A')) }}" />
                                            <span class="error error-submission_date"></span>
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label">{{ __('risk.Category') }}</label>
                                            <select class="select2 form-select" name="category_id">
                                                <option value="" selected>{{ __('locale.select-option') }}</option>
                                                @foreach ($categories as $category)
                                                    <option value="{{ $category->id }}" {{ $data['category_id'] == $category->id ? 'selected' : '' }}>
                                                        {{ $category->name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            <span class="error error-category_id"></span>
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label">{{ __('locale.ExternalReferenceId') }}</label>
                                            <input type="text" name="reference_id" class="form-control dt-post"
                                                aria-label="{{ __('locale.ExternalReferenceId') }}" value="{{ $data['reference_id'] }}" />
                                            <span class="error error-reference_id"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="rt-form-section">
                                    <div class="rt-form-section-title"><i data-feather="user"></i> {{ __('risk.SectionOwnership') }}</div>
                                    <div class="row g-1">
                                        <div class="col-md-6">
                                            <label class="form-label">{{ __('risk.RiskOwner') }}</label>
                                            <select class="select2 form-select" name="owner_id" id="owner_id">
                                                <option value="">{{ __('locale.select-option') }}</option>
                                                @foreach ($enabledUsers as $owner)
                                                    <option value="{{ $owner->id }}" data-manager="{{ $owner->risk_manager_id }}"
                                                        {{ $data['owner_id'] == $owner['id'] ? 'selected' : '' }}>
                                                        {{ $owner->name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            <span class="error error-owner_id"></span>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">{{ __('locale.OwnersManager') }}</label>
                                            @php $ownerManagerId = optional($enabledUsers->firstWhere('id', $data['owner_id']))->risk_manager_id; @endphp
                                            <select class="select2 form-select" id="owner_manager_display" disabled>
                                                <option value="">—</option>
                                                @foreach ($enabledUsers as $owner)
                                                    <option value="{{ $owner->id }}" {{ (int) $ownerManagerId === $owner->id ? 'selected' : '' }}>
                                                        {{ $owner->name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            <input type="hidden" name="owner_manager_id" id="owner_manager_id" value="{{ $ownerManagerId }}">
                                            <span class="error error-owner_manager_id"></span>
                                        </div>
                                        <div class="col-12">
                                            <small class="text-muted">{{ __('risk.OwnerFromAssetHint') }}</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="rt-form-section">
                                    <div class="rt-form-section-title"><i data-feather="map-pin"></i> {{ __('risk.SectionScope') }}</div>
                                    <div class="row g-1">
                                        <div class="col-12">
                                            <label class="form-label">{{ __('locale.SiteLocation') }}</label>
                                            <select class="form-select multiple-select2" name="location_id[]" multiple="multiple">
                                                @foreach ($locations as $location)
                                                    <option value="{{ $location->id }}" {{ in_array($location->id, $data['location_ids']) ? 'selected' : '' }}>
                                                        {{ $location->name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            <span class="error error-location_id"></span>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">{{ __('risk.AffectedAssets') }}</label>
                                            <select name="affected_asset_id[]" class="form-select select-affected-asset">
                                                <option value="" selected>{{ __('risk.SelectAnAsset') }}</option>
                                                @foreach ($assets as $asset)
                                                    <option value="{{ $asset['id'] }}_asset" data-owner-name="{{ $asset['owner_name'] }}"
                                                        data-rank="{{ $asset['rank'] }}"
                                                        {{ in_array($asset['id'], $data['asset_ids']) ? 'selected' : '' }}>
                                                        {{ $asset['name'] }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            <span class="error error-affected_asset_id"></span>
                                        </div>
                                        @php $linkedAssets = collect($assets)->whereIn('id', $data['asset_ids']); @endphp
                                        <div class="col-md-3">
                                            <label class="form-label">{{ __('risk.AssetOwner') }}</label>
                                            <input type="text" id="asset_owner_display" class="form-control" disabled placeholder="—"
                                                value="{{ $linkedAssets->pluck('owner_name')->filter()->unique()->implode(', ') }}">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="form-label">{{ __('risk.AssetRank') }}</label>
                                            <input type="text" id="asset_rank_display" class="form-control" readonly placeholder="—"
                                                value="{{ $data['asset_rank_snapshot'] ?? $linkedAssets->pluck('rank')->filter()->first() }}">
                                            <input type="hidden" name="asset_rank_snapshot" id="asset_rank_snapshot"
                                                value="{{ $data['asset_rank_snapshot'] ?? $linkedAssets->pluck('rank')->filter()->first() }}">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">{{ __('locale.Team') }}</label>
                                            <select name="team_id[]" class="form-select multiple-select2" multiple="multiple">
                                                @foreach ($teams as $team)
                                                    <option value="{{ $team->id }}" {{ in_array($team->id, $data['team_ids']) ? 'selected' : '' }}>
                                                        {{ $team->name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            <span class="error error-team_id"></span>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">{{ __('locale.AdditionalStakeholders') }}</label>
                                            <select name="additional_stakeholder_id[]" class="form-select multiple-select2" multiple="multiple">
                                                @foreach ($enabledUsers as $additionalStakeholder)
                                                    <option value="{{ $additionalStakeholder->id }}"
                                                        {{ in_array($additionalStakeholder->id, $data['additionalStakeholder_ids']) ? 'selected' : '' }}>
                                                        {{ $additionalStakeholder->name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            <span class="error error-additional_stakeholder_id"></span>
                                        </div>
                                        <div class="col-12">
                                            <label class="form-label">{{ __('risk.Tags') }}</label>
                                            <select name="tags[]" class="form-select multiple-select2" multiple="multiple">
                                                @foreach ($tags as $tag)
                                                    <option value="{{ $tag->id }}" {{ in_array($tag->id, $data['tag_ids']) ? 'selected' : '' }}>
                                                        {{ $tag->tag }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            <span class="error error-tags"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="rt-modal-actions">
                                    <button id="cancel-edit-details" type="reset" class="btn btn-outline-secondary" data-bs-dismiss="modal">{{ __('locale.Cancel') }}</button>
                                    <button id="submit-edit-details" type="button" class="btn btn-primary">{{ __('locale.SaveDetails') }}</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        @endif

        <!-- CloseRisks END -->
        @if (auth()->user()->hasPermission('riskmanagement.update'))
            <!-- Modal Structure -->
            <div class="modal fade rt-modal" tabindex="-1" role="dialog" id="editRiskModal2"
                aria-labelledby="editRiskModal2Label" aria-hidden="true">
                <div class="modal-dialog modal-xl modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editRiskModal2Label">
                                {{ __('locale.EditRisk') }}
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="{{ __('locale.Close') }}"></button>
                        </div>
                        <div class="modal-body">
                            <!-- Form Inside Modal -->
                            <form id="edit-details-form2" method="post"
                                action="{{ route('admin.risk_management.ajax.update') }}">
                                @csrf
                                @method('put')
                                <input type="hidden" name="id" value="{{ $data['id'] }}">
                                <input type="hidden" name="second_edit" value="2">

                                <div class="rt-form-section">
                                    <div class="rt-form-section-title"><i data-feather="shield"></i> {{ __('risk.SectionControlMapping') }}</div>
                                    <div class="row g-1">
                                        <div class="col-md-6">
                                            <label class="form-label">{{ __('risk.ControlRegulation') }}</label>
                                            <select class="select2 form-select" name="framework_id">
                                                <option value="" selected>{{ __('locale.select-option') }}</option>
                                                @foreach ($frameworks as $framework)
                                                    <option value="{{ $framework->id }}" data-controls="{{ json_encode($framework->FrameworkControls) }}"
                                                        {{ $data['regulation'] == $framework->id ? 'selected' : '' }}>
                                                        {{ $framework->name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            <span class="error error-framework_id"></span>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">{{ __('risk.ControlNumber') }}</label>
                                            <select class="select2 form-select" name="control_id">
                                                <option value="" selected>{{ __('locale.select-option') }}</option>
                                                @foreach ($data['framework_controls'] as $frameworkControl)
                                                    <option value="{{ $frameworkControl['id'] }}"
                                                        {{ $data['control_id'] == $frameworkControl['id'] ? 'selected' : '' }}>
                                                        {{ $frameworkControl['short_name'] }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            <span class="error error-control_id"></span>
                                        </div>
                                        <div class="col-12">
                                            <label class="form-label">{{ __('locale.Technology') }}</label>
                                            <select name="technology_id[]" class="form-select multiple-select2" multiple="multiple">
                                                @foreach ($technologies as $technology)
                                                    <option value="{{ $technology->id }}"
                                                        {{ in_array($technology->id, $data['technology_ids']) ? 'selected' : '' }}>
                                                        {{ $technology->name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            <span class="error error-technology_id"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="rt-form-section">
                                    <div class="rt-form-section-title"><i data-feather="bar-chart-2"></i> {{ __('risk.SectionScoring') }}</div>
                                    <div class="row g-1">
                                        <div class="col-md-6 col-lg-3">
                                            <label class="form-label">{{ __('risk.ImpactScope') }}</label>
                                            <select class="select2 form-select" name="risk_source_id">
                                                <option value="" selected>{{ __('locale.select-option') }}</option>
                                                @foreach ($riskSources as $riskSource)
                                                    <option value="{{ $riskSource->id }}" {{ $data['source_id'] == $riskSource->id ? 'selected' : '' }}>
                                                        {{ $riskSource->name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            <span class="error error-risk_source_id"></span>
                                        </div>
                                        <div class="col-md-6 col-lg-3">
                                            <label class="form-label">{{ __('risk.RiskScoringMethod') }}</label>
                                            <select class="select2 form-select" name="risk_scoring_method_id">
                                                <option value="" selected disabled hidden>{{ __('locale.select-option') }}</option>
                                                @foreach ($riskScoringMethods as $riskScoringMethod)
                                                    <option value="{{ $riskScoringMethod->id }}"
                                                        {{ $data['risk_scoring']['id'] == $riskScoringMethod->id ? 'selected' : '' }}>
                                                        {{ $riskScoringMethod->name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            <span class="error error-risk_scoring_method_id"></span>
                                        </div>
                                        <div class="col-md-6 col-lg-3">
                                            <label class="form-label">{{ __('risk.CurrentLikelihood') }}</label>
                                            <select class="select2 form-select" name="current_likelihood_id">
                                                <option value="" disabled hidden selected>{{ __('locale.select-option') }}</option>
                                                @foreach ($riskLikelihoods as $riskLikelihood)
                                                    <option value="{{ $riskLikelihood->id }}"
                                                        {{ $data['likelihood']['id'] == $riskLikelihood->id ? 'selected' : '' }}>
                                                        {{ $riskLikelihood->name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            <span class="error error-current_likelihood_id"></span>
                                        </div>
                                        <div class="col-md-6 col-lg-3">
                                            <label class="form-label">{{ __('risk.CurrentImpact') }}</label>
                                            <select class="select2 form-select" name="current_impact_id">
                                                <option value="" disabled hidden selected>{{ __('locale.select-option') }}</option>
                                                @foreach ($impacts as $impact)
                                                    <option value="{{ $impact->id }}" {{ $data['impact']['id'] == $impact->id ? 'selected' : '' }}>
                                                        {{ $impact->name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            <span class="error error-current_impact_id"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="rt-form-section">
                                    <div class="rt-form-section-title"><i data-feather="file-text"></i> {{ __('risk.SectionAnalysis') }}</div>
                                    <div class="row g-1">
                                        <div class="col-12">
                                            <label class="form-label">{{ __('risk.ResponsiblePart') }}</label>
                                            <select class="select2 form-select" name="responsible_department_id">
                                                <option value="">{{ __('locale.select-option') }}</option>
                                                @foreach ($departments as $department)
                                                    <option value="{{ $department->id }}" {{ (int) $data['responsible_department_id'] === $department->id ? 'selected' : '' }}>
                                                        {{ $department->name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            @if (!$data['responsible_department_id'] && $data['assessment'])
                                                <small class="text-muted">{{ __('risk.PreviousResponsibleParty') }}: {{ strip_tags($data['assessment']) }}</small>
                                            @endif
                                            <span class="error error-responsible_department_id"></span>
                                        </div>
                                        <div class="col-12">
                                            <label class="form-label">{{ __('risk.CurrentControl') }}</label>
                                            <textarea class="form-control" name="current_control" rows="2">{{ $data['current_control'] }}</textarea>
                                            <span class="error error-current_control"></span>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">{{ __("locale.KRI'S") }}</label>
                                            <div id="risk_addational_notes" class="rt-editor">{!! $data['notes'] !!}</div>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">{{ __('locale.Description') }}</label>
                                            <div id="risk_description" class="rt-editor">{!! $data['risk_description'] !!}</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="rt-form-section">
                                    <div class="rt-form-section-title"><i data-feather="paperclip"></i> {{ __('risk.SupportingDocumentation') }}</div>
                                    <div class="row g-1">
                                        <div class="col-12 supporting_documentation_container">
                                            <input type="file" multiple name="supporting_documentation[]" class="form-control dt-post"
                                                aria-label="{{ __('risk.SupportingDocumentation') }}" />
                                            <span class="error error-supporting_documentation"></span>
                                            <div class="d-flex flex-wrap gap-50 mt-1">
                                                @forelse ($data['files'] ?? [] as $file)
                                                    <span class="rt-file-chip">
                                                        <span class="supporting_documentation cursor-pointer" data-id="{{ $file['id'] }}"
                                                            data-risk-id="{{ $data['id'] }}"><i data-feather="file-text"></i> {{ $file['name'] }}</span>
                                                        <span class="text-danger delete_supporting_documentation cursor-pointer" data-id="{{ $file['id'] }}"
                                                            data-risk-id="{{ $data['id'] }}"><i data-feather="x"></i></span>
                                                    </span>
                                                @empty
                                                    <span class="rt-empty">{{ __('locale.NONE') }}</span>
                                                @endforelse
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="rt-modal-actions">
                                    <button id="cancel-edit-details2" type="reset" class="btn btn-outline-secondary" data-bs-dismiss="modal">{{ __('locale.Cancel') }}</button>
                                    <button id="submit-edit-details2" type="button" class="btn btn-primary">{{ __('locale.SaveDetails') }}</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        @endif

        <!-- Modal Structure -->
        <div class="modal fade" id="addCommentModal" tabindex="-1" aria-labelledby="addCommentModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addCommentModalLabel">
                            {{ __('locale.Comments') }}
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                            aria-label="{{ __('locale.Close') }}"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Add Comment Form -->
                        <div id="add-comment" data-id="IDIDID">
                            <form method="post" action="/" class="px-0">
                                @csrf
                                <input type="hidden" name="id" value="{{ $data['id'] }}">
                                <textarea class="form-control" rows="3" name="comment"></textarea>
                                <span class="error error-comment"></span>

                                <div class="text-end">
                                    <button class="btn btn-success mt-2 js-submit-comment"
                                        type="button">{{ __('locale.Submit') }}</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="modal fade" id="changeRiskStatusModal" tabindex="-1"
            aria-labelledby="changeRiskStatusModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="changeRiskStatusModalLabel">
                            {{ __('locale.SetRiskStatusTo') }}
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                            aria-label="{{ __('locale.Close') }}"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Form for changing risk status -->
                        <form class="row px-0" id="change-risk-status-form" method="post"
                            action="{{ route('admin.risk_management.ajax.update') }}">
                            @csrf
                            @method('put')
                            <input type="hidden" name="id" value="{{ $data['id'] }}">
                            <div class="col-12">
                                {{-- Close reason --}}
                                <div class="mb-1">
                                    <select class="select2 form-select" name="status">
                                        <option value="" selected>
                                            {{ __('locale.select-option') }}
                                        </option>
                                        @foreach ($statuses as $status)
                                            @if ($status->name == 'Closed')
                                                @if (auth()->user()->hasPermission('riskmanagement.AbleToCloseRisks'))
                                                    <option value="{{ $status->id }}">
                                                        {{ __('risk.CloseRisk') }}
                                                    </option>
                                                @endif
                                            @else
                                                <option value="{{ $status->id }}">
                                                    {{ $status->name }}
                                                </option>
                                            @endif
                                        @endforeach
                                    </select>
                                    <span class="error error-status"></span>
                                </div>
                            </div>
                            <div class="col-12 text-center mt-2">
                                <button id="submit-change-risk-status" type="button"
                                    class="btn btn-primary me-1">{{ __('locale.Update') }}</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>


        <!-- CloseRisks start -->
        @if (auth()->user()->hasPermission('riskmanagement.AbleToCloseRisks'))
            <!-- Close Risk Modal -->
            <div class="modal fade" id="closeRiskModal" tabindex="-1" aria-labelledby="closeRiskModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="closeRiskModalLabel">
                                {{ __('risk.CloseRisk') }}
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="{{ __('locale.Close') }}"></button>
                        </div>
                        <div class="modal-body">
                            <form id="close-reason-form" method="post"
                                action="{{ route('admin.risk_management.ajax.update') }}">
                                @csrf
                                @method('put')
                                <input type="hidden" name="id" value="{{ $data['id'] }}">

                                <!-- Close reason -->
                                <div class="mb-3">
                                    <label class="form-label">{{ __('locale.Reason') }}</label>
                                    <select class="select2 form-select" name="close_reason">
                                        <option value="" selected>
                                            {{ __('locale.select-option') }}
                                        </option>
                                        @foreach ($closeReasons as $closeReason)
                                            <option value="{{ $closeReason->id }}">
                                                {{ $closeReason->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                    <span class="error error-close_reason"></span>
                                </div>

                                <!-- Close-Out Information note -->
                                <div class="mb-3">
                                    <label class="form-label">{{ __('risk.CloseOutInformation') }}</label>
                                    <textarea class="form-control" name="note" rows="3"></textarea>
                                    <span class="error error-note"></span>
                                </div>

                                <div class="text-center mt-3">
                                    <button id="submit-close-reason" type="button"
                                        class="btn btn-primary me-1">{{ __('locale.Submit') }}</button>
                                    <button type="button" class="btn btn-secondary"
                                        data-bs-dismiss="modal">{{ __('locale.Cancel') }}</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        @endif

        @if (auth()->user()->hasPermission('plan_mitigation.create'))
            <!-- Modal -->
            <div class="modal fade rt-modal" id="editMitigationModal" tabindex="-1"
                aria-labelledby="editMitigationModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-xl modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editMitigationModalLabel">{{ __('locale.EditMitigation') }}
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="{{ __('locale.Close') }}"></button>
                        </div>
                        <div class="modal-body">
                            <form id="edit-mitigation-form" method="post" action="/">
                                @csrf
                                <input type="hidden" name="risk_id" value="{{ $data['id'] }}">
                                <input type="hidden" name="action_plans_present" value="1">
                                @php
                                        $editNatures = $data['mitigation']['mitigation_nature'] ?? [];
                                        $editFunctions = $data['mitigation']['mitigation_function'] ?? [];
                                        $editResults = $data['mitigation']['expected_result'] ?? [];
                                    @endphp

                                <div class="rt-form-section">
                                    <div class="rt-form-section-title"><i data-feather="calendar"></i> {{ __('risk.SectionPlanning') }}</div>
                                    <div class="row g-1">
                                        <div class="col-md-4">
                                            <label class="text-label">{{ __('risk.MitigationPlanning') }}</label>
                                            <input name="planned_mitigation_date"
                                            class="form-control flatpickr-date-time-compliance"
                                            value="{{ format_date($data['mitigation']['planning_date'], '') }}" />
                                            <span class="error error-planned_mitigation_date "></span>
                                        </div>
                                        <div class="col-md-4">
                                            <label class="text-label">{{ __('risk.TreatmentDueDate') }}</label>
                                            <input type="date" class="form-control" name="treatment_due_date"
                                            value="{{ $data['mitigation']['treatment_due_date'] ?? '' }}">
                                        </div>
                                        <div class="col-md-4">
                                            <label class="text-label">{{ __('risk.PlanningStrategy') }}</label>
                                            <select class="select2 form-select" name="planning_strategy">
                                            <option value="">{{ __('locale.select-option') }}</option>
                                            @foreach ($planningStrategies as $planningStrategy)
                                            <option value="{{ $planningStrategy->id }}"
                                            {{ ($data['mitigation']['planning_strategy_id'] ?? '') == $planningStrategy->id ? 'selected' : '' }}>
                                            {{ $planningStrategy->name }}
                                            </option>
                                            @endforeach
                                            </select>
                                            <span class="error error-planning_strategy"></span>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="text-label">{{ __('risk.MitigationOwner') }}</label>
                                            <select class="select2 form-select" name="mitigation_owner_id">
                                            <option value="">{{ __('locale.select-option') }}</option>
                                            @foreach ($enabledUsers as $owner)
                                            <option value="{{ $owner->id }}"
                                            data-manager="{{ json_encode($owner->manager) }}"
                                            {{ isset($data['mitigation']['mitigation_owner']) && $data['mitigation']['mitigation_owner'] == $owner->name ? 'selected' : '' }}>
                                            {{ $owner->name }}
                                            </option>
                                            @endforeach
                                            </select>
                                            <span class="error error-mitigation_owner_id"></span>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="text-label">{{ __('risk.MitigationTeam') }}</label>
                                            <select name="mitigation_team_id[]" class="form-select multiple-select2"
                                            multiple="multiple">
                                            @foreach ($teams as $team)
                                            <option value="{{ $team->id }}"
                                            {{ in_array($team->id, $data['mitigation']['team_ids'] ?? []) ? 'selected' : '' }}>
                                            {{ $team->name }}
                                            </option>
                                            @endforeach
                                            </select>
                                            <span class="error error-mitigation_team_id"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="rt-form-section">
                                    <div class="rt-form-section-title"><i data-feather="dollar-sign"></i> {{ __('risk.SectionEffortCost') }}</div>
                                    <div class="row g-1">
                                        <div class="col-md-4">
                                            <label class="text-label">{{ __('risk.MitigationEffort') }}</label>
                                            <select class="select2 form-select" name="mitigation_effort">
                                            <option value="">{{ __('locale.select-option') }}</option>
                                            @foreach ($mitigationEfforts as $mitigationEffort)
                                            <option value="{{ $mitigationEffort->id }}"
                                            {{ ($data['mitigation']['mitigation_effort_id'] ?? '') == $mitigationEffort->id ? 'selected' : '' }}>
                                            {{ $mitigationEffort->name }}
                                            </option>
                                            @endforeach
                                            </select>
                                            <span class="error error-mitigation_effort"></span>
                                        </div>
                                        <div class="col-md-4">
                                            <label class="text-label">{{ __('risk.MitigationCost') }}</label>
                                            <select class="select2 form-select" name="mitigation_cost">
                                            <option value="">{{ __('locale.select-option') }}</option>
                                            @foreach ($mitigationCosts as $mitigationCost)
                                            <option value="{{ $mitigationCost->id }}"
                                            {{ ($data['mitigation']['mitigation_cost_id'] ?? '') == $mitigationCost->id ? 'selected' : '' }}>
                                            {{ $mitigationCost->name }}
                                            @php
                                            $valuation_level_name = '';
                                            if (!empty($mitigationCost->valuation_level_name)) {
                                            $valuation_level_name =
                                            ' (' . $mitigationCost->valuation_level_name . ')';
                                            }

                                            if ($mitigationCost->min_value === $mitigationCost->max_value) {
                                            echo get_setting('currency') .
                                            number_format($mitigationCost->min_value) .
                                            $valuation_level_name;
                                            } else {
                                            echo get_setting('currency') .
                                            number_format($mitigationCost->min_value) .
                                            ' to ' .
                                            get_setting('currency') .
                                            number_format($mitigationCost->max_value) .
                                            $valuation_level_name;
                                            }
                                            @endphp
                                            </option>
                                            @endforeach
                                            </select>
                                            <span class="error error-mitigation_cost"></span>
                                        </div>
                                        <div class="col-md-4">
                                            <label class="text-label">{{ __('risk.MitigationPercent') }}</label>
                                            <input type="number" min="0" class="form-control"
                                            name="mitigation_percent"
                                            value="{{ $data['mitigation']['mitigation_percent'] ?? '' }}">
                                            <span class="error error-mitigation_percent"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="rt-form-section">
                                    <div class="rt-form-section-title"><i data-feather="layers"></i> {{ __('risk.SectionClassification') }}</div>
                                    <div class="row g-1">
                                        <div class="col-md-4">
                                            <label class="text-label">{{ __('risk.MitigationNature') }}</label>
                                            <select name="mitigation_nature[]" class="form-select multiple-select2" multiple>
                                            <option value="technical" {{ in_array('technical', $editNatures) ? 'selected' : '' }}>{{ __('risk.NatureTechnical') }}</option>
                                            <option value="physical" {{ in_array('physical', $editNatures) ? 'selected' : '' }}>{{ __('risk.NaturePhysical') }}</option>
                                            <option value="administrative" {{ in_array('administrative', $editNatures) ? 'selected' : '' }}>{{ __('risk.NatureAdministrative') }}</option>
                                            </select>
                                        </div>
                                        <div class="col-md-4">
                                            <label class="text-label">{{ __('risk.MitigationFunction') }}</label>
                                            <select name="mitigation_function[]" class="form-select multiple-select2" multiple>
                                            <option value="preventive" {{ in_array('preventive', $editFunctions) ? 'selected' : '' }}>{{ __('risk.FuncPreventive') }}</option>
                                            <option value="detective" {{ in_array('detective', $editFunctions) ? 'selected' : '' }}>{{ __('risk.FuncDetective') }}</option>
                                            <option value="corrective" {{ in_array('corrective', $editFunctions) ? 'selected' : '' }}>{{ __('risk.FuncCorrective') }}</option>
                                            <option value="deterrent" {{ in_array('deterrent', $editFunctions) ? 'selected' : '' }}>{{ __('risk.FuncDeterrent') }}</option>
                                            <option value="recovery" {{ in_array('recovery', $editFunctions) ? 'selected' : '' }}>{{ __('risk.FuncRecovery') }}</option>
                                            <option value="compensating" {{ in_array('compensating', $editFunctions) ? 'selected' : '' }}>{{ __('risk.FuncCompensating') }}</option>
                                            </select>
                                        </div>
                                        <div class="col-md-4">
                                            <label class="text-label">{{ __('risk.ExpectedResult') }}</label>
                                            <select name="expected_result[]" class="form-select multiple-select2" multiple>
                                            <option value="reduce_impact" {{ in_array('reduce_impact', $editResults) ? 'selected' : '' }}>{{ __('risk.ReduceImpact') }}</option>
                                            <option value="reduce_likelihood" {{ in_array('reduce_likelihood', $editResults) ? 'selected' : '' }}>{{ __('risk.ReduceLikelihood') }}</option>
                                            </select>
                                        </div>
                                        <div class="col-12">
                                            <label class="text-label">{{ __('locale.MitigationControls') }}</label>
                                            <select name="mitigation_control_id[]" class="form-select multiple-select2"
                                            multiple="multiple">
                                            @foreach ($frameworks as $framework)
                                            @foreach ($framework->FrameworkControls as $control)
                                            <option value="{{ $control->id }}"
                                            {{ in_array($control->id, $data['mitigation']['mitigation_control_ids'] ?? []) ? 'selected' : '' }}>
                                            {{ $control->short_name }}
                                            </option>
                                            @endforeach
                                            @endforeach
                                            </select>
                                            <span class="error error-mitigation_control_id"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="rt-form-section">
                                    <div class="rt-form-section-title"><i data-feather="tool"></i> {{ __('risk.SectionSolution') }}</div>
                                    <div class="row g-1">
                                        <div class="col-12">
                                            <label class="text-label">{{ __('risk.CurrentSolution') }}</label>
                                            <div id="risk_current_solution" class="rt-editor">
                                            {!! $data['mitigation']['current_solution'] !!}
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="text-label">{{ __('risk.SecurityRequirements') }}</label>
                                            <textarea class="form-control" name="security_requirements" rows="3">{{ $data['mitigation']['security_requirements'] }}</textarea>
                                            <span class="error error-security_requirements "></span>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="text-label">{{ __('risk.SecurityRecommendations') }}</label>
                                            <textarea class="form-control" name="security_recommendations" rows="3">{{ $data['mitigation']['security_recommendations'] }}</textarea>
                                            <span class="error error-security_recommendations "></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="rt-form-section">
                                    <div class="rt-form-section-title justify-content-between">
                                        <span><i data-feather="list"></i> {{ __('risk.ActionPlans') }}</span>
                                        <button type="button" class="btn btn-sm btn-outline-primary" id="add_edit_action_plan">+ {{ __('risk.AddActionPlan') }}</button>
                                    </div>
                                    <div class="row g-1 small text-muted fw-bold mb-50 d-none d-md-flex">
                                        <div class="col-md-3">{{ __('risk.ActionTitle') }}</div>
                                        <div class="col-md-3">{{ __('risk.LikelihoodReduction') }}</div>
                                        <div class="col-md-3">{{ __('risk.ImpactReduction') }}</div>
                                        <div class="col-md-2">{{ __('risk.ActionDueDate') }}</div>
                                    </div>
                                    <div id="edit_action_plans_container">
                                        @foreach ($data['action_plans'] ?? [] as $idx => $plan)
                                            <div class="border rounded p-2 mb-2 edit-action-plan-row">
                                                <div class="row g-1">
                                                    <div class="col-md-3">
                                                        <input class="form-control" name="action_plans[{{ $idx }}][title]"
                                                            placeholder="{{ __('risk.ActionTitle') }}" value="{{ $plan->title }}">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <input type="number" min="0" max="100" step="0.01"
                                                            class="form-control edit-ap-likelihood"
                                                            name="action_plans[{{ $idx }}][likelihood_reduction]"
                                                            placeholder="{{ __('risk.LikelihoodReduction') }}"
                                                            value="{{ $plan->likelihood_reduction }}">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <input type="number" min="0" max="100" step="0.01"
                                                            class="form-control edit-ap-impact"
                                                            name="action_plans[{{ $idx }}][impact_reduction]"
                                                            placeholder="{{ __('risk.ImpactReduction') }}"
                                                            value="{{ $plan->impact_reduction }}">
                                                    </div>
                                                    <div class="col-md-2">
                                                        <input type="date" class="form-control"
                                                            name="action_plans[{{ $idx }}][due_date]"
                                                            value="{{ optional($plan->due_date)->format('Y-m-d') }}">
                                                    </div>
                                                    <div class="col-md-1">
                                                        <button type="button" class="btn btn-sm btn-outline-danger remove-edit-action-plan">×</button>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    </div>
                                    <small class="text-muted">{{ __('risk.ActionPlansHint') }} <span id="edit_action_plans_totals"></span></small>
                                </div>
                                <div class="rt-modal-actions">
                                    <button id="cancel-edit-mitigation" type="reset" class="btn btn-outline-secondary" data-bs-dismiss="modal">{{ __('locale.Cancel') }}</button>
                                    <button id="submit-edit-mitigation" type="button" class="btn btn-primary">{{ __('locale.SaveMitigation') }}</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        @endif

        <!-- Download File Form -->
        <form class="d-none" id="download-file-form" method="post"
            action="{{ route('admin.risk_management.ajax.download_file') }}">
            @csrf
            <input type="hidden" name="id">
            <input type="hidden" name="risk_id">
        </form>

        <!-- end tab -->

        <!-- Add Review Form -->
        <div class="modal fade" id="addReviewModal" tabindex="-1" aria-labelledby="addReviewModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addReviewModalLabel">{{ __('locale.AddReview') }}</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                            aria-label="{{ __('locale.Close') }}"></button>
                    </div>
                    <div class="modal-body">
                        <form class="row" id="add-review-form" method="post" action="/">
                            @csrf
                            <input type="hidden" name="risk_id" value="{{ $data['id'] }}">

                            <div class="col-12 col-md-6">
                                <!-- Basic Review Information -->
                                <div class="mb-1">
                                    <label class="text-label">{{ __('locale.ReviewDate') }}</label>:
                                    {{ date(get_default_date_format()) }}
                                </div>
                                <div class="mb-1">
                                    <label class="text-label">{{ __('locale.Reviewer') }}</label>:
                                    {{ auth()->user()->name }}
                                </div>

                                <!-- Review Selection Fields -->
                                @foreach (['review' => $reviews, 'next_step' => $nextSteps] as $field => $options)
                                    <div class="mb-1">
                                        <label class="text-label">{{ __('locale.' . ucfirst($field)) }}</label>
                                        <select class="select2 form-select" name="{{ $field }}"
                                            id="{{ $field }}">
                                            <option value="" selected disabled>
                                                {{ __('locale.select-option') }}</option>
                                            @foreach ($options as $option)
                                                <option value="{{ $option->id }}">{{ $option->name }}</option>
                                            @endforeach
                                        </select>
                                        <span class="error error-{{ $field }}"></span>
                                    </div>
                                @endforeach

                                <!-- Project Selection (Initially Hidden) -->
                                <div class="mb-1 d-none" id="project-container">
                                    <label class="text-label">{{ __('locale.ProjectName') }}</label>
                                    <select class="select2 form-select" name="project">
                                        <option value="" selected disabled>{{ __('locale.select-option') }}
                                        </option>
                                        @foreach ($projects as $project)
                                            <option value="{{ $project->id }}">{{ $project->name }}</option>
                                        @endforeach
                                    </select>
                                    <span class="error error-project"></span>
                                </div>

                                <!-- Comments -->
                                <div class="mb-1">
                                    <label class="text-label">{{ __('locale.Comment') }}</label>
                                    <textarea class="form-control" name="comments" rows="3"></textarea>
                                    <span class="error error-comments"></span>
                                </div>
                            </div>

                            <!-- Next Review Date Section -->
                            <div class="col-12 col-md-6 px-lg-5">
                                <div class="mb-1">
                                    <p>{{ __('locale.BasedOnTheCurrentRiskScore') }}
                                        {{ $data['get_next_review_default'] }}</p>
                                    <p>{{ __('locale.WouldYouLikeToUseADifferentDate') }}</p>
                                    <label class="text-label">{{ __('locale.NextReviewDate') }}</label>
                                    <input name="next_review_date"
                                        class="form-control flatpickr-date-time-compliance"
                                        value="{{ $data['get_next_review_default'] }}" />
                                    <span class="error error-next_review_date"></span>
                                </div>
                            </div>

                            <!-- Form Actions -->
                            <div class="col-12 text-center mt-2">
                                <button type="button" id="submit-add-review" class="btn btn-primary me-1">
                                    {{ __('locale.SubmitReview') }}
                                </button>
                                <button type="reset" id="cancel-add-review" class="btn btn-danger"
                                    data-bs-dismiss="modal">
                                    {{ __('locale.Cancel') }}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>



@endsection
@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/pickers/flatpickr/flatpickr.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>
@endsection

@section('page-script')
    <script src="{{ asset(mix('js/scripts/forms/form-select2.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
    <script src="{{ asset('vendors/js/extensions/moment.min.js') }}"></script>
    <script src="{{ asset('js/scripts/highcharts.js') }}"></script>
    <script>
        const lang = [],
            URLs = [],
            assets = [];
        lang['confirmDelete'] = "{{ __('locale.ConfirmDelete') }}";
        lang['cancel'] = "{{ __('locale.Cancel') }}";
        lang['success'] = "{{ __('locale.Success') }}";
        lang['error'] = "{{ __('locale.Error') }}";
        lang['confirmDeleteFileMessage'] = "{{ __('locale.AreYouSureToDeleteThisFile') }}";
        lang['revert'] = "{{ __('locale.YouWontBeAbleToRevertThis') }}";
        lang['resetMitigationsTitle'] = @json(__('risk.ResetMitigationsTitle'));
        lang['resetMitigationsText'] = @json(__('risk.ResetMitigationsText'));
        lang['resetMitigationsConfirm'] = @json(__('risk.ResetMitigations'));
        URLs['updateSubject'] = "{{ route('admin.risk_management.ajax.update_subject') }}";
        URLs['updateRiskScoring'] = "{{ route('admin.risk_management.ajax.update_risk_scoring') }}";
        URLs['addComment'] = "{{ route('admin.risk_management.ajax.add_comment') }}";
        URLs['getRiskLevels'] = "{{ route('admin.risk_management.ajax.get_risk_levels') }}";
        URLs['residualScoringHistory'] =
            "{{ route('admin.risk_management.ajax.residual_scoring_history', $data['id']) }}";
        URLs['getScoringHistories'] = "{{ route('admin.risk_management.ajax.get_scoring_histories', $data['id']) }}";
        const riskHistoryConfig = {
            maxScore: {{ (float) ($data['max_risk_score'] ?? 10) }},
            appetite: {{ isset($data['risk_appetite']['value']) && $data['risk_appetite']['value'] !== null ? (float) $data['risk_appetite']['value'] : 'null' }},
            labels: {
                inherent: @json(__('risk.InherentRisk')),
                residual: @json(__('risk.ResidualRisk')),
                score: @json(__('risk.HistoryScore')),
                level: @json(__('risk.HistoryLevel')),
                appetite: @json(__('risk.AppetiteLimitLine')),
                lastUpdate: @json(__('risk.HistoryLastUpdate')),
                now: @json(__('risk.HistoryNow')),
                changeLog: @json(__('risk.HistoryChangeLog')),
                date: @json(__('risk.HistoryDate')),
                change: @json(__('risk.HistoryChange')),
                reduction: @json(__('risk.HistoryReduction')),
                withinAppetite: @json(__('risk.WithinAppetite')),
                aboveAppetite: @json(__('risk.ExceedsAppetite')),
            },
        };
        URLs['updateDetails'] = "{{ route('admin.risk_management.ajax.update') }}";
        URLs['deleteFile'] = "{{ route('admin.risk_management.ajax.delete_file') }}";
        URLs['acceptRejectMitigation'] = "{{ route('admin.risk_management.ajax.accept_reject_mitigation') }}";
        URLs['updateRiskMitigation'] = "{{ route('admin.risk_management.ajax.update_risk_mitigation') }}";
        URLs['addRiskReview'] = "{{ route('admin.risk_management.ajax.add_risk_review') }}";
        URLs['riskCloseReason'] = "{{ route('admin.risk_management.ajax.risk_close_reason') }}";
        URLs['riskReopen'] = "{{ route('admin.risk_management.ajax.risk_reopen') }}";
        URLs['riskChangeStatus'] = "{{ route('admin.risk_management.ajax.risk_Change_Status') }}";
        URLs['resetRiskMitigations'] = "{{ route('admin.risk_management.ajax.reset_risk_mitigations') }}";
        URLs['resetRiskReviews'] = "{{ route('admin.risk_management.ajax.reset_risk_reviews') }}";
        URLs['treatmentStart'] = "{{ route('admin.risk_management.ajax.treatment_request.start') }}";
        URLs['treatmentAct'] = "{{ route('admin.risk_management.ajax.treatment_request.act') }}";
        URLs['redoStart'] = "{{ route('admin.risk_management.ajax.redo_assessment.start') }}";
        URLs['redoAct'] = "{{ route('admin.risk_management.ajax.redo_assessment.act') }}";

        const dataFormat = "{{ get_default_date_format() }}";

        $(document).on('click', '.open-treatment-modal', function() {
            const type = $(this).data('type');
            $('#treatment_type_input').val(type);
            $('#treatment_modal_title').text($(this).text());
            $('.treatment-extra').addClass('d-none');
            if (type === 'transfer') $('.transfer-extra').removeClass('d-none');
            if (type === 'avoid' || type === 'accept') $('.accept-extra, .avoid-extra').removeClass('d-none');
            if (type === 'accept') $('.appetite-extra').removeClass('d-none');
            new bootstrap.Modal(document.getElementById('treatmentRequestModal')).show();
        });

        $('#treatment_decision_date').on('change', function() {
            if (!this.value) return;
            const d = new Date(this.value);
            d.setFullYear(d.getFullYear() + 1);
            $('#treatment_reevaluate_date').val(d.toISOString().slice(0, 10));
        });

        $('#treatment-request-form').on('submit', function(e) {
            e.preventDefault();
            $.ajax({
                url: URLs['treatmentStart'],
                type: 'POST',
                data: $(this).serialize(),
                success: function(res) {
                    makeAlert('success', res.message, lang['success']);
                    if (res.reload) location.reload();
                },
                error: function(xhr) {
                    makeAlert('error', (xhr.responseJSON && xhr.responseJSON.message) || lang['error'], lang['error']);
                }
            });
        });

        $(document).on('click', '.act-treatment-btn', function() {
            $.ajax({
                url: URLs['treatmentAct'],
                type: 'POST',
                data: {
                    _token: $('meta[name="csrf-token"]').attr('content'),
                    request_id: $(this).data('id'),
                    decision: $(this).data('decision')
                },
                success: function(res) {
                    makeAlert('success', res.message, lang['success']);
                    if (res.reload) location.reload();
                },
                error: function(xhr) {
                    makeAlert('error', (xhr.responseJSON && xhr.responseJSON.message) || lang['error'], lang['error']);
                }
            });
        });

        $('#redo-assessment-form').on('submit', function(e) {
            e.preventDefault();
            const fd = new FormData(this);
            $.ajax({
                url: URLs['redoStart'],
                type: 'POST',
                data: fd,
                processData: false,
                contentType: false,
                success: function(res) {
                    makeAlert('success', res.message, lang['success']);
                    if (res.reload) location.reload();
                },
                error: function(xhr) {
                    makeAlert('error', (xhr.responseJSON && xhr.responseJSON.message) || lang['error'], lang['error']);
                }
            });
        });

        $(document).on('click', '.act-redo-btn', function() {
            $.ajax({
                url: URLs['redoAct'],
                type: 'POST',
                data: {
                    _token: $('meta[name="csrf-token"]').attr('content'),
                    request_id: $(this).data('id'),
                    decision: $(this).data('decision')
                },
                success: function(res) {
                    makeAlert('success', res.message, lang['success']);
                    if (res.reload) location.reload();
                },
                error: function(xhr) {
                    makeAlert('error', (xhr.responseJSON && xhr.responseJSON.message) || lang['error'], lang['error']);
                }
            });
        });

        // Deep-link: ?treatment=avoid|transfer|accept|redo
        (function() {
            const params = new URLSearchParams(window.location.search);
            const t = params.get('treatment');
            if (!t) return;
            setTimeout(function() {
                if (t === 'redo') {
                    const el = document.getElementById('redoAssessmentModal');
                    if (el) new bootstrap.Modal(el).show();
                } else {
                    $('.open-treatment-modal[data-type="' + t + '"]').trigger('click');
                }
            }, 400);
        })();


        Highcharts.setOptions({
            global: {
                timezone: "{{ get_setting('default_timezone') }}"
            }
        });
        assets['showLoading'] = "{{ asset('SR_images/progress.gif') }}";
    </script>
    <script src="{{ asset('ajax-files/risk_management/edit.js') }}?v={{ filemtime(public_path('ajax-files/risk_management/edit.js')) }}"></script>
    <script>
        document.querySelectorAll('.accordion-button').forEach(button => {
            button.addEventListener('click', function() {
                const icon = this.querySelector('i');
                if (this.classList.contains('collapsed')) {
                    icon.style.transform = "rotate(180deg)";
                } else {
                    icon.style.transform = "rotate(0deg)";
                }
            });
        });
        $('.rt-card.rt-collapsible').each(function() {
            const card = $(this);
            const header = card.children('.rt-card-header').first();
            card.find('.modal').appendTo('body');
            card.children().not(header).wrapAll('<div class="rt-collapse-body"></div>');
            card.children('.rt-collapse-body').hide();
            const actions = header.children().not('.rt-card-title');
            const chevron = $('<i data-feather="chevron-down" class="history-chevron rt-collapse-chevron"></i>');
            actions.length ? actions.last().after(chevron) : header.append(chevron);
        });
        if (window.feather) {
            feather.replace();
        }
        $(document).on('click', '.rt-collapsible > .rt-card-header', function(e) {
            if ($(e.target).closest('button, a, input, select, textarea, label, .dropdown').length) {
                return;
            }
            const card = $(this).closest('.rt-card');
            card.toggleClass('is-open');
            card.children('.rt-collapse-body').stop(true, true).slideToggle(250);
        });
        let editActionPlanIndex = {{ ($data['action_plans'] ?? collect())->count() }};
        function updateEditActionPlanTotals() {
            let l = 0, i = 0;
            $('#edit-mitigation-form .edit-ap-likelihood').each(function(){ l += parseFloat($(this).val()) || 0; });
            $('#edit-mitigation-form .edit-ap-impact').each(function(){ i += parseFloat($(this).val()) || 0; });
            if (l > 100) l = 100;
            if (i > 100) i = 100;
            $('#edit_action_plans_totals').text(l.toFixed(1) + '% / ' + i.toFixed(1) + '%');
        }
        $('#add_edit_action_plan').on('click', function() {
            const i = editActionPlanIndex++;
            $('#edit_action_plans_container').append(`
                <div class="border rounded p-2 mb-2 edit-action-plan-row">
                    <div class="row g-1">
                        <div class="col-md-3"><input class="form-control" name="action_plans[${i}][title]" placeholder="{{ __('risk.ActionTitle') }}"></div>
                        <div class="col-md-3"><input type="number" min="0" max="100" step="0.01" class="form-control edit-ap-likelihood" name="action_plans[${i}][likelihood_reduction]" placeholder="{{ __('risk.LikelihoodReduction') }}" value="0"></div>
                        <div class="col-md-3"><input type="number" min="0" max="100" step="0.01" class="form-control edit-ap-impact" name="action_plans[${i}][impact_reduction]" placeholder="{{ __('risk.ImpactReduction') }}" value="0"></div>
                        <div class="col-md-2"><input type="date" class="form-control" name="action_plans[${i}][due_date]"></div>
                        <div class="col-md-1"><button type="button" class="btn btn-sm btn-outline-danger remove-edit-action-plan">×</button></div>
                    </div>
                </div>`);
            updateEditActionPlanTotals();
        });
        $(document).on('click', '.remove-edit-action-plan', function() {
            $(this).closest('.edit-action-plan-row').remove();
            updateEditActionPlanTotals();
        });
        $(document).on('input', '#edit-mitigation-form .edit-ap-likelihood, #edit-mitigation-form .edit-ap-impact', updateEditActionPlanTotals);
        updateEditActionPlanTotals();

        $(document).on('input', 'input[name="mitigation_percent"]', function() {
            const value = parseInt($(this).val(), 10);
            if (value > 100) {
                $(this).val(100); // Restrict the value to 100
                $('.error-mitigation_percent').text(@json(__('risk.PercentageCannotExceed100')));
            } else {
                $('.error-mitigation_percent').text(''); // Clear error message
            }
        });

        $(document).ready(function() {
            // Trigger the alert for the active tab when the page loads
            var activeTab = $('#pills-tab .active').attr('id'); // Get the ID of the active tab

            // Hide all options by default
            $('#risk-actions option').hide();
            $('#risk-actions .step-default-option').prop('selected', true);

            // Display options based on the active tab
            if (activeTab === "pills-home-tab") { // Show options for Risk Identification
                $('#risk-actions .step-1-option').show();
            }
            if (activeTab === "pills-analysis-tab") {
                $('#risk-actions .step-2-option').show(); // Risk analysis options
            }
            if (activeTab === "pills-evalution-tab") {
                // Show options for Risk Evaluation
                $('#risk-actions .step-3-option').show(); // Reset Mitigations option
            }
            if (activeTab === "pills-review-tab") {
                // Show options for Risk Review
                $('#risk-actions .step-4-option').show(); // Review options
            }

            // Handle tab switching
            $('#pills-tab button').on('shown.bs.tab', function(e) {
                var activeTab = $(e.target).attr('id'); // Get the ID of the active tab
                $('#risk-actions .step-default-option').prop('selected', true);

                // Hide all options by default
                $('#risk-actions option').hide();

                // Display options based on the active tab
                if (activeTab === "pills-home-tab") { // Show options for Risk Identification
                    $('#risk-actions .step-1-option').show();
                }
                if (activeTab === "pills-analysis-tab") {
                    $('#risk-actions .step-2-option').show(); // Risk analysis options
                }
                if (activeTab === "pills-evalution-tab") {
                    // Show options for Risk Evaluation
                    $('#risk-actions .step-3-option').show(); // Reset Mitigations option
                }
                if (activeTab === "pills-review-tab") {
                    // Show options for Risk Review
                    $('#risk-actions .step-4-option').show(); // Review options
                }
            });
        });

        $(document).ready(function() {
            $('.select-affected-asset').on('change', function() {
                var selectedOption = $(this).find('option:selected');
                var rank = selectedOption.data('rank');
                $('#asset_owner_display').val(selectedOption.data('owner-name') || '');
                $('#asset_rank_display').val(rank !== undefined && rank !== '' ? rank : '');
                $('#asset_rank_snapshot').val(rank !== undefined && rank !== '' ? rank : '');
            });

            $('#owner_id').on('change', function() {
                var managerId = String($(this).find('option:selected').data('manager') || '');
                $('#owner_manager_id').val(managerId);
                $('#owner_manager_display').val(managerId).trigger('change.select2');
            });
        });
    </script>

    <!-- end accordion -->
@endsection
