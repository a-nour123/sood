@extends('admin/layouts/contentLayoutMaster')

@section('title', __('locale.Hierarchy'))

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset(mix('fonts/font-awesome/css/font-awesome.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/editors/quill/katex.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/editors/quill/monokai-sublime.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/editors/quill/quill.snow.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/editors/quill/quill.bubble.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/jstree.min.css')) }}">
    <link rel="stylesheet" href="{{ asset('vendors/org/jquery-ui-1.10.4.custom.min.css') }}">
    <link rel="stylesheet" href="{{ asset('vendors/org/jHTree.css') }}">
@endsection

@section('page-style')
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-tree.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-sweet-alerts.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/forms/form-quill-editor.css')) }}">

    <style>
        /* ─── jHTree (sidebar) ─── */
        body { background-color: #fafafa; font-family: 'Cairo', sans-serif; }
        #themes { font-size: 1.2em; }

        .tree li .trcont {
            width: auto; display: inline-block;
            -webkit-border-radius: 5px; -moz-border-radius: 5px;
            box-shadow: none; padding: 15px; border: 1px solid #3333334d;
        }
        #tree { color: white !important; }
        .tree ul { width: max-content; }
        .tree ul .trcont { color: #FFF; }
        .tree { zoom: 100%; }

        .funcbtnb.ui-state-default.ui-corner-all { display: none !important; }
        .funcbtna.ui-state-default.ui-corner-all {
            display: block !important; margin-top: 109px; margin-right: -12px;
            border-radius: 50%; width: 23px; height: 23px;
        }
        .funcbtna.ui-state-default.ui-corner-all.hide-collapse-element { display: none !important; }
        .funcbtna.ui-state-default.ui-corner-all .ui-icon-triangle-1-n { background-position: 3px -14px; }
        .funcbtna.ui-state-default.ui-corner-all .ui-icon-triangle-1-s { background-position: -62px -13px; }
        .trcont .ui-widget-header, .trcont .ui-widget-content { border: 0; color: #FFF; cursor: auto !important; }
        .tree_numbers { display: flex; place-content: space-between; margin-top: 10px; }
        .zomrval { border: 0; color: #33acb9; font-weight: bold; width: 35px; margin-bottom: 7px; }
        .grid-container { display: grid; min-height: 65vh; place-items: center; }

        @foreach ($departments as $department)
            .tree ul li#id_{{ $department['id'] }} .trcont,
            .tree ul li#id_{{ $department['id'] }} .trcont .ui-widget-header,
            .tree ul li#id_{{ $department['id'] }} .trcont .ui-widget-content {
                background: {{ $department['department_color'] }} !important;
            }
        @endforeach

        /* ════════════════════════════════════════
           MODAL — fullscreen container
        ════════════════════════════════════════ */
        #exampleModal .modal-dialog {
            margin: 0;
            max-width: none;
            width: 100%;
            height: 100vh;
        }
        #exampleModal .modal-content {
            height: 100vh;
            border-radius: 0;
            display: flex;
            flex-direction: column;
        }
        #exampleModal .modal-header {
            flex-shrink: 0;
            padding: 10px 16px;
            background: #fff;
            border-bottom: 1px solid #dee2e6;
            gap: 8px;
            flex-wrap: wrap;
            align-items: center;
        }
        #exampleModal .modal-body {
            flex: 1;
            overflow: hidden; /* JS handles panning via transform */
            padding: 0;
            background: #f0f2f5;
            position: relative;
            cursor: grab;
            user-select: none;
        }
        #exampleModal .modal-body.is-panning { cursor: grabbing; }

        /* ── Viewport inside modal-body – transform applied here ── */
        #org-chart-viewport {
            position: absolute;
            top: 0; left: 0;
            width: 100%; height: 100%;
            display: flex;
            align-items: flex-start;
            justify-content: center;
            padding: 30px;
            box-sizing: border-box;
            transform-origin: top center;
            will-change: transform;
            transition: transform 0.05s linear;
        }

        /* ── Custom org chart root ── */
        .org-chart-wrapper {
            font-family: 'Cairo', sans-serif;
            direction: rtl;
            min-width: max-content;
            width: 100%;
            margin: 0 auto;
            position: relative;
            display: inline-block;
            background: #ffffff;
        }

        /* ═══════════════════════════════════════
           TOOLBAR — redesigned, grouped buttons
        ═══════════════════════════════════════ */
        .org-toolbar {
            display: flex;
            align-items: center;
            gap: 6px;
            flex-wrap: wrap;
            flex: 1;
        }
        .org-toolbar-group {
            display: inline-flex;
            align-items: center;
            background: #f4f6fb;
            border: 1px solid #dde3ee;
            border-radius: 8px;
            overflow: hidden;
        }
        .org-toolbar-group .tb-btn {
            background: none;
            border: none;
            border-right: 1px solid #dde3ee;
            padding: 5px 11px;
            font-size: 15px;
            cursor: pointer;
            color: #3a4a6b;
            transition: background 0.15s, color 0.15s;
            display: flex; align-items: center; gap: 5px;
            white-space: nowrap;
            font-family: 'Cairo', sans-serif;
            font-size: 13px;
        }
        .org-toolbar-group .tb-btn:last-child { border-right: none; }
        .org-toolbar-group .tb-btn:hover { background: #e4eaf8; color: #1a2a4a; }
        .org-toolbar-group .tb-btn:active { background: #d0daf4; }
        .org-toolbar-group .tb-btn.active { background: #7367f0; color: #fff; }
        .tb-zoom-label {
            padding: 5px 10px;
            font-size: 12px;
            font-weight: 700;
            color: #3a4a6b;
            min-width: 46px;
            text-align: center;
            font-family: monospace;
        }

        /* ── Search box in toolbar ── */
        .org-search-wrap {
            display: inline-flex;
            align-items: center;
            background: #f4f6fb;
            border: 1px solid #dde3ee;
            border-radius: 8px;
            padding: 0 10px;
            gap: 6px;
        }
        .org-search-wrap input {
            background: none;
            border: none;
            outline: none;
            font-size: 13px;
            font-family: 'Cairo', sans-serif;
            color: #1a2a4a;
            width: 160px;
            padding: 5px 0;
        }
        .org-search-wrap input::placeholder { color: #9aabca; }
        .org-search-icon { font-size: 13px; color: #9aabca; }

        /* Node highlight when searched */
        .org-node.org-highlight {
            outline: 3px solid #f59e0b !important;
            outline-offset: 2px;
            box-shadow: 0 0 0 5px rgba(245,158,11,0.25) !important;
            animation: org-pulse 1s ease-in-out 3;
        }
        @keyframes org-pulse {
            0%,100% { outline-color: #f59e0b; }
            50%      { outline-color: #ef4444; }
        }

        /* Loading state */
        .org-chart-loading {
            text-align: center;
            padding: 80px 40px;
            color: #6c8eae;
            font-size: 1.1rem;
            font-family: 'Cairo', sans-serif;
        }

        /* ════════════════════════════════════════
           ORG CHART NODES — UNCHANGED FROM ORIGINAL
        ════════════════════════════════════════ */
        .org-node {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            border: 1.5px solid #b8c8d8;
            border-radius: 5px;
            background: #ffffff;
            padding: 7px 18px;
            font-size: 0.76rem;
            font-weight: 600;
            color: #22304a;
            white-space: nowrap;
            box-shadow: 0 1px 5px rgba(60,80,120,.10);
            line-height: 1.4;
            position: relative;
            transition: all 0.2s ease;
        }
        .org-node:hover {
            transform: scale(1.02);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 10;
        }
        .org-node--council {
            font-size: 1.25rem; font-weight: 800;
            padding: 13px 70px; border-width: 2px;
            border-color: #8aaac8; min-width: 280px;
        }
        .org-node--president {
            font-size: 1.4rem; font-weight: 800;
            padding: 15px 80px; border-width: 2px;
            border-color: #7a9bbf; min-width: 300px;
        }
        .org-node--office {
            font-size: 0.73rem; font-weight: 600;
            min-width: 135px; max-width: 155px;
            white-space: normal; padding: 8px 11px;
            line-height: 1.4; word-break: break-word;
        }
        .org-node--vp {
            background: #b8cfe8; border-color: #8aaac8;
            font-size: 0.73rem; font-weight: 700;
            color: #172030; min-width: 148px; max-width: 165px;
            white-space: normal; padding: 10px 10px; line-height: 1.35;
            word-break: break-word;
        }
        .org-node--sub {
            background: #ffffff; font-size: 0.66rem; font-weight: 600;
            min-width: 105px; max-width: 128px; white-space: normal;
            padding: 6px 8px; line-height: 1.35; word-break: break-word;
        }
        .org-node--unit {
            background: #ffffff; font-size: 0.70rem; font-weight: 600;
            min-width: 118px; max-width: 148px; white-space: normal;
            padding: 8px 10px; line-height: 1.35; word-break: break-word;
        }

        :root { --conn: #9eafc2; }
        .org-vstem { width: 2px; background: var(--conn); margin: 0 auto; }
        .org-centre { display: flex; flex-direction: column; align-items: center; width: 100%; }
        .org-offices-row { display: flex; align-items: center; justify-content: center; position: relative; width: 100%; flex-wrap: wrap; gap: 10px; }
        .org-offices-row__hline { height: 2px; background: var(--conn); flex: 1; max-width: 130px; }
        .org-vp-row { display: flex; flex-direction: row; align-items: flex-start; justify-content: center; gap: 10px; position: relative; flex-wrap: wrap; }
        .org-vp-col { display: flex; flex-direction: column; align-items: center; padding: 0 9px; position: relative; flex: 0 0 auto; }
        .org-crossbar-svg { position: absolute; top: 0; left: 0; pointer-events: none; overflow: visible; z-index: 5; }
        .org-sub-row--single {
            display: flex;
            justify-content: center;
        }
        .org-sub-branch {
            position: relative;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 8px;
            margin-top: 5px;
        }
        .org-sub-branch::before {
            content: '';
            position: absolute;
            top: -10px;
            bottom: 0;
            left: 50%;
            width: 2px;
            transform: translateX(-50%);
            background: var(--conn);
            z-index: 0;
        }
        .org-sub-branch-row {
            position: relative;
            z-index: 1;
            display: grid;
            grid-template-columns: minmax(110px, max-content) minmax(110px, max-content);
            column-gap: 28px;
            align-items: start;
        }
        .org-sub-branch-row::before {
            content: '';
            position: absolute;
            top: 10px;
            left: 50%;
            width: calc(100% - 36px);
            height: 2px;
            transform: translateX(-50%);
            background: var(--conn);
            z-index: 0;
        }
        .org-sub-branch-row--single {
            grid-template-columns: minmax(110px, max-content);
        }
        .org-sub-branch-row--single::before { display: none; }
        .org-sub-item { display: flex; flex-direction: column; align-items: center; flex: 0 0 auto; position: relative; z-index: 1; }
        .org-units-row { display: flex; flex-direction: row; flex-wrap: wrap; justify-content: center; gap: 15px; padding-top: 22px; margin-top: 32px; border-top: 2px solid var(--conn); max-width: 100%; }
    </style>
@endsection

@section('content')
<div class="content-header row">
    <div class="content-header-left col-12 mb-2">
        <div class="row breadcrumbs-top widget-grid">
            <div class="col-12">
                <div class="page-title mt-2">
                    <div class="row">
                        <div class="col-sm-12 ps-0">
                            @if (@isset($breadcrumbs))
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="{{ route('admin.dashboard') }}" style="display:flex;">
                                            <svg class="stroke-icon">
                                                <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}"></use>
                                            </svg>
                                        </a>
                                    </li>
                                    @foreach ($breadcrumbs as $breadcrumb)
                                        <li class="breadcrumb-item">
                                            @if (isset($breadcrumb['link']))
                                                <a href="{{ $breadcrumb['link'] == 'javascript:void(0)' ? $breadcrumb['link'] : url($breadcrumb['link']) }}">
                                            @endif
                                            {{ $breadcrumb['name'] }}
                                            @if (isset($breadcrumb['link']))</a>@endif
                                        </li>
                                    @endforeach
                                </ol>
                            @endisset
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="event_result"></div>

<section class="context-drag-drop-tree">
    <div class="row">
        <div class="col-12 col-md-6">
            <div>
                <div class="card mb-0">
                    <div class="card-header">
                        <h4 class="card-title">{{ __('hierarchy.Hierarchy') }}</h4>
                    </div>
                    <div class="card-body">
                        <div id="jstree-ajax"></div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-6" style="display:none" id="department-details">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">{{ __('hierarchy.Department') . ' ' . __('locale.Details') }}</h4>
                    </div>
                    <div class="card-body">
                        <div style="padding-bottom:10px;"><h5 class="d-inline">{{ __('locale.Name') }}:</h5><div id="department-data-name" class="d-inline-block p-0"></div></div>
                        <div style="padding-bottom:10px;"><h5 class="d-inline">{{ __('locale.Code') }}:</h5><div id="department-data-code" class="d-inline-block p-0"></div></div>
                        <div style="padding-bottom:10px;">
                            <h5 class="d-inline">{{ __('hierarchy.DepartmentColor') }}:</h5>
                            <div id="department-data-color" class="d-inline-block text-center rounded p-0"></div>
                        </div>
                        <div style="padding-bottom:10px;"><h5 class="d-inline">{{ __('hierarchy.Manager') }}:</h5><div id="department-data-manager" class="d-inline-block p-0"></div></div>
                        <div style="padding-bottom:10px;"><h5 class="d-inline">{{ __('hierarchy.ParentDepartment') }}:</h5><div id="department-data-parent" class="d-inline-block p-0"></div></div>
                        <div style="padding-bottom:10px;"><h5 class="d-inline">{{ __('locale.RequiredNumberOfEmplyees') }}:</h5><div id="department-data-required-num-employee" class="d-inline-block p-0"></div></div>
                        <div style="padding-bottom:10px;"><h5 class="d-inline">{{ __('locale.ActualNumberOfEmplyees') }}:</h5><div id="department-data-actual-num-employee" class="d-inline-block p-0"></div></div>
                        <div><h5>{{ __('hierarchy.vision') }}:</h5><div id="department-data-vision" class="ql-editor"></div></div>
                        <div><h5>{{ __('hierarchy.message') }}:</h5><div id="department-data-message" class="ql-editor"></div></div>
                        <div><h5>{{ __('hierarchy.mission') }}:</h5><div id="department-data-mission" class="ql-editor"></div></div>
                        <div><h5>{{ __('hierarchy.objectives') }}:</h5><div id="department-data-objectives" class="ql-editor"></div></div>
                        <div><h5>{{ __('hierarchy.responsibilities') }}:</h5><div id="department-data-responsibilities" class="ql-editor"></div></div>
                        <div><h5 class="d-inline">{{ __('locale.CreatedDate') }}:</h5><div class="d-inline-block" id="department-data-created-at"></div></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-6">
            <div class="grid-container">
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                    {{ __('locale.Organization Chart') }}
                </button>
            </div>
        </div>
    </div>

    <!-- ════════════════════════════════════════
         FULLSCREEN ORG CHART MODAL
    ════════════════════════════════════════ -->
    <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
         aria-labelledby="exampleModalLabel" aria-hidden="true" id="exampleModal">
        <div class="modal-dialog modal-fullscreen position-relative">
            <div class="modal-content">

                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel" style="font-family:'Cairo',sans-serif;font-size:15px;margin-left:8px;">
                        {{ __('locale.Organization Tree') }}
                    </h5>

                    <!-- ── TOOLBAR ── -->
                    <div class="org-toolbar">

                        <!-- Zoom group -->
                        <div class="org-toolbar-group">
                            <button class="tb-btn" id="zoom-out-btn" title="تصغير (-)">−</button>
                            <span class="tb-zoom-label" id="zoom-level">100%</span>
                            <button class="tb-btn" id="zoom-in-btn" title="تكبير (+)">+</button>
                            <button class="tb-btn" id="zoom-reset-btn" title="100%">↺</button>
                        </div>

                        <!-- Fit / Fullscreen group -->
                        <div class="org-toolbar-group">
                            <button class="tb-btn" id="fit-screen-btn" title="ملاءمة الشاشة">
                                <i class="fa fa-expand" style="font-size:12px;"></i> ملاءمة
                            </button>
                            <button class="tb-btn" id="fullscreen-btn" title="شاشة كاملة">
                                <i class="fa fa-arrows-alt" style="font-size:12px;"></i> تكبير
                            </button>
                        </div>

                        <!-- Search -->
                        <div class="org-search-wrap">
                            <span class="org-search-icon">🔍</span>
                            <input type="text" id="org-search-input" placeholder="بحث عن قسم..." autocomplete="off">
                        </div>

                        <!-- Reset pan hint -->
                        <div class="org-toolbar-group" style="opacity:.65;">
                            <button class="tb-btn" id="center-chart-btn" title="توسيط الشاشة">
                                <i class="fa fa-crosshairs" style="font-size:12px;"></i> توسيط
                            </button>
                        </div>
                    </div>

                    <button type="button" class="btn-close ms-2" data-bs-dismiss="modal" aria-label="{{ __('locale.Close') }}"></button>
                </div>

                <!-- modal-body: pan & zoom happens on #org-chart-viewport inside -->
                <div class="modal-body" id="org-modal-body">
                    <div id="org-chart-viewport">
                        <div id="org-chart-root" class="org-chart-wrapper">
                            <div class="org-chart-loading">
                                <i class="fa fa-spinner fa-spin fa-2x"></i>
                                <p>جاري تحميل الهيكل التنظيمي...</p>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>

<div id="quill-content" class="d-none"></div>
@endsection


@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/editors/quill/katex.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/editors/quill/quill.min.js')) }}"></script>
@endsection


@section('page-script')
    <script src="{{ asset('vendors/org/jquery-1.10.2.js') }}"></script>
    <script src="{{ asset('cdn/html2canvas.js') }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/jstree.min.js')) }}"></script>
    <script src="{{ asset('cdn/jspdf.min.js') }}"></script>
    <script src="{{ asset('vendors/org/jquery-ui-1.10.4.custom.min.js') }}"></script>
    <script src="{{ asset('vendors/org/jQuery.jHTree.js') }}"></script>

    {{-- ══════════════════════════════════════════
         1.  jHTree sidebar (unchanged)
    ══════════════════════════════════════════ --}}
    <script>
        var tree = null;

        function ShowModalEditJob() {
            var url = "{{ route('admin.hierarchy.get_org_chart') }}";
            $.ajax({
                url: url,
                type: "GET",
                headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                success: function (response) {
                    tree = generateDepartmentTree(response);
                    $("#tree").jHTree({ callType: 'obj', structureObj: tree });
                    $('.no-children').each(function () {
                        var className = $(this).attr('class');
                        var matches   = className.match(/id_\d+/);
                        if (matches) { $('#' + matches[0] + ' .after .funcbtna').addClass('hide-collapse-element'); }
                    });
                    renderOrgChart(response);
                },
                error: function (response) {
                    var responseData = response.responseJSON;
                    makeAlert('error', responseData.message, "{{ __('locale.Error') }}");
                    document.getElementById('org-chart-root').innerHTML = '<div class="org-chart-loading" style="color:red;">خطأ في تحميل البيانات</div>';
                }
            });
        }
        ShowModalEditJob();

        function generateDepartmentTree(departments, parentId) {
            parentId = parentId === undefined ? null : parentId;
            var treeArr = [];
            departments.forEach(function (department) {
                if (department.pid === parentId) {
                    var child = {
                        head: department.Name,
                        id: 'id_' + department.id,
                        contents: department.Manager +
                            '<br><div class="tree_numbers"><span>' +
                            ($.isNumeric(department.RequiredNumber) ? department.RequiredNumber : '') +
                            '</span><span>  ' + department.ActualNumber + '</span></div>'
                    };
                    var children = generateDepartmentTree(departments, department.id);
                    if (children.length > 0) {
                        child.children = children;
                    } else {
                        child.contents += '<span class="no-children id_' + department.id + '"></span>';
                    }
                    treeArr.push(child);
                }
            });
            return treeArr;
        }

        /* PDF export (unchanged) */
        $(document).ready(function () {
            $('.export-pdf-btn').click(function () {
                var filename  = $(this).data('filename');
                var treeWidth = $('#tremainul').width();
                getScreenshotOfElement(
                    $("div#tree").get(0), 0, 0,
                    treeWidth + 45, $("#tree").height() + 30,
                    function (data) {
                        var pdf = new jsPDF("l", "pt", [treeWidth, $("#tree").height()]);
                        pdf.addImage("data:image/png;base64," + data, "PNG", 0, 0, treeWidth, $("#tree").height());
                        pdf.save(filename + ".pdf");
                    }
                );
            });

            function getScreenshotOfElement(element, posX, posY, width, height, callback) {
                html2canvas(element, {
                    onrendered: function (canvas) {
                        var context = canvas.getContext("2d");
                        var imageData = context.getImageData(posX, posY, width, height).data;
                        var outputCanvas = document.createElement("canvas");
                        outputCanvas.width  = width;
                        outputCanvas.height = height;
                        var outputContext = outputCanvas.getContext("2d");
                        var idata = outputContext.createImageData(width, height);
                        idata.data.set(imageData);
                        outputContext.putImageData(idata, 0, 0);
                        callback(outputCanvas.toDataURL().replace("data:image/png;base64,", ""));
                    },
                    width: width, height: height, useCORS: true,
                    taintTest: false, allowTaint: false, letterRendering: true
                });
            }
        });
    </script>

    {{-- ══════════════════════════════════════════
         2.  Custom Org Chart Renderer (tree build logic — UNCHANGED)
    ══════════════════════════════════════════ --}}
    <script>
    function renderOrgChart(departments) {
        var root = document.getElementById('org-chart-root');
        if (!root) return;
        root.innerHTML = '<div class="org-chart-loading"><i class="fa fa-spinner fa-spin fa-2x"></i><p>جاري بناء الهيكل التنظيمي...</p></div>';
        setTimeout(function() { buildOrgChart(departments); }, 100);
    }

    function buildOrgChart(departments) {
        var root = document.getElementById('org-chart-root');
        if (!root) return;
        root.innerHTML = '';

        function el(tag, cls, text) {
            var e = document.createElement(tag);
            if (cls)  e.className = cls;
            if (text) e.textContent = text;
            return e;
        }
        function vstem(h) {
            var d = el('div', 'org-vstem');
            d.style.height = h + 'px';
            return d;
        }
        function hline(w) {
            var d = el('div');
            d.style.cssText = 'height:2px;background:var(--conn);width:' + (w || 90) + 'px;';
            return d;
        }

        var byId  = {};
        var byPid = {};
        departments.forEach(function (d) {
            byId[d.id]  = d;
            var pid = (d.pid === null || d.pid === undefined || d.pid === '') ? '__root__' : d.pid;
            if (!byPid[pid]) byPid[pid] = [];
            byPid[pid].push(d);
        });

        var roots = byPid['__root__'] || byPid[null] || byPid['0'] || [];

        function shadeColor(hex, pct) {
            if (!hex || hex === '#') return '#b8cfe8';
            var num = parseInt(hex.replace('#',''), 16);
            var r = Math.min(255, Math.max(0, (num >> 16) + pct));
            var g = Math.min(255, Math.max(0, ((num >> 8) & 0x00FF) + pct));
            var b = Math.min(255, Math.max(0, (num & 0x0000FF) + pct));
            return '#' + ((1 << 24) | (r << 16) | (g << 8) | b).toString(16).slice(1);
        }
        function getContrastColor(hex) {
            if (!hex || hex === '#') return '#22304a';
            var r = parseInt(hex.slice(1,3), 16);
            var g = parseInt(hex.slice(3,5), 16);
            var b = parseInt(hex.slice(5,7), 16);
            var brightness = (r * 299 + g * 587 + b * 114) / 1000;
            return brightness > 125 ? '#172030' : '#ffffff';
        }

        function nodeBox(dept, extraClass) {
            var box = el('div', 'org-node ' + (extraClass || ''));
            box.textContent = dept.Name;
            box.setAttribute('data-dept-name', dept.Name);
            if (dept.department_color) {
                box.style.backgroundColor = dept.department_color;
                box.style.color = getContrastColor(dept.department_color);
                box.style.borderColor = shadeColor(dept.department_color, -25);
            }
            return box;
        }

        function subItem(dept) {
            var wrap = el('div', 'org-sub-item');
            wrap.appendChild(vstem(16));
            wrap.appendChild(nodeBox(dept, 'org-node org-node--sub'));
            var kids = byPid[dept.id];
            if (kids && kids.length) {
                wrap.appendChild(vstem(10));
                wrap.appendChild(buildSubTree(kids));
            }
            return wrap;
        }

        function buildSubTree(kids) {
            if (!kids || kids.length === 0) return el('div');
            if (kids.length === 1) {
                var single = el('div', 'org-sub-row--single');
                single.appendChild(subItem(kids[0]));
                return single;
            }

            var branch = el('div', 'org-sub-branch');
            for (var i = 0; i < kids.length; i += 2) {
                var rowKids = kids.slice(i, i + 2);
                var row = el('div', 'org-sub-branch-row' + (rowKids.length === 1 ? ' org-sub-branch-row--single' : ''));
                rowKids.forEach(function (k) { row.appendChild(subItem(k)); });
                branch.appendChild(row);
            }
            return branch;
        }

        var centre = el('div', 'org-centre');
        root.appendChild(centre);

        if (roots.length === 0) {
            root.innerHTML = '<p style="text-align:center;padding:40px;color:#888;">لا توجد بيانات</p>';
            return;
        }

        var topNode = roots[0];
        centre.appendChild(nodeBox(topNode, 'org-node org-node--council'));
        centre.appendChild(vstem(26));

        var topKids = byPid[topNode.id] || [];
        if (topKids.length === 0) return;

        var presNode = topKids[0];
        centre.appendChild(nodeBox(presNode, 'org-node org-node--president'));

        var presKids = byPid[presNode.id] || [];
        var sideOffices  = [];
        var mainChildren = [];
        presKids.forEach(function (d) {
            var hasKids = byPid[d.id] && byPid[d.id].length > 0;
            if (!hasKids) { sideOffices.push(d); }
            else          { mainChildren.push(d); }
        });

        if (sideOffices.length > 0) {
            var officeRow = el('div', 'org-offices-row');
            officeRow.style.cssText = 'display:flex;align-items:center;justify-content:center;position:relative;width:100%;margin:0;flex-wrap:wrap;';
            var midPoint = Math.ceil(sideOffices.length / 2);
            var leftOffices  = sideOffices.slice(0, midPoint);
            var rightOffices = sideOffices.slice(midPoint);

            function buildOfficeGroup(offices) {
                if (!offices.length) return null;
                var group = el('div');
                group.style.cssText = 'display:flex;align-items:center;flex-wrap:wrap;justify-content:center;gap:8px;';
                offices.forEach(function (d, idx) {
                    group.appendChild(nodeBox(d, 'org-node org-node--office'));
                    if (idx < offices.length - 1) group.appendChild(hline(40));
                });
                return group;
            }

            var rightGroup = buildOfficeGroup(rightOffices);
            var leftGroup  = buildOfficeGroup(leftOffices);
            if (rightGroup) officeRow.appendChild(rightGroup);
            var centreVert = el('div');
            centreVert.style.cssText = 'width:2px;height:50px;background:var(--conn);flex-shrink:0;margin:0 15px;';
            officeRow.appendChild(centreVert);
            if (leftGroup) officeRow.appendChild(leftGroup);
            centre.appendChild(officeRow);
        } else {
            centre.appendChild(vstem(30));
        }

        if (mainChildren.length === 0) return;

        var vpContainer = el('div');
        vpContainer.style.cssText = 'position:relative;display:flex;flex-direction:column;align-items:center;width:100%;';
        centre.appendChild(vpContainer);

        var vpRow = el('div', 'org-vp-row');
        vpContainer.appendChild(vpRow);

        mainChildren.forEach(function (vp) {
            var col = el('div', 'org-vp-col');
            col.setAttribute('data-vp-id', vp.id);
            col.appendChild(vstem(22));
            var vpBox = nodeBox(vp, 'org-node org-node--vp');
            col.appendChild(vpBox);
            var vpKids = byPid[vp.id] || [];
            if (vpKids.length > 0) {
                col.appendChild(vstem(16));
                col.appendChild(buildSubTree(vpKids));
            }
            vpRow.appendChild(col);
        });

        requestAnimationFrame(function () { drawCrossbar(vpContainer, vpRow); });

        var topPeers = (byPid[topNode.id] || []).filter(function (d) { return d.id !== presNode.id; });
        if (topPeers.length > 0) {
            var unitRow = el('div', 'org-units-row');
            topPeers.forEach(function (u) { unitRow.appendChild(nodeBox(u, 'org-node org-node--unit')); });
            centre.appendChild(unitRow);
        }

        /* Init toolbar features after chart builds */
        initModalFeatures();
    }

    /* Draw horizontal crossbar SVG */
    function drawCrossbar(container, vpRow) {
        var old = container.querySelector('.org-crossbar-svg');
        if (old) old.parentNode.removeChild(old);
        var cols = vpRow.querySelectorAll('.org-vp-col');
        if (cols.length < 2) return;
        var containerRect = container.getBoundingClientRect();
        var points = [];
        cols.forEach(function (col) {
            var r = col.getBoundingClientRect();
            points.push({ cx: r.left + r.width / 2 - containerRect.left, stemTop: r.top - containerRect.top });
        });
        var y  = points[0].stemTop + 1;
        var x1 = Math.min.apply(null, points.map(function(p){return p.cx;}));
        var x2 = Math.max.apply(null, points.map(function(p){return p.cx;}));
        var h  = container.offsetHeight;
        var w  = container.offsetWidth;
        var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('class', 'org-crossbar-svg');
        svg.style.cssText = 'position:absolute;top:0;left:0;width:'+w+'px;height:'+h+'px;pointer-events:none;overflow:visible;z-index:5;';
        var bar = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        bar.setAttribute('x1', x1); bar.setAttribute('y1', y);
        bar.setAttribute('x2', x2); bar.setAttribute('y2', y);
        bar.setAttribute('stroke', '#9eafc2'); bar.setAttribute('stroke-width', '2');
        svg.appendChild(bar);
        points.forEach(function(p){
            var tick = document.createElementNS('http://www.w3.org/2000/svg', 'line');
            tick.setAttribute('x1', p.cx); tick.setAttribute('y1', y);
            tick.setAttribute('x2', p.cx); tick.setAttribute('y2', y+22);
            tick.setAttribute('stroke', '#9eafc2'); tick.setAttribute('stroke-width', '2');
            svg.appendChild(tick);
        });
        container.appendChild(svg);
    }
    </script>

    {{-- ══════════════════════════════════════════
         3.  Modal Interaction Features
             - Zoom (buttons, wheel, keyboard)
             - Drag-to-pan
             - Fit to screen
             - Fullscreen toggle
             - Export PNG
             - Node search / highlight
             - Center chart
    ══════════════════════════════════════════ --}}
    <script>
    (function () {
        /* ── State ── */
        var currentZoom = 1;
        var panX = 0, panY = 0;
        var MIN_ZOOM = 0.2, MAX_ZOOM = 3, ZOOM_STEP = 0.1;
        var isPanning = false, panStartX = 0, panStartY = 0, panStartPanX = 0, panStartPanY = 0;
        var isFullscreen = false;
        var chartReady = false;

        /* ── DOM refs (populated on first modal open) ── */
        var viewport, modalBody, chartRoot, zoomLabel;

        function getEls() {
            viewport  = document.getElementById('org-chart-viewport');
            modalBody = document.getElementById('org-modal-body');
            chartRoot = document.getElementById('org-chart-root');
            zoomLabel = document.getElementById('zoom-level');
        }

        /* ── Apply current transform ── */
        function applyTransform(animate) {
            if (!viewport) return;
            viewport.style.transition = animate ? 'transform 0.25s ease' : 'none';
            viewport.style.transform  = 'translate(' + panX + 'px, ' + panY + 'px) scale(' + currentZoom + ')';
            if (zoomLabel) zoomLabel.textContent = Math.round(currentZoom * 100) + '%';
        }

        /* ── Zoom around a point (px coords in modalBody) ── */
        function zoomAt(factor, cx, cy) {
            var newZoom = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, currentZoom * factor));
            if (newZoom === currentZoom) return;
            /* Adjust pan so zoom feels anchored at (cx, cy) */
            var ratio = newZoom / currentZoom;
            panX = cx + ratio * (panX - cx);
            panY = cy + ratio * (panY - cy);
            currentZoom = newZoom;
            applyTransform(false);
        }

        /* ── Center the chart in the viewport ── */
        function centerChart(animate) {
            panX = 0; panY = 0;
            applyTransform(animate !== false);
        }

        /* ── Fit chart to screen ── */
        function fitToScreen() {
            if (!modalBody || !chartRoot) return;
            var bw = modalBody.clientWidth  - 60;
            var bh = modalBody.clientHeight - 60;
            var cw = chartRoot.scrollWidth;
            var ch = chartRoot.scrollHeight;
            var scale = Math.min(bw / cw, bh / ch, 1);
            scale = Math.max(MIN_ZOOM, scale);
            currentZoom = parseFloat(scale.toFixed(2));
            panX = 0; panY = 0;
            applyTransform(true);
        }

        /* ── Fullscreen toggle ── */
        function toggleFullscreen() {
            var modal = document.getElementById('exampleModal');
            if (!modal) return;
            if (!document.fullscreenElement) {
                modal.requestFullscreen && modal.requestFullscreen();
                isFullscreen = true;
                document.getElementById('fullscreen-btn').innerHTML = '<i class="fa fa-compress" style="font-size:12px;"></i> خروج';
            } else {
                document.exitFullscreen && document.exitFullscreen();
                isFullscreen = false;
                document.getElementById('fullscreen-btn').innerHTML = '<i class="fa fa-arrows-alt" style="font-size:12px;"></i> تكبير';
            }
        }

        /* ── Search & Highlight ── */
        var searchTimeout;
        function doSearch(term) {
            var nodes = document.querySelectorAll('#org-chart-root .org-node');
            nodes.forEach(function(n){ n.classList.remove('org-highlight'); });
            if (!term || term.trim() === '') return;
            var q = term.trim().toLowerCase();
            var found = [];
            nodes.forEach(function(n){
                var name = (n.getAttribute('data-dept-name') || n.textContent || '').toLowerCase();
                if (name.indexOf(q) !== -1) {
                    n.classList.add('org-highlight');
                    found.push(n);
                }
            });
            /* Scroll first match into view */
            if (found.length > 0) {
                found[0].scrollIntoView({ behavior:'smooth', block:'center', inline:'center' });
            }
        }

        /* ── Drag-to-pan ── */
        function onMouseDown(e) {
            if (e.button !== 0) return;
            isPanning = true;
            panStartX  = e.clientX;
            panStartY  = e.clientY;
            panStartPanX = panX;
            panStartPanY = panY;
            modalBody.classList.add('is-panning');
        }
        function onMouseMove(e) {
            if (!isPanning) return;
            panX = panStartPanX + (e.clientX - panStartX);
            panY = panStartPanY + (e.clientY - panStartY);
            applyTransform(false);
        }
        function onMouseUp() {
            isPanning = false;
            if (modalBody) modalBody.classList.remove('is-panning');
        }

        /* Touch pan support */
        var touchStartX = 0, touchStartY = 0, touchStartPanX = 0, touchStartPanY = 0;
        var pinchStartDist = 0, pinchStartZoom = 1;

        function onTouchStart(e) {
            if (e.touches.length === 1) {
                touchStartX = e.touches[0].clientX;
                touchStartY = e.touches[0].clientY;
                touchStartPanX = panX;
                touchStartPanY = panY;
            } else if (e.touches.length === 2) {
                pinchStartDist = Math.hypot(
                    e.touches[1].clientX - e.touches[0].clientX,
                    e.touches[1].clientY - e.touches[0].clientY
                );
                pinchStartZoom = currentZoom;
            }
        }
        function onTouchMove(e) {
            e.preventDefault();
            if (e.touches.length === 1) {
                panX = touchStartPanX + (e.touches[0].clientX - touchStartX);
                panY = touchStartPanY + (e.touches[0].clientY - touchStartY);
                applyTransform(false);
            } else if (e.touches.length === 2) {
                var dist = Math.hypot(
                    e.touches[1].clientX - e.touches[0].clientX,
                    e.touches[1].clientY - e.touches[0].clientY
                );
                currentZoom = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, pinchStartZoom * (dist / pinchStartDist)));
                applyTransform(false);
            }
        }

        /* ── Wheel zoom ── */
        function onWheel(e) {
            e.preventDefault();
            var rect = modalBody.getBoundingClientRect();
            var cx = e.clientX - rect.left;
            var cy = e.clientY - rect.top;
            var factor = e.deltaY < 0 ? (1 + ZOOM_STEP) : (1 - ZOOM_STEP);
            zoomAt(factor, cx, cy);
        }

        /* ── Keyboard shortcuts ── */
        function onKeyDown(e) {
            var modal = document.getElementById('exampleModal');
            if (!modal || !modal.classList.contains('show')) return;
            /* Only when not focused on input */
            if (document.activeElement && document.activeElement.tagName === 'INPUT') return;
            switch(e.key) {
                case '+': case '=':
                    currentZoom = Math.min(MAX_ZOOM, currentZoom + ZOOM_STEP);
                    applyTransform(true); break;
                case '-':
                    currentZoom = Math.max(MIN_ZOOM, currentZoom - ZOOM_STEP);
                    applyTransform(true); break;
                case '0':
                    currentZoom = 1; panX = 0; panY = 0;
                    applyTransform(true); break;
                case 'f': case 'F':
                    fitToScreen(); break;
                case 'ArrowLeft':  panX += 60; applyTransform(false); break;
                case 'ArrowRight': panX -= 60; applyTransform(false); break;
                case 'ArrowUp':    panY += 60; applyTransform(false); break;
                case 'ArrowDown':  panY -= 60; applyTransform(false); break;
            }
        }

        /* ════════════════════════
           INIT — called after chart renders
        ════════════════════════ */
        function initModalFeatures() {
            getEls();
            if (chartReady) return;   /* avoid double-binding */
            chartReady = true;

            /* ── Zoom buttons ── */
            document.getElementById('zoom-in-btn').onclick = function() {
                currentZoom = Math.min(MAX_ZOOM, currentZoom + ZOOM_STEP);
                applyTransform(true);
            };
            document.getElementById('zoom-out-btn').onclick = function() {
                currentZoom = Math.max(MIN_ZOOM, currentZoom - ZOOM_STEP);
                applyTransform(true);
            };
            document.getElementById('zoom-reset-btn').onclick = function() {
                currentZoom = 1; panX = 0; panY = 0;
                applyTransform(true);
            };

            /* ── Fit / Fullscreen / Center ── */
            document.getElementById('fit-screen-btn').onclick  = fitToScreen;
            document.getElementById('fullscreen-btn').onclick  = toggleFullscreen;
            document.getElementById('center-chart-btn').onclick = function() { centerChart(true); };

            /* ── Search ── */
            var searchInput = document.getElementById('org-search-input');
            if (searchInput) {
                searchInput.addEventListener('input', function() {
                    clearTimeout(searchTimeout);
                    var term = this.value;
                    searchTimeout = setTimeout(function(){ doSearch(term); }, 300);
                });
                searchInput.addEventListener('keydown', function(e) {
                    if (e.key === 'Escape') { this.value = ''; doSearch(''); }
                });
            }

            /* ── Pan events (mouse) ── */
            if (modalBody) {
                modalBody.addEventListener('mousedown', onMouseDown);
                modalBody.addEventListener('touchstart', onTouchStart, { passive: true });
                modalBody.addEventListener('touchmove',  onTouchMove,  { passive: false });
                modalBody.addEventListener('wheel', onWheel, { passive: false });
            }
            document.addEventListener('mousemove', onMouseMove);
            document.addEventListener('mouseup',   onMouseUp);
            document.addEventListener('keydown',   onKeyDown);
        }

        /* ── Modal open/close events ── */
        document.addEventListener('DOMContentLoaded', function () {
            var modal = document.getElementById('exampleModal');
            if (!modal) return;

            modal.addEventListener('shown.bs.modal', function () {
                getEls();
                /* Reset pan & zoom on each open */
                currentZoom = 1; panX = 0; panY = 0;
                applyTransform(false);

                /* Redraw crossbar in case of resize */
                setTimeout(function() {
                    var container = document.querySelector('#org-chart-root .org-centre > div[style*="position:relative"]');
                    if (container) {
                        var vpRow = container.querySelector('.org-vp-row');
                        if (vpRow) drawCrossbar(container, vpRow);
                    }
                }, 120);
            });

            modal.addEventListener('hidden.bs.modal', function () {
                /* Clear search on close */
                var si = document.getElementById('org-search-input');
                if (si) { si.value = ''; doSearch(''); }
                if (document.fullscreenElement) document.exitFullscreen();
            });

            window.addEventListener('resize', function() {
                if (!modal.classList.contains('show')) return;
                setTimeout(function() {
                    var container = document.querySelector('#org-chart-root .org-centre > div[style*="position:relative"]');
                    if (container) {
                        var vpRow = container.querySelector('.org-vp-row');
                        if (vpRow) drawCrossbar(container, vpRow);
                    }
                }, 200);
            });
        });

        /* expose so buildOrgChart can call it */
        window.initModalFeatures = initModalFeatures;
    })();
    </script>

    <script>
        const error  = "{{ __('locale.Error') }}",
              success = "{{ __('locale.Success') }}",
              thisIsNotDraggable = "{{ __('locale.ThisIsNotDraggable') }}",
              url       = "{{ route('admin.hierarchy.ajax.index') }}",
              updateUrl = "{{ route('admin.hierarchy.ajax.drag_and_drop') }}",
              getDepartmentURL = "{{ route('admin.hierarchy.department.ajax.show', ':id') }}";

        const quill = new Quill('#quill-content', { theme: 'bubble' });
    </script>

    <script src="{{ asset('ajax-files/hierarchy/index.js') }}"></script>
    <script src="{{ asset(mix('js/scripts/forms/form-select2.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
@endsection