<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>{{ __('configure.Document') }}</title>
</head>
<body>
    <form method="post" action="{{ route('admin.configure.storename') }}">
        @csrf
        <div class="form-group">
          <label for="exampleInputEmail1">{{ __('locale.Name') }}</label>
          <input type="text" class="form-control" name="name" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="{{ __('configure.EnterEmail') }}">
          <small id="emailHelp" class="form-text text-muted">{{ __('configure.EmailPrivacyNote') }}</small>
        </div>
        <button type="submit" class="btn btn-primary">{{ __('locale.Submit') }}</button>
      </form>
</body>
</html>
