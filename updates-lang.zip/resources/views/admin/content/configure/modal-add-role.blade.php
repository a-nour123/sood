<!-- Add Role Modal -->
<div class="modal fade" id="addRoleModal" tabindex="-1" aria-hidden="true" data-type="create">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-add-new-role">
        <div class="modal-content">
            <div class="modal-header bg-transparent">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="{{ __('locale.Close') }}"></button>
            </div>
            <div class="modal-body px-5 pb-5">
                <div class="text-center mb-4">
                    <h1 class="role-title">{{ __('locale.AddNewRole') }}</h1>
                    <p>{{ __('locale.SetRolePermissions') }}</p>
                </div>
                <!-- Add role form -->
                <form id="addRoleForm" class="row" method="post"
                    action="{{ route('admin.configure.roles.role.store') }}">
                    @csrf
                    <div class="col-12">
                        <label class="form-label" for="modalRoleName">{{ __('locale.RoleName') }}</label>
                        <input type="text" id="modalRoleName" name="name" class="form-control"
                            placeholder="{{ __('locale.EnterRoleName') }}" tabindex="-1" data-msg="{{ __('locale.PleaseEnterRoleName') }}" />
                    </div>
                    <div class="col-12">
                        <h4 class="mt-2 pt-50">{{ __('locale.RolePermissions') }}</h4>
                        <div class="form-check">
                            <input class="form-check-input selectAllpermissionGroup" type="checkbox" />
                            <label class="form-check-label" for="selectAll"> {{ __('locale.SelectAll') }} </label>
                        </div>
                        <!-- Permission table -->
                        <div class="table-responsive">
                            <table class="table table-flush-spacing">
                                <tbody>
                                    @foreach ($permissions_group as $groups)
                                        {{--  @if (in_array($groups->id, [5]))
                                            @continue
                                        @endif  --}}
                                        <tr>
                                            <td class="text-nowrap fw-bolder">
                                                {{ $groups->name }}
                                                <span data-bs-toggle="tooltip" data-bs-placement="top"
                                                    title="{{ __('configure.FullAccessHint') }}">
                                                    <i data-feather="info"></i>
                                                </span>
                                            </td>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input selectAllPermission" type="checkbox"
                                                        data-id="{{ $groups->id }}" />
                                                    <label class="form-check-label" for="selectAll"> {{ __('locale.SelectAll') }} </label>
                                                </div>
                                            </td>
                                        </tr>


                                        {{-- <tr style="padding: 5px 0;">
                                            {{ $groups->name }} <i data-feather="info"></i>
                                        </tr> --}}
                                        @foreach ($groups->subgroups as $subgroup)
                                        {{-- nuglect Tests and Compliance --}}
                                            {{--  @if (in_array($subgroup->id, [4, 6, 7, 8, 11, 18]))
                                                @continue
                                            @endif  --}}
                                            <tr>
                                                <td class="text-nowrap fw-bolder" style="padding: 5px 0px 5px 20px">
                                                    {{ $subgroup->name }}
                                                    <input type="hidden" value="{{ $subgroup->id }}">
                                                </td>
                                                <td>
                                                    <div class="d-flex flex-wrap">
                                                        @foreach ($subgroup->permissions as $permission)
                                                            <div class="form-check me-2 me-lg-5" style="width: 18%;">
                                                                <input
                                                                    class="form-check-input checkboxType-{{ $groups->id }}"
                                                                    type="checkbox" name="keys[]"
                                                                    value="{{ $permission->id }}" />
                                                                <label class="form-check-label">
                                                                    {{ $permission->name }}
                                                                </label>
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach
                                    @endforeach


                                </tbody>
                            </table>
                        </div>
                        <!-- Permission table -->
                    </div>
                    <div class="col-12 text-center mt-2">
                        <button type="submit" class="btn btn-primary me-1">{{ __('locale.Submit') }}</button>
                        <button type="reset" class="btn btn-outline-secondary" data-bs-dismiss="modal"
                            aria-label="{{ __('locale.Close') }}">
                            {{ __('locale.Discard') }}
                        </button>
                    </div>
                </form>
                <!--/ Add role form -->
            </div>
        </div>
    </div>
</div>
<!--/ Add Role Modal -->
