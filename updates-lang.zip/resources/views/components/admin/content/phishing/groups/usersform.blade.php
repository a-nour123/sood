<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModal"
    aria-hidden="true" id="{{ $id }}">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myExtraLargeModal">{{ $title }}</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="{{ __('locale.Close') }}"></button>
            </div>

            <div class="modal-body dark-modal">
                <form action="{{ route('admin.phishing.group.AddUsersTogroup') }}" method="POST"
                    class="modal-content pt-4 p-3" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" name="id" class="test">

                    <!-- 🔵 Select All Users (Global) -->
                    <div class="mb-2">
                        <input type="checkbox" id="select-all-global">
                        <label for="select-all-global"><strong>{{ __('phishing.SelectAllUsersInAllDepartments') }}</strong></label>
                    </div>

                    <div class="tree">
                        @foreach ($departments as $department)
                            <ul>
                                <li style="margin-left: 20px;">
                                    <!-- Row for Department Name + Checkbox -->
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        @if ($department->employees->count())
                                            <input type="checkbox" class="select-all-dept"
                                                data-dept-id="{{ $department->id }}">
                                        @endif
                                        <a href="javascript:void(0);"
                                            style="color:{{ $department?->color?->value }}; flex:1;"
                                            class="department-anchor" data-dept-id="{{ $department->id }}">
                                            {{ $department->name }}
                                        </a>
                                    </div>

                                    <!-- Users List (Hidden by Default, Slides Below the Row) -->
                                    @if ($department->employees->count())
                                        <ul class="users-list" id="users-dept-{{ $department->id }}"
                                            style="display: none; margin-left: 30px; margin-top:5px;">
                                            @foreach ($department->employees as $user)
                                                <li>
                                                    <input type="checkbox" name="users[]" value="{{ $user->id }}"
                                                        class="user-checkbox dept-{{ $department->id }}"
                                                        id="user-{{ $user->id }}"
                                                        @if (
                                                            !is_null(\App\Models\PhishingGroup::find($idValue)) &&
                                                                in_array($user->id, \App\Models\PhishingGroup::find($idValue)->users->pluck('id')->toArray())) checked @endif>
                                                    <label for="user-{{ $user->id }}">{{ $user->name }}</label>
                                                </li>
                                            @endforeach
                                        </ul>
                                    @endif
                                </li>
                            </ul>
                        @endforeach
                    </div>

                    <button type="Submit" class="btn btn-primary data-submit me-1">{{ __('locale.Submit') }}</button>
                </form>
            </div>

        </div>
    </div>
</div>
