<!-- Risk Modal -->
<div class="wizardModal modal fade" id="{{ $id }}" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-add-new-role">
        <div class="modal-content">
            <div class="modal-header bg-transparent">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="{{ __('locale.Close') }}"></button>
            </div>
            <div class="modal-body px-2 px-md-5 pb-3">
                <div class="text-center mb-4">
                    <h1 class="role-title">{{ $title }}</h1>
                </div>
            </div>
            <div class="card-body basic-wizard important-validation">
                <div class="stepper-horizontal" id="stepper1">
                    <!-- Step 1 -->
                    <div class="stepper-1 step active">
                        <div class="step-circle"><span>1</span></div>
                        <div class="step-title">{{ __('risk.Identification') }}</div>
                        <div class="step-bar-left"></div>
                        <div class="step-bar-right"></div>
                    </div>
                    <!-- Step 2 -->
                    <div class="stepper-2 step">
                        <div class="step-circle"><span>2</span></div>
                        <div class="step-title">{{ __('risk.RiskAnalysis') }}</div>
                        <div class="step-bar-left"></div>
                        <div class="step-bar-right"></div>
                    </div>
                    <!-- Step 3 -->
                    <div class="stepper-3 step">
                        <div class="step-circle"><span>3</span></div>
                        <div class="step-title">{{ __('risk.RiskEvaulationAndTreatment') }}</div>
                        <div class="step-bar-left"></div>
                        <div class="step-bar-right"></div>
                    </div>
                    <!-- Step 4 -->
                    <div class="stepper-4 step">
                        <div class="step-circle"><span>4</span></div>
                        <div class="step-title">{{ __('risk.RiskReview') }}</div>
                        <div class="step-bar-left"></div>
                        <div class="step-bar-right"></div>
                    </div>
                </div>

                <form class="wizard-fields row" id="wizard-form"
                    action="{{ route('admin.risk_management.ajax.store') }}" method="POST"
                    enctype="multipart/form-data">
                    @csrf
                    <div id="msform">
                        <div class="tab" id="step1-content">
                            <div class="wizard-fields row">
                                <!-- First Column (6) -->
                                <div class="col-12 col-md-6 mb-2">
                                    <!-- Subject Field -->
                                    <div class="mb-1">
                                        <label class="form-label"
                                            for="subject">{{ __('locale.ScenarioDescription') }}</label>
                                        <input type="text" name="subject" id="subject" class="form-control"
                                            required />
                                        <div class="invalid-feedback">{{ __('locale.Required') }}.</div>
                                    </div>
                                </div>

                                <!-- Second Column (6) -->
                                <div class="col-12 col-md-6 mb-2">
                                    <!-- Risk Mapping -->
                                    <div class="mb-1">
                                        <label class="form-label">{{ __('report.VulnerabilityMapping') }}</label>
                                        <select name="risk_catalog_mapping_id[]" class="form-select multiple-select2"
                                            multiple="multiple">
                                            @foreach ($riskGroupings as $riskGrouping)
                                                <optgroup label="{{ $riskGrouping->name }}">
                                                    @foreach ($riskGrouping->RiskCatalogs as $riskCatalog)
                                                        <option value="{{ $riskCatalog->id }}">
                                                            {{ $riskCatalog->number . ' - ' . $riskCatalog->name }}
                                                        </option>
                                                    @endforeach
                                                </optgroup>
                                            @endforeach
                                        </select>
                                        <span class="error error-risk_catalog_mapping_id"></span>
                                    </div>
                                </div>

                                <!-- First Column (6) -->
                                <div class="col-12 col-md-6 mb-2">
                                    <!-- Threat Mapping -->
                                    <div class="mb-1">
                                        <label class="form-label">{{ __('report.ThreatMapping') }}</label>
                                        <select name="threat_catalog_mapping_id[]" class="form-select multiple-select2"
                                            multiple="multiple">
                                            @foreach ($threatGroupings as $threatGrouping)
                                                <optgroup label="{{ $threatGrouping->name }}">
                                                    @foreach ($threatGrouping->ThreatCatalogs as $ThreatCatalog)
                                                        <option value="{{ $ThreatCatalog->id }}">
                                                            {{ $ThreatCatalog->number . ' - ' . $ThreatCatalog->name }}
                                                        </option>
                                                    @endforeach
                                                </optgroup>
                                            @endforeach
                                        </select>
                                        <span class="error error-threat_catalog_mapping_id"></span>
                                    </div>
                                </div>

                                <!-- Second Column (6) -->
                                <div class="col-12 col-md-6 mb-2">
                                    <!-- Category Field -->
                                    <div class="mb-1">
                                        <label class="form-label">{{ __('report.Category') }}</label>
                                        <select class="select2 form-select" name="category_id">
                                            <option value="" selected>{{ __('locale.select-option') }}</option>
                                            @foreach ($categories as $category)
                                                <option value="{{ $category->id }}">{{ $category->name }}</option>
                                            @endforeach
                                        </select>
                                        <span class="error error-category_id"></span>
                                    </div>
                                </div>

                                <!-- First Column (6) -->
                                <div class="col-12 col-md-6 mb-2">
                                    <!-- Site Location -->
                                    <div class="mb-1">
                                        <label class="form-label">{{ __('locale.SiteLocation') }}</label>
                                        <select class="form-select multiple-select2" name="location_id[]"
                                            multiple="multiple">
                                            @foreach ($locations as $location)
                                                <option value="{{ $location->id }}">{{ $location->name }}</option>
                                            @endforeach
                                        </select>
                                        <span class="error error-location_id"></span>
                                    </div>
                                </div>
                                <!-- Related Asset (AJAX Select2 — no full asset dump) -->
                                <div class="col-12 col-md-6 mb-3">
                                    <div class="mb-1">
                                        <label class="form-label">{{ __('risk.RelatedAsset') }}</label>
                                        <select name="affected_asset_id[]"
                                            class="form-select select-affected-asset-ajax" required
                                            data-placeholder="{{ __('risk.SearchAssetPlaceholder') }}">
                                            <option value="">{{ __('locale.SelectOption') }}</option>
                                        </select>
                                        <span class="error error-affected_asset_id"></span>
                                    </div>
                                </div>

                                <!-- Asset Owner (display only) -->
                                <div class="col-12 col-md-3 mb-2">
                                    <div class="mb-1">
                                        <label class="form-label">{{ __('risk.AssetOwner') }}</label>
                                        <input type="text" id="asset_owner_display" class="form-control" disabled
                                            placeholder="—">
                                    </div>
                                </div>

                                <!-- Asset Rank (KSU #19) -->
                                <div class="col-12 col-md-3 mb-2">
                                    <div class="mb-1">
                                        <label class="form-label">{{ __('risk.AssetRank') }}</label>
                                        <input type="text" id="asset_rank_display" class="form-control" readonly
                                            placeholder="—">
                                        <input type="hidden" name="asset_rank_snapshot" id="asset_rank_snapshot">
                                    </div>
                                </div>

                                <!-- Risk Owner (chosen freely, independent of the asset owner) -->
                                <div class="col-12 col-md-6 mb-2">
                                    <div class="mb-1">
                                        <label class="form-label">{{ __('risk.RiskOwner') }}</label>
                                        <select class="select2 form-select" name="owner_id" id="owner_id">
                                            <option value="" selected>{{ __('locale.select-option') }}</option>
                                            @foreach ($owners as $owner)
                                                <option value="{{ $owner->id }}"
                                                    data-manager="{{ $owner->manager_id ?? '' }}"
                                                    data-department-manager="{{ $owner->department_manager_id ?? '' }}">
                                                    {{ $owner->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        <span class="error error-owner_id"></span>
                                    </div>
                                </div>

                                <!-- Owner's Manager (from Hierarchy) -->
                                <div class="col-12 col-md-6 mb-2">
                                    <div class="mb-1">
                                        <label class="form-label">{{ __('locale.OwnersManager') }}</label>
                                        <select class="select2 form-select" id="owner_manager_display" disabled>
                                            <option value="" selected>—</option>
                                            @foreach ($owners as $owner)
                                                <option value="{{ $owner->id }}">{{ $owner->name }}</option>
                                            @endforeach
                                        </select>
                                        <input type="hidden" name="owner_manager_id" id="owner_manager_id">
                                        <span class="error error-manager_id"></span>
                                    </div>
                                </div>
                                <div class="col-12 mb-2">
                                    <small class="text-muted">{{ __('risk.OwnerFromAssetHint') }}</small>
                                </div>

                                <!-- Additional Stakeholders -->
                                <div class="col-12 col-md-6 mb-2">
                                    <div class="mb-1">
                                        <label class="form-label">{{ __('locale.AdditionalStakeholders') }}</label>
                                        <select name="additional_stakeholder_id[]"
                                            class="form-select multiple-select2" multiple="multiple">
                                            @foreach ($enabledUsers as $additionalStakeholder)
                                                <option value="{{ $additionalStakeholder->id }}">
                                                    {{ $additionalStakeholder->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        <span class="error error-additional_stakeholder_id"></span>
                                    </div>
                                </div>


                                <!-- First Column (6) -->
                                <div class="col-12 col-md-6 mb-2">
                                    <!-- Tags -->
                                    <div class="mb-1">
                                        <label class="form-label">{{ __('report.Tags') }}</label>
                                        <select name="tags[]" class="form-select multiple-select2"
                                            multiple="multiple">
                                            @foreach ($tags as $tag)
                                                <option value="{{ $tag->id }}">{{ $tag->tag }}</option>
                                            @endforeach
                                        </select>
                                        <span class="error error-tags"></span>
                                    </div>
                                </div>

                                <!-- Second Column (6) -->
                                <div class="col-12 col-md-6 mb-2">
                                    <!-- Team -->
                                    <div class="mb-1">
                                        <label class="form-label">{{ __('locale.Team') }}</label>
                                        <select name="team_id[]" class="form-select multiple-select2"
                                            multiple="multiple">
                                            @foreach ($teams as $team)
                                                <option value="{{ $team->id }}">{{ $team->name }}</option>
                                            @endforeach
                                        </select>
                                        <span class="error error-team_id"></span>
                                    </div>
                                </div>

                                <!-- First Column (6) -->
                                <div class="col-12 col-md-6 mb-2">
                                    <!-- External Reference Id -->
                                    <div class="mb-1">
                                        <label class="form-label">{{ __('report.ExternalReferenceId') }}</label>
                                        <input type="text" name="reference_id" class="form-control dt-post"
                                            aria-label="{{ __('report.ExternalReferenceId') }}" />
                                        <span class="error error-reference_id"></span>
                                    </div>
                                </div>

                                <!-- Second Column (6) -->
                                <div class="col-12 col-md-6 mb-2">
                                    <!-- You can add additional form fields here if needed -->
                                </div>
                            </div>
                        </div>



                        <!-- Step 2 Content -->
                        <div class="tab" id="step2-content" style="display: none;">
                            <div class="wizard-fields row">
                                <!-- Left column (6) -->
                                <div class="col-12 col-md-6 mb-3">

                                    {{-- Control Regulation --}}
                                    <div class="mb-1">
                                        <label class="form-label ">{{ __('report.ControlRegulation') }}</label>
                                        <select class="select2 form-select" name="framework_id">
                                            <option value="" selected>{{ __('locale.select-option') }}</option>
                                            @foreach ($frameworks as $framework)
                                                <option value="{{ $framework->id }}"
                                                    data-controls="{{ json_encode($framework->FrameworkControls) }}">
                                                    {{ $framework->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        <span class="error error-framework_id"></span>
                                    </div>
                                </div>

                                <!-- Right column (6) -->
                                <div class="col-12 col-md-6 mb-3">

                                    {{-- Control Number --}}
                                    <div class="mb-1">
                                        <label class="form-label ">{{ __('report.ControlNumber') }}</label>
                                        <select class="select2 form-select" name="control_id">
                                            <option value="" selected>{{ __('locale.select-option') }}</option>
                                        </select>
                                        <span class="error error-control_id"></span>
                                    </div>

                                </div>

                                <!-- Right column (6) -->
                                <div class="col-12 col-md-6 mb-3">

                                    {{-- Technology --}}
                                    <div class="mb-1">
                                        <label class="form-label ">{{ __('locale.Technology') }}</label>
                                        <select name="technology_id[]" class="form-select multiple-select2"
                                            multiple="multiple">
                                            @foreach ($technologies as $technology)
                                                <option value="{{ $technology->id }}">{{ $technology->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        <span class="error error-technology_id"></span>
                                    </div>
                                </div>

                                <!-- Left column (6) -->
                                <div class="col-12 col-md-6 mb-3">

                                    {{-- Risk Source --}}
                                    <div class="mb-1">
                                        <label class="form-label">{{ __('locale.ImpactScope') }}</label>
                                        <select class="select2 form-select" name="risk_source_id">
                                            <option value="" selected>{{ __('locale.select-option') }}</option>
                                            @foreach ($riskSources as $riskSource)
                                                <option value="{{ $riskSource->id }}">{{ $riskSource->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        <span class="error error-risk_source_id"></span>
                                    </div>
                                </div>

                                <!-- Right column (6) -->
                                <div class="col-12 col-md-6 mb-3">

                                    {{-- Current Impact --}}
                                    <div class="mb-1">
                                        <label class="form-label">{{ __('report.CurrentImpact') }}</label>
                                        <select class="select2 form-select" name="current_impact_id">
                                            <option value="" disabled hidden selected>
                                                {{ __('locale.select-option') }}</option>
                                            @foreach ($impacts as $impact)
                                                <option value="{{ $impact->id }}">{{ $impact->name }}</option>
                                            @endforeach
                                        </select>
                                        <span class="error error-current_impact_id"></span>
                                    </div>
                                </div>

                                <!-- Left column (6) -->
                                <div class="col-12 col-md-6 mb-3">

                                    {{-- Current Likelihood --}}
                                    <div class="mb-1">
                                        <label class="form-label">{{ __('report.CurrentLikelihood') }}</label>
                                        <select class="select2 form-select" name="current_likelihood_id">
                                            <option value="" disabled hidden selected>
                                                {{ __('locale.select-option') }}</option>
                                            @foreach ($riskLikelihoods as $riskLikelihood)
                                                <option value="{{ $riskLikelihood->id }}">{{ $riskLikelihood->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        <span class="error error-current_likelihood_id"></span>
                                    </div>
                                </div>

                                <!-- Right column (6) -->
                                <div class="col-12 col-md-6 mb-3">

                                    {{-- Risk Scoring Method --}}
                                    <div class="mb-1">
                                        <label class="form-label">{{ __('report.RiskScoringMethod') }}</label>
                                        <select class="select2 form-select" name="risk_scoring_method_id">
                                            <option value="" disabled hidden>{{ __('locale.select-option') }}
                                            </option>
                                            @foreach ($riskScoringMethods as $riskScoringMethod)
                                                <option value="{{ $riskScoringMethod->id }}">
                                                    {{ $riskScoringMethod->name }}</option>
                                            @endforeach
                                        </select>
                                        <span class="error error-risk_scoring_method_id"></span>
                                    </div>
                                </div>

                                <!-- Responsible Party = Departments (KSU #22) -->
                                <div class="col-12 col-md-6 mb-3">
                                    <div class="mb-1">
                                        <label class="form-label">{{ __('risk.ResponsiblePart') }}</label>
                                        <select class="select2 form-select" name="responsible_department_id"
                                            id="responsible_department_id">
                                            <option value="" selected>{{ __('locale.select-option') }}</option>
                                            @foreach (($departments ?? []) as $department)
                                                <option value="{{ $department->id }}">{{ $department->name }}</option>
                                            @endforeach
                                        </select>
                                        <input type="hidden" name="risk_assessment" id="risk_assessment_hidden">
                                        <span class="error error-responsible_department_id"></span>
                                    </div>
                                </div>

                                <!-- Current Control (KSU #24) -->
                                <div class="col-12 col-md-6 mb-3">
                                    <div class="mb-1">
                                        <label class="form-label">{{ __('risk.CurrentControl') }}</label>
                                        <textarea class="form-control" name="current_control" rows="3"></textarea>
                                        <span class="error error-current_control"></span>
                                    </div>
                                </div>

                                <!-- Risk Evaluation from Heat Matrix (KSU #25) -->
                                <div class="col-12 col-md-6 mb-3">
                                    <div class="mb-1">
                                        <label class="form-label">{{ __('risk.RiskEvaluation') }}</label>
                                        <div id="risk_evaluation_display"
                                            class="form-control d-flex align-items-center justify-content-between"
                                            style="min-height:38px;background:#f8f8f8;">
                                            <span id="risk_evaluation_text">—</span>
                                            <span id="risk_evaluation_badge" class="badge"
                                                style="display:none;"></span>
                                        </div>
                                        <input type="hidden" name="risk_evaluation_score" id="risk_evaluation_score">
                                        <input type="hidden" name="risk_evaluation_level" id="risk_evaluation_level">
                                        <small class="text-muted">{{ __('risk.RiskEvaluationHint') }}</small>
                                    </div>
                                </div>

                                <!-- KRIs / Additional Notes -->
                                <div class="col-12 col-md-6 mb-3">
                                    <div class="mb-1">
                                        <label class="form-label">{{ __("locale.KRI'S") }}</label>
                                        <div id="risk_addational_notes_submit"></div>
                                    </div>
                                </div>

                                <div class="col-12 col-md-6 mb-3">
                                    <div class="mb-1">
                                        <label class="form-label">{{ __('report.SupportingDocumentation') }}</label>
                                        <input type="file" multiple name="supporting_documentation[]"
                                            class="form-control dt-post"
                                            aria-label="{{ __('locale.SupportingDocumentation') }}" />
                                        <span class="error error-supporting_documentation"></span>
                                    </div>
                                </div>

                                <div class="col-12 col-md-6 mb-3">
                                    <div class="mb-1">
                                        <label class="form-label">{{ __('locale.Description') }}</label>
                                        <textarea class="form-control" name="risk_description" rows="3"></textarea>
                                        <span class="error error-risk_description"></span>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <!-- Step 3 Content (Risk Evaluation and Treatment) -->
                        <div class="tab" id="step3-content" style="display: none;">
                            <div class="wizard-fields">
                                <div class="alert alert-secondary mb-2" id="treatment_eval_banner">
                                    <strong>{{ __('risk.RiskEvaluation') }}:</strong>
                                    <span id="treatment_eval_text">—</span>
                                </div>

                                <div class="row">
                                    <div class="col-12">
                                        <div class="mb-1">
                                            <label class="text-label">{{ __('risk.TreatmentOption') }}</label>
                                            <select id="planMitigationOption" class="form-select"
                                                name="mitigation_option" required>
                                                <option value="mitigate" selected>{{ __('risk.TreatMitigate') }}</option>
                                                <option value="avoid" disabled>{{ __('risk.TreatAvoid') }}</option>
                                                <option value="transfer" disabled>{{ __('risk.TreatTransfer') }}</option>
                                                <option value="accept" disabled>{{ __('risk.TreatAccept') }}</option>
                                            </select>
                                            <small class="text-muted">{{ __('risk.TreatmentOptionHint') }}</small>
                                        </div>
                                    </div>
                                </div>

                                <div id="planMitigationInputs">
                                    <div class="row">
                                        <div class="col-12 col-md-6">

                                            {{-- Mitigation Planning Date --}}
                                            <div class="mb-1">
                                                <label class="text-label">{{ __('risk.MitigationPlanning') }}</label>
                                                <input name="planned_mitigation_date"
                                                    class="form-control flatpickr-date-time-compliance" />
                                                <span class="error error-planned_mitigation_date "></span>
                                            </div>
                                        </div>

                                        <div class="col-12 col-md-6">
                                            {{-- Mitigation Effort --}}
                                            <div class="mb-1">
                                                <label class="text-label">{{ __('risk.MitigationEffort') }}</label>
                                                <select class="select2 form-select" name="mitigation_effort">
                                                    <option value="">{{ __('locale.select-option') }}</option>
                                                    @foreach ($mitigationEfforts as $mitigationEffort)
                                                        <option value="{{ $mitigationEffort->id }}">
                                                            {{ $mitigationEffort->name }}</option>
                                                    @endforeach
                                                </select>
                                                <span class="error error-mitigation_effort"></span>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Second Row -->
                                    <div class="row">
                                        <div class="col-12 col-md-6">
                                            {{-- Planning Strategy --}}
                                            <div class="mb-1">
                                                <label class="text-label">{{ __('risk.PlanningStrategy') }}</label>
                                                <select class="select2 form-select" name="planning_strategy">
                                                    <option value="">{{ __('locale.select-option') }}</option>
                                                    @foreach ($planningStrategies as $planningStrategy)
                                                        <option value="{{ $planningStrategy->id }}">
                                                            {{ $planningStrategy->name }}</option>
                                                    @endforeach
                                                </select>
                                                <span class="error error-planning_strategy"></span>
                                            </div>
                                        </div>

                                        <div class="col-12 col-md-6">
                                            {{-- Mitigation Owner --}}
                                            <div class="mb-1">
                                                <label class="text-label">{{ __('risk.MitigationOwner') }}</label>
                                                <select class="select2 form-select" name="mitigation_owner_id">
                                                    <option value="">{{ __('locale.select-option') }}</option>
                                                    @foreach ($enabledUsers as $owner)
                                                        <option value="{{ $owner->id }}">
                                                            {{ $owner->name }}</option>
                                                    @endforeach
                                                </select>
                                                <span class="error error-mitigation_owner_id"></span>
                                            </div>
                                        </div>

                                    </div>

                                    <!-- Third Row -->
                                    <div class="row">
                                        <div class="col-12 col-md-6">
                                            {{-- Mitigation Cost --}}
                                            <div class="mb-1">
                                                <label class="text-label">{{ __('risk.MitigationCost') }}</label>
                                                <select name="mitigation_cost" id="mitigation_cost"
                                                    class="form-control">
                                                    @foreach ($mitigationCosts as $mitigationCost)
                                                        <option value="{{ $mitigationCost->id }}">
                                                            {{ $mitigationCost->name }}
                                                            @php
                                                                $valuation_level_name = '';
                                                                if (!empty($mitigationCost->valuation_level_name)) {
                                                                    $valuation_level_name =
                                                                        ' (' .
                                                                        $mitigationCost->valuation_level_name .
                                                                        ')';
                                                                }

                                                                if (
                                                                    $mitigationCost->min_value ===
                                                                    $mitigationCost->max_value
                                                                ) {
                                                                    echo get_setting('currency') .
                                                                        number_format($mitigationCost->min_value) .
                                                                        $valuation_level_name;
                                                                } else {
                                                                    echo get_setting('currency') .
                                                                        number_format($mitigationCost->min_value) .
                                                                        ' to ' .
                                                                        get_setting('currency') .
                                                                        number_format($mitigationCost->max_value) .
                                                                        $valuation_level_name;
                                                                }
                                                            @endphp
                                                        </option>
                                                    @endforeach
                                                </select>
                                                <span class="error error-mitigation_cost"></span>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-6">
                                            <div class="mb-1">
                                                <label class="text-label">{{ __('risk.TreatmentDueDate') }}</label>
                                                <input name="treatment_due_date"
                                                    class="form-control flatpickr-date-time-compliance" />
                                                <span class="error error-treatment_due_date"></span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-12 col-md-4">
                                            <div class="mb-1">
                                                <label class="text-label">{{ __('risk.MitigationNature') }}</label>
                                                <select name="mitigation_nature[]" class="form-select multiple-select2"
                                                    multiple>
                                                    <option value="technical">{{ __('risk.NatureTechnical') }}</option>
                                                    <option value="physical">{{ __('risk.NaturePhysical') }}</option>
                                                    <option value="administrative">{{ __('risk.NatureAdministrative') }}</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-4">
                                            <div class="mb-1">
                                                <label class="text-label">{{ __('risk.MitigationFunction') }}</label>
                                                <select name="mitigation_function[]"
                                                    class="form-select multiple-select2" multiple>
                                                    <option value="preventive">{{ __('risk.FuncPreventive') }}</option>
                                                    <option value="detective">{{ __('risk.FuncDetective') }}</option>
                                                    <option value="corrective">{{ __('risk.FuncCorrective') }}</option>
                                                    <option value="deterrent">{{ __('risk.FuncDeterrent') }}</option>
                                                    <option value="recovery">{{ __('risk.FuncRecovery') }}</option>
                                                    <option value="compensating">{{ __('risk.FuncCompensating') }}</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-4">
                                            <div class="mb-1">
                                                <label class="text-label">{{ __('risk.ExpectedResult') }}</label>
                                                <select name="expected_result[]" class="form-select multiple-select2"
                                                    multiple>
                                                    <option value="reduce_impact">{{ __('risk.ReduceImpact') }}</option>
                                                    <option value="reduce_likelihood">{{ __('risk.ReduceLikelihood') }}</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row mb-2">
                                        <div class="col-12 d-flex justify-content-between align-items-center">
                                            <h6 class="mb-0">{{ __('risk.ActionPlans') }}</h6>
                                            <button type="button" class="btn btn-sm btn-outline-primary"
                                                id="add_action_plan_row">+ {{ __('risk.AddActionPlan') }}</button>
                                        </div>
                                        <div class="col-12" id="action_plans_container"></div>
                                        <div class="col-12 mt-1">
                                            <small class="text-muted">
                                                {{ __('risk.ActionPlansHint') }}
                                                <span id="action_plans_totals"></span>
                                            </small>
                                        </div>
                                    </div>

                                    <!-- Fourth Row -->
                                    <div class="row">
                                        <div class="col-12 col-md-6">
                                            {{-- Mitigation Team --}}
                                            <div class="mb-1">
                                                <label class="text-label">{{ __('risk.MitigationTeam') }}</label>
                                                <select name="mitigation_team_id[]"
                                                    class="form-select multiple-select2" multiple="multiple">
                                                    @foreach ($teams as $team)
                                                        <option value="{{ $team->id }}">
                                                            {{ $team->name }}</option>
                                                    @endforeach
                                                </select>
                                                <span class="error error-mitigation_team_id"></span>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-6">
                                            {{-- Current Solution --}}
                                            <div class="mb-1">
                                                <label class="text-label">{{ __('risk.CurrentSolution') }}</label>
                                                <div id="risk_current_solution"></div>
                                            </div>
                                        </div>

                                    </div>

                                    <!-- Fifth Row -->
                                    <div class="row">
                                        <div class="col-12 col-md-6">
                                            {{-- Mitigation Controls --}}
                                            <div class="mb-1">
                                                <label
                                                    class="text-label">{{ __('locale.MitigationControls') }}</label>
                                                <select name="mitigation_control_id[]"
                                                    class="form-select multiple-select2" multiple="multiple">
                                                    @foreach ($frameworks as $framework)
                                                        @foreach ($framework->FrameworkControls as $control)
                                                            <option value="{{ $control->id }}">
                                                                {{ $control->short_name }}
                                                            </option>
                                                        @endforeach
                                                    @endforeach
                                                </select>
                                                <span class="error error-mitigation_control_id"></span>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Sixth Row -->
                                    <div class="row">
                                        <div class="col-12 col-md-6">
                                            {{-- Security Recommendations --}}
                                            <div class="mb-1">
                                                <label
                                                    class="text-label">{{ __('risk.SecurityRecommendations') }}</label>
                                                <textarea class="form-control" name="security_recommendations" rows="3"></textarea>
                                                <span class="error error-security_recommendations "></span>
                                            </div>
                                        </div>

                                        <div class="col-12 col-md-6">
                                            {{-- Security Requirements --}}
                                            <div class="mb-1">
                                                <label
                                                    class="text-label">{{ __('risk.SecurityRequirements') }}</label>
                                                <textarea class="form-control" name="security_requirements" rows="3"></textarea>
                                                <span class="error error-security_requirements "></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {{-- Avoid treatment panel --}}
                                <div id="avoidTreatmentInputs" style="display:none;">
                                    <div class="row">
                                        <div class="col-md-6 mb-1">
                                            <label>{{ __('risk.ReasonDescription') }}</label>
                                            <textarea class="form-control" name="avoid_reason_description" rows="3"></textarea>
                                        </div>
                                        <div class="col-md-6 mb-1">
                                            <label>{{ __('risk.DecisionOwner') }}</label>
                                            <select class="select2 form-select" name="avoid_decision_owner_id">
                                                <option value="">{{ __('locale.select-option') }}</option>
                                                @foreach ($owners as $owner)
                                                    <option value="{{ $owner->id }}">{{ $owner->name }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="col-md-6 mb-1">
                                            <label>{{ __('risk.DecisionDate') }}</label>
                                            <input name="avoid_decision_date"
                                                class="form-control flatpickr-date-time-compliance treatment-decision-date"
                                                data-pair="avoid_reevaluate_date" />
                                        </div>
                                        <div class="col-md-6 mb-1">
                                            <label>{{ __('risk.ReevaluateDate') }}</label>
                                            <input name="avoid_reevaluate_date"
                                                class="form-control flatpickr-date-time-compliance" />
                                        </div>
                                        <div class="col-12 mb-1">
                                            <label>{{ __('risk.AvoidanceStrategy') }}</label>
                                            <textarea class="form-control" name="avoid_strategy_description" rows="3"></textarea>
                                        </div>
                                    </div>
                                </div>

                                {{-- Transfer treatment panel --}}
                                <div id="transferTreatmentInputs" style="display:none;">
                                    <div class="row">
                                        <div class="col-md-6 mb-1">
                                            <label>{{ __('risk.ReasonDescription') }}</label>
                                            <textarea class="form-control" name="transfer_reason_description" rows="3"></textarea>
                                        </div>
                                        <div class="col-md-6 mb-1">
                                            <label>{{ __('risk.DecisionOwner') }}</label>
                                            <select class="select2 form-select" name="transfer_decision_owner_id">
                                                <option value="">{{ __('locale.select-option') }}</option>
                                                @foreach ($owners as $owner)
                                                    <option value="{{ $owner->id }}">{{ $owner->name }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="col-md-6 mb-1">
                                            <label>{{ __('risk.DecisionDate') }}</label>
                                            <input name="transfer_decision_date"
                                                class="form-control flatpickr-date-time-compliance treatment-decision-date"
                                                data-pair="transfer_reevaluate_date" />
                                        </div>
                                        <div class="col-md-6 mb-1">
                                            <label>{{ __('risk.ReevaluateDate') }}</label>
                                            <input name="transfer_reevaluate_date"
                                                class="form-control flatpickr-date-time-compliance" />
                                        </div>
                                        <div class="col-md-6 mb-1">
                                            <label>{{ __('risk.TransferPartyType') }}</label>
                                            <select class="form-select" name="transfer_party_type">
                                                <option value="internal">{{ __('risk.Internal') }}</option>
                                                <option value="external">{{ __('risk.External') }}</option>
                                            </select>
                                        </div>
                                        <div class="col-md-6 mb-1">
                                            <label>{{ __('risk.TransferPartyDescription') }}</label>
                                            <textarea class="form-control" name="transfer_party_description" rows="2"></textarea>
                                        </div>
                                    </div>
                                </div>

                                {{-- Accept treatment panel --}}
                                <div id="acceptTreatmentInputs" style="display:none;">
                                    <div class="row">
                                        <div class="col-md-6 mb-1">
                                            <label>{{ __('risk.ReasonDescription') }}</label>
                                            <textarea class="form-control" name="accept_reason_description" rows="3"></textarea>
                                        </div>
                                        <div class="col-md-6 mb-1">
                                            <label>{{ __('risk.DecisionOwner') }}</label>
                                            <select class="select2 form-select" name="accept_decision_owner_id">
                                                <option value="">{{ __('locale.select-option') }}</option>
                                                @foreach ($owners as $owner)
                                                    <option value="{{ $owner->id }}">{{ $owner->name }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="col-md-6 mb-1">
                                            <label>{{ __('risk.DecisionDate') }}</label>
                                            <input name="accept_decision_date"
                                                class="form-control flatpickr-date-time-compliance treatment-decision-date"
                                                data-pair="accept_reevaluate_date" />
                                        </div>
                                        <div class="col-md-6 mb-1">
                                            <label>{{ __('risk.ReevaluateDate') }}</label>
                                            <input name="accept_reevaluate_date"
                                                class="form-control flatpickr-date-time-compliance" />
                                        </div>
                                        <div class="col-12 mb-1">
                                            <label>{{ __('risk.OwnerApprovalStatement') }}</label>
                                            <textarea class="form-control" name="accept_strategy_description" rows="3"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Step 4 Content (Risk Review) -->
                        <div class="tab" id="step4-content" style="display: none;">
                            <div class="wizard-fields row">
                                <!-- Perform a Review Option -->
                                <div class="row">
                                    <div class="col-12">
                                        <div class="mb-1">
                                            <label class="text-label">{{ __('locale.SelectOption') }}</label>
                                            <select id="performReviewOption" name="review_option"
                                                class="form-select">
                                                <option class="step-3-option" selected value="NoReview">
                                                    {{ __('locale.No Review') }}
                                                </option>
                                                <option class="step-3-option" value="PerformAReview">
                                                    {{ __('locale.Perform a Review') }}
                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div id="planReviewInputs" style="display: none;">

                                    {{-- Review --}}
                                    <div class="mb-1">
                                        <label class="text-label">{{ __('locale.Review') }}</label>
                                        <select class="select2 form-select" name="review">
                                            <option value="" selected disabled>
                                                {{ __('locale.select-option') }}</option>
                                            @foreach ($reviews as $review)
                                                <option value="{{ $review->id }}">
                                                    {{ $review->name }}</option>
                                            @endforeach
                                        </select>
                                        <span class="error error-review"></span>
                                    </div>
                                    {{-- Next Step --}}
                                    <div class="mb-1">
                                        <label class="text-label">{{ __('locale.NextStep') }}</label>
                                        <select class="select2 form-select" name="next_step">
                                            <option value="" selected disabled>
                                                {{ __('locale.select-option') }}</option>
                                            @foreach ($nextSteps as $nextStep)
                                                <option value="{{ $nextStep->id }}">
                                                    {{ $nextStep->name }}</option>
                                            @endforeach
                                        </select>
                                        <span class="error error-next_step"></span>
                                    </div>
                                    {{-- Project Name --}}
                                    <div class="mb-1 d-none" id="project-container">
                                        <label class="text-label">{{ __('locale.ProjectName') }}</label>
                                        <select class="select2 form-select" name="project">
                                            <option value="" selected disabled>
                                                {{ __('locale.select-option') }}</option>
                                            @foreach ($projects as $project)
                                                <option value="{{ $project->id }}">
                                                    {{ $project->name }}</option>
                                            @endforeach
                                        </select>
                                        <span class="error error-project"></span>
                                    </div>
                                    <div class="mb-1 mt-1">
                                        <label class="text-label">{{ __('locale.NextReviewDate') }}</label>
                                        <input name="next_review_date"
                                            class="form-control flatpickr-date-time-compliance" />
                                        <span class="error error-next_review_date "></span>
                                    </div>
                                    {{-- Comment --}}
                                    <div class="mb-1">
                                        <label class="text-label">{{ __('locale.Comment') }}</label>
                                        <textarea class="form-control" name="comments" rows="3"></textarea>
                                        <span class="error error-comments "></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>

                <!-- Wizard Navigation -->
                <div class="wizard-footer d-flex gap-2 justify-content-end m-3">
                    <button type="button" class="btn alert-light-primary" id="backbtn">{{ __('locale.Back') }}</button>
                    <button type="button" class="btn btn-primary" id="nextbtn">{{ __('locale.Next') }}</button>
                </div>
            </div>
        </div>
    </div>
</div>
