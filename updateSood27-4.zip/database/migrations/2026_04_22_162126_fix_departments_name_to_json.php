<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

class FixDepartmentsNameToJson extends Migration
{
    public function up()
    {
        $departments = DB::table('departments')->get();

        foreach ($departments as $dept) {
            // لو مش JSON
            if (!is_array(json_decode($dept->name, true))) {
                DB::table('departments')
                    ->where('id', $dept->id)
                    ->update([
                        'name' => json_encode([
                            'en' => $dept->name,
                            'ar' => $dept->name
                        ])
                    ]);
            }
        }
    }

    public function down()
    {
        // optional
    }
}