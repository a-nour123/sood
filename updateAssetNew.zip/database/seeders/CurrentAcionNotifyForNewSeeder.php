<?php

namespace Database\Seeders;

use App\Models\Action;
use Illuminate\Database\Seeder;

class CurrentAcionNotifyForNewSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Action::insert([
            ['id' => 178, 'name' => 'exception_current_notify'],
            ['id' => 179, 'name' => 'cross_request_current_notify'],
        ]);
    }
}
