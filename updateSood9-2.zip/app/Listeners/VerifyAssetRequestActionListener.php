<?php

namespace App\Listeners;

use App\Events\VerifyAssetRequest;
use App\Events\VerifyAssetRequestAction;
use App\Http\Traits\NotificationHandlingTrait;
use App\Models\Action;
use App\Models\AssetRequestVerify;
use App\Models\AssetRequestVerifyResponsible;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class VerifyAssetRequestActionListener
{
    use NotificationHandlingTrait;

    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  object  $event
     * @return void
     */
    public function handle(VerifyAssetRequestAction $event)
    {
        // Getting the action ID of the event
        $action1 = Action::where('name', 'approve_or_reject_asset_verification_request')->first();
        $actionId1 = $action1['id'];

        // Getting the model from the event
        $requestVerify = $event->requestVerify;
        $requestVerify->load(['asset.Users', 'requester', 'doneBy']);
        $responsibleUserId = AssetRequestVerifyResponsible::latest()->first()->user_id ?? null;
        // For debugging purposes, you can use dd() to check the result
        $roles = [
            'Asset-Owner' => [$requestVerify->asset->asset_owner ?? null],
            'Requester' => [$requestVerify->requester->id ?? null],
            'Responsible-Request-Verified' => [$responsibleUserId ?? null]
        ];
        $requestVerify->asset_name = $requestVerify->asset?->name ?? 'N/A';
        $requestVerify->created_by = $requestVerify->requester?->name ?? 'N/A';
        $requestVerify->done_by = $requestVerify->doneBy?->name ?? 'N/A';
        $requestVerify->asset_owner = $requestVerify->asset?->asset_owner?->name ?? 'N/A';
        $requestVerify->verified_at = $requestVerify->done_at ?? 'N/A';
        $requestVerify->done_by = $requestVerify->doneBy?->name ?? 'N/A';

        // defining the link we want the user to be redirected to after clicking the system notification
        $link = ['link' => route('admin.asset_management.ajax.verfiyRequest')];
        $actionId2 = null;
        $nextDateNotify = null;
        $modelId = null;
        $modelType = null;
        $proccess = null;
        // handling different kinds of notifications using  "sendNotificationForActiogit n" function from "NotificationHandlingTrait"
        $this->sendNotificationForAction($actionId1, $actionId2 = null, $link, $requestVerify, $roles, $nextDateNotify = null, $modelId = null, $modelType = null, $proccess = null);
    }
}
