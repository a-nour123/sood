<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AssetRequestVerify extends Model
{
    use HasFactory;

    protected $table = 'asset_request_verifies';
    protected $dates = ['done_at', 'created_at', 'updated_at'];

    protected $fillable = [
        'asset_id',
        'requested_by',
        'status',
        'done_by',
        'done_at',
        'type'
    ];

    /* ================= Relations ================= */

    public function asset()
    {
        return $this->belongsTo(Asset::class);
    }

    public function requester()
    {
        return $this->belongsTo(User::class, 'requested_by');
    }

    public function doneBy()
    {
        return $this->belongsTo(User::class, 'done_by');
    }
}
