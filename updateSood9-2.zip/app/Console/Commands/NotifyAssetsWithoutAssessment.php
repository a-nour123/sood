<?php

namespace App\Console\Commands;

use App\Http\Traits\NotificationHandlingTrait;
use Illuminate\Console\Command;
use App\Models\Asset;
use App\Models\Action;

class NotifyAssetsWithoutAssessment extends Command
{
    use NotificationHandlingTrait;

    protected $signature = 'assets:notify-without-assessment';
    protected $description = 'Notify asset owners about assets that do not have an assessment';

    public function handle()
    {
        // 1️⃣ Get all verified assets WITHOUT assessment
        $assets = Asset::whereDoesntHave('hasAssessment')
            ->where('verified', 1)
            ->get();

        if ($assets->isEmpty()) {
            $this->info('No assets without assessment.');
            return;
        }

        // 2️⃣ Get action id
        $action = Action::where('name', 'notify_asset_not_has_assessment')->first();
        if (!$action) {
            $this->error('Action notify_asset_not_has_assessment not found.');
            return;
        }
        $actionId = $action->id;

        // 3️⃣ Group assets by asset owner
        $assetsByOwner = $assets->groupBy('asset_owner');

        foreach ($assetsByOwner as $assetOwner => $ownerAssets) {

            if (!$assetOwner) continue;

            // Combine all asset names into one string
            $combinedNames = $ownerAssets->pluck('name')->filter()->implode(', ');

            // Use an array for the model (expected by handleVariables)
            $customModel = [
                'asset_name' => $combinedNames,
            ];

            /** ---------------- Collect ALL teams for this owner ---------------- */
            $teamsIds = [];
            foreach ($ownerAssets as $asset) {
                if (!empty($asset->teams)) {
                    foreach ($asset->teams as $teamId) {
                        $teamsIds[] = $teamId;
                    }
                }
            }
            $teamsIds = array_values(array_unique($teamsIds));

            /** ---------------- Notification roles ---------------- */
            $roles = [
                'Team-teams'  => !empty($teamsIds) ? $teamsIds : null,
                'Asset-Owner' => [$assetOwner],
            ];

            /** ---------------- Link ---------------- */
            $link = [
                'link' => route('admin.asset_management.index'),
            ];

            /** ---------------- Send ONE notification per owner ---------------- */
            $this->sendNotificationForAction(
                $actionId,
                null,               // actionId2
                $link,
                $customModel,       // 🚀 array with only 'asset_name'
                $roles,
                null,               // nextDateNotify
                null,               // modelId
                'asset_collection', // modelType
                null                // process
            );
        }


        $this->info('Notifications sent successfully to all asset owners.');
    }
}
