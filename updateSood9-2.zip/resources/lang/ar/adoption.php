<?php

return [
    'print_document' => 'طباعة المستند',
    'internal_use_only' => 'للاستخدام الداخلي فقط',
    'internal_use_description' => 'وصف الاستخدام الداخلي',
    'introduction' => 'مقدمة',
    'documents' => 'المستندات',
    'name' => 'الاسم',
    'version_name' => 'اسم الإصدار',
    'content' => 'المحتوى',
    'reviewer' => 'المُراجع',
    'changed_by' => 'تم التغيير بواسطة',
    'on_date' => 'في',
    'review_and_approval' => 'المراجعة والموافقة',
    'job_title' => 'المسمى الوظيفي',
    'signature_and_status' => 'التوقيع والحالة',
    'document_owner_approval' => 'موافقة مالك المستند',
    'authorized_person_approval' => 'موافقة الشخص المخول',
    
    // Status translations
    'status_approved' => 'تمت الموافقة',
    'status_rejected' => 'مرفوض',
    'status_pending' => 'قيد الانتظار',
    'status_reviewed' => 'تمت المراجعة',

     'next' => 'التالي',
    'back' => 'رجوع',
    'old' => 'القديم',
    'new' => 'الجديد',
    'changed_by' => 'تم التغيير بواسطة',
    'on_date' => 'في',
    
    // Form select options
    'status_pending' => 'قيد الانتظار',
    'status_approved' => 'تمت الموافقة',
    'status_rejected' => 'مرفوض',
];