<?php

return [
    'print_document' => 'Print Document',
    'internal_use_only' => 'For Internal Use Only',
    'internal_use_description' => 'Internal Use Description',
    'introduction' => 'Introduction',
    'documents' => 'Documents',
    'name' => 'Name',
    'version_name' => 'Version Name',
    'content' => 'Content',
    'reviewer' => 'Reviewer',
    'changed_by' => 'Changed by',
    'on_date' => 'on',
    'review_and_approval' => 'Review and Approval',
    'job_title' => 'Job Title',
    'signature_and_status' => 'Signature and Status',
    'document_owner_approval' => 'Document Owner Approval',
    'authorized_person_approval' => 'Authorized Person Approval',
    
    // Status translations
    'status_approved' => 'Approved',
    'status_rejected' => 'Rejected',
    'status_pending' => 'Pending',
    'status_reviewed' => 'Reviewed',

        'next' => 'Next',
    'back' => 'Back',
    'old' => 'Old',
    'new' => 'New',
    'changed_by' => 'Changed by',
    'on_date' => 'on',
    
    // Form select options
    'status_pending' => 'Pending',
    'status_approved' => 'Approved',
    'status_rejected' => 'Rejected',
];
