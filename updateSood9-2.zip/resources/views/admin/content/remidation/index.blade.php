@extends('admin.layouts.contentLayoutMaster')
@section('title', __('locale.Remidation Requests'))
<style>
    .gov_btn {
        border-color: #44225c !important;
        background-color: #44225c !important;
        color: #fff !important;
        /* padding: 7px; */
        border: 1px solid transparent;
        padding: 0.786rem 1.5rem;
        line-height: 1;
        border-radius: 0.358rem;
        font-weight: 500;
        font-size: 1rem;
    }

    .gov_check {
        padding: 0.786rem 0.7rem;
        line-height: 1;
        font-weight: 500;
        font-size: 1.2rem;
    }

    .gov_err {

        color: red;
    }

    .gov_btn {
        border-color: #44225c;
        background-color: #44225c;
        color: #fff !important;
        /* padding: 7px; */
        border: 1px solid transparent;
        padding: 0.786rem 1.5rem;
        line-height: 1;
        border-radius: 0.358rem;
        font-weight: 500;
        font-size: 1rem;
    }

    .gov_btn_edit {
        border-color: #5388B4 !important;
        background-color: #5388B4 !important;
        color: #fff !important;
        border: 1px solid transparent;
        padding: 0.786rem 1.5rem;
        line-height: 1;
        border-radius: 0.358rem;
        font-weight: 500;
        font-size: 1rem;
    }

    .gov_btn_map {
        border-color: #6c757d !important;
        background-color: #6c757d !important;
        color: #fff !important;
        border: 1px solid transparent;
        padding: 0.786rem 1.5rem;
        line-height: 1;
        border-radius: 0.358rem;
        font-weight: 500;
        font-size: 1rem;
    }

    .gov_btn_delete {
        border-color: red !important;
        background-color: red !important;
        color: #fff !important;
        border: 1px solid transparent;
        padding: 0.786rem 1.5rem;
        line-height: 1;
        border-radius: 0.358rem;
        font-weight: 500;
        font-size: 1rem;
    }
</style>

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/pickadate/pickadate.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/flatpickr/flatpickr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/dataTables.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/responsive.bootstrap5.min.css')) }}">

    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/buttons.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/pickadate/pickadate.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/flatpickr/flatpickr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/animate/animate.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/pages/app-chat.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/pages/app-chat-list.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/wizard/bs-stepper.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/jquery.rateyo.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/plyr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-sweet-alerts.css')) }}">
    <link rel="stylesheet" href="{{ asset('cdn/toastr.min.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('css/core.css')) }}" />
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/vendors.min.css')) }}" />
@endsection

@section('content')
    <section>
        <div class="content-header row">
            <div class="content-header-left col-12 mb-2">

                <div class="row breadcrumbs-top  widget-grid">
                    <div class="col-12">
                        <div class="page-title mt-2">
                            <div class="row">
                                <div class="col-sm-6 ps-0">
                                    @if (@isset($breadcrumbs))
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}"
                                                    style="display: flex;">
                                                    <svg class="stroke-icon">
                                                        <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}">
                                                        </use>
                                                    </svg></a></li>
                                            @foreach ($breadcrumbs as $breadcrumb)
                                                <li class="breadcrumb-item">
                                                    @if (isset($breadcrumb['link']))
                                                        <a
                                                            href="{{ $breadcrumb['link'] == 'javascript:void(0)' ? $breadcrumb['link'] : url($breadcrumb['link']) }}">
                                                    @endif
                                                    {{ $breadcrumb['name'] }}
                                                    @if (isset($breadcrumb['link']))
                                                        </a>
                                                    @endif
                                                </li>
                                            @endforeach
                                        </ol>
                                    @endisset
                            </div>
                            @if (auth()->user()->hasPermission('remidation.list'))
                            <div class="col-sm-6 pe-0 d-flex justify-content-end align-items-center gap-2">
                                <button class="btn btn-outline-primary mb-1" id="exportBtn">
                                    <i class="fa-solid fa-file-export"></i>
                                    {{ __('locale.Export') }}
                                </button>
                            </div>
                            @endif
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <div class="fluid-container slide-table">
            <h1>{{ __('locale.remediation') }}</h1>
            <table class="dt-advanced-server-search table" id="dataTableREfresh">
                <thead>
                    <tr>
                        <th>{{ __('locale.responsible_user') }}</th>
                        <th>{{ __('locale.corrective_action_plan') }}</th>
                        <th>{{ __('locale.budgetary') }}</th>
                        <th>{{ __('locale.Status') }}</th>
                        <th>{{ __('locale.due_date') }}</th>
                        <th>{{ __('locale.comments') }}</th>
                        <th>{{ __('locale.control_name') }}</th>
                        <th>{{ __('locale.action') }}</th>
                    </tr>
                </thead>
            </table>

            <!-- Modal HTML -->
            <div class="modal fade" id="remediationModal" tabindex="-1" aria-labelledby="remediationModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="remediationModalLabel">{{ __('locale.Remediation Details') }}
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form id="remediationForm">
                                @csrf
                                <div class="row">
                                    <!-- Budgetary -->
                                    <div class="col-xl-6 col-md-6 col-12">
                                        <div class="mb-1">
                                            <label class="form-label"
                                                for="budgetary">{{ __('locale.Budgetary') }}</label>
                                            <input type="number" class="form-control" id="budgetary" name="budgetary">
                                        </div>
                                    </div>

                                    <!-- Status -->
                                    <div class="col-xl-6 col-md-6 col-12">
                                        <div class="mb-1">
                                            <label class="form-label" for="status">{{ __('locale.Status') }}</label>
                                            <select class="form-select" id="status" name="status">
                                                <option value="" disabled>{{ __('locale.select-option') }}
                                                </option>
                                                <option value="1">{{ __('locale.Approved') }}</option>
                                                <option value="2">{{ __('locale.Rejected') }}</option>
                                                <!-- Add more status options as needed -->
                                            </select>
                                        </div>
                                    </div>

                                    <!-- Due Date -->
                                    <div class="col-xl-6 col-md-6 col-12">
                                        <div class="mb-1">
                                            <label class="form-label"
                                                for="due_date">{{ __('locale.Due Date') }}</label>
                                            <input type="date" class="form-control" id="due_date"
                                                name="due_date">
                                        </div>
                                    </div>

                                    <!-- Comments -->
                                    <div class="col-12">
                                        <div class="mb-1">
                                            <label class="form-label"
                                                for="comments">{{ __('locale.Comments') }}</label>
                                            <textarea class="form-control" id="comments" name="comments" rows="2"></textarea>
                                        </div>
                                    </div>
                                    <div class="mb-1">
                                        <label class="form-label">{{ __("locale.KRI'S") }}</label>
                                        <div id="corrective_action_plan_editor" style="height:100px;">
                                            {!! isset($remediationDetails) ? $remediationDetails->corrective_action_plan : '' !!}
                                        </div>
                                    </div>
                                    <input type="hidden" name="corrective_action_plan"
                                        id="corrective_action_plan_hidden">

                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary"
                                data-bs-dismiss="modal">{{ __('locale.Close') }}</button>
                            <button type="button" class="btn btn-primary"
                                id="saveChangesBtnRemidation">{{ __('locale.Save Changes') }}</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="exportModal" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">{{ __('locale.Export Remediation') }}</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>

                        {{-- Form starts here --}}
                        <form id="exportForm" method="POST"
                            action="{{ route('admin.compliance.remediation.export') }}">
                            @csrf

                            <div class="modal-body">
                                {{-- Framework --}}
                                <div class="mb-1">
                                    <label class="form-label">{{ __('locale.Framework') }}</label>
                                    <select class="form-select" id="frameworkSelect" name="framework_id" required>
                                        <option value="">{{ __('locale.select-option') }}</option>
                                        @foreach ($frameworks as $framework)
                                            <option value="{{ $framework->id }}">
                                                {{ $framework->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                {{-- Audit --}}
                                <div class="mb-1">
                                    <label class="form-label">{{ __('locale.Audit') }}</label>
                                    <select class="form-select" id="auditSelect" name="audit_id" disabled required>
                                        <option value="">{{ __('locale.select-option') }}</option>
                                        @foreach ($frameworks as $framework)
                                            @foreach ($framework->audits as $audit)
                                                <option value="{{ $audit->id }}"
                                                    data-framework="{{ $framework->id }}" style="display:none">
                                                    {{ $audit->audit_name }}
                                                </option>
                                            @endforeach
                                        @endforeach
                                    </select>
                                </div>
                            </div>

                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                    {{ __('locale.Close') }}
                                </button>
                                <button type="submit" class="btn btn-primary" id="submitExportBtn">
                                    <span class="btn-text">{{ __('locale.Export') }}</span>
                                    <span class="btn-loading" style="display:none;">
                                        <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                                        {{ __('locale.Exporting') }}
                                    </span>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>


</section>
@endsection
@section('vendor-script')

<script src="{{ asset(mix('vendors/js/tables/datatable/jquery.dataTables.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.bootstrap5.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.responsive.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/responsive.bootstrap5.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/datatables.checkboxes.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/pickers/flatpickr/flatpickr.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/pickers/pickadate/picker.js')) }}"></script>ad
<script src="{{ asset(mix('vendors/js/pickers/pickadate/picker.date.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/pickers/pickadate/picker.time.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/pickers/pickadate/legacy.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>
<!-- BlockUI Plugin -->

@endsection
@section('page-script')
<script src="{{ asset(mix('js/scripts/forms/form-select2.js')) }}"></script>
<script src="{{ asset(mix('js/scripts/forms/pickers/form-pickers.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
<script src="{{ asset('ajax-files/compliance/define-test.js') }}"></script>
<script src="{{ asset('/js/scripts/forms/form-repeater.js') }}"></script>
<script src="{{ asset('/vendors/js/forms/repeater/jquery.repeater.min.js') }}"></script>
<script src="{{ asset('cdn/jquery.blockUI.min.js') }}"></script>
<script>
    function makeAlert($status, message, title) {
        // On load Toast
        if (title == 'Success')
            title = '👋' + title;
        toastr[$status](message, title, {
            closeButton: true,
            tapToDismiss: false
        });
    };

    $(document).ready(function() {
        var table = $('#dataTableREfresh').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: '{{ route('admin.compliance.remediation.list') }}',
                type: 'GET',
                data: function(d) {
                    d._token = '{{ csrf_token() }}'; // Add CSRF token if required
                    d.framework_id = $('#frameworkSelect')
                        .val(); // Example: get value from a select input
                    d.status = $('#statusSelect').val(); // Example: get value from a select input
                }
            },
            columns: [{
                    data: 'responsible_user_name',
                    name: 'responsible_user_name'
                },
                {
                    data: 'corrective_action_plan',
                    name: 'corrective_action_plan'
                },
                {
                    data: 'budgetary',
                    name: 'budgetary'
                },
                {
                    data: 'status',
                    name: 'status',
                    render: function(data, type, row) {
                        // Render the status column based on its value
                        switch (data) {
                            case 1:
                                return '<span class="badge rounded-pill badge-light-success">{{ __('locale.Approved') }}</span>';
                            case 2:
                                return '<span class="badge rounded-pill badge-light-danger">{{ __('locale.Rejected') }}</span>';
                            default:
                                return 'Unknown'; // Or any default text you prefer
                        }
                    }
                },
                {
                    data: 'due_date',
                    name: 'due_date'
                },
                {
                    data: 'comments',
                    name: 'comments'
                },
                {
                    data: 'control_name',
                    name: 'control_name'
                },
                {
                    data: 'actions',
                    name: 'actions',
                    orderable: false,
                    searchable: false
                }
            ]
        });

        // Fetch details when edit button is clicked
        $('#dataTableREfresh').on('click', '.edit-btn', function() {
            var id = $(this).data('id');
            // AJAX request to fetch the details of the selected remediation
            $.ajax({
                url: '{{ route('admin.compliance.remediation.details') }}', // Adjust route as needed
                type: 'GET',
                data: {
                    id: id,
                    _token: '{{ csrf_token() }}'
                },
                success: function(response) {
                    // Populate the modal with the fetched data
                    $('#corrective_action_plan_hidden').val(response
                        .corrective_action_plan);
                    quill.root.innerHTML = response
                        .corrective_action_plan; // Populate the Quill editor
                    $('#budgetary').val(response.budgetary);
                    $('#status').val(response.status);
                    $('#due_date').val(response.due_date);
                    $('#comments').val(response.comments);
                    $('#remediationForm').data('id', id);

                    // Open the modal
                    $('#remediationModal').modal('show');
                },
                error: function(xhr) {
                    console.log('An error occurred:', xhr.responseText);
                }
            });
        });

        var quill = new Quill('#corrective_action_plan_editor', {
            theme: 'snow',
            modules: {
                toolbar: [
                    [{
                        'header': [1, 2, 3, 4, 5, 6, false]
                    }],
                    ['bold', 'italic', 'underline', 'strike'],
                    [{
                        'list': 'ordered'
                    }, {
                        'list': 'bullet'
                    }],
                    [{
                        'indent': '-1'
                    }, {
                        'indent': '+1'
                    }],
                    [{
                        'direction': 'rtl'
                    }],
                    ['clean'],
                ],
            },
        });

        $('#saveChangesBtnRemidation').click(function() {
            var correctiveActionPlan = quill.root.innerHTML;
            // Store the HTML content in the hidden input field
            $('#corrective_action_plan_hidden').val(correctiveActionPlan);

            // Prepare the form data
            var form = $('#remediationForm').serialize();
            var id = $('#remediationForm').data('id'); // Get the ID from the form data

            // Send AJAX request to update the remediation details
            $.ajax({
                url: '{{ route('admin.compliance.remediation.update') }}', // Adjust route as needed
                type: 'POST',
                data: form + '&id=' + id, // Add the ID to the data
                success: function(response) {
                    $('#remediationModal').modal('hide');
                    $('#dataTableREfresh').DataTable()
                        .draw(); // Refresh DataTables with updated data
                    makeAlert('success', 'Remediation details updated successfully.',
                        'Success');
                },
                error: function(xhr) {
                    // Check if the error is a validation error (422 Unprocessable Entity)
                    if (xhr.status === 422) {
                        var errors = xhr.responseJSON.errors;
                        var errorMessage = '';

                        // Collect all error messages
                        $.each(errors, function(key, value) {
                            errorMessage += value.join(' ') +
                                '\n'; // Concatenate all error messages
                        });

                        makeAlert('error', errorMessage, 'Validation Error');
                    } else {
                        makeAlert('error',
                            'An error occurred while updating the remediation details.',
                            'Error');
                    }
                }
            });
        });

    });

    // Open modal
    $('#exportBtn').on('click', function() {
        $('#exportModal').modal('show');

        // Reset form
        $('#exportForm')[0].reset();
        $('#auditSelect').prop('disabled', true).find('option[data-framework]').hide();
    });

    // Change framework → show related audits only
    $('#frameworkSelect').on('change', function() {
        const frameworkId = $(this).val();
        const auditSelect = $('#auditSelect');

        auditSelect.val('');
        auditSelect.find('option[data-framework]').hide();

        if (!frameworkId) {
            auditSelect.prop('disabled', true);
            return;
        }

        auditSelect.find(`option[data-framework="${frameworkId}"]`).show();
        auditSelect.prop('disabled', false);
    });

    // Handle export form submission
    $('#exportForm').on('submit', function(e) {
        e.preventDefault();
        
        // Get form data
        var frameworkId = $('#frameworkSelect').val();
        var auditId = $('#auditSelect').val();

        // Validation
        if (!frameworkId || !auditId) {
            makeAlert('error', '{{ __('locale.Please select both Framework and Audit') }}', 'Error');
            return;
        }

        // Update button state
        const submitBtn = $('#submitExportBtn');
        submitBtn.prop('disabled', true);
        submitBtn.find('.btn-text').hide();
        submitBtn.find('.btn-loading').show();
        
        // Hide modal
        $('#exportModal').modal('hide');

        // Prepare data for AJAX request
        var formData = new FormData(this);
        
        // AJAX request to generate and download Excel
        $.ajax({
            url: '{{ route('admin.compliance.remediation.export') }}',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            xhrFields: {
                responseType: 'blob' // Important for file download
            },
            beforeSend: function() {
                $.blockUI({
                    message: '<div class="d-flex justify-content-center align-items-center"><p class="me-50 mb-0">{{ __("locale.PleaseWaitAction", ["action" => __("locale.Exporting")]) }}</p> <div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                    css: {
                        backgroundColor: 'transparent',
                        color: '#fff',
                        border: '0'
                    },
                    overlayCSS: {
                        opacity: 0.5
                    }
                });
            },
            complete: function() {
                $.unblockUI();
                // Reset button state
                submitBtn.prop('disabled', false);
                submitBtn.find('.btn-text').show();
                submitBtn.find('.btn-loading').hide();
            },
            success: function(blob, status, xhr) {
                // Create download link
                var url = window.URL.createObjectURL(blob);
                var a = document.createElement('a');
                a.href = url;
                
                // Extract filename from Content-Disposition header if available
                var filename = 'Remediation_Export_' + frameworkId + '_' + auditId + '.xlsx';
                
                // Try to get filename from response headers
                try {
                    var disposition = xhr.getResponseHeader('Content-Disposition');
                    if (disposition && disposition.indexOf('attachment') !== -1) {
                        var filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
                        var matches = filenameRegex.exec(disposition);
                        if (matches != null && matches[1]) {
                            filename = matches[1].replace(/['"]/g, '');
                        }
                    }
                } catch(e) {
                    // If we can't get headers, use default filename
                }
                
                a.download = filename;
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
                document.body.removeChild(a);
                
                // Show success message
                makeAlert('success', '{{ __("locale.Export completed successfully!") }}', 'Success');
            },
            error: function(xhr, status, error) {
                // Show error message
                if (xhr.status === 422) {
                    var errors = xhr.responseJSON.errors;
                    var errorMessage = '';
                    
                    $.each(errors, function(key, value) {
                        errorMessage += value.join(' ') + '\n';
                    });
                    
                    makeAlert('error', errorMessage, 'Validation Error');
                } else if (xhr.status === 404) {
                    makeAlert('error', '{{ __("locale.No data found for export.") }}', 'Error');
                } else {
                    makeAlert('error', '{{ __("locale.An error occurred during export. Please try again.") }}', 'Error');
                }
                
                console.error('Export error:', error);
            }
        });
    });

    // Close modal handler
    $('#exportModal').on('hidden.bs.modal', function() {
        // Reset form
        $('#exportForm')[0].reset();
        $('#auditSelect').prop('disabled', true).find('option[data-framework]').hide();
        
        // Reset button state (in case modal was closed before AJAX completed)
        const submitBtn = $('#submitExportBtn');
        submitBtn.prop('disabled', false);
        submitBtn.find('.btn-text').show();
        submitBtn.find('.btn-loading').hide();
    });
</script>


@endsection