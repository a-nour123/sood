@extends('admin/layouts/contentLayoutMaster')

@section('title', __('incident.incident'))

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/flatpickr/flatpickr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/dataTables.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
@endsection

@section('page-style')
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/forms/pickers/form-flat-pickr.css')) }}">
    <style>
        /* Simplified Color Variables */
        /* Additional CSS for Arabic Export Support - Add this to your page-style section */

/* Preload Arabic fonts for better rendering */
@import url('{{ asset('cdn/css2.css') }}');

/* Ensure Arabic text uses proper fonts when exporting */
.exporting {
    direction: inherit;
}

.exporting [dir="rtl"] {
    direction: rtl !important;
}

/* FIXED: Ensure proper font rendering for Arabic with unicode-bidi */
@if (app()->getLocale() === 'ar')
    body,
    html,
    * {
        font-family: "Cairo", "Amiri", "Segoe UI", Tahoma, Arial, "DejaVu Sans", sans-serif !important;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        text-rendering: optimizeLegibility;
        unicode-bidi: embed !important;
    }

    h1, h2, h3, h4, h5, h6, .fw-600, .fw-700,
    .section-title, .metric-label, .kpi-label,
    .card-header h4, .card-header p, 
    .dashboard-card .card-header h4,
    .dashboard-card .card-header p {
        font-family: "Cairo", "Amiri", "Segoe UI", Tahoma, Arial, "DejaVu Sans", sans-serif !important;
        -webkit-font-smoothing: antialiased !important;
        -moz-osx-font-smoothing: grayscale !important;
        text-rendering: optimizeLegibility !important;
        letter-spacing: normal !important;
        word-spacing: normal !important;
        font-feature-settings: "liga" 1, "kern" 1 !important;
        -webkit-font-feature-settings: "liga" 1, "kern" 1 !important;
        -moz-font-feature-settings: "liga" 1, "kern" 1 !important;
        unicode-bidi: embed !important;
        direction: rtl !important;
        text-align: right !important;
    }

    /* FIXED: Fix icon direction and display in RTL */
    [class*="fa-"],
    .fa,
    i[class*="fa"],
    .card-header i,
    .dashboard-card .card-header i {
        direction: ltr !important;
        display: inline-block !important;
        unicode-bidi: bidi-override !important;
        font-family: "Font Awesome 6 Free", "Font Awesome 6 Pro" !important;
        font-weight: 900 !important;
        vertical-align: middle !important;
    }

    /* FIXED: Proper spacing between icons and text in RTL */
    .card-header h4 i,
    .dashboard-card .card-header h4 i,
    h4 i.fa,
    h4 i[class*="fa-"] {
        margin-left: 0.5rem !important;
        margin-right: 0 !important;
        float: right !important;
    }

    /* Ensure card header content flows correctly */
    .dashboard-card .card-header {
        direction: rtl !important;
        text-align: right !important;
    }

    /* Fix badge alignment in RTL */
    .dashboard-card .card-header .badge {
        margin-right: auto !important;
        margin-left: 0 !important;
    }
@endif

/* Ensure charts are visible during export */
.exporting [id$="chart"],
.exporting [id*="Chart"],
.exporting [id$="-chart"],
.exporting .chart-container {
    visibility: visible !important;
    display: block !important;
    opacity: 1 !important;
}

/* Print-specific styles */
@media print {
    body {
        background: white;
    }

    .dashboard-card,
    .chart-container,
    .kpi-card,
    .metric-card {
        box-shadow: none !important;
        border: 1px solid #ddd;
        page-break-inside: avoid;
    }

    /* Hide export buttons when printing */
    .btn,
    .filter-section {
        display: none !important;
    }

    /* Ensure proper page breaks */
    .row.mb-4 {
        page-break-inside: avoid;
    }
}
        :root {
            --primary: #3498db;
            --primary-light: #ebf5fb;
            --primary-dark: #2980b9;
            --secondary: #2c3e50;
            --success: #27ae60;
            --success-light: #d5f4e6;
            --warning: #f39c12;
            --warning-light: #fef5e7;
            --danger: #e74c3c;
            --danger-light: #fdedec;
            --info: #3498db;
            --gray: #95a5a6;
            --light-gray: #ecf0f1;
            --dark: #2c3e50;
            --light: #f8f9fa;
            --white: #ffffff;
            --border: #dfe6e9;
            --shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            --shadow-md: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        /* Base Container */
        .dashboard-container {
            padding: 20px;
            background-color: var(--light-gray);
            min-height: 100vh;
        }

        /* Filter Section */
        .filter-section {
            background: var(--white);
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 25px;
            border: 1px solid var(--border);
            box-shadow: var(--shadow);
        }

        .filter-section .form-label {
            font-weight: 600;
            color: var(--dark);
            margin-bottom: 8px;
            font-size: 14px;
        }

        .filter-section .form-control {
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 10px 15px;
            font-size: 14px;
            height: 42px;
        }

        .filter-section .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.2);
        }

        .filter-section .btn {
            border-radius: 8px;
            padding: 10px 20px;
            font-weight: 600;
            font-size: 14px;
            height: 42px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            border: none;
        }

        .filter-section .btn-primary {
            background-color: var(--primary);
        }

        .filter-section .btn-primary:hover {
            background-color: var(--primary-dark);
            transform: translateY(-1px);
        }

        .filter-section .btn-outline-secondary {
            border: 1px solid var(--border);
            color: var(--gray);
            background: transparent;
        }

        .filter-section .btn-outline-secondary:hover {
            border-color: var(--primary);
            color: var(--primary);
        }

        .filter-section .btn-success {
            background-color: var(--success);
        }

        .filter-section .btn-success:hover {
            background-color: #229954;
            transform: translateY(-1px);
        }

        /* KPI Cards */
        .kpi-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin-bottom: 25px;
        }

        .kpi-card {
            background: var(--white);
            border-radius: 10px;
            padding: 20px;
            border: 1px solid var(--border);
            box-shadow: var(--shadow);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .kpi-card:hover {
            transform: translateY(-3px);
            box-shadow: var(--shadow-md);
        }

        .kpi-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
            background-color: var(--primary);
        }

        .kpi-value {
            font-size: 2.5rem;
            font-weight: 700;
            line-height: 1;
            margin-bottom: 8px;
            color: var(--dark);
        }

        .kpi-label {
            font-size: 14px;
            color: var(--gray);
            font-weight: 500;
            margin-bottom: 10px;
        }

        .kpi-trend {
            display: inline-block;
            padding: 4px 12px;
            background-color: var(--primary-light);
            color: var(--primary);
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        /* Report Cards */
        .dashboard-card {
            background: var(--white);
            border-radius: 10px;
            margin-bottom: 25px;
            border: 1px solid var(--border);
            box-shadow: var(--shadow);
            overflow: hidden;
        }

        .dashboard-card .card-header {
            padding: 20px;
            background: var(--white);
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .dashboard-card .card-header h4 {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--dark);
            margin: 0;
        }

        .dashboard-card .card-header p {
            color: var(--gray);
            font-size: 14px;
            margin-top: 5px;
            margin-bottom: 0;
        }

        .dashboard-card .card-body {
            padding: 20px;
        }

        /* Metric Cards */
        .metric-card {
            background: var(--white);
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            border: 1px solid var(--border);
            box-shadow: var(--shadow);
            transition: all 0.3s ease;
            margin-bottom: 15px;
        }

        .metric-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
        }

        .metric-icon {
            width: 50px;
            height: 50px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            font-size: 20px;
            color: var(--white);
        }

        .metric-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--dark);
            line-height: 1;
            margin-bottom: 8px;
        }

        .metric-label {
            font-size: 14px;
            color: var(--gray);
            font-weight: 500;
        }

        /* Chart Containers */
        .chart-container {
            background: var(--white);
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            border: 1px solid var(--border);
            box-shadow: var(--shadow);
        }

        .chart-container h6 {
            color: var(--dark);
            font-weight: 600;
            margin-bottom: 15px;
            font-size: 16px;
        }

        /* Critical Cards */
        .critical-card {
            background: var(--white);
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            border-left: 4px solid var(--danger);
            border: 1px solid var(--border);
            box-shadow: var(--shadow);
        }

        /* Executive Summary */
        .executive-summary {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: var(--white);
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 25px;
        }

        /* Status Badges */
        .status-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .status-open {
            background-color: var(--primary);
            color: white;
        }

        .status-progress {
            background-color: var(--warning);
            color: white;
        }

        .status-closed {
            background-color: var(--success);
            color: white;
        }

        .status-critical {
            background-color: var(--danger);
            color: white;
        }

        /* Data Tables */
        .data-table {
            width: 100%;
            border-collapse: collapse;
        }

        .data-table thead th {
            background-color: var(--primary);
            color: white;
            font-weight: 600;
            padding: 12px 15px;
            text-align: left;
            border: none;
        }

        .data-table tbody td {
            padding: 12px 15px;
            border-bottom: 1px solid var(--border);
            vertical-align: middle;
        }

        .data-table tbody tr:hover {
            background-color: var(--light-gray);
        }

        /* Utility Classes */
        .color-primary {
            color: var(--primary);
        }

        .color-success {
            color: var(--success);
        }

        .color-warning {
            color: var(--warning);
        }

        .color-danger {
            color: var(--danger);
        }

        .color-info {
            color: var(--info);
        }

        .color-dark {
            color: var(--dark);
        }

        .color-gray {
            color: var(--gray);
        }

        .bg-primary-light {
            background-color: var(--primary-light);
        }

        .bg-success-light {
            background-color: var(--success-light);
        }

        .bg-warning-light {
            background-color: var(--warning-light);
        }

        .bg-danger-light {
            background-color: var(--danger-light);
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .dashboard-container {
                padding: 10px;
            }

            .kpi-grid {
                grid-template-columns: 1fr;
            }

            .filter-section {
                padding: 15px;
            }

            .filter-section .row>div {
                margin-bottom: 15px;
            }

            .filter-section .d-flex {
                flex-direction: column;
                gap: 10px;
            }

            .filter-section .btn {
                width: 100%;
            }

            .dashboard-card .card-header,
            .dashboard-card .card-body {
                padding: 15px;
            }

            .chart-container {
                padding: 15px;
            }
        }

        /* Print Styles */
        @media print {

            .filter-section,
            .btn,
            .no-print {
                display: none !important;
            }

            .dashboard-container {
                padding: 0;
                background: white !important;
            }

            .dashboard-card {
                box-shadow: none !important;
                border: 1px solid #ddd !important;
                margin-bottom: 20px !important;
                break-inside: avoid;
            }
        }
    </style>
@endsection


@section('content')
    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">
            <div class="row breadcrumbs-top widget-grid">
                <div class="col-12">
                    <div class="page-title mt-2">
                        <div class="row">
                            <div class="col-sm-6 ps-0">
                                @if (@isset($breadcrumbs))
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item">
                                            <a href="{{ route('admin.dashboard') }}" style="display: flex;">
                                                <svg class="stroke-icon">
                                                    <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}">
                                                    </use>
                                                </svg>
                                            </a>
                                        </li>
                                        @foreach ($breadcrumbs as $breadcrumb)
                                            <li class="breadcrumb-item">
                                                @if (isset($breadcrumb['link']))
                                                    <a
                                                        href="{{ $breadcrumb['link'] == 'javascript:void(0)' ? $breadcrumb['link'] : url($breadcrumb['link']) }}">
                                                @endif
                                                {{ $breadcrumb['name'] }}
                                                @if (isset($breadcrumb['link']))
                                                    </a>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ol>
                                @endisset
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Filter Section -->
<div class="filter-section">
    <div class="row align-items-center">
        <div class="col-md-8">
            <div class="row">
                <div class="col-md-5 mb-2">
                    <label class="form-label fw-500 color-primary">{{ __('incident.DetectionDateFrom') }}</label>
                    <input type="date" id="filterDateFrom" class="form-control shadow-sm">
                </div>
                <div class="col-md-5 mb-2">
                    <label class="form-label fw-500 color-primary">{{ __('incident.DetectionDateTo') }}</label>
                    <input type="date" id="filterDateTo" class="form-control shadow-sm">
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="d-flex gap-2">
                <button id="filterBtn"
                    class="btn btn-primary flex-fill d-flex align-items-center justify-content-center gap-2">
                    <i class="fa fa-search"></i>
                    <span>{{ __('incident.FilterData') }}</span>
                </button>
                <button id="resetBtn" title="{{ __('incident.ResetFilters') }}"
                    class="btn btn-outline-secondary d-flex align-items-center justify-content-center gap-2">
                    <i class="fa fa-refresh"></i>
                </button>
                <button id="exportReportBtn" onclick="exportToPDF()" title="{{ __('incident.ExportReport') }}"
                    class="btn btn-success d-flex align-items-center justify-content-center gap-2">
                    <i class="fa fa-file-pdf"></i>
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Incident Overview Cards -->
<div class="row mb-4">
    <div class="col-md-3 col-sm-6">
        <div class="kpi-card" style="background: var(--primary-gradient);">
            <div class="kpi-content">
                <div class="kpi-value animate__animated animate__fadeIn" data-counter="overall">{{ $incident_count }}
                </div>
                <div class="kpi-label">{{ __('incident.TotalIncidents') }}</div>
                <div class="kpi-trend">
                    <i class="fa fa-chart-line me-1"></i> {{ __('incident.Overview') }}
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-3 col-sm-6">
        <div class="kpi-card" style="background: var(--info-gradient);">
            <div class="kpi-content">
                <div class="kpi-value animate__animated animate__fadeIn" data-counter="open">{{ $open_incident_count }}
                </div>
                <div class="kpi-label">{{ __('incident.OpenIncidents') }}</div>
                <div class="kpi-trend">{{ __('incident.Active') }}</div>
            </div>
        </div>
    </div>

    <div class="col-md-3 col-sm-6">
        <div class="kpi-card" style="background: var(--warning-gradient);">
            <div class="kpi-content">
                <div class="kpi-value animate__animated animate__fadeIn" data-counter="progress">
                    {{ $progress_incident_count }}</div>
                <div class="kpi-label">{{ __('incident.InProgress') }}</div>
                <div class="kpi-trend">{{ __('incident.Processing') }}</div>
            </div>
        </div>
    </div>

    <div class="col-md-3 col-sm-6">
        <div class="kpi-card" style="background: var(--success-gradient);">
            <div class="kpi-content">
                <div class="kpi-value animate__animated animate__fadeIn" data-counter="closed">
                    {{ $closed_incident_count }}</div>
                <div class="kpi-label">{{ __('incident.ClosedIncidents') }}</div>
                <div class="kpi-trend">{{ __('incident.Resolved') }}</div>
            </div>
        </div>
    </div>
</div>

<!-- REPORT 1: Alerts and Security Incidents Summary -->
<div class="row mb-4">
    <div class="col-12">
        <div class="dashboard-card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <div>
                    <h4 class="mb-0 fw-600">
                        <i class="fa fa-shield-alt me-2 color-primary"></i>
                        {{ __('incident.SecurityAlertsIncidentsReport') }}
                    </h4>
                    <p class="text-muted mb-0">{{ __('incident.ComprehensiveOverviewSecurityEvents') }}</p>
                </div>
                <span class="badge bg-primary fs-6">{{ __('incident.RealTime') }}</span>
            </div>
            <div class="card-body">
                <div class="row mb-4">
                    <div class="col-md-4">
                        <div class="metric-card">
                            <div class="metric-icon" style="background: rgba(102, 126, 234, 0.1); color: #667eea;">
                                <i class="fa fa-bell"></i>
                            </div>
                            <div class="metric-value" id="alerts-total">{{ $alertsReportData['total_alerts'] }}</div>
                            <div class="metric-label">{{ __('incident.TotalAlertsIncidents') }}</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="metric-card">
                            <div class="metric-icon" style="background: rgba(52, 195, 143, 0.1); color: #34c38f;">
                                <i class="fa fa-check-double"></i>
                            </div>
                            <div class="metric-value" id="alerts-actions">{{ $alertsReportData['actions_taken'] }}
                            </div>
                            <div class="metric-label">{{ __('incident.ActionsTaken') }}</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="metric-card">
                            <div class="metric-icon" style="background: rgba(248, 170, 75, 0.1); color: #f8aa4b;">
                                <i class="fa fa-clock"></i>
                            </div>
                            <div class="metric-value">{{ round($alertsReportData['avg_response_time'] ?? 0, 1) }}h
                            </div>
                            <div class="metric-label">{{ __('incident.AvgResponseTime') }}</div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="chart-container">
                            <h6 class="fw-600 mb-3">{{ __('incident.SeverityDistribution') }}</h6>
                            <div id="severity-chart" style="height: 250px;"></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="chart-container">
                            <h6 class="fw-600 mb-3">{{ __('incident.StatusBreakdown') }}</h6>
                            <div id="status-breakdown-chart" style="height: 250px;"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- REPORT 2: Performance Comparison Report -->
<div class="row mb-4">
    <div class="col-12">
        <div class="dashboard-card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <div>
                    <h4 class="mb-0 fw-600">
                        <i class="fa fa-chart-line me-2 color-warning"></i>
                        {{ __('incident.PerformanceComparisonReport') }}
                    </h4>
                    <p class="text-muted mb-0">{{ __('incident.MonthlyPerformanceSLAAnalysis') }}</p>
                </div>
                <span class="badge bg-warning fs-6">{{ __('incident.Trending') }}</span>
            </div>
            <div class="card-body">
                <div class="row mb-4">
                    <div class="col-md-3 col-sm-6">
                        <div class="metric-card">
                            <div class="metric-icon" style="background: rgba(102, 126, 234, 0.1); color: #667eea;">
                                <i class="fa fa-calendar-alt"></i>
                            </div>
                            <div class="metric-value" id="perf-current">
                                {{ $performanceReportData['current_month_count'] }}</div>
                            <div class="metric-label">{{ __('incident.CurrentMonth') }}</div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="metric-card">
                            <div class="metric-icon" style="background: rgba(108, 117, 125, 0.1); color: #6c757d;">
                                <i class="fa fa-calendar"></i>
                            </div>
                            <div class="metric-value" id="perf-previous">
                                {{ $performanceReportData['previous_month_count'] }}</div>
                            <div class="metric-label">{{ __('incident.PreviousMonth') }}</div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="metric-card">
                            <div class="metric-icon"
                                style="background: {{ $performanceReportData['percentage_change'] > 0 ? 'rgba(244, 106, 106, 0.1)' : 'rgba(52, 195, 143, 0.1)' }}; color: {{ $performanceReportData['percentage_change'] > 0 ? '#f46a6a' : '#34c38f' }};">
                                <i
                                    class="fa {{ $performanceReportData['percentage_change'] > 0 ? 'fa-arrow-up' : 'fa-arrow-down' }}"></i>
                            </div>
                            <div class="metric-value {{ $performanceReportData['percentage_change'] > 0 ? 'color-danger' : 'color-success' }}"
                                id="perf-change">
                                {{ $performanceReportData['percentage_change'] > 0 ? '+' : '' }}{{ $performanceReportData['percentage_change'] }}%
                            </div>
                            <div class="metric-label">{{ __('incident.ChangeRate') }}</div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="metric-card">
                            <div class="metric-icon" style="background: rgba(52, 195, 143, 0.1); color: #34c38f;">
                                <i class="fa fa-bullseye"></i>
                            </div>
                            <div class="metric-value color-success" id="perf-sla">
                                {{ $performanceReportData['sla_compliance'] }}%</div>
                            <div class="metric-label">{{ __('incident.SLACompliance') }}</div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-8">
                        <div class="chart-container">
                            <h6 class="fw-600 mb-3">{{ __('incident.MostAffectedAssetsSystems') }}</h6>
                            <div id="affected-assets-chart" style="height: 300px;"></div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="chart-container">
                            <h6 class="fw-600 mb-3">{{ __('incident.ResponseMetrics') }}</h6>
                            <div class="mb-3">
                                <div class="d-flex justify-content-between mb-2">
                                    <span class="text-muted">{{ __('incident.AvgResponseTime') }}:</span>
                                    <strong
                                        class="color-primary">{{ $performanceReportData['avg_response_time'] ?? 0 }}h</strong>
                                </div>
                                <div class="progress" style="height: 8px;">
                                    <div class="progress-bar bg-primary"
                                        style="width: {{ min(($performanceReportData['avg_response_time'] ?? 0) * 10, 100) }}%">
                                    </div>
                                </div>
                            </div>
                            <div class="mb-3">
                                <div class="d-flex justify-content-between mb-2">
                                    <span class="text-muted">{{ __('incident.AvgClosureTime') }}:</span>
                                    <strong
                                        class="color-success">{{ $performanceReportData['avg_closure_time'] ?? 0 }}h</strong>
                                </div>
                                <div class="progress" style="height: 8px;">
                                    <div class="progress-bar bg-success"
                                        style="width: {{ min(($performanceReportData['avg_closure_time'] ?? 0) * 5, 100) }}%">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- REPORT 3: Compliance and Documentation Report -->
<div class="row mb-4">
    <div class="col-12">
        <div class="dashboard-card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <div>
                    <h4 class="mb-0 fw-600">
                        <i class="fa fa-clipboard-check me-2 color-success"></i>
                        {{ __('incident.ComplianceDocumentationReport') }}
                    </h4>
                    <p class="text-muted mb-0">{{ __('incident.DocumentationComplianceProcedureAnalysis') }}</p>
                </div>
                <span class="badge bg-success fs-6">{{ __('incident.Compliance') }}</span>
            </div>
            <div class="card-body">
                <div class="row mb-4">
                    <div class="col-md-3 col-sm-6">
                        <div class="metric-card">
                            <div class="metric-value" id="comp-total">{{ $complianceReportData['total_incidents'] }}
                            </div>
                            <div class="metric-label">{{ __('incident.TotalIncidents') }}</div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="metric-card">
                            <div class="metric-value color-info">
                                {{ $complianceReportData['documentation_compliance'] }}%</div>
                            <div class="metric-label">{{ __('incident.DocumentationRate') }}</div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="metric-card">
                            <div class="metric-value color-warning">
                                {{ $complianceReportData['procedure_compliance'] }}%</div>
                            <div class="metric-label">{{ __('incident.ProcedureAdherence') }}</div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="metric-card">
                            <div class="metric-value color-danger" id="comp-recurring">
                                {{ count($complianceReportData['recurring_incidents']) }}</div>
                            <div class="metric-label">{{ __('incident.RecurringIncidents') }}</div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="chart-container">
                            <h6 class="fw-600 mb-3">{{ __('incident.RecurringIncidentsAnalysis') }}</h6>
                            <div id="recurring-incidents-chart" style="height: 300px;"></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="chart-container">
                            <h6 class="fw-600 mb-3">{{ __('incident.ImprovementRecommendations') }}</h6>
                            <div class="list-group list-group-flush">
                                @foreach ($complianceReportData['recommendations'] as $index => $recommendation)
                                    <div class="list-group-item border-0 px-0 py-2">
                                        <div class="d-flex">
                                            <span class="badge bg-primary me-3"
                                                style="width: 30px; height: 30px; display: flex; align-items: center; justify-content: center;">{{ $index + 1 }}</span>
                                            <div class="flex-grow-1">
                                                <p class="mb-0">{{ $recommendation }}</p>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- REPORT 4: Critical Incidents Detailed Report -->
<div class="row mb-4">
    <div class="col-12">
        <div class="dashboard-card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <div>
                    <h4 class="mb-0 fw-600">
                        <i class="fa fa-exclamation-triangle me-2 color-danger"></i>
                        {{ __('incident.CriticalIncidentsReport') }}
                    </h4>
                    <p class="text-muted mb-0">{{ __('incident.DetailedCriticalIncidentsAnalysis') }}</p>
                </div>
                <span class="badge bg-danger fs-6">{{ __('incident.Critical') }}</span>
            </div>
            <div class="card-body">
                <div class="alert alert-danger glass-effect d-flex align-items-center">
                    <i class="fa fa-info-circle fa-2x me-3"></i>
                    <div>
                        <h6 class="alert-heading mb-1">{{ __('incident.AttentionRequired') }}</h6>
                        <p class="mb-0">
                            {{ __('incident.ReportContainsCriticalIncidents', ['count' => count($criticalIncidentsData)]) }}
                        </p>
                    </div>
                </div>

                <div class="row">
                    @foreach ($criticalIncidentsData as $critical)
                        <div class="col-md-6 mb-3">
                            <div class="critical-card p-3">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <div>
                                        <span class="badge bg-danger mb-2">{{ $critical['classification'] }}</span>
                                        <h6 class="fw-600 mb-1">{{ $critical['summary'] }}</h6>
                                        <small class="text-muted">Incident ID: {{ $critical['id'] }}</small>
                                    </div>
                                    <span
                                        class="badge bg-{{ $critical['current_status'] == 'closed' ? 'success' : ($critical['current_status'] == 'progress' ? 'warning' : 'secondary') }}">
                                        {{ ucfirst($critical['current_status']) }}
                                    </span>
                                </div>

                                <div class="row g-2 mb-3">
                                    <div class="col-6">
                                        <div class="small text-muted">{{ __('incident.AttackType') }}</div>
                                        <div class="fw-500">{{ $critical['attack_type'] }}</div>
                                    </div>
                                    <div class="col-6">
                                        <div class="small text-muted">{{ __('incident.DetectionDate') }}</div>
                                        <div class="fw-500">{{ $critical['detected_on'] }}</div>
                                    </div>
                                    <div class="col-6">
                                        <div class="small text-muted">{{ __('incident.ResponseTime') }}</div>
                                        <div class="fw-500 color-primary">{{ $critical['response_time_hours'] }}
                                            {{ __('incident.Hours') }}
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="small text-muted">{{ __('incident.ClosureTime') }}</div>
                                        <div
                                            class="fw-500 {{ $critical['closure_time_hours'] ? 'color-success' : 'text-muted' }}">
                                            {{ $critical['closure_time_hours'] ?? __('incident.Pending') }}
                                        </div>
                                    </div>
                                </div>

                                @if (count($critical['affected_systems']) > 0)
                                    <div class="mb-2">
                                        <div class="small text-muted mb-1">{{ __('incident.AffectedSystems') }}</div>
                                        <div>
                                            @foreach ($critical['affected_systems'] as $system)
                                                <span class="badge bg-secondary me-1 mb-1">{{ $system }}</span>
                                            @endforeach
                                        </div>
                                    </div>
                                @endif

                                <div class="d-flex justify-content-between mt-3">
                                    <small class="text-muted">TLP: {{ $critical['tlp_level'] }}</small>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</div>

<!-- REPORT 5: Executive Summary Report -->
<div class="row mb-4">
    <div class="col-12">
        <div class="executive-summary">
            <div class="row align-items-center mb-4">
                <div class="col-md-8">
                    <h3 class="fw-700 mb-2">{{ __('incident.ExecutiveDashboard') }}</h3>
                    <p class="opacity-75 mb-0">{{ __('incident.StrategicOverviewKPISecurityOps') }}</p>
                </div>
                <div class="col-md-4 text-end">
                    <span class="badge bg-warning fs-6">{{ __('incident.ExecutiveView') }}</span>
                </div>
            </div>

            <div class="row mb-4">
                @foreach ($executiveSummaryData['kpis'] as $key => $value)
                    <div class="col-md-2 col-sm-4 mb-3">
                        <div class="text-center">
                            <div class="kpi-value mb-1">
                                {{ $value }}{{ $key == 'avg_resolution_time' ? 'h' : ($key == 'sla_compliance_rate' || $key == 'documentation_rate' ? '%' : '') }}
                            </div>
                            <div class="kpi-label">
                                @if ($key == 'total_incidents')
                                    {{ __('incident.TotalIncidents') }}
                                @elseif($key == 'critical_incidents')
                                    {{ __('incident.CriticalIncidents') }}
                                @elseif($key == 'avg_resolution_time')
                                    {{ __('incident.AvgResolution') }}
                                @elseif($key == 'sla_compliance_rate')
                                    {{ __('incident.SLACompliance') }}
                                @elseif($key == 'documentation_rate')
                                    {{ __('incident.DocumentationRate') }}
                                @endif
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="chart-container glass-effect">
                        <h6 class="fw-600 mb-3 text-white">{{ __('incident.PrimaryThreatsAnalysis') }}</h6>
                        <div id="primary-threats-chart" style="height: 250px;"></div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="chart-container glass-effect">
                        <h6 class="fw-600 mb-3 text-white">{{ __('incident.StrategicIndicators') }}</h6>
                        <div id="strategic-indicators-chart" style="height: 250px;"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- REPORT 6: Evidence Analysis Report -->
<div class="row mb-4">
    <div class="col-12">
        <div class="dashboard-card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <div>
                    <h4 class="mb-0 fw-600">
                        <i class="fa fa-search me-2 color-warning"></i>
                        {{ __('incident.EvidenceAnalysisReport') }}
                    </h4>
                    <p class="text-muted mb-0">{{ __('incident.ForensicEvidenceCollectionMetrics') }}</p>
                </div>
                <span class="badge bg-warning fs-6">{{ __('incident.Forensic') }}</span>
            </div>
            <div class="card-body">
                <div class="row mb-4">
                    @foreach ($evidenceAnalysisData['evidence_stats'] as $key => $value)
                        <div class="col-md-3 col-sm-6">
                            <div class="metric-card">
                                <div class="metric-value">
                                    @if ($key == 'evidence_coverage_rate')
                                        {{ round($value, 2) }}%
                                    @else
                                        {{ $value }}
                                    @endif
                                </div>
                                <div class="metric-label">
                                    @if ($key == 'total_evidence_collected')
                                        Total Evidence
                                    @elseif($key == 'incidents_with_evidence')
                                        Incidents with Evidence
                                    @elseif($key == 'evidence_coverage_rate')
                                        Coverage Rate
                                    @endif
                                </div>
                            </div>
                        </div>
                    @endforeach
                    <div class="col-md-3 col-sm-6">
                        <div class="metric-card">
                            <div class="metric-value">{{ round($evidenceAnalysisData['evidence_quality_score'], 2) }}
                            </div>
                            <div class="metric-label"> {{ __('incident.QualityScore') }}</div>
                        </div>
                    </div>
                </div>

                <div class="chart-container">
                    <h6 class="fw-600 mb-3">{{ __('incident.EvidenceCollectionAnalysis') }}</h6>
                    <div class="table-responsive">
                        <table class="table data-table">
                            <thead>
                                <tr>
                                    <th>{{ __('incident.IncidentID') }}</th>
                                    <th>{{ __('incident.Summary') }}</th>
                                    <th>{{ __('incident.Classification') }}</th>
                                    <th>{{ __('incident.EvidenceCount') }}</th>
                                    <th>{{ __('incident.Status') }}</th>
                                    <th>{{ __('incident.DetectionDate') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($evidenceAnalysisData['observed_cases'] as $case)
                                    <tr>
                                        <td><strong>#{{ $case['incident_id'] }}</strong></td>
                                        <td>{{ Str::limit($case['summary'], 50) }}</td>
                                        <td>
                                            <span
                                                class="badge bg-{{ $case['classification'] == 'Critical' ? 'danger' : ($case['classification'] == 'High' ? 'warning' : 'info') }}">
                                                {{ $case['classification'] }}
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge bg-primary">{{ $case['evidence_count'] }}</span>
                                        </td>
                                        <td>
                                            <span class="status-badge status-{{ $case['status'] }}">
                                                {{ $case['status'] }}
                                            </span>
                                        </td>
                                        <td>{{ $case['detection_date'] }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Original Analytics Section -->
<div class="row mb-4">
    <div class="col-12">
        <div class="dashboard-card">
            <div class="card-header">
                <h5 class="fw-600">
                    <i class="fa fa-chart-pie me-2 color-primary"></i>
                    {{ __('incident.DetailedAnalytics') }}
                </h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-4">
                        <div class="chart-container">
                            <h6 class="fw-600 mb-3">{{ __('incident.IncidentClassification') }}</h6>
                            <div id="chart-classification-container" style="height: 300px;"></div>
                        </div>
                    </div>
                    <div class="col-md-6 mb-4">
                        <div class="chart-container">
                            <h6 class="fw-600 mb-3">{{ __('incident.StatusOverTime') }}</h6>
                            <div id="chart-status-over-time" style="height: 300px;"></div>
                        </div>
                    </div>
                    <div class="col-md-6 mb-4">
                        <div class="chart-container">
                            <h6 class="fw-600 mb-3">{{ __('incident.AttackTypeDistribution') }}</h6>
                            <div id="chart-attack-type" style="height: 300px;"></div>
                        </div>
                    </div>
                    <div class="col-md-6 mb-4">
                        <div class="chart-container">
                            <h6 class="fw-600 mb-3">{{ __('incident.DirectionAnalysis') }}</h6>
                            <div id="chart-direction" style="height: 300px;"></div>
                        </div>
                    </div>
                    <div class="col-12 mb-4">
                        <div class="chart-container">
                            <h6 class="fw-600 mb-3">{{ __('incident.PlaybookDistribution') }}</h6>
                            <div id="chart-play-book" style="height: 350px;"></div>
                        </div>
                    </div>
                    <div class="col-md-6 mb-4">
                        <div class="chart-container">
                            <h6 class="fw-600 mb-3">{{ __('incident.TLPLevelDistribution') }}</h6>
                            <div id="chart-tlp-level" style="height: 300px;"></div>
                        </div>
                    </div>
                    <div class="col-md-6 mb-4">
                        <div class="chart-container">
                            <h6 class="fw-600 mb-3">{{ __('incident.PAPLevelDistribution') }}</h6>
                            <div id="chart-pap-level" style="height: 300px;"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

@section('vendor-script')
<script src="{{ asset(mix('vendors/js/tables/datatable/jquery.dataTables.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/pickers/flatpickr/flatpickr.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>

<script src="{{ asset('cdn/html2canvas.min.js') }}"></script>
<script src="{{ asset('cdn/jspdf.umd.min.js') }}"></script>
<script src="{{ asset('cdn/xlsx.full.min.js') }}"></script>
<script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>
@endsection

{{-- Replace the entire @section('page-script') in your graph.blade.php with this complete section --}}

@section('page-script')
<script src="{{ asset('js/scripts/highcharts/highcharts.js') }}"></script>
<script src="{{ asset('js/scripts/highcharts/modules/accessibility.js') }}"></script>

<script>
    // Global variable for report data - accessible throughout the page
    let currentReportData = {};

    $(document).ready(function() {
        // Initialize tooltips
        $('[data-bs-toggle="tooltip"]').tooltip();

        // Store report data globally for filtering
        currentReportData = {
            incident_count: {{ $incident_count }},
            open_incident_count: {{ $open_incident_count }},
            progress_incident_count: {{ $progress_incident_count }},
            closed_incident_count: {{ $closed_incident_count }},
            alertsReportData: @json($alertsReportData),
            performanceReportData: @json($performanceReportData),
            complianceReportData: @json($complianceReportData),
            criticalIncidentsData: @json($criticalIncidentsData),
            executiveSummaryData: @json($executiveSummaryData),
            evidenceAnalysisData: @json($evidenceAnalysisData),
            classificationData: @json($classificationData),
            attackData: @json($attackData),
            directionData: @json($directionData),
            statusOverTimeData: @json($statusOverTimeData),
            tlpData: @json($tlpData),
            papData: @json($papData),
            detectionData: @json($detectionData),
            occurrenceData: @json($occurrenceData),
            playBookData: @json($playBookData),
        };

        // Initialize all charts on page load
        renderAllCharts(currentReportData);

        // Filter functionality with AJAX
        $('#filterBtn').click(function() {
            const from = $('#filterDateFrom').val();
            const to = $('#filterDateTo').val();

            if (!from && !to) {
                Swal.fire({
                    icon: 'warning',
                    title: '{{ __('incident.NoDateSelected') }}',
                    text: '{{ __('incident.SelectAtLeastOneDate') }}',
                    timer: 2000,
                    showConfirmButton: false
                });
                return;
            }

            // Show loading state
            const $btn = $(this);
            $btn.prop('disabled', true).html(
                '<i class="fa fa-spinner fa-spin"></i> {{ __('incident.Loading') }}...');

            // Make AJAX call to filter data
            $.ajax({
                url: "{{ route('admin.incident.statistics.filter') }}",
                data: {
                    from: from,
                    to: to,
                    _token: '{{ csrf_token() }}'
                },
                success: function(response) {
                    console.log('Filter response:', response);

                    // Update current data
                    currentReportData = response;

                    // Update all counters with animation
                    animateValue('[data-counter="overall"]', parseInt($(
                            '[data-counter="overall"]').text()), response
                        .incident_count);
                    animateValue('[data-counter="open"]', parseInt($(
                            '[data-counter="open"]').text()), response
                        .open_incident_count);
                    animateValue('[data-counter="progress"]', parseInt($(
                            '[data-counter="progress"]').text()), response
                        .progress_incident_count);
                    animateValue('[data-counter="closed"]', parseInt($(
                            '[data-counter="closed"]').text()), response
                        .closed_incident_count);

                    // Update all metrics
                    $('#alerts-total').text(response.alertsReportData.total_alerts);
                    $('#alerts-actions').text(response.alertsReportData.actions_taken);
                    $('#perf-current').text(response.performanceReportData
                        .current_month_count);
                    $('#perf-previous').text(response.performanceReportData
                        .previous_month_count);

                    const changeValue = response.performanceReportData.percentage_change;
                    $('#perf-change').text((changeValue > 0 ? '+' : '') + changeValue + '%')
                        .removeClass('color-danger color-success')
                        .addClass(changeValue > 0 ? 'color-danger' : 'color-success');

                    $('#perf-sla').text(response.performanceReportData.sla_compliance +
                        '%');
                    $('#comp-total').text(response.complianceReportData.total_incidents);
                    $('#comp-recurring').text(response.complianceReportData
                        .recurring_incidents.length);

                    // Re-render all charts with new data
                    renderAllCharts(response);

                    // Show success message
                    Swal.fire({
                        icon: 'success',
                        title: 'Filtered Successfully',
                        text: 'Data has been updated',
                        timer: 1500,
                        showConfirmButton: false
                    });

                    // Smooth scroll to top
                    $('html, body').animate({
                        scrollTop: $('.filter-section').offset().top - 20
                    }, 500);
                },
                error: function(xhr, status, error) {
                    console.error('Filter error:', error);
                    console.error('Response:', xhr.responseText);

                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Failed to filter data. Please try again.',
                        confirmButtonText: 'OK'
                    });
                },
                complete: function() {
                    $btn.prop('disabled', false).html(
                        '<i class="fa fa-search"></i> <span>Filter Data</span>');
                }
            });
        });

        // Reset filter
        $('#resetBtn').click(function() {
            $('#filterDateFrom').val('');
            $('#filterDateTo').val('');

            Swal.fire({
                title: 'Reset Filters?',
                text: 'This will reload the page with all data',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Yes, Reset',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    location.reload();
                }
            });
        });

        // Animate counter value
        function animateValue(selector, start, end) {
            const element = $(selector);
            const duration = 1000;
            const range = end - start;
            const increment = range / (duration / 16);
            let current = start;

            const timer = setInterval(() => {
                current += increment;
                if ((increment > 0 && current >= end) || (increment < 0 && current <= end)) {
                    current = end;
                    clearInterval(timer);
                }
                element.text(Math.floor(current));
            }, 16);
        }

        // Render all charts function
        function renderAllCharts(data) {
            console.log('Rendering charts with data:', data);

            // 1. Severity Distribution Chart
            if (data.alertsReportData && data.alertsReportData.severity_distribution) {
                const severityData = Object.entries(data.alertsReportData.severity_distribution).map(([name,
                    value
                ]) => ({
                    name: name,
                    y: value
                }));

                renderChart('severity-chart', {
                    chart: {
                        type: 'pie',
                        height: 250
                    },
                    title: {
                        text: null
                    },
                    plotOptions: {
                        pie: {
                            innerSize: '60%',
                            dataLabels: {
                                enabled: true,
                                format: '<b>{point.name}</b>: {point.y}',
                                distance: 10
                            }
                        }
                    },
                    colors: ['#f46a6a', '#f8aa4b', '#34c38f', '#5b73e8', '#9f7aea'],
                    series: [{
                        name: 'Incidents',
                        data: severityData
                    }]
                });
            }

            // 2. Status Breakdown Chart
            if (data.alertsReportData && data.alertsReportData.status_breakdown) {
                renderChart('status-breakdown-chart', {
                    chart: {
                        type: 'column',
                        height: 250
                    },
                    title: {
                        text: null
                    },
                    xAxis: {
                        categories: ['Open', 'In Progress', 'Closed']
                    },
                    yAxis: {
                        title: {
                            text: 'Count'
                        }
                    },
                    colors: ['#667eea', '#f8aa4b', '#34c38f'],
                    series: [{
                        name: 'Incidents',
                        data: [
                            data.alertsReportData.status_breakdown.open || 0,
                            data.alertsReportData.status_breakdown.progress || 0,
                            data.alertsReportData.status_breakdown.closed || 0
                        ]
                    }],
                    plotOptions: {
                        column: {
                            borderRadius: 5,
                            dataLabels: {
                                enabled: true
                            }
                        }
                    }
                });
            }

            // 3. Affected Assets Chart
            if (data.performanceReportData && data.performanceReportData.most_affected_assets) {
                const assetsData = Object.entries(data.performanceReportData.most_affected_assets).map(([name,
                    count
                ]) => ({
                    name: name,
                    y: count
                }));

                if (assetsData.length > 0) {
                    renderChart('affected-assets-chart', {
                        chart: {
                            type: 'bar',
                            height: 300
                        },
                        title: {
                            text: null
                        },
                        xAxis: {
                            type: 'category',
                            title: {
                                text: 'Assets'
                            }
                        },
                        yAxis: {
                            title: {
                                text: 'Incident Count'
                            }
                        },
                        series: [{
                            name: 'Incidents',
                            data: assetsData,
                            colorByPoint: true
                        }],
                        colors: ['#667eea', '#764ba2', '#f8aa4b', '#34c38f', '#5b73e8'],
                        plotOptions: {
                            bar: {
                                borderRadius: 5,
                                dataLabels: {
                                    enabled: true
                                }
                            }
                        }
                    });
                }
            }

            // 4. Recurring Incidents Chart
            if (data.complianceReportData && data.complianceReportData.recurring_incidents) {
                const recurringData = data.complianceReportData.recurring_incidents.map(item => ({
                    name: item.attack_type,
                    y: item.occurrences
                }));

                if (recurringData.length > 0) {
                    renderChart('recurring-incidents-chart', {
                        chart: {
                            type: 'column',
                            height: 300
                        },
                        title: {
                            text: null
                        },
                        xAxis: {
                            type: 'category',
                            title: {
                                text: 'Attack Type'
                            }
                        },
                        yAxis: {
                            title: {
                                text: 'Occurrences'
                            }
                        },
                        series: [{
                            name: 'Occurrences',
                            data: recurringData,
                            color: '#f46a6a'
                        }],
                        plotOptions: {
                            column: {
                                borderRadius: 5,
                                dataLabels: {
                                    enabled: true
                                }
                            }
                        }
                    });
                } else {
                    $('#recurring-incidents-chart').html(
                        '<div class="text-center text-muted py-5">No recurring incidents found</div>');
                }
            }

            // 5. Primary Threats Chart
            if (data.executiveSummaryData && data.executiveSummaryData.primary_threats) {
                const threatsData = data.executiveSummaryData.primary_threats.map(item => ({
                    name: item.threat_type,
                    y: item.count
                }));

                renderChart('primary-threats-chart', {
                    chart: {
                        type: 'pie',
                        height: 250,
                        backgroundColor: 'transparent'
                    },
                    title: {
                        text: null,
                        style: {
                            color: '#fff'
                        }
                    },
                    plotOptions: {
                        pie: {
                            dataLabels: {
                                enabled: true,
                                format: '<b>{point.name}</b>: {point.y}',
                                style: {
                                    color: '#fff'
                                }
                            }
                        }
                    },
                    colors: ['#f46a6a', '#f8aa4b', '#34c38f', '#5b73e8', '#9f7aea'],
                    series: [{
                        name: 'Threats',
                        data: threatsData
                    }]
                });
            }

            // 6. Strategic Indicators Chart
            if (data.executiveSummaryData && data.executiveSummaryData.strategic_indicators) {
                const indicators = data.executiveSummaryData.strategic_indicators;
                renderChart('strategic-indicators-chart', {
                    chart: {
                        type: 'column',
                        height: 250,
                        backgroundColor: 'transparent'
                    },
                    title: {
                        text: null
                    },
                    xAxis: {
                        categories: ['Response Efficiency', 'Prevention Effectiveness'],
                        labels: {
                            style: {
                                color: '#fff'
                            }
                        }
                    },
                    yAxis: {
                        title: {
                            text: 'Percentage (%)',
                            style: {
                                color: '#fff'
                            }
                        },
                        labels: {
                            style: {
                                color: '#fff'
                            }
                        },
                        max: 100
                    },
                    series: [{
                        name: 'Score',
                        data: [
                            indicators.response_efficiency || 0,
                            indicators.prevention_effectiveness || 0
                        ],
                        color: '#34c38f'
                    }],
                    plotOptions: {
                        column: {
                            borderRadius: 5,
                            dataLabels: {
                                enabled: true,
                                format: '{y}%',
                                style: {
                                    color: '#fff'
                                }
                            }
                        }
                    },
                    legend: {
                        itemStyle: {
                            color: '#fff'
                        }
                    }
                });
            }

            // 7. Classification Chart
            if (data.classificationData && data.classificationData.series) {
                renderChart('chart-classification-container', {
                    chart: {
                        type: 'column',
                        height: 300
                    },
                    title: {
                        text: null
                    },
                    xAxis: {
                        categories: data.classificationData.categories
                    },
                    yAxis: {
                        title: {
                            text: 'Count'
                        }
                    },
                    series: data.classificationData.series,
                    plotOptions: {
                        column: {
                            stacking: 'normal',
                            borderRadius: 5,
                            dataLabels: {
                                enabled: true
                            }
                        }
                    }
                });
            }

            // 8. Status Over Time Chart
            if (data.statusOverTimeData && data.statusOverTimeData.series) {
                renderChart('chart-status-over-time', {
                    chart: {
                        type: 'line',
                        height: 300
                    },
                    title: {
                        text: null
                    },
                    xAxis: {
                        categories: data.statusOverTimeData.categories
                    },
                    yAxis: {
                        title: {
                            text: 'Incidents'
                        }
                    },
                    series: data.statusOverTimeData.series,
                    plotOptions: {
                        line: {
                            dataLabels: {
                                enabled: false
                            },
                            marker: {
                                enabled: true,
                                radius: 4
                            }
                        }
                    }
                });
            }

            // 9. Attack Type Chart
            if (data.attackData && data.attackData.length > 0) {
                renderChart('chart-attack-type', {
                    chart: {
                        type: 'pie',
                        height: 300
                    },
                    title: {
                        text: null
                    },
                    plotOptions: {
                        pie: {
                            innerSize: '50%',
                            dataLabels: {
                                enabled: true,
                                format: '<b>{point.name}</b>: {point.y}'
                            }
                        }
                    },
                    series: [{
                        name: 'Attacks',
                        data: data.attackData
                    }]
                });
            }

            // 10. Direction Chart
            if (data.directionData && data.directionData.length > 0) {
                renderChart('chart-direction', {
                    chart: {
                        type: 'pie',
                        height: 300
                    },
                    title: {
                        text: null
                    },
                    series: [{
                        name: 'Direction',
                        data: data.directionData
                    }],
                    plotOptions: {
                        pie: {
                            dataLabels: {
                                enabled: true,
                                format: '<b>{point.name}</b>: {point.y}'
                            }
                        }
                    }
                });
            }

            // 11. Playbook Chart
            if (data.playBookData && data.playBookData.length > 0) {
                renderChart('chart-play-book', {
                    chart: {
                        type: 'bar',
                        height: 350
                    },
                    title: {
                        text: null
                    },
                    xAxis: {
                        type: 'category',
                        title: {
                            text: 'Playbook'
                        }
                    },
                    yAxis: {
                        title: {
                            text: 'Usage Count'
                        }
                    },
                    series: [{
                        name: 'Usage',
                        data: data.playBookData,
                        colorByPoint: true
                    }],
                    plotOptions: {
                        bar: {
                            borderRadius: 5,
                            dataLabels: {
                                enabled: true
                            }
                        }
                    }
                });
            }

            // 12. TLP Level Chart
            if (data.tlpData && data.tlpData.length > 0) {
                renderChart('chart-tlp-level', {
                    chart: {
                        type: 'pie',
                        height: 300
                    },
                    title: {
                        text: null
                    },
                    series: [{
                        name: 'TLP Level',
                        data: data.tlpData
                    }],
                    plotOptions: {
                        pie: {
                            dataLabels: {
                                enabled: true,
                                format: '<b>{point.name}</b>: {point.y}'
                            }
                        }
                    }
                });
            }

            // 13. PAP Level Chart
            if (data.papData && data.papData.length > 0) {
                renderChart('chart-pap-level', {
                    chart: {
                        type: 'pie',
                        height: 300
                    },
                    title: {
                        text: null
                    },
                    series: [{
                        name: 'PAP Level',
                        data: data.papData
                    }],
                    plotOptions: {
                        pie: {
                            dataLabels: {
                                enabled: true,
                                format: '<b>{point.name}</b>: {point.y}'
                            }
                        }
                    }
                });
            }
        }

        // Generic chart render function
        function renderChart(containerId, options) {
            const defaultOptions = {
                exporting: {
                    enabled: true,
                    buttons: {
                        contextButton: {
                            menuItems: [
                                'viewFullscreen',
                                'printChart',
                                'separator',
                                'downloadPNG',
                                'downloadJPEG',
                                'downloadPDF',
                                'downloadSVG'
                            ]
                        }
                    }
                },
                credits: {
                    enabled: false
                },
                accessibility: {
                    enabled: true
                }
            };

            const mergedOptions = $.extend(true, {}, defaultOptions, options);

            try {
                Highcharts.chart(containerId, mergedOptions);
            } catch (error) {
                console.error(`Error rendering chart ${containerId}:`, error);
                $(`#${containerId}`).html(
                    '<div class="text-center text-danger py-3">Error rendering chart</div>');
            }
        }

        // Initialize data tables
        if ($.fn.DataTable) {
            $('.data-table').DataTable({
                pageLength: 10,
                responsive: true,
                dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>rtip',
                language: {
                    search: "Search:",
                    lengthMenu: "Show _MENU_ entries",
                    info: "Showing _START_ to _END_ of _TOTAL_ entries",
                    paginate: {
                        first: "First",
                        last: "Last",
                        next: "Next",
                        previous: "Previous"
                    }
                }
            });
        }

        // Add counter animation on page load
        setTimeout(() => {
            animateCounters();
        }, 300);

        function animateCounters() {
            $('[data-counter]').each(function() {
                const $this = $(this);
                const countTo = parseInt($this.text()) || 0;

                $({
                    countNum: 0
                }).animate({
                    countNum: countTo
                }, {
                    duration: 1500,
                    easing: 'swing',
                    step: function() {
                        $this.text(Math.floor(this.countNum));
                    },
                    complete: function() {
                        $this.text(countTo);
                    }
                });
            });
        }

        // Log initial data for debugging
        console.log('Initial report data loaded:', currentReportData);

        // Export to PDF function - now inside document ready with access to currentReportData
// Export to PDF function - Enhanced with Arabic support matching vulnerability export
window.exportToPDF = async function() {
    // Show loading indicator
    Swal.fire({
        title: '{{ __('incident.GeneratingPDF') }}',
        html: '{{ __('incident.PleaseWaitPrepareReport') }}',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });

    try {
        const {
            jsPDF
        } = window.jspdf;

        if (!jsPDF) {
            throw new Error('jsPDF not available');
        }

        const pdf = new jsPDF('p', 'mm', 'a4');
        const pageWidth = 210;
        const pageHeight = 297;
        const margin = 10;
        const contentWidth = pageWidth - (margin * 2);

        let currentPageNum = 1;
        let yPosition = margin;

        // Detect if Arabic language
        const isArabic = document.documentElement.lang === 'ar' ||
            document.documentElement.dir === 'rtl' ||
            '{{ app()->getLocale() }}' === 'ar';

        // Add exporting class to body for CSS visibility
        document.body.classList.add('exporting');

        // Helper function to preload and ensure fonts are ready
        async function ensureFontsLoaded() {
            if (!document.fonts || !document.fonts.check) {
                // Fallback if Font Loading API is not available
                await new Promise(resolve => setTimeout(resolve, 500));
                return;
            }

            // List of fonts that support Arabic
            const arabicFonts = [
                '16px Arial',
                '16px "Segoe UI"',
                '16px Tahoma',
                '16px "Times New Roman"',
                '16px "DejaVu Sans"',
                '16px "Noto Sans Arabic"',
                '16px "Cairo"',
                '16px "Amiri"'
            ];

            // Check if fonts are loaded, if not wait for them
            const fontPromises = arabicFonts.map(font => {
                if (document.fonts.check(font)) {
                    return Promise.resolve();
                }
                return document.fonts.load(font).catch(() => {
                    // If font fails to load, continue anyway
                    return Promise.resolve();
                });
            });

            await Promise.all(fontPromises);

            // Additional wait to ensure fonts are applied
            await new Promise(resolve => setTimeout(resolve, 300));
        }

        // Preload fonts before starting export
        await ensureFontsLoaded();

        // Helper function to add page footer
        function addPageFooter() {
            pdf.setFontSize(8);
            pdf.setTextColor(128, 128, 128);
            pdf.text(`Page ${currentPageNum}`, margin, pageHeight - 5);
            pdf.text(`Generated: ${new Date().toLocaleString()}`, pageWidth - margin,
                pageHeight - 5, {
                    align: 'right'
                });
        }

        // Add blue left sidebar to first page only
        function addLeftSidebar() {
            pdf.setFillColor(74, 158, 255); // Light blue
            pdf.rect(0, 0, 15, pageHeight, 'F');

            // Add gradient effect with darker blue at bottom
            pdf.setFillColor(30, 136, 229); // Darker blue
            pdf.rect(0, pageHeight / 2, 15, pageHeight / 2, 'F');
        }

        // Helper function to check and add new page if needed
        function checkPageBreak(requiredHeight) {
            if (yPosition + requiredHeight > pageHeight - margin - 5) {
                addPageFooter();
                pdf.addPage();
                currentPageNum++;
                yPosition = margin;
                return true;
            }
            return false;
        }

        // Helper function to capture element as image (handles Arabic properly)
        async function captureElementAsImage(element, options = {}) {
            // Inject font styles into the document to ensure Arabic fonts are available
            const fontStyle = document.createElement('style');
            fontStyle.textContent = `
                @import url('{{ asset('cdn/css2.css') }}');
                * {
                    font-family: ${isArabic ? '"Cairo", "Amiri", "Segoe UI", Tahoma, Arial, "DejaVu Sans", sans-serif' : 'Arial, "Helvetica Neue", Helvetica, sans-serif'} !important;
                    -webkit-font-smoothing: antialiased;
                    -moz-osx-font-smoothing: grayscale;
                    text-rendering: optimizeLegibility;
                }
                h1, h2, h3, h4, h5, h6, .fw-600, .fw-700 {
                    font-family: ${isArabic ? '"Cairo", "Amiri", "Segoe UI", Tahoma, Arial, "DejaVu Sans", sans-serif' : 'Arial, "Helvetica Neue", Helvetica, sans-serif'} !important;
                    -webkit-font-smoothing: antialiased !important;
                    -moz-osx-font-smoothing: grayscale !important;
                    text-rendering: optimizeLegibility !important;
                }
            `;
            document.head.appendChild(fontStyle);

            // Wait for fonts to be applied
            await new Promise(resolve => setTimeout(resolve, 200));

            const defaultOptions = {
                scale: 2,
                backgroundColor: '#ffffff',
                logging: false,
                useCORS: true,
                allowTaint: true,
                removeContainer: false,
                imageTimeout: 15000,
                fontEmbedCSS: true,
                onclone: function(clonedDoc) {
                    // Inject font styles into cloned document
                    const clonedFontStyle = clonedDoc.createElement('style');
                    clonedFontStyle.textContent = `
                        @import url('{{ asset('cdn/css2.css') }}');
                        * {
                            font-family: ${isArabic ? '"Cairo", "Amiri", "Segoe UI", Tahoma, Arial, "DejaVu Sans", sans-serif' : 'Arial, "Helvetica Neue", Helvetica, sans-serif'} !important;
                            -webkit-font-smoothing: antialiased;
                            -moz-osx-font-smoothing: grayscale;
                            text-rendering: optimizeLegibility;
                        }
                        body, html {
                            direction: ${isArabic ? 'rtl' : 'ltr'};
                        }
                        h1, h2, h3, h4, h5, h6, .fw-600, .fw-700 {
                            font-family: ${isArabic ? '"Cairo", "Amiri", "Segoe UI", Tahoma, Arial, "DejaVu Sans", sans-serif' : 'Arial, "Helvetica Neue", Helvetica, sans-serif'} !important;
                            -webkit-font-smoothing: antialiased !important;
                            -moz-osx-font-smoothing: grayscale !important;
                            text-rendering: optimizeLegibility !important;
                        }
                    `;
                    clonedDoc.head.appendChild(clonedFontStyle);

                    // Find the cloned element
                    const clonedElement = clonedDoc.body.querySelector(element.tagName + (element.className ? '.' + element.className.split(' ').join('.') : ''));
                    if (clonedElement) {
                        // Preserve RTL direction
                        if (isArabic || element.closest('[dir="rtl"]')) {
                            clonedElement.setAttribute('dir', 'rtl');
                            clonedElement.style.direction = 'rtl';
                            clonedElement.style.textAlign = 'right';
                        }
                        // Ensure visibility
                        clonedElement.style.visibility = 'visible';
                        clonedElement.style.display = '';
                        clonedElement.style.opacity = '1';

                        // Apply font family to all text elements
                        const textElements = clonedElement.querySelectorAll('*');
                        textElements.forEach(el => {
                            if (isArabic) {
                                el.style.fontFamily = '"Cairo", "Amiri", "Segoe UI", Tahoma, Arial, "DejaVu Sans", sans-serif';
                                el.style.webkitFontSmoothing = 'antialiased';
                                el.style.mozOsxFontSmoothing = 'grayscale';
                                el.style.textRendering = 'optimizeLegibility';
                                el.style.unicodeBidi = 'embed';
                                el.style.fontFeatureSettings = '"liga" 1, "kern" 1';
                                el.style.webkitFontFeatureSettings = '"liga" 1, "kern" 1';
                                el.style.mozFontFeatureSettings = '"liga" 1, "kern" 1';
                                el.style.letterSpacing = 'normal';
                                el.style.wordSpacing = 'normal';
                            } else {
                                el.style.unicodeBidi = 'normal';
                            }
                        });

                        // Ensure charts are visible in cloned document
                        const charts = clonedElement.querySelectorAll('[id$="chart"], [id*="Chart"]');
                        charts.forEach(chart => {
                            chart.style.visibility = 'visible';
                            chart.style.display = 'block';
                            chart.style.opacity = '1';
                        });
                    }
                },
                ...options
            };

            // Ensure element is visible
            const originalDisplay = element.style.display;
            const originalVisibility = element.style.visibility;
            const originalOpacity = element.style.opacity;
            element.style.display = '';
            element.style.visibility = 'visible';
            element.style.opacity = '1';

            // Ensure charts in element are visible
            const charts = element.querySelectorAll('[id$="chart"], [id*="Chart"]');
            charts.forEach(chart => {
                chart.style.visibility = 'visible';
                chart.style.display = 'block';
                chart.style.opacity = '1';
            });

            // Wait for any animations or rendering (longer for Arabic)
            await new Promise(resolve => setTimeout(resolve, isArabic ? 500 : 300));

            // Ensure fonts are loaded before capture
            await ensureFontsLoaded();

            // Retry mechanism for Arabic text rendering
            let canvas;
            let retryCount = 0;
            const maxRetries = isArabic ? 2 : 1;

            while (retryCount < maxRetries) {
                try {
                    canvas = await html2canvas(element, defaultOptions);

                    // For Arabic, verify text is rendered (check if canvas has content)
                    if (isArabic && retryCount < maxRetries - 1) {
                        const ctx = canvas.getContext('2d');
                        const imageData = ctx.getImageData(0, 0, Math.min(100, canvas.width), Math.min(100, canvas.height));
                        const hasContent = imageData.data.some(pixel => pixel !== 255); // Check if not all white

                        if (hasContent) {
                            break; // Content rendered, exit retry loop
                        }

                        // Wait longer before retry
                        await new Promise(resolve => setTimeout(resolve, 500));
                        retryCount++;
                    } else {
                        break; // Not Arabic or last retry
                    }
                } catch (error) {
                    if (retryCount < maxRetries - 1) {
                        retryCount++;
                        await new Promise(resolve => setTimeout(resolve, 500));
                    } else {
                        throw error;
                    }
                }
            }

            // Remove injected font style
            if (fontStyle.parentNode) {
                fontStyle.parentNode.removeChild(fontStyle);
            }

            // Restore original styles
            element.style.display = originalDisplay;
            element.style.visibility = originalVisibility;
            element.style.opacity = originalOpacity;

            return canvas;
        }

        // ==================== COVER PAGE ====================
        addLeftSidebar(); // Add sidebar only to first page

        // Add logo at top right
        const logoImg = new Image();
        logoImg.crossOrigin = 'anonymous';
        logoImg.src = '{{ asset('images/ksu-logo.png') }}';

        try {
            await new Promise((resolve, reject) => {
                logoImg.onload = resolve;
                logoImg.onerror = reject;
                setTimeout(resolve, 1000); // Timeout after 1 second
            });
            pdf.addImage(logoImg, 'PNG', pageWidth - 65, 15, 50, 40);
        } catch (e) {
            console.warn('Logo image not available:', e);
        }

        // Create cover page content using HTML to preserve Arabic
            const arabicFontFamily = isArabic
                ? '"Cairo", "Amiri", "Segoe UI", Tahoma, Arial, "DejaVu Sans", sans-serif'
                : 'Arial, "Helvetica Neue", Helvetica, sans-serif';

            const coverPageHTML = `
                <div style="
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    text-align: center;
                    height: 100vh; /* لتمركز عمودي كامل */
                    padding: 40px;
                    font-family: ${arabicFontFamily};
                    direction: ${isArabic ? 'rtl' : 'ltr'};
                    -webkit-font-smoothing: antialiased;
                    -moz-osx-font-smoothing: grayscale;
                    text-rendering: optimizeLegibility;
                    unicode-bidi: embed;
                    font-feature-settings: 'liga' 1, 'kern' 1;
                ">
                    <div>
                        <h1 style="
                            font-size: 32px;
                            font-weight: bold;
                            margin-bottom: 15px;
                            color: #000;
                            letter-spacing: normal;
                            word-spacing: normal;
                            line-height: 1.4;
                            font-family: ${arabicFontFamily};
                        ">
                            ${isArabic ? 'تقرير إحصائيات الحوادث الأمنية' : 'Security Incidents Statistics Report'}
                        </h1>
                    </div>
                </div>
            `;


        // Create temporary element for cover page
        const coverPageDiv = document.createElement('div');
        coverPageDiv.innerHTML = coverPageHTML;
        coverPageDiv.style.position = 'absolute';
        coverPageDiv.style.left = '-9999px';
        coverPageDiv.style.width = '800px';
        coverPageDiv.style.fontFamily = arabicFontFamily;
        document.body.appendChild(coverPageDiv);

        // Wait for fonts to load and render
        await ensureFontsLoaded();
        await new Promise(resolve => setTimeout(resolve, 300));

        // Capture cover page content
        const coverCanvas = await captureElementAsImage(coverPageDiv);
        document.body.removeChild(coverPageDiv);

        const coverImgData = coverCanvas.toDataURL('image/jpeg', 0.9);
        const coverHeight = (coverCanvas.height * contentWidth) / coverCanvas.width;

        const titleYPosition = 150;
        const titleHeight = Math.min(coverHeight, 180);

        if (titleYPosition + titleHeight > pageHeight - margin - 10) {
            const adjustedY = pageHeight - titleHeight - 20;
            pdf.addImage(coverImgData, 'JPEG', margin, adjustedY, contentWidth, titleHeight);
        } else {
            pdf.addImage(coverImgData, 'JPEG', margin, titleYPosition, contentWidth, titleHeight);
        }

        addPageFooter();

        // ==================== CONTENT PAGES ====================
        // Add new page for content
        pdf.addPage();
        currentPageNum = 2;
        yPosition = margin;
        addPageFooter();

        // Function to capture section
        async function captureSection(sectionSelector, minHeight = 40, sectionName = '') {
            const section = typeof sectionSelector === 'string' ? 
                document.querySelector(sectionSelector) : sectionSelector;
            
            if (!section) {
                console.warn(`Section ${sectionName || sectionSelector} not found`);
                return null;
            }

            if (checkPageBreak(minHeight + 20)) {
                // Footer already added in checkPageBreak()
            }

            // Wait for charts in this section to render
            await new Promise(resolve => setTimeout(resolve, isArabic ? 500 : 300));

            const canvas = await captureElementAsImage(section, {
                scale: 2,
                backgroundColor: '#ffffff',
                logging: false
            });

            const imgData = canvas.toDataURL('image/jpeg', 0.85);
            const imgHeight = (canvas.height * contentWidth) / canvas.width;
            const finalHeight = Math.min(imgHeight, minHeight);

            if (checkPageBreak(finalHeight + 10)) {
                // Re-capture if page break occurred
                const canvas2 = await captureElementAsImage(section, {
                    scale: 2,
                    backgroundColor: '#ffffff',
                    logging: false
                });
                const imgData2 = canvas2.toDataURL('image/jpeg', 0.85);
                const imgHeight2 = (canvas2.height * contentWidth) / canvas2.width;
                const finalHeight2 = Math.min(imgHeight2, minHeight);
                pdf.addImage(imgData2, 'JPEG', margin, yPosition, contentWidth, finalHeight2);
                yPosition += finalHeight2 + 12;
            } else {
                pdf.addImage(imgData, 'JPEG', margin, yPosition, contentWidth, finalHeight);
                yPosition += finalHeight + 12;
            }

            return finalHeight;
        }

        // Capture all sections in order
        try {
            // 1. KPI Cards
            await captureSection('.row.mb-4:nth-of-type(1)', 50, 'KPI Cards');
            
            // 2. Alerts and Security Incidents Summary
            const alertsSection = document.querySelectorAll('.row.mb-4')[1];
            if (alertsSection) {
                await captureSection(alertsSection, 80, 'Alerts Report');
            }
            
            // 3. Performance Comparison Report
            const perfSection = document.querySelectorAll('.row.mb-4')[2];
            if (perfSection) {
                await captureSection(perfSection, 80, 'Performance Report');
            }
            
            // 4. Compliance and Documentation Report
            const complianceSection = document.querySelectorAll('.row.mb-4')[3];
            if (complianceSection) {
                await captureSection(complianceSection, 80, 'Compliance Report');
            }
            
            // 5. Critical Incidents Detailed Report
            const criticalSection = document.querySelectorAll('.row.mb-4')[4];
            if (criticalSection) {
                await captureSection(criticalSection, 100, 'Critical Incidents');
            }
            
            // 6. Executive Summary Report
            const executiveSection = document.querySelector('.executive-summary');
            if (executiveSection) {
                await captureSection(executiveSection, 80, 'Executive Summary');
            }
            
            // 7. Evidence Analysis Report
            const evidenceSection = document.querySelectorAll('.dashboard-card')[5];
            if (evidenceSection) {
                await captureSection(evidenceSection, 100, 'Evidence Analysis');
            }
            
            // 8. Detailed Analytics
            const analyticsSection = document.querySelectorAll('.dashboard-card')[6];
            if (analyticsSection) {
                await captureSection(analyticsSection, 120, 'Detailed Analytics');
            }
        } catch (error) {
            console.error('Error capturing sections:', error);
        }

        // Add footer to last page
        pdf.setPage(pdf.internal.getNumberOfPages());
        addPageFooter();

        // Remove exporting class
        document.body.classList.remove('exporting');

        // Save the PDF
        const dateStr = new Date().toISOString().split('T')[0];
        const fileName = `Security_Incidents_Report_${dateStr}.pdf`;
        pdf.save(fileName);

        // Show success message
        Swal.fire({
            icon: 'success',
            title: isArabic ? 'تم التصدير بنجاح' : 'Export Successful!',
            text: isArabic ? 'تم تحميل تقرير PDF' : 'Your PDF has been downloaded',
            timer: 2000,
            showConfirmButton: false
        });

    } catch (error) {
        console.error('Export error:', error);
        // Remove exporting class on error
        document.body.classList.remove('exporting');

        const isArabic = '{{ app()->getLocale() }}' === 'ar';
        Swal.fire({
            icon: 'error',
            title: isArabic ? 'فشل التصدير' : 'Export Failed',
            text: isArabic ? 'حدث خطأ أثناء إنشاء PDF' : 'There was an error generating the PDF. Please try again.',
            confirmButtonText: 'OK'
        });
    }
};
    });
</script>
@endsection
