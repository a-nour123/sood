@extends('admin/layouts/contentLayoutMaster')

@section('title', __('report.framework_control_compliance_status'))
@section('vendor-style')
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
@endsection

@section('page-style')
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <style>
        /* Enhanced Table Styling */
        .report-table {
            border-collapse: collapse;
            width: 100%;
            margin: 0 0 1.5rem 0;
            background-color: white;
            border: 2px solid #2c3e50;
            font-family: 'Segoe UI', 'Arial', 'Tahoma', 'DejaVu Sans', sans-serif;
        }

        .report-table thead {
            background-color: #34495e;
            color: white;
        }

        .report-table thead th {
            padding: 12px 8px;
            font-weight: 600;
            text-align: center;
            border: 1px solid #2c3e50;
            font-size: 14px;
            background-color: #34495e;
        }

        .report-table tbody tr {
            border-bottom: 1px solid #bdc3c7;
        }

        .report-table tbody tr:nth-child(even) {
            background-color: #f8f9fa;
        }

        .report-table tbody tr:hover {
            background-color: #e8f4f8;
        }

        .report-table tbody td {
            padding: 10px 8px;
            text-align: center;
            border: 1px solid #bdc3c7;
            font-size: 13px;
            color: #2c3e50;
            word-wrap: break-word;
            overflow-wrap: break-word;
            background-color: white;
        }

        /* Arabic text support */
        .arabic-text {
            font-family: 'Segoe UI', 'Arial', 'Tahoma', 'DejaVu Sans', 'Noto Sans Arabic', sans-serif;
            direction: rtl;
            unicode-bidi: embed;
        }

        .latin-text {
            font-family: 'Segoe UI', 'Arial', sans-serif;
            direction: ltr;
        }

        .domain-header {
            background-color: #2c3e50;
            color: white;
            padding: 12px 20px;
            margin: 25px 0 15px 0;
            font-size: 16px;
            font-weight: 600;
            border-left: 5px solid #3498db;
            text-align: center;
            width: 100%;
        }

        .subdomain-header {
            background-color: #3498db !important;
            color: white !important;
            font-weight: 600;
        }

        .control-status-cell {
            font-weight: 600;
            padding: 8px;
            color: white;
        }

        .section-divider {
            border: none;
            height: 2px;
            background-color: #bdc3c7;
            margin: 25px 0;
            width: 100%;
        }

        .report-header {
            text-align: center;
            margin: 0 0 30px 0;
            padding: 20px;
            background-color: #f8f9fa;
            border: 2px solid #3498db;
            border-radius: 5px;
            width: 100%;
        }

        .report-title {
            font-size: 1.6rem;
            color: #2c3e50;
            font-weight: 700;
            margin-bottom: 10px;
        }

        .report-date {
            color: #7f8c8d;
            font-size: 14px;
            margin-top: 8px;
            font-weight: 500;
        }

        .export-btn-container {
            margin-bottom: 20px;
        }

        .btn-export {
            background-color: #3498db;
            border: none;
            color: white;
            padding: 10px 25px;
            border-radius: 5px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-export:hover {
            background-color: #2980b9;
            color: white;
        }

        .btn-export:disabled {
            background-color: #95a5a6;
            cursor: not-allowed;
            opacity: 0.7;
        }

        /* Remove any default margins/padding */
        #exported-part-container {
            padding: 0 !important;
            margin: 0 !important;
        }

        #exported-part-container > * {
            margin-left: 0 !important;
            margin-right: 0 !important;
        }

        /* RTL/LTR support */
        [dir="rtl"] .report-table,
        .report-table[dir="rtl"] {
            direction: rtl;
            font-family: 'Segoe UI', 'Tahoma', 'Arial', 'DejaVu Sans', sans-serif;
        }

        [dir="ltr"] .report-table,
        .report-table[dir="ltr"] {
            direction: ltr;
        }

        /* Loading overlay */
        .pdf-loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.85);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 9999;
        }

        .pdf-loading-content {
            background: white;
            padding: 30px 40px;
            border-radius: 10px;
            text-align: center;
            min-width: 350px;
            max-width: 450px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.2);
        }

        .pdf-spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #3498db;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* Progress bar styles */
        .progress {
            background-color: #e9ecef;
            border-radius: 0.25rem;
            overflow: hidden;
            height: 20px;
            margin: 15px 0;
        }

        .progress-bar {
            background-color: #3498db;
            transition: width 0.3s ease;
        }

        .progress-bar-striped {
            background-image: linear-gradient(45deg, rgba(255,255,255,0.15) 25%, 
                transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, 
                rgba(255,255,255,0.15) 75%, transparent 75%, transparent);
            background-size: 1rem 1rem;
        }

        .progress-bar-animated {
            animation: progress-bar-stripes 1s linear infinite;
        }

        @keyframes progress-bar-stripes {
            0% { background-position: 1rem 0; }
            100% { background-position: 0 0; }
        }

        .pdf-loading-content h4 {
            margin-bottom: 15px;
            color: #2c3e50;
        }

        .pdf-loading-content #exportProgress {
            margin: 10px 0 5px 0;
            font-weight: 500;
            color: #2c3e50;
        }

        .pdf-loading-content .text-muted {
            margin-top: 10px;
            font-size: 12px;
            color: #7f8c8d !important;
        }

        /* Hidden container for PDF generation */
        #pdf-render-container {
            position: fixed;
            left: -9999px;
            top: 0;
            width: 297mm; /* A4 landscape width */
            background: white;
            padding: 20px;
            box-sizing: border-box;
        }

        /* Cancel button */
        .btn-cancel-export {
            background-color: #e74c3c;
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: 5px;
            font-weight: 500;
            margin-top: 15px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .btn-cancel-export:hover {
            background-color: #c0392b;
        }

        .btn-cancel-export:disabled {
            background-color: #95a5a6;
            cursor: not-allowed;
        }
    </style>
@endsection

@section('content')
    <!-- Loading Overlay with Progress -->
    <div class="pdf-loading-overlay" id="pdfLoadingOverlay">
        <div class="pdf-loading-content">
            <div class="pdf-spinner"></div>
            <h4 id="exportMessage">Generating PDF...</h4>
            <div class="progress">
                <div class="progress-bar progress-bar-striped progress-bar-animated" 
                     role="progressbar" 
                     id="exportProgressBar"
                     style="width: 0%;"
                     aria-valuenow="0" 
                     aria-valuemin="0" 
                     aria-valuemax="100">
                </div>
            </div>
            <p id="exportProgress" class="mb-1">Initializing...</p>
            <small class="text-muted">Please don't close this window</small>
            <br>
            <button type="button" class="btn-cancel-export" id="cancelExportBtn">Cancel Export</button>
        </div>
    </div>

    <!-- Hidden container for PDF rendering -->
    <div id="pdf-render-container"></div>

    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">
            <div class="row breadcrumbs-top widget-grid">
                <div class="col-12">
                    <div class="page-title mt-2">
                        <div class="row">
                            <div class="col-sm-12 ps-0">
                                @if (@isset($breadcrumbs))
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}"
                                                style="display: flex;">
                                                <svg class="stroke-icon">
                                                    <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}">
                                                    </use>
                                                </svg></a></li>
                                        @foreach ($breadcrumbs as $breadcrumb)
                                            <li class="breadcrumb-item">
                                                @if (isset($breadcrumb['link']))
                                                    <a
                                                        href="{{ $breadcrumb['link'] == 'javascript:void(0)' ? $breadcrumb['link'] : url($breadcrumb['link']) }}">
                                                @endif
                                                {{ $breadcrumb['name'] }}
                                                @if (isset($breadcrumb['link']))
                                                    </a>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ol>
                                @endisset
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <section class="basic-select2">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header border-bottom p-1">
                        <div class="head-label">
                            <h4 class="card-title">{{ __('report.Report') }}:
                                {{ __('report.framework_control_compliance_status') }}</h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row mt-2">
                            <div class="row">
                                <div class="col-6">
                                    <label class="form-label">{{ __('report.Framework') }}:</label>
                                    <select class="form-control select2" name="framework_id" id="framework"
                                        @if ($frameworkId !== null) disabled @endif>
                                        <option value="" disabled selected>{{ __('locale.select-option') }}</option>
                                        @foreach ($frameworks as $framework)
                                            <option value="{{ $framework->id }}"
                                                {{ $frameworkId == $framework->id ? 'selected' : '' }}>
                                                {{ $framework->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                    <span class="error error-framework_id"></span>
                                </div>
                                <div class="col-6">
                                    <label class="form-label">{{ __('compliance.AuditName') }}:</label>
                                    <select class="form-control select2" name="audit_name" id="AuditName">
                                        <option value="" disabled selected>{{ __('locale.select-option') }}</option>
                                    </select>
                                    <span class="error error-framework_id"></span>
                                </div>
                            </div>

                            <div id="report-table-container" class="pt-2" style="display: none">
                                <div class="export-btn-container">
                                    <button
                                        data-filename="{{ __('report.framework_control_compliance_status') }} {{ __('report.Report') }}"
                                        type="button" class="btn btn-export export-pdf-btn">
                                        <i data-feather="file-text" class="me-25"></i>
                                        <span>{{ __('locale.Export') }} PDF (Landscape)</span>
                                    </button>
                                    <span id="export-status" class="ms-3" style="display: none; color: #3498db; font-size: 0.875rem;"></span>
                                </div>
                                <div id="exported-part-container"></div>
                            </div>

                            <div class="demo-spacing-0 mt-2" style="display: none" id="report-table-container-empty">
                                <div class="alert alert-danger" role="alert">
                                    <div class="alert-body text-center">
                                        {{ __('locale.ThereIsNoData') }}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection

@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
@endsection

@section('page-script')
    <script src="{{ asset(mix('js/scripts/forms/form-select2.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
    
    <!-- Add jsPDF library -->
    <script src="{{ asset('cdn/jspdf.umd.min.js') }}"></script>
    <script src="{{ asset('cdn/html2canvas.min.js') }}"></script>

    <script>
        const reportName = "{{ __('report.framework_control_compliance_status') }} {{ __('report.Report') }}";
        const { jsPDF } = window.jspdf;
        
        // Get current locale from Laravel
        const currentLocale = "{{ app()->getLocale() }}";
        const isArabic = currentLocale === 'ar';

        // Global variables for export control
        let isExportCancelled = false;
        let currentExportPromise = null;

        // Function to reset export state
        function resetExportState() {
            isExportCancelled = false;
            currentExportPromise = null;
        }

        // Function to update progress
        function updateProgress(current, total, message = '') {
            const $overlay = $('#pdfLoadingOverlay');
            const $progress = $overlay.find('#exportProgress');
            const $message = $overlay.find('#exportMessage');
            const $progressBar = $overlay.find('#exportProgressBar');
            
            if (message) {
                $message.text(message);
            }
            
            if (current && total) {
                const percentage = Math.round((current / total) * 100);
                $progress.text(`${current}/${total} sections (${percentage}%)`);
                $progressBar.css('width', `${percentage}%`);
                $progressBar.attr('aria-valuenow', percentage);
            }
        }

        // Enhanced function to build report optimized for landscape PDF
        function buildReportTable(response) {
            // Check if response contains Arabic text
            const responseText = JSON.stringify(response.data);
            const containsArabic = /[\u0600-\u06FF]/.test(responseText);
            const textDirection = containsArabic ? 'rtl' : 'ltr';
            const textClass = containsArabic ? 'arabic-text' : 'latin-text';
            
            let htmlContent = `
                <div class="report-header ${textClass}" dir="${textDirection}">
                    <h2 class="report-title">${reportName}</h2>
                    <div class="report-date">${isArabic ? 'تم الإنشاء في:' : 'Generated on:'} ${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</div>
                </div>
            `;

            response.data.domains.forEach((domain, domainIndex) => {
                const domainName = domain.name;
                htmlContent += `<div class="domain-header ${textClass}" dir="${textDirection}">${domainIndex + 1}. ${domainName}</div>`;

                domain.families.forEach((subDomain, subDomainIndex) => {
                    const subDomainName = subDomain.name;
                    htmlContent += `
                        <table class="report-table" dir="${textDirection}">
                            <thead>
                                <tr>
                                    <th>${domainIndex + 1}.${subDomainIndex + 1}</th>
                                    <th colspan="4" class="subdomain-header ${textClass}">${subDomainName}</th>
                                </tr>
                    `;

                    if (subDomain.framework_controls.length) {
                        const controlNumberLabel = isArabic ? 'رقم الضابط' : 'Control Number';
                        const subControlNumberLabel = isArabic ? 'رقم الضابط الفرعى' : 'Sub-Control Number';
                        const mainControlLabel = isArabic ? 'الضابط الأساسي' : 'Main Control';
                        const subControlLabel = isArabic ? 'الضابط الفرعي' : 'Sub-Control';
                        
                        htmlContent += `
                                <tr>
                                    <th rowspan="2" class="${textClass}">${controlNumberLabel}</th>
                                    <th rowspan="2" class="${textClass}">${subControlNumberLabel}</th>
                                    <th colspan="2" class="${textClass}">${isArabic ? 'مستوى الالتزام' : 'Compliance Level'}</th>
                                </tr>
                                <tr>
                                    <th class="${textClass}">${mainControlLabel}</th>
                                    <th class="${textClass}">${subControlLabel}</th>
                                </tr>
                            </thead>
                            <tbody>
                        `;

                        subDomain.framework_controls.forEach((frameworkControl) => {
                            const controlNumber = frameworkControl.control_number ?? '';
                            const controlStatus = frameworkControl.control_status?.trim() || 'No Action';
                            const statusColor = response.data.control_status_colors[frameworkControl.control_status] || '#95a5a6';

                            htmlContent += `
                                <tr>
                                    <td class="${textClass}">${controlNumber}</td>
                                    <td>-</td>
                                    <td style="background-color: ${statusColor}; color: white; font-weight: 600;" class="control-status-cell ${textClass}">${controlStatus}</td>
                                    <td>-</td>
                                </tr>
                            `;

                            frameworkControl.framework_controls.forEach((subFrameworkControl) => {
                                const subControlNumber = subFrameworkControl.control_number ?? '';
                                const subControlStatus = subFrameworkControl.control_status || 'No Action';
                                const subStatusColor = response.data.control_status_colors[subControlStatus] || '#95a5a6';

                                htmlContent += `
                                    <tr>
                                        <td>-</td>
                                        <td class="${textClass}">${subControlNumber}</td>
                                        <td>-</td>
                                        <td style="background-color: ${subStatusColor}; color: white; font-weight: 600;" class="control-status-cell ${textClass}">${subControlStatus}</td>
                                    </tr>
                                `;
                            });
                        });

                        htmlContent += `</tbody>`;
                    } else {
                        htmlContent += `</thead>`;
                    }

                    htmlContent += `</table>`;
                });

                htmlContent += `<hr class="section-divider">`;
            });

            return htmlContent;
        }

        // Function to generate PDF with progress tracking and cancellation
        async function generatePDFWithProgress(response) {
            // Reset cancellation flag
            isExportCancelled = false;
            
            const $overlay = $('#pdfLoadingOverlay');
            $overlay.css('display', 'flex');
            
            // Initialize progress tracking
            updateProgress(0, 0, isArabic ? 'جاري إعداد التصدير...' : 'Preparing PDF export...');
            
            try {
                // Build the HTML content
                const htmlContent = buildReportTable(response);
                
                // Create a temporary container for rendering
                const $renderContainer = $('#pdf-render-container');
                $renderContainer.html(htmlContent);
                
                // Get all elements to capture
                const $elements = $renderContainer.children();
                const totalElements = $elements.length;
                
                // Update progress
                updateProgress(0, totalElements, isArabic ? 
                    `جاري معالجة ${totalElements} قسم...` : 
                    `Processing ${totalElements} sections...`);
                
                // Create PDF in landscape mode
                const pdf = new jsPDF({
                    orientation: 'landscape',
                    unit: 'mm',
                    format: 'a4',
                    compress: true
                });
                
                const pageWidth = pdf.internal.pageSize.getWidth();
                const pageHeight = pdf.internal.pageSize.getHeight();
                const margin = 15; // Increased margin for better readability
                
                let currentY = margin;
                let pageNumber = 1;
                let processedElements = 0;
                
                // Process each element with progress tracking
                for (let i = 0; i < $elements.length; i++) {
                    // Check if export was cancelled
                    if (isExportCancelled) {
                        throw new Error(isArabic ? 'تم إلغاء التصدير' : 'Export cancelled');
                    }
                    
                    processedElements = i + 1;
                    
                    // Update progress every 3 elements to reduce UI updates
                    if (i % 3 === 0 || i === $elements.length - 1) {
                        updateProgress(processedElements, totalElements, isArabic ? 
                            `جاري تحويل القسم ${processedElements} من ${totalElements}...` : 
                            `Converting section ${processedElements} of ${totalElements}...`);
                    }
                    
                    const element = $elements[i];
                    
                    // Capture element as image with optimized settings
                    const canvas = await html2canvas(element, {
                        scale: 1.5, // Optimized for performance
                        useCORS: true,
                        logging: false,
                        backgroundColor: '#ffffff',
                        windowWidth: 1123,
                        removeContainer: true,
                        onclone: function(clonedDoc) {
                            // Remove any animations that might interfere
                            clonedDoc.querySelectorAll('.spin, .pdf-spinner, .btn-export').forEach(el => {
                                el.style.display = 'none';
                            });
                        }
                    });
                    
                    // Check cancellation again after canvas creation
                    if (isExportCancelled) {
                        throw new Error(isArabic ? 'تم إلغاء التصدير' : 'Export cancelled');
                    }
                    
                    // Use JPEG for smaller file size and faster processing
                    const imgData = canvas.toDataURL('image/jpeg', 0.85);
                    const imgWidth = pageWidth - (margin * 2);
                    const imgHeight = (canvas.height * imgWidth) / canvas.width;
                    
                    // Check if we need a new page
                    if (currentY + imgHeight > pageHeight - margin && pageNumber > 1) {
                        pdf.addPage();
                        currentY = margin;
                        pageNumber++;
                        
                        if (pageNumber % 2 === 0) {
                            updateProgress(processedElements, totalElements, isArabic ? 
                                `إضافة صفحة ${pageNumber}...` : 
                                `Adding page ${pageNumber}...`);
                        }
                    }
                    
                    // Add image to PDF
                    pdf.addImage(imgData, 'JPEG', margin, currentY, imgWidth, imgHeight);
                    currentY += imgHeight + 8; // Add spacing between sections
                    
                    // Clear canvas from memory
                    canvas.width = 0;
                    canvas.height = 0;
                    
                    // If this element goes beyond the page, prepare for next page
                    if (currentY > pageHeight - margin - 30) {
                        pdf.addPage();
                        currentY = margin;
                        pageNumber++;
                    }
                    
                    // Add small delay every 5 elements to prevent UI blocking
                    if (i % 5 === 0) {
                        await new Promise(resolve => {
                            setTimeout(resolve, 50);
                            // Check for cancellation during delay
                            if (isExportCancelled) {
                                resolve();
                                throw new Error(isArabic ? 'تم إلغاء التصدير' : 'Export cancelled');
                            }
                        });
                    }
                }
                
                // Clear the render container
                $renderContainer.empty();
                
                // Final progress update
                updateProgress(totalElements, totalElements, isArabic ? 
                    'جاري حفظ الملف...' : 
                    'Saving PDF file...');
                
                // Small delay before saving
                await new Promise(resolve => setTimeout(resolve, 500));
                
                // Check final cancellation
                if (isExportCancelled) {
                    throw new Error(isArabic ? 'تم إلغاء التصدير' : 'Export cancelled');
                }
                
                // Generate filename with timestamp
                const timestamp = new Date().toISOString().split('T')[0];
                const filename = `${reportName.replace(/\s+/g, '_')}_${timestamp}.pdf`;
                
                // Save PDF
                pdf.save(filename);
                
                // Show success message
                $overlay.css('display', 'none');
                makeAlert('success', isArabic ? 'تم تصدير PDF بنجاح!' : 'PDF exported successfully!', 'Success');
                
            } catch (error) {
                console.error('PDF Generation Error:', error);
                
                // Clear the render container
                $('#pdf-render-container').empty();
                
                // If it's a cancellation, show appropriate message
                if (error.message.includes('cancelled')) {
                    $overlay.css('display', 'none');
                    makeAlert('info', isArabic ? 'تم إلغاء التصدير' : 'Export cancelled', 'Info');
                } else {
                    // Show error state
                    $('#exportMessage').text(isArabic ? 'خطأ: ' : 'Error: ' + error.message);
                    $('#exportProgress').text(isArabic ? 'فشل في إنشاء PDF' : 'Failed to generate PDF');
                    
                    // Hide overlay after a delay
                    setTimeout(() => {
                        $overlay.css('display', 'none');
                        makeAlert('error', 
                            isArabic ? 'فشل في إنشاء PDF: ' : 'Failed to generate PDF: ' + error.message, 
                            'Error'
                        );
                    }, 2000);
                }
            } finally {
                // Reset export state
                resetExportState();
            }
        }

        // Function to handle the change event
        const handleFrameworkChange = function() {
            const framework = $(this).val();
            $.ajax({
                url: "{{ route('admin.reporting.framewrok_control_compliance_status_info') }}",
                type: "POST",
                data: {
                    framework_id: framework,
                    _token: $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    if (response.status) {
                        if (response.data.domains.length) {
                            const htmlContent = buildReportTable(response);
                            $('#exported-part-container').html(htmlContent);
                            $('#report-table-container-empty').slideUp();
                            $('#report-table-container').slideDown();
                        } else {
                            $('#report-table-container-empty').slideDown();
                            $('#report-table-container').slideUp();
                        }
                        makeAlert('success', response.message, '@lang('locale.Success')');
                    } else {
                        $('#report-table-container-empty').slideDown();
                        $('#report-table-container').slideUp();
                        showError(response.errors);
                    }
                },
                error: function(response) {
                    $('#report-table-container-empty').slideDown();
                    $('#report-table-container').slideUp();
                    const responseData = response.responseJSON;
                    makeAlert('error', responseData.message, '@lang('locale.Error')');
                    showError(responseData.errors);
                }
            });
        };

        $('#framework').on('change', handleFrameworkChange);

        @if ($frameworkId !== null)
            $('#framework').val('{{ $frameworkId }}').change();
        @endif

        $('#AuditName').on('change', function(e) {
            const framework = $('#framework').val();
            const auditName = $('#AuditName').val();

            $.ajax({
                url: "{{ route('admin.reporting.framewrok_control_compliance_status_info') }}",
                type: "POST",
                data: {
                    framework_id: framework,
                    audit_name: auditName,
                    _token: $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    if (response.status) {
                        if (response.data.domains.length) {
                            const htmlContent = buildReportTable(response);
                            $('#exported-part-container').html(htmlContent);
                            $('#report-table-container-empty').slideUp();
                            $('#report-table-container').slideDown();
                        } else {
                            $('#report-table-container-empty').slideDown();
                            $('#report-table-container').slideUp();
                        }
                        makeAlert('success', response.message, '@lang('locale.Success')');
                    } else {
                        $('#report-table-container-empty').slideDown();
                        $('#report-table-container').slideUp();
                        showError(response.errors);
                    }
                },
                error: function(response) {
                    $('#report-table-container-empty').slideDown();
                    $('#report-table-container').slideUp();
                    const responseData = response.responseJSON;
                    makeAlert('error', responseData.message, '@lang('locale.Error')');
                    showError(responseData.errors);
                }
            });
        });

        // PDF Export with progress tracking and cancellation
        $(document).off('click', '.export-pdf-btn').on('click', '.export-pdf-btn', async function(e) {
            e.preventDefault();
            e.stopImmediatePropagation();
            
            const $btn = $(this);
            
            // Check if already exporting
            if ($btn.data('exporting') === true) {
                console.log('Export already in progress, ignoring click');
                return;
            }
            
            // Mark as exporting
            $btn.data('exporting', true);
            
            // Disable button and show loading state
            const originalHtml = $btn.html();
            const $exportStatus = $('#export-status');
            
            $btn.prop('disabled', true).html('<i data-feather="loader" class="me-25 spin"></i><span>' + 
                (isArabic ? 'جاري الإنشاء...' : 'Generating...') + '</span>');
            
            $exportStatus.text(isArabic ? 'جاري إنشاء PDF...' : 'PDF generation in progress...').show();
            feather.replace();
            
            // Get framework and audit data from selects
            const frameworkId = $('#framework').val();
            const auditName = $('#AuditName').val();
            
            if (!frameworkId) {
                makeAlert('error', 
                    isArabic ? 'الرجاء اختيار الإطار أولاً' : 'Please select a framework first.', 
                    'Error'
                );
                $btn.prop('disabled', false).html(originalHtml).removeData('exporting');
                $exportStatus.hide();
                feather.replace();
                return;
            }
            
            // Reset export state
            resetExportState();
            
            // Fetch fresh data for PDF generation
            $.ajax({
                url: "{{ route('admin.reporting.framewrok_control_compliance_status_info') }}",
                type: "POST",
                data: {
                    framework_id: frameworkId,
                    audit_name: auditName,
                    _token: $('meta[name="csrf-token"]').attr('content')
                },
                success: async function(response) {
                    if (response.status) {
                        // Store the export promise for cancellation
                        currentExportPromise = generatePDFWithProgress(response);
                        await currentExportPromise;
                    } else {
                        makeAlert('error', 
                            isArabic ? 'فشل في الحصول على بيانات التقرير' : 'Failed to get report data.', 
                            'Error'
                        );
                        $('#pdfLoadingOverlay').css('display', 'none');
                    }
                    $btn.prop('disabled', false).html(originalHtml).removeData('exporting');
                    $exportStatus.hide();
                    feather.replace();
                },
                error: function(response) {
                    console.error('Error fetching data:', response);
                    makeAlert('error', 
                        isArabic ? 'فشل في جلب بيانات التقرير' : 'Failed to fetch report data.', 
                        'Error'
                    );
                    $('#pdfLoadingOverlay').css('display', 'none');
                    $btn.prop('disabled', false).html(originalHtml).removeData('exporting');
                    $exportStatus.hide();
                    feather.replace();
                }
            });
        });

        // Cancel export button handler
        $('#cancelExportBtn').on('click', function() {
            const $btn = $(this);
            
            if ($btn.data('cancelling')) {
                return; // Already cancelling
            }
            
            $btn.data('cancelling', true);
            $btn.prop('disabled', true).text(isArabic ? 'جاري الإلغاء...' : 'Cancelling...');
            
            // Set cancellation flag
            isExportCancelled = true;
            
            // Reset button after 2 seconds
            setTimeout(() => {
                $btn.prop('disabled', false)
                   .text(isArabic ? 'إلغاء التصدير' : 'Cancel Export')
                   .removeData('cancelling');
            }, 2000);
        });

        function makeAlert($status, message, title) {
            if (title == 'Success') {
                title = '👋 ' + title;
            }
            toastr[$status](message, title, {
                closeButton: true,
                tapToDismiss: false,
                timeOut: 5000,
                progressBar: true,
                positionClass: isArabic ? 'toast-top-left' : 'toast-top-right'
            });
        }

        function showError(data) {
            $('.error').empty();
            $.each(data, function(key, value) {
                $('.error-' + key).empty();
                $('.error-' + key).append(value);
            });
        }

        $(document).ready(function() {
            // Add spinner animation style
            const style = document.createElement('style');
            style.textContent = `
                .spin {
                    animation: spin 1s linear infinite;
                }
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
            `;
            document.head.appendChild(style);
            
            // Handle window beforeunload during export
            let isExporting = false;
            
            $(document).on('exportStarted', function() {
                isExporting = true;
            });
            
            $(document).on('exportEnded', function() {
                isExporting = false;
            });
            
            // Warn user if they try to leave during export
            window.addEventListener('beforeunload', function(e) {
                if (isExporting) {
                    const message = isArabic ? 
                        'جاري تصدير PDF! إذا غادرت هذه الصفحة، قد يفشل التصدير.' :
                        'PDF export in progress! If you leave this page, the export may fail.';
                    
                    e.preventDefault();
                    e.returnValue = message;
                    return message;
                }
            });
            
            $('#framework').off('change').on('change', function() {
                var frameworkId = $(this).val();

                $.ajax({
                    url: "{{ route('admin.reporting.auditTestNumber', ['id' => ':id']) }}".replace(':id',
                        frameworkId),
                    type: 'GET',
                    success: function(response) {
                        $('#AuditName').empty().append(
                            '<option value="" selected>{{ __('locale.select-option') }}</option>'
                        );

                        if (response.auditData.length > 0) {
                            $.each(response.auditData, function(index, audit) {
                                var formattedText = audit.audit_name + " -- Test Number: " + audit
                                    .test_number_initiated;
                                $('#AuditName').append('<option value="' + audit.audit_name + '">' +
                                    formattedText + '</option>');
                            });
                        } else {
                            $('#AuditName').append(
                                '<option value="" disabled selected>{{ __('locale.select-option') }}</option>'
                            );
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching audit data:', error);
                        makeAlert('error', 
                            isArabic ? 'فشل في تحميل بيانات التدقيق' : 'Failed to load audit data', 
                            'Error'
                        );
                    }
                });
            });

            @if ($frameworkId !== null)
                $('#framework').val('{{ $frameworkId }}').trigger('change');
            @endif
        });
    </script>
@endsection