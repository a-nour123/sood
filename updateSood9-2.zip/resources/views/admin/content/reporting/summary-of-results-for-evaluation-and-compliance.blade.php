@extends('admin/layouts/contentLayoutMaster')

@section('title', __('report.summary_of_results_for_evaluation_and_compliance'))

@section('vendor-style')
    <!-- vendor css files -->
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/charts/apexcharts.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
@endsection

@section('page-style')
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/charts/chart-apex.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    @if (app()->getLocale() === 'ar')
        <style>
            body[dir="rtl"] .highcharts-container text,
            body[dir="rtl"] .highcharts-axis-labels text,
            body[dir="rtl"] .highcharts-legend-item text,
            body[dir="rtl"] .highcharts-title text,
            body[dir="rtl"] .highcharts-subtitle text {
                font-family: 'Cairo', Arial, sans-serif !important;
            }

            .chartDomaingraph{
                margin: auto !important;
            }
            
            .highcharts-legend-item {
                text-align: right !important;
            }

            .highcharts-axis-labels {
                text-anchor: end !important;
            }

            .highcharts-tooltip {
                text-align: right !important;
            }

            .table[dir="rtl"] th,
            .table[dir="rtl"] td {
                text-align: right;
            }
            
            /* ApexCharts Arabic fixes */
            .apexcharts-canvas {
                direction: rtl;
            }
            
            .apexcharts-text tspan {
                font-family: 'Cairo', Arial, sans-serif !important;
            }
            
            .apexcharts-xaxis-label,
            .apexcharts-yaxis-label,
            .apexcharts-legend-text {
                font-family: 'Cairo', Arial, sans-serif !important;
                font-weight: 600;
            }
            
            .apexcharts-tooltip {
                font-family: 'Cairo', Arial, sans-serif !important;
                text-align: right;
            }
            
            .apexcharts-data-labels text {
                font-family: 'Cairo', Arial, sans-serif !important;
                font-weight: bold;
            }
            
            /* Fix for chart export */
            .apexcharts-inner foreignObject {
                direction: rtl;
                text-align: right;
            }
            
            #statusChart-container {
                direction: rtl;
            }
            
            /* Highcharts Arabic fixes */
            .highcharts-axis-labels text,
            .highcharts-legend-item text,
            .highcharts-tooltip text {
                font-family: 'Cairo', Arial, sans-serif !important;
                text-anchor: end;
            }
            
            /* Fix for PDF export - ensure proper column order */
            @media print {
                .pdf-export-container .graph-view {
                    order: 1 !important;
                }
                .pdf-export-container .data-view {
                    order: 2 !important;
                }
            }
        </style>
    @endif
@endsection

@section('content')
    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">
            <div class="row breadcrumbs-top  widget-grid">
                <div class="col-12">
                    <div class="page-title mt-2">
                        <div class="row">
                            <div class="col-sm-12 ps-0">
                                @if (@isset($breadcrumbs))
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}" style="display: flex;">
                                                <svg class="stroke-icon">
                                                    <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}">
                                                    </use>
                                                </svg></a></li>
                                        @foreach ($breadcrumbs as $breadcrumb)
                                            <li class="breadcrumb-item">
                                                @if (isset($breadcrumb['link']))
                                                    <a href="{{ $breadcrumb['link'] == 'javascript:void(0)' ? $breadcrumb['link'] : url($breadcrumb['link']) }}">
                                                @endif
                                                {{ $breadcrumb['name'] }}
                                                @if (isset($breadcrumb['link']))
                                                    </a>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ol>
                                @endisset
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <section class="basic-select2">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header border-bottom p-1 d-flex justify-content-between align-items-center">
                        <div class="head-label">
                            <h4 class="card-title">{{ __('report.Report') }}:
                                {{ __('report.summary_of_results_for_evaluation_and_compliance_to_the_basic_controls_of_cybersecurity') }}
                            </h4>
                        </div>
                        <button class="btn btn-primary export-pdf-btn" style="display: none;" onclick="exportAllChartsToPDF()">
                            <span class="btn-text">
                                <i data-feather="download"></i> {{ __('report.ExportAllChartstoPDF') }}
                            </span>
                            <span class="btn-loading" style="display: none;">
                                <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                                {{ __('report.GeneratingPDF') }}
                            </span>
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="row mt-2">
                            <div class="col-6">
                                <label class="form-label">{{ __('report.Framework') }}:</label>
                                <select class="form-control select2" name="framework_id" id="framework" @if ($frameworkId !== null) disabled @endif>
                                    <option value="" disabled selected>{{ __('locale.select-option') }}</option>
                                    @foreach ($frameworks as $framework)
                                        <option value="{{ $framework->id }}" {{ $frameworkId == $framework->id ? 'selected' : '' }}>
                                            {{ $framework->name }}
                                        </option>
                                    @endforeach
                                </select>
                                <span class="error error-framework_id"></span>
                            </div>
                            <div class="col-6">
                                <label class="form-label">{{ __('compliance.AuditName') }}:</label>
                                <select class="form-control select2" name="audit_name" id="AuditName">
                                    <option value="" disabled selected>{{ __('locale.select-option') }}</option>
                                </select>
                                <span class="error error-framework_id"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <div class="row">
        <section id="apexchart">
            <div id="report-table-container" style="display: none">
                <div class="col-12 m-0 p-0" id="report-header"></div>
                <div class="row mt-2">
                    <!-- total framework control statuses Starts-->
                    <div class="col-12">
                        <div class="">
                            <div class="alert alert-primary" role="alert">
                                <div class="alert-body text-center">
                                    {{ __('report.The_general_level_of_cybersecurity_assessment_of_the_entity') }}
                                </div>
                            </div>
                            <div class="card" id="chartDomaingraph" style="display: none">
                                <div class="card-header pb-0">
                                    <h3 class="m-0">{{ __('report.DomainComplianceStatistic') }}</h3>
                                </div>
                                <div class="card-body row p-2">
                                    <div class="col-lg-12">
                                        <div id="statusChart-container" class="chart-wrapper"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body pt-0 row align-items-center justify-content-between pdf-export-container">
                                <div class="col-xl-9 col-12 {{ app()->getLocale() === 'ar' ? 'order-2 order-xl-1' : '' }} graph-view">
                                    <div id="donut-chart-total"></div>
                                </div>
                                <div class="col-xl-3 col-12 {{ app()->getLocale() === 'ar' ? 'order-1 order-xl-2' : '' }} data-view">
                                    <table class="table w-100" id="total-framework-control-statuses-table" dir="{{ app()->getLocale() === 'ar' ? 'rtl' : 'ltr' }}">
                                        <thead>
                                            <tr class="text-center">
                                                <th colspan="2">{{ __('report.Status') }}</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="col-9">{{ __('locale.Not Applicable', [], 'en') }} - {{ __('locale.Not Applicable', [], 'ar') }}</td>
                                                <td class="col-3 text-center"></td>
                                            </tr>
                                            <tr>
                                                <td class="col-9">{{ __('locale.Not Implemented', [], 'en') }} - {{ __('locale.Not Implemented', [], 'ar') }}</td>
                                                <td class="col-3 text-center"></td>
                                            </tr>
                                            <tr>
                                                <td class="col-9">{{ __('locale.Partially Implemented', [], 'en') }} - {{ __('locale.Partially Implemented', [], 'ar') }}</td>
                                                <td class="col-3 text-center"></td>
                                            </tr>
                                            <tr>
                                                <td class="col-9">{{ __('locale.Implemented', [], 'en') }} - {{ __('locale.Implemented', [], 'ar') }}</td>
                                                <td class="col-3 text-center"></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- total framework control statuses Ends-->
                </div>
            </div>
            <div class="demo-spacing-0 mt-2" style="display: none" id="report-table-container-empty">
                <div class="alert alert-danger" role="alert">
                    <div class="alert-body text-center">
                        {{ __('locale.ThereIsNoData') }}
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@section('vendor-script')
    <!-- vendor files -->
    <script src="{{ asset(mix('vendors/js/charts/apexcharts.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
    <script src="{{ asset('cdn/html2canvas.min.js') }}"></script>
    <script src="{{ asset('cdn/jspdf.umd.min.js') }}"></script>
@endsection

@section('page-script')
    <script src="{{ asset(mix('js/scripts/forms/form-select2.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
    <script src="{{ asset('js/scripts/html2pdf_v0.10.1_.bundle.min.js') }}"></script>
    <script src="{{ asset('cdn/d3.min.js') }}"></script>
    <script src="{{ asset(mix('vendors/js/charts/chart.min.js')) }}"></script>
    <script src="{{ asset('new_d/js/chart/chartist/chartist.js') }}"></script>
    <script src="{{ asset('new_d/js/chart/chartist/chartist-plugin-tooltip.js') }}"></script>
    <script src="{{ asset('new_d/js/chart/apex-chart/apex-chart.js') }}"></script>
    <script src="{{ asset('new_d/js/chart/apex-chart/stock-prices.js') }}"></script>
    <script src="{{ asset('ajax-files/asset_management/asset/index.js') }}"></script>
    <script src="{{ asset('js/scripts/highcharts/highcharts.js') }}"></script>
    
    <script>
        const statuses = [];
        let lang = [];
        lang['Not Applicable'] = "{{ __('locale.Not Applicable', [], 'en') }} - {{ __('locale.Not Applicable', [], 'ar') }}";
        lang['Not Implemented'] = "{{ __('locale.Not Implemented', [], 'en') }} - {{ __('locale.Not Implemented', [], 'ar') }}";
        lang['Partially Implemented'] = "{{ __('locale.Partially Implemented', [], 'en') }} - {{ __('locale.Partially Implemented', [], 'ar') }}";
        lang['Implemented'] = "{{ __('locale.Implemented', [], 'en') }} - {{ __('locale.Implemented', [], 'ar') }}";

        statuses['Not Applicable'] = {
            name: "{{ __('locale.Not Applicable') }}",
            color: "{{ $statuses['Not Applicable'] }}"
        };
        statuses['Not Implemented'] = {
            name: "{{ __('locale.Not Implemented') }}",
            color: "{{ $statuses['Not Implemented'] }}"
        };
        statuses['Partially Implemented'] = {
            name: "{{ __('locale.Partially Implemented') }}",
            color: "{{ $statuses['Partially Implemented'] }}"
        };
        statuses['Implemented'] = {
            name: "{{ __('locale.Implemented') }}",
            color: "{{ $statuses['Implemented'] }}"
        };

        const reportName = "{{ __('report.summary_of_results_for_evaluation_and_compliance') }} {{ __('report.Report') }}";
        const isRTL = {{ app()->getLocale() === 'ar' ? 'true' : 'false' }};

        // Translation strings for JavaScript
        const translations = {
            controlStatusDistribution: "{{ __('report.ControlStatusDistribution') }}",
            total: "{{ __('report.Total') }}",
            count: "{{ __('report.Count') }}",
            overallComplianceStatus: "{{ __('report.OverallComplianceStatus') }}",
            domainComplianceStatistics: "{{ __('report.DomainComplianceStatistics') }}",
            domainName: "{{ __('report.DomainName') }}",
            percentage: "{{ __('report.Percentage') }}",
            implemented: "{{ __('locale.Implemented') }}",
            notImplemented: "{{ __('locale.Not Implemented') }}",
            notApplicable: "{{ __('locale.Not Applicable') }}",
            partiallyImplemented: "{{ __('locale.Partially Implemented') }}",
            pdfExportedSuccessfully: "{{ __('report.PDFExportedSuccessfully') }}",
            generatingPDF: "{{ __('report.GeneratingPDF') }}",
            success: "{{ __('locale.Success') }}",
            error: "{{ __('locale.Error') }}",
            selectOption: "{{ __('locale.select-option') }}",
            testNumber: "{{ __('report.TestNumber') }}",
            CapturingHeader: "{{ __('report.CapturingHeader') }}",
            CapturingMainSection: "{{ __('report.CapturingMainSection') }}",
            CapturingDomainStatistics: "{{ __('report.CapturingDomainStatistics') }}",
            CapturingOverallCompliance: "{{ __('report.CapturingOverallCompliance') }}",
            CapturingDomain: "{{ __('report.CapturingDomain') }}",
            of: "{{ __('report.of') }}",
            GeneratingPDFFile: "{{ __('report.GeneratingPDFFile') }}",
            ErrorGeneratingPDF: "{{ __('report.ErrorGeneratingPDF') }}"
        };

        // Highcharts Donut Chart Function with legend disabled
        function drawDonutChart(containerId, data, total) {
            const container = $(containerId)[0];

            Highcharts.chart(container, {
                chart: {
                    type: 'pie',
                    style: {
                        direction: isRTL ? 'rtl' : 'ltr',
                        fontFamily: isRTL ? 'Cairo, Arial, sans-serif' : 'inherit'
                    },
                    options3d: {
                        enabled: true,
                        alpha: 45
                    }
                },
                title: {
                    text: translations.controlStatusDistribution,
                    style: {
                        fontFamily: isRTL ? 'Cairo, Arial, sans-serif' : 'inherit'
                    }
                },
                subtitle: {
                    text: `${translations.total}: ${total}`,
                    style: {
                        fontFamily: isRTL ? 'Cairo, Arial, sans-serif' : 'inherit'
                    }
                },
                tooltip: {
                    pointFormat: '{series.name}: <b>{point.y}</b> ({point.percentage:.1f}%)',
                    style: {
                        direction: isRTL ? 'rtl' : 'ltr',
                        fontFamily: isRTL ? 'Cairo, Arial, sans-serif' : 'inherit'
                    },
                    useHTML: true
                },
                plotOptions: {
                    pie: {
                        innerSize: '50%',
                        depth: 45,
                        allowPointSelect: true,
                        cursor: 'pointer',
                        dataLabels: {
                            enabled: true,
                            format: '<b>{point.name}</b>: {point.y} ({point.percentage:.1f}%)',
                            style: {
                                fontSize: '12px',
                                direction: isRTL ? 'rtl' : 'ltr',
                                textAlign: isRTL ? 'right' : 'left',
                                fontFamily: isRTL ? 'Cairo, Arial, sans-serif' : 'inherit'
                            },
                            useHTML: true,
                            connectorShape: 'fixedOffset',
                            connectorWidth: 1
                        },
                        showInLegend: false
                    }
                },
                legend: {
                    enabled: false
                },
                series: [{
                    name: translations.count,
                    colorByPoint: true,
                    data: [{
                        name: lang['Not Applicable'],
                        y: data[0],
                        color: statuses['Not Applicable'].color
                    }, {
                        name: lang['Not Implemented'],
                        y: data[1],
                        color: statuses['Not Implemented'].color
                    }, {
                        name: lang['Partially Implemented'],
                        y: data[2],
                        color: statuses['Partially Implemented'].color
                    }, {
                        name: lang['Implemented'],
                        y: data[3],
                        color: statuses['Implemented'].color
                    }]
                }],
                credits: {
                    enabled: false
                },
                exporting: {
                    enabled: false
                },
                lang: {
                    decimalPoint: isRTL ? ',' : '.',
                    thousandsSep: isRTL ? '.' : ','
                }
            });
        }

        // Updated PDF Export Function with ApexCharts fix
        async function exportAllChartsToPDF() {
            const exportBtn = $('.export-pdf-btn');
            exportBtn.prop('disabled', true);
            exportBtn.find('.btn-text').hide();
            exportBtn.find('.btn-loading').show();
            
            showLoadingOverlay();

            setTimeout(async function() {
                try {
                    const { jsPDF } = window.jspdf;
                    const pdf = new jsPDF({
                        orientation: 'p',
                        unit: 'mm',
                        format: 'a4',
                        compress: true
                    });

                    const pageWidth = pdf.internal.pageSize.getWidth();
                    const pageHeight = pdf.internal.pageSize.getHeight();
                    const margin = 10;
                    let yPosition = margin;
                    const validImages = [];

                    // 1. Capture Header
                    updateLoadingMessage(translations.CapturingHeader);
                    const headerElement = $('#report-table-container #report-header');
                    if (headerElement.length) {
                        const headerImg = await captureElementAsImage(headerElement[0]);
                        if (headerImg) validImages.push(headerImg);
                    }

                    // 2. Capture main alert
                    updateLoadingMessage(translations.CapturingMainSection);
                    const mainAlert = $('#report-table-container .alert.alert-primary').first();
                    if (mainAlert.length) {
                        const alertImg = await captureElementAsImage(mainAlert[0]);
                        if (alertImg) validImages.push(alertImg);
                    }

                    // 3. SPECIAL FIX: Capture Domain Statistics chart FIRST
                    updateLoadingMessage(translations.CapturingDomainStatistics);
                    const domainChartCard = $('#chartDomaingraph');
                    if (domainChartCard.is(':visible')) {
                        // Wait a moment for chart to fully render
                        await new Promise(resolve => setTimeout(resolve, 500));
                        
                        // Clone the chart container to avoid affecting the original
                        const chartClone = domainChartCard.clone();
                        chartClone.css({
                            position: 'absolute',
                            left: '-9999px',
                            top: '0',
                            width: domainChartCard.width(),
                            height: domainChartCard.height(),
                            backgroundColor: '#ffffff'
                        });
                        
                        $('body').append(chartClone);
                        
                        // Force chart redraw to ensure proper rendering
                        const chartContainer = chartClone.find('#statusChart-container');
                        if (chartContainer.length && typeof ApexCharts !== 'undefined') {
                            // Get the chart instance
                            const chart = ApexCharts.getChartByID(chartContainer.find('.apexcharts-canvas').attr('id'));
                            if (chart) {
                                // Trigger data labels to show
                                chart.updateOptions({
                                    dataLabels: {
                                        enabled: true
                                    }
                                }, false, false);
                            }
                        }
                        
                        // Wait for chart to update
                        await new Promise(resolve => setTimeout(resolve, 300));
                        
                        const chartImg = await captureElementAsImage(chartClone[0], {
                            scale: 2,
                            backgroundColor: '#ffffff',
                            onclone: function(clonedDoc) {
                                // Ensure chart is visible in clone
                                const clonedChart = clonedDoc.querySelector('#statusChart-container');
                                if (clonedChart) {
                                    clonedChart.style.visibility = 'visible';
                                    clonedChart.style.opacity = '1';
                                }
                            }
                        });
                        
                        if (chartImg) validImages.push(chartImg);
                        chartClone.remove();
                    }

                    // 4. Capture Overall Compliance section
                    updateLoadingMessage(translations.CapturingOverallCompliance);
                    const overallSection = $('#report-table-container .card-body.pt-0.row').first();
                    if (overallSection.length) {
                        if (isRTL) {
                            overallSection.find('.graph-view').css({
                                'order': '1',
                                'width': '75%',
                                'float': 'right'
                            });
                            overallSection.find('.data-view').css({
                                'order': '2',
                                'width': '25%',
                                'float': 'left'
                            });
                        }
                        
                        const overallImg = await captureElementAsImage(overallSection[0]);
                        if (overallImg) validImages.push(overallImg);
                        
                        if (isRTL) {
                            overallSection.find('.graph-view').css({
                                'order': '',
                                'width': '',
                                'float': ''
                            });
                            overallSection.find('.data-view').css({
                                'order': '',
                                'width': '',
                                'float': ''
                            });
                        }
                    }

                    // 5. Capture each domain section
                    const domainSections = $('.framwwork-domains-statuses');
                    const totalDomains = domainSections.length;
                    
                    for (let i = 0; i < totalDomains; i++) {
                        updateLoadingMessage(`${translations.CapturingDomain} ${i + 1} ${translations.of} ${totalDomains}...`);
                        const domainSection = $(domainSections[i]);
                        
                        // SPECIAL FIX: Handle donut charts in domain sections
                        const donutChartContainer = domainSection.find('.graph-view .apexcharts-canvas');
                        if (donutChartContainer.length) {
                            // Force donut chart to render completely
                            const chartId = donutChartContainer.attr('id');
                            if (chartId && typeof ApexCharts !== 'undefined') {
                                const donutChart = ApexCharts.getChartByID(chartId);
                                if (donutChart) {
                                    donutChart.updateOptions({
                                        dataLabels: {
                                            enabled: true
                                        }
                                    }, false, false);
                                }
                            }
                            
                            // Wait for chart update
                            await new Promise(resolve => setTimeout(resolve, 200));
                        }
                        
                        if (isRTL) {
                            domainSection.find('.graph-view').css({
                                'order': '1',
                                'width': '75%',
                                'float': 'right'
                            });
                            domainSection.find('.data-view').css({
                                'order': '2',
                                'width': '25%',
                                'float': 'left'
                            });
                        }
                        
                        const domainImg = await captureElementAsImage(domainSection[0], {
                            scale: 2,
                            backgroundColor: '#ffffff'
                        });
                        
                        if (domainImg) validImages.push(domainImg);
                        
                        if (isRTL) {
                            domainSection.find('.graph-view').css({
                                'order': '',
                                'width': '',
                                'float': ''
                            });
                            domainSection.find('.data-view').css({
                                'order': '',
                                'width': '',
                                'float': ''
                            });
                        }
                        
                        await new Promise(resolve => setTimeout(resolve, 100));
                    }

                    // Add all images to PDF
                    updateLoadingMessage(translations.GeneratingPDFFile);
                    
                    validImages.forEach((imgData, index) => {
                        const imgWidth = pageWidth - (2 * margin);
                        const imgHeight = (imgData.height * imgWidth) / imgData.width;

                        if (index > 0 && yPosition + imgHeight > pageHeight - margin) {
                            pdf.addPage();
                            yPosition = margin;
                        }

                        pdf.addImage(imgData.dataUrl, 'PNG', margin, yPosition, imgWidth, imgHeight);
                        yPosition += imgHeight + 5;

                        if (imgHeight > 100 && yPosition > pageHeight / 2) {
                            pdf.addPage();
                            yPosition = margin;
                        }
                    });

                    // Save PDF
                    const fileName = `${reportName}_${new Date().getTime()}.pdf`;
                    pdf.save(fileName);

                    hideLoadingOverlay();
                    exportBtn.prop('disabled', false);
                    exportBtn.find('.btn-loading').hide();
                    exportBtn.find('.btn-text').show();

                    makeAlert('success', translations.pdfExportedSuccessfully, translations.success);

                } catch (error) {
                    console.error('Error generating PDF:', error);
                    hideLoadingOverlay();
                    exportBtn.prop('disabled', false);
                    exportBtn.find('.btn-loading').hide();
                    exportBtn.find('.btn-text').show();
                    makeAlert('error', translations.ErrorGeneratingPDF + ': ' + error.message, translations.error);
                }
            }, 100);
        }

        // Updated capture function with ApexCharts support
        async function captureElementAsImage(element, options = {}) {
            const defaultOptions = {
                scale: 2,
                logging: false,
                backgroundColor: '#ffffff',
                useCORS: true,
                allowTaint: true,
                scrollY: -window.scrollY,
                scrollX: -window.scrollX,
                windowWidth: element.scrollWidth,
                windowHeight: element.scrollHeight,
                imageTimeout: 15000,
                removeContainer: true,
                onclone: function(clonedDoc) {
                    // Fix for ApexCharts in cloned document
                    const apexCharts = clonedDoc.querySelectorAll('.apexcharts-canvas');
                    apexCharts.forEach(chart => {
                        // Make sure charts are visible
                        chart.style.visibility = 'visible';
                        chart.style.opacity = '1';
                        
                        // Fix for foreignObject elements in SVG
                        const foreignObjects = chart.querySelectorAll('foreignObject');
                        foreignObjects.forEach(fo => {
                            fo.style.overflow = 'visible';
                        });
                    });
                    
                    // Fix for RTL text alignment
                    if (isRTL) {
                        const textElements = clonedDoc.querySelectorAll('text');
                        textElements.forEach(text => {
                            text.setAttribute('text-anchor', 'end');
                            text.style.direction = 'rtl';
                            text.style.textAnchor = 'end';
                        });
                    }
                }
            };
            
            const finalOptions = { ...defaultOptions, ...options };
            
            try {
                const canvas = await html2canvas(element, finalOptions);
                
                return {
                    canvas: canvas,
                    dataUrl: canvas.toDataURL('image/png', 1.0),
                    width: canvas.width,
                    height: canvas.height
                };
            } catch (error) {
                console.error('Error capturing element:', error);
                return null;
            }
        }

        // Show loading overlay
        function showLoadingOverlay() {
            $('#pdf-loading-overlay').remove();

            const overlay = $(`
                <div id="pdf-loading-overlay" style="
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: rgba(0, 0, 0, 0.7);
                    z-index: 9999;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    flex-direction: column;
                ">
                    <div style="
                        background: white;
                        padding: 30px 50px;
                        border-radius: 10px;
                        text-align: center;
                        box-shadow: 0 10px 40px rgba(0,0,0,0.3);
                    ">
                        <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                        <h4 style="margin-top: 20px; margin-bottom: 10px; color: #333;">
                            ${translations.generatingPDF || 'Generating PDF...'}
                        </h4>
                        <p id="pdf-loading-message" style="color: #666; margin: 0;">
                            ${isRTL ? 'الرجاء الانتظار...' : 'Please wait...'}
                        </p>
                    </div>
                </div>
            `);

            $('body').append(overlay);
        }

        // Update loading message
        function updateLoadingMessage(message) {
            $('#pdf-loading-message').text(message);
        }

        // Hide loading overlay
        function hideLoadingOverlay() {
            $('#pdf-loading-overlay').fadeOut(300, function() {
                $(this).remove();
            });
        }

        // Updated GetchartDomain function with better Arabic/RTL support
function GetchartDomain(domainStatusCounts) {

    const labels = Object.keys(domainStatusCounts);

    const implementedCounts = [];
    const notImplementedCounts = [];
    const notApplicableCounts = [];
    const partiallyImplementedCounts = [];

    labels.forEach(label => {
        const list = domainStatusCounts[label];

        let implemented = 0;
        let notImplemented = 0;
        let notApplicable = 0;
        let partiallyImplemented = 0;

        list.forEach(status => {
            switch (status.status_name) {
                case "Implemented":
                    implemented = +status.percentage;
                    break;
                case "Not Implemented":
                    notImplemented = +status.percentage;
                    break;
                case "Not Applicable":
                    notApplicable = +status.percentage;
                    break;
                case "Partially Implemented":
                    partiallyImplemented = +status.percentage;
                    break;
            }
        });

        implementedCounts.push(implemented);
        notImplementedCounts.push(notImplemented);
        notApplicableCounts.push(notApplicable);
        partiallyImplementedCounts.push(partiallyImplemented);
    });

    // Clear old chart
    const chartContainer = document.querySelector('#statusChart-container');
    chartContainer.innerHTML = '';

    const options = {
        series: [
            { name: translations.implemented, data: implementedCounts },
            { name: translations.notImplemented, data: notImplementedCounts },
            { name: translations.notApplicable, data: notApplicableCounts },
            { name: translations.partiallyImplemented, data: partiallyImplementedCounts }
        ],

        chart: {
            type: 'bar',
            height: 500,
            animations: { enabled: false },
            toolbar: { show: false },
            fontFamily: 'inherit'
        },

        colors: [
            statuses['Implemented'].color,
            statuses['Not Implemented'].color,
            statuses['Not Applicable'].color,
            statuses['Partially Implemented'].color
        ],

        plotOptions: {
            bar: {
                horizontal: false,
                columnWidth: '55%',
                borderRadius: 0,
                dataLabels: {
                    position: 'top'
                }
            }
        },

        dataLabels: {
            enabled: true,
            formatter: function (val) {
                return val === 0 ? '' : `${val.toFixed(1)}%`;
            },
            offsetY: -6,
            style: {
                fontSize: '12px',
                fontWeight: 600,
                colors: ['#000'],
                fontFamily: isRTL ? 'Cairo, Arial, sans-serif' : 'inherit'
            },
            background: {
                enabled: false
            }
        },

        stroke: {
            show: false
        },

        xaxis: {
            categories: labels,
            opposite: isRTL,
            labels: {
                style: {
                    fontSize: '12px',
                    fontWeight: 500,
                    fontFamily: 'inherit'
                }
            },
            title: {
                text: translations.domainName,
                style: {
                    fontSize: '14px',
                    fontWeight: 'bold',
                    fontFamily: 'inherit'
                }
            },
            axisBorder: { show: true },
            axisTicks: { show: true }
        },

        yaxis: {
            min: 0,
            max: 100,
            tickAmount: 5,
            opposite: isRTL,
            labels: {
                formatter: val => `${val}%`,
                style: {
                    fontSize: '12px',
                    fontFamily: 'inherit'
                }
            },
            title: {
                text: `${translations.percentage} (%)`,
                style: {
                    fontSize: '14px',
                    fontWeight: 'bold',
                    fontFamily: 'inherit'
                }
            }
        },

        tooltip: {
            shared: true,
            intersect: false,
            y: {
                formatter: val => `${val.toFixed(1)}%`
            },
            style: {
                fontFamily: 'inherit',
                direction: 'ltr'
            }
        },

        legend: {
            position: 'bottom',
            horizontalAlign: 'center',
            fontSize: '14px',
            fontFamily: 'inherit',
            fontWeight: 500,
            markers: {
                width: 12,
                height: 12,
                radius: 6
            },
            itemMargin: {
                horizontal: 15,
                vertical: 10
            }
        },

        grid: {
            borderColor: '#e0e0e0',
            strokeDashArray: 4,
            xaxis: {
                lines: { show: false }
            },
            yaxis: {
                lines: { show: true }
            }
        }
    };

    const chart = new ApexCharts(chartContainer, options);
    chart.render();

    // Save reference (PDF export)
    window.domainChart = chart;
}


        const handleFrameworkChange = function() {
            const framework = $(this).val();
            $.ajax({
                url: "{{ route('admin.reporting.summary_of_results_for_evaluation_and_compliance_info') }}",
                type: "POST",
                data: {
                    framework_id: framework,
                    _token: $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    if (response.status) {
                        console.log(response);
                        $('#chartDomaingraph').css('display', 'block');
                        $('#chartDomaingraph').slideDown();
                        GetchartDomain(response.data.domainStatusCounts);

                        $('#report-table-container #report-header').html(
                            `<h1 class="text-center" style="font-size: 1.5rem;">
                            <span class="badge rounded-pill badge-glow bg-primary" 
                                  style="font-size: 1.5rem; padding: 0.5rem 1.5rem; line-height: unset;">
                                ${reportName}
                            </span>
                        </h1>
                        <p class="text-center">${response.data.dateTime}</p>`
                        );

                        if (response.data.domains.length) {
                            $('.export-pdf-btn').slideDown();
                            $('#report-table-container-empty').slideUp();
                            $('#report-table-container').slideDown();

                            const totalFrameworkControlStatusesTable = $('#total-framework-control-statuses-table');
                            totalFrameworkControlStatusesTable.find('tbody tr:nth-of-type(1) td:nth-of-type(2)').text(response.data.data.total['Not Applicable']);
                            totalFrameworkControlStatusesTable.find('tbody tr:nth-of-type(2) td:nth-of-type(2)').text(response.data.data.total['Not Implemented']);
                            totalFrameworkControlStatusesTable.find('tbody tr:nth-of-type(3) td:nth-of-type(2)').text(response.data.data.total['Partially Implemented']);
                            totalFrameworkControlStatusesTable.find('tbody tr:nth-of-type(4) td:nth-of-type(2)').text(response.data.data.total['Implemented']);

                            $('#donut-chart-total').html('');
                            drawDonutChart('#donut-chart-total', [
                                response.data.data.total['Not Applicable'],
                                response.data.data.total['Not Implemented'],
                                response.data.data.total['Partially Implemented'],
                                response.data.data.total['Implemented']
                            ], response.data.data.all);

                            $('#report-table-container .row .framwwork-domains-statuses').remove();
                            response.data.domains.forEach((domain, domainIndex) => {
                                const domainCard = `
                                <div class="col-12 framwwork-domains-statuses">
                                    <div class="">
                                        <div class="alert alert-primary" role="alert">
                                            <div class="alert-body text-center" style="font-size: 16px; font-weight: bold;">
                                                ${domain.name} - ${domainIndex + 1}
                                            </div>
                                        </div>
                                        <div class="card-body pt-0 row align-items-center justify-content-center pdf-export-container">
                                            <div class="col-xl-9 col-12 ${isRTL ? 'order-2 order-xl-1' : ''} graph-view">
                                                <div id="donut-chart-domain-${domain.id}"></div>
                                            </div>
                                            <div class="col-xl-3 col-12 ${isRTL ? 'order-1 order-xl-2' : ''} data-view">
                                                <table class="table w-100" dir="${isRTL ? 'rtl' : 'ltr'}" 
                                                       style="${isRTL ? 'text-align: right;' : 'text-align: left;'}">
                                                    <thead>
                                                        <tr class="text-center">
                                                            <th colspan="2" style="${isRTL ? 'text-align: right;' : 'text-align: left;'}">
                                                                {{ __('report.Status') }}
                                                            </th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td class="col-9" style="${isRTL ? 'text-align: right;' : 'text-align: left;'}">
                                                                ${lang['Not Applicable']}
                                                            </td>
                                                            <td class="col-3 text-center">
                                                                ${domain['Not Applicable']}
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td class="col-9" style="${isRTL ? 'text-align: right;' : 'text-align: left;'}">
                                                                ${lang['Not Implemented']}
                                                            </td>
                                                            <td class="col-3 text-center">
                                                                ${domain['Not Implemented']}
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td class="col-9" style="${isRTL ? 'text-align: right;' : 'text-align: left;'}">
                                                                ${lang['Partially Implemented']}
                                                            </td>
                                                            <td class="col-3 text-center">
                                                                ${domain['Partially Implemented']}
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td class="col-9" style="${isRTL ? 'text-align: right;' : 'text-align: left;'}">
                                                                ${lang['Implemented']}
                                                            </td>
                                                            <td class="col-3 text-center">
                                                                ${domain['Implemented']}
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            `;
                                $('#report-table-container > .row.mt-2').append(domainCard);
                                $(`#donut-chart-domain-${domain.id}`).html('');
                                drawDonutChart(`#donut-chart-domain-${domain.id}`, [
                                    domain['Not Applicable'],
                                    domain['Not Implemented'],
                                    domain['Partially Implemented'],
                                    domain['Implemented']
                                ], domain['total']);
                            });

                            $('#report-table-container-empty').slideUp();
                            $('#report-table-container').slideDown();
                        } else {
                            $('.export-pdf-btn').slideUp();
                            $('#report-table-container-empty').slideDown();
                            $('#report-table-container').slideUp();
                        }

                        makeAlert('success', response.message, translations.success);
                    } else {
                        $('#report-table-container-empty').slideDown();
                        $('#report-table-container').slideUp();
                        showError(response.errors);
                    }
                },
                error: function(response) {
                    $('.export-pdf-btn').slideUp();
                    $('#report-table-container-empty').slideDown();
                    $('#report-table-container').slideUp();
                    const responseData = response.responseJSON;
                    makeAlert('error', responseData.message, translations.error);
                    showError(responseData.errors);
                }
            });
        };

        $('#framework').on('change', handleFrameworkChange);

        @if ($frameworkId !== null)
            $('#framework').val('{{ $frameworkId }}').change();
        @endif

        $('#AuditName').on('change', function(e) {
            const framework = $('#framework').val();
            const auditName = $('#AuditName').val();

            $.ajax({
                url: "{{ route('admin.reporting.summary_of_results_for_evaluation_and_compliance_info') }}",
                type: "POST",
                data: {
                    framework_id: framework,
                    audit_name: auditName,
                    _token: $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    if (response.status) {
                        $('#report-table-container #report-header').html(
                            `<h1 class="text-center" style="font-size: 1.5rem;"><span class="badge rounded-pill badge-glow bg-primary" style="font-size: 1.5rem; padding: 0.5rem 1.5rem; line-height: unset;">${reportName}</span></h1><p class="text-center">${response.data.dateTime}</p>`
                        );

                        if (response.data.domains.length) {
                            $('.export-pdf-btn').slideDown();
                            $('#report-table-container-empty').slideUp();
                            $('#report-table-container').slideDown();

                            const totalFrameworkControlStatusesTable = $('#total-framework-control-statuses-table');
                            totalFrameworkControlStatusesTable.find('tbody tr:nth-of-type(1) td:nth-of-type(2)').text(response.data.data.total['Not Applicable']);
                            totalFrameworkControlStatusesTable.find('tbody tr:nth-of-type(2) td:nth-of-type(2)').text(response.data.data.total['Not Implemented']);
                            totalFrameworkControlStatusesTable.find('tbody tr:nth-of-type(3) td:nth-of-type(2)').text(response.data.data.total['Partially Implemented']);
                            totalFrameworkControlStatusesTable.find('tbody tr:nth-of-type(4) td:nth-of-type(2)').text(response.data.data.total['Implemented']);

                            $('#donut-chart-total').html('');
                            drawDonutChart('#donut-chart-total', [
                                response.data.data.total['Not Applicable'],
                                response.data.data.total['Not Implemented'],
                                response.data.data.total['Partially Implemented'],
                                response.data.data.total['Implemented']
                            ], response.data.data.all);

                            $('#report-table-container .row .framwwork-domains-statuses').remove();
                            response.data.domains.forEach((domain, domainIndex) => {
                                const domainCard = `
                                <div class="col-12 framwwork-domains-statuses">
                                    <div class="">
                                        <div class="alert alert-primary" role="alert">
                                            <div class="alert-body text-center" style="font-size: 16px; font-weight: bold;">
                                                ${domain.name} - ${domainIndex + 1}
                                            </div>
                                        </div>
                                        <div class="card-body pt-0 row align-items-center justify-content-center pdf-export-container">
                                            <div class="col-xl-9 col-12 ${isRTL ? 'order-2 order-xl-1' : ''} graph-view">
                                                <div id="donut-chart-domain-${domain.id}"></div>
                                            </div>
                                            <div class="col-xl-3 col-12 ${isRTL ? 'order-1 order-xl-2' : ''} data-view">
                                                <table class="table w-100" dir="${isRTL ? 'rtl' : 'ltr'}" 
                                                       style="${isRTL ? 'text-align: right;' : 'text-align: left;'}">
                                                    <thead>
                                                        <tr class="text-center">
                                                            <th colspan="2" style="${isRTL ? 'text-align: right;' : 'text-align: left;'}">
                                                                {{ __('report.Status') }}
                                                            </th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td class="col-9" style="${isRTL ? 'text-align: right;' : 'text-align: left;'}">
                                                                ${lang['Not Applicable']}
                                                            </td>
                                                            <td class="col-3 text-center">
                                                                ${domain['Not Applicable']}
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td class="col-9" style="${isRTL ? 'text-align: right;' : 'text-align: left;'}">
                                                                ${lang['Not Implemented']}
                                                            </td>
                                                            <td class="col-3 text-center">
                                                                ${domain['Not Implemented']}
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td class="col-9" style="${isRTL ? 'text-align: right;' : 'text-align: left;'}">
                                                                ${lang['Partially Implemented']}
                                                            </td>
                                                            <td class="col-3 text-center">
                                                                ${domain['Partially Implemented']}
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td class="col-9" style="${isRTL ? 'text-align: right;' : 'text-align: left;'}">
                                                                ${lang['Implemented']}
                                                            </td>
                                                            <td class="col-3 text-center">
                                                                ${domain['Implemented']}
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            `;
                                $('#report-table-container > .row.mt-2').append(domainCard);
                                $(`#donut-chart-domain-${domain.id}`).html('');
                                drawDonutChart(`#donut-chart-domain-${domain.id}`, [
                                    domain['Not Applicable'],
                                    domain['Not Implemented'],
                                    domain['Partially Implemented'],
                                    domain['Implemented']
                                ], domain['total']);
                            });
                            GetchartDomain(response.data.domainStatusCounts);

                            $('#report-table-container-empty').slideUp();
                            $('#report-table-container').slideDown();
                        } else {
                            $('.export-pdf-btn').slideUp();
                            $('#report-table-container-empty').slideDown();
                            $('#report-table-container').slideUp();
                        }

                        makeAlert('success', response.message, translations.success);
                    } else {
                        $('#report-table-container-empty').slideDown();
                        $('#report-table-container').slideUp();
                        showError(response.errors);
                    }
                },
                error: function(response, data) {
                    $('.export-pdf-btn').slideUp();
                    $('#report-table-container-empty').slideDown();
                    $('#report-table-container').slideUp();
                    const responseData = response.responseJSON;
                    makeAlert('error', responseData.message, translations.error);
                    showError(responseData.errors);
                }
            });
        });

        function makeAlert($status, message, title) {
            if (title == translations.success)
                title = '👋' + title;
            toastr[$status](message, title, {
                closeButton: true,
                tapToDismiss: false,
            });
        }

        function showError(data) {
            $('.error').empty();
            $.each(data, function(key, value) {
                $('.error-' + key).empty();
                $('.error-' + key).append(value);
            });
        }

        $(document).ready(function() {
            $('#framework').off('change').on('change', function() {
                var frameworkId = $(this).val();

                $.ajax({
                    url: "{{ route('admin.reporting.auditTestNumber', ['id' => ':id']) }}".replace(':id', frameworkId),
                    type: 'GET',
                    success: function(response) {
                        $('#AuditName').empty().append(
                            '<option value="" selected>' + translations.selectOption + '</option>'
                        );

                        if (response.auditData.length > 0) {
                            $.each(response.auditData, function(index, audit) {
                                var formattedText = audit.audit_name + " -- " +
                                    translations.testNumber + ": " + audit.test_number_initiated;
                                $('#AuditName').append('<option value="' + audit.audit_name + '">' + formattedText + '</option>');
                            });
                        } else {
                            $('#AuditName').append(
                                '<option value="" disabled selected>' + translations.selectOption + '</option>'
                            );
                        }
                    },
                    error: function(error) {
                        console.error(error);
                    }
                });
            });

            @if ($frameworkId !== null)
                $('#framework').val('{{ $frameworkId }}').trigger('change');
            @endif

            // Initialize feather icons if available
            if (typeof feather !== 'undefined') {
                feather.replace();
            }
        });
    </script>
@endsection