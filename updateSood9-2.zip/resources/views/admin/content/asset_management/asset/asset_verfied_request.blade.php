@extends('admin/layouts/contentLayoutMaster')

@section('title', __('asset.VerifiedAssetRequests'))

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/pickadate/pickadate.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/flatpickr/flatpickr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/dataTables.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/responsive.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/buttons.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/pickadate/pickadate.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/flatpickr/flatpickr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/animate/animate.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">

@endsection

@section('page-style')
    {{-- <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}"> --}}
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/base/plugins/forms/pickers/form-flat-pickr.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/forms/pickers/form-flat-pickr.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/forms/pickers/form-pickadate.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-sweet-alerts.css')) }}">
    <link rel="stylesheet" type="text/css" href="{{ asset(mix('vendors/css/forms/wizard/bs-stepper.min.css')) }}">
    <link rel="stylesheet" type="text/css" href="{{ asset(mix('css/base/plugins/forms/form-wizard.css')) }}">
    <link rel="stylesheet" href="{{ asset('cdn/all.min.css') }}">

    <style>
        .card.domains span {
            background: #f2f2f2;
            margin: 5px;
            border: 1px solid #DDD;
            padding: 5px;
            border-radius: 15px;
        }

        .btn {
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        .btn:hover {
            transform: translateY(-2px);
        }

        .card {
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .alert {
            border-radius: 8px;
        }

        .card.domains {
            {{--  display: flex;  --}} {{--  flex-flow: wrap;  --}}
        }

        /* .slide-table {
                                                                                                                                                                                                                                                                    display: none;
                                                                                                                                                                                                                                                                } */

        .apexcharts-canvas {
            margin: auto !important
        }

        .node circle {
            fill: #fff;
            stroke: steelblue;
            stroke-width: 3px;
        }



        .link {
            fill: none;
            stroke: #ccc;
            stroke-width: 2px;
        }

        .table-striped tbody tr:nth-of-type(odd) {
            --bs-table-accent-bg: white !important;
        }

        #sedationModal .modal-dialog.modal-fullscreen {
            max-width: 100%;
            width: 100%;
            height: 100%;
            margin: 0;
        }

        #sedationModal .modal-content {
            height: 100%;
            border-radius: 0;
        }

        #sedationModal .modal-body {
            overflow-y: auto;
            height: calc(100% - 56px);
            /* Adjust based on header and footer height */
        }

        #sedationModal .modal-header,
        #sedationModal .modal-footer {
            padding: 15px;
        }

        .modal-custom-size {
            max-width: 60%;
            /* Adjust this value as needed */
        }

        .card {
            border: none;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        .button-icon {
            color: #007bff;
            /* Bootstrap primary color */
            font-size: 24px;
        }

        .button-icon:hover {
            color: #0056b3;
            /* Darker shade on hover */
        }

        .alert {
            border-radius: 15px;
            margin-bottom: 20px;
        }

        .chart-container {
            position: relative;
            height: 40vh;
            width: 100%;
        }

        .logo {
            margin-bottom: 20px;
            text-align: center;
        }

        .framework-name {
            font-size: 26px;
            color: #343a40;
            font-weight: bold;
        }

        .framework-description {
            font-size: 16px;
            line-height: 1.6;
            color: #6c757d !important;
        }

        .fa-history {
            color: #ff6347 !important;
            /* Tomato color */
        }

        .icon-current {
            color: #4caf50 !important;
            /* Green color */
        }

        .fa-arrow-left {
            color: #2196f3 !important;
            /* Blue color */
        }

        .fas {
            font-size: 21px !important;
        }

        < !-- Custom CSS for fluid modal -->.modal-dialog-fluid {
            max-width: 90% !important;
            ;
            /* Adjust this value as needed */
            width: auto;
        }

        @media (min-width: 768px) {
            .modal-dialog-fluid {
                max-width: 80% !important;
                ;
                /* Adjust this value as needed for larger screens */
            }
        }

        @media (min-width: 992px) {
            .modal-dialog-fluid {
                max-width: 70% !important;
                ;
                /* Adjust this value as needed for larger screens */
            }
        }

        @media (min-width: 1200px) {
            .modal-dialog-fluid {
                max-width: 60% !important;
                ;
                /* Adjust this value as needed for larger screens */
            }
        }


        .radial-progress-card h6 {
            font-size: 1.2rem;
        }

        .sale-details {
            font-size: 1.5rem;
            font-weight: bold;
        }

        .f-light {
            font-size: 0.9rem;
        }

        .modern-card {
            border: none;
            /* No border for a clean look */
            border-radius: 12px;
            /* Rounded corners */
            background-color: #ffffff;
            /* White background */
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            /* Soft shadow */
            transition: transform 0.3s, box-shadow 0.3s;
            /* Smooth transitions */
        }

        .modern-card:hover {
            transform: translateY(-5px);
            /* Lift effect on hover */
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.15);
            /* Enhanced shadow on hover */
        }

        .status-box h6 {
            font-size: 1.15rem;
            /* Font size for status */
            font-weight: 600;
            /* Semi-bold */
            color: #4a4a4a;
            /* Dark gray color */
        }

        .count-text {
            font-size: 1.4rem;
            /* Larger font for count */
            font-weight: bold;
            /* Bold text for emphasis */
            color: #3b82f6;
            /* Blue color for count */
        }

        .percentage-text {
            font-size: 0.85rem;
            /* Smaller font for percentage */
            color: #6b7280;
            /* Gray color for less emphasis */
        }

        .total-controls {
            font-size: 0.9rem;
            /* Font size for total controls */
            color: #9ca3af;
            /* Lighter gray color */
            margin-top: 10px;
            /* Space above */
        }

        .radial-chart-wrap {
            margin-top: 15px;
            /* Spacing for the chart */
            display: flex;
            /* Flexbox for centering */
            justify-content: center;
            /* Center horizontally */
            align-items: center;
            /* Center vertically */
        }

        .card-header.card-no-border.pb-0.d-flex {
            justify-content: space-between !important;
        }

        #showRequirementDetailsModal {
            z-index: 999999999999999999;
        }

        /* Animation for radial charts */
        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        .radial-chart-wrap {
            animation: fadeIn 0.5s ease-in;
            /* Animation effect */
        }

        .widget-1 .widget-round.secondary {
            border-color: #e1cfcd !important;
        }

        /* Adjust margins and styling for modal form */
    </style>
@endsection
@section('content')

    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">

            <div class="row breadcrumbs-top  widget-grid">
                <div class="col-12">
                    <div class="page-title mt-2">
                        <div class="row">
                            <div class="col-sm-6 ps-0">
                                @if (@isset($breadcrumbs))
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}"
                                                style="display: flex;">
                                                <svg class="stroke-icon">
                                                    <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}">
                                                    </use>
                                                </svg></a></li>
                                        @foreach ($breadcrumbs as $breadcrumb)
                                            <li class="breadcrumb-item">
                                                @if (isset($breadcrumb['link']))
                                                    <a
                                                        href="{{ $breadcrumb['link'] == 'javascript:void(0)' ? $breadcrumb['link'] : url($breadcrumb['link']) }}">
                                                @endif
                                                {{ $breadcrumb['name'] }}
                                                @if (isset($breadcrumb['link']))
                                                    </a>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ol>
                                @endisset
                        </div>
                        <div class="col-sm-6 pe-0" style="text-align: end;">

                            <div class="action-content">
                                {{-- @if (auth()->user()->hasPermission('audits.create'))
                                    <a href="{{ route('admin.governance.notificationsSettingsAduitSchedule') }}"
                                        class=" btn btn-primary" target="_self">
                                        <i class="fa fa-regular fa-bell"></i>
                                    </a>
                                @endif --}}


                                <!--
                                <a class="btn btn-primary" href="http://"> <i class="fa fa-solid fa-gear"></i> </a> -->
                                {{-- <a class="btn btn-primary"
                                    href="{{ route('admin.governance.framework.ajax.graphViewFramework', ['id' => $framework->id]) }}">
                                    <i class="fa-solid fa-file-invoice"></i> --}}
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <div id="quill-service-content" class="d-none"></div>

    <table id="dataTableREfresh" class="dt-advanced-server-search table">
        <thead>
            <tr>
                <th>#</th>
                <th>{{ __('asset.Asset') }}</th>
                <th>{{ __('asset.RequestedBy') }}</th>
                <th>{{ __('asset.Status') }}</th>
                <th>{{ __('asset.type') }}</th>
                <th>{{ __('asset.DoneBy') }}</th>
                <th>{{ __('asset.DoneAt') }}</th>
                <th>{{ __('asset.RequestedAt') }}</th>
                <th>{{ __('asset.Actions') }}</th>
            </tr>
        </thead>
    </table>
</div>




@endsection
@section('vendor-script')
<script src="{{ asset('js/scripts/components/components-dropdowns-font-awesome.js') }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/jquery.dataTables.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.bootstrap5.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.responsive.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/responsive.bootstrap5.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/pickers/flatpickr/flatpickr.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/buttons.print.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/datatables.buttons.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/pickers/pickadate/picker.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/pickers/pickadate/picker.date.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/pickers/pickadate/picker.time.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/pickers/pickadate/legacy.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>
@endsection

@section('page-script')
<script src="{{ asset(mix('vendors/js/tables/datatable/responsive.bootstrap5.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/datatables.checkboxes.min.js')) }}"></script>
<script src="{{ asset(mix('js/scripts/forms/form-select2.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/forms/wizard/bs-stepper.min.js')) }}"></script>
<script src="{{ asset(mix('js/scripts/forms/form-wizard.js')) }}"></script>
<script src="{{ asset('js/scripts/config.js') }}"></script>
<script src="{{ asset(mix('vendors/js/charts/chart.min.js')) }}"></script>
<script src="{{ asset('new_d/js/chart/chartist/chartist.js') }}"></script>
<script src="{{ asset('new_d/js/chart/chartist/chartist-plugin-tooltip.js') }}"></script>
<script src="{{ asset('new_d/js/chart/apex-chart/apex-chart.js') }}"></script>
<script src="{{ asset('new_d/js/chart/apex-chart/stock-prices.js') }}"></script>
<script src="{{ asset('ajax-files/asset_management/asset/index.js') }}"></script>
<script src="{{ asset('js/scripts/highcharts/highcharts.js') }}"></script>
<script src="{{ asset('js/scripts/config.js') }}"></script>
<script src="{{ asset('cdn/d3_1.min.js') }}"></script>
<script src="{{ asset(mix('vendors/js/charts/chart.min.js')) }}"></script>
<script src="{{ asset('cdn/chart.js') }}"></script>
<script src="{{ asset('cdn/jquery-ui.min.js') }}"></script>
<script src="{{ asset('cdn/feather-icons') }}"></script>
<script src="{{ asset('cdn/sedation-jquery-ui.min.js') }}"></script>


<script type="text/javascript">
    $(document).ready(function() {

        let table = $('#dataTableREfresh').DataTable({
            processing: true,
            serverSide: true,
            responsive: true,
            ajax: {
                url: "{{ route('admin.asset_management.ajax.ajaxTableVerfiedRequest') }}",
                type: "POST",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            },
            columns: [{
                    data: 'id',
                    name: 'id'
                },
                {
                    data: 'asset_name',
                    name: 'asset.name'
                },
                {
                    data: 'requested_by',
                    name: 'requester.name'
                },
                {
                    data: 'status',
                    name: 'status'
                },
                {
                    data: 'type',
                    name: 'type'
                },
                {
                    data: 'done_by',
                    name: 'doneBy.name'
                },
                {
                    data: 'done_at',
                    name: 'done_at'
                },
                {
                    data: 'created_at',
                    name: 'created_at'
                },
                {
                    data: 'actions',
                    name: 'actions',
                    orderable: false,
                    searchable: false
                }
            ],
            order: [
                [0, 'desc']
            ]
        });

    });


    function handleVerifyRequest(id, action) {
        let title = action === 'approve' ? 'Approve request?' : 'Reject request?';
        let confirmText = action === 'approve' ?
            'This will mark the asset as verified.' :
            'This request will be rejected.';

        Swal.fire({
            title: title,
            text: confirmText,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: action === 'approve' ? 'Yes, approve' : 'Yes, reject',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {

                $.ajax({
                    url: "{{ route('admin.asset_management.ajax.verifyOrRejectRequest', ':id') }}"
                        .replace(':id', id),
                    type: 'POST',
                    data: {
                        _token: $('meta[name="csrf-token"]').attr('content'),
                        action: action
                    },
                    success: function(response) {
                        Swal.fire(
                            action === 'approve' ? 'Approved' : 'Rejected',
                            response.message,
                            'success'
                        );

                        $('#dataTableREfresh').DataTable().ajax.reload(null, false);
                    },
                    error: function(xhr) {
                        Swal.fire(
                            'Error',
                            xhr.responseJSON?.message ?? 'Something went wrong',
                            'error'
                        );
                    }
                });

            }
        });
    }
</script>
@endsection
