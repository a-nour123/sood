<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('assets', function (Blueprint $table) {
            $table->integer('rank')->nullable()->after('asset_owner');
            $table->integer('can_update')->nullable()->after('rank');
            $table->integer('can_delete')->nullable()->after('can_update');            
        });
    }

    public function down(): void
    {
        Schema::table('assets', function (Blueprint $table) {
            $table->dropColumn('rank');
        });
    }
};

