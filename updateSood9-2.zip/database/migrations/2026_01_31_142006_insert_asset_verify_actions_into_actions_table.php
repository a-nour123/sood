<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        DB::table('actions')->insert([
            [
                'id'   => 172,
                'name' => 'create_asset_verification_request',
            ],
            [
                'id'   => 173,
                'name' => 'approve_or_reject_asset_verification_request',
            ],
            [
                'id'   => 174,
                'name' => 'notify_asset_not_has_assessment',
            ],
        ]);
    }

    public function down(): void
    {
        DB::table('actions')
            ->whereIn('id', [172, 173])
            ->delete();
    }
};
