<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('request_histories', function (Blueprint $table) {
            $table->id();

            $table->foreignId('request_id')
                ->constrained('cybersecurity_requests')
                ->cascadeOnDelete();

            $table->foreignId('user_id')
                ->constrained('users')
                ->cascadeOnDelete();

            $table->string('action');

            $table->string('old_status')->nullable();
            $table->string('new_status')->nullable();

            $table->text('notes')->nullable();

            $table->timestamps();

            // Optional indexes for performance
            $table->index('action');
            $table->index('created_at');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('request_histories');
    }
};
