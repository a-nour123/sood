@extends('admin/layouts/contentLayoutMaster')

@section('title', __('request.title'))

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/charts/apexcharts.css')) }}">
@endsection

@section('content')
    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">
            <div class="row breadcrumbs-top widget-grid">
                <div class="col-12">
                    <div class="page-title mt-2">
                        <div class="row">
                            <div class="col-md-12 ps-0">
                                @if (@isset($breadcrumbs))
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item">
                                            <a href="{{ route('admin.dashboard') }}" style="display: flex;">
                                                <svg class="stroke-icon">
                                                    <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}"></use>
                                                </svg>
                                            </a>
                                        </li>
                                        @foreach ($breadcrumbs as $breadcrumb)
                                            <li class="breadcrumb-item">
                                                @if (isset($breadcrumb['link']))
                                                    <a href="{{ $breadcrumb['link'] == 'javascript:void(0)' ? $breadcrumb['link'] : url($breadcrumb['link']) }}">
                                                @endif
                                                {{ __($breadcrumb['name']) }}
                                                @if (isset($breadcrumb['link']))
                                                    </a>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ol>
                                @endisset
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row">
        <div class="col-lg-3 col-sm-6 col-12">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h3 class="fw-bolder mb-75">{{ $totalRequests }}</h3>
                            <span>{{ __('request.total_requests') }}</span>
                        </div>
                        <div class="avatar bg-light-primary p-50">
                            <span class="avatar-content">
                                <i class="fa fa-file-alt font-medium-4"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-sm-6 col-12">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h3 class="fw-bolder mb-75">{{ $completedRequests }}</h3>
                            <span>{{ __('request.completed') }}</span>
                        </div>
                        <div class="avatar bg-light-success p-50">
                            <span class="avatar-content">
                                <i class="fa fa-check-circle font-medium-4"></i>
                            </span>
                        </div>
                    </div>
                    <small class="text-muted">{{ $completionRate }}% {{ __('request.completion_rate') }}</small>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-sm-6 col-12">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h3 class="fw-bolder mb-75">{{ $pendingRequests }}</h3>
                            <span>{{ __('request.pending') }}</span>
                        </div>
                        <div class="avatar bg-light-warning p-50">
                            <span class="avatar-content">
                                <i class="fa fa-clock font-medium-4"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-sm-6 col-12">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h3 class="fw-bolder mb-75">{{ $lateRequestsTotal }}</h3>
                            <span>{{ __('request.late_requests') }}</span>
                        </div>
                        <div class="avatar bg-light-danger p-50">
                            <span class="avatar-content">
                                <i class="fa fa-exclamation-triangle font-medium-4"></i>
                            </span>
                        </div>
                    </div>
                    <small class="text-muted">{{ __('request.avg_completion') }}: {{ $avgCompletionTime }} {{ __('request.days') }}</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Charts Row 1 -->
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">{{ __('request.requests_by_department') }}</h4>
                </div>
                <div class="card-body">
                    <div id="chart-department"></div>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">{{ __('request.requests_by_type') }}</h4>
                </div>
                <div class="card-body">
                    <div id="chart-type"></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Charts Row 2 -->
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">{{ __('request.requests_by_status') }}</h4>
                </div>
                <div class="card-body">
                    <div id="chart-status"></div>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">{{ __('request.requests_by_priority') }}</h4>
                </div>
                <div class="card-body">
                    <div id="chart-priority"></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Department Ranking & Processing Time -->
    @if(isset($departmentRanking) && $departmentRanking->count() > 0)
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">{{ __('request.department_ranking') }}</h4>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>{{ __('request.rank') }}</th>
                                <th>{{ __('request.department') }}</th>
                                <th>{{ __('request.total_requests') }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($departmentRanking as $index => $dept)
                            <tr>
                                <td>{{ $index + 1 }}</td>
                                <td>{{ $dept->name ?? $dept->department_name }}</td>
                                <td><span class="badge bg-primary">{{ $dept->total }}</span></td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">{{ __('request.avg_processing_time') }}</h4>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>{{ __('request.department') }}</th>
                                <th>{{ __('request.avg_days') }}</th>
                                <th>{{ __('request.late_requests') }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(isset($avgProcessingTime) && $avgProcessingTime->count() > 0)
                                @foreach($avgProcessingTime as $dept)
                                <tr>
                                    <td>{{ $dept->name ?? $dept->department_name }}</td>
                                    <td><span class="badge bg-info">{{ $dept->avg_days }} {{ __('request.days') }}</span></td>
                                    <td><span class="badge bg-danger">{{ $lateRequestsByDepartment[$dept->name] ?? 0 }}</span></td>
                                </tr>
                                @endforeach
                            @else
                                <tr>
                                    <td colspan="3" class="text-center">{{ __('request.no_data') }}</td>
                                </tr>
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    @endif

    <!-- Monthly Trends -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">{{ __('request.monthly_trends') }}</h4>
                </div>
                <div class="card-body">
                    <div id="chart-monthly-trends"></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Requests -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">{{ __('request.recent_requests') }}</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>{{ __('request.request_number') }}</th>
                                    <th>{{ __('request.requester') }}</th>
                                    <th>{{ __('request.department') }}</th>
                                    <th>{{ __('request.type') }}</th>
                                    <th>{{ __('request.priority') }}</th>
                                    <th>{{ __('request.status') }}</th>
                                    <th>{{ __('request.created') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($recentRequests as $req)
                                <tr>
                                    <td><a href="{{ route('admin.cybersecurity_requests.show', $req->id) }}">{{ $req->request_number }}</a></td>
                                    <td>{{ $req->requester->name ?? '-' }}</td>
                                    <td>{{ $req->department->name ?? $req->receiving_department }}</td>
                                    <td>{{ $req->requestType->name ?? __('request.na') }}</td>
                                    <td>
                                        @php
                                            $priorityColors = ['High' => 'danger', 'Moderate' => 'warning', 'Low' => 'success'];
                                        @endphp
                                        <span class="badge bg-{{ $priorityColors[$req->priority] ?? 'secondary' }}">{{ $req->priority }}</span>
                                    </td>
                                    <td>
                                        @php
                                            $statusColors = [
                                                'created' => 'info',
                                                'under management approval' => 'warning',
                                                'approved' => 'success',
                                                'under process' => 'primary',
                                                'closed' => 'secondary',
                                                'rejected' => 'danger'
                                            ];
                                        @endphp
                                        <span class="badge bg-{{ $statusColors[$req->status] ?? 'secondary' }}">{{ ucfirst($req->status) }}</span>
                                    </td>
                                    <td>{{ $req->created_at->format('Y-m-d') }}</td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/charts/apexcharts.min.js')) }}"></script>
@endsection

@section('page-script')
    <script>
        $(document).ready(function() {
            // Department Chart
            var departmentData = {!! json_encode($requestsByDepartment) !!};
            var departmentChart = new ApexCharts(document.querySelector("#chart-department"), {
                series: Object.values(departmentData),
                labels: Object.keys(departmentData),
                chart: { type: 'donut', height: 350 },
                legend: { position: 'bottom' }
            });
            departmentChart.render();

            // Type Chart
            var typeData = {!! json_encode($requestsByType) !!};
            var typeChart = new ApexCharts(document.querySelector("#chart-type"), {
                series: Object.values(typeData),
                labels: Object.keys(typeData),
                chart: { type: 'pie', height: 350 },
                legend: { position: 'bottom' }
            });
            typeChart.render();

            // Status Chart
            var statusData = {!! json_encode($requestsByStatus) !!};
            var statusChart = new ApexCharts(document.querySelector("#chart-status"), {
                series: Object.values(statusData),
                labels: Object.keys(statusData),
                chart: { type: 'donut', height: 350 },
                legend: { position: 'bottom' }
            });
            statusChart.render();

            // Priority Chart
            var priorityData = {!! json_encode($requestsByPriority) !!};
            var priorityChart = new ApexCharts(document.querySelector("#chart-priority"), {
                series: [{
                    data: Object.values(priorityData)
                }],
                chart: { type: 'bar', height: 350 },
                xaxis: { categories: Object.keys(priorityData) },
                colors: ['#7367f0']
            });
            priorityChart.render();

            // Monthly Trends
            var monthlyData = {!! json_encode($monthlyTrends) !!};
            var monthlyChart = new ApexCharts(document.querySelector("#chart-monthly-trends"), {
                series: [{
                    name: '{{ __('request.requests') }}',
                    data: monthlyData.map(item => item.total)
                }],
                chart: { type: 'area', height: 350 },
                xaxis: { categories: monthlyData.map(item => item.month) },
                colors: ['#7367f0']
            });
            monthlyChart.render();
        });
    </script>
@endsection