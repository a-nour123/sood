@extends('admin/layouts/contentLayoutMaster')

@section('title', __('request.title'))

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/dataTables.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/responsive.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">
@endsection

@section('page-style')
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-sweet-alerts.css')) }}">
@endsection

@section('content')
    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">
            <div class="row breadcrumbs-top widget-grid">
                <div class="col-12">
                    <div class="page-title mt-2">
                        <div class="row">
                            <div class="col-md-6 ps-0">
                                @if (@isset($breadcrumbs))
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item">
                                            <a href="{{ route('admin.dashboard') }}" style="display: flex;">
                                                <svg class="stroke-icon">
                                                    <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}">
                                                    </use>
                                                </svg>
                                            </a>
                                        </li>
                                        @foreach ($breadcrumbs as $breadcrumb)
                                            <li class="breadcrumb-item">
                                                @if (isset($breadcrumb['link']))
                                                    <a
                                                        href="{{ $breadcrumb['link'] == 'javascript:void(0)' ? $breadcrumb['link'] : url($breadcrumb['link']) }}">
                                                @endif
                                                {{ __($breadcrumb['name']) }}
                                                @if (isset($breadcrumb['link']))
                                                    </a>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ol>
                                @endisset
                        </div>
                        <div class="col-md-6 pe-0" style="text-align: end;">
                            <div class="action-content">
                                <a href="{{ route('admin.cybersecurity_requests.index') }}" class="btn btn-primary">
                                    <i class="fa fa-list"></i> {{ __('request.all_requests') }}
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">{{ __('request.my_assigned_requests') }}</h4>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label>{{ __('request.status') }}</label>
                        <select id="filter-status" class="form-select">
                            <option value="">{{ __('request.all') }}</option>
                            <option value="approved">{{ __('request.approved') }}</option>
                            <option value="under process">{{ __('request.under_process') }}</option>
                            <option value="closed">{{ __('request.closed') }}</option>
                            <option value="planned">{{ __('request.planned') }}</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label>{{ __('request.priority') }}</label>
                        <select id="filter-priority" class="form-select">
                            <option value="">{{ __('request.all') }}</option>
                            <option value="High">{{ __('request.high') }}</option>
                            <option value="Moderate">{{ __('request.moderate') }}</option>
                            <option value="Low">{{ __('request.low') }}</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label>{{ __('request.late_requests') }}</label>
                        <select id="filter-late" class="form-select">
                            <option value="">{{ __('request.all') }}</option>
                            <option value="1">{{ __('request.late_only') }}</option>
                        </select>
                    </div>
                </div>

                <table class="table table-hover" id="operator-table">
                    <thead>
                        <tr>
                            <th>{{ __('request.request_number') }}</th>
                            <th>{{ __('request.requester') }}</th>
                            <th>{{ __('request.type') }}</th>
                            <th>{{ __('request.priority') }}</th>
                            <th>{{ __('request.due_date') }}</th>
                            <th>{{ __('request.status') }}</th>
                            <th>{{ __('request.late') }}</th>
                            <th>{{ __('request.actions') }}</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Confirm Modal -->
<div class="modal fade" id="confirmModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">{{ __('request.confirm_start_processing') }}</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="confirmForm">
                @csrf
                <input type="hidden" name="request_id" id="confirm_request_id">
                <div class="modal-body">
                    <p>{{ __('request.confirm_start_message') }}</p>
                    <div class="mb-3">
                        <label class="form-label">{{ __('request.notes') }}</label>
                        <textarea class="form-control" name="notes" rows="3" placeholder="{{ __('request.optional_notes') }}"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary"
                        data-bs-dismiss="modal">{{ __('request.cancel') }}</button>
                    <button type="submit" class="btn btn-primary">{{ __('request.start_processing') }}</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Refuse Modal -->
<div class="modal fade" id="refuseModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">{{ __('request.refuse_request') }}</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="refuseForm">
                @csrf
                <input type="hidden" name="request_id" id="refuse_request_id">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">{{ __('request.reason_for_refusal') }} <span
                                class="text-danger">*</span></label>
                        <textarea class="form-control" name="notes" rows="3"
                            placeholder="{{ __('request.refusal_reason_placeholder') }}" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary"
                        data-bs-dismiss="modal">{{ __('request.cancel') }}</button>
                    <button type="submit" class="btn btn-warning">{{ __('request.refuse_request') }}</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Close Request Modal -->
<div class="modal fade" id="closeModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">{{ __('request.close_request') }}</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="closeForm" enctype="multipart/form-data">
                @csrf
                <input type="hidden" name="request_id" id="close_request_id">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">{{ __('request.final_status') }} <span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="final_status"
                            placeholder="{{ __('request.final_status_placeholder') }}" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">{{ __('request.completion_notes') }} <span
                                class="text-danger">*</span></label>
                        <textarea class="form-control" name="notes" rows="4"
                            placeholder="{{ __('request.completion_notes_placeholder') }}" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">{{ __('request.attachments') }}</label>
                        <input type="file" class="form-control" name="attachments[]" multiple>
                        <small class="text-muted">{{ __('request.max_file_size') }}</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary"
                        data-bs-dismiss="modal">{{ __('request.cancel') }}</button>
                    <button type="submit" class="btn btn-success">{{ __('request.close_request') }}</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@section('vendor-script')
<script src="{{ asset(mix('vendors/js/tables/datatable/jquery.dataTables.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.bootstrap5.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.responsive.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/responsive.bootstrap5.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>
@endsection

@section('page-script')
<script>
    $(document).ready(function() {
        const table = $('#operator-table').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: '{{ route('admin.cybersecurity_requests.operator.data') }}',
                data: function(d) {
                    d.status = $('#filter-status').val();
                    d.priority = $('#filter-priority').val();
                    d.late = $('#filter-late').val();
                }
            },
            columns: [{
                    data: 'request_number',
                    name: 'request_number'
                },
                {
                    data: 'requester_name',
                    name: 'requester.name'
                },
                {
                    data: 'requestType',
                    name: 'requestType'
                },
                {
                    data: 'priority_badge',
                    name: 'priority',
                    orderable: false
                },
                {
                    data: 'due_date',
                    name: 'due_date'
                },
                {
                    data: 'status_badge',
                    name: 'status',
                    orderable: false
                },
                {
                    data: 'is_late_badge',
                    name: 'is_late_badge',
                    orderable: false,
                    searchable: false
                },
                {
                    data: 'actions',
                    name: 'actions',
                    orderable: false,
                    searchable: false
                }
            ],
            order: [
                [4, 'asc']
            ], // Order by due date ascending
            responsive: true
        });

        // Filter handlers
        $('#filter-status, #filter-priority, #filter-late').change(function() {
            table.ajax.reload();
        });

        // Confirm request
        $(document).on('click', '.confirm-request', function() {
            const id = $(this).data('id');
            $('#confirm_request_id').val(id);
            $('#confirmModal').modal('show');
        });

        $('#confirmForm').on('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);

            $.ajax({
                url: '{{ route('admin.cybersecurity_requests.operator.confirm') }}',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        $('#confirmModal').modal('hide');
                        table.ajax.reload();
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr) {
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        toastr.error(xhr.responseJSON.message);
                    } else {
                        toastr.error('{{ __('request.error_confirming_request') }}');
                    }
                }
            });
        });

        // Refuse request
        $(document).on('click', '.refuse-request', function() {
            const id = $(this).data('id');
            $('#refuse_request_id').val(id);
            $('#refuseModal').modal('show');
        });

        $('#refuseForm').on('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);

            $.ajax({
                url: '{{ route('admin.cybersecurity_requests.operator.refuse') }}',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        $('#refuseModal').modal('hide');
                        table.ajax.reload();
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr) {
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        toastr.error(xhr.responseJSON.message);
                    } else {
                        toastr.error('{{ __('request.error_refusing_request') }}');
                    }
                }
            });
        });

        // Close request
        $(document).on('click', '.close-request', function() {
            const id = $(this).data('id');
            $('#close_request_id').val(id);
            $('#closeModal').modal('show');
        });

        $('#closeForm').on('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);

            $.ajax({
                url: '{{ route('admin.cybersecurity_requests.operator.close') }}',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        $('#closeModal').modal('hide');
                        table.ajax.reload();
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr) {
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        toastr.error(xhr.responseJSON.message);
                    } else {
                        toastr.error('{{ __('request.error_closing_request') }}');
                    }
                }
            });
        });

        // Reset forms when modals are hidden
        $('#confirmModal').on('hidden.bs.modal', function() {
            $('#confirmForm')[0].reset();
        });

        $('#refuseModal').on('hidden.bs.modal', function() {
            $('#refuseForm')[0].reset();
        });

        $('#closeModal').on('hidden.bs.modal', function() {
            $('#closeForm')[0].reset();
        });
    });
</script>
@endsection
