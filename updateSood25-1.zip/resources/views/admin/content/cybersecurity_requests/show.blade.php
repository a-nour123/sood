@extends('admin/layouts/contentLayoutMaster')

@section('title', __('request.title'))

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
@endsection

@section('page-style')
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <style>
        .timeline {
            position: relative;
            padding: 20px 0;
        }

        .timeline-item {
            position: relative;
            padding-left: 40px;
            margin-bottom: 30px;
        }

        .timeline-item::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: #7367f0;
        }

        .timeline-item::after {
            content: '';
            position: absolute;
            left: 5px;
            top: 12px;
            bottom: -30px;
            width: 2px;
            background: #e0e0e0;
        }

        .timeline-item:last-child::after {
            display: none;
        }

        .communication-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 15px;
        }

        .attachment-item {
            display: inline-block;
            padding: 8px 15px;
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-right: 10px;
            margin-bottom: 10px;
        }
    </style>
@endsection

@section('content')
    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">
            <div class="row breadcrumbs-top widget-grid">
                <div class="col-12">
                    <div class="page-title mt-2">
                        <div class="row">
                            <div class="col-md-12 ps-0">
                                @if (@isset($breadcrumbs))
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item">
                                            <a href="{{ route('admin.dashboard') }}" style="display: flex;">
                                                <svg class="stroke-icon">
                                                    <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}">
                                                    </use>
                                                </svg>
                                            </a>
                                        </li>
                                        @foreach ($breadcrumbs as $breadcrumb)
                                            <li class="breadcrumb-item">
                                                @if (isset($breadcrumb['link']))
                                                    <a
                                                        href="{{ $breadcrumb['link'] == 'javascript:void(0)' ? $breadcrumb['link'] : url($breadcrumb['link']) }}">
                                                @endif
                                                {{ __($breadcrumb['name']) }}
                                                @if (isset($breadcrumb['link']))
                                                    </a>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ol>
                                @endisset
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Request Information -->
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">{{ __('request.request_information') }}</h4>
                    <div class="d-flex gap-2">
                        @php
                            $statusColors = [
                                'created' => 'info',
                                'under management approval' => 'warning',
                                'approved' => 'success',
                                'under process' => 'primary',
                                'closed' => 'secondary',
                                'rejected' => 'danger',
                                'planned' => 'info',
                                'returned' => 'warning',
                            ];
                            $priorityColors = [
                                'High' => 'danger',
                                'Moderate' => 'warning',
                                'Low' => 'success',
                            ];
                        @endphp
                        <span class="badge bg-{{ $statusColors[$request->status] ?? 'secondary' }}">{{ ucfirst($request->status) }}</span>
                        <span class="badge bg-{{ $priorityColors[$request->priority] ?? 'secondary' }}">{{ $request->priority }}</span>
                        @if ($request->isLate())
                            <span class="badge bg-danger"><i class="fa fa-clock"></i> {{ __('request.late') }}</span>
                        @endif
                    </div>
                </div>
                <div class="card-body">
                    <table class="table table-borderless">
                        <tr>
                            <th width="200">{{ __('request.request_number') }}:</th>
                            <td>{{ $request->request_number }}</td>
                        </tr>
                        <tr>
                            <th>{{ __('request.created_at') }}:</th>
                            <td>{{ $request->created_at }}</td>
                        </tr>
                        <tr>
                            <th>{{ __('request.requester') }}:</th>
                            <td>{{ $request->requester->name ?? '-' }}</td>
                        </tr>
                        <tr>
                            <th>{{ __('request.requester_department') }}:</th>
                            <td>{{ $request->requesterDepartment->name }}</td>
                        </tr>
                        <tr>
                            <th>{{ __('request.receiving_department') }}:</th>
                            <td>{{ $request->department->name }}</td>
                        </tr>
                        <tr>
                            <th>{{ __('request.request_type') }}:</th>
                            <td>{{ $request->requestType->name }}</td>
                        </tr>
                        <tr>
                            <th>{{ __('request.request_reason') }}:</th>
                            <td>{{ $request->requestReason->name }}</td>
                        </tr>
                        <tr>
                            <th>{{ __('request.due_date') }}:</th>
                            <td>{{ $request->due_date }}</td>
                        </tr>
                        @if ($request->assigned_to)
                            <tr>
                                <th>{{ __('request.assigned_to') }}:</th>
                                <td>{{ $request->assignedUser->name ?? '-' }}</td>
                            </tr>
                        @endif
                        @if ($request->approved_by)
                            <tr>
                                <th>{{ __('request.approved_by') }}:</th>
                                <td>{{ $request->approver->name ?? '-' }} ({{ $request->approved_at }})</td>
                            </tr>
                        @endif
                        @if ($request->completed_at)
                            <tr>
                                <th>{{ __('request.completed_at') }}:</th>
                                <td>{{ $request->completed_at }}</td>
                            </tr>
                            <tr>
                                <th>{{ __('request.processing_time') }}:</th>
                                <td>{{ $request->getProcessingTime() }} {{ __('request.days') }}</td>
                            </tr>
                        @endif
                        @if ($request->final_status)
                            <tr>
                                <th>{{ __('request.final_status') }}:</th>
                                <td>{{ $request->final_status }}</td>
                            </tr>
                        @endif
                    </table>

                    <div class="mt-3">
                        <h5>{{ __('request.description') }}</h5>
                        <p>{{ $request->description }}</p>
                    </div>

                    @if ($request->approval_notes)
                        <div class="mt-3">
                            <h5>{{ __('request.approval_notes') }}</h5>
                            <p>{{ $request->approval_notes }}</p>
                        </div>
                    @endif

                    @if ($request->attachments->count() > 0)
                        <div class="mt-3">
                            <h5>{{ __('request.attachments') }}</h5>
                            @foreach ($request->attachments as $attachment)
                                <div class="attachment-item">
                                    <i class="fa fa-file"></i>
                                    <a href="{{ Storage::url($attachment->file_path) }}"
                                        download="{{ $attachment->file_name }}">
                                        {{ $attachment->file_name }}
                                    </a>
                                    <small class="text-muted">({{ $attachment->getFileSizeFormatted() }})</small>
                                </div>
                            @endforeach
                        </div>
                    @endif
                </div>
            </div>

            <!-- Communications -->
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">{{ __('request.communications') }}</h4>
                </div>
                <div class="card-body">
                    @forelse($request->communications as $comm)
                        <div class="communication-item">
                            <div class="d-flex justify-content-between">
                                <strong>{{ $comm->user->name }}</strong>
                                <small class="text-muted">{{ $comm->created_at }}</small>
                            </div>
                            <p class="mb-2 mt-2">{{ $comm->message }}</p>
                            @if ($comm->attachments->count() > 0)
                                <div class="attachments">
                                    @foreach ($comm->attachments as $att)
                                        <a href="{{ Storage::url($attachment->file_path) }}"
                                            download="{{ $attachment->file_name }}" class="btn btn-sm btn-outline-primary">
                                            <i class="fa fa-download"></i> {{ $att->file_name }}
                                        </a>
                                    @endforeach
                                </div>
                            @endif
                        </div>
                    @empty
                        <p class="text-muted">{{ __('request.no_communications') }}</p>
                    @endforelse

                    @if (!in_array($request->status, ['closed', 'rejected']))
                        <div class="mt-3">
                            <h5>{{ __('request.add_communication') }}</h5>
                            <form id="communication-form" enctype="multipart/form-data">
                                @csrf
                                <div class="mb-3">
                                    <textarea class="form-control" name="message" rows="3" placeholder="{{ __('request.enter_your_message') }}" required></textarea>
                                </div>
                                <div class="mb-3">
                                    <input type="file" class="form-control" name="attachments[]" multiple>
                                </div>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-paper-plane"></i> {{ __('request.send') }}
                                </button>
                            </form>
                        </div>
                    @endif
                </div>
            </div>
        </div>

        <!-- History -->
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">{{ __('request.request_history') }}</h4>
                </div>
                <div class="card-body">
                    <div class="timeline">
                        @foreach ($request->history as $history)
                            <div class="timeline-item">
                                <small class="text-muted">{{ $history->created_at }}</small>
                                <h6 class="mt-1">{{ $history->action }}</h6>
                                <p class="mb-0"><small>{{ __('request.by') }}: {{ $history->user->name }}</small></p>
                                @if ($history->notes)
                                    <p class="text-muted mt-1"><small>{{ $history->notes }}</small></p>
                                @endif
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('vendor-script')
<script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
@endsection

@section('page-script')
<script>
    $(document).ready(function() {
        $('#communication-form').on('submit', function(e) {
            e.preventDefault();

            const formData = new FormData(this);

            $.ajax({
                url: '{{ route('admin.cybersecurity_requests.communication.add', $request->id) }}',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        location.reload();
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr) {
                    toastr.error('{{ __('request.error_adding_communication') }}');
                }
            });
        });
    });
</script>
@endsection