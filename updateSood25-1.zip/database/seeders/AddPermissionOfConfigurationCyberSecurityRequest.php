<?php

namespace Database\Seeders;

use App\Models\PermissionGroup;
use App\Models\Subgroup;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class AddPermissionOfConfigurationCyberSecurityRequest extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        $permissionGroups  = PermissionGroup::pluck('id', 'name');
        $governanceId = $permissionGroups['Governance'];

        $subgroup = Subgroup::updateOrCreate([
            'name' => 'Cybersecurity Requests',
            "permission_group_id" => $governanceId
        ], [
            'name' => 'Cybersecurity Requests',
            "permission_group_id" => $governanceId
        ]);


        $subId = $subgroup->id;

        // Define all permissions needed for all controllers
        $permissions = [
            [
                'key' => 'cybersecurity_requests.configuration',
                'name' => 'configure cybersecurity request',
                'subgroup_id' => $subId,
                'created_at' => now(),
                'updated_at' => now(),
            ]
        ];

        // Insert permissions (skip duplicates)
        foreach ($permissions as $permission) {
            if (!DB::table('permissions')->where('key', $permission['key'])->exists()) {
                DB::table('permissions')->insert($permission);
            }
        }

        // ========== Assign permissions to roles ==========

        // 1. Super Admin (role_id = 1) - Gets ALL permissions
        $superAdminRoleId = 1;

        foreach ($permissions as $permission) {
            $permissionId = DB::table('permissions')
                ->where('key', $permission['key'])
                ->value('id');

            if ($permissionId) {
                // Check if already assigned
                $exists = DB::table('role_responsibilities')
                    ->where('role_id', $superAdminRoleId)
                    ->where('permission_id', $permissionId)
                    ->exists();

                if (!$exists) {
                    DB::table('role_responsibilities')->insert([
                        'role_id' => $superAdminRoleId,
                        'permission_id' => $permissionId,
                    ]);
                }
            }
        }



        $this->command->info('All cybersecurity permissions have been seeded successfully!');
    }
}
