<?php

namespace App\Http\Controllers\admin\CyberSecurity;

use App\Events\AddedCommunicationRequest;
use App\Events\ClosedRequest;
use App\Events\ConfirmedRequest;
use App\Events\RefusedRequest;
use App\Http\Controllers\Controller;
use App\Models\CybersecurityRequest;
use App\Models\Department;
use App\Models\RequestCommunication;
use App\Models\RequestCommunicationAttachment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;

class RequestOperatorController extends Controller
{
    public function index()
    {
        if (!auth()->user()->hasPermission('cybersecurity_requests.operate')) {
            abort(403, 'Unauthorized action.');
        }

        $breadcrumbs = [
            ['name' => __('locale.Dashboard'), 'link' => route('admin.dashboard')],
            ['link' => route('admin.cybersecurity_requests.index'), 'name' => __('request.requests')],
            ['name' => __('request.my_assigned_requests'), 'link' => 'javascript:void(0)']
        ];

        return view('admin.content.cybersecurity_requests.operator', compact('breadcrumbs'));
    }

    public function getData(Request $request)
    {
        $user = auth()->user();

        if (!$user->hasPermission('cybersecurity_requests.operate')) {
            abort(403);
        }

        $isManager = Department::where('manager_id', $user->id)->exists();

        $query = CybersecurityRequest::with([
            'requester',
            'assignedUser',
            'requestType',
            'department'
        ])
            ->whereNotIn('status', ['rejected', 'returned'])
            ->where(function ($q) use ($user, $isManager) {

                // assigned directly to me
                $q->where('assigned_to', $user->id);

                // manager → all in his department
                if ($isManager) {
                    $q->orWhereHas('assignedUser', function ($sub) use ($user) {
                        $sub->where('department_id', $user->department_id);
                    });
                }
            });

        /* ===========================
        APPLY FILTERS HERE
    ============================ */

        // Status filter
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // Priority filter
        if ($request->filled('priority')) {
            $query->where('priority', $request->priority);
        }

        // Late filter
        if ($request->late == 1) {
            $query->whereDate('due_date', '<', now())
                ->whereNotIn('status', ['closed']);
        }

        return DataTables::of($query)
            ->addColumn('requester_name', fn($row) => $row->requester->name ?? '-')
            ->addColumn('requestType', fn($row) => $row->requestType->name ?? '-')
            ->addColumn('status_badge', function ($row) {
                $colors = [
                    'approved' => 'success',
                    'under process' => 'primary',
                    'closed' => 'secondary',
                    'planned' => 'info'
                ];
                return '<span class="badge bg-' . ($colors[$row->status] ?? 'secondary') . '">' . ucfirst($row->status) . '</span>';
            })
            ->addColumn('priority_badge', function ($row) {
                $colors = [
                    'High' => 'danger',
                    'Moderate' => 'warning',
                    'Low' => 'success'
                ];
                return '<span class="badge bg-' . ($colors[$row->priority] ?? 'secondary') . '">' . $row->priority . '</span>';
            })
            ->addColumn(
                'is_late_badge',
                fn($row) =>
                $row->isLate()
                    ? '<span class="badge bg-danger"><i class="fa fa-clock"></i> Late</span>'
                    : ''
            )
            ->addColumn('actions', function ($row) {
                $dropdown = '<div class="dropdown">
                <a class="dropdown-toggle hide-arrow text-primary" data-bs-toggle="dropdown">
                    <i class="fa fa-ellipsis-v"></i>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">';

                $dropdown .= '<li>
                <a class="dropdown-item" href="' . route('admin.cybersecurity_requests.show', $row->id) . '">
                    ' . __('locale.View') . '
                </a>
            </li>';

                if ($row->status === 'approved') {
                    $dropdown .= '<li>
                    <a class="dropdown-item confirm-request" data-id="' . $row->id . '">
                        ' . __('locale.Start Processing') . '
                    </a>
                </li>
                <li>
                    <a class="dropdown-item refuse-request" data-id="' . $row->id . '">
                        ' . __('locale.Refuse') . '
                    </a>
                </li>';
                }

                if ($row->status === 'under process') {
                    $dropdown .= '<li>
                    <a class="dropdown-item close-request" data-id="' . $row->id . '">
                        ' . __('locale.Close Request') . '
                    </a>
                </li>';
                }

                return $dropdown . '</ul></div>';
            })
            ->rawColumns(['status_badge', 'priority_badge', 'is_late_badge', 'actions'])
            ->make(true);
    }



    public function confirm(Request $request)
    {
        if (!auth()->user()->hasPermission('cybersecurity_requests.operate')) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        $validated = $request->validate([
            'notes' => 'nullable|string'
        ]);

        DB::beginTransaction();
        try {
            $cybersecurityRequest = CybersecurityRequest::findOrFail($request->request_id);

            if ($cybersecurityRequest->assigned_to !== auth()->id()) {
                return response()->json([
                    'success' => false,
                    'message' => 'You are not assigned to this request'
                ], 403);
            }

            $oldStatus = $cybersecurityRequest->status;

            $cybersecurityRequest->update([
                'status' => 'under process'
            ]);

            // Add history
            $cybersecurityRequest->addHistory(
                'Request Processing Started',
                $oldStatus,
                'under process',
                $validated['notes'] ?? 'Operator confirmed and started processing the request'
            );

            // Add communication if notes provided
            if (!empty($validated['notes'])) {
                RequestCommunication::create([
                    'request_id' => $cybersecurityRequest->id,
                    'user_id' => auth()->id(),
                    'message' => $validated['notes']
                ]);
            }

            event(new ConfirmedRequest($cybersecurityRequest));


            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Request confirmed and processing started'
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Error confirming request: ' . $e->getMessage()
            ], 500);
        }
    }

    public function refuse(Request $request)
    {
        if (!auth()->user()->hasPermission('cybersecurity_requests.operate')) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        $validated = $request->validate([
            'notes' => 'required|string'
        ]);

        DB::beginTransaction();
        try {
            $cybersecurityRequest = CybersecurityRequest::findOrFail($request->request_id);

            if ($cybersecurityRequest->assigned_to !== auth()->id()) {
                return response()->json([
                    'success' => false,
                    'message' => 'You are not assigned to this request'
                ], 403);
            }

            $oldStatus = $cybersecurityRequest->status;

            $cybersecurityRequest->update([
                'status' => 'returned',
                'assigned_to' => null
            ]);

            // Add history
            $cybersecurityRequest->addHistory(
                'Request Refused by Operator',
                $oldStatus,
                'returned',
                $validated['notes']
            );

            // Add communication
            RequestCommunication::create([
                'request_id' => $cybersecurityRequest->id,
                'user_id' => auth()->id(),
                'message' => 'Request refused: ' . $validated['notes']
            ]);

            event(new RefusedRequest($cybersecurityRequest));


            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Request refused successfully'
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Error refusing request: ' . $e->getMessage()
            ], 500);
        }
    }

    public function close(Request $request)
    {
        if (!auth()->user()->hasPermission('cybersecurity_requests.operate')) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        $validated = $request->validate([
            'final_status' => 'required|string',
            'notes' => 'required|string',
            'attachments.*' => 'nullable|file|max:10240'
        ]);

        DB::beginTransaction();
        try {
            $cybersecurityRequest = CybersecurityRequest::findOrFail($request->request_id);

            if ($cybersecurityRequest->assigned_to !== auth()->id()) {
                return response()->json([
                    'success' => false,
                    'message' => 'You are not assigned to this request'
                ], 403);
            }

            $oldStatus = $cybersecurityRequest->status;

            $cybersecurityRequest->update([
                'status' => 'closed',
                'final_status' => $validated['final_status'],
                'completed_at' => now()
            ]);

            // Add history
            $cybersecurityRequest->addHistory(
                'Request Closed',
                $oldStatus,
                'closed',
                $validated['notes']
            );

            // Add communication
            $communication = RequestCommunication::create([
                'request_id' => $cybersecurityRequest->id,
                'user_id' => auth()->id(),
                'message' => 'Request closed: ' . $validated['notes']
            ]);

            // Handle attachments
            if ($request->hasFile('attachments')) {
                foreach ($request->file('attachments') as $file) {
                    $path = $file->store('communication_attachments', 'public');

                    RequestCommunicationAttachment::create([
                        'communication_id' => $communication->id,
                        'file_name' => $file->getClientOriginalName(),
                        'file_path' => $path,
                        'file_type' => $file->getClientMimeType(),
                        'file_size' => $file->getSize()
                    ]);
                }
            }

            event(new ClosedRequest($cybersecurityRequest));


            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Request closed successfully'
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Error closing request: ' . $e->getMessage()
            ], 500);
        }
    }

    public function addCommunication(Request $request, $id)
    {
        $validated = $request->validate([
            'message' => 'required|string',
            'attachments.*' => 'nullable|file|max:10240'
        ]);

        DB::beginTransaction();
        try {
            $cybersecurityRequest = CybersecurityRequest::findOrFail($id);

            $communication = RequestCommunication::create([
                'request_id' => $cybersecurityRequest->id,
                'user_id' => auth()->id(),
                'message' => $validated['message']
            ]);

            // Handle attachments
            if ($request->hasFile('attachments')) {
                foreach ($request->file('attachments') as $file) {
                    $path = $file->store('communication_attachments', 'public');

                    RequestCommunicationAttachment::create([
                        'communication_id' => $communication->id,
                        'file_name' => $file->getClientOriginalName(),
                        'file_path' => $path,
                        'file_type' => $file->getClientMimeType(),
                        'file_size' => $file->getSize()
                    ]);
                }
            }

            // Notify relevant parties
            $notifyUsers = collect([$cybersecurityRequest->requester]);
            if ($cybersecurityRequest->assignedUser && $cybersecurityRequest->assigned_to !== auth()->id()) {
                $notifyUsers->push($cybersecurityRequest->assignedUser);
            }

            event(new AddedCommunicationRequest($cybersecurityRequest));

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Communication added successfully',
                'communication' => $communication->load('user', 'attachments')
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Error adding communication: ' . $e->getMessage()
            ], 500);
        }
    }
}
