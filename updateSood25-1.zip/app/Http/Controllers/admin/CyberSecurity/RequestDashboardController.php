<?php

namespace App\Http\Controllers\admin\CyberSecurity;

use App\Http\Controllers\Controller;
use App\Models\CybersecurityRequest;
use App\Models\Department;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RequestDashboardController extends Controller
{
    public function index()
    {
        if (!auth()->user()->hasPermission('cybersecurity_requests.dashboard')) {
            abort(403, 'Unauthorized action.');
        }

        $breadcrumbs = [
            ['name' => __('Dashboard'), 'link' => route('admin.dashboard')],
            ['link' => route('admin.cybersecurity_requests.index'), 'name' => __('request.requests')],
            ['name' => __('Requests Dashboard'), 'link' => 'javascript:void(0)'],
        ];

        // Department Ranking (New Query)
        $departmentRanking = CybersecurityRequest::join(
            'departments',
            'cybersecurity_requests.receiving_department',
            '=',
            'departments.id'
        )
            ->select('departments.name', DB::raw('count(*) as total'))
            ->groupBy('departments.name')
            ->orderBy('total', 'desc')
            ->limit(10)
            ->get();

        /*
        |--------------------------------------------------------------------------
        | Requests by Department
        |--------------------------------------------------------------------------
        */
        $requestsByDepartment = CybersecurityRequest::join(
            'departments',
            'cybersecurity_requests.receiving_department',
            '=',
            'departments.id'
        )
            ->select('departments.name', DB::raw('count(*) as total'))
            ->groupBy('departments.name')
            ->pluck('total', 'departments.name');

        /*
        |--------------------------------------------------------------------------
        | Average Processing Time by Department
        |--------------------------------------------------------------------------
        */
        $avgProcessingTime = CybersecurityRequest::join(
            'departments',
            'cybersecurity_requests.receiving_department',
            '=',
            'departments.id'
        )
            ->whereNotNull('completed_at')
            ->select(
                'departments.name',
                DB::raw('AVG(TIMESTAMPDIFF(DAY, cybersecurity_requests.created_at, cybersecurity_requests.completed_at)) as avg_days')
            )
            ->groupBy('departments.name')
            ->orderBy('avg_days', 'desc')
            ->get()
            ->map(function ($row) {
                $row->avg_days = round($row->avg_days, 1);
                return $row;
            });

        /*
        |--------------------------------------------------------------------------
        | Late Requests
        |--------------------------------------------------------------------------
        */
        $lateRequestsByDepartment = CybersecurityRequest::late()
            ->join('departments', 'cybersecurity_requests.receiving_department', '=', 'departments.id')
            ->select('departments.name', DB::raw('count(*) as total'))
            ->groupBy('departments.name')
            ->pluck('total', 'departments.name');

        $lateRequestsTotal = $lateRequestsByDepartment->sum();

        /*
        |--------------------------------------------------------------------------
        | Requests by Type
        |--------------------------------------------------------------------------
        */
        $requestsByType = CybersecurityRequest::join(
            'request_types',
            'cybersecurity_requests.request_type_id',
            '=',
            'request_types.id'
        )
            ->select('request_types.name', DB::raw('count(*) as total'))
            ->groupBy('request_types.name')
            ->pluck('total', 'request_types.name');

        /*
        |--------------------------------------------------------------------------
        | Requests by Reason
        |--------------------------------------------------------------------------
        */
        $requestsByReason = CybersecurityRequest::join(
            'request_reasons',
            'cybersecurity_requests.request_reason_id',
            '=',
            'request_reasons.id'
        )
            ->select('request_reasons.name', DB::raw('count(*) as total'))
            ->groupBy('request_reasons.name')
            ->pluck('total', 'request_reasons.name');

        /*
        |--------------------------------------------------------------------------
        | Status & Priority
        |--------------------------------------------------------------------------
        */
        $requestsByStatus = CybersecurityRequest::select('status', DB::raw('count(*) as total'))
            ->groupBy('status')
            ->pluck('total', 'status');

        $requestsByPriority = CybersecurityRequest::select('priority', DB::raw('count(*) as total'))
            ->groupBy('priority')
            ->pluck('total', 'priority');

        /*
        |--------------------------------------------------------------------------
        | Recent Requests
        |--------------------------------------------------------------------------
        */
        $recentRequests = CybersecurityRequest::with([
            'requester',
            'assignedUser',
            'requestType',
            'requestReason',
            'department',
        ])
            ->latest()
            ->limit(10)
            ->get();

        /*
        |--------------------------------------------------------------------------
        | Monthly Trends
        |--------------------------------------------------------------------------
        */
        $monthlyTrends = CybersecurityRequest::select(
            DB::raw('DATE_FORMAT(created_at, "%Y-%m") as month'),
            DB::raw('count(*) as total')
        )
            ->where('created_at', '>=', now()->subMonths(12))
            ->groupBy('month')
            ->orderBy('month')
            ->get();

        /*
        |--------------------------------------------------------------------------
        | Performance Metrics
        |--------------------------------------------------------------------------
        */
        $totalRequests     = CybersecurityRequest::count();
        $completedRequests = CybersecurityRequest::completed()->count();
        $pendingRequests   = CybersecurityRequest::pending()->count();
        $rejectedRequests  = CybersecurityRequest::where('status', 'rejected')->count();

        $completionRate = $totalRequests > 0
            ? round(($completedRequests / $totalRequests) * 100, 1)
            : 0;

        $avgCompletionTime = CybersecurityRequest::whereNotNull('completed_at')
            ->selectRaw('AVG(TIMESTAMPDIFF(DAY, created_at, completed_at)) as avg_days')
            ->value('avg_days');

        $avgCompletionTime = $avgCompletionTime ? round($avgCompletionTime, 1) : 0;

        return view('admin.content.cybersecurity_requests.dashboard', compact(
            'breadcrumbs',
            'departmentRanking', // Add this
            'requestsByDepartment',
            'avgProcessingTime',
            'lateRequestsTotal',
            'lateRequestsByDepartment',
            'requestsByType',
            'requestsByReason',
            'requestsByStatus',
            'requestsByPriority',
            'recentRequests',
            'monthlyTrends',
            'totalRequests',
            'completedRequests',
            'pendingRequests',
            'rejectedRequests',
            'completionRate',
            'avgCompletionTime'
        ));
    }

    /*
    |--------------------------------------------------------------------------
    | Chart Data API
    |--------------------------------------------------------------------------
    */
    public function getChartData(Request $request)
    {
        $type = $request->get('type');

        $data = match ($type) {

            'department' => CybersecurityRequest::join(
                'departments',
                'cybersecurity_requests.receiving_department',
                '=',
                'departments.id'
            )
                ->select('departments.name as label', DB::raw('count(*) as value'))
                ->groupBy('departments.name')
                ->get(),

            'type' => CybersecurityRequest::join(
                'request_types',
                'cybersecurity_requests.request_type_id',
                '=',
                'request_types.id'
            )
                ->select('request_types.name as label', DB::raw('count(*) as value'))
                ->groupBy('request_types.name')
                ->get(),

            'reason' => CybersecurityRequest::join(
                'request_reasons',
                'cybersecurity_requests.request_reason_id',
                '=',
                'request_reasons.id'
            )
                ->select('request_reasons.name as label', DB::raw('count(*) as value'))
                ->groupBy('request_reasons.name')
                ->get(),

            'status' => CybersecurityRequest::select('status as label', DB::raw('count(*) as value'))
                ->groupBy('status')
                ->get(),

            'priority' => CybersecurityRequest::select('priority as label', DB::raw('count(*) as value'))
                ->groupBy('priority')
                ->get(),

            'monthly' => CybersecurityRequest::select(
                DB::raw('DATE_FORMAT(created_at, "%Y-%m") as label'),
                DB::raw('count(*) as value')
            )
                ->where('created_at', '>=', now()->subMonths(12))
                ->groupBy('label')
                ->orderBy('label')
                ->get(),

            default => collect(),
        };

        return response()->json(['data' => $data]);
    }
}
