<?php

namespace App\Http\Controllers\admin\CyberSecurity;

use App\Events\CreatedRequest;
use App\Events\DeletedRequest;
use App\Events\UpdatedRequest;
use App\Http\Controllers\Controller;
use App\Models\Action;
use App\Models\CybersecurityRequest;
use App\Models\Department;
use App\Models\RequestAttachment;
use App\Models\RequestReason;
use App\Models\RequestType;
use App\Models\RiskFunction;
use App\Models\RiskGrouping;
use App\Models\ThreatGrouping;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\Storage;


class CybersecurityRequestController extends Controller
{
    public function index()
    {
        if (!auth()->user()->hasPermission('cybersecurity_requests.view')) {
            abort(403, 'Unauthorized action.');
        }

        $breadcrumbs = [
            ['name' => __('locale.Dashboard'), 'link' => route('admin.dashboard')],
            ['name' => __('request.requests'), 'link' => 'javascript:void(0)']
        ];

        $departments = Department::select('id', 'name')->get();
        $requestTypes = RequestType::select('id', 'name')->get();
        $requestReasons = RequestReason::select('id', 'name')->get();

        return view('admin.content.cybersecurity_requests.index', compact(
            'breadcrumbs',
            'departments',
            'requestTypes',
            'requestReasons'
        ));
    }

    public function configure()
    {
        if (!auth()->user()->hasPermission('cybersecurity_requests.configuration')) {
            abort(403, 'Unauthorized action.');
        }

        $breadcrumbs = [
            ['link' => route('admin.dashboard'), 'name' => __('locale.Dashboard')],
            ['link' => route('admin.cybersecurity_requests.index'), 'name' => __('request.requests')],
            ['name' => __('locale.Configure')]
        ];
        $addValueTables = [
            'request_types' => 'requestTypes',
            'request_reasons' => 'requestReasons',
        ];
        $risk_groupings = RiskGrouping::all();
        $risk_functions = RiskFunction::all();
        $threat_groupings = ThreatGrouping::all();

        return view('admin.content.configure.Add_Values', compact('breadcrumbs', 'addValueTables', 'risk_groupings', 'risk_functions', 'threat_groupings'));
    }

    public function getData(Request $request)
    {
        $query = CybersecurityRequest::with(['requester', 'assignedUser', 'requestType', 'department'])
            ->join('request_types', 'cybersecurity_requests.request_type_id', '=', 'request_types.id')
            ->select(
                'cybersecurity_requests.*',
                'request_types.name as request_type_name'
            );

        // Filter by user role
        if (!auth()->user()->hasPermission('cybersecurity_requests.view_all')) {
            $query->where('requester_id', auth()->id());
        }

        // Apply filters
        if ($request->has('status') && $request->status != '') {
            $query->where('status', $request->status);
        }

        if ($request->has('priority') && $request->priority != '') {
            $query->where('priority', $request->priority);
        }

        if ($request->has('department') && $request->department != '') {
            $query->where('receiving_department', $request->department);
        }

        if ($request->has('late') && $request->late == '1') {
            $query->where('due_date', '<', now())
                ->whereNotIn('status', ['closed', 'rejected']);
        }

        return DataTables::of($query)
            ->addColumn('requester_name', function ($row) {
                return $row->requester->name ?? '-';
            })
            ->addColumn('assigned_to_name', function ($row) {
                return $row->assignedUser->name ?? '-';
            })
            ->addColumn('request_type_name', function ($row) {
                return $row->requestType->name ?? $row->request_type_name ?? 'N/A';
            })
            ->addColumn('receiving_department', function ($row) {
                return $row->department->name ?? '-';
            })
            ->addColumn('status_badge', function ($row) {
                $statusColors = [
                    'created' => 'info',
                    'under management approval' => 'warning',
                    'approved' => 'success',
                    'under process' => 'primary',
                    'closed' => 'secondary',
                    'rejected' => 'danger',
                    'planned' => 'info',
                    'returned' => 'warning'
                ];
                $color = $statusColors[$row->status] ?? 'secondary';
                return '<span class="badge bg-' . $color . '">' . ucfirst($row->status) . '</span>';
            })
            ->addColumn('priority_badge', function ($row) {
                $colors = [
                    'High' => 'danger',
                    'Moderate' => 'warning',
                    'Low' => 'success'
                ];
                $color = $colors[$row->priority] ?? 'secondary';
                return '<span class="badge bg-' . $color . '">' . $row->priority . '</span>';
            })
            ->addColumn('actions', function ($row) {
                $actions = '<div class="dropdown">
                    <button type="button" class="btn btn-sm dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                        <i class="fa fa-ellipsis-v"></i>
                    </button>
                    <div class="dropdown-menu">';

                if (auth()->user()->hasPermission('cybersecurity_requests.view')) {

                    $actions .= '<a class="dropdown-item view-request" href="' . route('admin.cybersecurity_requests.show', $row->id) . '">
                        <i class="fa fa-eye me-1"></i> ' . __('locale.View') . '
                    </a>';
                }

                if (auth()->user()->hasPermission('cybersecurity_requests.edit') && $row->status !== 'closed') {
                    $actions .= '<a class="dropdown-item edit-request" href="#" data-id="' . $row->id . '">
                        <i class="fa fa-edit me-1"></i> ' . __('locale.Edit') . '
                    </a>';
                }

                if (auth()->user()->hasPermission('cybersecurity_requests.delete')) {
                    $actions .= '<a class="dropdown-item delete-request" href="#" data-id="' . $row->id . '">
                        <i class="fa fa-trash me-1"></i> ' . __('locale.Delete') . '
                    </a>';
                }

                $actions .= '</div></div>';

                return $actions;
            })
            ->rawColumns(['status_badge', 'priority_badge', 'actions'])
            ->make(true);
    }

    public function store(Request $request)
    {
        if (!auth()->user()->hasPermission('cybersecurity_requests.create')) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized action.'
            ], 403);
        }

        $validated = $request->validate([
            'receiving_department' => 'required|exists:departments,id',
            'request_type' => 'required|exists:request_types,id',
            'request_reason' => 'required|exists:request_reasons,id',
            'priority' => 'required|in:High,Moderate,Low',
            'due_date' => 'required|date',
            'description' => 'required|string',
            'attachments.*' => 'nullable|file|max:10240',
        ]);

        DB::beginTransaction();

        try {
            $cybersecurityRequest = CybersecurityRequest::create([
                'requester_id'         => auth()->id(),
                'requester_department' => auth()->user()->department_id ?? 1,
                'receiving_department' => $validated['receiving_department'],
                'request_type_id'      => $validated['request_type'],
                'request_reason_id'    => $validated['request_reason'],
                'priority'             => $validated['priority'],
                'due_date'             => $validated['due_date'],
                'description'          => $validated['description'],
                'status'               => 'created',
            ]);

            // Attachments
            if ($request->hasFile('attachments')) {
                foreach ($request->file('attachments') as $file) {
                    $path = $file->store('request_attachments', 'public');

                    RequestAttachment::create([
                        'request_id' => $cybersecurityRequest->id,
                        'file_name'  => $file->getClientOriginalName(),
                        'file_path'  => $path,
                        'file_type'  => $file->getClientMimeType(),
                        'file_size'  => $file->getSize(),
                    ]);
                }
            }

            // Add history
            $cybersecurityRequest->addHistory('Request Created', null, 'created');

            DB::commit();
            event(new CreatedRequest($cybersecurityRequest));


            return response()->json([
                'success' => true,
                'message' => 'Request created successfully'
            ]);
        } catch (\Throwable $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function show($id)
    {
        $request = CybersecurityRequest::with([
            'requester',
            'assignedUser',
            'approver',
            'attachments',
            'communications.user',
            'communications.attachments',
            'history.user',
            'department',
            'requesterDepartment',
            'requestType',
            'requestReason',
        ])->findOrFail($id);

        // Check permission
        if (
            !auth()->user()->hasPermission('cybersecurity_requests.view_all') &&
            $request->requester_id !== auth()->id() &&
            $request->assigned_to !== auth()->id()
        ) {
            abort(403, 'Unauthorized action.');
        }

        $breadcrumbs = [
            ['name' => __('locale.Dashboard'), 'link' => route('admin.dashboard')],
            ['name' => __('request.cybersecurity_requests'), 'link' => route('admin.cybersecurity_requests.index')],
            ['name' => __('request.request_details'), 'link' => 'javascript:void(0)']
        ];

        return view('admin.content.cybersecurity_requests.show', compact('request', 'breadcrumbs'));
    }

    public function edit(Request $request)
    {
        $cybersecurityRequest = CybersecurityRequest::with('attachments')->findOrFail($request->id);

        // Permission check
        if (
            !auth()->user()->hasPermission('cybersecurity_requests.edit') ||
            ($cybersecurityRequest->requester_id !== auth()->id() &&
                !auth()->user()->hasPermission('cybersecurity_requests.edit_all'))
        ) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized action.'
            ], 403);
        }

        if ($cybersecurityRequest->status === 'closed') {
            return response()->json([
                'success' => false,
                'message' => 'Cannot edit closed request'
            ], 400);
        }

        // Transform attachments to include full URLs
        $attachments = $cybersecurityRequest->attachments->map(function ($attachment) {
            return [
                'id' => $attachment->id,
                'file_name' => $attachment->file_name,
                'file_url' => Storage::url($attachment->file_path),
                'file_size' => $attachment->file_size,
            ];
        });

        return response()->json([
            'success' => true,
            'data' => [
                'request'        => array_merge($cybersecurityRequest->toArray(), ['attachments' => $attachments]),
                'departments'    => Department::select('id', 'name')->get(),
                'requestTypes'   => RequestType::select('id', 'name')->get(),
                'requestReasons' => RequestReason::select('id', 'name')->get(),
                'priorities'     => ['High', 'Moderate', 'Low'],
            ]
        ]);
    }


    public function update(Request $request, $id)
    {
        $cybersecurityRequest = CybersecurityRequest::findOrFail($id);

        // Permission check
        if (
            !auth()->user()->hasPermission('cybersecurity_requests.edit') ||
            (
                $cybersecurityRequest->requester_id !== auth()->id() &&
                !auth()->user()->hasPermission('cybersecurity_requests.edit_all')
            )
        ) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized action.'
            ], 403);
        }

        if ($cybersecurityRequest->status === 'closed') {
            return response()->json([
                'success' => false,
                'message' => 'Cannot update a closed request'
            ], 400);
        }

        $validated = $request->validate([
            'receiving_department' => 'required|exists:departments,id',
            'request_type_id'      => 'required|exists:request_types,id',
            'request_reason_id'    => 'required|exists:request_reasons,id',
            'priority'             => 'required|in:High,Moderate,Low',
            'due_date'             => 'required|date',
            'description'          => 'required|string',
            'new_attachments.*'    => 'nullable|file|max:10240', // Changed from attachments to new_attachments
        ]);

        DB::beginTransaction();

        try {
            $oldStatus = $cybersecurityRequest->status;

            $cybersecurityRequest->update([
                'receiving_department' => $validated['receiving_department'],
                'request_type_id'      => $validated['request_type_id'],
                'request_reason_id'    => $validated['request_reason_id'],
                'priority'             => $validated['priority'],
                'due_date'             => $validated['due_date'],
                'description'          => $validated['description'],
            ]);

            // Handle new attachments - use 'new_attachments' instead of 'attachments'
            if ($request->hasFile('new_attachments')) {
                foreach ($request->file('new_attachments') as $file) {
                    $path = $file->store('request_attachments', 'public');

                    RequestAttachment::create([
                        'request_id' => $cybersecurityRequest->id,
                        'file_name'  => $file->getClientOriginalName(),
                        'file_path'  => $path,
                        'file_type'  => $file->getClientMimeType(),
                        'file_size'  => $file->getSize(),
                    ]);
                }
            }

            // Add history log
            $cybersecurityRequest->addHistory('Request Updated', $oldStatus, $cybersecurityRequest->status);
            event(new UpdatedRequest($cybersecurityRequest));

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Request updated successfully!'
            ]);
        } catch (\Throwable $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Error updating request: ' . $e->getMessage()
            ], 500);
        }
    }

    public function destroy($id)
    {
        $cybersecurityRequest = CybersecurityRequest::findOrFail($id);

        if (!auth()->user()->hasPermission('cybersecurity_requests.delete')) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized action.'
            ], 403);
        }

        try {
            // Delete attachments first
            foreach ($cybersecurityRequest->attachments as $attachment) {
                if (file_exists(storage_path('app/public/' . $attachment->file_path))) {
                    unlink(storage_path('app/public/' . $attachment->file_path));
                }
                $attachment->delete();
            }

            // Delete the request
            $cybersecurityRequest->delete();
            event(new DeletedRequest($cybersecurityRequest));

            return response()->json([
                'success' => true,
                'message' => 'Request deleted successfully'
            ]);
        } catch (\Throwable $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error deleting request: ' . $e->getMessage()
            ], 500);
        }
    }

    public function attachmentDelete($id)
    {
        $attachment = RequestAttachment::findOrFail($id);
        $request = $attachment->request;

        // Check permission
        if (
            !auth()->user()->hasPermission('cybersecurity_requests.edit') ||
            (
                $request->requester_id !== auth()->id() &&
                !auth()->user()->hasPermission('cybersecurity_requests.edit_all')
            )
        ) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized action.'
            ], 403);
        }

        try {
            // Delete file from storage
            if (file_exists(storage_path('app/public/' . $attachment->file_path))) {
                unlink(storage_path('app/public/' . $attachment->file_path));
            }

            $attachment->delete();

            return response()->json([
                'success' => true,
                'message' => 'Attachment deleted successfully'
            ]);
        } catch (\Throwable $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error deleting attachment: ' . $e->getMessage()
            ], 500);
        }
    }


    public function notificationsSetting()
    {
        // defining the breadcrumbs that will be shown in page
        $breadcrumbs = [
            ['link' => route('admin.dashboard'), 'name' => __('locale.Dashboard')],
            ['link' => route('admin.cybersecurity_requests.index'), 'name' => __('request.Request')],
            ['name' => __('locale.NotificationsSettings')]
        ];

        $users = User::select('id', 'name')->get();  // getting all users to list them in select input of users
        $moduleActionsIds = [162, 163, 164, 165, 166, 167, 168, 169, 170, 171];   // defining ids of actions modules
        $moduleActionsIdsAutoNotify = [];  // defining ids of actions modules
        // defining variables associated with each action "for the user to choose variables he wants to add to the message of notification" "each action id will be the array key of action's variables list"
        $actionsVariables = [
            162 => ['request_number', 'requester_name', 'requester_department', 'receiving_department', 'type', 'reason', 'priority', 'due_date', 'final_status', 'assigne_name', 'approver_name', 'approved_at', 'approval_notes', 'completed_at', 'communication', 'communication_by', 'description', 'status'],
            163 => ['request_number', 'requester_name', 'requester_department', 'receiving_department', 'type', 'reason', 'priority', 'due_date', 'final_status', 'assigne_name', 'approver_name', 'approved_at', 'approval_notes', 'completed_at', 'communication', 'communication_by', 'description', 'status'],
            164 => ['request_number', 'requester_name', 'requester_department', 'receiving_department', 'type', 'reason', 'priority', 'due_date', 'final_status', 'assigne_name', 'approver_name', 'approved_at', 'approval_notes', 'completed_at', 'communication', 'communication_by', 'description', 'status'],
            165 => ['request_number', 'requester_name', 'requester_department', 'receiving_department', 'type', 'reason', 'priority', 'due_date', 'final_status', 'assigne_name', 'approver_name', 'approved_at', 'approval_notes', 'completed_at', 'communication', 'communication_by', 'description', 'status'],
            166 => ['request_number', 'requester_name', 'requester_department', 'receiving_department', 'type', 'reason', 'priority', 'due_date', 'final_status', 'assigne_name', 'approver_name', 'approved_at', 'approval_notes', 'completed_at', 'communication', 'communication_by', 'description', 'status'],
            167 => ['request_number', 'requester_name', 'requester_department', 'receiving_department', 'type', 'reason', 'priority', 'due_date', 'final_status', 'assigne_name', 'approver_name', 'approved_at', 'approval_notes', 'completed_at', 'communication', 'communication_by', 'description', 'status'],
            168 => ['request_number', 'requester_name', 'requester_department', 'receiving_department', 'type', 'reason', 'priority', 'due_date', 'final_status', 'assigne_name', 'approver_name', 'approved_at', 'approval_notes', 'completed_at', 'communication', 'communication_by', 'description', 'status'],
            169 => ['request_number', 'requester_name', 'requester_department', 'receiving_department', 'type', 'reason', 'priority', 'due_date', 'final_status', 'assigne_name', 'approver_name', 'approved_at', 'approval_notes', 'completed_at', 'communication', 'communication_by', 'description', 'status'],
            170 => ['request_number', 'requester_name', 'requester_department', 'receiving_department', 'type', 'reason', 'priority', 'due_date', 'final_status', 'assigne_name', 'approver_name', 'approved_at', 'approval_notes', 'completed_at', 'communication', 'communication_by', 'description', 'status'],
            171 => ['request_number', 'requester_name', 'requester_department', 'receiving_department', 'type', 'reason', 'priority', 'due_date', 'final_status', 'assigne_name', 'approver_name', 'approved_at', 'approval_notes', 'completed_at', 'communication', 'communication_by', 'description', 'status'],
        ];
        // defining roles associated with each action "for the user to choose roles he wants to sent the notification to" "each action id will be the array key of action's roles list"
        $actionsRoles = [
            162 => ['requester' => __('request.requester'), 'receiving_department_manager' => __('request.department_manager'), 'assigned' => __('request.assigned'), 'approved_by' => __('request.approver'), 'communication_users' => __('request.communication_users')],
            163 => ['requester' => __('request.requester'), 'receiving_department_manager' => __('request.department_manager'), 'assigned' => __('request.assigned'), 'approved_by' => __('request.approver'), 'communication_users' => __('request.communication_users')],
            164 => ['requester' => __('request.requester'), 'receiving_department_manager' => __('request.department_manager'), 'assigned' => __('request.assigned'), 'approved_by' => __('request.approver'), 'communication_users' => __('request.communication_users')],
            165 => ['requester' => __('request.requester'), 'receiving_department_manager' => __('request.department_manager'), 'assigned' => __('request.assigned'), 'approved_by' => __('request.approver'), 'communication_users' => __('request.communication_users')],
            166 => ['requester' => __('request.requester'), 'receiving_department_manager' => __('request.department_manager'), 'assigned' => __('request.assigned'), 'approved_by' => __('request.approver'), 'communication_users' => __('request.communication_users')],
            167 => ['requester' => __('request.requester'), 'receiving_department_manager' => __('request.department_manager'), 'assigned' => __('request.assigned'), 'approved_by' => __('request.approver'), 'communication_users' => __('request.communication_users')],
            168 => ['requester' => __('request.requester'), 'receiving_department_manager' => __('request.department_manager'), 'assigned' => __('request.assigned'), 'approved_by' => __('request.approver'), 'communication_users' => __('request.communication_users')],
            169 => ['requester' => __('request.requester'), 'receiving_department_manager' => __('request.department_manager'), 'assigned' => __('request.assigned'), 'approved_by' => __('request.approver'), 'communication_users' => __('request.communication_users')],
            170 => ['requester' => __('request.requester'), 'receiving_department_manager' => __('request.department_manager'), 'assigned' => __('request.assigned'), 'approved_by' => __('request.approver'), 'communication_users' => __('request.communication_users')],
            171 => ['requester' => __('request.requester'), 'receiving_department_manager' => __('request.department_manager'), 'assigned' => __('request.assigned'), 'approved_by' => __('request.approver'), 'communication_users' => __('request.communication_users')],
        ];
        // getting actions with their system notifications settings, sms settings and mail settings to list them in tables
        $actionsWithSettings = Action::whereIn('actions.id', $moduleActionsIds)
            ->leftJoin('system_notifications_settings', 'actions.id', '=', 'system_notifications_settings.action_id')
            ->leftJoin('mail_settings', 'actions.id', '=', 'mail_settings.action_id')
            ->leftJoin('sms_settings', 'actions.id', '=', 'sms_settings.action_id')
            ->leftJoin('auto_notifies', 'actions.id', '=', 'auto_notifies.action_id')
            ->get([
                'actions.id as action_id',
                'actions.name as action_name',
                'system_notifications_settings.id as system_notification_setting_id',
                'system_notifications_settings.status as system_notification_setting_status',
                'mail_settings.id as mail_setting_id',
                'mail_settings.status as mail_setting_status',
                'sms_settings.id as sms_setting_id',
                'sms_settings.status as sms_setting_status',
                'auto_notifies.id as auto_notifies_id',
                'auto_notifies.status as auto_notifies_status',
            ]);
        $actionsWithSettingsAuto = Action::whereIn('actions.id', $moduleActionsIdsAutoNotify)
            ->leftJoin('auto_notifies', 'actions.id', '=', 'auto_notifies.action_id')
            ->get([
                'actions.id as action_id',
                'actions.name as action_name',
                'auto_notifies.id as auto_notifies_id',
                'auto_notifies.status as auto_notifies_status',
            ]);
        return view('admin.notifications-settings.index', compact('breadcrumbs', 'users', 'actionsWithSettings', 'actionsVariables', 'actionsRoles', 'moduleActionsIdsAutoNotify', 'actionsWithSettingsAuto'));
    }
}
