<?php

namespace App\Http\Controllers\admin\CyberSecurity;

use App\Events\ApprovedRequest;
use App\Events\RejectedRequest;
use App\Events\ReturnedRequest;
use App\Http\Controllers\Controller;
use App\Models\CybersecurityRequest;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;

class RequestApprovalController extends Controller
{
    public function index()
    {
        if (!auth()->user()->hasPermission('cybersecurity_requests.approve')) {
            abort(403, 'Unauthorized action.');
        }

        $breadcrumbs = [
            ['name' => __('Dashboard'), 'link' => route('admin.dashboard')],
            ['link' => route('admin.cybersecurity_requests.index'), 'name' => __('request.requests')],
            ['name' => __('request.Request Approvals'), 'link' => 'javascript:void(0)']
        ];

        return view('admin.content.cybersecurity_requests.approvals', compact('breadcrumbs'));
    }

    public function getData(Request $request)
    {
        if (!auth()->user()->hasPermission('cybersecurity_requests.approve')) {
            abort(403, 'Unauthorized action.');
        }

        $user = auth()->user();

        $query = CybersecurityRequest::with(['requester', 'department'])
            ->whereIn('status', ['created', 'under management approval'])
            ->where('receiving_department', $user->department_id)
            ->whereHas('department', function ($q) use ($user) {
                $q->where('manager_id', $user->id);
            })
            ->join('request_types', 'cybersecurity_requests.request_type_id', '=', 'request_types.id')
            ->select(
                'cybersecurity_requests.*',
                'request_types.name as request_type_name'
            );

        return DataTables::of($query)
            ->addColumn('requester_name', function ($row) {
                return $row->requester->name ?? '-';
            })
            ->addColumn('department_name', function ($row) {
                return $row->department->name ?? '-';
            })
            ->addColumn('status_badge', function ($row) {
                $statusColors = [
                    'created' => 'info',
                    'under management approval' => 'warning'
                ];
                $color = $statusColors[$row->status] ?? 'secondary';
                return '<span class="badge bg-' . $color . '">' . ucfirst($row->status) . '</span>';
            })
            ->addColumn('request_type_name', function ($row) {
                return $row->requestType->name ?? $row->request_type_name ?? 'N/A';
            })
            ->addColumn('priority_badge', function ($row) {
                $colors = [
                    'High' => 'danger',
                    'Moderate' => 'warning',
                    'Low' => 'success'
                ];
                $color = $colors[$row->priority] ?? 'secondary';
                return '<span class="badge bg-' . $color . '">' . $row->priority . '</span>';
            })
            ->addColumn('actions', function ($row) {
                // Start the dropdown structure
                $dropdown = '
            <div class="dropdown">
                <a class="pe-1 dropdown-toggle hide-arrow text-primary" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical font-small-4">
                        <circle cx="12" cy="12" r="1"></circle>
                        <circle cx="12" cy="5" r="1"></circle>
                        <circle cx="12" cy="19" r="1"></circle>
                    </svg>
                </a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuButton">';

                // View action
                $dropdown .= '<li><a class="dropdown-item" href="' . route('admin.cybersecurity_requests.show', $row->id) . '">' . __('locale.View') . '</a></li>';

                // Approve action
                $dropdown .= '<li><a class="dropdown-item approve-request" href="#" data-id="' . $row->id . '" data-department-id="' . $row->receiving_department . '">' . __('locale.Approve') . '</a></li>';
                // Reject action
                $dropdown .= '<li><a class="dropdown-item reject-request" href="#" data-id="' . $row->id . '">' . __('locale.Reject') . '</a></li>';

                // Return action
                $dropdown .= '<li><a class="dropdown-item return-request" href="#" data-id="' . $row->id . '">' . __('locale.Return') . '</a></li>';

                $dropdown .= '
                </ul>
            </div>';

                return $dropdown;
            })
            ->rawColumns(['status_badge', 'priority_badge', 'actions'])
            ->make(true);
    }

    public function approve(Request $request)
    {
        if (!auth()->user()->hasPermission('cybersecurity_requests.approve')) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        $validated = $request->validate([
            'notes' => 'nullable|string',
            'assigned_to' => 'required|exists:users,id'
        ]);

        DB::beginTransaction();
        try {
            $cybersecurityRequest = CybersecurityRequest::findOrFail($request->request_id);

            $oldStatus = $cybersecurityRequest->status;

            $cybersecurityRequest->update([
                'status' => 'approved',
                'approved_by' => auth()->id(),
                'approved_at' => now(),
                'approval_notes' => $validated['notes'] ?? null,
                'assigned_to' => $validated['assigned_to']
            ]);

            // Add history
            $cybersecurityRequest->addHistory(
                'Request Approved',
                $oldStatus,
                'approved',
                $validated['notes'] ?? null
            );

            event(new ApprovedRequest($cybersecurityRequest));


            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Request approved successfully'
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Error approving request: ' . $e->getMessage()
            ], 500);
        }
    }

    public function reject(Request $request)
    {
        if (!auth()->user()->hasPermission('cybersecurity_requests.approve')) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        $validated = $request->validate([
            'notes' => 'required|string'
        ]);

        DB::beginTransaction();
        try {
            $cybersecurityRequest = CybersecurityRequest::findOrFail($request->request_id);

            $oldStatus = $cybersecurityRequest->status;

            $cybersecurityRequest->update([
                'status' => 'rejected',
                'approved_by' => auth()->id(),
                'approved_at' => now(),
                'approval_notes' => $validated['notes'],
                'final_status' => 'Rejected by management'
            ]);

            // Add history
            $cybersecurityRequest->addHistory(
                'Request Rejected',
                $oldStatus,
                'rejected',
                $validated['notes']
            );

            event(new RejectedRequest($cybersecurityRequest));


            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Request rejected successfully'
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Error rejecting request: ' . $e->getMessage()
            ], 500);
        }
    }

    public function return(Request $request)
    {
        if (!auth()->user()->hasPermission('cybersecurity_requests.approve')) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        $validated = $request->validate([
            'notes' => 'required|string'
        ]);

        DB::beginTransaction();
        try {
            $cybersecurityRequest = CybersecurityRequest::findOrFail($request->request_id);

            $oldStatus = $cybersecurityRequest->status;

            $cybersecurityRequest->update([
                'status' => 'returned',
                'approval_notes' => $validated['notes']
            ]);

            // Add history
            $cybersecurityRequest->addHistory(
                'Request Returned',
                $oldStatus,
                'returned',
                $validated['notes']
            );

            event(new ReturnedRequest($cybersecurityRequest));


            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Request returned successfully'
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Error returning request: ' . $e->getMessage()
            ], 500);
        }
    }

    public function getOperators(Request $request)
    {

        $departmentId = $request->department;
        $operators = User::withPermission('cybersecurity_requests.operate')
            ->where('users.department_id', $departmentId)
            ->select('users.id', 'users.name', 'users.email')
            ->distinct()
            ->get();

        return response()->json(compact('operators'));
    }
}
