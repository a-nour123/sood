<?php

namespace App\Http\Controllers\admin\incident;

use App\Http\Controllers\Controller;
use App\Models\Incident;
use App\Models\IncidentClassify;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;

class StatisticIncidentController extends Controller
{
    public function statistics()
    {
        $breadcrumbs = [
            ['link' => route('admin.dashboard'), 'name' => __('locale.Dashboard')],
            ['link' => route('admin.incident.index'), 'name' => __('incident.incident')],
            ['name' => __('incident.statistics')]
        ];

        $incidents = $this->getOptimizedIncidents();
        $data = $this->getStatisticsData($incidents);

        return view('admin.content.incident.graph', array_merge([
            'breadcrumbs' => $breadcrumbs,
        ], $data));
    }

    public function filterStatistics(Request $request)
    {
        $from = $request->input('from');
        $to = $request->input('to');

        $incidents = $this->getOptimizedIncidents($from, $to);

        return response()->json($this->getStatisticsData($incidents));
    }

    /**
     * Optimized incident loading with single query
     */
    private function getOptimizedIncidents($from = null, $to = null)
    {
        $query = Incident::with([
            'occurrence', 'direction', 'attack', 'detected', 
            'tlpLevel', 'papLevel', 'playBook', 'incidentUsers', 
            'incidentTeams', 'affectedAssets', 'files', 
            'relatedIncidents', 'criteriaScores', 'playbookUsers',
            'playbookTeams'
        ]);

        if ($from && $to) {
            $query->whereDate('created_at', '>=', $from)
                ->whereDate('created_at', '<=', $to);
        } elseif ($from) {
            $query->whereDate('created_at', '>=', $from);
        } elseif ($to) {
            $query->whereDate('created_at', '<=', $to);
        }

        return $query->get();
    }

    /**
     * Calculate all scores in single query
     */
    private function calculateAllScores($incidentIds)
    {
        return Cache::remember('incident_scores_' . md5(json_encode($incidentIds)), 3600, function() use ($incidentIds) {
            return DB::table('incident_criteria_scores as ics')
                ->join('incident_scores as is', 'ics.incident_score_id', '=', 'is.id')
                ->whereIn('ics.incident_id', $incidentIds)
                ->select('ics.incident_id', DB::raw('SUM(is.point) as total_score'))
                ->groupBy('ics.incident_id')
                ->pluck('total_score', 'incident_id');
        });
    }

    /**
     * Get classifications in single query
     */
    private function getClassifications()
    {
        return Cache::remember('incident_classifications', 3600, function() {
            return IncidentClassify::orderBy('value', 'asc')->get();
        });
    }

    /**
     * Map incidents to classifications efficiently
     */
    private function mapIncidentsToClassifications($incidents)
    {
        $incidentIds = $incidents->pluck('id')->toArray();
        $scores = $this->calculateAllScores($incidentIds);
        $classifications = $this->getClassifications();

        return $incidents->map(function($incident) use ($scores, $classifications) {
            $totalScore = $scores[$incident->id] ?? 0;
            $classify = $classifications->first(function($c) use ($totalScore) {
                return $c->value >= $totalScore;
            });

            return [
                'incident' => $incident,
                'score' => $totalScore,
                'classification' => $classify
            ];
        });
    }

    private function getStatisticsData($incidents)
    {
        // Calculate all scores once
        $mappedIncidents = $this->mapIncidentsToClassifications($incidents);

        // Basic counts - single pass
        $statusCounts = $incidents->countBy('status');
        $incident_count = $incidents->count();
        $open_incident_count = $statusCounts['open'] ?? 0;
        $progress_incident_count = $statusCounts['progress'] ?? 0;
        $closed_incident_count = $statusCounts['closed'] ?? 0;

        // Chart data
        $classificationData = $this->getClassificationChartData($mappedIncidents);
        $attackData = $this->getAttackTypeChartData($incidents);
        $directionData = $this->getDirectionChartData($incidents);
        $statusOverTimeData = $this->getStatusOverTimeChartData($incidents);
        $tlpData = $this->getTLPChartData($incidents);
        $papData = $this->getPAPChartData($incidents);
        $detectionData = $this->getDetectionChartData($incidents);
        $occurrenceData = $this->getOccurrenceChartData($incidents);
        $playBookData = $this->getPlayBookChartData($incidents);

        // Enhanced reports
        $alertsReportData = $this->getAlertsReportData($incidents, $mappedIncidents);
        $performanceReportData = $this->getPerformanceReportData($incidents);
        $complianceReportData = $this->getComplianceReportData($incidents);
        $criticalIncidentsData = $this->getCriticalIncidentsData($mappedIncidents);
        $executiveSummaryData = $this->getExecutiveSummaryData($incidents, $mappedIncidents);
        $evidenceAnalysisData = $this->getEvidenceAnalysisData($incidents);

        return [
            'incident_count' => $incident_count,
            'open_incident_count' => $open_incident_count,
            'progress_incident_count' => $progress_incident_count,
            'closed_incident_count' => $closed_incident_count,
            'classificationData' => $classificationData,
            'attackData' => $attackData,
            'directionData' => $directionData,
            'statusOverTimeData' => $statusOverTimeData,
            'tlpData' => $tlpData,
            'papData' => $papData,
            'detectionData' => $detectionData,
            'occurrenceData' => $occurrenceData,
            'playBookData' => $playBookData,
            'alertsReportData' => $alertsReportData,
            'performanceReportData' => $performanceReportData,
            'complianceReportData' => $complianceReportData,
            'criticalIncidentsData' => $criticalIncidentsData,
            'executiveSummaryData' => $executiveSummaryData,
            'evidenceAnalysisData' => $evidenceAnalysisData,
        ];
    }

    // ============================================
    // OPTIMIZED CHART METHODS
    // ============================================

    private function getClassificationChartData($mappedIncidents)
    {
        $priorityData = $mappedIncidents
            ->filter(fn($item) => $item['classification'])
            ->groupBy(fn($item) => $item['classification']->id . '_' . $item['classification']->priority)
            ->map(function($group, $key) {
                $first = $group->first();
                $statusCounts = $group->pluck('incident')->countBy('status');
                
                return [
                    'open' => $statusCounts['open'] ?? 0,
                    'progress' => $statusCounts['progress'] ?? 0,
                    'closed' => $statusCounts['closed'] ?? 0,
                    'color' => $first['classification']->color,
                    'name' => $first['classification']->priority,
                    'id' => $first['classification']->id
                ];
            })
            ->sortKeys();

        return [
            'categories' => ['Open', 'In Progress', 'Closed'],
            'series' => $priorityData->map(fn($counts) => [
                'name' => $counts['name'],
                'color' => $counts['color'],
                'data' => [$counts['open'], $counts['progress'], $counts['closed']]
            ])->values()
        ];
    }

    private function getAttackTypeChartData($incidents)
    {
        return $incidents
            ->groupBy(fn($incident) => $incident->attack->name ?? 'Unknown')
            ->map(function($group, $name) {
                $statusCounts = $group->countBy('status');
                return [
                    'name' => $name,
                    'y' => $group->count(),
                    'statusBreakdown' => [
                        'open' => $statusCounts['open'] ?? 0,
                        'progress' => $statusCounts['progress'] ?? 0,
                        'closed' => $statusCounts['closed'] ?? 0
                    ]
                ];
            })
            ->values();
    }

    private function getDirectionChartData($incidents)
    {
        return $incidents
            ->groupBy(fn($incident) => $incident->direction->name ?? 'Unknown')
            ->map(fn($group, $name) => ['name' => $name, 'y' => $group->count()])
            ->values();
    }

    private function getStatusOverTimeChartData($incidents)
    {
        $grouped = $incidents->groupBy(fn($incident) => $incident->created_at->format('Y-m'));
        $months = $grouped->keys()->sort()->values();
        $statuses = ['open', 'progress', 'closed'];

        $series = collect($statuses)->map(function($status) use ($grouped, $months) {
            return [
                'name' => ucfirst($status),
                'data' => $months->map(fn($month) => 
                    $grouped->get($month, collect())->where('status', $status)->count()
                )->values()
            ];
        });

        return [
            'categories' => $months->map(fn($month) => 
                Carbon::createFromFormat('Y-m', $month)->format('M Y')
            )->values(),
            'series' => $series
        ];
    }

    private function getTLPChartData($incidents)
    {
        return $incidents
            ->groupBy(fn($incident) => $incident->tlpLevel->name ?? 'Unknown')
            ->map(fn($group, $name) => ['name' => $name, 'y' => $group->count()])
            ->values();
    }

    private function getPlayBookChartData($incidents)
    {
        return $incidents
            ->groupBy(fn($incident) => $incident->playBook->name ?? 'No PlayBook')
            ->map(function($group, $name) {
                $statusCounts = $group->countBy('status');
                return [
                    'name' => $name,
                    'y' => $group->count(),
                    'statusBreakdown' => [
                        'open' => $statusCounts['open'] ?? 0,
                        'progress' => $statusCounts['progress'] ?? 0,
                        'closed' => $statusCounts['closed'] ?? 0
                    ]
                ];
            })
            ->sortByDesc('y')
            ->values();
    }

    private function getPAPChartData($incidents)
    {
        return $incidents
            ->groupBy(fn($incident) => $incident->papLevel->name ?? 'Unknown')
            ->map(fn($group, $name) => ['name' => $name, 'y' => $group->count()])
            ->sortByDesc('y')
            ->values();
    }

    private function getDetectionChartData($incidents)
    {
        $detectionData = $incidents
            ->groupBy(fn($incident) => $incident->detected->name ?? 'Unknown')
            ->map(fn($group, $name) => ['name' => $name, 'y' => $group->count()])
            ->values();

        return [
            'data' => $detectionData,
            'categories' => $detectionData->pluck('name')->toArray()
        ];
    }

    private function getOccurrenceChartData($incidents)
    {
        return $incidents
            ->groupBy(fn($incident) => $incident->occurrence->name ?? 'Unknown')
            ->map(fn($group, $name) => ['name' => $name, 'value' => $group->count(), 'y' => $group->count()])
            ->values();
    }

    // ============================================
    // OPTIMIZED ENHANCED REPORT METHODS
    // ============================================

    private function getAlertsReportData($incidents, $mappedIncidents)
    {
        $totalAlerts = $incidents->count();
        
        // Severity distribution - optimized
        $severityDistribution = $mappedIncidents
            ->filter(fn($item) => $item['classification'])
            ->countBy(fn($item) => $item['classification']->priority);

        // Status breakdown
        $statusBreakdown = $incidents->countBy('status');

        // Actions taken
        $actionsTaken = $incidents->whereNotNull('play_book_id')->count();

        // Responsible parties - optimized to avoid N+1
        $responsibleParties = $incidents->map(fn($incident) => [
            'incident_id' => $incident->id,
            'summary' => $incident->summary ?? 'No summary',
            'teams' => $incident->incidentTeams->pluck('name')->toArray(),
            'users' => $incident->incidentUsers->pluck('name')->toArray(),
        ]);

        // Timeline data - FIXED: Now filtered by date range
        $timelineData = $incidents
            ->groupBy(fn($incident) => 
                $incident->detected_on ? 
                    Carbon::parse($incident->detected_on)->format('Y-m-d') : 
                    $incident->created_at->format('Y-m-d')
            )
            ->map(fn($group, $date) => ['date' => $date, 'count' => $group->count()])
            ->values();

        return [
            'total_alerts' => $totalAlerts,
            'severity_distribution' => $severityDistribution,
            'status_breakdown' => $statusBreakdown,
            'actions_taken' => $actionsTaken,
            'responsible_parties' => $responsibleParties,
            'timeline_data' => $timelineData,
        ];
    }

    private function getPerformanceReportData($incidents)
    {
        // Get the date range from the incidents collection
        if ($incidents->isEmpty()) {
            $currentMonth = Carbon::now();
            $previousMonth = Carbon::now()->subMonth();
        } else {
            // Determine the date range from incidents
            $minDate = $incidents->min('created_at');
            $maxDate = $incidents->max('created_at');
            
            // Use the last full month in the filtered range
            $currentMonth = Carbon::parse($maxDate)->startOfMonth();
            $previousMonth = Carbon::parse($maxDate)->subMonth()->startOfMonth();
        }

        // Filter by month - FIXED: Now uses filtered incidents
        $currentMonthIncidents = $incidents->filter(fn($i) => 
            $i->created_at->isSameMonth($currentMonth)
        );
        
        $previousMonthIncidents = $incidents->filter(fn($i) => 
            $i->created_at->isSameMonth($previousMonth)
        );

        $currentCount = $currentMonthIncidents->count();
        $previousCount = $previousMonthIncidents->count();
        $percentageChange = $previousCount > 0 ? (($currentCount - $previousCount) / $previousCount) * 100 : 0;

        // Optimized metrics - FIXED: Now uses filtered incidents
        $avgResponseTime = $this->calculateAverageResponseTime($currentMonthIncidents);
        $avgPreviousResponseTime = $this->calculateAverageResponseTime($previousMonthIncidents);
        $avgClosureTime = $this->calculateAverageClosureTime($currentMonthIncidents);
        $avgPreviousClosureTime = $this->calculateAverageClosureTime($previousMonthIncidents);
        $slaCompliance = $this->calculateSLACompliance($currentMonthIncidents);
        $mostAffectedAssets = $this->getMostAffectedAssets($currentMonthIncidents);
        $obstacles = $this->identifyObstacles($currentMonthIncidents);

        return [
            'current_month_count' => $currentCount,
            'previous_month_count' => $previousCount,
            'percentage_change' => round($percentageChange, 2),
            'avg_response_time' => $avgResponseTime,
            'avg_previous_response_time' => $avgPreviousResponseTime,
            'avg_closure_time' => $avgClosureTime,
            'avg_previous_closure_time' => $avgPreviousClosureTime,
            'sla_compliance' => $slaCompliance,
            'most_affected_assets' => $mostAffectedAssets,
            'obstacles' => $obstacles,
        ];
    }

    private function getComplianceReportData($incidents)
    {
        $totalIncidents = $incidents->count();

        // Optimized documentation check - FIXED: Now uses filtered incidents
        $fullyDocumented = $incidents->filter(fn($i) => 
            !empty($i->summary) && !empty($i->details) && $i->files->count() > 0
        )->count();

        $documentationCompliance = $totalIncidents > 0 ? ($fullyDocumented / $totalIncidents) * 100 : 0;

        $withProcedures = $incidents->whereNotNull('play_book_id')->count();
        $procedureCompliance = $totalIncidents > 0 ? ($withProcedures / $totalIncidents) * 100 : 0;

        $recurringIncidents = $this->analyzeRecurringIncidents($incidents);
        $recommendations = $this->generateRecommendations($incidents);

        return [
            'total_incidents' => $totalIncidents,
            'fully_documented' => $fullyDocumented,
            'documentation_compliance' => round($documentationCompliance, 2),
            'with_procedures' => $withProcedures,
            'procedure_compliance' => round($procedureCompliance, 2),
            'recurring_incidents' => $recurringIncidents,
            'recommendations' => $recommendations,
        ];
    }

    private function getCriticalIncidentsData($mappedIncidents)
    {
        // FIXED: This method already uses $mappedIncidents which is filtered
        return $mappedIncidents
            ->filter(function($item) {
                $classify = $item['classification'];
                return $classify && (
                    stripos($classify->priority, 'critical') !== false || 
                    stripos($classify->priority, 'high') !== false
                );
            })
            ->map(function($item) {
                $incident = $item['incident'];
                $classify = $item['classification'];
                
                $responseTime = $incident->updated_at->diffInHours($incident->created_at);
                $closureTime = $incident->status === 'closed' && $incident->updated_at 
                    ? $incident->updated_at->diffInHours($incident->created_at) 
                    : null;

                return [
                    'id' => $incident->id,
                    'summary' => $incident->summary ?? 'No summary provided',
                    'details' => $incident->details ?? 'No details provided',
                    'classification' => $classify->priority,
                    'affected_systems' => $incident->affectedAssets->pluck('name')->toArray(),
                    'source' => $incident->source ?? 'N/A',
                    'destination' => $incident->destination ?? 'N/A',
                    'immediate_actions' => $incident->playBook ? $incident->playBook->name : 'No playbook assigned',
                    'response_time_hours' => $responseTime,
                    'closure_time_hours' => $closureTime,
                    'current_status' => $incident->status,
                    'root_cause_analysis' => $this->performRootCauseAnalysis($incident),
                    'prevention_plan' => $this->generatePreventionPlan($incident),
                    'lessons_learned' => $this->extractLessonsLearned($incident),
                    'detected_on' => $incident->detected_on ? Carbon::parse($incident->detected_on)->format('Y-m-d H:i') : 'N/A',
                    'attack_type' => $incident->attack->name ?? 'Unknown',
                    'direction' => $incident->direction->name ?? 'Unknown',
                    'tlp_level' => $incident->tlpLevel->name ?? 'Unknown',
                    'assigned_teams' => $incident->incidentTeams->pluck('name')->toArray(),
                    'assigned_users' => $incident->incidentUsers->pluck('name')->toArray(),
                    'evidence_count' => $incident->files->count(),
                    'related_incidents_count' => $incident->relatedIncidents->count(),
                ];
            })
            ->values();
    }

    private function getExecutiveSummaryData($incidents, $mappedIncidents)
    {
        $totalIncidents = $incidents->count();
        
        // FIXED: Uses filtered incidents
        $criticalCount = $mappedIncidents->filter(function($item) {
            $classify = $item['classification'];
            return $classify && (
                stripos($classify->priority, 'critical') !== false || 
                stripos($classify->priority, 'high') !== false
            );
        })->count();

        $kpis = [
            'total_incidents' => $totalIncidents,
            'critical_incidents' => $criticalCount,
            'avg_resolution_time' => $this->calculateAverageClosureTime($incidents),
            'sla_compliance_rate' => $this->calculateSLACompliance($incidents),
            'documentation_rate' => $this->calculateDocumentationRate($incidents),
        ];

        $primaryThreats = $this->getPrimaryThreatDistribution($incidents);
        $contributingFactors = $this->getContributingFactors($incidents);
        $strategicIndicators = [
            'month_over_month_change' => $this->getMonthOverMonthChange($incidents),
            'most_targeted_assets' => $this->getMostTargetedAssets($incidents),
            'response_efficiency' => $this->calculateResponseEfficiency($incidents),
            'prevention_effectiveness' => $this->calculatePreventionEffectiveness($incidents),
        ];
        $responsibleEntities = $this->getResponsibleEntitiesSummary($incidents);

        return [
            'kpis' => $kpis,
            'primary_threats' => $primaryThreats,
            'contributing_factors' => $contributingFactors,
            'strategic_indicators' => $strategicIndicators,
            'responsible_entities' => $responsibleEntities,
            'executive_summary' => $this->generateExecutiveSummaryText($incidents, $criticalCount),
        ];
    }

    private function getEvidenceAnalysisData($incidents)
    {
        // FIXED: Uses filtered incidents
        $incidentIds = $incidents->pluck('id')->toArray();
        
        $playbookEvidenceCounts = DB::table('incident_play_book_actions as ipba')
            ->join('incident_evidence as ie', 'ipba.id', '=', 'ie.incident_play_book_action_id')
            ->whereIn('ipba.incident_id', $incidentIds)
            ->select('ipba.incident_id', DB::raw('COUNT(*) as evidence_count'))
            ->groupBy('ipba.incident_id')
            ->pluck('evidence_count', 'incident_id');

        $totalEvidenceCollected = $playbookEvidenceCounts->sum() + $incidents->sum(fn($i) => $i->files->count());
        $incidentsWithEvidence = $incidents->filter(fn($i) => 
            ($playbookEvidenceCounts[$i->id] ?? 0) + $i->files->count() > 0
        )->count();

        $evidenceStats = [
            'total_evidence_collected' => $totalEvidenceCollected,
            'incidents_with_evidence' => $incidentsWithEvidence,
            'incidents_without_evidence' => $incidents->count() - $incidentsWithEvidence,
        ];

        $coverageMetrics = [
            'evidence_coverage_rate' => $incidents->count() > 0 
                ? ($incidentsWithEvidence / $incidents->count()) * 100 
                : 0,
            'avg_evidence_per_incident' => $incidents->count() > 0 
                ? $totalEvidenceCollected / $incidents->count() 
                : 0,
        ];

        $observedCases = $this->getObservedCasesWithEvidence($incidents, $playbookEvidenceCounts);
        $qualityScore = $this->calculateEvidenceQualityScore($incidents, $playbookEvidenceCounts);

        return [
            'evidence_stats' => $evidenceStats,
            'coverage_metrics' => $coverageMetrics,
            'observed_cases' => $observedCases,
            'evidence_quality_score' => $qualityScore,
        ];
    }

    // ============================================
    // OPTIMIZED HELPER METHODS
    // ============================================

    private function calculateAverageResponseTime($incidents)
    {
        $withUpdates = $incidents->filter(fn($i) => $i->updated_at);
        
        if ($withUpdates->isEmpty()) return 0;

        $totalHours = $withUpdates->sum(fn($i) => $i->created_at->diffInHours($i->updated_at));
        
        return round($totalHours / $withUpdates->count(), 2);
    }

    private function calculateAverageClosureTime($incidents)
    {
        $closedIncidents = $incidents->where('status', 'closed');
        
        if ($closedIncidents->isEmpty()) return 0;

        $totalHours = $closedIncidents->sum(fn($i) => $i->created_at->diffInHours($i->updated_at));
        
        return round($totalHours / $closedIncidents->count(), 2);
    }

    private function calculateSLACompliance($incidents)
    {
        if ($incidents->isEmpty()) return 100;

        $compliantCount = $incidents->filter(function($i) {
            $responseTime = $i->updated_at ? $i->created_at->diffInHours($i->updated_at) : 999;
            return $responseTime <= 24;
        })->count();

        return round(($compliantCount / $incidents->count()) * 100, 2);
    }

    private function getMostAffectedAssets($incidents)
    {
        return $incidents
            ->flatMap(fn($i) => $i->affectedAssets)
            ->countBy(fn($asset) => $asset->name ?? 'Unknown')
            ->sortDesc()
            ->take(10)
            ->toArray();
    }

    private function identifyObstacles($incidents)
    {
        $obstacles = [];
        $total = $incidents->count();

        $openCount = $incidents->where('status', 'open')->count();
        if ($openCount > $total * 0.3) {
            $obstacles[] = "High number of unresolved incidents ({$openCount})";
        }

        $withoutPlaybook = $incidents->whereNull('play_book_id')->count();
        if ($withoutPlaybook > 0) {
            $obstacles[] = "{$withoutPlaybook} incidents without assigned playbooks";
        }

        $avgResponse = $this->calculateAverageResponseTime($incidents);
        if ($avgResponse > 24) {
            $obstacles[] = "Average response time exceeds 24 hours ({$avgResponse} hours)";
        }

        return $obstacles;
    }

    private function analyzeRecurringIncidents($incidents)
    {
        $total = $incidents->count();
        
        return $incidents
            ->countBy(fn($i) => $i->attack->name ?? 'Unknown')
            ->filter(fn($count) => $count > 2)
            ->map(fn($count, $type) => [
                'attack_type' => $type,
                'occurrences' => $count,
                'percentage' => round(($count / $total) * 100, 2)
            ])
            ->sortByDesc('occurrences')
            ->values()
            ->toArray();
    }

    private function generateRecommendations($incidents)
    {
        $recommendations = [];
        $total = $incidents->count();

        $undocumented = $incidents->filter(fn($i) => empty($i->details))->count();
        if ($undocumented > 0) {
            $recommendations[] = "Improve incident documentation - {$undocumented} incidents lack detailed information";
        }

        $withoutPlaybook = $incidents->whereNull('play_book_id')->count();
        if ($withoutPlaybook > $total * 0.2) {
            $recommendations[] = "Increase playbook adoption - assign playbooks to all incidents";
        }

        $recurring = $this->analyzeRecurringIncidents($incidents);
        if (!empty($recurring)) {
            $topRecurring = $recurring[0];
            $recommendations[] = "Focus on preventing {$topRecurring['attack_type']} attacks ({$topRecurring['occurrences']} occurrences)";
        }

        $avgResponse = $this->calculateAverageResponseTime($incidents);
        if ($avgResponse > 12) {
            $recommendations[] = "Improve response time - currently averaging {$avgResponse} hours";
        }

        return $recommendations;
    }

    private function performRootCauseAnalysis($incident)
    {
        $analysis = collect([
            $incident->attack ? "Attack Type: " . $incident->attack->name : null,
            $incident->direction ? "Direction: " . $incident->direction->name : null,
            $incident->detected ? "Detected via: " . $incident->detected->name : null,
            $incident->relatedIncidents->count() > 0 
                ? "Part of a pattern with " . $incident->relatedIncidents->count() . " related incidents" 
                : null
        ])->filter()->implode("; ");

        return $analysis ?: 'No root cause data available';
    }

    private function generatePreventionPlan($incident)
    {
        $plan = collect([
            $incident->attack ? "Implement specific controls against " . $incident->attack->name : null,
            $incident->affectedAssets->count() > 0 ? "Strengthen security for affected assets" : null,
            "Conduct security awareness training",
            "Review and update security policies"
        ])->filter()->toArray();

        return $plan;
    }

    private function extractLessonsLearned($incident)
    {
        $lessons = collect([
            $incident->status === 'closed' ? "Incident successfully resolved" : null,
            $incident->status === 'closed' && $incident->created_at->diffInHours($incident->updated_at) < 24 
                ? "Quick response time achieved" 
                : null,
            $incident->playBook ? "Playbook procedures were effective" : null,
            $incident->files->count() > 0 ? "Proper evidence collection and documentation" : null
        ])->filter()->toArray();

        return $lessons;
    }

    private function calculateDocumentationRate($incidents)
    {
        if ($incidents->isEmpty()) return 0;
        
        $documented = $incidents->filter(fn($i) => !empty($i->summary) && !empty($i->details))->count();
        
        return round(($documented / $incidents->count()) * 100, 2);
    }

    private function getPrimaryThreatDistribution($incidents)
    {
        $total = $incidents->count();
        
        return $incidents
            ->countBy(fn($i) => $i->attack->name ?? 'Unknown')
            ->sortDesc()
            ->take(5)
            ->map(fn($count, $name) => [
                'threat_type' => $name,
                'count' => $count,
                'percentage' => round(($count / $total) * 100, 2)
            ])
            ->values();
    }

    private function getContributingFactors($incidents)
    {
        return [
            'detection_methods' => $incidents
                ->countBy(fn($i) => $i->detected->name ?? 'Unknown')
                ->sortDesc()
                ->toArray(),
            'attack_directions' => $incidents
                ->countBy(fn($i) => $i->direction->name ?? 'Unknown')
                ->sortDesc()
                ->toArray()
        ];
    }

    private function getMonthOverMonthChange($incidents)
    {
        // FIXED: Use filtered incidents
        if ($incidents->isEmpty()) {
            return [
                'current' => 0,
                'previous' => 0,
                'change_percentage' => 0,
                'trend' => 'stable'
            ];
        }
        
        $maxDate = $incidents->max('created_at');
        $minDate = $incidents->min('created_at');
        
        $currentMonth = Carbon::parse($maxDate)->startOfMonth();
        $previousMonth = Carbon::parse($maxDate)->subMonth()->startOfMonth();
        
        $currentCount = $incidents->filter(fn($i) => 
            $i->created_at->isSameMonth($currentMonth)
        )->count();
        
        $previousCount = $incidents->filter(fn($i) => 
            $i->created_at->isSameMonth($previousMonth)
        )->count();
        
        $change = $previousCount > 0 ? (($currentCount - $previousCount) / $previousCount) * 100 : 0;
            
        return [
            'current' => $currentCount,
            'previous' => $previousCount,
            'change_percentage' => round($change, 2),
            'trend' => $change > 0 ? 'increasing' : ($change < 0 ? 'decreasing' : 'stable')
        ];
    }

    private function getMostTargetedAssets($incidents)
    {
        $incidentsByAsset = $incidents->flatMap(function($incident) {
            return $incident->affectedAssets->map(fn($asset) => [
                'name' => $asset->name ?? 'Unknown',
                'incident' => $incident
            ]);
        })->groupBy('name');

        return $incidentsByAsset->map(function($group, $name) {
            $incidents = collect($group)->pluck('incident');
            
            return [
                'name' => $name,
                'count' => $incidents->count(),
                'critical_incidents' => $incidents->filter(function($incident) {
                    // Quick check without recalculating score
                    return $incident->criteriaScores->isNotEmpty();
                })->count()
            ];
        })
        ->sortByDesc('count')
        ->take(10)
        ->toArray();
    }

    private function calculateResponseEfficiency($incidents)
    {
        if ($incidents->isEmpty()) return 0;
        
        $efficientResponses = $incidents->filter(function($i) {
            $responseTime = $i->updated_at ? $i->created_at->diffInHours($i->updated_at) : 999;
            return $responseTime <= 12;
        })->count();
        
        return round(($efficientResponses / $incidents->count()) * 100, 2);
    }

    private function calculatePreventionEffectiveness($incidents)
    {
        $recurringIncidents = $this->analyzeRecurringIncidents($incidents);
        
        if (empty($recurringIncidents)) {
            return 100;
        }
        
        $totalRecurring = collect($recurringIncidents)->sum('occurrences');
        $effectivenessScore = max(0, 100 - ($totalRecurring / $incidents->count() * 50));
        
        return round($effectivenessScore, 2);
    }

    private function getResponsibleEntitiesSummary($incidents)
    {
        $teamData = $incidents->flatMap(function($incident) {
            return $incident->incidentTeams->map(fn($team) => [
                'name' => $team->name ?? 'Unknown Team',
                'incident' => $incident
            ]);
        })->groupBy('name');

        $teamStats = $teamData->map(function($group, $name) {
            $incidents = collect($group)->pluck('incident');
            return [
                'name' => $name,
                'total_incidents' => $incidents->count(),
                'resolved' => $incidents->where('status', 'closed')->count(),
                'pending' => $incidents->whereIn('status', ['open', 'progress'])->count()
            ];
        })->values();

        $userData = $incidents->flatMap(function($incident) {
            return $incident->incidentUsers->map(fn($user) => [
                'name' => $user->name ?? 'Unknown User',
                'incident' => $incident
            ]);
        })->groupBy('name');

        $userStats = $userData->map(function($group, $name) {
            $incidents = collect($group)->pluck('incident');
            return [
                'name' => $name,
                'total_incidents' => $incidents->count(),
                'resolved' => $incidents->where('status', 'closed')->count()
            ];
        })->values();

        return [
            'teams' => $teamStats,
            'users' => $userStats
        ];
    }

    private function generateExecutiveSummaryText($incidents, $criticalCount)
    {
        $total = $incidents->count();
        $closed = $incidents->where('status', 'closed')->count();
        $sla = $this->calculateSLACompliance($incidents);
        
        $summary = "During the reporting period, {$total} security incidents were recorded. ";
        $summary .= "Of these, {$criticalCount} were classified as high or critical priority. ";
        $summary .= "{$closed} incidents have been successfully resolved. ";
        $summary .= "The team maintained a {$sla}% SLA compliance rate. ";
        
        $recurring = $this->analyzeRecurringIncidents($incidents);
        if (!empty($recurring)) {
            $topThreat = $recurring[0];
            $summary .= "The most prevalent threat type is {$topThreat['attack_type']} with {$topThreat['occurrences']} occurrences.";
        }
        
        return $summary;
    }

    private function getObservedCasesWithEvidence($incidents, $playbookEvidenceCounts)
    {
        $classifications = $this->getClassifications();
        $scores = $this->calculateAllScores($incidents->pluck('id')->toArray());

        return $incidents
            ->map(function($incident) use ($playbookEvidenceCounts, $classifications, $scores) {
                $evidenceCount = ($playbookEvidenceCounts[$incident->id] ?? 0) + $incident->files->count();
                
                if ($evidenceCount === 0) return null;

                $totalScore = $scores[$incident->id] ?? 0;
                $classify = $classifications->first(fn($c) => $c->value >= $totalScore);
                
                return [
                    'incident_id' => $incident->id,
                    'summary' => $incident->summary ?? 'No summary',
                    'classification' => $classify ? $classify->priority : 'Unknown',
                    'evidence_count' => $evidenceCount,
                    'status' => $incident->status,
                    'detection_date' => $incident->detected_on ? 
                        Carbon::parse($incident->detected_on)->format('Y-m-d') : 
                        $incident->created_at->format('Y-m-d'),
                ];
            })
            ->filter()
            ->sortByDesc('evidence_count')
            ->take(10)
            ->values();
    }

    private function calculateEvidenceQualityScore($incidents, $playbookEvidenceCounts)
    {
        if ($incidents->isEmpty()) return 0;
        
        $qualityScore = $incidents->sum(function($incident) use ($playbookEvidenceCounts) {
            $score = 0;
            
            if ($incident->files->count() > 0) $score += 25;
            if ($incident->playBook) $score += 25;
            if (!empty($incident->details) && strlen($incident->details) > 100) $score += 25;
            if (($playbookEvidenceCounts[$incident->id] ?? 0) > 0) $score += 25;
            
            return $score;
        });
        
        return round($qualityScore / $incidents->count(), 2);
    }
}