<?php

namespace App\Mail;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class PhishingEmail extends Mailable
{
    use Queueable, SerializesModels;

    public $emailData;
    public $employee;
    public $campaign_id;

    public function __construct($emailData,$employee,$campaign_id = null)
    {
        $this->emailData = $emailData;
        $this->employee = $employee;
        $this->campaign_id = $campaign_id;
    }

    public function build()
    {
        $body = view('emails.phishing.email')
            ->with([
                'campaign_id' => $this->campaign_id,
                'emailData' => $this->emailData,
                'employee' => $this->employee,
            ])
            ->render();


        $dynamicUrl = $this->getMailWebsiteUrl();
        $body = str_replace('$$emailId', $this->emailData['id'], $body);
        $body = str_replace('$$employeeId', $this->employee->id, $body);

        // Build the replacement URL
        $replacementUrl = config('app.url') . '/public/PWPI/' . $this->emailData->website->id . '/click?PMTI=' . $this->emailData['id'] . '&PEI=' . $this->employee->id. '&PCI=' . $this->campaign_id;

        $urlWithoutProtocol = preg_replace('#^https?://#', '', $replacementUrl);

        $body = preg_replace('#(https?://)\{PhishWebsitePage\}#i', '$1' . $urlWithoutProtocol, $body);
        // For cases without protocol, use full URL
        $body = str_replace('{PhishWebsitePage}', $replacementUrl, $body);

        // Clean up any duplicate protocols that might have been created
        $body = preg_replace('#(https?://)(https?://)+#', '$1', $body);

        $body = str_replace('$$NAME$$', $this->employee->name, $body);

        if($this->emailData['mail_attachment']){
            $attachmentHtml = view('emails.phishing.partial')
                ->with([
                    'campaign_id' => $this->campaign_id,
                    'fileName' => $this->emailData['mail_attachment'],
                    'emailId' => $this->emailData['id'],
                    'employeeId' => $this->employee->id,
                ])
                ->render();

            $body .= $attachmentHtml;
        }

        return $this->html($body);
    }

    public function getMailWebsiteUrl()
    {
        $website = $this->emailData->website;
        if($website->domain()->exists()){
            $subdomain = $website->from_address_name;
            $domain = ltrim($website->domain->name, '@');
            $dynamicUrl = "{$subdomain}.{$domain}/PWPI/{$website->id}?PMTI={$this->emailData->id}&PEI={$this->employee->id}";

        }else{
            $domain = $website->from_address_name;
            $dynamicUrl = "{$domain}/PWPI/{$website->id}?PMTI={$this->emailData->id}&PEI={$this->employee->id}";
        }

        return $dynamicUrl;
    }
}
