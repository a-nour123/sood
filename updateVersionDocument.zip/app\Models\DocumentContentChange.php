<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DocumentContentChange extends Model
{
    use HasFactory;

    protected $fillable = [
        'document_id',
        'version_number',
        'set_date',
        'acceptance_date',
        'old_content',
        'new_content',
        'changed_by',
        'status',
        'file_path',
        'file_name'
    ];

    protected $casts = [
        'set_date' => 'date',
        'acceptance_date' => 'date',
    ];

    public function document()
    {
        return $this->belongsTo(Document::class);
    }

    public function changedByUser()
    {
        return $this->belongsTo(User::class, 'changed_by');
    }

    public static function nextVersionForDocument($documentId): int
    {
        return ((int) static::where('document_id', $documentId)->max('version_number')) + 1;
    }

    public function getOldContentAttribute($value)
    {
        return str_replace('&nbsp;', ' ', strip_tags((string) $value));
    }

    public function getNewContentAttribute($value)
    {
        return str_replace('&nbsp;', ' ', strip_tags((string) $value));
    }
}