<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::table('document_content_changes', function (Blueprint $table) {
            if (!Schema::hasColumn('document_content_changes', 'version_number')) {
                $table->unsignedInteger('version_number')->default(1)->after('document_id');
            }
            if (!Schema::hasColumn('document_content_changes', 'set_date')) {
                $table->date('set_date')->nullable()->after('version_number');
            }
            if (!Schema::hasColumn('document_content_changes', 'acceptance_date')) {
                $table->date('acceptance_date')->nullable()->after('set_date');
            }
        });

        $versions = [];

        DB::table('document_content_changes')
            ->orderBy('document_id')
            ->orderBy('id')
            ->get()
            ->each(function ($row) use (&$versions) {
                $versions[$row->document_id] = ($versions[$row->document_id] ?? 0) + 1;
                $accepted = strtolower((string) $row->status) === 'accepted';

                DB::table('document_content_changes')->where('id', $row->id)->update([
                    'version_number' => $versions[$row->document_id],
                    'set_date' => $row->created_at ? substr($row->created_at, 0, 10) : null,
                    'acceptance_date' => $accepted && $row->updated_at ? substr($row->updated_at, 0, 10) : null,
                ]);
            });
    }

    public function down()
    {
        Schema::table('document_content_changes', function (Blueprint $table) {
            if (Schema::hasColumn('document_content_changes', 'acceptance_date')) {
                $table->dropColumn('acceptance_date');
            }
            if (Schema::hasColumn('document_content_changes', 'set_date')) {
                $table->dropColumn('set_date');
            }
            if (Schema::hasColumn('document_content_changes', 'version_number')) {
                $table->dropColumn('version_number');
            }
        });
    }
};
