<?php

namespace App\Http\Controllers\admin\hierarchy;

use App\Http\Controllers\Controller;
use App\Models\Department;
use App\Models\Job;
use App\Models\RaciActivity;
use App\Models\RaciAssignment;
use App\Models\RaciMatrix;
use App\Models\RaciStakeholder;
use App\Models\User;
use App\Services\RaciAnalyticsService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class RaciController extends Controller
{
    public function index()
    {
        $departments = Department::orderBy('id')->get();
        $portfolio = app(RaciAnalyticsService::class)->forPortfolio();
        $breadcrumbs = [
            ['link' => route('admin.dashboard'), 'name' => __('locale.Dashboard')],
            ['link' => route('admin.hierarchy.index'), 'name' => __('locale.Hierarchy')],
            ['name' => __('locale.RACI')],
        ];

        return view('admin.content.hierarchy.raci.index', compact('breadcrumbs', 'departments', 'portfolio'));
    }

    public function statistics()
    {
        $portfolio = app(RaciAnalyticsService::class)->forPortfolio();
        $breadcrumbs = [
            ['link' => route('admin.dashboard'), 'name' => __('locale.Dashboard')],
            ['link' => route('admin.hierarchy.index'), 'name' => __('locale.Hierarchy')],
            ['link' => route('admin.hierarchy.raci.index'), 'name' => __('locale.RACI')],
            ['name' => __('locale.Statistics')],
        ];

        return view('admin.content.hierarchy.raci.statistics', compact('breadcrumbs', 'portfolio'));
    }

    public function show($id)
    {
        $matrix = RaciMatrix::with(['department', 'activities.assignments', 'stakeholders'])->findOrFail($id);
        $departments = Department::orderBy('id')->get();
        $jobs = Job::orderBy('name')->get();
        $users = User::select('id', 'name', 'department_id', 'job_id')->orderBy('name')->get();
        $analytics = app(RaciAnalyticsService::class)->forMatrix($matrix);

        $assignmentMap = [];
        foreach ($matrix->activities as $activity) {
            foreach ($activity->assignments as $assignment) {
                $assignmentMap[$activity->id . '_' . $assignment->stakeholder_id] = $assignment->role;
            }
        }

        $breadcrumbs = [
            ['link' => route('admin.dashboard'), 'name' => __('locale.Dashboard')],
            ['link' => route('admin.hierarchy.index'), 'name' => __('locale.Hierarchy')],
            ['link' => route('admin.hierarchy.raci.index'), 'name' => __('locale.RACI')],
            ['name' => $matrix->name],
        ];

        return view('admin.content.hierarchy.raci.show', compact(
            'breadcrumbs',
            'matrix',
            'departments',
            'jobs',
            'users',
            'assignmentMap',
            'analytics'
        ));
    }

    public function ajaxAnalytics($id)
    {
        $matrix = RaciMatrix::with(['department', 'activities.assignments', 'stakeholders'])->findOrFail($id);

        return response()->json([
            'status' => true,
            'data' => app(RaciAnalyticsService::class)->forMatrix($matrix),
        ]);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => ['required', 'max:150'],
            'description' => ['nullable', 'max:1000'],
            'department_id' => ['nullable', 'exists:departments,id'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()->toArray(),
                'message' => __('hierarchy.ThereWasAProblemAddingTheRaci') . '<br>' . __('locale.Validation error'),
            ], 422);
        }

        DB::beginTransaction();
        try {
            $matrix = RaciMatrix::create([
                'name' => $request->name,
                'description' => $request->description,
                'department_id' => $request->department_id ?: null,
                'created_by' => auth()->id(),
            ]);

            DB::commit();
            write_log($matrix->id, auth()->id(), __('hierarchy.A New RACI created with name') . ' "' . $matrix->name . '". ' . __('locale.CreatedBy') . ' "' . auth()->user()->name . '"', 'Creating RACI');

            return response()->json([
                'status' => true,
                'message' => __('hierarchy.RaciWasAddedSuccessfully'),
            ]);
        } catch (\Throwable $th) {
            DB::rollBack();
            return response()->json([
                'status' => false,
                'errors' => [],
                'message' => __('locale.Error'),
            ], 502);
        }
    }

    public function ajaxGet($id)
    {
        $matrix = RaciMatrix::find($id);
        if (!$matrix) {
            return response()->json(['status' => false, 'message' => __('locale.Error 404')], 404);
        }

        $matrix->has_stakeholders = $matrix->stakeholders()->exists();

        return response()->json(['status' => true, 'data' => $matrix]);
    }

    public function update(Request $request, $id)
    {
        $matrix = RaciMatrix::find($id);
        if (!$matrix) {
            return response()->json(['status' => false, 'message' => __('locale.Error 404')], 404);
        }

        $validator = Validator::make($request->all(), [
            'name' => ['required', 'max:150'],
            'description' => ['nullable', 'max:1000'],
            'department_id' => ['nullable', 'exists:departments,id'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()->toArray(),
                'message' => __('hierarchy.ThereWasAProblemUpdatingTheRaci') . '<br>' . __('locale.Validation error'),
            ], 422);
        }

        $hasStakeholders = $matrix->stakeholders()->exists();
        $currentDepartmentId = $matrix->department_id ? (int) $matrix->department_id : null;
        $requestedDepartmentId = $request->filled('department_id') ? (int) $request->department_id : null;

        if ($hasStakeholders && $request->exists('department_id') && $requestedDepartmentId !== $currentDepartmentId) {
            return response()->json([
                'status' => false,
                'errors' => [
                    'department_id' => [__('hierarchy.RaciDepartmentLocked')],
                ],
                'message' => __('hierarchy.RaciDepartmentLocked'),
            ], 422);
        }

        $matrix->update([
            'name' => $request->name,
            'description' => $request->description,
            'department_id' => $hasStakeholders ? $matrix->department_id : ($request->department_id ?: null),
        ]);

        write_log($matrix->id, auth()->id(), __('hierarchy.A RACI that name is') . ' "' . $matrix->name . '" ' . __('locale.UpdatedBy') . ' "' . auth()->user()->name . '"', 'Updating RACI');

        return response()->json([
            'status' => true,
            'message' => __('hierarchy.RaciWasUpdatedSuccessfully'),
        ]);
    }

    public function destroy($id)
    {
        $matrix = RaciMatrix::find($id);
        if (!$matrix) {
            return response()->json(['status' => false, 'message' => __('locale.Error 404')], 404);
        }

        $name = $matrix->name;
        $matrix->delete();
        write_log($id, auth()->id(), __('hierarchy.A RACI that name is') . ' "' . $name . '" ' . __('locale.DeletedBy') . ' "' . auth()->user()->name . '"', 'Deleting RACI');

        return response()->json([
            'status' => true,
            'message' => __('hierarchy.RaciWasDeletedSuccessfully'),
        ]);
    }

    public function ajaxGetList(Request $request)
    {
        $dataTableDetails = [];
        $customFilterFields = [
            'normal' => ['name'],
            'relationships' => [],
            'other_global_filters' => ['description', 'created_at'],
        ];
        $relationshipsWithColumns = [
            'department:id,name',
        ];

        prepareDatatableRequestFields($request, $dataTableDetails, $customFilterFields);

        [$totalRecords, $totalRecordswithFilter] = getDatatableFilterTotalRecordsCount(
            RaciMatrix::class,
            $dataTableDetails,
            $customFilterFields
        );

        $mainTableColumns = getTableColumnsSelect('raci_matrices', [
            'id',
            'name',
            'description',
            'department_id',
            'created_at',
        ]);

        $matrices = getDatatableFilterRecords(
            RaciMatrix::class,
            $dataTableDetails,
            $customFilterFields,
            $relationshipsWithColumns,
            $mainTableColumns
        );

        $matrices->load(['activities.assignments', 'stakeholders']);
        $analytics = app(RaciAnalyticsService::class);

        $data_arr = [];
        foreach ($matrices as $matrix) {
            $summary = $analytics->summaryForMatrix($matrix);
            $data_arr[] = [
                'id' => $matrix->id,
                'name' => $matrix->name,
                'description' => $matrix->description,
                'department' => optional($matrix->department)->name ?: __('locale.AllOrganization'),
                'health' => $summary,
                'created_at' => optional($matrix->created_at)->format('Y-m-d H:i:s'),
                'Actions' => $matrix->id,
            ];
        }

        return response()->json(
            getDatatableAjaxResponse(intval($dataTableDetails['draw']), $totalRecords, $totalRecordswithFilter, $data_arr),
            200
        );
    }

    public function storeActivity(Request $request, $id)
    {
        $matrix = RaciMatrix::findOrFail($id);
        $validator = Validator::make($request->all(), [
            'name' => ['required', 'max:200'],
            'description' => ['nullable', 'max:1000'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()->toArray(),
                'message' => __('locale.Validation error'),
            ], 422);
        }

        $maxOrder = (int) $matrix->activities()->max('sort_order');
        $activity = $matrix->activities()->create([
            'name' => $request->name,
            'description' => $request->description,
            'sort_order' => $maxOrder + 1,
        ]);

        return response()->json([
            'status' => true,
            'message' => __('hierarchy.RaciActivityWasAddedSuccessfully'),
            'data' => $activity,
        ]);
    }

    public function updateActivity(Request $request, $activityId)
    {
        $activity = RaciActivity::findOrFail($activityId);
        $validator = Validator::make($request->all(), [
            'name' => ['required', 'max:200'],
            'description' => ['nullable', 'max:1000'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()->toArray(),
                'message' => __('locale.Validation error'),
            ], 422);
        }

        $activity->update($request->only('name', 'description'));

        return response()->json([
            'status' => true,
            'message' => __('hierarchy.RaciActivityWasUpdatedSuccessfully'),
        ]);
    }

    public function destroyActivity($activityId)
    {
        RaciActivity::findOrFail($activityId)->delete();

        return response()->json([
            'status' => true,
            'message' => __('hierarchy.RaciActivityWasDeletedSuccessfully'),
        ]);
    }

    public function storeStakeholder(Request $request, $id)
    {
        $matrix = RaciMatrix::findOrFail($id);
        $validator = Validator::make($request->all(), [
            'stakeholder_type' => ['required', 'in:job,department,user'],
            'stakeholder_id' => ['required', 'integer'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()->toArray(),
                'message' => __('locale.Validation error'),
            ], 422);
        }

        if (!$this->stakeholderExists($request->stakeholder_type, $request->stakeholder_id)) {
            return response()->json([
                'status' => false,
                'message' => __('locale.Error 404'),
            ], 404);
        }

        $exists = $matrix->stakeholders()
            ->where('stakeholder_type', $request->stakeholder_type)
            ->where('stakeholder_id', $request->stakeholder_id)
            ->exists();

        if ($exists) {
            return response()->json([
                'status' => false,
                'message' => __('hierarchy.RaciStakeholderAlreadyExists'),
            ], 422);
        }

        $maxOrder = (int) $matrix->stakeholders()->max('sort_order');
        $matrix->stakeholders()->create([
            'stakeholder_type' => $request->stakeholder_type,
            'stakeholder_id' => $request->stakeholder_id,
            'sort_order' => $maxOrder + 1,
        ]);

        return response()->json([
            'status' => true,
            'message' => __('hierarchy.RaciStakeholderWasAddedSuccessfully'),
        ]);
    }

    public function destroyStakeholder($stakeholderId)
    {
        RaciStakeholder::findOrFail($stakeholderId)->delete();

        return response()->json([
            'status' => true,
            'message' => __('hierarchy.RaciStakeholderWasDeletedSuccessfully'),
        ]);
    }

    public function importHierarchy(Request $request, $id)
    {
        $matrix = RaciMatrix::findOrFail($id);
        $added = 0;
        $maxOrder = (int) $matrix->stakeholders()->max('sort_order');

        if ($matrix->department_id) {
            $added += $this->addStakeholderIfMissing($matrix, 'department', $matrix->department_id, $maxOrder);
            $jobIds = User::where('department_id', $matrix->department_id)
                ->whereNotNull('job_id')
                ->pluck('job_id')
                ->unique();
            foreach ($jobIds as $jobId) {
                $added += $this->addStakeholderIfMissing($matrix, 'job', $jobId, $maxOrder);
            }
        } else {
            foreach (Job::pluck('id') as $jobId) {
                $added += $this->addStakeholderIfMissing($matrix, 'job', $jobId, $maxOrder);
            }
        }

        return response()->json([
            'status' => true,
            'message' => __('hierarchy.RaciHierarchyImportedSuccessfully', ['count' => $added]),
        ]);
    }

    public function saveAssignment(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'activity_id' => ['required', 'exists:raci_activities,id'],
            'stakeholder_id' => ['required', 'exists:raci_stakeholders,id'],
            'role' => ['nullable', 'in:R,A,C,I'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()->toArray(),
                'message' => __('locale.Validation error'),
            ], 422);
        }

        $activity = RaciActivity::findOrFail($request->activity_id);
        $stakeholder = RaciStakeholder::findOrFail($request->stakeholder_id);

        if ($activity->matrix_id !== $stakeholder->matrix_id) {
            return response()->json(['status' => false, 'message' => __('locale.Error')], 422);
        }

        if (!$request->role) {
            RaciAssignment::where('activity_id', $activity->id)
                ->where('stakeholder_id', $stakeholder->id)
                ->delete();

            return response()->json([
                'status' => true,
                'message' => __('hierarchy.RaciAssignmentCleared'),
                'role' => '',
            ]);
        }

        if ($request->role === 'A') {
            RaciAssignment::where('activity_id', $activity->id)
                ->where('role', 'A')
                ->where('stakeholder_id', '!=', $stakeholder->id)
                ->delete();
        }

        RaciAssignment::updateOrCreate(
            [
                'activity_id' => $activity->id,
                'stakeholder_id' => $stakeholder->id,
            ],
            ['role' => $request->role]
        );

        return response()->json([
            'status' => true,
            'message' => __('hierarchy.RaciAssignmentSaved'),
            'role' => $request->role,
        ]);
    }

    protected function stakeholderExists(string $type, int $id): bool
    {
        if ($type === 'job') {
            return Job::where('id', $id)->exists();
        }
        if ($type === 'department') {
            return Department::where('id', $id)->exists();
        }

        return User::where('id', $id)->exists();
    }

    protected function addStakeholderIfMissing(RaciMatrix $matrix, string $type, int $id, int &$maxOrder): int
    {
        $exists = $matrix->stakeholders()
            ->where('stakeholder_type', $type)
            ->where('stakeholder_id', $id)
            ->exists();

        if ($exists) {
            return 0;
        }

        $maxOrder++;
        $matrix->stakeholders()->create([
            'stakeholder_type' => $type,
            'stakeholder_id' => $id,
            'sort_order' => $maxOrder,
        ]);

        return 1;
    }
}
