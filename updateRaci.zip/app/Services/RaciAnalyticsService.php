<?php

namespace App\Services;

use App\Models\Department;
use App\Models\Job;
use App\Models\RaciMatrix;
use App\Models\User;
use Illuminate\Support\Collection;

class RaciAnalyticsService
{
    public function forMatrix(RaciMatrix $matrix): array
    {
        $matrix->loadMissing(['activities.assignments', 'stakeholders', 'department']);

        $activities = $matrix->activities;
        $stakeholders = $matrix->stakeholders;
        $labels = $this->stakeholderLabels($stakeholders);

        $activityCount = $activities->count();
        $stakeholderCount = $stakeholders->count();
        $cells = $activityCount * $stakeholderCount;
        $roleCounts = ['R' => 0, 'A' => 0, 'C' => 0, 'I' => 0];
        $filled = 0;

        $workload = [];
        foreach ($stakeholders as $stakeholder) {
            $workload[$stakeholder->id] = [
                'id' => $stakeholder->id,
                'name' => $labels[$stakeholder->id] ?? '-',
                'type' => $stakeholder->stakeholder_type,
                'type_label' => $stakeholder->type_label,
                'R' => 0,
                'A' => 0,
                'C' => 0,
                'I' => 0,
                'total' => 0,
            ];
        }

        $missingAccountable = [];
        $missingResponsible = [];
        $tooManyConsulted = [];
        $tooManyInformed = [];
        $unassignedActivities = [];
        $consultedLimit = max(3, (int) ceil($stakeholderCount * 0.4));
        $informedLimit = max(3, (int) ceil($stakeholderCount * 0.5));

        foreach ($activities as $activity) {
            $byRole = ['R' => 0, 'A' => 0, 'C' => 0, 'I' => 0];
            $assigned = 0;

            foreach ($activity->assignments as $assignment) {
                $role = strtoupper((string) $assignment->role);
                if (!isset($byRole[$role])) {
                    continue;
                }
                $byRole[$role]++;
                $roleCounts[$role]++;
                $filled++;
                $assigned++;
                if (isset($workload[$assignment->stakeholder_id])) {
                    $workload[$assignment->stakeholder_id][$role]++;
                    $workload[$assignment->stakeholder_id]['total']++;
                }
            }

            $row = ['id' => $activity->id, 'name' => $activity->name];

            if ($byRole['A'] === 0) {
                $missingAccountable[] = $row;
            }
            if ($byRole['R'] === 0) {
                $missingResponsible[] = $row;
            }
            if ($byRole['C'] > $consultedLimit) {
                $tooManyConsulted[] = $row + ['count' => $byRole['C']];
            }
            if ($byRole['I'] > $informedLimit) {
                $tooManyInformed[] = $row + ['count' => $byRole['I']];
            }
            if ($assigned === 0) {
                $unassignedActivities[] = $row;
            }
        }

        $idle = [];
        $overloaded = [];
        $accountableOwners = [];
        $overloadThreshold = max(3, (int) ceil($activityCount * 0.5));

        foreach ($workload as $row) {
            if ($activityCount > 0 && $row['total'] === 0) {
                $idle[] = ['id' => $row['id'], 'name' => $row['name']];
            }
            if ($activityCount > 0 && ($row['R'] + $row['A']) >= $overloadThreshold) {
                $overloaded[] = [
                    'id' => $row['id'],
                    'name' => $row['name'],
                    'r_count' => $row['R'],
                    'a_count' => $row['A'],
                    'total' => $row['total'],
                ];
            }
            if ($row['A'] > 0) {
                $accountableOwners[] = $row['name'];
            }
        }

        usort($workload, fn($a, $b) => $b['total'] <=> $a['total']);

        $fillRate = $cells > 0 ? round(($filled / $cells) * 100) : 0;
        $accountableRate = $activityCount > 0
            ? round((($activityCount - count($missingAccountable)) / $activityCount) * 100)
            : 0;
        $responsibleRate = $activityCount > 0
            ? round((($activityCount - count($missingResponsible)) / $activityCount) * 100)
            : 0;
        $readyRate = $activityCount > 0
            ? round((($activityCount - count($unassignedActivities)) / $activityCount) * 100)
            : 0;

        $typeMix = [
            'job' => $stakeholders->where('stakeholder_type', 'job')->count(),
            'department' => $stakeholders->where('stakeholder_type', 'department')->count(),
            'user' => $stakeholders->where('stakeholder_type', 'user')->count(),
        ];

        $health = $this->scoreHealth(
            $activityCount,
            $stakeholderCount,
            $fillRate,
            $accountableRate,
            $responsibleRate,
            count($idle),
            count($overloaded),
            count($tooManyConsulted)
        );

        $findings = $this->buildFindings(
            $activityCount,
            $stakeholderCount,
            $missingAccountable,
            $missingResponsible,
            $tooManyConsulted,
            $tooManyInformed,
            $unassignedActivities,
            $idle,
            $overloaded,
            $accountableOwners
        );

        return [
            'matrix_id' => $matrix->id,
            'name' => $matrix->name,
            'department' => optional($matrix->department)->name ?: __('locale.AllOrganization'),
            'counts' => [
                'activities' => $activityCount,
                'stakeholders' => $stakeholderCount,
                'assignments' => $filled,
                'cells' => $cells,
                'empty' => max(0, $cells - $filled),
            ],
            'role_counts' => $roleCounts,
            'coverage' => [
                'fill_rate' => $fillRate,
                'accountable_rate' => $accountableRate,
                'responsible_rate' => $responsibleRate,
                'ready_rate' => $readyRate,
            ],
            'health' => $health,
            'gaps' => [
                'missing_accountable' => $missingAccountable,
                'missing_responsible' => $missingResponsible,
                'too_many_consulted' => $tooManyConsulted,
                'too_many_informed' => $tooManyInformed,
                'unassigned_activities' => $unassignedActivities,
                'idle_stakeholders' => $idle,
                'overloaded' => $overloaded,
            ],
            'workload' => array_values($workload),
            'type_mix' => $typeMix,
            'findings' => $findings,
            'gap_count' => count($missingAccountable) + count($missingResponsible) + count($unassignedActivities),
        ];
    }

    public function forPortfolio(): array
    {
        $matrices = RaciMatrix::with(['department', 'activities.assignments', 'stakeholders'])->orderByDesc('id')->get();
        $rows = [];
        $roleCounts = ['R' => 0, 'A' => 0, 'C' => 0, 'I' => 0];
        $bands = ['healthy' => 0, 'watch' => 0, 'critical' => 0];
        $totalGaps = 0;
        $scoreSum = 0;
        $orgFindings = [];
        $typeMix = ['job' => 0, 'department' => 0, 'user' => 0];

        foreach ($matrices as $matrix) {
            $analytics = $this->forMatrix($matrix);
            $rows[] = [
                'id' => $matrix->id,
                'name' => $matrix->name,
                'department' => $analytics['department'],
                'health' => $analytics['health'],
                'coverage' => $analytics['coverage'],
                'counts' => $analytics['counts'],
                'gap_count' => $analytics['gap_count'],
                'url' => route('admin.hierarchy.raci.show', $matrix->id),
            ];

            foreach ($roleCounts as $role => $_) {
                $roleCounts[$role] += $analytics['role_counts'][$role];
            }
            foreach ($typeMix as $type => $_) {
                $typeMix[$type] += $analytics['type_mix'][$type];
            }
            $bands[$analytics['health']['band']]++;
            $totalGaps += $analytics['gap_count'];
            $scoreSum += $analytics['health']['score'];

            foreach ($analytics['findings'] as $finding) {
                if (in_array($finding['severity'], ['critical', 'warning'], true)) {
                    $orgFindings[] = [
                        'matrix' => $matrix->name,
                        'matrix_id' => $matrix->id,
                        'url' => route('admin.hierarchy.raci.show', $matrix->id),
                    ] + $finding;
                }
            }
        }

        usort($rows, fn($a, $b) => $a['health']['score'] <=> $b['health']['score']);
        usort($orgFindings, function ($a, $b) {
            $rank = ['critical' => 0, 'warning' => 1, 'info' => 2, 'success' => 3];
            return ($rank[$a['severity']] ?? 9) <=> ($rank[$b['severity']] ?? 9);
        });

        $count = $matrices->count();

        return [
            'summary' => [
                'matrices' => $count,
                'avg_health' => $count ? (int) round($scoreSum / $count) : 0,
                'critical' => $bands['critical'],
                'watch' => $bands['watch'],
                'healthy' => $bands['healthy'],
                'gaps' => $totalGaps,
                'activities' => $matrices->sum(fn($item) => $item->activities->count()),
                'stakeholders' => $matrices->sum(fn($item) => $item->stakeholders->count()),
            ],
            'role_counts' => $roleCounts,
            'type_mix' => $typeMix,
            'bands' => $bands,
            'matrices' => $rows,
            'findings' => array_slice($orgFindings, 0, 20),
        ];
    }

    public function summaryForMatrix(RaciMatrix $matrix): array
    {
        $analytics = $this->forMatrix($matrix);

        return [
            'health_score' => $analytics['health']['score'],
            'health_band' => $analytics['health']['band'],
            'health_label' => $analytics['health']['label'],
            'fill_rate' => $analytics['coverage']['fill_rate'],
            'gap_count' => $analytics['gap_count'],
            'activities' => $analytics['counts']['activities'],
            'stakeholders' => $analytics['counts']['stakeholders'],
        ];
    }

    protected function stakeholderLabels(Collection $stakeholders): array
    {
        $jobIds = $stakeholders->where('stakeholder_type', 'job')->pluck('stakeholder_id');
        $departmentIds = $stakeholders->where('stakeholder_type', 'department')->pluck('stakeholder_id');
        $userIds = $stakeholders->where('stakeholder_type', 'user')->pluck('stakeholder_id');

        $jobs = $jobIds->isEmpty() ? collect() : Job::whereIn('id', $jobIds)->pluck('name', 'id');
        $departments = $departmentIds->isEmpty() ? collect() : Department::whereIn('id', $departmentIds)->pluck('name', 'id');
        $users = $userIds->isEmpty() ? collect() : User::whereIn('id', $userIds)->pluck('name', 'id');

        $labels = [];
        foreach ($stakeholders as $stakeholder) {
            if ($stakeholder->stakeholder_type === 'job') {
                $labels[$stakeholder->id] = $jobs[$stakeholder->stakeholder_id] ?? '-';
            } elseif ($stakeholder->stakeholder_type === 'department') {
                $labels[$stakeholder->id] = $departments[$stakeholder->stakeholder_id] ?? '-';
            } else {
                $labels[$stakeholder->id] = $users[$stakeholder->stakeholder_id] ?? '-';
            }
        }

        return $labels;
    }

    protected function scoreHealth(
        int $activities,
        int $stakeholders,
        int $fillRate,
        int $accountableRate,
        int $responsibleRate,
        int $idleCount,
        int $overloadedCount,
        int $consultedBottlenecks
    ): array {
        if ($activities === 0 || $stakeholders === 0) {
            return [
                'score' => 0,
                'band' => 'critical',
                'color' => 'danger',
                'grade' => 'F',
                'label' => __('hierarchy.RaciHealthNotReady'),
            ];
        }

        $idlePenalty = min(12, $idleCount * 3);
        $overloadPenalty = min(10, $overloadedCount * 4);
        $consultPenalty = min(8, $consultedBottlenecks * 4);
        $balance = max(0, 15 - $idlePenalty - $overloadPenalty - $consultPenalty);

        $score = (int) round(
            ($fillRate * 0.25) +
            ($accountableRate * 0.35) +
            ($responsibleRate * 0.25) +
            $balance
        );
        $score = max(0, min(100, $score));

        if ($score >= 80) {
            $band = 'healthy';
            $color = 'success';
            $grade = $score >= 90 ? 'A' : 'B';
            $label = __('hierarchy.RaciHealthHealthy');
        } elseif ($score >= 55) {
            $band = 'watch';
            $color = 'warning';
            $grade = 'C';
            $label = __('hierarchy.RaciHealthWatch');
        } else {
            $band = 'critical';
            $color = 'danger';
            $grade = $score >= 40 ? 'D' : 'F';
            $label = __('hierarchy.RaciHealthCritical');
        }

        return compact('score', 'band', 'color', 'grade', 'label');
    }

    protected function buildFindings(
        int $activities,
        int $stakeholders,
        array $missingAccountable,
        array $missingResponsible,
        array $tooManyConsulted,
        array $tooManyInformed,
        array $unassignedActivities,
        array $idle,
        array $overloaded,
        array $accountableOwners
    ): array {
        $findings = [];

        if ($activities === 0 || $stakeholders === 0) {
            $findings[] = $this->finding('critical', 'empty', __('hierarchy.RaciFindingEmpty'));
            return $findings;
        }

        foreach (array_slice($missingAccountable, 0, 8) as $item) {
            $findings[] = $this->finding('critical', 'missing_a', __('hierarchy.RaciFindingMissingA', ['name' => $item['name']]));
        }
        foreach (array_slice($missingResponsible, 0, 8) as $item) {
            $findings[] = $this->finding('critical', 'missing_r', __('hierarchy.RaciFindingMissingR', ['name' => $item['name']]));
        }
        foreach (array_slice($unassignedActivities, 0, 5) as $item) {
            $findings[] = $this->finding('warning', 'unassigned', __('hierarchy.RaciFindingUnassigned', ['name' => $item['name']]));
        }
        foreach (array_slice($tooManyConsulted, 0, 5) as $item) {
            $findings[] = $this->finding('warning', 'too_many_c', __('hierarchy.RaciFindingTooManyC', [
                'name' => $item['name'],
                'count' => $item['count'],
            ]));
        }
        foreach (array_slice($tooManyInformed, 0, 3) as $item) {
            $findings[] = $this->finding('info', 'too_many_i', __('hierarchy.RaciFindingTooManyI', [
                'name' => $item['name'],
                'count' => $item['count'],
            ]));
        }
        foreach (array_slice($idle, 0, 5) as $item) {
            $findings[] = $this->finding('warning', 'idle', __('hierarchy.RaciFindingIdle', ['name' => $item['name']]));
        }
        foreach (array_slice($overloaded, 0, 5) as $item) {
            $findings[] = $this->finding('warning', 'overload', __('hierarchy.RaciFindingOverload', [
                'name' => $item['name'],
                'count' => $item['r_count'] + $item['a_count'],
                'total' => $activities,
            ]));
        }

        if (count($accountableOwners) === 1 && $activities > 2) {
            $findings[] = $this->finding('warning', 'spof', __('hierarchy.RaciFindingSingleOwner', [
                'name' => $accountableOwners[0],
            ]));
        }

        if (!$findings) {
            $findings[] = $this->finding('success', 'strong', __('hierarchy.RaciFindingStrong'));
        }

        return $findings;
    }

    protected function finding(string $severity, string $code, string $message): array
    {
        return compact('severity', 'code', 'message');
    }
}
