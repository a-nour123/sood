<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RaciAssignment extends Model
{
    use HasFactory;

    protected $guarded = [];

    public function activity()
    {
        return $this->belongsTo(RaciActivity::class, 'activity_id');
    }

    public function stakeholder()
    {
        return $this->belongsTo(RaciStakeholder::class, 'stakeholder_id');
    }
}
