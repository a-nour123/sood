<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RaciStakeholder extends Model
{
    use HasFactory;

    protected $guarded = [];

    public function matrix()
    {
        return $this->belongsTo(RaciMatrix::class, 'matrix_id');
    }

    public function assignments()
    {
        return $this->hasMany(RaciAssignment::class, 'stakeholder_id');
    }

    public function getLabelAttribute()
    {
        if ($this->stakeholder_type === 'job') {
            return optional(Job::find($this->stakeholder_id))->name;
        }

        if ($this->stakeholder_type === 'department') {
            return optional(Department::find($this->stakeholder_id))->name;
        }

        return optional(User::find($this->stakeholder_id))->name;
    }

    public function getTypeLabelAttribute()
    {
        return [
            'job' => __('locale.Job'),
            'department' => __('locale.Department'),
            'user' => __('locale.User'),
        ][$this->stakeholder_type] ?? $this->stakeholder_type;
    }
}
