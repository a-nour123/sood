<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RaciActivity extends Model
{
    use HasFactory;

    protected $guarded = [];

    public function matrix()
    {
        return $this->belongsTo(RaciMatrix::class, 'matrix_id');
    }

    public function assignments()
    {
        return $this->hasMany(RaciAssignment::class, 'activity_id');
    }
}
