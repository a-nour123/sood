<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RaciMatrix extends Model
{
    use HasFactory;

    protected $guarded = [];

    public function department()
    {
        return $this->belongsTo(Department::class);
    }

    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function activities()
    {
        return $this->hasMany(RaciActivity::class, 'matrix_id')->orderBy('sort_order')->orderBy('id');
    }

    public function stakeholders()
    {
        return $this->hasMany(RaciStakeholder::class, 'matrix_id')->orderBy('sort_order')->orderBy('id');
    }
}
