<div class="raci-analytics mb-2">
    <div class="d-flex justify-content-between align-items-center flex-wrap mb-1">
        <div>
            <h5 class="mb-25">{{ __('hierarchy.RaciStatistics') }}</h5>
            <small class="text-muted">{{ __('hierarchy.RaciHealthHint') }}</small>
        </div>
        <span id="raci-health-badge" class="badge bg-{{ $analytics['health']['color'] }}">
            {{ $analytics['health']['score'] }}% · {{ $analytics['health']['label'] }}
        </span>
    </div>

    <div class="row">
        <div class="col-xl-3 col-sm-6 mb-1">
            <div class="card raci-kpi-card h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <small class="text-muted">{{ __('hierarchy.RaciHealthScore') }}</small>
                            <h3 class="fw-bolder mb-0" id="raci-kpi-health">{{ $analytics['health']['score'] }}%</h3>
                            <small id="raci-kpi-health-label">{{ $analytics['health']['label'] }}</small>
                        </div>
                        <div class="avatar bg-light-{{ $analytics['health']['color'] }} p-50">
                            <span class="avatar-content"><i class="fa fa-shield-halved"></i></span>
                        </div>
                    </div>
                    <div class="small text-muted mt-50">{{ __('hierarchy.RaciGrade') }}: <strong id="raci-kpi-grade">{{ $analytics['health']['grade'] }}</strong></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-1">
            <div class="card raci-kpi-card h-100">
                <div class="card-body">
                    <small class="text-muted">{{ __('hierarchy.RaciFillRate') }}</small>
                    <h3 class="fw-bolder mb-0" id="raci-kpi-fill">{{ $analytics['coverage']['fill_rate'] }}%</h3>
                    <small>{{ __('hierarchy.RaciKpiFilled') }}: <span id="raci-kpi-filled">{{ $analytics['counts']['assignments'] }}</span></small>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-1">
            <div class="card raci-kpi-card h-100">
                <div class="card-body">
                    <small class="text-muted">{{ __('hierarchy.RaciMissingA') }}</small>
                    <h3 class="fw-bolder mb-0 text-danger" id="raci-kpi-a">{{ count($analytics['gaps']['missing_accountable']) }}</h3>
                    <small>{{ __('hierarchy.RaciRuleA') }}</small>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-1">
            <div class="card raci-kpi-card h-100">
                <div class="card-body">
                    <small class="text-muted">{{ __('hierarchy.RaciMissingR') }}</small>
                    <h3 class="fw-bolder mb-0 text-warning" id="raci-kpi-r">{{ count($analytics['gaps']['missing_responsible']) }}</h3>
                    <small>{{ __('hierarchy.RaciRuleR') }}</small>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-4 mb-1">
            <div class="card h-100">
                <div class="card-header py-1">
                    <h6 class="mb-0">{{ __('hierarchy.RaciHealthScore') }}</h6>
                </div>
                <div class="card-body">
                    <div id="raci-health-chart"></div>
                    <p class="small text-muted mb-0 text-center" id="raci-coverage-copy">
                        {{ __('hierarchy.RaciCoverageCopy', [
                            'a' => $analytics['coverage']['accountable_rate'],
                            'r' => $analytics['coverage']['responsible_rate'],
                            'fill' => $analytics['coverage']['fill_rate'],
                        ]) }}
                    </p>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-1">
            <div class="card h-100">
                <div class="card-header py-1">
                    <h6 class="mb-0">{{ __('hierarchy.RaciRoleMix') }}</h6>
                </div>
                <div class="card-body">
                    <div id="raci-role-chart"></div>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-1">
            <div class="card h-100">
                <div class="card-header py-1">
                    <h6 class="mb-0">{{ __('hierarchy.RaciInsights') }}</h6>
                </div>
                <div class="card-body" id="raci-findings">
                    @forelse ($analytics['findings'] as $finding)
                        <div class="raci-finding raci-finding-{{ $finding['severity'] === 'critical' ? 'danger' : ($finding['severity'] === 'warning' ? 'warning' : ($finding['severity'] === 'success' ? 'success' : 'info')) }}">
                            <i class="fa {{ $finding['severity'] === 'critical' ? 'fa-exclamation-circle' : ($finding['severity'] === 'warning' ? 'fa-exclamation-triangle' : ($finding['severity'] === 'success' ? 'fa-check-circle' : 'fa-info-circle')) }}"></i>
                            <div>{{ $finding['message'] }}</div>
                        </div>
                    @empty
                        <div class="text-muted small">{{ __('hierarchy.RaciNoFindings') }}</div>
                    @endforelse
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-7 mb-1">
            <div class="card h-100">
                <div class="card-header py-1">
                    <h6 class="mb-0">{{ __('hierarchy.RaciWorkload') }}</h6>
                </div>
                <div class="card-body">
                    <div id="raci-workload-chart"></div>
                </div>
            </div>
        </div>
        <div class="col-lg-5 mb-1">
            <div class="card h-100">
                <div class="card-header py-1">
                    <h6 class="mb-0">{{ __('hierarchy.RaciOverloaded') }} / {{ __('hierarchy.RaciIdleColumns') }}</h6>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-sm mb-0">
                            <thead>
                                <tr>
                                    <th>{{ __('hierarchy.RaciPeople') }}</th>
                                    <th class="text-center">R</th>
                                    <th class="text-center">A</th>
                                    <th class="text-center">C</th>
                                    <th class="text-center">I</th>
                                    <th class="text-center">Σ</th>
                                </tr>
                            </thead>
                            <tbody id="raci-workload-body">
                                @forelse ($analytics['workload'] as $row)
                                    <tr>
                                        <td>
                                            {{ $row['name'] }}
                                            <div class="small text-muted">{{ $row['type_label'] }}</div>
                                        </td>
                                        <td class="text-center"><span class="legend-letter raci-R">{{ $row['R'] }}</span></td>
                                        <td class="text-center"><span class="legend-letter raci-A">{{ $row['A'] }}</span></td>
                                        <td class="text-center"><span class="legend-letter raci-C">{{ $row['C'] }}</span></td>
                                        <td class="text-center"><span class="legend-letter raci-I">{{ $row['I'] }}</span></td>
                                        <td class="text-center fw-bold">{{ $row['total'] }}</td>
                                    </tr>
                                @empty
                                    <tr><td colspan="6" class="text-muted text-center">—</td></tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
