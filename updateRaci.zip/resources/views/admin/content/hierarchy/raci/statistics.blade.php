@extends('admin/layouts/contentLayoutMaster')

@section('title', __('hierarchy.RaciStatistics'))

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/charts/apexcharts.css')) }}">
@endsection

@section('page-style')
    <style>
        .raci-kpi-card { border-radius: 12px; box-shadow: 0 4px 14px rgba(68, 34, 92, .08); }
        .raci-finding {
            display: flex;
            gap: .6rem;
            align-items: flex-start;
            padding: .55rem .7rem;
            border-radius: 10px;
            margin-bottom: .45rem;
            font-size: .85rem;
        }
        .raci-finding i { margin-top: .15rem; }
        .raci-finding-danger { background: #ea54551a; color: #ea5455; }
        .raci-finding-warning { background: #ff9f431a; color: #d97706; }
        .raci-finding-info { background: #00cfe81a; color: #00b6cc; }
        .raci-finding-success { background: #28c76f1a; color: #28c76f; }
        .legend-letter {
            width: 28px;
            height: 28px;
            border-radius: 8px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: .8rem;
        }
        .raci-R { background: #28c76f1a; color: #28c76f; }
        .raci-A { background: #ea54551a; color: #ea5455; }
        .raci-C { background: #00cfe81a; color: #00cfe8; }
        .raci-I { background: #82868b1a; color: #4b4b4b; }
        .health-pill { border-radius: 999px; padding: .2rem .65rem; font-size: .75rem; font-weight: 700; }
    </style>
@endsection

@section('content')
    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">
            <div class="row breadcrumbs-top">
                <div class="col-12">
                    <div class="page-title mt-2">
                        <div class="row">
                            <div class="col-sm-8 ps-0">
                                @isset($breadcrumbs)
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item">
                                            <a href="{{ route('admin.dashboard') }}" style="display: flex;">
                                                <svg class="stroke-icon">
                                                    <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}"></use>
                                                </svg>
                                            </a>
                                        </li>
                                        @foreach ($breadcrumbs as $breadcrumb)
                                            <li class="breadcrumb-item">
                                                @if (isset($breadcrumb['link']))
                                                    <a href="{{ $breadcrumb['link'] }}">
                                                @endif
                                                {{ $breadcrumb['name'] }}
                                                @if (isset($breadcrumb['link']))
                                                    </a>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ol>
                                @endisset
                            </div>
                            <div class="col-sm-4 pe-0" style="text-align: end;">
                                <a href="{{ route('admin.hierarchy.raci.index') }}" class="btn btn-outline-secondary"
                                    title="{{ __('locale.Back') }}">{{ __('locale.Back') }}</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xl-3 col-sm-6 mb-1">
            <div class="card raci-kpi-card">
                <div class="card-body">
                    <small class="text-muted">{{ __('locale.RACI') }}</small>
                    <h3 class="fw-bolder mb-0">{{ $portfolio['summary']['matrices'] }}</h3>
                    <small>{{ __('hierarchy.RaciKpiTasks') }}: {{ $portfolio['summary']['activities'] }} · {{ __('hierarchy.RaciKpiPeople') }}: {{ $portfolio['summary']['stakeholders'] }}</small>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-1">
            <div class="card raci-kpi-card">
                <div class="card-body">
                    <small class="text-muted">{{ __('hierarchy.RaciAvgHealth') }}</small>
                    <h3 class="fw-bolder mb-0">{{ $portfolio['summary']['avg_health'] }}%</h3>
                    <small>{{ __('hierarchy.RaciBandHealthy') }}: {{ $portfolio['summary']['healthy'] }}</small>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-1">
            <div class="card raci-kpi-card">
                <div class="card-body">
                    <small class="text-muted">{{ __('hierarchy.RaciMatricesAtRisk') }}</small>
                    <h3 class="fw-bolder mb-0 text-danger">{{ $portfolio['summary']['critical'] }}</h3>
                    <small>{{ __('hierarchy.RaciBandWatch') }}: {{ $portfolio['summary']['watch'] }}</small>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-1">
            <div class="card raci-kpi-card">
                <div class="card-body">
                    <small class="text-muted">{{ __('hierarchy.RaciOpenGaps') }}</small>
                    <h3 class="fw-bolder mb-0 text-warning">{{ $portfolio['summary']['gaps'] }}</h3>
                    <small>{{ __('hierarchy.RaciMissingA') }} + {{ __('hierarchy.RaciMissingR') }}</small>
                </div>
            </div>
        </div>
    </div>

    @if ($portfolio['summary']['matrices'] === 0)
        <div class="card">
            <div class="card-body text-center text-muted py-3">{{ __('hierarchy.RaciNoMatrices') }}</div>
        </div>
    @else
        <div class="row">
            <div class="col-md-4 mb-1">
                <div class="card h-100">
                    <div class="card-header py-1"><h6 class="mb-0">{{ __('hierarchy.RaciHealthScore') }}</h6></div>
                    <div class="card-body"><div id="raci-portfolio-health-chart"></div></div>
                </div>
            </div>
            <div class="col-md-4 mb-1">
                <div class="card h-100">
                    <div class="card-header py-1"><h6 class="mb-0">{{ __('hierarchy.RaciRoleMix') }}</h6></div>
                    <div class="card-body"><div id="raci-portfolio-role-chart"></div></div>
                </div>
            </div>
            <div class="col-md-4 mb-1">
                <div class="card h-100">
                    <div class="card-header py-1"><h6 class="mb-0">{{ __('hierarchy.RaciTypeMix') }}</h6></div>
                    <div class="card-body"><div id="raci-portfolio-type-chart"></div></div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-7 mb-1">
                <div class="card">
                    <div class="card-header py-1"><h6 class="mb-0">{{ __('hierarchy.RaciRanking') }}</h6></div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th>{{ __('locale.Name') }}</th>
                                        <th>{{ __('locale.Department') }}</th>
                                        <th>{{ __('hierarchy.RaciHealthScore') }}</th>
                                        <th>{{ __('hierarchy.RaciFillRate') }}</th>
                                        <th>{{ __('hierarchy.RaciGaps') }}</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($portfolio['matrices'] as $row)
                                        <tr>
                                            <td>{{ $row['name'] }}</td>
                                            <td>{{ $row['department'] }}</td>
                                            <td>
                                                <span class="health-pill bg-light-{{ $row['health']['color'] }} text-{{ $row['health']['color'] }}">
                                                    {{ $row['health']['score'] }}% · {{ $row['health']['grade'] }}
                                                </span>
                                            </td>
                                            <td>{{ $row['coverage']['fill_rate'] }}%</td>
                                            <td>{{ $row['gap_count'] }}</td>
                                            <td>
                                                <a href="{{ $row['url'] }}" class="btn btn-sm btn-outline-primary"
                                                    title="{{ __('hierarchy.RaciViewMatrix') }}">{{ __('locale.View') }}</a>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-5 mb-1">
                <div class="card h-100">
                    <div class="card-header py-1"><h6 class="mb-0">{{ __('hierarchy.RaciInsights') }}</h6></div>
                    <div class="card-body" id="raci-findings">
                        @forelse ($portfolio['findings'] as $finding)
                            <div class="raci-finding raci-finding-{{ $finding['severity'] === 'critical' ? 'danger' : ($finding['severity'] === 'warning' ? 'warning' : 'info') }}">
                                <i class="fa {{ $finding['severity'] === 'critical' ? 'fa-exclamation-circle' : 'fa-exclamation-triangle' }}"></i>
                                <div>
                                    {{ $finding['message'] }}
                                    <a class="d-block small" href="{{ $finding['url'] }}">{{ $finding['matrix'] }}</a>
                                </div>
                            </div>
                        @empty
                            <div class="text-muted small">{{ __('hierarchy.RaciFindingStrong') }}</div>
                        @endforelse
                    </div>
                </div>
            </div>
        </div>
    @endif
@endsection

@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/charts/apexcharts.min.js')) }}"></script>
@endsection

@section('page-script')
    <script src="{{ asset('ajax-files/hierarchy/raci/analytics.js') }}"></script>
    <script>
        window.raciAnalyticsLang = {
            health: "{{ __('hierarchy.RaciHealthScore') }}",
            healthy: "{{ __('hierarchy.RaciBandHealthy') }}",
            watch: "{{ __('hierarchy.RaciBandWatch') }}",
            critical: "{{ __('hierarchy.RaciBandCritical') }}",
            job: "{{ __('locale.Job') }}",
            department: "{{ __('locale.Department') }}",
            user: "{{ __('locale.User') }}",
            noFindings: "{{ __('hierarchy.RaciNoFindings') }}"
        };
        $(function() {
            renderRaciPortfolioCharts(@json($portfolio));
        });
    </script>
@endsection
