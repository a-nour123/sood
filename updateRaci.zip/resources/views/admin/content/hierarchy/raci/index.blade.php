@extends('admin/layouts/contentLayoutMaster')

@section('title', __('locale.RACI'))

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/dataTables.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/responsive.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/buttons.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">
@endsection

@section('page-style')
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-sweet-alerts.css')) }}">
@endsection

@section('content')
    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">
            <div class="row breadcrumbs-top widget-grid">
                <div class="col-12">
                    <div class="page-title mt-2">
                        <div class="row">
                            <div class="col-sm-6 ps-0">
                                @isset($breadcrumbs)
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item">
                                            <a href="{{ route('admin.dashboard') }}" style="display: flex;">
                                                <svg class="stroke-icon">
                                                    <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}"></use>
                                                </svg>
                                            </a>
                                        </li>
                                        @foreach ($breadcrumbs as $breadcrumb)
                                            <li class="breadcrumb-item">
                                                @if (isset($breadcrumb['link']))
                                                    <a href="{{ $breadcrumb['link'] }}">
                                                @endif
                                                {{ $breadcrumb['name'] }}
                                                @if (isset($breadcrumb['link']))
                                                    </a>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ol>
                                @endisset
                            </div>
                            <div class="col-sm-6 pe-0" style="text-align: end;">
                                <div class="action-content">
                                    <a href="{{ route('admin.hierarchy.raci.statistics') }}" class="btn btn-outline-primary"
                                        title="{{ __('hierarchy.RaciStatistics') }}">
                                        <i class="fa fa-chart-pie"></i>
                                    </a>
                                    @if (auth()->user()->hasPermission('raci.create'))
                                        <button class="btn btn-primary" type="button" data-bs-toggle="modal"
                                            data-bs-target="#add-new-raci" title="{{ __('locale.Add') }}"
                                            aria-label="{{ __('locale.Add') }}">
                                            <i class="fa fa-plus"></i>
                                        </button>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @isset($portfolio)
        <div class="row">
            <div class="col-xl-3 col-sm-6 mb-1">
                <div class="card">
                    <div class="card-body">
                        <small class="text-muted">{{ __('hierarchy.RaciAvgHealth') }}</small>
                        <h3 class="fw-bolder mb-0">{{ $portfolio['summary']['avg_health'] }}%</h3>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-sm-6 mb-1">
                <div class="card">
                    <div class="card-body">
                        <small class="text-muted">{{ __('hierarchy.RaciMatricesAtRisk') }}</small>
                        <h3 class="fw-bolder mb-0 text-danger">{{ $portfolio['summary']['critical'] }}</h3>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-sm-6 mb-1">
                <div class="card">
                    <div class="card-body">
                        <small class="text-muted">{{ __('hierarchy.RaciOpenGaps') }}</small>
                        <h3 class="fw-bolder mb-0 text-warning">{{ $portfolio['summary']['gaps'] }}</h3>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-sm-6 mb-1">
                <div class="card">
                    <div class="card-body">
                        <small class="text-muted">{{ __('locale.RACI') }}</small>
                        <h3 class="fw-bolder mb-0">{{ $portfolio['summary']['matrices'] }}</h3>
                    </div>
                </div>
            </div>
        </div>
    @endisset

    <section id="advanced-search-datatable">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header border-bottom p-1">
                        <div class="head-label">
                            <h4 class="card-title">{{ __('locale.FilterBy') }}</h4>
                        </div>
                    </div>
                    <div class="card-body mt-2">
                        <form class="dt_adv_search" method="POST">
                            <div class="row g-1 mb-md-1">
                                <div class="col-md-3">
                                    <label class="form-label">{{ __('locale.Name') }}:</label>
                                    <input class="form-control dt-input" name="filter_name" type="text">
                                </div>
                            </div>
                        </form>
                        <div class="card-datatable pb-4">
                            <table class="dt-advanced-server-search table">
                                <thead>
                                    <tr>
                                        <th>{{ __('locale.#') }}</th>
                                        <th>{{ __('locale.Name') }}</th>
                                        <th>{{ __('locale.Description') }}</th>
                                        <th>{{ __('locale.Department') }}</th>
                                        <th>{{ __('hierarchy.RaciHealthScore') }}</th>
                                        <th>{{ __('locale.CreatedDate') }}</th>
                                        <th>{{ __('locale.Actions') }}</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    @if (auth()->user()->hasPermission('raci.create'))
        <div class="modal fade" id="add-new-raci" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">{{ __('hierarchy.AddANewRaci') }}</h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                            aria-label="{{ __('locale.Close') }}" title="{{ __('locale.Close') }}"></button>
                    </div>
                    <form action="{{ route('admin.hierarchy.raci.ajax.store') }}" method="POST">
                        @csrf
                        <div class="modal-body">
                            <div class="mb-1">
                                <label class="form-label">{{ __('locale.Name') }}</label>
                                <input type="text" name="name" class="form-control" required>
                                <span class="error error-name text-danger"></span>
                            </div>
                            <div class="mb-1">
                                <label class="form-label">{{ __('locale.Department') }}</label>
                                <select name="department_id" class="form-select select2">
                                    <option value="">{{ __('locale.AllOrganization') }}</option>
                                    @foreach ($departments as $department)
                                        <option value="{{ $department->id }}">{{ $department->name }}</option>
                                    @endforeach
                                </select>
                                <span class="error error-department_id text-danger"></span>
                            </div>
                            <div class="mb-1">
                                <label class="form-label">{{ __('locale.Description') }}</label>
                                <textarea name="description" class="form-control" rows="4"></textarea>
                                <span class="error error-description text-danger"></span>
                            </div>
                            <button type="submit" class="btn btn-primary"
                                title="{{ __('locale.Submit') }}">{{ __('locale.Submit') }}</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    @endif

    @if (auth()->user()->hasPermission('raci.update'))
        <div class="modal fade" id="edit-raci" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">{{ __('hierarchy.EditRaci') }}</h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                            aria-label="{{ __('locale.Close') }}" title="{{ __('locale.Close') }}"></button>
                    </div>
                    <form method="POST">
                        @csrf
                        <input type="hidden" name="id">
                        <div class="modal-body">
                            <div class="mb-1">
                                <label class="form-label">{{ __('locale.Name') }}</label>
                                <input type="text" name="name" class="form-control" required>
                                <span class="error error-name text-danger"></span>
                            </div>
                            <div class="mb-1">
                                <label class="form-label">{{ __('locale.Department') }}</label>
                                <select name="department_id" class="form-select select2">
                                    <option value="">{{ __('locale.AllOrganization') }}</option>
                                    @foreach ($departments as $department)
                                        <option value="{{ $department->id }}">{{ $department->name }}</option>
                                    @endforeach
                                </select>
                                <span class="error error-department_id text-danger"></span>
                                <small class="text-muted d-none department-lock-hint">{{ __('hierarchy.RaciDepartmentLockedHint') }}</small>
                            </div>
                            <div class="mb-1">
                                <label class="form-label">{{ __('locale.Description') }}</label>
                                <textarea name="description" class="form-control" rows="4"></textarea>
                                <span class="error error-description text-danger"></span>
                            </div>
                            <button type="submit" class="btn btn-primary"
                                title="{{ __('locale.Submit') }}">{{ __('locale.Submit') }}</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    @endif
@endsection

@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/tables/datatable/jquery.dataTables.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.bootstrap5.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.responsive.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/responsive.bootstrap5.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/datatables.buttons.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>
@endsection

@section('page-script')
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
    <script>
        const lang = [],
            URLs = [],
            permission = [];
        permission['edit'] = {{ auth()->user()->hasPermission('raci.update') ? 1 : 0 }};
        permission['delete'] = {{ auth()->user()->hasPermission('raci.delete') ? 1 : 0 }};
        permission['show'] = {{ auth()->user()->hasPermission('raci.list') ? 1 : 0 }};

        lang['Edit'] = "{{ __('locale.Edit') }}";
        lang['Delete'] = "{{ __('locale.Delete') }}";
        lang['View'] = "{{ __('locale.View') }}";
        lang['Gaps'] = "{{ __('hierarchy.RaciGaps') }}";
        lang['DetailsOfItem'] = "{{ __('locale.DetailsOfItem', ['item' => __('locale.RACI')]) }}";

        URLs['ajax_list'] = "{{ route('admin.hierarchy.raci.ajax.index') }}";
        URLs['show'] = "{{ route('admin.hierarchy.raci.show', ':id') }}";

        function initRaciModalSelect2($modal) {
            $modal.find('select.select2').each(function() {
                const $el = $(this);
                if ($el.hasClass('select2-hidden-accessible')) {
                    $el.select2('destroy');
                }
                $el.select2({
                    width: '100%',
                    dropdownParent: $modal,
                    dropdownAutoWidth: false
                });
            });
        }

        $('#add-new-raci, #edit-raci').on('shown.bs.modal', function() {
            initRaciModalSelect2($(this));
        });
    </script>
    <script src="{{ asset('ajax-files/hierarchy/raci/index.js') }}"></script>
    <script>
        $('#add-new-raci form').submit(function(e) {
            e.preventDefault();
            $.ajax({
                url: $(this).attr('action'),
                type: "POST",
                data: $(this).serialize(),
                success: function(data) {
                    if (data.status) {
                        makeAlert('success', data.message, "{{ __('locale.Success') }}");
                        $('#add-new-raci').modal('hide');
                        redrawDatatable();
                    } else {
                        showError(data['errors']);
                    }
                },
                error: function(response) {
                    const responseData = response.responseJSON;
                    makeAlert('error', responseData.message, "{{ __('locale.Error') }}");
                    showError(responseData.errors);
                }
            });
        });

        $('#edit-raci form').submit(function(e) {
            e.preventDefault();
            const id = $(this).find('input[name="id"]').val();
            let url = "{{ route('admin.hierarchy.raci.ajax.update', ':id') }}";
            url = url.replace(':id', id);
            $.ajax({
                url: url,
                type: "PUT",
                data: $(this).serialize(),
                success: function(data) {
                    if (data.status) {
                        makeAlert('success', data.message, "{{ __('locale.Success') }}");
                        $('#edit-raci').modal('hide');
                        redrawDatatable();
                    } else {
                        showError(data['errors']);
                    }
                },
                error: function(response) {
                    const responseData = response.responseJSON;
                    makeAlert('error', responseData.message, "{{ __('locale.Error') }}");
                    showError(responseData.errors);
                }
            });
        });

        function ShowModalEditRaci(id) {
            let url = "{{ route('admin.hierarchy.raci.ajax.edit', ':id') }}";
            url = url.replace(':id', id);
            $.ajax({
                url: url,
                type: "GET",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    if (response.status) {
                        const editForm = $("#edit-raci form");
                        editForm.find('input[name="id"]').val(id);
                        editForm.find("input[name='name']").val(response.data.name);
                        editForm.find("textarea[name='description']").val(response.data.description);
                        const $department = editForm.find("select[name='department_id']");
                        const locked = !!response.data.has_stakeholders;
                        $department.val(response.data.department_id || '');
                        $department.prop('disabled', locked);
                        editForm.find('.department-lock-hint').toggleClass('d-none', !locked);
                        editForm.find('.locked-department-id').remove();
                        if (locked) {
                            $department.after(
                                '<input type="hidden" name="department_id" class="locked-department-id" value="' +
                                (response.data.department_id || '') + '">'
                            );
                        }
                        $('#edit-raci').modal('show');
                    }
                },
                error: function(response) {
                    makeAlert('error', response.responseJSON.message, "{{ __('locale.Error') }}");
                }
            });
        }

        function DeleteRaci(id) {
            let url = "{{ route('admin.hierarchy.raci.ajax.destroy', ':id') }}";
            url = url.replace(':id', id);
            $.ajax({
                url: url,
                type: "DELETE",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(data) {
                    if (data.status) {
                        makeAlert('success', data.message, "{{ __('locale.Success') }}");
                        redrawDatatable();
                    }
                },
                error: function(response) {
                    makeAlert('error', response.responseJSON.message, "{{ __('locale.Error') }}");
                }
            });
        }

        function ShowModalDeleteRaci(id) {
            Swal.fire({
                title: "{{ __('locale.AreYouSureToDeleteThisRecord') }}",
                text: "{{ __('locale.YouWontBeAbleToRevertThis') }}",
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: "{{ __('locale.ConfirmDelete') }}",
                cancelButtonText: "{{ __('locale.Cancel') }}",
                customClass: {
                    confirmButton: 'btn btn-relief-success ms-1',
                    cancelButton: 'btn btn-outline-danger ms-1'
                },
                buttonsStyling: false
            }).then(function(result) {
                if (result.value) {
                    DeleteRaci(id);
                }
            });
        }

        $('.modal').on('hidden.bs.modal', function() {
            const $modal = $(this);
            const form = $modal.find('form');
            $modal.find('select.select2').each(function() {
                const $el = $(this);
                if ($el.hasClass('select2-hidden-accessible')) {
                    $el.select2('close');
                    $el.select2('destroy');
                }
            });
            $('.error').empty();
            form.find('.locked-department-id').remove();
            form.find('.department-lock-hint').addClass('d-none');
            form.find("select[name='department_id']").prop('disabled', false);
            form.trigger("reset");
            form.find('select').val('');
        });
    </script>
@endsection
