@extends('admin/layouts/contentLayoutMaster')

@section('title', $matrix->name)

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/charts/apexcharts.css')) }}">
@endsection

@section('page-style')
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-sweet-alerts.css')) }}">
    <style>
        .raci-hero {
            background: linear-gradient(135deg, #44225c 0%, #6b3d8a 100%);
            color: #fff;
            border-radius: 14px;
            padding: 1.25rem 1.5rem;
        }
        .raci-hero h3 { color: #fff; margin-bottom: .35rem; }
        .legend-card {
            border: 0;
            border-radius: 12px;
            height: 100%;
            box-shadow: 0 4px 14px rgba(68, 34, 92, .08);
        }
        .legend-letter {
            width: 42px;
            height: 42px;
            border-radius: 10px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-weight: 800;
            font-size: 1.15rem;
        }
        .raci-R { background: #28c76f1a; color: #28c76f; }
        .raci-A { background: #ea54551a; color: #ea5455; }
        .raci-C { background: #00cfe81a; color: #00cfe8; }
        .raci-I { background: #82868b1a; color: #4b4b4b; }
        .setup-card { border-radius: 12px; height: 100%; }
        .step-num {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            background: #44225c;
            color: #fff;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: .8rem;
            font-weight: 700;
            margin-inline-end: .5rem;
        }
        .raci-wrap { overflow-x: auto; }
        .raci-table { min-width: 760px; }
        .raci-table th { background: #f8f5fb; vertical-align: middle; text-align: center; }
        .raci-table td { vertical-align: middle; }
        .raci-table .activity-col {
            text-align: start;
            min-width: 220px;
            position: sticky;
            inset-inline-start: 0;
            background: #fff;
            z-index: 2;
        }
        .raci-table thead .activity-col { background: #f8f5fb; z-index: 3; }
        .raci-role-select { min-width: 150px; font-weight: 600; }
        .type-pill {
            font-size: .7rem;
            border-radius: 999px;
            padding: .15rem .5rem;
            background: #44225c14;
            color: #44225c;
        }
        .added-chip {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: #f4eef8;
            border-radius: 999px;
            padding: .25rem .7rem;
            margin: 0 .35rem .35rem 0;
            font-size: .85rem;
        }
        .empty-box {
            border: 2px dashed #d9d2e2;
            border-radius: 12px;
            padding: 2rem 1rem;
            text-align: center;
            color: #6e6b7b;
            background: #faf8fc;
        }
        .raci-kpi-card { border-radius: 12px; box-shadow: 0 4px 14px rgba(68, 34, 92, .08); }
        .raci-finding {
            display: flex;
            gap: .6rem;
            align-items: flex-start;
            padding: .55rem .7rem;
            border-radius: 10px;
            margin-bottom: .45rem;
            font-size: .85rem;
        }
        .raci-finding i { margin-top: .15rem; }
        .raci-finding-danger { background: #ea54551a; color: #ea5455; }
        .raci-finding-warning { background: #ff9f431a; color: #d97706; }
        .raci-finding-info { background: #00cfe81a; color: #00b6cc; }
        .raci-finding-success { background: #28c76f1a; color: #28c76f; }
        .raci-analytics .legend-letter {
            width: 28px;
            height: 28px;
            font-size: .8rem;
        }
    </style>
@endsection

@section('content')
    @php
        $canUpdate = auth()->user()->hasPermission('raci.update');
        $hasPeople = $matrix->stakeholders->count() > 0;
        $hasTasks = $matrix->activities->count() > 0;
    @endphp

    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">
            <div class="row breadcrumbs-top">
                <div class="col-12">
                    <div class="page-title mt-2">
                        <div class="row">
                            <div class="col-sm-8 ps-0">
                                @isset($breadcrumbs)
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item">
                                            <a href="{{ route('admin.dashboard') }}" style="display: flex;">
                                                <svg class="stroke-icon">
                                                    <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}"></use>
                                                </svg>
                                            </a>
                                        </li>
                                        @foreach ($breadcrumbs as $breadcrumb)
                                            <li class="breadcrumb-item">
                                                @if (isset($breadcrumb['link']))
                                                    <a href="{{ $breadcrumb['link'] }}">
                                                @endif
                                                {{ $breadcrumb['name'] }}
                                                @if (isset($breadcrumb['link']))
                                                    </a>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ol>
                                @endisset
                            </div>
                            <div class="col-sm-4 pe-0" style="text-align: end;">
                                <a href="{{ route('admin.hierarchy.raci.statistics') }}" class="btn btn-outline-primary me-50"
                                    title="{{ __('hierarchy.RaciStatistics') }}">
                                    <i class="fa fa-chart-pie"></i> {{ __('hierarchy.RaciStatistics') }}
                                </a>
                                <a href="{{ route('admin.hierarchy.raci.index') }}" class="btn btn-outline-secondary"
                                    title="{{ __('locale.Back') }}">{{ __('locale.Back') }}</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="raci-hero mb-2">
        <h3>{{ $matrix->name }}</h3>
        <p class="mb-50">{{ __('hierarchy.RaciHowItWorks') }}</p>
        <small>{{ __('hierarchy.RaciHowItWorksHint') }}</small>
        <div class="mt-1">
            <span class="badge bg-light text-dark">
                {{ $matrix->department->name ?? __('locale.AllOrganization') }}
                @if ($hasPeople)
                    <i class="fa fa-lock ms-25" title="{{ __('hierarchy.RaciDepartmentLockedHint') }}"></i>
                @endif
            </span>
            @if ($hasPeople)
                <div class="small mt-50 opacity-75">{{ __('hierarchy.RaciDepartmentLockedHint') }}</div>
            @endif
            @if ($matrix->description)
                <span class="ms-50">{{ $matrix->description }}</span>
            @endif
        </div>
    </div>

    <div class="row mb-2">
        <div class="col-md-3 col-sm-6 mb-1">
            <div class="card legend-card">
                <div class="card-body d-flex align-items-start">
                    <span class="legend-letter raci-R me-1">R</span>
                    <div>
                        <strong>{{ __('hierarchy.Responsible') }}</strong>
                        <div class="small text-muted">{{ __('hierarchy.ResponsibleHint') }}</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6 mb-1">
            <div class="card legend-card">
                <div class="card-body d-flex align-items-start">
                    <span class="legend-letter raci-A me-1">A</span>
                    <div>
                        <strong>{{ __('hierarchy.Accountable') }}</strong>
                        <div class="small text-muted">{{ __('hierarchy.AccountableHint') }}</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6 mb-1">
            <div class="card legend-card">
                <div class="card-body d-flex align-items-start">
                    <span class="legend-letter raci-C me-1">C</span>
                    <div>
                        <strong>{{ __('hierarchy.Consulted') }}</strong>
                        <div class="small text-muted">{{ __('hierarchy.ConsultedHint') }}</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6 mb-1">
            <div class="card legend-card">
                <div class="card-body d-flex align-items-start">
                    <span class="legend-letter raci-I me-1">I</span>
                    <div>
                        <strong>{{ __('hierarchy.Informed') }}</strong>
                        <div class="small text-muted">{{ __('hierarchy.InformedHint') }}</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @include('admin.content.hierarchy.raci.partials.analytics-panel')

    @if ($canUpdate)
        <div class="row mb-2">
            <div class="col-lg-6 mb-1">
                <div class="card setup-card">
                    <div class="card-body">
                        <h5 class="mb-50">
                            <span class="step-num">1</span>{{ __('hierarchy.RaciStepPeople') }}
                        </h5>
                        <p class="text-muted small">{{ __('hierarchy.RaciStepPeopleHint') }}</p>
                        <form id="add-stakeholder-form">
                            <label class="form-label">{{ __('hierarchy.ChooseType') }}</label>
                            <select name="stakeholder_type" id="stakeholder-type" class="form-select mb-1">
                                <option value="job">{{ __('locale.Job') }}</option>
                                <option value="department">{{ __('locale.Department') }}</option>
                                <option value="user">{{ __('locale.User') }}</option>
                            </select>
                            <label class="form-label">{{ __('hierarchy.ChoosePerson') }}</label>
                            <select name="stakeholder_id" id="stakeholder-id" class="form-select mb-1"></select>
                            <div class="d-flex gap-1 flex-wrap">
                                <button class="btn btn-primary" type="submit" title="{{ __('hierarchy.AddStakeholder') }}">
                                    {{ __('hierarchy.AddStakeholder') }}
                                </button>
                                <button type="button" class="btn btn-outline-primary" id="import-hierarchy-btn"
                                    title="{{ __('hierarchy.ImportFromHierarchy') }}">
                                    {{ __('hierarchy.ImportFromHierarchy') }}
                                </button>
                            </div>
                        </form>
                        <hr>
                        <div class="small text-muted mb-50">{{ __('hierarchy.RaciAddedPeople') }}</div>
                        @forelse ($matrix->stakeholders as $stakeholder)
                            <span class="added-chip">
                                {{ $stakeholder->label ?: '-' }}
                                <small>({{ $stakeholder->type_label }})</small>
                                <button type="button" class="btn btn-sm p-0 text-danger delete-stakeholder"
                                    data-id="{{ $stakeholder->id }}" title="{{ __('locale.Delete') }}">
                                    <i class="fa fa-times"></i>
                                </button>
                            </span>
                        @empty
                            <div class="small text-muted">{{ __('hierarchy.RaciNoPeopleAdded') }}</div>
                        @endforelse
                    </div>
                </div>
            </div>
            <div class="col-lg-6 mb-1">
                <div class="card setup-card">
                    <div class="card-body">
                        <h5 class="mb-50">
                            <span class="step-num">2</span>{{ __('hierarchy.RaciStepActivities') }}
                        </h5>
                        <p class="text-muted small">{{ __('hierarchy.RaciStepActivitiesHint') }}</p>
                        <form id="add-activity-form">
                            <label class="form-label">{{ __('hierarchy.ActivityName') }}</label>
                            <input type="text" name="name" class="form-control mb-1" required
                                placeholder="{{ __('hierarchy.ActivityName') }}">
                            <button class="btn btn-primary" type="submit" title="{{ __('hierarchy.AddActivity') }}">
                                {{ __('hierarchy.AddActivity') }}
                            </button>
                        </form>
                        <hr>
                        <div class="small text-muted mb-50">{{ __('hierarchy.RaciAddedTasks') }}</div>
                        @forelse ($matrix->activities as $activity)
                            <span class="added-chip">
                                {{ $activity->name }}
                                <button type="button" class="btn btn-sm p-0 text-danger delete-activity"
                                    data-id="{{ $activity->id }}" title="{{ __('locale.Delete') }}">
                                    <i class="fa fa-times"></i>
                                </button>
                            </span>
                        @empty
                            <div class="small text-muted">{{ __('hierarchy.RaciNoTasksAdded') }}</div>
                        @endforelse
                    </div>
                </div>
            </div>
        </div>
    @endif

    <div class="card">
        <div class="card-header border-bottom">
            <div>
                <h5 class="mb-25">
                    <span class="step-num">3</span>{{ __('hierarchy.RaciStepAssign') }}
                </h5>
                <small class="text-muted">{{ __('hierarchy.RaciStepAssignHint') }}</small>
            </div>
        </div>
        <div class="card-body">
            @if (!$hasPeople && !$hasTasks)
                <div class="empty-box">
                    {{ __('hierarchy.RaciEmptyMatrix') }}
                </div>
            @elseif ($hasPeople && !$hasTasks)
                <div class="empty-box mb-1">
                    {{ __('hierarchy.RaciAddTaskToAssign') }}
                </div>
                <div class="raci-wrap">
                    <table class="table table-bordered raci-table">
                        <thead>
                            <tr>
                                <th class="activity-col">{{ __('hierarchy.RaciTasks') }}</th>
                                @foreach ($matrix->stakeholders as $stakeholder)
                                    <th>
                                        <div>{{ $stakeholder->label ?: '-' }}</div>
                                        <span class="type-pill">{{ $stakeholder->type_label }}</span>
                                    </th>
                                @endforeach
                            </tr>
                        </thead>
                    </table>
                </div>
            @else
                <div class="raci-wrap">
                    <table class="table table-bordered raci-table">
                        <thead>
                            <tr>
                                <th class="activity-col">{{ __('hierarchy.RaciTasks') }}</th>
                                @foreach ($matrix->stakeholders as $stakeholder)
                                    <th>
                                        <div>{{ $stakeholder->label ?: '-' }}</div>
                                        <span class="type-pill">{{ $stakeholder->type_label }}</span>
                                        @if ($canUpdate)
                                            <div>
                                                <button type="button" class="btn btn-sm btn-link text-danger p-0 delete-stakeholder"
                                                    data-id="{{ $stakeholder->id }}" title="{{ __('locale.Delete') }}">
                                                    <i class="fa fa-times"></i> {{ __('locale.Delete') }}
                                                </button>
                                            </div>
                                        @endif
                                    </th>
                                @endforeach
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($matrix->activities as $activity)
                                @php
                                    $hasAccountable = $activity->assignments->contains(fn($item) => $item->role === 'A');
                                @endphp
                                <tr>
                                    <td class="activity-col">
                                        <strong>{{ $activity->name }}</strong>
                                        @if (!$hasAccountable)
                                            <div class="small text-danger">{{ __('hierarchy.RaciMissingAccountable') }}</div>
                                        @endif
                                        @if ($canUpdate)
                                            <button type="button" class="btn btn-sm btn-link text-danger p-0 delete-activity"
                                                data-id="{{ $activity->id }}" title="{{ __('locale.Delete') }}">
                                                <i class="fa fa-trash"></i> {{ __('locale.Delete') }}
                                            </button>
                                        @endif
                                    </td>
                                    @foreach ($matrix->stakeholders as $stakeholder)
                                        @php $role = $assignmentMap[$activity->id . '_' . $stakeholder->id] ?? ''; @endphp
                                        <td>
                                            @if ($canUpdate)
                                                <select class="form-select raci-role-select"
                                                    data-activity="{{ $activity->id }}"
                                                    data-stakeholder="{{ $stakeholder->id }}">
                                                    <option value="">{{ __('hierarchy.RaciChooseRole') }}</option>
                                                    <option value="R" {{ $role === 'R' ? 'selected' : '' }}>R — {{ __('hierarchy.ResponsibleHint') }}</option>
                                                    <option value="A" {{ $role === 'A' ? 'selected' : '' }}>A — {{ __('hierarchy.AccountableHint') }}</option>
                                                    <option value="C" {{ $role === 'C' ? 'selected' : '' }}>C — {{ __('hierarchy.ConsultedHint') }}</option>
                                                    <option value="I" {{ $role === 'I' ? 'selected' : '' }}>I — {{ __('hierarchy.InformedHint') }}</option>
                                                </select>
                                            @else
                                                @if ($role)
                                                    <span class="legend-letter raci-{{ $role }}">{{ $role }}</span>
                                                @else
                                                    —
                                                @endif
                                            @endif
                                        </td>
                                    @endforeach
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @endif
        </div>
    </div>
@endsection

@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/charts/apexcharts.min.js')) }}"></script>
@endsection

@section('page-script')
    <script src="{{ asset('ajax-files/hierarchy/raci/analytics.js') }}"></script>
    <script>
        const canUpdate = {{ $canUpdate ? 'true' : 'false' }};
        window.raciAnalyticsLang = {
            health: "{{ __('hierarchy.RaciHealthScore') }}",
            noFindings: "{{ __('hierarchy.RaciNoFindings') }}",
            coverageCopy: "{{ __('hierarchy.RaciCoverageCopy', ['a' => ':a', 'r' => ':r', 'fill' => ':fill']) }}"
        };
        const analyticsUrl = "{{ route('admin.hierarchy.raci.ajax.analytics', $matrix->id) }}";
        const jobs = @json($jobs->map(fn($item) => ['id' => $item->id, 'name' => $item->name]));
        const departments = @json($departments->map(fn($item) => ['id' => $item->id, 'name' => $item->name]));
        const users = @json($users->map(fn($item) => ['id' => $item->id, 'name' => $item->name]));
        const addedStakeholders = @json($matrix->stakeholders->map(fn($item) => [
            'type' => $item->stakeholder_type,
            'id' => (int) $item->stakeholder_id,
        ])->values());

        function makeAlert(status, message, title) {
            toastr[status](message, title, { closeButton: true, tapToDismiss: false });
        }

        function fillStakeholderOptions(type) {
            const source = type === 'department' ? departments : (type === 'user' ? users : jobs);
            const usedIds = addedStakeholders
                .filter(function(item) { return item.type === type; })
                .map(function(item) { return String(item.id); });
            const $select = $('#stakeholder-id');
            if ($select.hasClass('select2-hidden-accessible')) {
                $select.select2('destroy');
            }
            $select.empty();
            source.forEach(function(item) {
                if (usedIds.indexOf(String(item.id)) !== -1) {
                    return;
                }
                $select.append(new Option(item.name, item.id, false, false));
            });
            $select.select2({
                width: '100%',
                dropdownAutoWidth: false
            });
        }

        function paintSelect($select) {
            $select.removeClass('raci-R raci-A raci-C raci-I');
            if ($select.val()) {
                $select.addClass('raci-' + $select.val());
            }
        }

        function refreshRaciAnalytics() {
            $.get(analyticsUrl, function(res) {
                if (res && res.data) {
                    renderRaciMatrixAnalytics(res.data);
                }
            });
        }

        $(function() {
            fillStakeholderOptions('job');
            $('.raci-role-select').each(function() {
                paintSelect($(this));
            });
            renderRaciMatrixAnalytics(@json($analytics));

            $('#stakeholder-type').on('change', function() {
                fillStakeholderOptions($(this).val());
            });

            $('#add-activity-form').on('submit', function(e) {
                e.preventDefault();
                $.ajax({
                    url: "{{ route('admin.hierarchy.raci.ajax.activity.store', $matrix->id) }}",
                    type: "POST",
                    data: $(this).serialize() + '&_token={{ csrf_token() }}',
                    success: function(data) {
                        makeAlert('success', data.message, "{{ __('locale.Success') }}");
                        location.reload();
                    },
                    error: function(response) {
                        makeAlert('error', response.responseJSON.message, "{{ __('locale.Error') }}");
                    }
                });
            });

            $('#add-stakeholder-form').on('submit', function(e) {
                e.preventDefault();
                $.ajax({
                    url: "{{ route('admin.hierarchy.raci.ajax.stakeholder.store', $matrix->id) }}",
                    type: "POST",
                    data: $(this).serialize() + '&_token={{ csrf_token() }}',
                    success: function(data) {
                        makeAlert('success', data.message, "{{ __('locale.Success') }}");
                        location.reload();
                    },
                    error: function(response) {
                        makeAlert('error', response.responseJSON.message, "{{ __('locale.Error') }}");
                    }
                });
            });

            $('#import-hierarchy-btn').on('click', function() {
                $.ajax({
                    url: "{{ route('admin.hierarchy.raci.ajax.import_hierarchy', $matrix->id) }}",
                    type: "POST",
                    data: { _token: "{{ csrf_token() }}" },
                    success: function(data) {
                        makeAlert('success', data.message, "{{ __('locale.Success') }}");
                        location.reload();
                    },
                    error: function(response) {
                        makeAlert('error', response.responseJSON.message, "{{ __('locale.Error') }}");
                    }
                });
            });

            $(document).on('click', '.delete-activity, .delete-stakeholder', function() {
                const isActivity = $(this).hasClass('delete-activity');
                const id = $(this).data('id');
                const urlTemplate = isActivity
                    ? "{{ route('admin.hierarchy.raci.ajax.activity.destroy', ':id') }}"
                    : "{{ route('admin.hierarchy.raci.ajax.stakeholder.destroy', ':id') }}";
                Swal.fire({
                    title: "{{ __('locale.AreYouSureToDeleteThisRecord') }}",
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: "{{ __('locale.ConfirmDelete') }}",
                    cancelButtonText: "{{ __('locale.Cancel') }}"
                }).then(function(result) {
                    if (!result.value) return;
                    $.ajax({
                        url: urlTemplate.replace(':id', id),
                        type: "DELETE",
                        headers: { 'X-CSRF-TOKEN': "{{ csrf_token() }}" },
                        success: function(data) {
                            makeAlert('success', data.message, "{{ __('locale.Success') }}");
                            location.reload();
                        }
                    });
                });
            });

            $(document).on('change', '.raci-role-select', function() {
                if (!canUpdate) return;
                const $select = $(this);
                const role = $select.val();
                $.ajax({
                    url: "{{ route('admin.hierarchy.raci.ajax.assignment.save') }}",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}",
                        activity_id: $select.data('activity'),
                        stakeholder_id: $select.data('stakeholder'),
                        role: role
                    },
                    success: function(data) {
                        paintSelect($select);
                        if (data.role === 'A') {
                            $select.closest('tr').find('.raci-role-select').not($select).each(function() {
                                if ($(this).val() === 'A') {
                                    $(this).val('').trigger('change.select2');
                                    paintSelect($(this));
                                }
                            });
                        }
                        makeAlert('success', data.message, "{{ __('locale.Success') }}");
                        refreshRaciAnalytics();
                    },
                    error: function(response) {
                        makeAlert('error', response.responseJSON.message, "{{ __('locale.Error') }}");
                    }
                });
            });
        });
    </script>
@endsection
