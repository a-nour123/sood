function showError(data) {
  $('.error').empty();
  $.each(data || {}, function (key, value) {
    $('.error-' + key).empty();
    $('.error-' + key).append(value);
  });
}

function makeAlert($status, message, title) {
  if (title == 'Success') {
    title = '👋' + title;
  }
  toastr[$status](message, title, {
    closeButton: true,
    tapToDismiss: false,
  });
}

drawDatatable(
  [
    { data: 'id' },
    { data: 'name' },
    { data: 'description' },
    { data: 'department', orderable: false, searchable: false },
    {
      data: 'health',
      orderable: false,
      searchable: false,
      render: function (data) {
        if (!data) return '-';
        const color = data.health_band === 'healthy' ? 'success' : (data.health_band === 'watch' ? 'warning' : 'danger');
        return '<span class="badge bg-' + color + '">' + data.health_score + '%</span>' +
          '<div class="small text-muted">' + (data.health_label || '') +
          ' · ' + (data.gap_count || 0) + ' ' + (lang['Gaps'] || 'gaps') +
          ' · ' + (data.fill_rate || 0) + '%</div>';
      }
    },
    { data: 'created_at' },
    { data: 'Actions' }
  ],
  [
    {
      targets: -1,
      orderable: false,
      searchable: false,
      render: function (data) {
        let returnedString = '<div class="d-inline-flex">' +
          '<a class="pe-1 dropdown-toggle hide-arrow text-primary" data-bs-toggle="dropdown">' +
          '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical font-small-4"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg>' +
          '</a><div class="dropdown-menu dropdown-menu-end">';

        if (permission['show']) {
          const showUrl = URLs['show'].replace(':id', data);
          returnedString += '<a href="' + showUrl + '" class="dropdown-item">' +
            feather.icons['eye'].toSvg({ class: 'me-50 font-small-4' }) + lang['View'] + '</a>';
        }
        if (permission['edit']) {
          returnedString += '<a href="javascript:;" class="dropdown-item" onclick="ShowModalEditRaci(' + data + ')">' +
            feather.icons['edit'].toSvg({ class: 'me-50 font-small-4' }) + lang['Edit'] + '</a>';
        }
        if (permission['delete']) {
          returnedString += '<a href="javascript:;" class="dropdown-item" onclick="ShowModalDeleteRaci(' + data + ')">' +
            feather.icons['trash-2'].toSvg({ class: 'me-50 font-small-4' }) + lang['Delete'] + '</a>';
        }

        returnedString += '</div></div>';
        return returnedString;
      }
    }
  ],
  lang['DetailsOfItem'],
  'name'
);
