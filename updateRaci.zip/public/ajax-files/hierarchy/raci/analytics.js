function raciBandColor(band) {
  if (band === 'healthy') return '#28c76f';
  if (band === 'watch') return '#ff9f43';
  return '#ea5455';
}

function raciFindingClass(severity) {
  if (severity === 'critical') return 'danger';
  if (severity === 'warning') return 'warning';
  if (severity === 'success') return 'success';
  return 'info';
}

function raciFindingIcon(severity) {
  if (severity === 'critical') return 'fa-exclamation-circle';
  if (severity === 'warning') return 'fa-exclamation-triangle';
  if (severity === 'success') return 'fa-check-circle';
  return 'fa-info-circle';
}

function renderRaciFindings(target, findings) {
  const $box = $(target);
  if (!$box.length) return;
  if (!findings || !findings.length) {
    $box.html('<div class="text-muted small">' + (window.raciAnalyticsLang.noFindings || '') + '</div>');
    return;
  }
  const html = findings.map(function (item) {
    const cls = raciFindingClass(item.severity);
    const icon = raciFindingIcon(item.severity);
    const extra = item.matrix
      ? '<a class="ms-50" href="' + item.url + '">' + item.matrix + '</a>'
      : '';
    return '<div class="raci-finding raci-finding-' + cls + '">' +
      '<i class="fa ' + icon + '"></i>' +
      '<div>' + item.message + extra + '</div>' +
      '</div>';
  }).join('');
  $box.html(html);
}

function renderRaciWorkload(target, workload) {
  const $box = $(target);
  if (!$box.length) return;
  if (!workload || !workload.length) {
    $box.html('<div class="text-muted small">—</div>');
    return;
  }
  const rows = workload.map(function (row) {
    return '<tr>' +
      '<td>' + (row.name || '-') + '<div class="small text-muted">' + (row.type_label || '') + '</div></td>' +
      '<td class="text-center"><span class="legend-letter raci-R">' + row.R + '</span></td>' +
      '<td class="text-center"><span class="legend-letter raci-A">' + row.A + '</span></td>' +
      '<td class="text-center"><span class="legend-letter raci-C">' + row.C + '</span></td>' +
      '<td class="text-center"><span class="legend-letter raci-I">' + row.I + '</span></td>' +
      '<td class="text-center fw-bold">' + row.total + '</td>' +
      '</tr>';
  }).join('');
  $box.html(rows);
}

function raciChartBase() {
  return {
    chart: {
      fontFamily: 'inherit',
      toolbar: { show: false },
      parentHeightOffset: 0
    },
    legend: { fontSize: '12px' }
  };
}

function renderRaciHealthChart(selector, score, band) {
  const el = document.querySelector(selector);
  if (!el || typeof ApexCharts === 'undefined') return;
  const store = window.raciCharts = window.raciCharts || {};
  const options = Object.assign(raciChartBase(), {
    chart: { type: 'radialBar', height: 220, sparkline: { enabled: true } },
    series: [score || 0],
    colors: [raciBandColor(band)],
    plotOptions: {
      radialBar: {
        hollow: { size: '62%' },
        track: { background: '#eee6f3' },
        dataLabels: {
          name: { show: true, fontSize: '12px', offsetY: 22, color: '#6e6b7b' },
          value: { fontSize: '28px', fontWeight: 700, offsetY: -12, formatter: function (val) { return val + '%'; } }
        }
      }
    },
    labels: [window.raciAnalyticsLang.health || 'Health']
  });
  if (store[selector]) {
    store[selector].updateOptions(options, true, true);
    store[selector].updateSeries([score || 0], true);
  } else {
    store[selector] = new ApexCharts(el, options);
    store[selector].render();
  }
}

function seriesTotal(series) {
  return (series || []).reduce(function (sum, n) { return sum + Number(n || 0); }, 0);
}

function renderRaciDonut(selector, labels, series, colors) {
  const el = document.querySelector(selector);
  if (!el || typeof ApexCharts === 'undefined') return;
  const store = window.raciCharts = window.raciCharts || {};
  if (seriesTotal(series) === 0) {
    if (store[selector]) {
      store[selector].destroy();
      delete store[selector];
    }
    el.innerHTML = '<div class="text-muted text-center py-2">—</div>';
    return;
  }
  const options = Object.assign(raciChartBase(), {
    chart: { type: 'donut', height: 240 },
    labels: labels,
    series: series,
    colors: colors,
    stroke: { width: 0 },
    legend: { position: 'bottom' },
    dataLabels: { enabled: true },
    plotOptions: { pie: { donut: { size: '68%' } } }
  });
  if (store[selector]) {
    store[selector].updateOptions(options, true, true);
    store[selector].updateSeries(series);
  } else {
    el.innerHTML = '';
    store[selector] = new ApexCharts(el, options);
    store[selector].render();
  }
}

function renderRaciWorkloadChart(selector, workload) {
  const el = document.querySelector(selector);
  if (!el || typeof ApexCharts === 'undefined') return;
  const store = window.raciCharts = window.raciCharts || {};
  const names = (workload || []).map(function (row) { return row.name; });
  if (!names.length) {
    if (store[selector]) {
      store[selector].destroy();
      delete store[selector];
    }
    el.innerHTML = '<div class="text-muted text-center py-2">—</div>';
    return;
  }
  const options = Object.assign(raciChartBase(), {
    chart: { type: 'bar', stacked: true, height: Math.max(240, names.length * 28) },
    plotOptions: { bar: { horizontal: true, barHeight: '62%' } },
    xaxis: { categories: names, labels: { show: false } },
    yaxis: { labels: { maxWidth: 160 } },
    colors: ['#28c76f', '#ea5455', '#00cfe8', '#82868b'],
    series: [
      { name: 'R', data: (workload || []).map(function (row) { return row.R; }) },
      { name: 'A', data: (workload || []).map(function (row) { return row.A; }) },
      { name: 'C', data: (workload || []).map(function (row) { return row.C; }) },
      { name: 'I', data: (workload || []).map(function (row) { return row.I; }) }
    ],
    legend: { position: 'top' },
    dataLabels: { enabled: false },
    grid: { xaxis: { lines: { show: false } } }
  });
  if (store[selector]) {
    store[selector].updateOptions(options, true, true);
  } else {
    el.innerHTML = '';
    store[selector] = new ApexCharts(el, options);
    store[selector].render();
  }
}

function updateKpi(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

function renderRaciMatrixAnalytics(data) {
  if (!data) return;
  const health = data.health || {};
  const coverage = data.coverage || {};
  const counts = data.counts || {};
  const gaps = data.gaps || {};
  const lang = window.raciAnalyticsLang || {};

  updateKpi('raci-kpi-health', (health.score || 0) + '%');
  updateKpi('raci-kpi-health-label', health.label || '');
  updateKpi('raci-kpi-fill', (coverage.fill_rate || 0) + '%');
  updateKpi('raci-kpi-a', (gaps.missing_accountable || []).length);
  updateKpi('raci-kpi-r', (gaps.missing_responsible || []).length);
  updateKpi('raci-kpi-overload', (gaps.overloaded || []).length);
  updateKpi('raci-kpi-tasks', counts.activities || 0);
  updateKpi('raci-kpi-people', counts.stakeholders || 0);
  updateKpi('raci-kpi-filled', counts.assignments || 0);
  updateKpi('raci-kpi-grade', health.grade || '-');

  const badge = document.getElementById('raci-health-badge');
  if (badge) {
    badge.className = 'badge bg-' + (health.color || 'secondary');
    badge.textContent = (health.score || 0) + '% · ' + (health.label || '');
  }

  renderRaciFindings('#raci-findings', data.findings);
  renderRaciWorkload('#raci-workload-body', data.workload);
  renderRaciHealthChart('#raci-health-chart', health.score || 0, health.band);
  renderRaciDonut('#raci-role-chart', ['R', 'A', 'C', 'I'], [
    data.role_counts.R || 0,
    data.role_counts.A || 0,
    data.role_counts.C || 0,
    data.role_counts.I || 0
  ], ['#28c76f', '#ea5455', '#00cfe8', '#82868b']);
  renderRaciWorkloadChart('#raci-workload-chart', data.workload);

  const coverEl = document.getElementById('raci-coverage-copy');
  if (coverEl) {
    coverEl.textContent = (lang.coverageCopy || '')
      .replace(':a', coverage.accountable_rate || 0)
      .replace(':r', coverage.responsible_rate || 0)
      .replace(':fill', coverage.fill_rate || 0);
  }
}

function renderRaciPortfolioCharts(portfolio) {
  if (!portfolio) return;
  renderRaciDonut('#raci-portfolio-health-chart', [
    window.raciAnalyticsLang.healthy,
    window.raciAnalyticsLang.watch,
    window.raciAnalyticsLang.critical
  ], [
    portfolio.bands.healthy || 0,
    portfolio.bands.watch || 0,
    portfolio.bands.critical || 0
  ], ['#28c76f', '#ff9f43', '#ea5455']);
  renderRaciDonut('#raci-portfolio-role-chart', ['R', 'A', 'C', 'I'], [
    portfolio.role_counts.R || 0,
    portfolio.role_counts.A || 0,
    portfolio.role_counts.C || 0,
    portfolio.role_counts.I || 0
  ], ['#28c76f', '#ea5455', '#00cfe8', '#82868b']);
  renderRaciDonut('#raci-portfolio-type-chart', [
    window.raciAnalyticsLang.job,
    window.raciAnalyticsLang.department,
    window.raciAnalyticsLang.user
  ], [
    portfolio.type_mix.job || 0,
    portfolio.type_mix.department || 0,
    portfolio.type_mix.user || 0
  ], ['#44225c', '#7367f0', '#00cfe8']);
}
