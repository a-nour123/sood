<?php

use App\Models\Permission;
use App\Models\PermissionGroup;
use App\Models\RoleResponsibility;
use App\Models\Subgroup;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('raci_matrices', function (Blueprint $table) {
            $table->id();
            $table->string('name', 150);
            $table->string('description', 1000)->nullable();
            $table->foreignId('department_id')->nullable()->constrained('departments')->nullOnDelete();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->timestamps();

            $table->foreign('created_by')->references('id')->on('users')->nullOnDelete();
        });

        Schema::create('raci_activities', function (Blueprint $table) {
            $table->id();
            $table->foreignId('matrix_id')->constrained('raci_matrices')->cascadeOnDelete();
            $table->string('name', 200);
            $table->string('description', 1000)->nullable();
            $table->unsignedInteger('sort_order')->default(0);
            $table->timestamps();
        });

        Schema::create('raci_stakeholders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('matrix_id')->constrained('raci_matrices')->cascadeOnDelete();
            $table->enum('stakeholder_type', ['job', 'department', 'user']);
            $table->unsignedBigInteger('stakeholder_id');
            $table->unsignedInteger('sort_order')->default(0);
            $table->timestamps();

            $table->unique(['matrix_id', 'stakeholder_type', 'stakeholder_id'], 'raci_stakeholders_unique');
        });

        Schema::create('raci_assignments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('activity_id')->constrained('raci_activities')->cascadeOnDelete();
            $table->foreignId('stakeholder_id')->constrained('raci_stakeholders')->cascadeOnDelete();
            $table->enum('role', ['R', 'A', 'C', 'I']);
            $table->timestamps();

            $table->unique(['activity_id', 'stakeholder_id'], 'raci_assignments_unique');
        });

        $this->seedPermissions();
    }

    public function down()
    {
        Schema::dropIfExists('raci_assignments');
        Schema::dropIfExists('raci_stakeholders');
        Schema::dropIfExists('raci_activities');
        Schema::dropIfExists('raci_matrices');
    }

    protected function seedPermissions(): void
    {
        $permissionGroups = PermissionGroup::pluck('id', 'name');
        $governanceId = $permissionGroups['Governance'] ?? null;
        if (!$governanceId) {
            return;
        }

        $subgroup = Subgroup::firstOrCreate(
            ['name' => 'RACI'],
            ['permission_group_id' => $governanceId]
        );

        foreach (['list', 'create', 'update', 'delete'] as $status) {
            $permission = Permission::firstOrCreate(
                ['key' => 'raci.' . $status],
                [
                    'name' => $status,
                    'subgroup_id' => $subgroup->id,
                ]
            );

            RoleResponsibility::firstOrCreate([
                'role_id' => 1,
                'permission_id' => $permission->id,
            ]);
        }
    }
};
