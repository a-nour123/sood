<?php

namespace Database\Seeders;

use App\Models\Permission;
use App\Models\PermissionGroup;
use App\Models\RoleResponsibility;
use App\Models\Subgroup;
use Illuminate\Database\Seeder;

class AddRaciPermissionSeeder extends Seeder
{
    public function run()
    {
        $permissionGroups = PermissionGroup::pluck('id', 'name');
        $governanceId = $permissionGroups['Governance'] ?? null;

        if (!$governanceId) {
            $this->command->error('Governance group not found.');
            return;
        }

        $subgroup = Subgroup::firstOrCreate(
            ['name' => 'RACI'],
            ['permission_group_id' => $governanceId]
        );

        foreach (['list', 'create', 'update', 'delete'] as $status) {
            $permission = Permission::firstOrCreate(
                ['key' => 'raci.' . $status],
                [
                    'name' => $status,
                    'subgroup_id' => $subgroup->id,
                ]
            );

            $roleIds = RoleResponsibility::where('permission_id', optional(Permission::where('key', 'hierarchy.list')->first())->id)
                ->pluck('role_id')
                ->unique()
                ->push(1)
                ->unique();

            foreach ($roleIds as $roleId) {
                RoleResponsibility::firstOrCreate([
                    'role_id' => $roleId,
                    'permission_id' => $permission->id,
                ]);
            }
        }

        $this->command->info('RACI permissions seeded successfully.');
    }
}
