<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up()
    {
        $batchSize = 100;

        // Process the records in chunks to avoid memory issues
        DB::table('framework_controls')
            ->where(function ($query) {
                $query->where('short_name', 'LIKE', '%OOSMACC%')
                      ->orWhere('long_name', 'LIKE', '%OOSMACC%')
                      ->orWhere('control_number', 'LIKE', '%OOSMACC%');
            })
            ->orderBy('id')
            ->chunkById($batchSize, function ($controls) {
                foreach ($controls as $control) {
                    $updateData = [];

                    // Replace in short_name
                    if (!empty($control->short_name) && str_contains($control->short_name, 'OOSMACC')) {
                        $updateData['short_name'] = str_replace('OOSMACC', 'OSMACC', $control->short_name);
                    }

                    // Replace in long_name
                    if (!empty($control->long_name) && str_contains($control->long_name, 'OOSMACC')) {
                        $updateData['long_name'] = str_replace('OOSMACC', 'OSMACC', $control->long_name);
                    }

                    // Replace in control_number
                    if (!empty($control->control_number) && str_contains($control->control_number, 'OOSMACC')) {
                        $updateData['control_number'] = str_replace('OOSMACC', 'OSMACC', $control->control_number);
                    }

                    // Update only if there are changes
                    if (!empty($updateData)) {
                        DB::table('framework_controls')
                            ->where('id', $control->id)
                            ->update($updateData);
                    }
                }
            });
    }

    public function down()
    {
        // Optional rollback: change OSMACC back to OOSMACC
        $batchSize = 100;

        DB::table('framework_controls')
            ->where(function ($query) {
                $query->where('short_name', 'LIKE', '%OSMACC%')
                      ->orWhere('long_name', 'LIKE', '%OSMACC%')
                      ->orWhere('control_number', 'LIKE', '%OSMACC%');
            })
            ->orderBy('id')
            ->chunkById($batchSize, function ($controls) {
                foreach ($controls as $control) {
                    $updateData = [];

                    if (!empty($control->short_name) && str_contains($control->short_name, 'OSMACC')) {
                        $updateData['short_name'] = str_replace('OSMACC', 'OOSMACC', $control->short_name);
                    }

                    if (!empty($control->long_name) && str_contains($control->long_name, 'OSMACC')) {
                        $updateData['long_name'] = str_replace('OSMACC', 'OOSMACC', $control->long_name);
                    }

                    if (!empty($control->control_number) && str_contains($control->control_number, 'OSMACC')) {
                        $updateData['control_number'] = str_replace('OSMACC', 'OOSMACC', $control->control_number);
                    }

                    if (!empty($updateData)) {
                        DB::table('framework_controls')
                            ->where('id', $control->id)
                            ->update($updateData);
                    }
                }
            });
    }
};