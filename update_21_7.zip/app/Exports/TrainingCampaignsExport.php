<?php

namespace App\Exports;

use App\Models\PhishingCampaign;
use App\Support\PhishingTrainingCampaignStats;
use Carbon\Carbon;
use Illuminate\Support\Facades\App;

class TrainingCampaignsExport extends BaseExportTemplate
{
    private array $filters;
    private bool $archived;
    private array $rows = [];

    public function __construct(array $filters = [], bool $archived = false, $locale = null)
    {
        $locale = $locale ?? App::getLocale();
        $this->filters = $filters;
        $this->archived = $archived;

        parent::__construct($locale, $this->getTitle(), $this->getDescription());

        foreach ($this->loadCampaigns() as $campaign) {
            $this->rows[] = $this->processCampaign($campaign);
        }
    }

    private function getDateRange(): array
    {
        $startDate = !empty($this->filters['start_date'])
            ? Carbon::parse($this->filters['start_date'])->startOfDay()
            : Carbon::now()->subYear()->startOfDay();

        $endDate = !empty($this->filters['end_date'])
            ? Carbon::parse($this->filters['end_date'])->endOfDay()
            : Carbon::now()->endOfDay();

        return [$startDate, $endDate];
    }

    private function getTitle(): string
    {
        return $this->archived
            ? __('phishing.Archived_Training_Campaigns')
            : __('phishing.Active_Training_Campaigns');
    }

    private function getDescription(): string
    {
        [$startDate, $endDate] = $this->getDateRange();

        return $this->archived
            ? __('phishing.Archived_Training_Campaigns_Report_Description', [
                'from' => $startDate->format('Y-m-d'),
                'to' => $endDate->format('Y-m-d'),
            ])
            : __('phishing.Active_Training_Campaigns_Report_Description', [
                'from' => $startDate->format('Y-m-d'),
                'to' => $endDate->format('Y-m-d'),
            ]);
    }

    private function loadCampaigns()
    {
        [$startDate, $endDate] = $this->getDateRange();

        $query = PhishingCampaign::query()
            ->whereIn('campaign_type', ['security_awareness', 'simulated_phishing_and_security_awareness'])
            ->whereBetween('created_at', [$startDate, $endDate])
            ->orderBy('created_at', 'desc');

        if ($this->archived) {
            $query->onlyTrashed();
        } else {
            $query->withoutTrashed();
        }

        return $query->get();
    }

    private function processCampaign(PhishingCampaign $campaign): object
    {
        $metrics = PhishingTrainingCampaignStats::metrics($campaign);

        return (object) [
            'campaign_name' => $campaign->campaign_name,
            'status' => PhishingTrainingCampaignStats::statusLabel($campaign),
            'campaign_type' => PhishingTrainingCampaignStats::campaignTypeLabel($campaign),
            'schedule_date' => PhishingTrainingCampaignStats::scheduleDate($campaign),
            'employee_count' => $metrics['employee_count'],
            'assigned' => $metrics['assigned'],
            'passed' => $metrics['passed'],
            'failed' => $metrics['failed'],
            'passed_after_overdue' => $metrics['passed_after_overdue'],
            'overdue' => $metrics['overdue'],
        ];
    }

    public function collection()
    {
        return collect($this->rows);
    }

    public function map($row): array
    {
        return [
            $this->getCounter(),
            $row->campaign_name,
            $row->status,
            $row->campaign_type,
            $row->schedule_date,
            $row->employee_count,
            $row->assigned,
            $row->passed,
            $row->failed,
            $row->passed_after_overdue,
            $row->overdue,
        ];
    }

    public function headings(): array
    {
        return [
            '#',
            __('phishing.CAMPAIGN_NAME'),
            __('phishing.STATUS'),
            __('phishing.campaign_type'),
            __('phishing.SCHEDULED_DATE'),
            __('phishing.EMPLOYEE_COUNT'),
            __('phishing.ASSSIGNED'),
            __('phishing.PASSED'),
            __('phishing.FAILED'),
            __('phishing.PASSED_AFTER_OVERDUE'),
            __('phishing.OVERDUE'),
        ];
    }

    public function columnWidths(): array
    {
        return [
            'A' => 6,
            'B' => 35,
            'C' => 18,
            'D' => 22,
            'E' => 22,
            'F' => 18,
            'G' => 16,
            'H' => 14,
            'I' => 14,
            'J' => 22,
            'K' => 16,
        ];
    }
}
