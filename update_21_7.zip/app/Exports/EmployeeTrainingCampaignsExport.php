<?php

namespace App\Exports;

use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\App;

class EmployeeTrainingCampaignsExport extends BaseExportTemplate
{
    private int $employeeId;
    private ?User $employee = null;
    private array $rows = [];

    public function __construct(int $employeeId, $locale = null)
    {
        $locale = $locale ?? App::getLocale();
        $this->employeeId = $employeeId;
        $this->employee = User::findOrFail($employeeId);

        parent::__construct($locale, $this->getTitle(), $this->getDescription());

        foreach ($this->loadAssignments() as $assignment) {
            $this->rows[] = $assignment;
        }
    }

    private function getTitle(): string
    {
        return __('phishing.Employee_Training_Campaigns');
    }

    private function getDescription(): string
    {
        return __('phishing.Employee_Training_Campaigns_Report_Description', [
            'employee' => $this->employee->name ?? $this->employeeId,
        ]);
    }

    private function loadAssignments()
    {
        $user = User::with([
            'campaigns.trainingModules' => function ($query) {
                $query->whereHas('users', function ($subQuery) {
                    $subQuery->where('user_id', $this->employeeId);
                })->with(['users' => function ($q) {
                    $q->where('users.id', $this->employeeId);
                }]);
            },
        ])->findOrFail($this->employeeId);

        return $user->campaigns->flatMap(function ($campaign) {
            return $campaign->trainingModules->map(function ($trainingModule) use ($campaign) {
                $userOnModule = $trainingModule->users->firstWhere('id', $this->employeeId);
                if (!$userOnModule) {
                    return null;
                }

                $pivot = $userOnModule->pivot;
                $passed = (int) $pivot->passed;
                $daysUntilDue = $pivot->days_until_due;
                $dateAssigned = $pivot->created_at;

                $overdue = 'Not Overdue';
                if ($daysUntilDue !== null) {
                    $today = Carbon::today()->startOfDay();
                    $assignedDate = Carbon::parse($dateAssigned)->startOfDay();
                    $dueDate = $assignedDate->copy()->addDays((int) $daysUntilDue)->startOfDay();
                    $overdue = ($today->gt($dueDate) && !$passed) ? 'Overdue' : 'Not Overdue';
                }

                return (object) [
                    'campaign_name' => $campaign->campaign_name,
                    'training_name' => $trainingModule->name,
                    'score' => $pivot->score . '%',
                    'completed' => $pivot->completed_at ? 'Yes' : 'No',
                    'overdue' => $overdue,
                    'passed' => $passed ? 'Passed' : 'Not Passed',
                ];
            })->filter();
        })->values();
    }

    public function collection()
    {
        return collect($this->rows);
    }

    public function map($row): array
    {
        return [
            $this->getCounter(),
            $row->campaign_name,
            $row->training_name,
            $row->score,
            $row->completed,
            $row->overdue,
            $row->passed,
        ];
    }

    public function headings(): array
    {
        return [
            '#',
            __('phishing.CAMPAIGN_NAME'),
            __('phishing.Training_Name'),
            __('phishing.Score'),
            __('phishing.COMPLETED'),
            __('phishing.OVERDUE'),
            __('phishing.PASSED'),
        ];
    }

    public function columnWidths(): array
    {
        return [
            'A' => 6,
            'B' => 35,
            'C' => 30,
            'D' => 12,
            'E' => 14,
            'F' => 16,
            'G' => 14,
        ];
    }
}
