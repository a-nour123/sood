<?php

namespace App\Exports;

use App\Models\PhishingCampaign;
use Carbon\Carbon;
use Illuminate\Support\Facades\App;

class ActivePhishingCampaignsExport extends BaseExportTemplate
{
    private array $filters;
    private array $rows = [];

    public function __construct(array $filters = [], $locale = null)
    {
        $locale = $locale ?? App::getLocale();
        $this->filters = $filters;

        parent::__construct($locale, $this->getTitle(), $this->getDescription());

        foreach ($this->loadCampaigns() as $campaign) {
            $this->rows[] = $this->processCampaign($campaign);
        }
    }

    private function getDateRange(): array
    {
        $startDate = !empty($this->filters['start_date'])
            ? Carbon::parse($this->filters['start_date'])->startOfDay()
            : Carbon::now()->subYear()->startOfDay();

        $endDate = !empty($this->filters['end_date'])
            ? Carbon::parse($this->filters['end_date'])->endOfDay()
            : Carbon::now()->endOfDay();

        return [$startDate, $endDate];
    }

    private function getTitle(): string
    {
        return __('phishing.Active_Campaigns');
    }

    private function getDescription(): string
    {
        [$startDate, $endDate] = $this->getDateRange();

        return __('phishing.Active_Campaigns_Report_Description', [
            'from' => $startDate->format('Y-m-d'),
            'to' => $endDate->format('Y-m-d'),
        ]);
    }

    private function loadCampaigns()
    {
        [$startDate, $endDate] = $this->getDateRange();

        return PhishingCampaign::withoutTrashed()
            ->where('campaign_type', 'simulated_phishing')
            ->whereBetween('created_at', [$startDate, $endDate])
            ->get()
            ->map(function ($campaign) {
                $employeeIds = \Illuminate\Support\Facades\DB::table('phishing_campaign_employee_list')
                    ->where('campaign_id', $campaign->id)
                    ->pluck('employee_id');

                $pivotDeliveredIds = \Illuminate\Support\Facades\DB::table('phishing_campaign_employee_list')
                    ->where('campaign_id', $campaign->id)
                    ->where('is_delivered', 1)
                    ->pluck('employee_id');

                $trackingEmployeeIds = \Illuminate\Support\Facades\DB::table('phishing_mail_trackings')
                    ->where('campaign_id', $campaign->id)
                    ->whereIn('employee_id', $employeeIds)
                    ->distinct()
                    ->pluck('employee_id');

                $campaign->delivered_count = $pivotDeliveredIds->merge($trackingEmployeeIds)->unique()->count();

                $campaign->opend_count = \Illuminate\Support\Facades\DB::table('phishing_mail_trackings')
                    ->where('campaign_id', $campaign->id)
                    ->whereIn('employee_id', $employeeIds)
                    ->whereNotNull('opened_at')
                    ->count();

                $campaign->clicked_count = \Illuminate\Support\Facades\DB::table('phishing_mail_trackings')
                    ->where('campaign_id', $campaign->id)
                    ->whereIn('employee_id', $employeeIds)
                    ->whereNotNull('Page_link_clicked_at')
                    ->count();

                $campaign->downloaded_count = \Illuminate\Support\Facades\DB::table('phishing_mail_trackings')
                    ->where('campaign_id', $campaign->id)
                    ->whereIn('employee_id', $employeeIds)
                    ->whereNotNull('downloaded_at')
                    ->count();

                $campaign->submited_count = \Illuminate\Support\Facades\DB::table('phishing_mail_trackings')
                    ->where('campaign_id', $campaign->id)
                    ->whereIn('employee_id', $employeeIds)
                    ->whereNotNull('submited_at')
                    ->count();

                return $campaign;
            });
    }

    private function processCampaign($campaign): object
    {
        $scheduleDate = $campaign->schedule_date_from
            ? Carbon::parse($campaign->schedule_date_from . ' ' . ($campaign->schedule_time_from ?? '00:00:00'))->format('Y-m-d g:ia')
            : Carbon::parse($campaign->created_at)->format('Y-m-d g:ia');

        return (object) [
            'campaign_name' => $campaign->campaign_name,
            'status' => $campaign->approve == 1 ? __('locale.Approve') : __('locale.Pending'),
            'campaign_type' => __('locale.Phishing'),
            'schedule_date' => $scheduleDate,
            'delivered_count' => $campaign->delivered_count ?? 0,
            'opened_count' => $campaign->opend_count ?? 0,
            'clicked_count' => $campaign->clicked_count ?? 0,
            'downloaded_count' => $campaign->downloaded_count ?? 0,
            'submitted_count' => $campaign->submited_count ?? 0,
        ];
    }

    public function collection()
    {
        return collect($this->rows);
    }

    public function map($row): array
    {
        return [
            $this->getCounter(),
            $row->campaign_name,
            $row->status,
            $row->campaign_type,
            $row->schedule_date,
            $row->delivered_count,
            $row->opened_count,
            $row->clicked_count,
            $row->downloaded_count,
            $row->submitted_count,
        ];
    }

    public function headings(): array
    {
        return [
            '#',
            __('phishing.CAMPAIGN_NAME'),
            __('phishing.STATUS'),
            __('phishing.campaign_type'),
            __('phishing.SCEDULE_DATE'),
            __('phishing.EMAIL_DELIVERED'),
            __('phishing.EMAIL_OPENED'),
            __('phishing.Clicked_Link'),
            __('phishing.EMAIL_DOWNLOAD_FILE'),
            __('phishing.EMAIL_SUBMIT_DATA'),
        ];
    }

    public function columnWidths(): array
    {
        return [
            'A' => 6,
            'B' => 35,
            'C' => 18,
            'D' => 18,
            'E' => 22,
            'F' => 18,
            'G' => 18,
            'H' => 16,
            'I' => 22,
            'J' => 22,
        ];
    }
}
