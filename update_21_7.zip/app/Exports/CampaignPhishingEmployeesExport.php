<?php

namespace App\Exports;

use App\Models\PhishingCampaign;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\DB;

class CampaignPhishingEmployeesExport extends BaseExportTemplate
{
    private int $campaignId;
    private ?PhishingCampaign $campaign = null;
    private array $rows = [];

    public function __construct(int $campaignId, $locale = null)
    {
        $locale = $locale ?? App::getLocale();
        $this->campaignId = $campaignId;
        $this->campaign = PhishingCampaign::withTrashed()->findOrFail($campaignId);

        parent::__construct($locale, $this->getTitle(), $this->getDescription());

        foreach ($this->loadEmployees() as $employee) {
            $this->rows[] = $employee;
        }
    }

    private function getTitle(): string
    {
        return __('phishing.Campaign_Employees');
    }

    private function getDescription(): string
    {
        return __('phishing.Campaign_Employees_Report_Description', [
            'campaign' => $this->campaign->campaign_name ?? $this->campaignId,
        ]);
    }

    private function loadEmployees()
    {
        $campaign = PhishingCampaign::withTrashed()
            ->with('employees')
            ->findOrFail($this->campaignId);

        return $campaign->employees->map(function ($employee) {
            $base = [
                'campaign_id' => $this->campaignId,
                'employee_id' => $employee->id,
            ];

            $opened = DB::table('phishing_mail_trackings')->where($base)->whereNotNull('opened_at')->count();
            $clicked = DB::table('phishing_mail_trackings')->where($base)->whereNotNull('Page_link_clicked_at')->count();
            $downloaded = DB::table('phishing_mail_trackings')->where($base)->whereNotNull('downloaded_at')->count();
            $submitted = DB::table('phishing_mail_trackings')->where($base)->whereNotNull('submited_at')->count();
            $hasTracking = DB::table('phishing_mail_trackings')->where($base)->exists();

            $pivotDelivered = DB::table('phishing_campaign_employee_list')
                ->where('campaign_id', $this->campaignId)
                ->where('employee_id', $employee->id)
                ->where('is_delivered', 1)
                ->exists();

            return (object) [
                'name' => $employee->name,
                'email' => $employee->email,
                'delivered' => ($pivotDelivered || $hasTracking) ? 'Yes' : 'No',
                'count_of_opened' => $opened,
                'count_of_clik' => $clicked,
                'count_of_downloaded' => $downloaded,
                'count_of_submited' => $submitted,
            ];
        });
    }

    public function collection()
    {
        return collect($this->rows);
    }

    public function map($row): array
    {
        return [
            $this->getCounter(),
            $row->name,
            $row->email,
            $row->delivered,
            $row->count_of_opened,
            $row->count_of_clik,
            $row->count_of_downloaded,
            $row->count_of_submited,
        ];
    }

    public function headings(): array
    {
        return [
            '#',
            __('phishing.Name'),
            __('phishing.Email'),
            __('phishing.Email_Delivered'),
            __('phishing.Email_Opened'),
            __('phishing.Clicked_Link'),
            __('phishing.Email_Download_File'),
            __('phishing.Email_Submit_Data'),
        ];
    }

    public function columnWidths(): array
    {
        return [
            'A' => 6,
            'B' => 25,
            'C' => 30,
            'D' => 16,
            'E' => 14,
            'F' => 14,
            'G' => 18,
            'H' => 18,
        ];
    }
}
