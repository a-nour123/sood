<?php

namespace App\Exports;

use Carbon\Carbon;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\DB;

class PhishedEmployeesExport extends BaseExportTemplate
{
    private array $filters;
    private array $rows = [];

    public function __construct(array $filters = [], $locale = null)
    {
        $locale = $locale ?? App::getLocale();
        $this->filters = $filters;

        parent::__construct($locale, $this->getTitle(), $this->getDescription());

        foreach ($this->loadEmployees() as $employee) {
            $this->rows[] = (object) [
                'employee_id' => $employee->employee_id,
                'email' => $employee->email,
                'name' => $employee->name,
                'average_percentage' => $employee->average_percentage,
            ];
        }
    }

    private function getDateRange(): array
    {
        $startDate = !empty($this->filters['start_date'])
            ? Carbon::parse($this->filters['start_date'])->startOfDay()
            : Carbon::now()->subYear()->startOfDay();

        $endDate = !empty($this->filters['end_date'])
            ? Carbon::parse($this->filters['end_date'])->endOfDay()
            : Carbon::now()->endOfDay();

        return [$startDate, $endDate];
    }

    private function getTitle(): string
    {
        return __('phishing.Employee_Statistics');
    }

    private function getDescription(): string
    {
        [$startDate, $endDate] = $this->getDateRange();

        return __('phishing.Employee_Statistics_Report_Description', [
            'from' => $startDate->format('Y-m-d'),
            'to' => $endDate->format('Y-m-d'),
        ]);
    }

    private function loadEmployees()
    {
        [$startDate, $endDate] = $this->getDateRange();

        return DB::table('phishing_mail_trackings')
            ->join('users', 'phishing_mail_trackings.employee_id', '=', 'users.id')
            ->whereBetween('phishing_mail_trackings.created_at', [$startDate, $endDate])
            ->select(
                'phishing_mail_trackings.employee_id',
                'users.name',
                'users.email',
                DB::raw('
                    COUNT(*) as total_rows,
                    SUM(
                        CASE
                            WHEN opened_at IS NOT NULL AND submited_at IS NOT NULL AND downloaded_at IS NOT NULL AND Page_link_clicked_at IS NOT NULL THEN 100
                            ELSE
                                (CASE WHEN opened_at IS NOT NULL THEN 25 ELSE 0 END) +
                                (CASE WHEN submited_at IS NOT NULL THEN 25 ELSE 0 END) +
                                (CASE WHEN Page_link_clicked_at IS NOT NULL THEN 25 ELSE 0 END) +
                                (CASE WHEN downloaded_at IS NOT NULL THEN 25 ELSE 0 END)
                        END
                    ) AS total_points
                ')
            )
            ->groupBy('phishing_mail_trackings.employee_id', 'users.name', 'users.email')
            ->orderByDesc('total_points')
            ->get()
            ->map(function ($employee) {
                $maxPossiblePoints = $employee->total_rows * 100;
                $employee->average_percentage = number_format(($employee->total_points / $maxPossiblePoints) * 100, 2);

                return $employee;
            })
            ->sortByDesc('average_percentage')
            ->values();
    }

    public function collection()
    {
        return collect($this->rows);
    }

    public function map($row): array
    {
        return [
            $this->getCounter(),
            $row->employee_id,
            $row->email,
            $row->name,
            $row->average_percentage,
        ];
    }

    public function headings(): array
    {
        return [
            '#',
            __('phishing.ID'),
            __('phishing.email'),
            __('phishing.name'),
            __('phishing.RISK_SCORE'),
        ];
    }

    public function columnWidths(): array
    {
        return [
            'A' => 6,
            'B' => 10,
            'C' => 30,
            'D' => 25,
            'E' => 18,
        ];
    }
}
