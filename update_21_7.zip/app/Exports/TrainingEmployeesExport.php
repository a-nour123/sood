<?php

namespace App\Exports;

use Carbon\Carbon;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\DB;

class TrainingEmployeesExport extends BaseExportTemplate
{
    private array $filters;
    private array $rows = [];

    public function __construct(array $filters = [], $locale = null)
    {
        $locale = $locale ?? App::getLocale();
        $this->filters = $filters;

        parent::__construct($locale, $this->getTitle(), $this->getDescription());

        foreach ($this->loadEmployees() as $employee) {
            $this->rows[] = (object) [
                'user_id' => $employee->user_id,
                'email' => $employee->email,
                'name' => $employee->name,
            ];
        }
    }

    private function getDateRange(): array
    {
        $startDate = !empty($this->filters['start_date'])
            ? Carbon::parse($this->filters['start_date'])->startOfDay()
            : Carbon::now()->subYear()->startOfDay();

        $endDate = !empty($this->filters['end_date'])
            ? Carbon::parse($this->filters['end_date'])->endOfDay()
            : Carbon::now()->endOfDay();

        return [$startDate, $endDate];
    }

    private function getTitle(): string
    {
        return __('phishing.Training_Employee_Statistic');
    }

    private function getDescription(): string
    {
        [$startDate, $endDate] = $this->getDateRange();

        return __('phishing.Training_Employees_Report_Description', [
            'from' => $startDate->format('Y-m-d'),
            'to' => $endDate->format('Y-m-d'),
        ]);
    }

    private function loadEmployees()
    {
        [$startDate, $endDate] = $this->getDateRange();

        return DB::table('l_m_s_user_training_modules')
            ->join('users', 'l_m_s_user_training_modules.user_id', '=', 'users.id')
            ->whereBetween('l_m_s_user_training_modules.created_at', [$startDate, $endDate])
            ->select(
                'l_m_s_user_training_modules.user_id',
                'users.name',
                'users.email',
            )
            ->groupBy('l_m_s_user_training_modules.user_id', 'users.name', 'users.email')
            ->orderBy('users.name')
            ->get();
    }

    public function collection()
    {
        return collect($this->rows);
    }

    public function map($row): array
    {
        return [
            $this->getCounter(),
            $row->user_id,
            $row->email,
            $row->name,
        ];
    }

    public function headings(): array
    {
        return [
            '#',
            __('phishing.ID'),
            __('phishing.email'),
            __('phishing.name'),
        ];
    }

    public function columnWidths(): array
    {
        return [
            'A' => 6,
            'B' => 10,
            'C' => 30,
            'D' => 25,
        ];
    }
}
