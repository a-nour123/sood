<?php

namespace App\Exports;

use App\Models\LMSTrainingModule;
use App\Models\PhishingCampaign;
use Carbon\Carbon;
use Illuminate\Support\Facades\App;

class CampaignTrainingEmployeesExport extends BaseExportTemplate
{
    private int $campaignId;
    private ?PhishingCampaign $campaign = null;
    private array $rows = [];

    public function __construct(int $campaignId, $locale = null)
    {
        $locale = $locale ?? App::getLocale();
        $this->campaignId = $campaignId;
        $this->campaign = PhishingCampaign::withTrashed()->findOrFail($campaignId);

        parent::__construct($locale, $this->getTitle(), $this->getDescription());

        foreach ($this->loadEmployees() as $employee) {
            $this->rows[] = $employee;
        }
    }

    private function getTitle(): string
    {
        return __('phishing.Campaign_Employees');
    }

    private function getDescription(): string
    {
        return __('phishing.Campaign_Employees_Report_Description', [
            'campaign' => $this->campaign->campaign_name ?? $this->campaignId,
        ]);
    }

    private function loadEmployees()
    {
        $campaign = PhishingCampaign::withTrashed()
            ->with([
                'userTraining' => function ($query) {
                    $query->withPivot(
                        'score',
                        'passed',
                        'created_at',
                        'completed_at',
                        'days_until_due',
                        'training_module_id',
                        'count_of_entering_exam'
                    );
                },
            ])
            ->findOrFail($this->campaignId);

        return $campaign->userTraining->map(function ($userTraining) {
            $pivot = $userTraining->pivot;
            $daysUntilDue = $pivot->days_until_due;
            $passed = (int) $pivot->passed;
            $completedAt = $pivot->completed_at;
            $dateAssigned = $pivot->created_at;
            $examCount = (int) ($pivot->count_of_entering_exam ?? 0);

            if ($examCount > 0 && $passed === 0) {
                $failedLabel = 'Failed';
            } elseif ($passed === 1) {
                $failedLabel = 'Passed';
            } else {
                $failedLabel = 'Not Attempted';
            }

            $passedAfterOverdue = 'No';
            if ($daysUntilDue !== null && $passed === 1 && $completedAt !== null) {
                $assignedDate = Carbon::parse($dateAssigned)->startOfDay();
                $dueDate = $assignedDate->copy()->addDays((int) $daysUntilDue)->startOfDay();
                $completed = Carbon::parse($completedAt)->startOfDay();
                $passedAfterOverdue = $completed->gt($dueDate) ? 'Yes' : 'No';
            }

            $overdue = 'Not Overdue';
            if ($daysUntilDue !== null) {
                $today = Carbon::today()->startOfDay();
                $assignedDate = Carbon::parse($dateAssigned)->startOfDay();
                $dueDate = $assignedDate->copy()->addDays((int) $daysUntilDue)->startOfDay();

                if ($passed === 1 && $completedAt !== null) {
                    $completed = Carbon::parse($completedAt)->startOfDay();
                    $overdue = $completed->gt($dueDate) ? 'Was Overdue' : 'Not Overdue';
                } else {
                    $overdue = $today->gt($dueDate) ? 'Overdue' : 'Not Overdue';
                }
            }

            return (object) [
                'user_email' => $userTraining->email,
                'user_name' => $userTraining->name,
                'training_name' => LMSTrainingModule::find($pivot->training_module_id)->name ?? '-',
                'date_assigned' => $dateAssigned,
                'days_until_due' => $daysUntilDue ?? 'N/A',
                'score' => $pivot->score . '%',
                'passed' => $passed ? 'Passed' : 'Not Passed',
                'failed' => $failedLabel,
                'passed_after_overdue' => $passedAfterOverdue,
                'overdue' => $overdue,
            ];
        });
    }

    public function collection()
    {
        return collect($this->rows);
    }

    public function map($row): array
    {
        return [
            $this->getCounter(),
            $row->user_email,
            $row->user_name,
            $row->training_name,
            $row->date_assigned,
            $row->days_until_due,
            $row->score,
            $row->passed,
            $row->failed,
            $row->passed_after_overdue,
            $row->overdue,
        ];
    }

    public function headings(): array
    {
        return [
            '#',
            __('phishing.Email'),
            __('phishing.Name'),
            __('phishing.Training_Name'),
            __('phishing.Date_Assigned'),
            __('phishing.Days_Until_Due'),
            __('phishing.Score'),
            __('phishing.PASSED'),
            __('phishing.FAILED'),
            __('phishing.PASSED_AFTER_OVERDUE'),
            __('phishing.OVERDUE'),
        ];
    }

    public function columnWidths(): array
    {
        return [
            'A' => 6,
            'B' => 30,
            'C' => 25,
            'D' => 30,
            'E' => 22,
            'F' => 18,
            'G' => 12,
            'H' => 14,
            'I' => 16,
            'J' => 22,
            'K' => 16,
        ];
    }
}
