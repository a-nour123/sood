<?php

namespace App\Http\Controllers\admin\phishing;

use App\Exports\ActivePhishingCampaignsExport;
use App\Exports\CampaignPhishingEmployeesExport;
use App\Exports\CampaignTrainingEmployeesExport;
use App\Exports\EmployeeTrainingCampaignsExport;
use App\Exports\PhishedEmployeesExport;
use App\Exports\TrainingCampaignsExport;
use App\Exports\TrainingEmployeesExport;
use App\Http\Controllers\Controller;
use App\Interfaces\Admin\Phishing\PhishingDashboardInterface;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;

class PhishingDashboardController extends Controller
{
    protected $PhishingDashboardInterface;

    public function __construct(PhishingDashboardInterface $PhishingDashboardInterface)
    {
        $this->PhishingDashboardInterface = $PhishingDashboardInterface;
    }
    public function index()
    {
        return $this->PhishingDashboardInterface->index();
    }

    public function reporting(Request $request)
    {
        return $this->PhishingDashboardInterface->reporting($request);
    }

    public function trainingReporting(Request $request)
    {
        return $this->PhishingDashboardInterface->trainingReporting($request);
    }

    public function cisoTrainingReport(Request $request)
    {
        return $this->PhishingDashboardInterface->cisoTrainingReport($request);
    }

    public function cisoPhishingReport(Request $request)
    {
        return $this->PhishingDashboardInterface->cisoPhishingReport($request);
    }

    public function awarenessTeamReport(Request $request)
    {
        return $this->PhishingDashboardInterface->awarenessTeamReport($request);
    }

    public function exportActiveCampaigns(Request $request)
    {
        $filters = $request->only(['start_date', 'end_date']);

        return Excel::download(
            new ActivePhishingCampaignsExport($filters),
            'active-phishing-campaigns.xlsx'
        );
    }

    public function exportPhishedEmployees(Request $request)
    {
        $filters = $request->only(['start_date', 'end_date']);

        return Excel::download(
            new PhishedEmployeesExport($filters),
            'phished-employees.xlsx'
        );
    }

    public function exportCampaignPhishingEmployees($id)
    {
        return Excel::download(
            new CampaignPhishingEmployeesExport((int) $id),
            'campaign-phishing-employees-' . $id . '.xlsx'
        );
    }

    public function exportActiveTrainingCampaigns(Request $request)
    {
        $filters = $request->only(['start_date', 'end_date']);

        return Excel::download(
            new TrainingCampaignsExport($filters, false),
            'active-training-campaigns.xlsx'
        );
    }

    public function exportArchivedTrainingCampaigns(Request $request)
    {
        $filters = $request->only(['start_date', 'end_date']);

        return Excel::download(
            new TrainingCampaignsExport($filters, true),
            'archived-training-campaigns.xlsx'
        );
    }

    public function exportTrainingEmployees(Request $request)
    {
        $filters = $request->only(['start_date', 'end_date']);

        return Excel::download(
            new TrainingEmployeesExport($filters),
            'training-employees.xlsx'
        );
    }

    public function exportCampaignTrainingEmployees($id)
    {
        return Excel::download(
            new CampaignTrainingEmployeesExport((int) $id),
            'campaign-training-employees-' . $id . '.xlsx'
        );
    }

    public function exportEmployeeTrainingCampaigns($id)
    {
        return Excel::download(
            new EmployeeTrainingCampaignsExport((int) $id),
            'employee-training-campaigns-' . $id . '.xlsx'
        );
    }
}
