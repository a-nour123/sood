<?php

namespace App\Support;

use App\Models\LMSUserTrainingModule;
use App\Models\PhishingCampaign;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;

class PhishingTrainingCampaignStats
{
    public static function assignmentsQuery(PhishingCampaign $campaign): Builder
    {
        $moduleIds = $campaign->trainingModules()->pluck('l_m_s_training_modules.id');
        $employeeIds = $campaign->employees()->pluck('users.id');

        return LMSUserTrainingModule::query()
            ->where(function ($query) use ($campaign, $moduleIds, $employeeIds) {
                $query->where('campaign_id', $campaign->id);

                if ($moduleIds->isNotEmpty()) {
                    $query->orWhere(function ($legacy) use ($moduleIds, $employeeIds) {
                        $legacy->whereNull('campaign_id')
                            ->whereIn('training_module_id', $moduleIds);

                        if ($employeeIds->isNotEmpty()) {
                            $legacy->whereIn('user_id', $employeeIds);
                        }
                    });
                }
            });
    }

    public static function assignments(PhishingCampaign $campaign): Collection
    {
        return self::assignmentsQuery($campaign)->get();
    }

    public static function employeeCount(PhishingCampaign $campaign): int
    {
        return self::assignmentsQuery($campaign)->count();
    }

    public static function assigned(PhishingCampaign $campaign): int
    {
        return (int) self::assignmentsQuery($campaign)->distinct('user_id')->count('user_id');
    }

    public static function passed(PhishingCampaign $campaign): int
    {
        return self::assignmentsQuery($campaign)->where('passed', 1)->count();
    }

    public static function failed(PhishingCampaign $campaign): int
    {
        return self::assignmentsQuery($campaign)
            ->where('passed', 0)
            ->where('count_of_entering_exam', '>', 0)
            ->count();
    }

    public static function passedAfterOverdue(PhishingCampaign $campaign): int
    {
        return self::assignments($campaign)->filter(function ($assignment) {
            if ((int) $assignment->passed !== 1 || $assignment->days_until_due === null) {
                return false;
            }

            $assignedDate = Carbon::parse($assignment->created_at)->startOfDay();
            $dueDate = $assignedDate->copy()->addDays((int) $assignment->days_until_due)->startOfDay();
            $completedAt = $assignment->completed_at
                ? Carbon::parse($assignment->completed_at)->startOfDay()
                : null;

            return $completedAt && $completedAt->gt($dueDate);
        })->count();
    }

    public static function overdue(PhishingCampaign $campaign): int
    {
        $today = Carbon::today()->startOfDay();

        return self::assignments($campaign)->filter(function ($assignment) use ($today) {
            if ((int) $assignment->passed === 1 || $assignment->days_until_due === null) {
                return false;
            }

            $assignedDate = Carbon::parse($assignment->created_at)->startOfDay();
            $dueDate = $assignedDate->copy()->addDays((int) $assignment->days_until_due)->startOfDay();

            return $today->gt($dueDate);
        })->count();
    }

    public static function campaignTypeLabel(PhishingCampaign $campaign): string
    {
        return $campaign->campaign_type === 'security_awareness' ? 'Training' : 'Phishing + Training';
    }

    public static function statusLabel(PhishingCampaign $campaign): string
    {
        return $campaign->approve == 1 ? __('locale.Approve') : __('locale.Pending');
    }

    public static function scheduleDate(PhishingCampaign $campaign): string
    {
        if ($campaign->schedule_date_from) {
            return Carbon::parse($campaign->schedule_date_from . ' ' . ($campaign->schedule_time_from ?? '00:00:00'))->format('Y-m-d g:ia');
        }

        return Carbon::parse($campaign->created_at)->format('Y-m-d g:ia');
    }

    public static function metrics(PhishingCampaign $campaign): array
    {
        return [
            'employee_count' => self::employeeCount($campaign),
            'assigned' => self::assigned($campaign),
            'passed' => self::passed($campaign),
            'failed' => self::failed($campaign),
            'passed_after_overdue' => self::passedAfterOverdue($campaign),
            'overdue' => self::overdue($campaign),
        ];
    }
}
