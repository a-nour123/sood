<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithColumnWidths;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithDrawings;
use Maatwebsite\Excel\Events\AfterSheet;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Font;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;
use App\Models\AuditResponsible;
use App\Models\FrameworkControlTestAudit;
use Carbon\Carbon;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Storage;

class RequirementDetailsComplianceExport implements FromArray, WithStyles, WithColumnWidths, WithEvents, WithDrawings
{
    protected $frameworkId;
    protected $auditId;
    protected $auditData;
    protected $companyName;
    protected $currentRow = 1;
    protected $totalRows = 0;
    protected $drawings = [];
    protected $imagePositions = [];
    protected $isRTL = false;
    protected $testNumber = 'N/A';
    protected $statistics = [];

    // Row tracking for precise styling
    protected $mainTitleRow     = 1;
    protected $logoRow          = 2;
    protected $auditInfoRows    = [];
    protected $summaryTitleRow  = 0;
    protected $summaryDataRows  = [];
    protected $controlTitleRow  = 0;

    public function __construct($frameworkId, $auditId, $companyName = "King Saud University")
    {
        $this->frameworkId = $frameworkId;
        $this->auditId     = $auditId;
        $this->companyName = $companyName;

        $this->isRTL = App::getLocale() == 'ar';

        $this->prepareData();
        $this->calculateStatistics();
    }

    // -------------------------------------------------------------------------
    // Data preparation
    // -------------------------------------------------------------------------

    protected function prepareData()
    {
        $this->auditData = AuditResponsible::with([
            'frameworkaduit',
            'owner',
            'frameworkControlTestAudits' => function ($query) {
                $query->with([
                    'frameworkControl',
                    'frameworkControl.Family',
                    'controlAuditEvidences' => function ($q) {
                        $q->with(['evidence.creator']);
                    },
                    'FrameworkControlTestResult.testResult',
                    'UserTester',
                ]);
            },
        ])
            ->where('framework_id', $this->frameworkId)
            ->where('id', $this->auditId)
            ->first();

        if (!$this->auditData) {
            return;
        }

        $firstAudit = $this->auditData->frameworkControlTestAudits->first();
        if ($firstAudit) {
            $testNumberArray  = json_decode($firstAudit->test_number, true);
            $this->testNumber = $testNumberArray[0] ?? 'N/A';
        }
    }

    protected function calculateStatistics()
    {
        $totalControls    = 0;
        $totalEvidence    = 0;
        $approvedEvidence = 0;
        $rejectedEvidence = 0;
        $noActionEvidence = 0;

        foreach ($this->auditData->frameworkControlTestAudits as $testAudit) {
            $totalControls++;

            foreach ($testAudit->controlAuditEvidences as $evidence) {
                $totalEvidence++;
                $status = $evidence->evidence_audit_status ?? 'no_action';

                switch ($status) {
                    case 'approved':
                        $approvedEvidence++;
                        break;
                    case 'rejected':
                        $rejectedEvidence++;
                        break;
                    default:
                        $noActionEvidence++;
                        break;
                }
            }
        }

        $complianceRate = $totalEvidence > 0
            ? round(($approvedEvidence / $totalEvidence) * 100, 2)
            : 0;

        $this->statistics = [
            'total_controls'    => $totalControls,
            'total_evidence'    => $totalEvidence,
            'approved_evidence' => $approvedEvidence,
            'rejected_evidence' => $rejectedEvidence,
            'no_action_evidence'=> $noActionEvidence,
            'compliance_rate'   => $complianceRate,
        ];
    }

    // -------------------------------------------------------------------------
    // Drawings (evidence images only – logo is added inside AfterSheet)
    // -------------------------------------------------------------------------

    public function drawings()
    {
        // Only return evidence image drawings here.
        // The logo drawing is added directly to the sheet in AfterSheet so we
        // can call setWorksheet() and avoid duplicate-drawing issues.
        return $this->drawings;
    }

    // -------------------------------------------------------------------------
    // Array – build row data and track row numbers for styling
    // -------------------------------------------------------------------------

    public function array(): array
    {
        $data       = [];
        $currentRow = 0; // 0-based counter that maps to 1-based spreadsheet rows

        // ------------------------------------------------------------------
        // ROW 1 – Main title
        // ------------------------------------------------------------------
        $this->mainTitleRow = 1;
        $data[] = [__('locale.REQUIREMENT DETAILS COMPLIANCE REPORT'), '', '', '', '', '', '', '', ''];
        $currentRow++; // row 1

        // ------------------------------------------------------------------
        // ROW 2 – Logo row (empty data, logo will be placed via drawing)
        // ------------------------------------------------------------------
        $this->logoRow = 2;
        $data[] = ['', '', '', '', '', '', '', '', ''];
        $currentRow++; // row 2

        // ROW 3 – blank spacer
        $data[] = ['', '', '', '', '', '', '', '', ''];
        $currentRow++; // row 3

        // ------------------------------------------------------------------
        // ROWS 4-5 – Audit information
        // ------------------------------------------------------------------
        $this->auditInfoRows = [4, 5];

        $data[] = [
            __('locale.Framework') . ':',
            $this->auditData->frameworkaduit->name ?? 'N/A',
            '',
            __('locale.Audit Name') . ':',
            $this->auditData->audit_name ?? 'N/A',
            '',
            __('locale.Test Number') . ':',
            $this->testNumber,
            '',
        ];
        $currentRow++; // row 4

        $data[] = [
            __('locale.Responsible') . ':',
            $this->auditData->owner->name ?? 'N/A',
            '',
            __('locale.Generated By') . ':',
            auth()->user()->name ?? __('locale.System'),
            '',
            __('locale.Generated') . ':',
            date('Y-m-d H:i:s'),
            '',
        ];
        $currentRow++; // row 5

        // ROW 6 – blank spacer
        $data[] = ['', '', '', '', '', '', '', '', ''];
        $currentRow++; // row 6

        // ------------------------------------------------------------------
        // ROW 7 – Executive summary title
        // ------------------------------------------------------------------
        $this->summaryTitleRow = 7;
        $data[] = [__('locale.EXECUTIVE SUMMARY'), '', '', '', '', '', '', '', ''];
        $currentRow++; // row 7

        // ROW 8 – blank spacer
        $data[] = ['', '', '', '', '', '', '', '', ''];
        $currentRow++; // row 8

        // ROWS 9-10 – Summary statistics
        $this->summaryDataRows = [9, 10];

        $data[] = [
            __('locale.Total Controls') . ':',
            $this->statistics['total_controls'],
            '',
            __('locale.Total Evidence') . ':',
            $this->statistics['total_evidence'],
            '',
            __('locale.Compliance Rate') . ':',
            $this->statistics['compliance_rate'] . '%',
            '',
        ];
        $currentRow++; // row 9

        $data[] = [
            __('locale.Approved Evidence') . ':',
            $this->statistics['approved_evidence'],
            '',
            __('locale.Rejected Evidence') . ':',
            $this->statistics['rejected_evidence'],
            '',
            __('locale.No Action Evidence') . ':',
            $this->statistics['no_action_evidence'],
            '',
        ];
        $currentRow++; // row 10

        // ROW 11 – blank spacer
        $data[] = ['', '', '', '', '', '', '', '', ''];
        $currentRow++; // row 11

        // ------------------------------------------------------------------
        // ROW 12 – Control details section title
        // ------------------------------------------------------------------
        $this->controlTitleRow = 12;
        $data[] = [__('locale.CONTROL DETAILS WITH EVIDENCE'), '', '', '', '', '', '', '', ''];
        $currentRow++; // row 12

        // ROW 13 – blank spacer
        $data[] = ['', '', '', '', '', '', '', '', ''];
        $currentRow++; // row 13

        // ------------------------------------------------------------------
        // Controls loop
        // ------------------------------------------------------------------
        $controlIndex = 0;

        foreach ($this->auditData->frameworkControlTestAudits as $testAudit) {
            $controlIndex++;
            $frameworkControl = $testAudit->frameworkControl;
            $familyName       = ($frameworkControl && $frameworkControl->Family)
                ? $frameworkControl->Family->name
                : __('locale.Uncategorized');

            // Blank spacer before each control block
            $data[]      = ['', '', '', '', '', '', '', '', ''];
            $currentRow++; // spacer

            // Control header row
            $data[] = [
                __('locale.CONTROL') . ' ' . $controlIndex,
                $frameworkControl->short_name ?? 'N/A',
                '',
                __('locale.FAMILY') . ':',
                $familyName,
                '',
                __('locale.STATUS') . ':',
                $this->getTestStatus($testAudit),
                '',
            ];
            $currentRow++;

            // Blank spacer
            $data[]      = ['', '', '', '', '', '', '', '', ''];
            $currentRow++;

            // ---- Control details sub-table ----
            // Headers
            $data[] = [
                '',
                __('locale.Attribute'),
                __('locale.Value'),
                '',
                __('locale.Metrics'),
                __('locale.Count'),
                '',
                '',
                '',
            ];
            $currentRow++;

            // Data rows
            $data[] = [
                '',
                __('locale.Control ID'),
                $testAudit->framework_control_id,
                '',
                __('locale.Total Evidence'),
                $testAudit->controlAuditEvidences->count(),
                '',
                '',
                '',
            ];
            $currentRow++;

            $data[] = [
                '',
                __('locale.Tester'),
                $testAudit->UserTester->name ?? 'N/A',
                '',
                __('locale.Approved Evidence'),
                $testAudit->controlAuditEvidences->where('evidence_audit_status', 'approved')->count(),
                '',
                '',
                '',
            ];
            $currentRow++;

            $data[] = [
                '',
                __('locale.Created Date'),
                $this->formatDate($testAudit->created_at),
                '',
                __('locale.Rejected Evidence'),
                $testAudit->controlAuditEvidences->where('evidence_audit_status', 'rejected')->count(),
                '',
                '',
                '',
            ];
            $currentRow++;

            // Blank spacer
            $data[]      = ['', '', '', '', '', '', '', '', ''];
            $currentRow++;

            // ---- Evidence section ----
            if ($testAudit->controlAuditEvidences->count() > 0) {
                // Supporting evidence sub-header
                $data[]      = ['', __('locale.SUPPORTING EVIDENCE'), '', '', '', '', '', '', ''];
                $currentRow++;

                // Blank spacer
                $data[]      = ['', '', '', '', '', '', '', '', ''];
                $currentRow++;

                // Evidence table header
                $data[] = [
                    '',
                    '#',
                    __('locale.Evidence Name'),
                    __('locale.Status'),
                    __('locale.Description'),
                    __('locale.Created By'),
                    __('locale.Upload Date'),
                    __('locale.Updated Date'),
                    __('locale.File'),
                ];
                $currentRow++;

                foreach ($testAudit->controlAuditEvidences as $evIndex => $evidence) {
                    $filePath  = $evidence->evidence->file_unique_name ?? null;
                    $isImage   = $filePath ? $this->isImageFile($filePath) : false;

                    if ($filePath) {
                        $fileCellValue = $isImage ? '' : __('locale.View File');
                    } else {
                        $fileCellValue = __('locale.File Missing');
                    }

                    $data[] = [
                        '',
                        $evIndex + 1,
                        $evidence->evidence->description ?? 'N/A',
                        $this->getEvidenceStatus($evidence->evidence_audit_status),
                        $evidence->evidence->description ?? '-',
                        $evidence->evidence->creator->name ?? 'N/A',
                        $this->formatDate($evidence->created_at),
                        $this->formatDate($evidence->updated_at),
                        $fileCellValue,
                    ];
                    $currentRow++;

                    // Handle image files
                    if ($filePath && $isImage && Storage::disk('local')->exists($filePath)) {
                        $this->addImageDrawing($evidence, $currentRow);
                    }
                }

                // Blank spacer after evidence list
                $data[]      = ['', '', '', '', '', '', '', '', ''];
                $currentRow++;
            } else {
                $data[]      = ['', __('locale.NO EVIDENCE AVAILABLE'), '', '', '', '', '', '', ''];
                $data[]      = ['', '', '', '', '', '', '', '', ''];
                $currentRow += 2;
            }

            // Spacer between controls
            $data[]      = ['', '', '', '', '', '', '', '', ''];
            $currentRow++;
        }

        $this->totalRows = count($data);

        return $data;
    }

    // -------------------------------------------------------------------------
    // Image drawing helper
    // -------------------------------------------------------------------------

    protected function addImageDrawing($evidence, $rowNumber)
    {
        $filePath = $evidence->evidence->file_unique_name;
        $fileName = $evidence->evidence->file_name ?? 'image';

        $drawing = new Drawing();
        $drawing->setName($fileName);
        $drawing->setDescription($evidence->evidence->description ?? '');
        $drawing->setPath(storage_path('app/' . $filePath));

        [$width, $height] = getimagesize(storage_path('app/' . $filePath));
        $ratio = $width / $height;

        if ($ratio > 1) {
            $drawing->setWidth(150);
            $drawing->setHeight((int) (150 / $ratio));
        } else {
            $drawing->setHeight(150);
            $drawing->setWidth((int) (150 * $ratio));
        }

        $drawing->setCoordinates('I' . $rowNumber);
        $this->imagePositions[] = $rowNumber;
        $this->drawings[]       = $drawing;
    }

    // -------------------------------------------------------------------------
    // Styles (base, applied before AfterSheet)
    // -------------------------------------------------------------------------

    public function styles(Worksheet $sheet)
    {
        $horizontalAlignment = $this->isRTL
            ? Alignment::HORIZONTAL_RIGHT
            : Alignment::HORIZONTAL_LEFT;

        return [
            'A:I' => [
                'font'      => ['size' => 10],
                'alignment' => [
                    'vertical'   => Alignment::VERTICAL_CENTER,
                    'horizontal' => $horizontalAlignment,
                ],
            ],
        ];
    }

    // -------------------------------------------------------------------------
    // Column widths
    // -------------------------------------------------------------------------

    public function columnWidths(): array
    {
        return [
            'A' => 14,
            'B' => 28,
            'C' => 22,
            'D' => 16,
            'E' => 22,
            'F' => 16,
            'G' => 16,
            'H' => 16,
            'I' => 25,
        ];
    }

    // -------------------------------------------------------------------------
    // Events
    // -------------------------------------------------------------------------

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event) {
                $sheet = $event->sheet->getDelegate();

                $horizontalAlignment = $this->isRTL
                    ? Alignment::HORIZONTAL_RIGHT
                    : Alignment::HORIZONTAL_LEFT;

                // RTL sheet direction
                if ($this->isRTL) {
                    $sheet->setRightToLeft(true);
                }

                // --- Section styling ---
                $this->styleMainTitle($sheet);
                $this->styleLogoRow($sheet);
                $this->styleAuditInfo($sheet);
                $this->styleSummarySection($sheet);
                $this->styleControlsSection($sheet);
                $this->applyGeneralFormatting($sheet);

                // --- Logo (positioned properly under header without overlapping) ---
                $this->addLogo($sheet);

                // --- Hyperlink styling for non-image file cells ---
                for ($row = 1; $row <= $this->totalRows; $row++) {
                    if ($sheet->getCell('I' . $row)->getValue() === __('locale.View File')) {
                        $sheet->getStyle('I' . $row)
                            ->getFont()
                            ->setColor(new \PhpOffice\PhpSpreadsheet\Style\Color(
                                \PhpOffice\PhpSpreadsheet\Style\Color::COLOR_BLUE
                            ))
                            ->setUnderline(true);
                    }
                }

                // --- Row heights ---
                for ($row = 1; $row <= $this->totalRows; $row++) {
                    $sheet->getRowDimension($row)->setRowHeight(-1);
                }
                foreach ($this->imagePositions as $imageRow) {
                    $sheet->getRowDimension($imageRow)->setRowHeight(120);
                }

                // --- Text wrapping & alignment ---
                $sheet->getStyle('A1:I' . $this->totalRows)
                    ->getAlignment()
                    ->setWrapText(true)
                    ->setHorizontal($horizontalAlignment);

                // --- Footer ---
                $sheet->getHeaderFooter()
                    ->setOddFooter(
                        '&L' . __('locale.Generated by Audit System') .
                        ' &C' . __('locale.Confidential') .
                        ' &R' . __('locale.Page') . ' &P ' . __('locale.of') . ' &N'
                    );
            },
        ];
    }

    // -------------------------------------------------------------------------
    // Logo (positioned at the right side under the header)
    // -------------------------------------------------------------------------

    protected function addLogo($sheet)
    {
        $logoPath = public_path('images/ksu-logo.png');

        if (!file_exists($logoPath)) {
            return;
        }

        try {
            $drawing = new Drawing();
            $drawing->setName('Logo');
            $drawing->setDescription('KSU Logo');
            $drawing->setPath($logoPath);
            $drawing->setHeight(50); // Logo height set to 50 pixels
            
            // Position logo at the right side in the dedicated logo row (row 2)
            if ($this->isRTL) {
                // For RTL: Place logo in column A (which appears on the right visually)
                $drawing->setCoordinates('A' . $this->logoRow);
                $drawing->setOffsetX(10);  // Positive offset moves right from column A
                $drawing->setOffsetY(5);   // Vertical offset from top of cell
            } else {
                // For LTR: Place logo in column I (rightmost column)
                $drawing->setCoordinates('I' . $this->logoRow);
                $drawing->setOffsetX(-50); // Negative offset moves left from column I
                $drawing->setOffsetY(5);   // Vertical offset from top of cell
            }
            
            $drawing->setWorksheet($sheet);
            
            // Adjust the logo row height to accommodate the logo (50px height + 20px padding = 70)
            $sheet->getRowDimension($this->logoRow)->setRowHeight(70);
            
        } catch (\Exception $e) {
            // Logo file unreadable – continue without it
        }
    }

    // -------------------------------------------------------------------------
    // Logo row styling
    // -------------------------------------------------------------------------

    private function styleLogoRow($sheet)
    {
        if ($this->logoRow > 0) {
            // Add a subtle bottom border to separate logo from content
            $sheet->getStyle('A' . $this->logoRow . ':I' . $this->logoRow)->applyFromArray([
                'borders' => [
                    'bottom' => [
                        'borderStyle' => Border::BORDER_MEDIUM,
                        'color' => ['rgb' => 'CCCCCC'],
                    ],
                ],
            ]);
            
            // Ensure the logo row has proper height and no text overlap
            $sheet->getRowDimension($this->logoRow)->setRowHeight(70);
        }
    }

    // -------------------------------------------------------------------------
    // Section stylers
    // -------------------------------------------------------------------------

    private function styleMainTitle($sheet)
    {
        // Merge A1:I1 for the title
        $sheet->mergeCells('A1:I1');

        $sheet->getStyle('A1:I1')->applyFromArray([
            'font' => [
                'bold'  => true,
                'size'  => 18,
                'color' => ['rgb' => 'black'],
            ],
            'fill' => [
                'fillType'   => Fill::FILL_SOLID,
                'startColor' => ['rgb' => 'white'],
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER,
                'vertical'   => Alignment::VERTICAL_CENTER,
            ],
        ]);

        $sheet->getRowDimension(1)->setRowHeight(40);
    }

    private function styleAuditInfo($sheet)
    {
        $labelRanges = ['A', 'D', 'G'];
        $valueRanges = ['B', 'E', 'H'];

        foreach ($this->auditInfoRows as $row) {
            foreach ($labelRanges as $col) {
                $sheet->getStyle("{$col}{$row}")->applyFromArray([
                    'font' => [
                        'bold'  => true,
                        'color' => ['rgb' => '2F5F8F'],
                    ],
                    'fill' => [
                        'fillType'   => Fill::FILL_SOLID,
                        'startColor' => ['rgb' => 'E6F1FF'],
                    ],
                ]);
            }

            foreach ($valueRanges as $col) {
                $sheet->getStyle("{$col}{$row}")->applyFromArray([
                    'font' => ['color' => ['rgb' => '1B365D']],
                ]);
            }
        }
    }

    private function styleSummarySection($sheet)
    {
        // Summary title row
        $row = $this->summaryTitleRow;
        $sheet->mergeCells("A{$row}:I{$row}");
        $sheet->getStyle("A{$row}:I{$row}")->applyFromArray([
            'font' => [
                'bold'  => true,
                'size'  => 14,
                'color' => ['rgb' => 'FFFFFF'],
            ],
            'fill' => [
                'fillType'   => Fill::FILL_SOLID,
                'startColor' => ['rgb' => '2E7D32'],
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER,
                'vertical'   => Alignment::VERTICAL_CENTER,
            ],
        ]);
        $sheet->getRowDimension($row)->setRowHeight(30);

        // Summary data rows
        foreach ($this->summaryDataRows as $dataRow) {
            $sheet->getStyle("A{$dataRow}:I{$dataRow}")->applyFromArray([
                'fill' => [
                    'fillType'   => Fill::FILL_SOLID,
                    'startColor' => ['rgb' => 'F1F8E9'],
                ],
                'font' => ['bold' => true],
            ]);
        }
    }

    private function styleControlsSection($sheet)
    {
        // Controls section title row
        $row = $this->controlTitleRow;
        $sheet->mergeCells("A{$row}:I{$row}");
        $sheet->getStyle("A{$row}:I{$row}")->applyFromArray([
            'font' => [
                'bold'  => true,
                'size'  => 14,
                'color' => ['rgb' => 'FFFFFF'],
            ],
            'fill' => [
                'fillType'   => Fill::FILL_SOLID,
                'startColor' => ['rgb' => 'D32F2F'],
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER,
                'vertical'   => Alignment::VERTICAL_CENTER,
            ],
        ]);
        $sheet->getRowDimension($row)->setRowHeight(30);

        // Style individual control rows
        $controlLabel        = __('locale.CONTROL');
        $supportingEvidence  = __('locale.SUPPORTING EVIDENCE');
        $noEvidence          = __('locale.NO EVIDENCE AVAILABLE');
        $attributeLabel      = __('locale.Attribute');

        for ($r = $this->controlTitleRow + 2; $r <= $this->totalRows; $r++) {
            $aCellValue = (string) ($sheet->getCell('A' . $r)->getValue() ?? '');
            $bCellValue = (string) ($sheet->getCell('B' . $r)->getValue() ?? '');

            // Control header rows
            if (str_starts_with($aCellValue, $controlLabel . ' ')) {
                $sheet->getStyle("A{$r}:I{$r}")->applyFromArray([
                    'font' => [
                        'bold'  => true,
                        'size'  => 12,
                        'color' => ['rgb' => 'FFFFFF'],
                    ],
                    'fill' => [
                        'fillType'   => Fill::FILL_SOLID,
                        'startColor' => ['rgb' => '3F51B5'],
                    ],
                ]);
                $sheet->getRowDimension($r)->setRowHeight(25);
                continue;
            }

            // Supporting evidence / no evidence sub-headers
            if (in_array($bCellValue, [$supportingEvidence, $noEvidence], true)) {
                $sheet->getStyle("B{$r}:I{$r}")->applyFromArray([
                    'font' => [
                        'bold'  => true,
                        'color' => ['rgb' => 'FFFFFF'],
                    ],
                    'fill' => [
                        'fillType'   => Fill::FILL_SOLID,
                        'startColor' => ['rgb' => '607D8B'],
                    ],
                ]);
                continue;
            }

            // Sub-table header rows
            if (in_array($bCellValue, [$attributeLabel, '#'], true)) {
                $sheet->getStyle("A{$r}:I{$r}")->applyFromArray([
                    'font' => ['bold' => true],
                    'fill' => [
                        'fillType'   => Fill::FILL_SOLID,
                        'startColor' => ['rgb' => 'CFD8DC'],
                    ],
                ]);
            }
        }
    }

    private function applyGeneralFormatting($sheet)
    {
        // Outer border for the data range
        $sheet->getStyle('A1:I' . $this->totalRows)
            ->getBorders()
            ->getOutline()
            ->setBorderStyle(Border::BORDER_MEDIUM);

        // Thin inner borders for non-empty rows
        for ($row = 3; $row <= $this->totalRows; $row++) {
            if ($sheet->getCell('B' . $row)->getValue() !== null &&
                $sheet->getCell('B' . $row)->getValue() !== '') {
                $sheet->getStyle("A{$row}:I{$row}")
                    ->getBorders()
                    ->getAllBorders()
                    ->setBorderStyle(Border::BORDER_THIN);
            }
        }
    }

    // -------------------------------------------------------------------------
    // Helper methods
    // -------------------------------------------------------------------------

    private function isImageFile($filePath): bool
    {
        $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg'];
        $extension       = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
        return in_array($extension, $imageExtensions, true);
    }

    private function getTestStatus($testAudit): string
    {
        $testNumberArray = json_decode($testAudit->test_number, true);
        $status          = $testNumberArray[1] ?? 'No Action';

        return match ($status) {
            'Approved' => '✓ ' . __('locale.Approved'),
            'Rejected' => '✗ ' . __('locale.Rejected'),
            default    => '⏳ ' . __('locale.No Action'),
        };
    }

    private function getEvidenceStatus($status): string
    {
        return match ($status) {
            'approved' => '✓ ' . __('locale.APPROVED'),
            'rejected' => '✗ ' . __('locale.REJECTED'),
            default    => '👁 ' . __('locale.REVIEW'),
        };
    }

    private function formatDate($date): string
    {
        if (!$date) {
            return '-';
        }

        if (is_string($date)) {
            try {
                return date('M j, Y', strtotime($date));
            } catch (\Exception $e) {
                return $date;
            }
        }

        if (method_exists($date, 'format')) {
            return $date->format('M j, Y');
        }

        return '-';
    }
}