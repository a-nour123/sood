@extends('admin/layouts/contentLayoutMaster')

@section('title', __('phishing.Awareness_Team_Report'))

@section('vendor-style')
@endsection

@section('page-style')
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .page-wrapper.compact-small .page-body-wrapper .page-body {
            margin-left: 0 !important;
        }
        .page-wrapper .page-body-wrapper .page-body {
            padding: 0 !important;
        }
        .highcharts-credits {
            display: none;
        }
        .report-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 2rem;
            border-radius: 10px;
            margin-bottom: 2rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .report-logo {
            max-width: 150px;
            max-height: 150px;
            margin-bottom: 1rem;
        }
        .editable-title {
            cursor: pointer;
            border-bottom: 2px dashed rgba(255,255,255,0.5);
            padding: 0.25rem 0.5rem;
            display: inline-block;
            transition: all 0.3s ease;
        }
        .editable-title:hover {
            background: rgba(255,255,255,0.1);
        }
        .title-input {
            background: rgba(255,255,255,0.2);
            border: 2px solid white;
            color: white;
            padding: 0.5rem;
            border-radius: 5px;
            width: 100%;
            max-width: 500px;
        }
        .title-input::placeholder {
            color: rgba(255,255,255,0.7);
        }
        .card {
            border-radius: 10px;
            transition: all 0.3s ease;
            border: none;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .card:hover {
            box-shadow: 0 5px 15px rgba(0,0,0,0.1) !important;
        }
        .card-header {
            border-radius: 10px 10px 0 0;
            font-weight: 600;
        }
        .table {
            border-radius: 5px;
            overflow: hidden;
        }
        .table thead th {
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.85rem;
            letter-spacing: 0.5px;
        }
        .table tbody tr {
            transition: all 0.2s ease;
        }
        .table tbody tr:hover {
            background-color: #f8f9fa;
        }
        .badge {
            padding: 0.5em 0.75em;
            font-weight: 500;
        }
    </style>
    @include('admin.content.phishing.dashboard.partials.print-pdf-styles')
@endsection

@section('content')
    @include('admin.content.phishing.dashboard.partials.print-pdf-toolbar')
    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">
            <div class="row breadcrumbs-top widget-grid">
                <div class="col-12">
                    <div class="page-title mt-2">
                        <div class="row">
                            <div class="col-sm-12 ps-0">
                                @if (@isset($breadcrumbs))
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}" style="display: flex;">
                                            <svg class="stroke-icon">
                                                <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}"></use>
                                            </svg></a></li>
                                        @foreach ($breadcrumbs as $breadcrumb)
                                            <li class="breadcrumb-item">
                                                @if (isset($breadcrumb['link']))
                                                    <a href="{{ $breadcrumb['link'] == 'javascript:void(0)' ? $breadcrumb['link'] : url($breadcrumb['link']) }}">
                                                @endif
                                                {{ $breadcrumb['name'] }}
                                                @if (isset($breadcrumb['link']))
                                                    </a>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ol>
                                @endisset
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="page-wrapper" id="pageWrapper">
        <div class="page-body-wrapper">
            <div class="page-body">
                <div class="container-fluid"></div>
                <div class="container-fluid dashboard_default">
                    <div class="row widget-grid">

                        {{-- Report Configuration --}}
                        <div class="col-12 mb-3">
                            <div class="card">
                                <div class="card-body">
                                    <form method="GET" action="{{ route('admin.phishing.awareness.team-report') }}" id="report-config-form" class="row g-3">
                                        <div class="col-md-3">
                                            <label for="start_date" class="form-label">{{ __('phishing.Start_Date') }}</label>
                                            <input type="date" name="start_date" id="start_date" class="form-control" 
                                                   value="{{ request('start_date', \Carbon\Carbon::now()->subYear()->format('Y-m-d')) }}">
                                        </div>
                                        <div class="col-md-3">
                                            <label for="end_date" class="form-label">{{ __('phishing.End_Date') }}</label>
                                            <input type="date" name="end_date" id="end_date" class="form-control" 
                                                   value="{{ request('end_date', \Carbon\Carbon::now()->format('Y-m-d')) }}">
                                        </div>
                                        <div class="col-md-3">
                                            <label for="display_mode" class="form-label">{{ __('phishing.Display_Mode') }}</label>
                                            <select name="display_mode" id="display_mode" class="form-control">
                                                <option value="chart" {{ request('display_mode', 'chart') == 'chart' ? 'selected' : '' }}>{{ __('phishing.Chart') }}</option>
                                                <option value="table" {{ request('display_mode') == 'table' ? 'selected' : '' }}>{{ __('phishing.Table') }}</option>
                                            </select>
                                        </div>
                                        <div class="col-md-3">
                                            <label for="report_title" class="form-label">{{ __('phishing.Report_Title') }}</label>
                                            <input type="text" name="report_title" id="report_title" class="form-control" 
                                                   value="{{ request('report_title', __('phishing.Awareness_Team_Report')) }}" 
                                                   placeholder="{{ __('phishing.Report_Title') }}">
                                        </div>
                                        <div class="col-md-12">
                                            <label class="form-label fw-bold mb-2">{{ __('phishing.Select_Report_Contents') }}</label>
                                            <div class="form-check">
                                                <input type="hidden" name="include_training" value="0">
                                                <input class="form-check-input" type="checkbox" name="include_training" id="include_training" 
                                                       value="1" {{ request('include_training', '1') == '1' ? 'checked' : '' }}>
                                                <label class="form-check-label" for="include_training">
                                                    {{ __('phishing.Include_Training_Details') }}
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input type="hidden" name="include_phishing" value="0">
                                                <input class="form-check-input" type="checkbox" name="include_phishing" id="include_phishing" 
                                                       value="1" {{ request('include_phishing', '1') == '1' ? 'checked' : '' }}>
                                                <label class="form-check-label" for="include_phishing">
                                                    {{ __('phishing.Include_Phishing_Details') }}
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <button type="submit" class="btn btn-primary">{{ __('phishing.Generate_Report') }}</button>
                                            <a href="{{ route('admin.phishing.awareness.team-report') }}" class="btn btn-secondary">{{ __('phishing.Reset') }}</a>
                                            <button type="button" class="btn btn-success" onclick="exportReport()">{{ __('phishing.Export_Report') }}</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        {{-- Report Header with Logo and Title --}}
                        <div class="col-12">
                            <div class="report-header">
                                <div class="row align-items-center">
                                    <div class="col-md-3 text-center">
                                        @if(request('logo_path'))
                                            <img src="{{ asset('storage/' . request('logo_path')) }}" alt="Logo" class="report-logo">
                                        @else
                                            <div class="report-logo-placeholder" style="width: 150px; height: 150px; background: rgba(255,255,255,0.2); border-radius: 10px; display: flex; align-items: center; justify-content: center; margin: 0 auto;">
                                                <span>{{ __('phishing.Logo') }}</span>
                                            </div>
                                        @endif
                                    </div>
                                    <div class="col-md-9">
                                        <h1 id="report-title-display" class="editable-title" onclick="editTitle()">
                                            {{ $reportTitle }}
                                        </h1>
                                        <input type="text" id="report-title-input" class="title-input d-none" 
                                               value="{{ $reportTitle }}" 
                                               onblur="saveTitle()" 
                                               onkeypress="if(event.key === 'Enter') saveTitle()">
                                        <p class="mt-2 mb-0">
                                            {{ __('phishing.Report_Generated_On') }}: {{ \Carbon\Carbon::now()->format('Y-m-d H:i:s') }}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        @if(request('include_training') == '1')
                        {{-- Training Details --}}
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header pb-0">
                                    <h3 class="m-0">{{ __('phishing.Training_Information') }}</h3>
                                </div>
                                <div class="card-body">
                                    @if($displayMode == 'chart')
                                        <div id="training-chart-container"></div>
                                    @else
                                        <div class="table-responsive">
                                            <table class="table table-striped">
                                                <thead>
                                                    <tr>
                                                        <th>{{ __('phishing.month') }}</th>
                                                        <th>{{ __('phishing.Training_Employee_Delivered') }}</th>
                                                        <th>{{ __('phishing.Training_Passed_Employee') }}</th>
                                                        <th>{{ __('phishing.Training_Failed_Employee') }}</th>
                                                        <th>{{ __('phishing.Training_Over_Due_Employee') }}</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @forelse($trainingDetails as $detail)
                                                        <tr>
                                                            <td>{{ data_get($detail, 'month') }}</td>
                                                            <td>{{ data_get($detail, 'total_recieved_users') }}</td>
                                                            <td>{{ data_get($detail, 'total_passed_users') }}</td>
                                                            <td>{{ data_get($detail, 'total_failed_users') }}</td>
                                                            <td>{{ data_get($detail, 'total_overdue_users') }}</td>
                                                        </tr>
                                                    @empty
                                                        <tr>
                                                            <td colspan="5" class="text-center">{{ __('locale.NoDataAvailable') }}</td>
                                                        </tr>
                                                    @endforelse
                                                </tbody>
                                            </table>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        @endif

                        @if(request('include_phishing') == '1')
                        {{-- Phishing Details --}}
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header pb-0">
                                    <h3 class="m-0">{{ __('phishing.Phishing_Statistics') }}</h3>
                                </div>
                                <div class="card-body">
                                    @if($displayMode == 'chart')
                                        <div id="phishing-chart-container"></div>
                                    @else
                                        <div class="table-responsive">
                                            <table class="table table-striped">
                                                <thead>
                                                    <tr>
                                                        <th>{{ __('phishing.month') }}</th>
                                                        <th>{{ __('phishing.opened_count') }}</th>
                                                        <th>{{ __('phishing.clicked_link_count') }}</th>
                                                        <th>{{ __('phishing.form_submited_count') }}</th>
                                                        <th>{{ __('phishing.file_downloaded_count') }}</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @forelse($phishingDetails as $detail)
                                                        <tr>
                                                            <td>{{ data_get($detail, 'month') }}</td>
                                                            <td>{{ data_get($detail, 'mails_opened') }}</td>
                                                            <td>{{ data_get($detail, 'clicked_link') }}</td>
                                                            <td>{{ data_get($detail, 'mails_submitted') }}</td>
                                                            <td>{{ data_get($detail, 'mails_downloaded') }}</td>
                                                        </tr>
                                                    @empty
                                                        <tr>
                                                            <td colspan="5" class="text-center">{{ __('locale.NoDataAvailable') }}</td>
                                                        </tr>
                                                    @endforelse
                                                </tbody>
                                            </table>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>

                        {{-- Campaigns Details --}}
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header pb-0">
                                    <h3 class="m-0">{{ __('phishing.Campaigns_Statistic') }}</h3>
                                </div>
                                <div class="card-body">
                                    @if($displayMode == 'chart')
                                        <div id="campaigns-chart-container"></div>
                                    @else
                                        <div class="table-responsive">
                                            <table class="table table-striped">
                                                <thead>
                                                    <tr>
                                                        <th>{{ __('phishing.CAMPAIGN_NAME') }}</th>
                                                        <th>{{ __('phishing.Total_Emails_Delivered') }}</th>
                                                        <th>{{ __('phishing.Total_Employees_Targeted') }}</th>
                                                        <th>{{ __('phishing.opened_count') }}</th>
                                                        <th>{{ __('phishing.clicked_link_count') }}</th>
                                                        <th>{{ __('phishing.file_downloaded_count') }}</th>
                                                        <th>{{ __('phishing.form_submited_count') }}</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @forelse($campaignsDetails as $campaign)
                                                        <tr>
                                                            <td>{{ data_get($campaign, 'campaign_name') }}</td>
                                                            <td>{{ data_get($campaign, 'deliverd_email_templates_count') }}</td>
                                                            <td>{{ data_get($campaign, 'deliverd_employees_count') }}</td>
                                                            <td>{{ data_get($campaign, 'opened_trackings_count') }}</td>
                                                            <td>{{ data_get($campaign, 'clicked_trackings_count') }}</td>
                                                            <td>{{ data_get($campaign, 'downloaded_trackings_count') }}</td>
                                                            <td>{{ data_get($campaign, 'submitted_trackings_count') }}</td>
                                                        </tr>
                                                    @empty
                                                        <tr>
                                                            <td colspan="7" class="text-center">{{ __('locale.NoDataAvailable') }}</td>
                                                        </tr>
                                                    @endforelse
                                                </tbody>
                                            </table>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        @endif

                    </div>
                </div>
            </div>
        </div>
    </div>
    @include('admin.content.phishing.dashboard.partials.print-pdf-close')
@endsection

@section('vendor-script')
@endsection

@section('page-script')
    <script src="{{ asset('js/scripts/config.js') }}"></script>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="https://code.highcharts.com/modules/export-data.js"></script>
    
    <script>
        // Fix Highcharts locale issue immediately after loading
        (function() {
            if (typeof Highcharts !== 'undefined') {
                // Set default locale to avoid "Invalid language tag" error
                try {
                    Highcharts.setOptions({
                        global: {
                            useUTC: false
                        },
                        lang: {
                            months: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
                            shortMonths: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                            weekdays: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
                            decimalPoint: '.',
                            thousandsSep: ','
                        }
                    });
                } catch(e) {
                    console.warn('Highcharts locale setup warning:', e);
                }
            }
        })();
    </script>
    
    <script>
        function editTitle() {
            document.getElementById('report-title-display').classList.add('d-none');
            document.getElementById('report-title-input').classList.remove('d-none');
            document.getElementById('report-title-input').focus();
        }

        function saveTitle() {
            const newTitle = document.getElementById('report-title-input').value;
            document.getElementById('report-title-display').textContent = newTitle;
            document.getElementById('report-title-input').classList.add('d-none');
            document.getElementById('report-title-display').classList.remove('d-none');
            document.getElementById('report_title').value = newTitle;
        }

        function exportReport() {
            window.print();
        }

        @if($displayMode == 'chart')
        document.addEventListener('DOMContentLoaded', function() {
            console.log('Charts initialization started');
            @if(request('include_training') == '1')
            @php
                $trainingCollection = collect($trainingDetails ?? []);
                $trainingCategories = $trainingCollection->pluck('month')->toArray();
                $trainingReceived = $trainingCollection->pluck('total_recieved_users')->toArray();
                $trainingPassed = $trainingCollection->pluck('total_passed_users')->toArray();
                $trainingFailed = $trainingCollection->pluck('total_failed_users')->toArray();
                $trainingOverdue = $trainingCollection->pluck('total_overdue_users')->toArray();
            @endphp
            console.log('Training categories count:', {!! count($trainingCategories) !!});
            console.log('Training container exists:', document.getElementById('training-chart-container') !== null);
            @if(count($trainingCategories) > 0)
            // Training Chart
            console.log('Creating training chart with data:', {!! json_encode($trainingCategories, JSON_UNESCAPED_UNICODE) !!});
            var trainingContainer = document.getElementById('training-chart-container');
            if (trainingContainer) {
                try {
                    Highcharts.chart('training-chart-container', {
                        chart: { type: 'column' },
                        title: { text: '{{ __('phishing.Training_Information') }}' },
                        xAxis: {
                            categories: {!! json_encode($trainingCategories, JSON_UNESCAPED_UNICODE) !!},
                            labels: {
                                formatter: function() {
                                    return this.value;
                                }
                            }
                        },
                        yAxis: { 
                            min: 0, 
                            title: { text: '{{ __('phishing.Count') }}' },
                            labels: {
                                formatter: function() {
                                    return this.value;
                                }
                            }
                        },
                        legend: { enabled: true },
                        tooltip: { shared: true },
                        plotOptions: {
                            column: {
                                stacking: null,
                                dataLabels: { enabled: true }
                            }
                        },
                        series: [
                            {
                                name: '{{ __('phishing.Training_Employee_Delivered') }}',
                                data: {!! json_encode($trainingReceived, JSON_UNESCAPED_UNICODE) !!}
                            },
                            {
                                name: '{{ __('phishing.Training_Passed_Employee') }}',
                                data: {!! json_encode($trainingPassed, JSON_UNESCAPED_UNICODE) !!}
                            },
                            {
                                name: '{{ __('phishing.Training_Failed_Employee') }}',
                                data: {!! json_encode($trainingFailed, JSON_UNESCAPED_UNICODE) !!}
                            },
                            {
                                name: '{{ __('phishing.Training_Over_Due_Employee') }}',
                                data: {!! json_encode($trainingOverdue, JSON_UNESCAPED_UNICODE) !!}
                            }
                        ]
                    });
                    console.log('Training chart created successfully');
                } catch (error) {
                    console.error('Error creating training chart:', error);
                    trainingContainer.innerHTML = '<p class="text-center text-danger">Error creating chart: ' + error.message + '</p>';
                }
            } else {
                console.error('Training chart container not found!');
            }
            @else
            // Show message if no training data
            console.log('No training data available');
            var trainingContainer = document.getElementById('training-chart-container');
            if (trainingContainer) {
                trainingContainer.innerHTML = '<p class="text-center text-muted">{{ __('locale.NoDataAvailable') }}</p>';
            }
            @endif
            @endif

            @if(request('include_phishing') == '1')
            @php
                $phishingCollection = collect($phishingDetails ?? []);
                $phishingCategories = $phishingCollection->pluck('month')->toArray();
                $phishingOpened = $phishingCollection->pluck('mails_opened')->toArray();
                $phishingClicked = $phishingCollection->pluck('clicked_link')->toArray();
                $phishingSubmitted = $phishingCollection->pluck('mails_submitted')->toArray();
                $phishingDownloaded = $phishingCollection->pluck('mails_downloaded')->toArray();
            @endphp
            console.log('Phishing categories count:', {!! count($phishingCategories) !!});
            console.log('Phishing container exists:', document.getElementById('phishing-chart-container') !== null);
            @if(count($phishingCategories) > 0)
            // Phishing Chart
            console.log('Creating phishing chart with data:', {!! json_encode($phishingCategories, JSON_UNESCAPED_UNICODE) !!});
            var phishingContainer = document.getElementById('phishing-chart-container');
            if (phishingContainer) {
                try {
                    Highcharts.chart('phishing-chart-container', {
                        chart: { type: 'column' },
                        title: { text: '{{ __('phishing.Phishing_Statistics') }}' },
                        xAxis: {
                            categories: {!! json_encode($phishingCategories, JSON_UNESCAPED_UNICODE) !!},
                            labels: {
                                formatter: function() {
                                    return this.value;
                                }
                            }
                        },
                        yAxis: { 
                            min: 0, 
                            title: { text: '{{ __('phishing.Count') }}' },
                            labels: {
                                formatter: function() {
                                    return this.value;
                                }
                            }
                        },
                        legend: { enabled: true },
                        tooltip: { shared: true },
                        plotOptions: {
                            column: {
                                stacking: null,
                                dataLabels: { enabled: true }
                            }
                        },
                        series: [
                            {
                                name: '{{ __('phishing.opened_count') }}',
                                data: {!! json_encode($phishingOpened, JSON_UNESCAPED_UNICODE) !!}
                            },
                            {
                                name: '{{ __('phishing.clicked_link_count') }}',
                                data: {!! json_encode($phishingClicked, JSON_UNESCAPED_UNICODE) !!}
                            },
                            {
                                name: '{{ __('phishing.form_submited_count') }}',
                                data: {!! json_encode($phishingSubmitted, JSON_UNESCAPED_UNICODE) !!}
                            },
                            {
                                name: '{{ __('phishing.file_downloaded_count') }}',
                                data: {!! json_encode($phishingDownloaded, JSON_UNESCAPED_UNICODE) !!}
                            }
                        ]
                    });
                    console.log('Phishing chart created successfully');
                } catch (error) {
                    console.error('Error creating phishing chart:', error);
                    phishingContainer.innerHTML = '<p class="text-center text-danger">Error creating chart: ' + error.message + '</p>';
                }
            } else {
                console.error('Phishing chart container not found!');
            }
            @else
            // Show message if no phishing data
            console.log('No phishing data available');
            var phishingContainer = document.getElementById('phishing-chart-container');
            if (phishingContainer) {
                phishingContainer.innerHTML = '<p class="text-center text-muted">{{ __('locale.NoDataAvailable') }}</p>';
            }
            @endif

            @php
                $campaignCollection = collect($campaignsDetails ?? []);
                $campaignCategories = $campaignCollection->pluck('campaign_name')->toArray();
                $campaignEmails = $campaignCollection->pluck('deliverd_email_templates_count')->toArray();
                $campaignEmployees = $campaignCollection->pluck('deliverd_employees_count')->toArray();
                $campaignOpened = $campaignCollection->pluck('opened_trackings_count')->toArray();
                $campaignClicked = $campaignCollection->pluck('clicked_trackings_count')->toArray();
                $campaignDownloaded = $campaignCollection->pluck('downloaded_trackings_count')->toArray();
                $campaignSubmitted = $campaignCollection->pluck('submitted_trackings_count')->toArray();
            @endphp
            console.log('Campaign categories count:', {!! count($campaignCategories) !!});
            console.log('Campaigns container exists:', document.getElementById('campaigns-chart-container') !== null);
            @if(count($campaignCategories) > 0)
            // Campaigns Chart
            console.log('Creating campaigns chart with data:', {!! json_encode($campaignCategories, JSON_UNESCAPED_UNICODE) !!});
            var campaignsContainer = document.getElementById('campaigns-chart-container');
            if (campaignsContainer) {
                try {
                    Highcharts.chart('campaigns-chart-container', {
                        chart: { type: 'column' },
                        title: { text: '{{ __('phishing.Campaigns_Statistic') }}' },
                        xAxis: {
                            categories: {!! json_encode($campaignCategories, JSON_UNESCAPED_UNICODE) !!},
                            labels: {
                                formatter: function() {
                                    return this.value;
                                }
                            }
                        },
                        yAxis: { 
                            min: 0, 
                            title: { text: '{{ __('phishing.Count') }}' },
                            labels: {
                                formatter: function() {
                                    return this.value;
                                }
                            }
                        },
                        legend: { enabled: true },
                        tooltip: { shared: true },
                        plotOptions: {
                            column: {
                                stacking: null,
                                dataLabels: { enabled: true }
                            }
                        },
                        series: [
                            {
                                name: '{{ __('phishing.Total_Emails_Delivered') }}',
                                data: {!! json_encode($campaignEmails, JSON_UNESCAPED_UNICODE) !!}
                            },
                            {
                                name: '{{ __('phishing.Total_Employees_Targeted') }}',
                                data: {!! json_encode($campaignEmployees, JSON_UNESCAPED_UNICODE) !!}
                            },
                            {
                                name: '{{ __('phishing.opened_count') }}',
                                data: {!! json_encode($campaignOpened, JSON_UNESCAPED_UNICODE) !!}
                            },
                            {
                                name: '{{ __('phishing.clicked_link_count') }}',
                                data: {!! json_encode($campaignClicked, JSON_UNESCAPED_UNICODE) !!}
                            },
                            {
                                name: '{{ __('phishing.file_downloaded_count') }}',
                                data: {!! json_encode($campaignDownloaded, JSON_UNESCAPED_UNICODE) !!}
                            },
                            {
                                name: '{{ __('phishing.form_submited_count') }}',
                                data: {!! json_encode($campaignSubmitted, JSON_UNESCAPED_UNICODE) !!}
                            }
                        ]
                    });
                    console.log('Campaigns chart created successfully');
                } catch (error) {
                    console.error('Error creating campaigns chart:', error);
                    campaignsContainer.innerHTML = '<p class="text-center text-danger">Error creating chart: ' + error.message + '</p>';
                }
            } else {
                console.error('Campaigns chart container not found!');
            }
            @else
            // Show message if no campaigns data
            console.log('No campaigns data available');
            var campaignsContainer = document.getElementById('campaigns-chart-container');
            if (campaignsContainer) {
                campaignsContainer.innerHTML = '<p class="text-center text-muted">{{ __('locale.NoDataAvailable') }}</p>';
            }
            @endif
            @endif
        });
        @endif
    </script>
    @include('admin.content.phishing.dashboard.partials.print-pdf-script')
@endsection
