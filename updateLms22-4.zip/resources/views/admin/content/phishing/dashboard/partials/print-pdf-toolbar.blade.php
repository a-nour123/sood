<div class="mb-2 d-flex justify-content-end phishing-no-print">
    <button type="button" class="btn btn-outline-primary" data-phishing-export-pdf onclick="exportPhishingDashboardPrintPdf()"
        title="{{ app()->getLocale() === 'ar' ? 'يفتح الطباعة — اختر «حفظ كـ PDF» كوجهة الطابعة' : 'Opens print — choose «Save as PDF» as the printer' }}">
        <i class="fas fa-file-pdf me-50"></i> {{ __('locale.Export') }} PDF
    </button>
</div>
<div id="phishing-dashboard-export-container" style="font-family: Tahoma, Arial, sans-serif;">
@php
    $__phishingExportLogo = getSystemSetting('institution_photo');
@endphp
@if (!empty($__phishingExportLogo))
    <div class="phishing-dashboard-print-header" aria-hidden="true">
        <img src="{{ asset('storage/' . $__phishingExportLogo) }}" alt="">
    </div>
@endif
