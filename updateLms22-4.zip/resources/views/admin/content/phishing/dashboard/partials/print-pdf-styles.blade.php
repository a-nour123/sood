<link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
<style>
    /* Phishing dashboards: print / Save as PDF (same approach as LMS training dashboard) */
    @media print {
        @page {
            size: landscape;
            margin: 10mm;
        }

        body.phishing-dashboard-print-prep .phishing-no-print {
            display: none !important;
        }

        body.phishing-dashboard-print-prep .sidebar-wrapper,
        body.phishing-dashboard-print-prep .main-menu,
        body.phishing-dashboard-print-prep .horizontal-menu,
        body.phishing-dashboard-print-prep .navbar,
        body.phishing-dashboard-print-prep .header-navbar,
        body.phishing-dashboard-print-prep .footer,
        body.phishing-dashboard-print-prep footer,
        body.phishing-dashboard-print-prep .loader-wrapper,
        body.phishing-dashboard-print-prep .content-overlay,
        body.phishing-dashboard-print-prep .header-navbar-shadow,
        body.phishing-dashboard-print-prep .sidenav-overlay,
        body.phishing-dashboard-print-prep .drag-target {
            display: none !important;
        }

        body.phishing-dashboard-print-prep .modal,
        body.phishing-dashboard-print-prep .modal-backdrop {
            display: none !important;
        }

        body.phishing-dashboard-print-prep #pageWrapper,
        body.phishing-dashboard-print-prep .app-content,
        body.phishing-dashboard-print-prep .content-area-wrapper,
        body.phishing-dashboard-print-prep .content-wrapper,
        body.phishing-dashboard-print-prep .page-body-wrapper,
        body.phishing-dashboard-print-prep .content-body {
            width: 100% !important;
            max-width: none !important;
            margin: 0 !important;
            padding: 0 !important;
            box-shadow: none !important;
        }

        body.phishing-dashboard-print-prep #phishing-dashboard-export-container {
            width: 100% !important;
            max-width: none !important;
            margin: 0 !important;
        }

        body.phishing-dashboard-print-prep .nav-tabs,
        body.phishing-dashboard-print-prep .nav-tabs-custom {
            display: none !important;
        }

        body.phishing-dashboard-print-prep .tab-content > .tab-pane {
            display: block !important;
            opacity: 1 !important;
            visibility: visible !important;
        }

        body.phishing-dashboard-print-prep .widget-1:hover,
        body.phishing-dashboard-print-prep .stats-card:hover {
            transform: none !important;
        }

        body.phishing-dashboard-print-prep .dataTables_length,
        body.phishing-dashboard-print-prep .dataTables_filter,
        body.phishing-dashboard-print-prep .dataTables_info,
        body.phishing-dashboard-print-prep .dataTables_paginate,
        body.phishing-dashboard-print-prep .dt-buttons {
            display: none !important;
        }

        body.phishing-dashboard-print-prep .phishing-dashboard-print-header {
            display: flex !important;
            flex-direction: row;
            direction: ltr;
            justify-content: flex-end;
            align-items: flex-start;
            width: 100%;
            margin: 0 0 16px 0;
            padding: 0 0 12px 0;
            border-bottom: 1px solid #dee2e6;
            box-sizing: border-box;
        }

        body.phishing-dashboard-print-prep .phishing-dashboard-print-header img {
            display: block;
            max-height: 80px;
            max-width: 240px;
            width: auto;
            height: auto;
            object-fit: contain;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }
    }

    .phishing-dashboard-print-header {
        display: none !important;
    }
</style>
