<script>
    function exportPhishingDashboardPrintPdf() {
        const btn = document.querySelector('[data-phishing-export-pdf]');
        const root = document.getElementById('phishing-dashboard-export-container');
        if (!root) {
            return;
        }

        if (btn) {
            btn.disabled = true;
        }

        try {
            document.body.classList.add('phishing-dashboard-print-prep');

            var cleaned = false;
            var done = function () {
                if (cleaned) {
                    return;
                }
                cleaned = true;
                document.body.classList.remove('phishing-dashboard-print-prep');
                window.removeEventListener('afterprint', done);
                if (btn) {
                    btn.disabled = false;
                }
            };
            window.addEventListener('afterprint', done);

            requestAnimationFrame(function () {
                if (typeof Highcharts !== 'undefined' && Highcharts.charts) {
                    Highcharts.charts.forEach(function (c) {
                        if (c && typeof c.reflow === 'function') {
                            try {
                                c.reflow();
                            } catch (e) {}
                        }
                    });
                }
                window.print();
                setTimeout(done, 3500);
            });
        } catch (e) {
            document.body.classList.remove('phishing-dashboard-print-prep');
            if (btn) {
                btn.disabled = false;
            }
            console.error(e);
        }
    }
</script>
