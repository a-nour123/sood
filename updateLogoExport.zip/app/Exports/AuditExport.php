<?php

namespace App\Exports;

use Illuminate\Support\Collection;

class AuditExport extends BaseExportTemplate
{
    private Collection $rows;
    private array $headers;

    public function __construct($locale = null)
    {
        parent::__construct($locale);

        /**
         * get data
         */
        $data = collect(get_audit_trail());

        $this->rows = $data;

        /**
         * auto headers from first row
         */
        $this->headers = $data->isNotEmpty()
            ? array_keys($data->first())
            : [];
    }

    /**
     * data collection
     */
    public function collection()
    {
        return $this->rows;
    }

    /**
     * map row
     */
    public function map($row): array
    {
        return array_values((array) $row);
    }

    /**
     * headers
     */
    public function headings(): array
    {
        return array_map(function ($header) {
            return __("audit.$header"); // translation support
        }, $this->headers);
    }

    /**
     * dynamic column widths
     */
    public function columnWidths(): array
    {
        $widths = [];
        $letters = range('A', 'Z');

        foreach ($this->headers as $i => $header) {
            $widths[$letters[$i] ?? 'A'] = 25;
        }

        return $widths;
    }

    /**
     * optional styling
     */
    protected function applyCustomStyles($sheet)
    {
        $lastColumn = $this->getLastColumnLetter();

        $sheet->getStyle("A2:{$lastColumn}1000")
            ->getAlignment()
            ->setWrapText(true);
    }
}
