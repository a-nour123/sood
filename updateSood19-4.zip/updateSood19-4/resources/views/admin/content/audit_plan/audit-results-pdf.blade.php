<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}" dir="{{ app()->getLocale() == 'ar' ? 'rtl' : 'ltr' }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Audit Compliance Report</title>

    <!-- CSS Libraries -->
    <link rel="stylesheet" href="{{ asset('cdn/bootcss.css') }}">
    <link rel="stylesheet" href="build/css/intlTelInput.css" />
    <link rel="stylesheet" href="build/css/demo.css" />

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            font-size: 10pt;
            line-height: 1.4;
            color: #333333;
            background: #F5F5F5;
            padding: 20px;
        }

        /* RTL Specific Styles */
        html[dir="rtl"] body {
            font-family: 'Tajawal', 'Arial', sans-serif;
        }

        html[dir="rtl"] .export-button-container {
            right: auto;
            left: 20px;
        }

        html[dir="rtl"] .control-header-right {
            margin-right: auto;
            margin-left: 0;
        }

        html[dir="rtl"] .summary-grid {
            direction: rtl;
        }

        html[dir="rtl"] .data-table th,
        html[dir="rtl"] .data-table td,
        html[dir="rtl"] .details-table td {
            text-align: right;
        }

        html[dir="rtl"] .audit-info-header {
            text-align: right;
        }

        html[dir="rtl"] .audit-info-value {
            text-align: right;
        }

        html[dir="rtl"] .container {
            margin: 60px auto 0;
        }

        html[dir="rtl"] .control-header {
            flex-direction: row-reverse;
        }

        html[dir="rtl"] .footer {
            flex-direction: row-reverse;
        }

        /* Add Tajawal font for Arabic */
        @import url('https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap');

        .export-button-container {
            position: fixed;
            top: 20px;
            {% if app()->getLocale() == 'ar' %}
            left: 20px;
            {% else %}
            right: 20px;
            {% endif %}
            z-index: 1000;
        }

        .export-pdf-btn {
            background: linear-gradient(135deg, #555555 0%, #333333 100%);
            border: none;
            padding: 12px 30px;
            border-radius: 8px;
            color: white;
            font-weight: 600;
            font-size: 14px;
            box-shadow: 0 4px 15px rgba(51, 51, 51, 0.4);
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .export-pdf-btn:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(51, 51, 51, 0.6);
        }

        .export-pdf-btn:disabled {
            opacity: 0.7;
            cursor: not-allowed;
        }

        .container {
            max-width: 1200px;
            margin: 60px auto 0;
            background: white;
            border: 2px solid #555555;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }

        /* Loading Overlay */
        .loading-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            z-index: 9999;
            justify-content: center;
            align-items: center;
        }

        .loading-overlay.active {
            display: flex;
        }

        .loading-content {
            text-align: center;
            color: white;
        }

        .spinner {
            width: 60px;
            height: 60px;
            border: 5px solid rgba(255, 255, 255, 0.3);
            border-top: 5px solid #fff;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }
            100% {
                transform: rotate(360deg);
            }
        }

        .loading-text {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .loading-subtext {
            font-size: 14px;
            color: #ccc;
        }

        .progress-bar-container {
            width: 300px;
            height: 4px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 2px;
            margin: 20px auto 0;
            overflow: hidden;
        }

        .progress-bar {
            height: 100%;
            background: linear-gradient(90deg, #666666, #444444);
            width: 0%;
            transition: width 0.3s ease;
        }

        .main-title {
            background-color: #333333;
            color: #FFFFFF;
            text-align: center;
            padding: 15px;
            font-size: 18pt;
            font-weight: bold;
            border-bottom: 2px solid #444444;
        }

        .audit-info {
            display: table;
            width: 100%;
            border-collapse: collapse;
        }

        .audit-info-row {
            display: table-row;
        }

        .audit-info-cell {
            display: table-cell;
            padding: 8px 12px;
            border: 1px solid #D9D9D9;
            vertical-align: middle;
        }

        .audit-info-header {
            background-color: #E0E0E0;
            color: #333333;
            font-weight: bold;
            width: 15%;
        }

        .audit-info-value {
            color: #555555;
            width: 18%;
        }

        .summary-title {
            background-color: #555555;
            color: #FFFFFF;
            text-align: center;
            padding: 12px;
            font-size: 14pt;
            font-weight: bold;
            margin-top: 20px;
        }

        .summary-content {
            background-color: #F9F9F9;
            padding: 15px;
            border: 1px solid #D9D9D9;
        }

        .summary-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
            font-weight: bold;
        }

        .summary-item {
            text-align: center;
        }

        .summary-label {
            color: #555555;
            font-size: 9pt;
            margin-bottom: 5px;
        }

        .summary-value {
            color: #333333;
            font-size: 16pt;
        }

        .controls-title {
            background-color: #444444;
            color: #FFFFFF;
            text-align: center;
            padding: 12px;
            font-size: 14pt;
            font-weight: bold;
            margin-top: 20px;
        }

        .control-card {
            margin: 20px 0;
            border: 1px solid #D9D9D9;
        }

        .control-header {
            background-color: #666666;
            color: #FFFFFF;
            padding: 10px 15px;
            font-size: 12pt;
            font-weight: bold;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .control-header-left {
            flex: 1;
        }

        .control-header-right {
            display: flex;
            gap: 20px;
        }

        .control-status,
        .control-result {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .details-table {
            width: 100%;
            border-collapse: collapse;
        }

        .details-table td {
            padding: 8px 12px;
            border: 1px solid #D9D9D9;
        }

        .details-table .label-cell {
            background-color: #D0D0D0;
            font-weight: bold;
            color: #333333;
            width: 25%;
        }

        .details-table .value-cell {
            width: 25%;
            color: #555555;
        }

        .section-header {
            background-color: #888888;
            color: #FFFFFF;
            padding: 8px 15px;
            font-weight: bold;
            margin-top: 10px;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 5px;
        }

        .data-table thead {
            background-color: #D0D0D0;
        }

        .data-table th {
            padding: 8px 12px;
            border: 1px solid #D9D9D9;
            font-weight: bold;
            text-align: left;
            color: #333333;
        }

        .data-table td {
            padding: 8px 12px;
            border: 1px solid #D9D9D9;
            vertical-align: top;
            color: #555555;
        }

        .data-table tr:nth-child(even) {
            background-color: #F9F9F9;
        }

        /* Status Colors - Gray scale with subtle tints */
        .status-approved {
            color: #2E7D32;
            font-weight: bold;
        }

        .status-rejected {
            color: #C62828;
            font-weight: bold;
        }

        .status-review {
            color: #F57C00;
            font-weight: bold;
        }

        .status-closed {
            color: #2E7D32;
            font-weight: bold;
        }

        .status-open {
            color: #F57C00;
            font-weight: bold;
        }

        .evidence-image {
            max-width: 200px;
            max-height: 150px;
            border: 1px solid #D9D9D9;
            border-radius: 4px;
            display: block;
            margin: 5px 0;
        }

        .file-link {
            color: #555555;
            text-decoration: underline;
        }

        .file-link-modern {
            color: #555555;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 4px 8px;
            background: #F5F5F5;
            border: 1px solid #D9D9D9;
            border-radius: 4px;
            font-size: 9pt;
            transition: all 0.2s ease;
        }

        .file-link-modern:hover {
            background: #E0E0E0;
            border-color: #888888;
        }

        .status-badge {
            display: inline-block;
            padding: 2px 6px;
            background: #E0E0E0;
            color: #333333;
            border-radius: 3px;
            font-size: 8pt;
            font-weight: bold;
        }

        .footer {
            margin-top: 30px;
            padding: 15px;
            border-top: 2px solid #555555;
            display: flex;
            justify-content: space-between;
            font-size: 9pt;
            color: #666666;
        }

        .spacer {
            height: 15px;
        }

        .charts-section {
            padding: 20px;
            background: white;
        }

        .chart-container {
            margin: 20px 0;
            padding: 15px;
            border: 1px solid #D9D9D9;
            border-radius: 8px;
        }

        .chart-title {
            font-size: 14pt;
            font-weight: bold;
            color: #333333;
            margin-bottom: 15px;
            text-align: center;
        }

        /* Enhanced Print Styles */
        @media print {
            @page {
                size: A4;
                margin: 15mm 10mm 15mm 10mm;
            }

            * {
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
                color-adjust: exact !important;
            }

            body {
                padding: 0;
                margin: 0;
                background: white;
                font-size: 9pt;
            }

            .export-button-container {
                display: none !important;
            }

            .loading-overlay {
                display: none !important;
            }

            .container {
                max-width: 100%;
                margin: 0;
                border: none;
                box-shadow: none;
                background: white;
            }

            /* Page breaks */
            .control-card {
                page-break-inside: avoid;
                break-inside: avoid;
            }

            .summary-content {
                page-break-inside: avoid;
                break-inside: avoid;
            }

            .audit-info {
                page-break-inside: avoid;
                break-inside: avoid;
            }

            .section-header {
                page-break-after: avoid;
                break-after: avoid;
            }

            .data-table thead {
                display: table-header-group;
            }

            .data-table tr {
                page-break-inside: avoid;
                break-inside: avoid;
            }

            /* Preserve grayscale colors */
            .main-title {
                background-color: #333333 !important;
                color: #FFFFFF !important;
            }

            .audit-info-header {
                background-color: #E0E0E0 !important;
                color: #333333 !important;
            }

            .summary-title {
                background-color: #555555 !important;
                color: #FFFFFF !important;
            }

            .summary-content {
                background-color: #F9F9F9 !important;
            }

            .controls-title {
                background-color: #444444 !important;
                color: #FFFFFF !important;
            }

            .control-header {
                background-color: #666666 !important;
                color: #FFFFFF !important;
            }

            .section-header {
                background-color: #888888 !important;
                color: #FFFFFF !important;
            }

            .details-table .label-cell,
            .data-table thead {
                background-color: #D0D0D0 !important;
                color: #333333 !important;
            }

            .data-table tr:nth-child(even) {
                background-color: #F9F9F9 !important;
            }

            .status-approved {
                color: #2E7D32 !important;
            }

            .status-rejected {
                color: #C62828 !important;
            }

            .status-review {
                color: #F57C00 !important;
            }

            .status-closed {
                color: #2E7D32 !important;
            }

            .status-open {
                color: #F57C00 !important;
            }

            /* Images */
            .evidence-image {
                max-width: 150px;
                max-height: 100px;
                page-break-inside: avoid;
            }

            /* Tables */
            table {
                border-collapse: collapse !important;
            }

            td,
            th {
                border: 1px solid #D9D9D9 !important;
            }

            /* Footer */
            .footer {
                border-top: 2px solid #555555 !important;
            }

            /* Hide charts if not needed */
            .charts-section {
                display: none;
            }

            /* RTL Print Styles */
            html[dir="rtl"] .data-table th,
            html[dir="rtl"] .data-table td {
                text-align: right !important;
            }
        }
    </style>
</head>

<body>
<!-- Loading Overlay -->
<div class="loading-overlay" id="loadingOverlay">
    <div class="loading-content">
        <div class="spinner"></div>
        <div class="loading-text">{{ __('report.Preparing Print') }}</div>
        <div class="loading-subtext" id="loadingSubtext">{{ __('report.Please wait') }}</div>
        <div class="progress-bar-container">
            <div class="progress-bar" id="progressBar"></div>
        </div>
    </div>
</div>

<!-- Export Button -->
<div class="export-button-container">
    <button class="export-pdf-btn" id="printBtn" onclick="triggerPrint()">
        <i class="fas fa-print"></i> {{ __('report.Print Report') }}
    </button>
</div>

<div class="container">
    <!-- Main Title -->
    <div class="main-title">
        {{ __('report.AUDIT COMPLIANCE REPORT') }}
    </div>
    
    <div class="spacer"></div>
    
    <!-- Audit Information Section -->
    <div class="audit-info">
        <div class="audit-info-row">
            <div class="audit-info-cell audit-info-header">{{ __('report.Audit Name') }}:</div>
            <div class="audit-info-cell audit-info-value">{{ $auditData->audit_name }}</div>
            <div class="audit-info-cell audit-info-header">{{ __('report.Audit Type') }}:</div>
            <div class="audit-info-cell audit-info-value">
                {{ $auditData->audit_type == 1 ? __('locale.Internal') : __('locale.External') }}
            </div>
            <div class="audit-info-cell audit-info-header">{{ __('report.Audit Function') }}:</div>
            <div class="audit-info-cell audit-info-value">
                {{ $auditData->audit_function == 1 ? __('locale.New') : __('locale.Archieved') }}
            </div>
            <div class="audit-info-cell audit-info-header">{{ __('report.Generated') }}:</div>
            <div class="audit-info-cell audit-info-value">{{ $generatedDate }}</div>
        </div>
        <div class="audit-info-row">
            <div class="audit-info-cell audit-info-header">{{ __('report.Responsible') }}:</div>
            <div class="audit-info-cell audit-info-value" colspan="3">{{ $auditData->owner->name ?? 'N/A' }}</div>
            <div class="audit-info-cell audit-info-header">{{ __('report.Framework') }}:</div>
            <div class="audit-info-cell audit-info-value" colspan="3">
                {{ $auditData->frameworkaduit->name ?? 'N/A' }}
            </div>
        </div>
    </div>
    
    <!-- Executive Summary Section -->
    <div class="summary-title">
        {{ __('report.EXECUTIVE SUMMARY') }}
    </div>
    <div class="summary-content">
        <div class="summary-grid">
            <div class="summary-item">
                <div class="summary-label">{{ __('report.Total Controls') }}</div>
                <div class="summary-value">{{ $totalControls }}</div>
            </div>
            <div class="summary-item">
                <div class="summary-label">{{ __('report.Passed') }}</div>
                <div class="summary-value" style="color: #2E7D32;">{{ $passedControls }}</div>
            </div>
            <div class="summary-item">
                <div class="summary-label">{{ __('report.Failed') }}</div>
                <div class="summary-value" style="color: #C62828;">{{ $failedControls }}</div>
            </div>
            <div class="summary-item">
                <div class="summary-label">{{ __('report.Compliance Rate') }}</div>
                <div class="summary-value">{{ $complianceRate }}%</div>
            </div>
        </div>
    </div>
    
    <!-- Charts Section -->
    <div class="charts-section" style="display: none;">
        <div class="chart-container" id="donut-chart-total">
            <div class="chart-title">{{ __('report.Overall Compliance Status') }}</div>
        </div>
        <div class="chart-container" id="statusChart-container">
            <div class="chart-title">{{ __('report.Domain Compliance Statistics') }}</div>
        </div>
    </div>
    
    <!-- Controls Detail Section -->
    <div class="controls-title">
        {{ __('report.CONTROL DETAILS') }}
    </div>
    
    @foreach ($auditData->frameworkControlTestAudits as $index => $testAudit)
    <div class="control-card">
        <div class="control-header">
            <div class="control-header-left">
                {{ __('report.CONTROL') }} {{ $index + 1 }}: {{ $testAudit->name }}
            </div>
            <div class="control-header-right">
                <div class="control-status">
                    <span>{{ __('report.STATUS') }}:</span>
                    <span class="{{ $testAudit->action_status == 1 ? 'status-closed' : 'status-open' }}">
                        {{ $testAudit->action_status == 1 ? '✓ ' . __('report.CLOSED') : '⚠ ' . __('report.OPEN') }}
                    </span>
                </div>
                <div class="control-result">
                    <span>{{ __('report.RESULT') }}:</span>
                    <span>{{ $testAudit->FrameworkControlTestResult->testResult->name ?? 'N/A' }}</span>
                </div>
            </div>
        </div>
        
        <table class="details-table">
            <tr>
                <td class="label-cell">{{ __('report.Control ID') }}</td>
                <td class="value-cell">{{ $testAudit->id }}</td>
                <td class="label-cell">{{ __('report.Objectives') }}</td>
                <td class="value-cell">{{ $testAudit->controlAuditObjectives->count() }}</td>
            </tr>
            <tr>
                <td class="label-cell">{{ __('report.Created Date') }}</td>
                <td class="value-cell">{{ $testAudit->created_at ? $testAudit->created_at : '-' }}</td>
                <td class="label-cell">{{ __('report.Evidence Items') }}</td>
                <td class="value-cell">{{ $testAudit->controlAuditEvidences->count() }}</td>
            </tr>
            <tr>
                <td class="label-cell">{{ __('report.Last Updated') }}</td>
                <td class="value-cell">{{ $testAudit->updated_at ? $testAudit->updated_at : '-' }}</td>
                <td class="label-cell">{{ __('report.Completion') }}</td>
                <td class="value-cell">
                    @php
                        $totalItems = $testAudit->controlAuditObjectives->count() + $testAudit->controlAuditEvidences->count();
                        if ($totalItems === 0) {
                            $completionRate = 100;
                        } else {
                            $completedObjectives = $testAudit->controlAuditObjectives
                                ->whereNotNull('objective_audit_status')
                                ->where('objective_audit_status', '!=', 'no_action')
                                ->count();
                            $completedEvidence = $testAudit->controlAuditEvidences
                                ->whereNotNull('evidence_audit_status')
                                ->where('evidence_audit_status', '!=', 'no_action')
                                ->count();
                            $completionRate = round((($completedObjectives + $completedEvidence) / $totalItems) * 100);
                        }
                    @endphp
                    {{ $completionRate }}%
                </td>
            </tr>
        </table>
        
        @if ($testAudit->controlAuditObjectives->count() > 0)
        <div class="section-header">
            {{ __('report.CONTROL OBJECTIVES') }}
        </div>
        <table class="data-table">
            <thead>
                <tr>
                    <th style="width: 5%;">#</th>
                    <th style="width: 35%;">{{ __('report.Objective Name') }}</th>
                    <th style="width: 15%;">{{ __('report.Status') }}</th>
                    <th style="width: 30%;">{{ __('report.Comments') }}</th>
                    <th style="width: 15%;">{{ __('report.Assessment Date') }}</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($testAudit->controlAuditObjectives as $objIndex => $objective)
                <tr>
                    <td>{{ $objIndex + 1 }}</td>
                    <td>{{ $objective->controlControlObjective->objective->name ?? 'N/A' }}</td>
                    <td>
                        @php
                            $status = $objective->objective_audit_status;
                            $statusText = '';
                            $statusClass = '';
                            
                            if ($status === 'approved') {
                                $statusText = '✓ ' . __('report.APPROVED');
                                $statusClass = 'status-approved';
                            } elseif ($status === 'rejected') {
                                $statusText = '✗ ' . __('report.REJECTED');
                                $statusClass = 'status-rejected';
                            } elseif ($status === 'no_action') {
                                $statusText = '👁 ' . __('report.REVIEW');
                                $statusClass = 'status-review';
                            } else {
                                $statusText = '❓ ' . strtoupper($status ?? __('report.UNKNOWN'));
                                $statusClass = '';
                            }
                        @endphp
                        <span class="{{ $statusClass }}">{{ $statusText }}</span>
                    </td>
                    <td>{{ $objective->objective_audit_comments ?? '-' }}</td>
                    <td>{{ $objective->created_at ? $objective->created_at : '-' }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
        @endif
        
        @if ($testAudit->controlAuditEvidences->count() > 0)
        <div class="section-header">
            {{ __('report.SUPPORTING EVIDENCE') }}
        </div>
        <table class="data-table">
            <thead>
                <tr>
                    <th style="width: 4%;">#</th>
                    <th style="width: 20%;">{{ __('report.Evidence Name') }}</th>
                    <th style="width: 12%;">{{ __('report.Status') }}</th>
                    <th style="width: 25%;">{{ __('report.Description') }}</th>
                    <th style="width: 12%;">{{ __('report.Upload Date') }}</th>
                    <th style="width: 8%;">{{ __('report.File Type') }}</th>
                    <th style="width: 19%;">{{ __('report.File') }}</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($testAudit->controlAuditEvidences as $evIndex => $evidence)
                <tr>
                    <td>{{ $evIndex + 1 }}</td>
                    <td>{{ $evidence->evidence->file_name ?? 'N/A' }}</td>
                    <td>
                        @php
                            $status = $evidence->evidence_audit_status;
                            $statusText = '';
                            $statusClass = '';
                            
                            if ($status === 'approved') {
                                $statusText = '✓ ' . __('report.APPROVED');
                                $statusClass = 'status-approved';
                            } elseif ($status === 'rejected') {
                                $statusText = '✗ ' . __('report.REJECTED');
                                $statusClass = 'status-rejected';
                            } elseif ($status === 'no_action') {
                                $statusText = '👁 ' . __('report.REVIEW');
                                $statusClass = 'status-review';
                            } else {
                                $statusText = '❓ ' . strtoupper($status ?? __('report.UNKNOWN'));
                                $statusClass = '';
                            }
                        @endphp
                        <span class="{{ $statusClass }}">{{ $statusText }}</span>
                    </td>
                    <td>{{ $evidence->evidence->description ?? '-' }}</td>
                    <td>{{ $evidence->created_at ? $evidence->created_at : '-' }}</td>
                    <td>
                        @php
                            $fileName = $evidence->evidence->file_name ?? 'N/A';
                            $fileType = strtoupper(pathinfo($fileName, PATHINFO_EXTENSION));
                        @endphp
                        <span class="status-badge">{{ $fileType }}</span>
                    </td>
                    <td>
                        @php
                            $evidenceId = $evidence->evidence->id ?? null;
                            $fileName = $evidence->evidence->file_name ?? 'N/A';
                            $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp'];
                            $extension = $fileName ? strtolower(pathinfo($fileName, PATHINFO_EXTENSION)) : '';
                            $isImage = in_array($extension, $imageExtensions);
                        @endphp
                        @if ($evidenceId)
                            @if ($isImage)
                                <a href="javascript:void(0);" data-evidence-id="{{ $evidenceId }}" class="file-link-modern download-evidence-file" title="{{ $fileName }}">
                                    <i class="fas fa-image"></i> {{ __('report.View Image') }}
                                </a>
                            @else
                                <a href="javascript:void(0);" data-evidence-id="{{ $evidenceId }}" class="file-link-modern download-evidence-file">
                                    <i class="fas fa-download"></i> {{ __('report.Download') }}
                                </a>
                            @endif
                        @else
                            <span style="color: #9ca3af;">{{ __('report.No File') }}</span>
                        @endif
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
        @endif
    </div>
    @endforeach
    
    <div class="footer">
        <div>{{ __('report.Generated by Audit System') }}</div>
        <div>{{ __('report.Confidential') }}</div>
        <div>{{ __('report.Page 1 of 1') }}</div>
    </div>
</div>

<script src="{{ asset('cdn/jquery-3.6.0.min.js') }}"></script>

<script>
    // Get current language
    var currentLang = document.documentElement.lang || 'en';
    
    // Trigger print dialog on page load
    window.addEventListener('load', function() {
        // Wait a short moment for all content to render
        setTimeout(function() {
            window.print();
        }, 500);
    });

    // Function to manually trigger print
    function triggerPrint() {
        window.print();
    }

    // Handle Ctrl+P keyboard shortcut
    document.addEventListener('keydown', function(e) {
        if ((e.ctrlKey || e.metaKey) && e.key === 'p') {
            e.preventDefault();
            window.print();
        }
    });
    
    // Handle evidence file download/view
    $(document).on('click', '.download-evidence-file', function(e) {
        e.preventDefault();
        var evidenceId = $(this).data('evidence-id');
        if (evidenceId) {
            viewEvidenceFile(evidenceId);
        }
    });

    // Function to view/download evidence file
    function viewEvidenceFile(evidenceId) {
        var url = "{{ route('admin.compliance.ajax.download_evidence_file', '') }}" + "/" + evidenceId;
        window.open(url, '_blank', 'noopener,noreferrer');
    }

    // Adjust text alignment based on language
    function adjustForLanguage() {
        if (currentLang === 'ar') {
            // Additional RTL adjustments if needed
            $('.control-header').css('flex-direction', 'row-reverse');
            $('.footer').css('flex-direction', 'row-reverse');
        }
    }

    // Call on document ready
    $(document).ready(function() {
        adjustForLanguage();
    });
</script>
</body>
</html>