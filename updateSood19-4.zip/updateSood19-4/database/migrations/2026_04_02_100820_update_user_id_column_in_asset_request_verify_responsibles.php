<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class UpdateUserIdColumnInAssetRequestVerifyResponsibles extends Migration
{
    public function up()
    {
        Schema::table('asset_request_verify_responsibles', function (Blueprint $table) {

            // حذف الـ foreign key
            $table->dropForeign(['user_id']);

            // حذف العمود القديم
            $table->dropColumn('user_id');

            // إضافة العمود الجديد
            $table->text('user_ids')->nullable();
        });
    }

    public function down()
    {
        Schema::table('asset_request_verify_responsibles', function (Blueprint $table) {

            // رجوع العمود القديم
            $table->unsignedBigInteger('user_id')->nullable();

            // رجوع الـ foreign key
            $table->foreign('user_id')
                ->references('id')
                ->on('users')
                ->onDelete('cascade');

            // حذف العمود الجديد
            $table->dropColumn('user_ids');
        });
    }
}