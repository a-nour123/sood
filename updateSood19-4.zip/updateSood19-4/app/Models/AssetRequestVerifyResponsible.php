<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AssetRequestVerifyResponsible extends Model
{
    use HasFactory;
    protected $table = 'asset_request_verify_responsibles';
    protected $fillable = [
        'user_ids',
    ];
}
