<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithColumnWidths;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithDrawings;
use Maatwebsite\Excel\Events\AfterSheet;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;
use App\Models\AuditResponsible;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\App;

class AuditResultsExport implements FromArray, WithStyles, WithColumnWidths, WithEvents, WithDrawings
{
    protected $auditData;
    protected $currentRow = 1;
    protected $controlStartRows = [];
    protected $totalRows = 0;
    protected $drawings = [];
    protected $evidenceData = [];
    protected $imagePositions = [];
    protected $isRTL = false;
    protected $title;
    protected $description;

    public function __construct($auditId)
    {
        $this->auditData = AuditResponsible::with([
            'frameworkControlTestAudits.FrameworkControlTestResult.testResult',
            'frameworkControlTestAudits.controlAuditEvidences.evidence',
            'frameworkControlTestAudits.controlAuditObjectives.controlControlObjective.objective',
            'frameworkControlTestAudits.controlAuditObjectives.controlControlObjective.responsibleUser',
            'frameworkControlTestAudits.controlAuditObjectives.controlControlObjective.responsibleTeam'
        ])->findOrFail($auditId);

        // Check if current locale is Arabic (RTL)
        $this->isRTL = App::getLocale() == 'ar';
        
        // Set title and description
        $this->title = __('report.AUDIT COMPLIANCE REPORT');
        $this->description = sprintf(
            __('report.Audit Report for %s - Generated on %s'),
            $this->auditData->audit_name,
            date('Y-m-d H:i:s')
        );

        // Prepare evidence data for easy access
        $this->prepareEvidenceData();
    }

    protected function prepareEvidenceData()
    {
        $this->evidenceData = [];
        $rowCounter = 1;

        foreach ($this->auditData->frameworkControlTestAudits as $testAudit) {
            foreach ($testAudit->controlAuditEvidences as $evidence) {
                $this->evidenceData[$rowCounter] = [
                    'file_path' => $evidence->evidence->file_unique_name ?? null,
                    'file_name' => $evidence->evidence->file_name ?? 'N/A'
                ];
                $rowCounter++;
            }
        }
    }

    public function drawings()
    {
        return $this->drawings;
    }

    public function array(): array
    {
        $data = [];
        $currentDataRow = 0;

        // Report Header Section with Title
        $data[] = [$this->title, '', '', '', '', '', '', '', '', '', '', '', ''];
        $currentDataRow += 1;

        // Description row
        $data[] = [$this->description, '', '', '', '', '', '', '', '', '', '', '', ''];
        $currentDataRow += 1;

        // Empty spacer row
        $data[] = ['', '', '', '', '', '', '', '', '', '', '', '', ''];
        $currentDataRow += 1;

        // Audit Information Section
        $data[] = [
            __('report.Audit Name') . ':',
            $this->auditData->audit_name,
            __('report.Audit Type') . ':',
            $this->getAuditTypeText($this->auditData->audit_type),
            __('report.Audit Function') . ':',
            $this->getAuditFunctionText($this->auditData->audit_function),
            __('report.Generated') . ':',
            date('Y-m-d H:i:s'),
            '',
            '',
            '',
            '',
            ''
        ];
        $data[] = [
            __('report.Responsible') . ':',
            $this->auditData->owner->name,
            '',
            __('report.Framework') . ':',
            $this->auditData->frameworkaduit->name,
            '',
            '',
            '',
            '',
            '',
            '',
            '',
            ''
        ];
        $data[] = ['', '', '', '', '', '', '', '', '', '', '', '', ''];
        $currentDataRow += 3;

        // Summary Section
        $totalControls = $this->auditData->frameworkControlTestAudits->count();
        $passedControls = $this->auditData->frameworkControlTestAudits->where('action_status', 1)->count();
        $failedControls = $totalControls - $passedControls;

        $data[] = [__('report.EXECUTIVE SUMMARY'), '', '', '', '', '', '', '', '', '', '', '', ''];
        $data[] = ['', '', '', '', '', '', '', '', '', '', '', '', ''];
        $data[] = [
            __('report.Total Controls') . ':',
            $totalControls,
            '',
            __('report.Passed') . ':',
            $passedControls,
            '',
            __('report.Failed') . ':',
            $failedControls,
            '',
            '',
            '',
            '',
            ''
        ];
        $data[] = [
            __('report.Compliance Rate') . ':',
            round(($passedControls / max($totalControls, 1)) * 100, 2) . '%',
            '',
            '',
            '',
            '',
            '',
            '',
            '',
            '',
            '',
            '',
            ''
        ];
        $data[] = ['', '', '', '', '', '', '', '', '', '', '', '', ''];
        $currentDataRow += 5;

        // Controls Detail Section
        $data[] = [__('report.CONTROL DETAILS'), '', '', '', '', '', '', '', '', '', '', '', ''];
        $data[] = ['', '', '', '', '', '', '', '', '', '', '', '', ''];
        $currentDataRow += 2;

        foreach ($this->auditData->frameworkControlTestAudits as $index => $testAudit) {
            $this->controlStartRows[] = $currentDataRow;

            // Control Header with enhanced information
            $data[] = ['', '', '', '', '', '', '', '', '', '', '', '', ''];
            $currentDataRow += 1;

            $data[] = [
                __('report.CONTROL') . ' ' . ($index + 1),
                $testAudit->name,
                '',
                __('report.STATUS') . ':',
                $this->getStatusOpenClosedText($testAudit->action_status),
                __('report.RESULT') . ':',
                $testAudit->FrameworkControlTestResult->testResult->name ?? 'N/A',
                '',
                '',
                '',
                '',
                '',
                ''
            ];
            $currentDataRow += 1;

            $data[] = ['', '', '', '', '', '', '', '', '', '', '', '', ''];
            $currentDataRow += 1;

            // Control Details Table
            $data[] = ['', __('report.Attribute'), __('report.Value'), '', __('report.Metrics'), __('report.Count'), '', '', '', '', '', '', ''];
            $data[] = ['', __('report.Control ID'), $testAudit->id, '', __('report.Objectives'), $testAudit->controlAuditObjectives->count(), '', '', '', '', '', '', ''];
            $data[] = ['', __('report.Created Date'), $this->formatDate($testAudit->created_at), '', __('report.Evidence Items'), $testAudit->controlAuditEvidences->count(), '', '', '', '', '', '', ''];
            $data[] = ['', __('report.Last Updated'), $this->formatDate($testAudit->updated_at), '', __('report.Completion'), $this->calculateCompletionRate($testAudit) . '%', '', '', '', '', '', '', ''];
            $data[] = ['', '', '', '', '', '', '', '', '', '', '', '', ''];
            $currentDataRow += 5;

            // Objectives Section
            if ($testAudit->controlAuditObjectives->count() > 0) {
                $data[] = ['', __('report.CONTROL OBJECTIVES'), '', '', '', '', '', '', '', '', '', '', ''];
                $data[] = ['', '', '', '', '', '', '', '', '', '', '', '', ''];
                $data[] = ['', '#', __('report.Objective Name'), __('report.Status'), __('report.Responsible Type'), __('report.Responsible'), __('report.Due Date'), __('report.Comments'), __('report.Assessment Date'), '', '', '', ''];
                $currentDataRow += 3;

                foreach ($testAudit->controlAuditObjectives as $objIndex => $objective) {
                    $controlObjective = $objective->controlControlObjective;
                    $responsibleType = $controlObjective->responsible_type ?? 'N/A';
                    $responsible = 'N/A';

                    if ($responsibleType === 'user' && $controlObjective->responsibleUser) {
                        $responsible = $controlObjective->responsibleUser->name;
                    } elseif ($responsibleType === 'team' && $controlObjective->responsibleTeam) {
                        $responsible = $controlObjective->responsibleTeam->name;
                    } elseif ($responsibleType === 'manager') {
                        $responsible = $controlObjective->responsibleUser->name;
                    }

                    $dueDate = $controlObjective->due_date ? $this->formatDate($controlObjective->due_date) : '-';

                    $data[] = [
                        '',
                        $objIndex + 1,
                        $controlObjective->objective->name ?? 'N/A',
                        $this->getObjectiveStatus($objective->objective_audit_status),
                        $this->getResponsibleTypeText($responsibleType),
                        $responsible,
                        $dueDate,
                        $objective->objective_audit_comments ?? '-',
                        $this->formatDate($objective->created_at),
                        '',
                        '',
                        '',
                        ''
                    ];
                    $currentDataRow += 1;
                }
                $data[] = ['', '', '', '', '', '', '', '', '', '', '', '', ''];
                $currentDataRow += 1;
            }

            // Evidence Section
            if ($testAudit->controlAuditEvidences->count() > 0) {
                $data[] = ['', __('report.SUPPORTING EVIDENCE'), '', '', '', '', '', '', '', '', '', '', ''];
                $data[] = ['', '', '', '', '', '', '', '', '', '', '', '', ''];
                $data[] = ['', '#', __('report.Evidence Name'), __('report.Status'), __('report.Description'), __('report.Upload Date'), __('report.File Type'), __('report.File'), '', '', '', '', ''];
                $currentDataRow += 3;

                foreach ($testAudit->controlAuditEvidences as $evIndex => $evidence) {
                    $fileName = $evidence->evidence->file_name ?? 'N/A';
                    $filePath = $evidence->evidence->file_unique_name ?? null;
                    $fileType = pathinfo($fileName, PATHINFO_EXTENSION);

                    $exists = $filePath ? Storage::disk('local')->exists($filePath) : false;
                    $isImage = $exists ? $this->isImageFile($filePath) : false;
                    $fileCellValue = $exists ? ($isImage ? '' : __('report.View File')) : __('report.File Missing');

                    $data[] = [
                        '',
                        $evIndex + 1,
                        $fileName,
                        $this->getEvidenceStatus($evidence->evidence_audit_status),
                        $evidence->evidence->description ?? '-',
                        $this->formatDate($evidence->created_at),
                        strtoupper($fileType),
                        $fileCellValue,
                        '',
                        '',
                        '',
                        '',
                        ''
                    ];
                    $currentDataRow += 1;

                    if ($exists && $isImage) {
                        $drawing = new Drawing();
                        $drawing->setName($fileName);
                        $drawing->setDescription($evidence->evidence->description ?? '');
                        $drawing->setPath(storage_path('app/' . $filePath));

                        list($width, $height) = getimagesize(storage_path('app/' . $filePath));
                        $ratio = $width / $height;
                        if ($ratio > 1) {
                            $drawing->setWidth(200);
                            $drawing->setHeight(200 / $ratio);
                        } else {
                            $drawing->setHeight(200);
                            $drawing->setWidth(200 * $ratio);
                        }

                        $excelRowNumber = $currentDataRow;
                        $drawing->setCoordinates('H' . $excelRowNumber);
                        $this->imagePositions[] = $excelRowNumber;
                        $this->drawings[] = $drawing;
                    }
                }
                $data[] = ['', '', '', '', '', '', '', '', '', '', '', '', ''];
                $currentDataRow += 1;
            }
        }

        $currentDataRow += 4;
        $this->totalRows = count($data);
        return $data;
    }

    public function styles(Worksheet $sheet)
    {
        $horizontalAlignment = $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_LEFT;

        return [
            'A:M' => [
                'font' => ['size' => 10],
                'alignment' => [
                    'vertical' => Alignment::VERTICAL_CENTER,
                    'horizontal' => $horizontalAlignment
                ]
            ]
        ];
    }

    public function columnWidths(): array
    {
        return [
            'A' => 14, 'B' => 30, 'C' => 25, 'D' => 18, 'E' => 25,
            'F' => 25, 'G' => 15, 'H' => 30, 'I' => 15, 'J' => 25,
            'K' => 15, 'L' => 20, 'M' => 25
        ];
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event) {
                $sheet = $event->sheet->getDelegate();
                
                // Add logo
                $this->addLogo($sheet);
                
                // Set RTL if needed
                if ($this->isRTL) {
                    $sheet->setRightToLeft(true);
                }
                
                // Apply all styles
                $this->styleTitleAndDescription($sheet);
                $this->styleAuditInfo($sheet);
                $this->styleSummarySection($sheet);
                $this->styleControlsSection($sheet);
                $this->applyGeneralFormatting($sheet);
                
                // Add hyperlinks for non-image files
                for ($row = 1; $row <= $this->totalRows; $row++) {
                    $cellValue = $sheet->getCell('H' . $row)->getValue();
                    if ($cellValue === __('report.View File')) {
                        $sheet->getStyle('H' . $row)
                            ->getFont()
                            ->setColor(new \PhpOffice\PhpSpreadsheet\Style\Color(\PhpOffice\PhpSpreadsheet\Style\Color::COLOR_BLUE))
                            ->setUnderline(true);
                    }
                }
                
                // Auto-fit row heights
                for ($row = 1; $row <= $this->totalRows; $row++) {
                    $sheet->getRowDimension($row)->setRowHeight(-1);
                }
                
                // Set specific row heights for rows with images
                foreach ($this->imagePositions as $imageRow) {
                    $sheet->getRowDimension($imageRow)->setRowHeight(150);
                }
                
                // Enable text wrapping
                $horizontalAlignment = $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_LEFT;
                $sheet->getStyle('A1:M' . $this->totalRows)
                    ->getAlignment()
                    ->setWrapText(true)
                    ->setHorizontal($horizontalAlignment);
                
                // Add footer
                if ($this->isRTL) {
                    $sheet->getHeaderFooter()
                        ->setOddFooter('&R' . __('report.Generated by Audit System') . ' &C' . __('report.Confidential') . ' &L' . __('report.Page') . ' &P ' . __('report.of') . ' &N');
                } else {
                    $sheet->getHeaderFooter()
                        ->setOddFooter('&L' . __('report.Generated by Audit System') . ' &C' . __('report.Confidential') . ' &R' . __('report.Page') . ' &P ' . __('report.of') . ' &N');
                }
            }
        ];
    }

    protected function addLogo($sheet)
    {
        try {
            $drawing = new Drawing();
            $drawing->setName('Logo');
            $drawing->setDescription('Company Logo');
            
            $logoPath = public_path('images/ksu-logo.png');
            
            if (!file_exists($logoPath)) {
                $alternativePaths = [
                    public_path('logo.png'),
                    public_path('images/logo.png'),
                    public_path('img/logo.png'),
                    public_path('assets/images/logo.png')
                ];
                
                foreach ($alternativePaths as $path) {
                    if (file_exists($path)) {
                        $logoPath = $path;
                        break;
                    }
                }
            }
            
            if (file_exists($logoPath)) {
                $drawing->setPath($logoPath);
                $drawing->setHeight(60);
                $drawing->setCoordinates('M1');
                $drawing->setWorksheet($sheet);
                $sheet->getColumnDimension('M')->setWidth(25);
            }
        } catch (\Exception $e) {
            // Logo not added, continue silently
        }
    }

    protected function styleTitleAndDescription($sheet)
    {
        $horizontalAlignment = $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_CENTER;
        
        // Title styling - Dark Gray
        $sheet->mergeCells('A1:M1');
        $sheet->getStyle('A1:M1')->applyFromArray([
            'font' => ['bold' => true, 'size' => 18, 'color' => ['rgb' => 'FFFFFF']],
            'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => '333333']],
            'alignment' => ['horizontal' => $horizontalAlignment, 'vertical' => Alignment::VERTICAL_CENTER]
        ]);
        $sheet->getRowDimension(1)->setRowHeight(35);
        
        // Description styling - Light Gray
        $sheet->mergeCells('A2:M2');
        $sheet->getStyle('A2:M2')->applyFromArray([
            'font' => ['size' => 10, 'italic' => true, 'color' => ['rgb' => '666666']],
            'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'F5F5F5']],
            'alignment' => ['horizontal' => $horizontalAlignment, 'vertical' => Alignment::VERTICAL_CENTER]
        ]);
        $sheet->getRowDimension(2)->setRowHeight(25);
    }

    protected function styleAuditInfo($sheet)
    {
        $infoRows = [4, 5];
        
        foreach ($infoRows as $row) {
            // Style labels - Medium Gray
            $sheet->getStyle("A{$row}:B{$row}")->applyFromArray([
                'font' => ['bold' => true, 'color' => ['rgb' => '333333']],
                'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'E0E0E0']]
            ]);
            
            $sheet->getStyle("D{$row}:E{$row}")->applyFromArray([
                'font' => ['bold' => true, 'color' => ['rgb' => '333333']],
                'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'E0E0E0']]
            ]);
            
            $sheet->getStyle("G{$row}:H{$row}")->applyFromArray([
                'font' => ['bold' => true, 'color' => ['rgb' => '333333']],
                'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'E0E0E0']]
            ]);
            
            // Style values - Light Gray
            $sheet->getStyle("B{$row}")->applyFromArray([
                'font' => ['color' => ['rgb' => '555555']],
                'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'FAFAFA']]
            ]);
            
            $sheet->getStyle("E{$row}")->applyFromArray([
                'font' => ['color' => ['rgb' => '555555']],
                'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'FAFAFA']]
            ]);
            
            $sheet->getStyle("H{$row}")->applyFromArray([
                'font' => ['color' => ['rgb' => '555555']],
                'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'FAFAFA']]
            ]);
        }
    }

    protected function styleSummarySection($sheet)
    {
        $horizontalAlignment = $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_CENTER;
        
        // Summary title - Dark Gray
        $sheet->mergeCells('A7:M7');
        $sheet->getStyle('A7:M7')->applyFromArray([
            'font' => ['bold' => true, 'size' => 14, 'color' => ['rgb' => 'FFFFFF']],
            'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => '555555']],
            'alignment' => ['horizontal' => $horizontalAlignment, 'vertical' => Alignment::VERTICAL_CENTER]
        ]);
        
        // Summary data - Very Light Gray
        $sheet->getStyle('A9:M12')->applyFromArray([
            'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'F9F9F9']],
            'font' => ['bold' => true, 'color' => ['rgb' => '444444']]
        ]);
    }

    protected function styleControlsSection($sheet)
    {
        $horizontalAlignment = $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_CENTER;
        
        // Controls section title - Dark Gray
        $sheet->mergeCells('A13:M13');
        $sheet->getStyle('A13:M13')->applyFromArray([
            'font' => ['bold' => true, 'size' => 14, 'color' => ['rgb' => 'FFFFFF']],
            'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => '444444']],
            'alignment' => ['horizontal' => $horizontalAlignment, 'vertical' => Alignment::VERTICAL_CENTER]
        ]);
        
        // Style control headers
        for ($row = 15; $row <= $this->totalRows; $row++) {
            $cellValue = $sheet->getCell('A' . $row)->getValue();
            
            if (strpos($cellValue, __('report.CONTROL') . ' ') === 0) {
                $sheet->getStyle("A{$row}:M{$row}")->applyFromArray([
                    'font' => ['bold' => true, 'size' => 12, 'color' => ['rgb' => 'FFFFFF']],
                    'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => '666666']]
                ]);
                $sheet->getRowDimension($row)->setRowHeight(25);
            }
            
            // Section headers
            $bCellValue = $sheet->getCell('B' . $row)->getValue();
            if (in_array($bCellValue, [__('report.CONTROL OBJECTIVES'), __('report.SUPPORTING EVIDENCE')])) {
                $sheet->getStyle("B{$row}:K{$row}")->applyFromArray([
                    'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
                    'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => '888888']]
                ]);
            }
            
            // Table headers
            if ($bCellValue === '#' || $bCellValue === __('report.Attribute')) {
                $sheet->getStyle("A{$row}:M{$row}")->applyFromArray([
                    'font' => ['bold' => true, 'color' => ['rgb' => '333333']],
                    'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'D0D0D0']]
                ]);
            }
        }
    }

    protected function applyGeneralFormatting($sheet)
    {
        $horizontalAlignment = $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_LEFT;
        
        // Apply borders
        $sheet->getStyle('A1:M' . $this->totalRows)
            ->getBorders()
            ->getOutline()
            ->setBorderStyle(Border::BORDER_MEDIUM);
        
        // Apply thin borders to content cells
        for ($row = 4; $row <= $this->totalRows; $row++) {
            if (!empty($sheet->getCell('B' . $row)->getValue())) {
                $sheet->getStyle("A{$row}:M{$row}")
                    ->getBorders()
                    ->getAllBorders()
                    ->setBorderStyle(Border::BORDER_THIN);
            }
        }
    }

    private function isImageFile($filePath)
    {
        $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg'];
        $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
        return in_array($extension, $imageExtensions);
    }

    private function getResponsibleTypeText($type)
    {
        if ($type === 'user') return __('report.User');
        if ($type === 'team') return __('report.Team');
        if ($type === 'manager') return __('report.Manager');
        return __('report.N/A');
    }

    private function formatDate($date)
    {
        if (!$date) return '-';
        if (is_string($date)) {
            try {
                return date('M j, Y', strtotime($date));
            } catch (Exception $e) {
                return $date;
            }
        }
        if (method_exists($date, 'format')) {
            return $date->format('M j, Y');
        }
        return '-';
    }

    private function calculateCompletionRate($testAudit)
    {
        $totalItems = $testAudit->controlAuditObjectives->count() + $testAudit->controlAuditEvidences->count();
        if ($totalItems === 0) return 100;
        
        $completedObjectives = $testAudit->controlAuditObjectives
            ->whereNotNull('objective_audit_status')
            ->where('objective_audit_status', '!=', 'no_action')
            ->count();
        
        $completedEvidence = $testAudit->controlAuditEvidences
            ->whereNotNull('evidence_audit_status')
            ->where('evidence_audit_status', '!=', 'no_action')
            ->count();
        
        return round((($completedObjectives + $completedEvidence) / $totalItems) * 100);
    }

    private function getStatusOpenClosedText($status)
    {
        return $status == 1 ? '✓ ' . __('report.CLOSED') : '⚠ ' . __('report.OPEN');
    }

    private function getObjectiveStatus($status)
    {
        $statuses = [
            'approved' => '✓ ' . __('report.APPROVED'),
            'rejected' => '✗ ' . __('report.REJECTED'),
            'no_action' => '👁 ' . __('report.REVIEW')
        ];
        return $statuses[$status] ?? '❓ ' . strtoupper($status ?? __('report.UNKNOWN'));
    }

    private function getEvidenceStatus($status)
    {
        $statuses = [
            'approved' => '✓ ' . __('report.APPROVED'),
            'rejected' => '✗ ' . __('report.REJECTED'),
            'no_action' => '👁 ' . __('report.REVIEW')
        ];
        return $statuses[$status] ?? '❓ ' . strtoupper($status ?? __('report.UNKNOWN'));
    }

    private function getAuditTypeText($type)
    {
        return $type == 1 ? __('report.Internal') : __('report.External');
    }

    private function getAuditFunctionText($type)
    {
        return $type == 1 ? __('report.New') : __('report.Archieved');
    }
}