<?php

namespace App\Exports;

use App\Models\Incident;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Color;
use Illuminate\Support\Facades\App;

class IncidentExport extends BaseExportTemplate
{
    private $locale;
    private array $rows = [];
    protected $filters;

    public function __construct(array $filters = [], $locale = null)
    {
        $this->locale = $locale ?? App::getLocale();
        $this->filters = $filters;

        $title = $this->getTitleByFilters($filters);
        $description = $this->getDescriptionByFilters($filters);

        parent::__construct($this->locale, $title, $description);

        // Load and process incidents
        $incidents = $this->loadIncidents();

        foreach ($incidents as $incident) {
            $this->rows[] = $this->processIncident($incident);
        }
    }

    /**
     * Get title based on applied filters
     */
    private function getTitleByFilters(array $filters): string
    {
        $baseTitle = __('locale.Incidents Report');

        if (!empty($filters['status'])) {
            $status = ucfirst($filters['status']);
            $statusText = __('locale.' . $status);
            if ($statusText == 'locale.' . $status) {
                $statusText = $status;
            }
            return __('locale.Incidents Report') . ' - ' . $statusText;
        }

        return $baseTitle;
    }

    /**
     * Get description based on applied filters
     */
    private function getDescriptionByFilters(array $filters): string
    {
        $parts = [];

        if (!empty($filters['direction_id'])) {
            $parts[] = __('locale.Direction filtered');
        }
        if (!empty($filters['attack_id'])) {
            $parts[] = __('locale.Attack type filtered');
        }
        if (!empty($filters['detected_id'])) {
            $parts[] = __('locale.Detection source filtered');
        }
        if (!empty($filters['play_book_id'])) {
            $parts[] = __('locale.Playbook filtered');
        }
        if (!empty($filters['status'])) {
            $parts[] = __('locale.Status') . ': ' . ucfirst($filters['status']);
        }
        if (!empty($filters['date_from']) && !empty($filters['date_to'])) {
            $parts[] = __('locale.Date range') . ': ' . $filters['date_from'] . ' ' . __('locale.to') . ' ' . $filters['date_to'];
        } elseif (!empty($filters['date_from'])) {
            $parts[] = __('locale.From date') . ': ' . $filters['date_from'];
        } elseif (!empty($filters['date_to'])) {
            $parts[] = __('locale.To date') . ': ' . $filters['date_to'];
        }

        if (empty($parts)) {
            return __('locale.This report contains all security incidents with their details and status');
        }

        return __('locale.This report contains security incidents') . ' ' . implode(', ', $parts);
    }

    /**
     * Load incidents with filters applied
     */
    private function loadIncidents()
    {
        $query = Incident::query();

        if (!empty($this->filters['direction_id'])) {
            $query->where('direction_id', $this->filters['direction_id']);
        }
        if (!empty($this->filters['attack_id'])) {
            $query->where('attack_id', $this->filters['attack_id']);
        }
        if (!empty($this->filters['detected_id'])) {
            $query->where('detected_id', $this->filters['detected_id']);
        }
        if (!empty($this->filters['play_book_id'])) {
            $query->where('play_book_id', $this->filters['play_book_id']);
        }
        if (!empty($this->filters['status'])) {
            $query->where('status', $this->filters['status']);
        }
        if (!empty($this->filters['date_from'])) {
            $query->whereDate('created_at', '>=', $this->filters['date_from']);
        }
        if (!empty($this->filters['date_to'])) {
            $query->whereDate('created_at', '<=', $this->filters['date_to']);
        }

        return $query->with([
            'occurrence',
            'direction',
            'attack',
            'detected',
            'tlpLevel',
            'papLevel'
        ])->orderBy('created_at', 'desc')->get();
    }

    /**
     * Process a single incident
     */
    private function processIncident($incident)
    {
        // Translate status
        $status = $this->translateIncidentStatus($incident->status);

        // Format detected on date
        $detectedOn = $incident->detected_on
            ? date('Y-m-d', strtotime($incident->detected_on))
            : __('locale.Not specified');

        // Format created at
        $createdAt = $incident->created_at
            ? $incident->created_at->format('Y-m-d H:i:s')
            : __('locale.N/A');

        // Get priority with color indication
        $priority = $incident->total_score ?? __('locale.Not calculated');
        $priorityLevel = $this->getPriorityLevel($incident->total_score);

        // Get related entity names with fallbacks
        $occurrence = optional($incident->occurrence)->name ?? __('locale.N/A');
        $direction = optional($incident->direction)->name ?? __('locale.N/A');
        $attack = optional($incident->attack)->name ?? __('locale.N/A');
        $detectedBy = optional($incident->detected)->name ?? __('locale.N/A');
        $tlpLevel = optional($incident->tlpLevel)->name ?? __('locale.Not set');
        $papLevel = optional($incident->papLevel)->name ?? __('locale.Not set');

        return (object)[
            'summary' => $incident->summary ?? __('locale.No summary provided'),
            'occurrence' => $occurrence,
            'direction' => $direction,
            'attack' => $attack,
            'detected_by' => $detectedBy,
            'detected_on' => $detectedOn,
            'tlp_level' => $tlpLevel,
            'pap_level' => $papLevel,
            'priority' => $priority,
            'priority_level' => $priorityLevel,
            'status' => $status,
            'created_at' => $createdAt,
        ];
    }

    /**
     * Translate incident status
     */
    private function translateIncidentStatus($status)
    {
        if (empty($status)) {
            return __('locale.Unknown');
        }

        $statusMap = [
            'new' => 'locale.New',
            'investigating' => 'locale.Investigating',
            'contained' => 'locale.Contained',
            'eradicated' => 'locale.Eradicated',
            'recovered' => 'locale.Recovered',
            'closed' => 'locale.Closed',
        ];

        $key = $statusMap[$status] ?? 'locale.' . ucfirst($status);
        $translated = __($key);

        if ($translated == $key) {
            $translated = ucfirst(str_replace('_', ' ', $status));
        }

        return $translated;
    }

    /**
     * Get priority level based on score
     */
    private function getPriorityLevel($score)
    {
        if ($score === null) {
            return __('locale.Not calculated');
        }

        if ($score >= 8) {
            return __('locale.Critical');
        } elseif ($score >= 6) {
            return __('locale.High');
        } elseif ($score >= 4) {
            return __('locale.Medium');
        } elseif ($score >= 2) {
            return __('locale.Low');
        } else {
            return __('locale.Very Low');
        }
    }

    /**
     * Return filtered incidents collection
     */
    public function collection()
    {
        return collect($this->rows);
    }

    /**
     * Map each incident row
     */
    public function map($row): array
    {
        return [
            $this->getCounter(),
            $row->summary,
            $row->occurrence,
            $row->direction,
            $row->attack,
            $row->detected_by,
            $row->detected_on,
            $row->tlp_level,
            $row->pap_level,
            $row->priority,
            $row->status,
            $row->created_at,
        ];
    }

    /**
     * Column headings
     */
    public function headings(): array
    {
        if ($this->isRTL) {
            return [
                '#',
                __('locale.Summary'),
                __('locale.Occurrence'),
                __('locale.Direction'),
                __('locale.Attack'),
                __('locale.DetectedBy'),
                __('locale.DetectedOn'),
                __('locale.TLP'),
                __('locale.PAP'),
                __('locale.Priority'),
                __('locale.Status'),
                __('locale.CreatedAt'),
            ];
        }

        return [
            '#',
            __('locale.Summary'),
            __('locale.Occurrence'),
            __('locale.Direction'),
            __('locale.Attack Type'),
            __('locale.Detected By'),
            __('locale.Detected On'),
            __('locale.TLP Level'),
            __('locale.PAP Level'),
            __('locale.Priority Score'),
            __('locale.Status'),
            __('locale.Created At'),
        ];
    }

    /**
     * Column widths
     * 
     * Data starts at column A:
     *   A = # (counter)
     *   B = Summary
     *   C = Occurrence
     *   D = Direction
     *   E = Attack Type
     *   F = Detected By
     *   G = Detected On
     *   H = TLP Level
     *   I = PAP Level
     *   J = Priority Score
     *   K = Status
     *   L = Created At
     */
    public function columnWidths(): array
    {
        return [
            'A' => 6,   // #
            'B' => 50,  // Summary
            'C' => 20,  // Occurrence
            'D' => 20,  // Direction
            'E' => 20,  // Attack Type
            'F' => 25,  // Detected By
            'G' => 18,  // Detected On
            'H' => 12,  // TLP Level
            'I' => 12,  // PAP Level
            'J' => 18,  // Priority Score
            'K' => 18,  // Status
            'L' => 20,  // Created At
        ];
    }

    /**
     * Apply wrap text to long text columns
     */
    protected function applyCustomStyles(Worksheet $sheet)
    {
        $highestRow = $sheet->getHighestRow();

        // Determine header row number (accounting for title and description)
        $headerRow = 1;
        if ($this->title) {
            $headerRow = $this->description ? 3 : 2;
        }
        $dataStartRow = $headerRow + 1;

        // Wrap text for Summary, Occurrence, Direction, Attack Type, Detected By
        $wrapColumns = ['B', 'C', 'D', 'E', 'F'];
        foreach ($wrapColumns as $col) {
            $sheet->getStyle("{$col}{$dataStartRow}:{$col}{$highestRow}")
                ->getAlignment()
                ->setWrapText(true);
        }

        // Auto row heights for data rows
        for ($row = $dataStartRow; $row <= $highestRow; $row++) {
            $sheet->getRowDimension($row)->setRowHeight(-1);
        }
    }
}
