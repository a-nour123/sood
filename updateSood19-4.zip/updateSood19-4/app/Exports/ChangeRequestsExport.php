<?php

namespace App\Exports;

use App\Models\ChangeRequest;
use App\Models\Department;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Color;
use Illuminate\Support\Facades\App;

class ChangeRequestsExport extends BaseExportTemplate
{
    private $locale;
    private array $rows = [];

    public function __construct($locale = null)
    {
        $this->locale = $locale ?? App::getLocale();

        $title = __('locale.Change Requests Report');
        $description = __('locale.This report contains all change requests with their status and review cycle details');

        parent::__construct($this->locale, $title, $description);

        $this->rows = $this->buildCollection();
    }
    /**
     * Translate status with proper formatting
     */
    private function translateStatus($status)
    {
        $statusKey = 'locale.' . $status;
        $translated = __($statusKey);

        // If translation not found, format the status nicely
        if ($translated == $status) {
            $translated = str_replace('_', ' ', $status);
            $translated = ucwords($translated);
        }

        return $translated;
    }

    /**
     * Translate review cycle with proper formatting
     */
    private function translateReviewCycle($cycle)
    {
        $cycleKey = 'locale.' . $cycle;
        $translated = __($cycleKey);

        // If translation not found, format the cycle nicely
        if ($translated == $cycle) {
            $translated = str_replace('-', ' ', $cycle);
            $translated = ucwords($translated);
        }

        return $translated;
    }

    /**
     * main data builder
     */
    private function buildCollection()
    {
        $currentUserId = auth()->id();

        $managerIds = Department::pluck('manager_id')->toArray();
        $currentUserIsDepartmentManager = in_array($currentUserId, $managerIds);

        $currentUserIsInResponsibleDepartment =
            auth()->id() == change_requests_responsible_department_manager_id();

        /**
         * queries
         */
        if ($currentUserIsInResponsibleDepartment) {
            $_changeRequests = ChangeRequest::with('created_by_user:id,username')
                ->where('review_cycle', 'Responsible-Department-Review')
                ->get();
        } elseif ($currentUserIsDepartmentManager) {
            $departments = Department::where('manager_id', $currentUserId)->get();

            $employees = [];
            foreach ($departments as $department) {
                $employees = array_merge(
                    $employees,
                    $department->employees()
                        ->where('id', '<>', $currentUserId)
                        ->pluck('id')
                        ->toArray()
                );
            }

            $_changeRequests = ChangeRequest::with('created_by_user:id,username,department_id')
                ->whereIn('created_by', $employees)
                ->where('review_cycle', 'Department-Manager-Review')
                ->orWhere('created_by', $currentUserId)
                ->get();
        } else {
            $_changeRequests = ChangeRequest::with('created_by_user:id,username,department_id')
                ->where('created_by', $currentUserId)
                ->get();
        }

        /**
         * mapping output rows
         */
        $rows = [];
        foreach ($_changeRequests as $cr) {
            $creatorName = $cr->created_by_user->username ?? __('locale.N/A');

            // Check if the creator is the current user
            $creator = ($creatorName == auth()->user()->username)
                ? __('locale.Me')
                : $creatorName;

            // Get status with proper translation
            $status = $this->translateStatus($cr->status);

            // Get review cycle with proper translation
            $cycle = $this->translateReviewCycle($cr->review_cycle);

            // Format rejection reason or set N/A
            $reason = $cr->rejection_reason ?? __('locale.N/A');

            $rows[] = (object)[
                'title' => $cr->title,
                'description' => $cr->description ?? __('locale.No Description'),
                'creator' => $creator,
                'file' => $cr->display_file_name ?? __('locale.No File'),
                'status' => $status,
                'reason' => $reason,
                'cycle' => $cycle,
                'date' => $cr->created_at->format('Y-m-d H:i'),
            ];
        }

        return $rows;
    }

    /**
     * collection
     */
    public function collection()
    {
        return collect($this->rows);
    }

    /**
     * map rows
     */
    public function map($row): array
    {
        return [
            $this->getCounter(),
            $row->title,
            $row->description,
            $row->creator,
            $row->file,
            $row->status,
            $row->reason,
            $row->cycle,
            $row->date,
        ];
    }

    /**
     * headers
     */
    public function headings(): array
    {
        if ($this->isRTL) {
            return [
                '#',
                __('locale.Title'),
                __('locale.Description'),
                __('locale.CreatedBy'),
                __('locale.File'),
                __('locale.Status'),
                __('locale.Reason'),
                __('locale.ReviewCycle'),
                __('locale.CreatedDate'),
            ];
        }

        return [
            '#',
            __('locale.Title'),
            __('locale.Description'),
            __('locale.Created By'),
            __('locale.File'),
            __('locale.Status'),
            __('locale.Rejection Reason'),
            __('locale.Review Cycle'),
            __('locale.Created Date'),
        ];
    }

    /**
     * column widths
     * 
     * Data starts at column A:
     *   A = # (counter)
     *   B = Title
     *   C = Description
     *   D = Created By
     *   E = File
     *   F = Status
     *   G = Reason
     *   H = Review Cycle
     *   I = Created Date
     */
    public function columnWidths(): array
    {
        return [
            'A' => 6,   // #
            'B' => 30,  // Title
            'C' => 50,  // Description
            'D' => 25,  // Created By
            'E' => 30,  // File
            'F' => 20,  // Status
            'G' => 40,  // Reason
            'H' => 25,  // Review Cycle
            'I' => 20,  // Created Date
        ];
    }

    /**
     * custom styling
     */
    protected function applyCustomStyles(Worksheet $sheet)
    {
        $highestRow = $sheet->getHighestRow();

        // Determine header row number (accounting for title and description)
        $headerRow = 1;
        if ($this->title) {
            $headerRow = $this->description ? 3 : 2;
        }
        $dataStartRow = $headerRow + 1;

        // Wrap text for Description, Reason, and Title
        $wrapColumns = ['B', 'C', 'G'];
        foreach ($wrapColumns as $col) {
            $sheet->getStyle("{$col}{$dataStartRow}:{$col}{$highestRow}")
                ->getAlignment()
                ->setWrapText(true);
        }

        // Auto row heights for data rows
        for ($row = $dataStartRow; $row <= $highestRow; $row++) {
            $sheet->getRowDimension($row)->setRowHeight(-1);
        }
    }
}
