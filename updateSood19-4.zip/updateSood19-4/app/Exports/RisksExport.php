<?php

namespace App\Exports;

use App\Models\Impact;
use App\Models\Likelihood;
use App\Models\Risk;
use App\Models\RiskLevel;
use App\Models\ScoringMethod;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Color;
use Illuminate\Support\Facades\App;

class RisksExport extends BaseExportTemplate
{
    private $locale;
    private array $rows = [];

    public function __construct($locale = null)
    {
        $this->locale = $locale ?? App::getLocale();

        $title = __('locale.Risks Report');
        $description = __('locale.This report contains all risks with their assessments, scoring, and mitigation status');

        parent::__construct($this->locale, $title, $description);

        // Load and process risks
        $risks = Risk::with(['riskScoring', 'source', 'submittedBy:id,name'])->get();
        
        foreach ($risks as $risk) {
            $this->rows[] = $this->processRisk($risk);
        }
    }

    /**
     * Process a single risk
     */
    private function processRisk($risk)
    {
        // Get calculated risk values
        $calculatedRisk = $risk->riskScoring->calculated_risk ?? "0.0";
        $residualRisk = ($calculatedRisk && $calculatedRisk != "0.0") 
            ? get_residual_risk($risk->id) 
            : "0.0";

        // Get risk level data
        $calculatedRiskData = $this->getRiskValueData($calculatedRisk);
        $residualRiskData = $this->getRiskValueData($residualRisk);

        // Format risk values with level names
        $calculatedRiskFormatted = $calculatedRisk . ' (' . $calculatedRiskData['name'] . ')';
        $residualRiskFormatted = $residualRisk . ' (' . $residualRiskData['name'] . ')';

        // Get risk catalogs and threat catalogs
        $riskCatalogs = $risk->riskCatalogs();
        $threatCatalogs = $risk->threatCatalog();

        // Get related entity names with fallbacks
        $likelihood = Likelihood::find($risk->riskScoring->CLASSIC_likelihood ?? null)?->name 
            ?? __('locale.Not assessed');
            
        $impact = Impact::find($risk->riskScoring->CLASSIC_impact ?? null)?->name 
            ?? __('locale.Not assessed');
            
        $scoringMethod = ScoringMethod::find($risk->riskScoring->scoring_method ?? null)?->name 
            ?? __('locale.Not specified');
            
        $source = $risk->source?->name ?? __('locale.Not specified');
        $submittedBy = $risk->submittedBy?->name ?? __('locale.Unknown');
        
        // Format created date
        $createdAt = $risk->created_at 
            ? $risk->created_at->format('Y-m-d H:i')
            : __('locale.N/A');
            
        // Translate status
        $status = $this->translateRiskStatus($risk->status);
        
        // Get risk level colors for styling
        $calculatedRiskColor = $calculatedRiskData['color'] ?? 'white';
        $residualRiskColor = $residualRiskData['color'] ?? 'white';

        return (object)[
            'status' => $status,
            'status_raw' => $risk->status,
            'subject' => $risk->subject ?? __('locale.No subject'),
            'calculated_risk' => $calculatedRiskFormatted,
            'calculated_risk_value' => (float)$calculatedRisk,
            'calculated_risk_level' => $calculatedRiskData['name'],
            'calculated_risk_color' => $calculatedRiskColor,
            'residual_risk' => $residualRiskFormatted,
            'residual_risk_value' => (float)$residualRisk,
            'residual_risk_level' => $residualRiskData['name'],
            'residual_risk_color' => $residualRiskColor,
            'scoring_method' => $scoringMethod,
            'likelihood' => $likelihood,
            'impact' => $impact,
            'riskCatalogs' => $riskCatalogs,
            'threatCatalogs' => $threatCatalogs,
            'source' => $source,
            'submitted_by' => $submittedBy,
            'created_at' => $createdAt,
        ];
    }

    /**
     * Translate risk status
     */
    private function translateRiskStatus($status)
    {
        if (empty($status)) {
            return __('locale.Unknown');
        }
        
        $statusMap = [
            'open' => 'locale.Open',
            'in_progress' => 'locale.In Progress',
            'mitigated' => 'locale.Mitigated',
            'closed' => 'locale.Closed',
            'accepted' => 'locale.Accepted',
            'rejected' => 'locale.Rejected',
        ];
        
        $key = $statusMap[$status] ?? 'locale.' . ucfirst(str_replace('_', ' ', $status));
        $translated = __($key);
        
        if ($translated == $key) {
            $translated = ucfirst(str_replace('_', ' ', $status));
        }
        
        return $translated;
    }

    /**
     * Return collection
     */
    public function collection()
    {
        return collect($this->rows);
    }

    /**
     * Map each row
     */
    public function map($risk): array
    {
        $riskCatalogsNames = !empty($risk->riskCatalogs) 
            ? implode(', ', array_map(fn($r) => $r['name'], $risk->riskCatalogs))
            : __('locale.No vulnerabilities mapped');
            
        $threatCatalogsNames = !empty($risk->threatCatalogs) 
            ? implode(', ', array_map(fn($t) => $t['name'], $risk->threatCatalogs))
            : __('locale.No threats mapped');

        return [
            $this->getCounter(),
            $risk->status,
            $risk->subject,
            $risk->calculated_risk,
            $risk->residual_risk,
            $risk->scoring_method,
            $risk->likelihood,
            $risk->impact,
            $riskCatalogsNames,
            $threatCatalogsNames,
            $risk->source,
            $risk->submitted_by,
            $risk->created_at,
        ];
    }

    /**
     * Column headings
     */
    public function headings(): array
    {
        if ($this->isRTL) {
            return [
                '#',
                __('locale.Status'),
                __('locale.Subject'),
                __('locale.InherentRisk'),
                __('locale.ResidualRisk'),
                __('locale.RiskScoringMethod'),
                __('locale.CurrentLikelihood'),
                __('locale.CurrentImpact'),
                __('locale.VulnerabilityMapping'),
                __('locale.ThreatMapping'),
                __('locale.ImpactScope'),
                __('locale.SubmittedBy'),
                __('locale.SubmissionDate'),
            ];
        }

        return [
            '#',
            __('locale.Status'),
            __('locale.Risk Subject'),
            __('locale.Inherent Risk'),
            __('locale.Residual Risk'),
            __('locale.Scoring Method'),
            __('locale.Likelihood'),
            __('locale.Impact'),
            __('locale.Vulnerability Mapping'),
            __('locale.Threat Mapping'),
            __('locale.Risk Source'),
            __('locale.Submitted By'),
            __('locale.Submission Date'),
        ];
    }

    /**
     * Column widths
     * 
     * Data starts at column A:
     *   A = # (counter)
     *   B = Status
     *   C = Risk Subject
     *   D = Inherent Risk
     *   E = Residual Risk
     *   F = Scoring Method
     *   G = Likelihood
     *   H = Impact
     *   I = Vulnerability Mapping
     *   J = Threat Mapping
     *   K = Risk Source
     *   L = Submitted By
     *   M = Submission Date
     */
    public function columnWidths(): array
    {
        return [
            'A' => 6,   // #
            'B' => 18,  // Status
            'C' => 45,  // Risk Subject
            'D' => 22,  // Inherent Risk
            'E' => 22,  // Residual Risk
            'F' => 25,  // Scoring Method
            'G' => 20,  // Likelihood
            'H' => 20,  // Impact
            'I' => 45,  // Vulnerability Mapping
            'J' => 45,  // Threat Mapping
            'K' => 25,  // Risk Source
            'L' => 25,  // Submitted By
            'M' => 20,  // Submission Date
        ];
    }

    /**
     * Apply wrap text for long text columns
     */
protected function applyCustomStyles(Worksheet $sheet)
{
    $highestRow = $sheet->getHighestRow();

    // Determine header row number (accounting for title and description)
    $headerRow = 1;
    if ($this->title) {
        $headerRow = $this->description ? 3 : 2;
    }
    $dataStartRow = $headerRow + 1;

    // Wrap text for long text columns
    $wrapColumns = ['C', 'I', 'J'];
    foreach ($wrapColumns as $col) {
        $sheet->getStyle("{$col}{$dataStartRow}:{$col}{$highestRow}")
            ->getAlignment()
            ->setWrapText(true);
    }

    // Auto row heights for data rows
    for ($row = $dataStartRow; $row <= $highestRow; $row++) {
        $sheet->getRowDimension($row)->setRowHeight(-1);
    }
}

    /**
     * Color a risk cell based on its value
     */
    private function colorRiskCell($sheet, $cell, $value)
    {
        // Extract risk level from parentheses
        if (preg_match('/\((.*?)\)/', $value, $matches)) {
            $riskLevel = trim($matches[1]);
            
            // Color based on risk level
            if (stripos($riskLevel, 'critical') !== false || stripos($riskLevel, 'very high') !== false) {
                $sheet->getStyle($cell)->getFont()->setColor(new Color(Color::COLOR_DARKRED));
                $sheet->getStyle($cell)->getFont()->setBold(true);
            } elseif (stripos($riskLevel, 'high') !== false) {
                $sheet->getStyle($cell)->getFont()->setColor(new Color('FF6B6B')); // Light Red
                $sheet->getStyle($cell)->getFont()->setBold(true);
            } elseif (stripos($riskLevel, 'medium') !== false) {
                $sheet->getStyle($cell)->getFont()->setColor(new Color('FFA500')); // Orange
            } elseif (stripos($riskLevel, 'low') !== false) {
                $sheet->getStyle($cell)->getFont()->setColor(new Color('008000')); // Green
            } elseif (stripos($riskLevel, 'insignificant') !== false) {
                $sheet->getStyle($cell)->getFont()->setColor(new Color('999999')); // Gray
                $sheet->getStyle($cell)->getFont()->setItalic(true);
            }
        }
    }

    /**
     * Return a risk level data.
     */
    protected function getRiskValueData($calculated_risk)
    {
        $riskLevel = RiskLevel::orderBy('value', 'desc')
            ->where('value', '<=', $calculated_risk)
            ->first();

        if (!$riskLevel) {
            return [
                'name' => __('locale.Insignificant'), 
                'color' => 'white'
            ];
        }

        return [
            'name' => $riskLevel->display_name ?: $riskLevel->name ?: __('locale.Insignificant'),
            'color' => $riskLevel->color ?? 'white'
        ];
    }
}