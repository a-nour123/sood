<?php

namespace App\Exports;

use App\Models\CybersecurityRequest;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;

class CybersecurityRequestsExport extends BaseExportTemplate
{
    private $locale;
    private array $rows = [];
    private array $filters = [];

    /**
     * Constructor
     * 
     * @param array $filters Optional filters (status, priority, department, date_from, date_to)
     * @param string|null $locale
     */
    public function __construct(array $filters = [], ?string $locale = null)
    {
        $this->locale = $locale ?? App::getLocale();
        $this->filters = $filters;

        $title = $this->getTitleByFilters($filters);
        $description = $this->getDescriptionByFilters($filters);

        parent::__construct($this->locale, $title, $description);

        // Load and process requests
        $requests = $this->loadRequests();
        
        foreach ($requests as $request) {
            $this->rows[] = $this->processRequest($request);
        }
    }

    /**
     * Helper method to translate text
     */
    private function translate($key)
    {
        $currentLocale = App::getLocale();
        App::setLocale($this->locale);
        $translated = __($key);
        App::setLocale($currentLocale);

        if ($translated == $key) {
            $parts = explode('.', $key);
            $translated = end($parts);
            if ($this->locale === 'en') {
                $translated = str_replace('_', ' ', $translated);
                $translated = ucwords($translated);
            }
        }

        return $translated;
    }

    /**
     * Check if current user has admin permission
     */
    private function isAdmin(): bool
    {
        $user = Auth::user();
        return $user && ($user->hasPermission('cybersecurity_requests.view_all') || $user->role_id === 1);
    }

    /**
     * Get title based on applied filters
     */
    private function getTitleByFilters(array $filters): string
    {
        $baseTitle = __('locale.Cybersecurity Requests Report');
        
        if (!empty($filters['status'])) {
            $status = ucfirst(str_replace('_', ' ', $filters['status']));
            return $baseTitle . ' - ' . $status;
        }
        
        if (!empty($filters['priority'])) {
            return $baseTitle . ' - ' . ucfirst($filters['priority']) . ' ' . __('locale.Priority');
        }
        
        return $baseTitle;
    }

    /**
     * Get description based on applied filters
     */
    private function getDescriptionByFilters(array $filters): string
    {
        $parts = [];
        
        if (!empty($filters['status'])) {
            $parts[] = __('locale.Status') . ': ' . ucfirst(str_replace('_', ' ', $filters['status']));
        }
        if (!empty($filters['priority'])) {
            $parts[] = __('locale.Priority') . ': ' . ucfirst($filters['priority']);
        }
        if (!empty($filters['department'])) {
            $parts[] = __('locale.Department') . ': ' . $filters['department'];
        }
        if (!empty($filters['date_from']) && !empty($filters['date_to'])) {
            $parts[] = __('locale.Date range') . ': ' . $filters['date_from'] . ' ' . __('locale.to') . ' ' . $filters['date_to'];
        } elseif (!empty($filters['date_from'])) {
            $parts[] = __('locale.From date') . ': ' . $filters['date_from'];
        } elseif (!empty($filters['date_to'])) {
            $parts[] = __('locale.To date') . ': ' . $filters['date_to'];
        }
        
        // Add scope information to description
        if (!$this->isAdmin()) {
            $parts[] = __('locale.Showing only your requests and requests assigned to you');
        }
        
        if (empty($parts)) {
            return __('locale.This report contains all cybersecurity requests with their status, priority, and processing details');
        }
        
        return __('locale.This report contains cybersecurity requests') . ' ' . implode(', ', $parts);
    }

    /**
     * Load requests with filters applied and proper permissions
     */
    private function loadRequests(): Collection
    {
        $user = Auth::user();
        $query = CybersecurityRequest::with([
            'requester:id,name,email',
            'assignedUser:id,name,email',
            'approver:id,name,email',
            'requestType:id,name',
            'requestReason:id,name',
            'department:id,name',
            'requesterDepartment:id,name'
        ]);

        // Apply permission-based filtering
        if (!$this->isAdmin()) {
            // Non-admin users can only see:
            // 1. Requests they created (requester_id = user id)
            // 2. Requests assigned to them (assigned_to = user id)
            $query->where(function ($q) use ($user) {
                $q->where('requester_id', $user->id)
                  ->orWhere('assigned_to', $user->id);
            });
        }

        // Apply additional filters
        if (!empty($this->filters['status'])) {
            $query->where('status', $this->filters['status']);
        }
        if (!empty($this->filters['priority'])) {
            $query->where('priority', $this->filters['priority']);
        }
        if (!empty($this->filters['department'])) {
            $query->where('receiving_department', $this->filters['department']);
        }
        if (!empty($this->filters['requester_id'])) {
            // Only apply requester_id filter if admin or if it's the user's own ID
            if ($this->isAdmin() || $this->filters['requester_id'] == $user->id) {
                $query->where('requester_id', $this->filters['requester_id']);
            }
        }
        if (!empty($this->filters['assigned_to'])) {
            // Only apply assigned_to filter if admin or if it's the user's own ID
            if ($this->isAdmin() || $this->filters['assigned_to'] == $user->id) {
                $query->where('assigned_to', $this->filters['assigned_to']);
            }
        }
        if (!empty($this->filters['date_from'])) {
            $query->whereDate('created_at', '>=', $this->filters['date_from']);
        }
        if (!empty($this->filters['date_to'])) {
            $query->whereDate('created_at', '<=', $this->filters['date_to']);
        }

        return $query->orderBy('created_at', 'desc')->get();
    }

    /**
     * Process a single cybersecurity request
     */
    private function processRequest($request)
    {
        // Translate status
        $status = $this->translateRequestStatus($request->status);
        
        // Translate priority
        $priority = $this->translatePriority($request->priority);
        
        // Get related data with fallbacks
        $requesterName = $request->requester?->name ?? __('locale.Unknown');
        $requesterEmail = $request->requester?->email ?? __('locale.N/A');
        $assignedTo = $request->assignedUser?->name ?? __('locale.Not assigned');
        $approvedBy = $request->approver?->name ?? __('locale.Not approved');
        $requestType = $request->requestType?->name ?? __('locale.N/A');
        $requestReason = $request->requestReason?->name ?? __('locale.N/A');
        $receivingDept = $request->department?->name ?? $request->receiving_department ?? __('locale.N/A');
        $requesterDept = $request->requesterDepartment?->name ?? $request->requester_department ?? __('locale.N/A');
        
        // Format dates
        $createdAt = $request->created_at ? $request->created_at->format('Y-m-d H:i') : __('locale.N/A');
        $dueDate = $request->due_date ? date('Y-m-d', strtotime($request->due_date)) : __('locale.Not set');
        $approvedAt = $request->approved_at ? date('Y-m-d H:i', strtotime($request->approved_at)) : __('locale.N/A');
        $completedAt = $request->completed_at ? date('Y-m-d H:i', strtotime($request->completed_at)) : __('locale.N/A');
        
        // Clean description
        $description = $request->description 
            ? strip_tags($request->description) 
            : __('locale.No description');
        
        // Get additional info
        $processingTime = $request->getProcessingTime();
        $processingTimeText = $processingTime ? $processingTime . ' ' . __('locale.days') : __('locale.N/A');
        
        $isLate = $request->isLate();
        $lateStatus = $isLate ? __('locale.Yes') : __('locale.No');
        
        $approvalNotes = $request->approval_notes ?? __('locale.N/A');

        return (object)[
            'request_number' => $request->request_number,
            'request_type' => $requestType,
            'request_reason' => $requestReason,
            'subject' => $request->subject ?? __('locale.No subject'),
            'description' => $description,
            'requester_name' => $requesterName,
            'requester_email' => $requesterEmail,
            'requester_department' => $requesterDept,
            'receiving_department' => $receivingDept,
            'assigned_to' => $assignedTo,
            'priority' => $priority,
            'priority_raw' => $request->priority,
            'status' => $status,
            'status_raw' => $request->status,
            'due_date' => $dueDate,
            'is_late' => $lateStatus,
            'processing_time' => $processingTimeText,
            'approved_by' => $approvedBy,
            'approved_at' => $approvedAt,
            'approval_notes' => $approvalNotes,
            'completed_at' => $completedAt,
            'created_at' => $createdAt,
        ];
    }

    /**
     * Translate request status
     */
    private function translateRequestStatus($status)
    {
        if (empty($status)) {
            return __('locale.Unknown');
        }
        
        $statusMap = [
            'created' => 'locale.Created',
            'under management approval' => 'locale.Under Management Approval',
            'approved' => 'locale.Approved',
            'under process' => 'locale.Under Process',
            'planned' => 'locale.Planned',
            'returned' => 'locale.Returned',
            'closed' => 'locale.Closed',
            'rejected' => 'locale.Rejected',
        ];
        
        $key = $statusMap[$status] ?? 'locale.' . ucfirst(str_replace(' ', '_', $status));
        $translated = __($key);
        
        if ($translated == $key) {
            $translated = ucfirst(str_replace('_', ' ', $status));
        }
        
        return $translated;
    }

    /**
     * Translate priority
     */
    private function translatePriority($priority)
    {
        $priorityMap = [
            'High' => 'locale.High',
            'Moderate' => 'locale.Moderate',
            'Low' => 'locale.Low',
        ];
        
        $key = $priorityMap[$priority] ?? 'locale.' . ucfirst($priority);
        $translated = __($key);
        
        if ($translated == $key) {
            $translated = ucfirst($priority);
        }
        
        return $translated;
    }

    /**
     * Return collection
     */
    public function collection()
    {
        return collect($this->rows);
    }

    /**
     * Map each request to export row
     */
    public function map($row): array
    {
        return [
            $this->getCounter(),
            $row->request_number,
            $row->request_type,
            $row->request_reason,
            $row->subject,
            $row->description,
            $row->requester_name,
            $row->requester_email,
            $row->requester_department,
            $row->receiving_department,
            $row->assigned_to,
            $row->priority,
            $row->status,
            $row->due_date,
            $row->is_late,
            $row->processing_time,
            $row->approved_by,
            $row->approved_at,
            $row->completed_at,
            $row->created_at,
        ];
    }

    /**
     * Column headings
     */
    public function headings(): array
    {
        if ($this->isRTL) {
            return [
                '#',
                __('locale.RequestNumber'),
                __('locale.RequestType'),
                __('locale.RequestReason'),
                __('locale.Subject'),
                __('locale.Description'),
                __('locale.Requester'),
                __('locale.RequesterEmail'),
                __('locale.RequesterDepartment'),
                __('locale.ReceivingDepartment'),
                __('locale.AssignedTo'),
                __('locale.Priority'),
                __('locale.Status'),
                __('locale.DueDate'),
                __('locale.IsLate'),
                __('locale.ProcessingTime'),
                __('locale.ApprovedBy'),
                __('locale.ApprovedAt'),
                __('locale.CompletedAt'),
                __('locale.CreatedAt'),
            ];
        }

        return [
            '#',
            __('locale.Request Number'),
            __('locale.Request Type'),
            __('locale.Request Reason'),
            __('locale.Subject'),
            __('locale.Description'),
            __('locale.Requester Name'),
            __('locale.Requester Email'),
            __('locale.Requester Department'),
            __('locale.Receiving Department'),
            __('locale.Assigned To'),
            __('locale.Priority'),
            __('locale.Status'),
            __('locale.Due Date'),
            __('locale.Late Request'),
            __('locale.Processing Time'),
            __('locale.Approved By'),
            __('locale.Approval Date'),
            __('locale.Completion Date'),
            __('locale.Created Date'),
        ];
    }

    /**
     * Column widths
     */
    public function columnWidths(): array
    {
        return [
            'A' => 6,   // #
            'B' => 18,  // Request Number
            'C' => 20,  // Request Type
            'D' => 20,  // Request Reason
            'E' => 35,  // Subject
            'F' => 50,  // Description
            'G' => 25,  // Requester Name
            'H' => 30,  // Requester Email
            'I' => 25,  // Requester Department
            'J' => 25,  // Receiving Department
            'K' => 25,  // Assigned To
            'L' => 12,  // Priority
            'M' => 22,  // Status
            'N' => 15,  // Due Date
            'O' => 12,  // Is Late
            'P' => 15,  // Processing Time
            'Q' => 25,  // Approved By
            'R' => 20,  // Approval Date
            'S' => 20,  // Completion Date
            'T' => 20,  // Created Date
        ];
    }

    /**
     * Apply custom styles
     */
    protected function applyCustomStyles(Worksheet $sheet)
    {
        $highestRow = $sheet->getHighestRow();

        // Determine header row number (accounting for title and description)
        $headerRow = 1;
        if ($this->title) {
            $headerRow = $this->description ? 3 : 2;
        }
        $dataStartRow = $headerRow + 1;

        // Wrap text for Subject, Description columns
        $wrapColumns = ['E', 'F'];
        foreach ($wrapColumns as $col) {
            $sheet->getStyle("{$col}{$dataStartRow}:{$col}{$highestRow}")
                ->getAlignment()
                ->setWrapText(true);
        }

        // Auto row heights for data rows
        for ($row = $dataStartRow; $row <= $highestRow; $row++) {
            $sheet->getRowDimension($row)->setRowHeight(-1);
        }
    }
}