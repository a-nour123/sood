<?php

namespace App\Exports;

use App\Models\AssetGroup;
use Maatwebsite\Excel\Concerns\WithProperties;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use Illuminate\Support\Facades\App;

class AssetGroupsExport extends BaseExportTemplate implements WithProperties
{
    use \App\Traits\LaravelExportPropertiesTrait;

    private $locale;
    private array $rows = [];

    /**
     * Constructor to initialize properties
     */
    public function __construct($locale = null)
    {
        $this->locale = $locale ?? App::getLocale();

        $title = __('locale.Asset Groups Report');
        $description = __('locale.This report contains all asset groups with their associated assets');

        parent::__construct($this->locale, $title, $description);

        $assetGroups = AssetGroup::with('assets')->get();

        foreach ($assetGroups as $assetGroup) {
            $assetGroupAssetsNames = $assetGroup->assets->pluck('name')->toArray();
            
            if (count($assetGroupAssetsNames)) {
                $assetGroupAssetsNames = "(" . implode('), (', $assetGroupAssetsNames) . ")";
            } else {
                $assetGroupAssetsNames = __('locale.No Assets');
            }

            $this->rows[] = (object)[
                'name' => $assetGroup->name,
                'assets' => $assetGroupAssetsNames,
            ];
        }
    }

    /**
     * @return \Illuminate\Support\Collection
     */
    public function collection()
    {
        return collect($this->rows);
    }

    /**
     * @var object $row
     */
    public function map($row): array
    {
        return [
            $this->getCounter(),
            $row->name,
            $row->assets,
        ];
    }

    public function headings(): array
    {
        if ($this->isRTL) {
            return [
                '#',
                __('locale.AssetGroupName'),
                __('locale.Assets')
            ];
        }

        return [
            '#',
            __('locale.Asset Group Name'),
            __('locale.Assets')
        ];
    }

    /**
     * Define column widths
     * 
     * Data starts at column A:
     *   A = # (counter)
     *   B = Asset Group Name
     *   C = Assets (logo floats over columns C and D area if needed)
     */
    public function columnWidths(): array
    {
        return [
            'A' => 8,   // # column
            'B' => 35,  // Asset Group Name column
            'C' => 60,  // Assets column
        ];
    }

    /**
     * Apply custom styles for the Asset Groups export
     */
protected function applyCustomStyles(Worksheet $sheet)
{
    $highestRow = $sheet->getHighestRow();

    // Determine header row number (accounting for title and description)
    $headerRow = 1;
    if ($this->title) {
        $headerRow = $this->description ? 3 : 2;
    }
    $dataStartRow = $headerRow + 1;

    // Wrap text for Assets column
    $sheet->getStyle("C{$dataStartRow}:C{$highestRow}")
        ->getAlignment()
        ->setWrapText(true);

    // Auto row heights for data rows
    for ($row = $dataStartRow; $row <= $highestRow; $row++) {
        $sheet->getRowDimension($row)->setRowHeight(-1);
    }
}
}