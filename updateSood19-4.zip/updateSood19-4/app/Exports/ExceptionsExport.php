<?php

namespace App\Exports;

use App\Models\Exception;
use App\Models\User;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Color;
use App\Traits\LaravelExportPropertiesTrait;
use DateTime;
use Illuminate\Support\Facades\App;

class ExceptionsExport extends BaseExportTemplate
{
    use LaravelExportPropertiesTrait;

    private array $rows = [];
    private $locale;

    public function __construct($locale = null)
    {
        $this->locale = $locale ?? App::getLocale();

        $title       = __('locale.Exceptions Report');
        $description = __('locale.This report contains all exception requests with their status and approval details');

        parent::__construct($this->locale, $title, $description);

        $exceptions = Exception::with(['user' => function ($query) {
            $query->select('id', 'name');
        }])->get();

        foreach ($exceptions as $exception) {
            // Calculate end date
            $end_date = null;
            if ($exception->approval_date != null) {
                $start_date = new DateTime($exception->approval_date);
                $end_date   = (clone $start_date)->modify("+{$exception->request_duration} days");
                $end_date   = $end_date->format('Y-m-d');
            }

            // Get approver name based on exception type
            $approver_name = null;
            if ($exception->type == 'policy' && $exception->policy_approver_id) {
                $approver      = User::find($exception->policy_approver_id);
                $approver_name = $approver ? $approver->name : 'N/A';
            } elseif ($exception->type == 'control' && $exception->control_approver_id) {
                $approver      = User::find($exception->control_approver_id);
                $approver_name = $approver ? $approver->name : 'N/A';
            } elseif ($exception->type == 'risk' && $exception->risk_approver_id) {
                $approver      = User::find($exception->risk_approver_id);
                $approver_name = $approver ? $approver->name : 'N/A';
            }

            // Get related entity name
            $related_entity = 'N/A';
            if ($exception->type == 'policy') {
                $policy = \DB::table('exception_policy')
                    ->join('documents', 'exception_policy.policy_id', '=', 'documents.id')
                    ->select('documents.document_name')
                    ->where('exception_policy.exception_id', $exception->id)
                    ->first();
                $related_entity = $policy ? $policy->document_name : 'N/A';
            } elseif ($exception->type == 'control') {
                $control = \DB::table('control_exception')
                    ->join('framework_controls', 'control_exception.control_id', '=', 'framework_controls.id')
                    ->select('framework_controls.short_name')
                    ->where('control_exception.exception_id', $exception->id)
                    ->first();
                $related_entity = $control ? $control->short_name : 'N/A';
            } elseif ($exception->type == 'risk') {
                $risk = \DB::table('exception_risk')
                    ->join('risks', 'exception_risk.risk_id', '=', 'risks.id')
                    ->select('risks.subject')
                    ->where('exception_risk.exception_id', $exception->id)
                    ->first();
                $related_entity = $risk ? $risk->subject : 'N/A';
            }

            // Request status label
            $request_status = '';
            if ($exception->request_status == 0) {
                $request_status = __('locale.Pending');
            } elseif ($exception->request_status == 1) {
                $request_status = __('locale.Approved');
            } else {
                $request_status = __('locale.Rejected');
            }

            // Exception status label
            $exception_status = $exception->exception_status == 1
                ? __('locale.Open')
                : __('locale.Closed');

            // Exception type translation
            $exception_type = '';
            if ($exception->type == 'policy') {
                $exception_type = __('locale.Policy');
            } elseif ($exception->type == 'control') {
                $exception_type = __('locale.Control');
            } elseif ($exception->type == 'risk') {
                $exception_type = __('locale.Risk');
            }

            $this->rows[] = (object) [
                'name'             => $exception->name,
                'type'             => $exception_type,
                'related_entity'   => $related_entity,
                'creator_name'     => $exception->user ? $exception->user->name : 'N/A',
                'approver_name'    => $approver_name ?? 'N/A',
                'submission_date'  => $exception->created_at->format('Y-m-d'),
                'approval_date'    => $exception->approval_date ?? 'N/A',
                'request_status'   => $request_status,
                'exception_status' => $exception_status,
                'request_duration' => $exception->request_duration
                    ? $exception->request_duration . ' ' . __('locale.Days')
                    : 'N/A',
                'end_date'         => $end_date ?? 'N/A',
                'risk_severity'    => $exception->risk_severity ?? 'N/A',
                'description'      => strip_tags($exception->description) ?? '',
            ];
        }
    }

    /**
     * Return collection
     */
    public function collection()
    {
        return collect($this->rows);
    }

    /**
     * Map each row
     */
    public function map($exception): array
    {
        return [
            $this->getCounter(),
            $exception->name,
            $exception->type,
            $exception->related_entity,
            $exception->creator_name,
            $exception->approver_name,
            $exception->submission_date,
            $exception->approval_date,
            $exception->request_status,
            $exception->exception_status,
            $exception->request_duration,
            $exception->end_date,
            $exception->risk_severity,
            $exception->description,
        ];
    }

    /**
     * Column headings
     */
    public function headings(): array
    {
        if ($this->isRTL) {
            return [
                '#',
                __('locale.Name'),
                __('locale.ExceptionType'),
                __('locale.RelatedEntity'),
                __('locale.Requestor'),
                __('locale.Approver'),
                __('locale.SubmissionDate'),
                __('locale.ApprovalDate'),
                __('locale.RequestStatus'),
                __('locale.ExceptionStatus'),
                __('locale.ExceptionDuration'),
                __('locale.EndsOn'),
                __('locale.RiskSeverity'),
                __('locale.Description'),
            ];
        }

        return [
            '#',
            __('locale.Name'),
            __('locale.Exception Type'),
            __('locale.Related Entity'),
            __('locale.Requestor'),
            __('locale.Approver'),
            __('locale.Submission Date'),
            __('locale.Approval Date'),
            __('locale.Request Status'),
            __('locale.Exception Status'),
            __('locale.Exception Duration'),
            __('locale.Ends On'),
            __('locale.Risk Severity'),
            __('locale.Description'),
        ];
    }

    /**
     * Column widths
     *
     * Data starts at column A (no spacer). Logo floats over N+O area.
     *   A  = #  (counter)
     *   B  = Name
     *   C  = Exception Type
     *   D  = Related Entity
     *   E  = Requestor
     *   F  = Approver
     *   G  = Submission Date
     *   H  = Approval Date
     *   I  = Request Status
     *   J  = Exception Status
     *   K  = Exception Duration
     *   L  = Ends On
     *   M  = Risk Severity
     *   N  = Description  ← logo floats over N and O
     */
    public function columnWidths(): array
    {
        return [
            'A' => 6,   // #
            'B' => 25,  // Name
            'C' => 18,  // Exception Type
            'D' => 30,  // Related Entity
            'E' => 22,  // Requestor
            'F' => 22,  // Approver
            'G' => 15,  // Submission Date
            'H' => 15,  // Approval Date
            'I' => 18,  // Request Status
            'J' => 18,  // Exception Status
            'K' => 18,  // Exception Duration
            'L' => 15,  // Ends On
            'M' => 18,  // Risk Severity
            'N' => 50,  // Description
        ];
    }

    /**
     * Apply custom styles for the exceptions export.
     *
     * Column map (data starts at A):
     *   A=#, B=Name, C=Type, D=RelatedEntity, E=Requestor, F=Approver,
     *   G=SubmissionDate, H=ApprovalDate, I=RequestStatus, J=ExceptionStatus,
     *   K=Duration, L=EndsOn, M=RiskSeverity, N=Description
     */
protected function applyCustomStyles(Worksheet $sheet)
{
    $highestRow = $sheet->getHighestRow();

    // Determine header row number (accounting for title and description)
    $headerRow = 1;
    if ($this->title) {
        $headerRow = $this->description ? 3 : 2;
    }
    $dataStartRow = $headerRow + 1;

    // Wrap text for Related Entity and Description columns
    $wrapColumns = ['D', 'N'];
    foreach ($wrapColumns as $col) {
        $sheet->getStyle("{$col}{$dataStartRow}:{$col}{$highestRow}")
            ->getAlignment()
            ->setWrapText(true);
    }

    // Auto row heights for data rows
    for ($row = $dataStartRow; $row <= $highestRow; $row++) {
        $sheet->getRowDimension($row)->setRowHeight(-1);
    }
}
}