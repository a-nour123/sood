<?php

namespace App\Exports;

use Carbon\Carbon;
use Illuminate\Support\Collection;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Color;
use Illuminate\Support\Facades\App;

class AssetsExport extends BaseExportTemplate
{
    private $assets;
    private $locale;
    private array $rows = [];

    public function __construct(Collection $assets, $locale = null)
    {
        $this->locale = $locale ?? App::getLocale();
        $this->assets = $assets;

        $title = __('locale.Assets Report');
        $description = __('locale.This report contains all assets with their detailed information and configurations');

        parent::__construct($this->locale, $title, $description);

        // Pre-process data
        foreach ($this->assets as $asset) {
            $teams = $asset->teamsName()?->toArray() ?? [];
            $tags = $asset->tags()?->pluck('tag')->toArray() ?? [];

            $this->rows[] = (object)[
                'name' => $asset->name,
                'ip' => $asset->ip,
                'category' => $asset->assetCategory->name ?? __('locale.N/A'),
                'location' => $asset->location->name ?? __('locale.N/A'),
                'teams' => implode(', ', $teams) ?: __('locale.No Teams'),
                'tags' => implode(', ', $tags) ?: __('locale.No Tags'),
                'details' => $asset->details ?? __('locale.N/A'),
                'url' => $asset->url ?? __('locale.N/A'),
                'os' => $asset->assetOs->name ?? __('locale.N/A'),
                'os_version' => $asset->os_version ?? __('locale.N/A'),
                'project_vlan' => $asset->project_vlan ?? __('locale.N/A'),
                'vlan' => $asset->vlan ?? __('locale.N/A'),
                'model' => $asset->model ?? __('locale.N/A'),
                'firmware' => $asset->firmware ?? __('locale.N/A'),
                'city' => $asset->city ?? __('locale.N/A'),
                'rack_location' => $asset->rack_location ?? __('locale.N/A'),
                'mac_address' => $asset->mac_address ?? __('locale.N/A'),
                'subnet_mask' => $asset->subnet_mask ?? __('locale.N/A'),
                'user' => $asset->Users->name ?? __('locale.N/A'),
                'environment_category' => $asset->assetEnvironmentCategory->name ?? __('locale.N/A'),
                'start_date' => optional($asset->start_date)->format('Y-m-d') ?: __('locale.N/A'),
                'expiration_date' => optional($asset->expiration_date)->format('Y-m-d') ?: __('locale.N/A'),
                'alert_period' => $asset->alert_period ? $asset->alert_period . ' ' . __('locale.Days') : __('locale.N/A'),
                'created_date' => optional($asset->created)->format('Y-m-d') ?: __('locale.N/A'),
                'verified' => $asset->verified 
                    ? __('locale.verified') 
                    : __('locale.not_verified'),
                'rank' => $asset->rank ?? __('locale.N/A'),
            ];
        }
    }

    public function collection()
    {
        return collect($this->rows);
    }

    public function map($row): array
    {
        return [
            $this->getCounter(),
            $row->name,
            $row->ip,
            $row->category,
            $row->location,
            $row->teams,
            $row->tags,
            $row->details,
            $row->url,
            $row->os,
            $row->os_version,
            $row->project_vlan,
            $row->vlan,
            $row->model,
            $row->firmware,
            $row->city,
            $row->rack_location,
            $row->mac_address,
            $row->subnet_mask,
            $row->user,
            $row->environment_category,
            $row->start_date,
            $row->expiration_date,
            $row->alert_period,
            $row->created_date,
            $row->verified,
            $row->rank,
        ];
    }

    public function headings(): array
    {
        if ($this->isRTL) {
            return [
                '#',
                __('locale.AssetName'),
                __('locale.IPAddress'),
                __('locale.Category'),
                __('locale.AssetSiteLocation'),
                __('locale.Teams'),
                __('locale.Tags'),
                __('locale.AssetDetails'),
                __('locale.Url'),
                __('locale.Os'),
                __('locale.OsVersion'),
                __('locale.ProjectVlan'),
                __('locale.Vlan'),
                __('locale.Model'),
                __('locale.Firmware'),
                __('locale.City'),
                __('locale.RackLocation'),
                __('locale.MacAddress'),
                __('locale.SubnetMask'),
                __('locale.Users'),
                __('locale.AssetEnvironmentCategory'),
                __('locale.StartDate'),
                __('locale.EndDate'),
                __('locale.AlertPeriod'),
                __('locale.CreatedDate'),
                __('locale.VerifiedAssets'),
                __('locale.Rank'),
            ];
        }

        return [
            '#',
            __('locale.Asset Name'),
            __('locale.IP Address'),
            __('locale.Category'),
            __('locale.Asset Site Location'),
            __('locale.Teams'),
            __('locale.Tags'),
            __('locale.Asset Details'),
            __('locale.URL'),
            __('locale.OS'),
            __('locale.OS Version'),
            __('locale.Project VLAN'),
            __('locale.VLAN'),
            __('locale.Model'),
            __('locale.Firmware'),
            __('locale.City'),
            __('locale.Rack Location'),
            __('locale.MAC Address'),
            __('locale.Subnet Mask'),
            __('locale.User'),
            __('locale.Asset Environment Category'),
            __('locale.Start Date'),
            __('locale.End Date'),
            __('locale.Alert Period'),
            __('locale.Created Date'),
            __('locale.Verified'),
            __('locale.Rank'),
        ];
    }

    public function columnWidths(): array
    {
        return [
            'A' => 6,   // #
            'B' => 25,  // Asset Name
            'C' => 18,  // IP Address
            'D' => 20,  // Category
            'E' => 25,  // Location
            'F' => 30,  // Teams
            'G' => 30,  // Tags
            'H' => 40,  // Asset Details
            'I' => 30,  // URL
            'J' => 15,  // OS
            'K' => 15,  // OS Version
            'L' => 15,  // Project VLAN
            'M' => 15,  // VLAN
            'N' => 20,  // Model
            'O' => 20,  // Firmware
            'P' => 20,  // City
            'Q' => 25,  // Rack Location
            'R' => 25,  // MAC Address
            'S' => 20,  // Subnet Mask
            'T' => 25,  // User
            'U' => 25,  // Environment Category
            'V' => 18,  // Start Date
            'W' => 18,  // End Date
            'X' => 15,  // Alert Period
            'Y' => 18,  // Created Date
            'Z' => 18,  // Verified
            'AA' => 10, // Rank
        ];
    }

protected function applyCustomStyles(Worksheet $sheet)
{
    $highestRow = $sheet->getHighestRow();

    // Determine header row number (accounting for title and description)
    $headerRow = 1;
    if ($this->title) {
        $headerRow = $this->description ? 3 : 2;
    }
    $dataStartRow = $headerRow + 1;

    // Columns that need text wrapping
    $wrapColumns = ['F', 'G', 'H', 'I'];
    foreach ($wrapColumns as $col) {
        $sheet->getStyle("{$col}{$dataStartRow}:{$col}{$highestRow}")
            ->getAlignment()
            ->setWrapText(true);
    }

    // Auto row heights for data rows
    for ($row = $dataStartRow; $row <= $highestRow; $row++) {
        $sheet->getRowDimension($row)->setRowHeight(-1);
    }
}
}