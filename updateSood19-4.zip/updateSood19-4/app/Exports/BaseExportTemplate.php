<?php

namespace App\Exports;

use Illuminate\Support\Facades\App;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithColumnWidths;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;

abstract class BaseExportTemplate implements
    FromCollection,
    WithMapping,
    WithHeadings,
    WithStyles,
    WithColumnWidths,
    WithEvents
{
    protected $counter = 1;
    protected $isRTL;
    protected $logoPath;
    protected $logoHeight;
    protected $title;
    protected $description;

    public function __construct($locale = null, $title = null, $description = null)
    {
        $locale = $locale ?? app()->getLocale();
        app()->setLocale($locale);

        $this->isRTL = $locale === 'ar';
        $this->title = $title;
        $this->description = $description;
        $this->logoPath = public_path('images/ksu-logo.png');
        $this->logoHeight = 80;
    }

    abstract public function collection();
    abstract public function map($item): array;
    abstract public function headings(): array;
    abstract public function columnWidths(): array;

    /**
     * Get last column letter dynamically
     */
    protected function getLastColumnLetter(): string
    {
        return Coordinate::stringFromColumnIndex(count($this->headings()));
    }

    /**
     * styles() is required by WithStyles but we handle all styling in registerEvents().
     * Return minimal styles here to avoid conflicts.
     */
    public function styles(Worksheet $sheet)
    {
        return [];
    }

    /**
     * events
     *
     * Layout (same for BOTH LTR and RTL):
     *   Col A … lastDataCol = data columns (headings count), starting from A
     *   Logo floats over the last two data columns (N and O area) — no extra column added
     */
    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event) {
                $sheet = $event->sheet->getDelegate();

                // Reset counter so it always starts from 1
                $this->counter = 1;

                // Set RTL direction for Arabic
                if ($this->isRTL) {
                    $sheet->setRightToLeft(true);
                }

                $headings  = $this->headings();
                $totalRows = $this->collection()->count();

                // ------------------------------------------------------------------
                // COLUMN LAYOUT: data starts at column A (index 1), no extra columns
                // ------------------------------------------------------------------
                $dataStartColIndex = 1; // column A
                $dataEndColIndex   = count($headings); // last data column
                $dataStartCol      = 'A';
                $dataEndCol        = Coordinate::stringFromColumnIndex($dataEndColIndex);

                // In RTL, column A is visually on the RIGHT side of the screen.
                // In LTR, the last column is visually on the RIGHT side of the screen.
                $logoAnchorCol = $this->isRTL ? 'A' : $dataEndCol;

                // ------------------------------------------------------------------
                // ROW LAYOUT
                // ------------------------------------------------------------------
                $currentRow = 1;

                // --- Title row — title text centered, logo floats over N+O on the right ---
                if ($this->title) {
                    $sheet->mergeCells("A{$currentRow}:{$dataEndCol}{$currentRow}");
                    $sheet->setCellValue("A{$currentRow}", $this->title);

                    $sheet->getStyle("A{$currentRow}")->applyFromArray([
                        'font'      => ['bold' => true, 'size' => 14, 'color' => ['rgb' => '2F5496']],
                        'alignment' => [
                            'horizontal' => Alignment::HORIZONTAL_CENTER,
                            'vertical'   => Alignment::VERTICAL_CENTER,
                        ],
                    ]);

                    $sheet->getRowDimension($currentRow)->setRowHeight(70);

                    // Logo anchored at second-to-last column, floats over N and O
                    if (file_exists($this->logoPath)) {
                        $drawing = new Drawing();
                        $drawing->setName('Logo');
                        $drawing->setDescription('Logo');
                        $drawing->setPath($this->logoPath);
                        $drawing->setHeight($this->logoHeight);
                        $drawing->setCoordinates($logoAnchorCol . $currentRow);
                        $drawing->setOffsetX(5);
                        $drawing->setOffsetY(10);
                        $drawing->setWorksheet($sheet);
                    }

                    $currentRow++;
                }

                // --- Description row ---
                if ($this->description) {
                    $sheet->mergeCells("A{$currentRow}:{$dataEndCol}{$currentRow}");
                    $sheet->setCellValue("A{$currentRow}", $this->description);
                    $sheet->getStyle("A{$currentRow}")->applyFromArray([
                        'font'      => ['size' => 10, 'italic' => true, 'color' => ['rgb' => '666666']],
                        'alignment' => [
                            'horizontal' => Alignment::HORIZONTAL_CENTER,
                            'vertical'   => Alignment::VERTICAL_CENTER,
                        ],
                    ]);
                    $sheet->getRowDimension($currentRow)->setRowHeight(25);
                    $currentRow++;
                }

                // --- Header row ---
                $headerRow = $currentRow;
                $col = $dataStartColIndex;
                foreach ($headings as $heading) {
                    $sheet->setCellValueByColumnAndRow($col, $headerRow, $heading);
                    $col++;
                }

                $sheet->getStyle("{$dataStartCol}{$headerRow}:{$dataEndCol}{$headerRow}")->applyFromArray([
                    'font'      => [
                        'bold'  => true,
                        'color' => ['rgb' => '2F5496'],
                        'size'  => 11,
                    ],
                    'alignment' => [
                        'horizontal' => $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_CENTER,
                        'vertical'   => Alignment::VERTICAL_CENTER,
                    ],
                    'fill'      => [
                        'fillType' => Fill::FILL_SOLID,
                        'color'    => ['rgb' => 'E7E6E6'],
                    ],
                ]);
                $sheet->getRowDimension($headerRow)->setRowHeight(40);
                $currentRow++;

                // --- Data rows ---
                $dataFirstRow = $currentRow;
                foreach ($this->collection() as $item) {
                    $mappedData = $this->map($item);
                    $col = $dataStartColIndex;
                    foreach ($mappedData as $value) {
                        $sheet->setCellValueByColumnAndRow($col, $currentRow, $value);
                        $col++;
                    }
                    $currentRow++;
                }
                $dataLastRow = $currentRow - 1;

                // --- Borders & alignment for data rows ---
                if ($totalRows > 0) {
                    $dataAlignment = $this->isRTL
                        ? Alignment::HORIZONTAL_RIGHT
                        : Alignment::HORIZONTAL_LEFT;

                    $sheet->getStyle("{$dataStartCol}{$dataFirstRow}:{$dataEndCol}{$dataLastRow}")->applyFromArray([
                        'borders'   => [
                            'allBorders' => [
                                'borderStyle' => Border::BORDER_THIN,
                                'color'       => ['rgb' => 'D9D9D9'],
                            ],
                        ],
                        'alignment' => [
                            'vertical'   => Alignment::VERTICAL_CENTER,
                            'horizontal' => $dataAlignment,
                        ],
                    ]);

                    // Center the counter column (A)
                    $sheet->getStyle("{$dataStartCol}{$dataFirstRow}:{$dataStartCol}{$dataLastRow}")
                        ->getAlignment()
                        ->setHorizontal(Alignment::HORIZONTAL_CENTER);

                    // Alternating row colors
                    for ($row = $dataFirstRow; $row <= $dataLastRow; $row++) {
                        if ($row % 2 === 0) {
                            $sheet->getStyle("{$dataStartCol}{$row}:{$dataEndCol}{$row}")->applyFromArray([
                                'fill' => [
                                    'fillType' => Fill::FILL_SOLID,
                                    'color'    => ['rgb' => 'F8F9FA'],
                                ],
                            ]);
                        }
                    }
                }

                // --- Auto-size data columns ---
                for ($c = $dataStartColIndex; $c <= $dataEndColIndex; $c++) {
                    $sheet->getColumnDimensionByColumn($c)->setAutoSize(true);
                }

                // --- Freeze pane below header ---
                $sheet->freezePane("{$dataStartCol}" . ($headerRow + 1));

                // --- Apply subclass custom styles ---
                $this->applyCustomStyles($sheet);
            },
        ];
    }

    /**
     * Helper method to translate text with fallback
     */
    protected function trans($key, $replace = [], $locale = null)
    {
        $locale          = $locale ?? ($this->isRTL ? 'ar' : 'en');
        $originalLocale  = App::getLocale();
        App::setLocale($locale);

        $translation = __($key, $replace);

        if ($translation === $key) {
            $parts       = explode('.', $key);
            $translation = end($parts);
            if ($locale === 'en') {
                $translation = str_replace('_', ' ', $translation);
                $translation = ucwords($translation);
            }
        }

        App::setLocale($originalLocale);

        return $translation;
    }

    /**
     * Override in subclasses if needed
     */
    protected function applyCustomStyles(Worksheet $sheet) {}

    protected function getCounter(): int
    {
        return $this->counter++;
    }
}