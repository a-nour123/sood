<?php

namespace App\Exports;

use App\Models\ControlObjective;
use App\Models\Framework;
use App\Models\FrameworkControl;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use Illuminate\Support\Facades\App;

class ControlObjectivesExport extends BaseExportTemplate
{
    private $locale;
    private array $rows = [];
    private $frameworks;
    private $controls;

    public function __construct($locale = null)
    {
        $this->locale = $locale ?? App::getLocale();

        $title = __('locale.Control Objectives Report');
        $description = __('locale.This report contains all control objectives with their associated frameworks and controls');

        parent::__construct($this->locale, $title, $description);

        /**
         * preload frameworks
         */
        $this->frameworks = Framework::pluck('name', 'id')
            ->mapWithKeys(fn($name, $id) => [trim($id) => $name]);

        /**
         * preload controls
         */
        $this->controls = FrameworkControl::pluck('short_name', 'id')
            ->mapWithKeys(fn($name, $id) => [trim($id) => $name]);

        /**
         * load and process rows
         */
        $controlObjectives = ControlObjective::get();
        
        foreach ($controlObjectives as $objective) {
            $this->rows[] = $this->processControlObjective($objective);
        }
    }

    /**
     * Process a single control objective
     */
    private function processControlObjective($objective)
    {
        $frameworkIds = !empty($objective->framework_id) 
            ? explode(',', str_replace(' ', '', $objective->framework_id)) 
            : [];
        
        $controlIds = !empty($objective->control_id) 
            ? explode(',', str_replace(' ', '', $objective->control_id)) 
            : [];

        /**
         * names
         */
        $frameworkNames = array_map(
            fn($id) => $this->frameworks[$id] ?? $id,
            $frameworkIds
        );

        $controlNames = array_map(
            fn($id) => $this->controls[$id] ?? $id,
            $controlIds
        );

        /**
         * decode json description
         */
        $descArr = json_decode($objective->getRawOriginal('description'), true) ?? [];

        $desc_en = isset($descArr['en']) && !empty($descArr['en'])
            ? strip_tags($descArr['en'])
            : __('locale.No Description');

        $desc_ar = isset($descArr['ar']) && !empty($descArr['ar'])
            ? strip_tags($descArr['ar'])
            : __('locale.No Description');

        /**
         * format framework and control lists
         */
        $frameworkList = !empty($frameworkNames) 
            ? implode(', ', $frameworkNames) 
            : __('locale.No Frameworks');
            
        $controlList = !empty($controlNames) 
            ? implode(', ', $controlNames) 
            : __('locale.No Controls');

        return (object)[
            'name' => $objective->name,
            'description_en' => $desc_en,
            'description_ar' => $desc_ar,
            'frameworks' => $frameworkList,
            'controls' => $controlList,
            'created_date' => $objective->created_at->format('Y-m-d H:i'),
        ];
    }

    /**
     * collection
     */
    public function collection()
    {
        return collect($this->rows);
    }

    /**
     * map
     */
    public function map($row): array
    {
        return [
            $this->getCounter(),
            $row->name,
            $row->description_en,
            $row->description_ar,
            $row->frameworks,
            $row->controls,
            $row->created_date,
        ];
    }

    /**
     * headers
     */
    public function headings(): array
    {
        if ($this->isRTL) {
            return [
                '#',
                __('locale.Name'),
                __('locale.Description_English'),
                __('locale.Description_Arabic'),
                __('locale.Framework'),
                __('locale.Controls'),
                __('locale.CreatedDate')
            ];
        }

        return [
            '#',
            __('locale.Name'),
            __('locale.Description (English)'),
            __('locale.Description (Arabic)'),
            __('locale.Framework(s)'),
            __('locale.Control(s)'),
            __('locale.Created Date')
        ];
    }

    /**
     * widths
     */
    public function columnWidths(): array
    {
        return [
            'A' => 6,   // #
            'B' => 30,  // Name
            'C' => 50,  // Description English
            'D' => 50,  // Description Arabic
            'E' => 35,  // Frameworks
            'F' => 35,  // Controls
            'G' => 20,  // Created Date
        ];
    }

    /**
     * styling
     */
protected function applyCustomStyles(Worksheet $sheet)
{
    $highestRow = $sheet->getHighestRow();

    // Determine header row number (accounting for title and description)
    $headerRow = 1;
    if ($this->title) {
        $headerRow = $this->description ? 3 : 2;
    }
    $dataStartRow = $headerRow + 1;

    // Wrap text for all text columns
    $wrapColumns = ['B', 'C', 'D', 'E', 'F'];
    foreach ($wrapColumns as $col) {
        $sheet->getStyle("{$col}{$dataStartRow}:{$col}{$highestRow}")
            ->getAlignment()
            ->setWrapText(true);
    }

    // Auto row heights for data rows
    for ($row = $dataStartRow; $row <= $highestRow; $row++) {
        $sheet->getRowDimension($row)->setRowHeight(-1);
    }
}
}