<?php

namespace App\Exports;

use App\Models\FrameworkControl;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Color;
use Illuminate\Support\Facades\App;

class FrameworkControlsExport extends BaseExportTemplate
{
    private $locale;
    private array $rows = [];

    /**
     * Constructor
     */
    public function __construct($locale = null)
    {
        $this->locale = $locale ?? App::getLocale();

        $title = __('locale.Framework Controls Report');
        $description = __('locale.This report contains all framework controls with their attributes, testing information, and hierarchical relationships');

        parent::__construct($this->locale, $title, $description);

        // Load and process framework controls
        $controls = $this->loadControls();

        foreach ($controls as $control) {
            $this->rows[] = $this->processControl($control);
        }
    }

    /**
     * Load controls with all relationships
     */
    private function loadControls()
    {
        return FrameworkControl::withCount('frameworkControls')
            ->with([
                'family_with_parent:id,name,parent_id',
                'parentFrameworkControl:id,short_name',
                'phase',
                'priority',
                'maturity',
                'type',
                'class',
                'ControlDesiredMaturity:id,name',
                'custom_test:framework_control_id,name,test_frequency,last_date,tester',
                'Frameworks:id,name',
                'owner:id,name'
            ])
            ->get();
    }

    /**
     * Process a single framework control
     */
    private function processControl($control)
    {
        // Handle raw description JSON
        $rawDescription = $control->getRawOriginal('description');
        if (is_string($rawDescription)) {
            $description = json_decode($rawDescription, true) ?? [];
        } else {
            $description = $rawDescription ?? [];
        }

        $description_en = isset($description['en']) && !empty($description['en'])
            ? strip_tags($description['en'])
            : __('locale.No Description');

        $description_ar = isset($description['ar']) && !empty($description['ar'])
            ? strip_tags($description['ar'])
            : __('locale.No Description');

        // Get framework names
        $controlFrameworksNames = $control->Frameworks->pluck('name')->filter()->toArray();
        $frameName = !empty($controlFrameworksNames)
            ? implode(', ', $controlFrameworksNames)
            : __('locale.No Framework');

        // Get family information
        $familyName = $control->family_with_parent?->name ?? __('locale.N/A');
        $familyParentName = $control->family_with_parent?->parentFamily?->name ?? __('locale.N/A');

        // Get parent control
        $parentControl = $control->parentFrameworkControl?->short_name ?? __('locale.N/A');

        // Get related entities with translations
        $priority = $control->priority?->name ?? __('locale.Not Set');
        $phase = $control->phase?->name ?? __('locale.Not Set');
        $type = $control->type?->name ?? __('locale.Not Set');
        $maturity = $control->maturity?->name ?? __('locale.Not Set');
        $class = $control->class?->name ?? __('locale.Not Set');
        $desiredMaturity = $control->ControlDesiredMaturity?->name ?? __('locale.Not Set');

        // Get owner and tester information
        $owner = $control->owner?->name ?? __('locale.Not Assigned');
        $tester = $control->custom_test?->UserTester?->name ?? __('locale.Not Assigned');
        $testName = $control->custom_test?->name ?? __('locale.No Test');

        // Format test frequency
        $testFrequency = $control->custom_test?->test_frequency
            ? $control->custom_test->test_frequency . ' ' . __('locale.days')
            : __('locale.N/A');

        // Format last test date
        $lastTestDate = $control->custom_test?->last_date
            ? date('Y-m-d', strtotime($control->custom_test->last_date))
            : __('locale.N/A');

        // Format mitigation percent with percentage sign
        $mitigationPercent = $control->mitigation_percent
            ? $control->mitigation_percent . '%'
            : __('locale.N/A');

        // Translate control status
        $controlStatus = $this->translateControlStatus($control->control_status);

        // Handle supplemental guidance
        $supplementalGuidance = $control->supplemental_guidance
            ? strip_tags($control->supplemental_guidance)
            : __('locale.N/A');

        return (object)[
            'short_name' => $control->short_name,
            'long_name' => $control->long_name ?? __('locale.N/A'),
            'description_en' => $description_en,
            'description_ar' => $description_ar,
            'control_number' => $control->control_number ?? __('locale.N/A'),
            'frame_name' => $frameName,
            'family_parent_name' => $familyParentName,
            'family_name' => $familyName,
            'parent_control' => $parentControl,
            'mitigation_percent' => $mitigationPercent,
            'supplemental_guidance' => $supplementalGuidance,
            'priority' => $priority,
            'phase' => $phase,
            'type' => $type,
            'maturity' => $maturity,
            'class' => $class,
            'desired_maturity' => $desiredMaturity,
            'control_status' => $controlStatus,
            'owner' => $owner,
            'tester' => $tester,
            'test_name' => $testName,
            'test_frequency' => $testFrequency,
            'last_test_date' => $lastTestDate,
        ];
    }

    /**
     * Translate control status with proper formatting
     */
    private function translateControlStatus($status)
    {
        if (empty($status)) {
            return __('locale.Not Set');
        }

        $statusKey = 'locale.' . ucfirst($status);
        $translated = __($statusKey);

        if ($translated == $statusKey) {
            $translated = ucfirst(str_replace('_', ' ', $status));
        }

        return $translated;
    }

    /**
     * Get all framework controls with relationships and mapped objects
     */
    public function collection()
    {
        return collect($this->rows);
    }

    /**
     * Map each control to an array
     */
    public function map($row): array
    {
        return [
            $this->getCounter(),
            $row->short_name,
            $row->long_name,
            $row->description_en,
            $row->description_ar,
            $row->control_number,
            $row->frame_name,
            $row->family_parent_name,
            $row->family_name,
            $row->parent_control,
            $row->mitigation_percent,
            $row->supplemental_guidance,
            $row->priority,
            $row->phase,
            $row->type,
            $row->maturity,
            $row->class,
            $row->desired_maturity,
            $row->control_status,
            $row->owner,
            $row->tester,
            $row->test_name,
            $row->test_frequency,
            $row->last_test_date,
        ];
    }

    /**
     * Column headings
     */
    public function headings(): array
    {
        if ($this->isRTL) {
            return [
                '#',
                __('locale.ControlShortName'),
                __('locale.ControlLongName'),
                __('locale.DescriptionEnglish'),
                __('locale.DescriptionArabic'),
                __('locale.ControlNumber'),
                __('locale.Framework'),
                __('locale.Domain'),
                __('locale.sub_domain'),
                __('locale.ParentControlFramework'),
                __('locale.MitigationPercent'),
                __('locale.SupplementalGuidance'),
                __('locale.ControlPriority'),
                __('locale.ControlPhase'),
                __('locale.ControlType'),
                __('locale.ControlMaturity'),
                __('locale.ControlClass'),
                __('locale.ControlDesiredMaturity'),
                __('locale.ControlStatus'),
                __('locale.ControlOwner'),
                __('locale.Tester'),
                __('locale.TestName'),
                __('locale.TestFrequency') . " (" . __('locale.days') . ")",
                __('locale.LastTestDate')
            ];
        }

        return [
            '#',
            __('locale.Control Short Name'),
            __('locale.Control Long Name'),
            __('locale.Description (English)'),
            __('locale.Description (Arabic)'),
            __('locale.Control Number'),
            __('locale.Framework(s)'),
            __('locale.Parent Domain'),
            __('locale.Sub-domain'),
            __('locale.Parent Control'),
            __('locale.Mitigation %'),
            __('locale.Supplemental Guidance'),
            __('locale.Priority'),
            __('locale.Phase'),
            __('locale.Type'),
            __('locale.Maturity'),
            __('locale.Class'),
            __('locale.Desired Maturity'),
            __('locale.Status'),
            __('locale.Owner'),
            __('locale.Tester'),
            __('locale.Test Name'),
            __('locale.Test Frequency'),
            __('locale.Last Test Date')
        ];
    }

    /**
     * Column widths
     */
    public function columnWidths(): array
    {
        return [
            'A' => 6,   // #
            'B' => 20,  // Short Name
            'C' => 35,  // Long Name
            'D' => 40,  // Description EN
            'E' => 40,  // Description AR
            'F' => 15,  // Control Number
            'G' => 30,  // Framework(s)
            'H' => 25,  // Parent Domain
            'I' => 25,  // Sub-domain
            'J' => 25,  // Parent Control
            'K' => 18,  // Mitigation %
            'L' => 45,  // Supplemental Guidance
            'M' => 18,  // Priority
            'N' => 18,  // Phase
            'O' => 18,  // Type
            'P' => 18,  // Maturity
            'Q' => 18,  // Class
            'R' => 20,  // Desired Maturity
            'S' => 15,  // Status
            'T' => 25,  // Owner
            'U' => 25,  // Tester
            'V' => 25,  // Test Name
            'W' => 18,  // Test Frequency
            'X' => 18,  // Last Test Date
        ];
    }

    /**
     * Custom styles for wrap text and formatting
     */
    protected function applyCustomStyles(Worksheet $sheet)
    {
        $highestRow = $sheet->getHighestRow();

        // Determine header row number (accounting for title and description)
        $headerRow = 1;
        if ($this->title) {
            $headerRow = $this->description ? 3 : 2;
        }
        $dataStartRow = $headerRow + 1;

        // Wrap text for description and guidance columns
        $wrapColumns = ['C', 'D', 'E', 'L'];
        foreach ($wrapColumns as $col) {
            $sheet->getStyle("{$col}{$dataStartRow}:{$col}{$highestRow}")
                ->getAlignment()
                ->setWrapText(true);
        }

        // Auto row heights for data rows
        for ($row = $dataStartRow; $row <= $highestRow; $row++) {
            $sheet->getRowDimension($row)->setRowHeight(-1);
        }
    }
}
