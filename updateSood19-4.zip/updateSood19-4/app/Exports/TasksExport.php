<?php

namespace App\Exports;

use App\Models\Task;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Color;
use Illuminate\Support\Facades\App;

class TasksExport extends BaseExportTemplate
{
    private $locale;
    private string $tasksType = '';
    private array $rows = [];

    public function __construct(string $tasksType, ?string $locale = null)
    {
        $this->locale = $locale ?? App::getLocale();
        $this->tasksType = in_array($tasksType, ['created', 'assigned']) ? $tasksType : 'created';

        // Set title and description based on tasks type
        $title = $this->getTitleByType($this->tasksType);
        $description = $this->getDescriptionByType($this->tasksType);

        parent::__construct($this->locale, $title, $description);

        // Load and process tasks
        $tasks = $this->loadTasks();

        foreach ($tasks as $task) {
            $this->rows[] = $this->processTask($task);
        }
    }

    /**
     * Get title based on tasks type
     */
    private function getTitleByType(string $tasksType): string
    {
        if ($tasksType === 'created') {
            return __('locale.Tasks Created By Me Report');
        }

        return __('locale.Tasks Assigned To Me Report');
    }

    /**
     * Get description based on tasks type
     */
    private function getDescriptionByType(string $tasksType): string
    {
        if ($tasksType === 'created') {
            return __('locale.This report contains all tasks that you have created, showing their status, assignments, and completion progress');
        }

        return __('locale.This report contains all tasks assigned to you or your teams, showing your responsibilities and deadlines');
    }

    /**
     * Load tasks based on type
     */
    private function loadTasks()
    {
        $currentUser = auth()->user();

        if ($this->tasksType === 'created') {
            return $currentUser->createdTasks()
                ->with('assignable:id,name', 'action_by_user:id,name', 'created_by_user:id,name')
                ->orderBy('due_date')
                ->get();
        }

        // Assigned tasks
        $currentUserTasks = $currentUser->tasks()
            ->with('assignable:id,name', 'action_by_user:id,name', 'created_by_user:id,name')
            ->orderBy('due_date')
            ->get();

        $teamIds = $currentUser->teams()->pluck('id')->toArray();
        $teamTasks = Task::where('assignable_type', 'App\Models\Team')
            ->whereIn('assignable_id', $teamIds)
            ->with('assignable:id,name', 'created_by_user:id,name', 'action_by_user:id,name')
            ->orderBy('due_date')
            ->get();

        return $currentUserTasks->merge($teamTasks);
    }

    /**
     * Process a single task
     */
    private function processTask($task)
    {
        $currentUserId = auth()->id();

        // Get assignee type and name
        $assigneeType = class_basename($task->assignable_type);
        $assigneeName = $task->assignable->name ?? __('locale.Unknown');

        // Check if assignee is the current user
        if ($assigneeType === 'User' && $task->assignable && $task->assignable->id === $currentUserId) {
            $assigneeName = __('locale.Me');
        }

        // Get action by user name
        $actionByName = $task->action_by_user->name ?? '';
        if (empty($actionByName) && $task->created_by_user && $task->created_by_user->id === $currentUserId) {
            $actionByName = __('locale.Me');
        } elseif (empty($actionByName)) {
            $actionByName = __('locale.Not started');
        }

        // Get created by name
        $createdByName = $this->tasksType === 'created'
            ? __('locale.Me')
            : ($task->created_by_user->name ?? __('locale.Unknown'));

        // Translate priority
        $priority = $this->translateTaskPriority($task->priority);

        // Translate status
        $status = $this->translateTaskStatus($task->status);

        // Format dates
        $startDate = $task->start_date ? $task->start_date->format('Y-m-d') : __('locale.Not set');
        $dueDate = $task->due_date ? $task->due_date->format('Y-m-d') : __('locale.Not set');
        $completedDate = $task->completed_date ? $task->completed_date->format('Y-m-d H:i') : '';
        $acceptedDate = $task->accepted_date ? $task->accepted_date->format('Y-m-d H:i') : '';
        $createdAt = $task->created_at ? $task->created_at->format('Y-m-d H:i') : __('locale.N/A');

        // Check if task is overdue
        $isOverdue = $this->isTaskOverdue($task);

        // Get completion status
        $completed = $task->completed ? '✓' : '✗';

        // Clean description
        $description = $task->description
            ? strip_tags($task->description)
            : __('locale.No description');

        return (object)[
            'title' => $task->title ?? __('locale.Untitled'),
            'assignee_type' => $assigneeType,
            'assignee_name' => $assigneeName,
            'start_date' => $startDate,
            'due_date' => $dueDate,
            'priority' => $priority,
            'priority_raw' => $task->priority,
            'status' => $status,
            'status_raw' => $task->status,
            'action_by' => $actionByName,
            'description' => $description,
            'completed' => $completed,
            'completed_date' => $completedDate,
            'accepted_date' => $acceptedDate,
            'created_by' => $createdByName,
            'created_at' => $createdAt,
            'is_overdue' => $isOverdue,
            'is_completed' => $task->completed,
        ];
    }

    /**
     * Translate task priority
     */
    private function translateTaskPriority($priority)
    {
        $priorityMap = [
            'low' => 'locale.Low',
            'medium' => 'locale.Medium',
            'high' => 'locale.High',
            'urgent' => 'locale.Urgent',
        ];

        $key = $priorityMap[$priority] ?? 'locale.' . ucfirst($priority);
        $translated = __($key);

        if ($translated == $key) {
            $translated = ucfirst($priority);
        }

        return $translated;
    }

    /**
     * Translate task status
     */
    private function translateTaskStatus($status)
    {
        $statusMap = [
            'pending' => 'locale.Pending',
            'in_progress' => 'locale.In Progress',
            'completed' => 'locale.Completed',
            'accepted' => 'locale.Accepted',
            'rejected' => 'locale.Rejected',
            'cancelled' => 'locale.Cancelled',
        ];

        $key = $statusMap[$status] ?? 'locale.' . ucfirst(str_replace('_', ' ', $status));
        $translated = __($key);

        if ($translated == $key) {
            $translated = ucfirst(str_replace('_', ' ', $status));
        }

        return $translated;
    }

    /**
     * Check if task is overdue
     */
    private function isTaskOverdue($task)
    {
        if ($task->completed || !$task->due_date) {
            return false;
        }

        $today = now()->startOfDay();
        $dueDate = $task->due_date->startOfDay();

        return $dueDate < $today;
    }

    /**
     * Return collection
     */
    public function collection()
    {
        return collect($this->rows);
    }

    /**
     * Map each task to an export row
     */
    public function map($task): array
    {
        return [
            $this->getCounter(),
            $task->title,
            $task->assignee_type,
            $task->assignee_name,
            $task->start_date,
            $task->due_date,
            $task->priority,
            $task->status,
            $task->action_by,
            $task->description,
            $task->completed,
            $task->completed_date,
            $task->accepted_date,
            $task->created_by,
            $task->created_at,
        ];
    }

    /**
     * Column headings
     */
    public function headings(): array
    {
        if ($this->isRTL) {
            return [
                '#',
                __('locale.TaskTitle'),
                __('locale.AssigneeType'),
                __('locale.Assignee'),
                __('locale.StartDate'),
                __('locale.DueDate'),
                __('locale.TaskPriority'),
                __('locale.TaskStatus'),
                __('locale.ActionBy'),
                __('locale.Description'),
                __('locale.Completed'),
                __('locale.CompletedDate'),
                __('locale.AcceptedDate'),
                __('locale.CreatedBy'),
                __('locale.CreatedDate'),
            ];
        }

        return [
            '#',
            __('locale.Task Title'),
            __('locale.Assignee Type'),
            __('locale.Assignee'),
            __('locale.Start Date'),
            __('locale.Due Date'),
            __('locale.Priority'),
            __('locale.Status'),
            __('locale.Last Action By'),
            __('locale.Description'),
            __('locale.Completed'),
            __('locale.Completion Date'),
            __('locale.Acceptance Date'),
            __('locale.Created By'),
            __('locale.Created Date'),
        ];
    }

    /**
     * Column widths
     * 
     * Data starts at column A:
     *   A = # (counter)
     *   B = Task Title
     *   C = Assignee Type
     *   D = Assignee
     *   E = Start Date
     *   F = Due Date
     *   G = Priority
     *   H = Status
     *   I = Last Action By
     *   J = Description
     *   K = Completed
     *   L = Completion Date
     *   M = Acceptance Date
     *   N = Created By
     *   O = Created Date
     */
    public function columnWidths(): array
    {
        return [
            'A' => 6,   // #
            'B' => 40,  // Task Title
            'C' => 18,  // Assignee Type
            'D' => 28,  // Assignee
            'E' => 15,  // Start Date
            'F' => 15,  // Due Date
            'G' => 15,  // Priority
            'H' => 20,  // Status
            'I' => 25,  // Last Action By
            'J' => 50,  // Description
            'K' => 12,  // Completed
            'L' => 20,  // Completion Date
            'M' => 20,  // Acceptance Date
            'N' => 25,  // Created By
            'O' => 20,  // Created Date
        ];
    }

    /**
     * Apply wrap text for long text columns
     */
    protected function applyCustomStyles(Worksheet $sheet)
    {
        $highestRow = $sheet->getHighestRow();

        // Determine header row number (accounting for title and description)
        $headerRow = 1;
        if ($this->title) {
            $headerRow = $this->description ? 3 : 2;
        }
        $dataStartRow = $headerRow + 1;

        // Wrap text for long text columns
        $wrapColumns = ['B', 'D', 'J'];
        foreach ($wrapColumns as $col) {
            $sheet->getStyle("{$col}{$dataStartRow}:{$col}{$highestRow}")
                ->getAlignment()
                ->setWrapText(true);
        }

        // Auto row heights for data rows
        for ($row = $dataStartRow; $row <= $highestRow; $row++) {
            $sheet->getRowDimension($row)->setRowHeight(-1);
        }
    }
}
