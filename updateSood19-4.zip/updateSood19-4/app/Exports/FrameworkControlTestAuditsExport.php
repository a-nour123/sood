<?php

namespace App\Exports;

use App\Models\FrameworkControlTestAudit;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Color;
use Illuminate\Support\Facades\App;

class FrameworkControlTestAuditsExport extends BaseExportTemplate
{
    private $locale;
    private array $rows = [];
    private string $auditType;
    private array $statusArray = [];

    /**
     * Constructor
     */
    public function __construct(string $auditType, $locale = null)
    {
        $this->locale = $locale ?? App::getLocale();
        $this->auditType = $auditType;

        // Set title and description based on audit type
        $title = $this->getTitleByType($auditType);
        $description = $this->getDescriptionByType($auditType);

        parent::__construct($this->locale, $title, $description);

        // Set status array based on audit type
        if ($auditType === 'active') {
            $this->statusArray = [1, 2, 3, 4];
        } elseif ($auditType === 'past') {
            $this->statusArray = [5];
        }

        // Load and process audits
        $audits = $this->loadAudits();

        foreach ($audits as $audit) {
            $this->rows[] = $this->processAudit($audit);
        }
    }

    /**
     * Get title based on audit type
     */
    private function getTitleByType(string $auditType): string
    {
        if ($auditType === 'active') {
            return __('locale.Active Control Test Audits Report');
        } elseif ($auditType === 'past') {
            return __('locale.Past Control Test Audits Report');
        }

        return __('locale.Control Test Audits Report');
    }

    /**
     * Get description based on audit type
     */
    private function getDescriptionByType(string $auditType): string
    {
        if ($auditType === 'active') {
            return __('locale.This report contains all active control test audits including pending, in-progress, and scheduled tests');
        } elseif ($auditType === 'past') {
            return __('locale.This report contains all completed control test audits with their final results');
        }

        return __('locale.This report contains all control test audits with their status and scheduling information');
    }

    /**
     * Load audits filtered by status
     */
    private function loadAudits()
    {
        return FrameworkControlTestAudit::whereIn('status', $this->statusArray)
            ->with([
                'FrameworkControlWithFramworks:id,short_name,family',
                'FrameworkControlWithFramworks.Frameworks',
                'FrameworkControlWithFramworks.Families',
                'UserTester:id,name'
            ])
            ->orderBy('created_at', 'desc')
            ->get();
    }

    /**
     * Process a single audit
     */
    private function processAudit($audit)
    {
        // Process control information
        $controlName = '';
        $frameworkNames = [];
        $subDomainNames = [];

        if ($audit->FrameworkControlWithFramworks) {
            $controlName = $audit->FrameworkControlWithFramworks->short_name;

            // Get framework names
            $frameworkNames = $audit->FrameworkControlWithFramworks->Frameworks
                ->pluck('name')
                ->filter()
                ->toArray();

            // Get sub-domain names
            $subDomainNames = $audit->FrameworkControlWithFramworks->Families
                ->pluck('name')
                ->filter()
                ->toArray();

            // Append frameworks to control name for display
            if (!empty($frameworkNames)) {
                $controlName .= ' (' . implode(', ', $frameworkNames) . ')';
            }
        }

        // Format framework names
        $frameworksDisplay = !empty($frameworkNames)
            ? implode(', ', $frameworkNames)
            : __('locale.No Framework');

        // Format sub-domain names
        $subDomainsDisplay = !empty($subDomainNames)
            ? implode(', ', $subDomainNames)
            : __('locale.No Sub-domain');

        // Get tester name
        $testerName = $audit->UserTester?->name ?? __('locale.Not Assigned');

        // Format test name
        $testName = $audit->name ?? __('locale.No Test Name');

        // Format dates
        $lastDate = $audit->last_date
            ? date('Y-m-d', strtotime($audit->last_date))
            : __('locale.Not Scheduled');

        $nextDate = $audit->next_date
            ? date('Y-m-d', strtotime($audit->next_date))
            : __('locale.Not Scheduled');

        // Calculate days until next test (if applicable)
        $daysUntilNext = $this->calculateDaysUntilNext($audit->next_date);

        // Determine urgency status
        $urgencyStatus = $this->getUrgencyStatus($daysUntilNext);

        return (object)[
            'frameworks' => $frameworksDisplay,
            'sub_domains' => $subDomainsDisplay,
            'control' => $controlName ?: __('locale.Unknown Control'),
            'test_name' => $testName,
            'tester' => $testerName,
            'last_date' => $lastDate,
            'next_date' => $nextDate,
            'days_until_next' => $daysUntilNext,
            'urgency_status' => $urgencyStatus,
        ];
    }

    /**
     * Calculate days until next test
     */
    private function calculateDaysUntilNext($nextDate)
    {
        if (!$nextDate) {
            return null;
        }

        $today = new \DateTime();
        $next = new \DateTime($nextDate);
        $interval = $today->diff($next);

        return $next >= $today ? (int)$interval->format('%a') : -(int)$interval->format('%a');
    }

    /**
     * Get urgency status based on days until next test
     */
    private function getUrgencyStatus($daysUntilNext)
    {
        if ($daysUntilNext === null) {
            return __('locale.Not Scheduled');
        }

        if ($daysUntilNext < 0) {
            return __('locale.Overdue');
        } elseif ($daysUntilNext <= 7) {
            return __('locale.Urgent');
        } elseif ($daysUntilNext <= 30) {
            return __('locale.Upcoming');
        } elseif ($daysUntilNext <= 90) {
            return __('locale.Scheduled');
        } else {
            return __('locale.Future');
        }
    }

    /**
     * Return collection of audits filtered by status
     */
    public function collection()
    {
        return collect($this->rows);
    }

    /**
     * Map each audit to array for export
     */
    public function map($row): array
    {
        return [
            $this->getCounter(),
            $row->frameworks,
            $row->sub_domains,
            $row->control,
            $row->test_name,
            $row->tester,
            $row->last_date,
            $row->next_date,
        ];
    }

    /**
     * Column headings
     */
    public function headings(): array
    {
        if ($this->isRTL) {
            return [
                '#',
                __('locale.Framework'),
                __('locale.control_sub_domain'),
                __('locale.Control'),
                __('locale.TestName'),
                __('locale.Tester'),
                __('locale.LastTestDate'),
                __('locale.NextTestDate'),
            ];
        }

        return [
            '#',
            __('locale.Framework(s)'),
            __('locale.Sub-domain'),
            __('locale.Control'),
            __('locale.Test Name'),
            __('locale.Tester'),
            __('locale.Last Test Date'),
            __('locale.Next Test Date'),
        ];
    }

    /**
     * Column widths
     * 
     * Data starts at column A:
     *   A = # (counter)
     *   B = Framework(s)
     *   C = Sub-domain
     *   D = Control
     *   E = Test Name
     *   F = Tester
     *   G = Last Test Date
     *   H = Next Test Date
     */
    public function columnWidths(): array
    {
        return [
            'A' => 6,   // #
            'B' => 30,  // Framework(s)
            'C' => 30,  // Sub-domain
            'D' => 35,  // Control
            'E' => 30,  // Test Name
            'F' => 25,  // Tester
            'G' => 18,  // Last Test Date
            'H' => 18,  // Next Test Date
        ];
    }

    /**
     * Apply custom wrap text styles
     */
    protected function applyCustomStyles(Worksheet $sheet)
    {
        $highestRow = $sheet->getHighestRow();

        // Determine header row number (accounting for title and description)
        $headerRow = 1;
        if ($this->title) {
            $headerRow = $this->description ? 3 : 2;
        }
        $dataStartRow = $headerRow + 1;

        // Wrap text for Framework(s), Sub-domain, Control, and Test Name columns
        $wrapColumns = ['B', 'C', 'D', 'E'];
        foreach ($wrapColumns as $col) {
            $sheet->getStyle("{$col}{$dataStartRow}:{$col}{$highestRow}")
                ->getAlignment()
                ->setWrapText(true);
        }

        // Auto row heights for data rows
        for ($row = $dataStartRow; $row <= $highestRow; $row++) {
            $sheet->getRowDimension($row)->setRowHeight(-1);
        }
    }
}
