<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithColumnWidths;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithCustomStartCell;
use Maatwebsite\Excel\Events\AfterSheet;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;
use App\Models\Document;
use App\Models\MappedControlsCompliance;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\App;

class ControlDocumentAuditResultsExport implements FromArray, WithStyles, WithColumnWidths, WithEvents, WithCustomStartCell
{
    protected $auditData;
    protected $evidenceData = [];
    protected $companyName;
    protected $auditTitle;
    protected $isRTL = false;
    protected $title;
    protected $description;

    public function __construct($auditId)
    {
        $this->companyName = "King Saud University";
        $this->auditData = MappedControlsCompliance::with([
            'controlDocuments.controls:id,short_name',
        ])->findOrFail($auditId);

        // Check if current locale is Arabic (RTL)
        $this->isRTL = App::getLocale() == 'ar';

        $this->auditTitle = __('report.Control_Document_Audit_Results');

        // Set title and description
        $this->title = $this->auditTitle;
        $this->description = $this->companyName
            . ' - ' . __('report.Control_Document_Audit')
            . ' | ' . __('report.Generated')
            . ': ' . \Carbon\Carbon::now()->format('F j, Y');

        $plannedDate = $this->auditData->start_date;
        $query = collect();

        foreach ($this->auditData->controlDocuments as $doc) {
            $policies = $doc->document_actions['policies'] ?? [];

            $normalizedPolicies = collect($policies)->map(function ($p) {
                return is_array($p) ? $p : ['id' => (int) $p];
            });

            $policyIds = $normalizedPolicies->pluck('id')->toArray();
            $policyModels = Document::whereIn('id', $policyIds)->get(['id', 'document_name']);

            foreach ($policyModels as $policy) {
                $policyMeta = $normalizedPolicies->firstWhere('id', $policy->id);

                $reviewer = null;
                if (!empty($policyMeta['updated_by'])) {
                    $user = User::find($policyMeta['updated_by']);
                    $reviewer = $user?->name;
                }

                $action = null;
                if (($policyMeta['status'] ?? null) === 'approved') {
                    $action = '✔ ' . __('report.Approved');
                } elseif (($policyMeta['status'] ?? null) === 'rejected') {
                    $action = '✘ ' . __('report.Rejected');
                } else {
                    $action = __('report.Pending');
                }

                $query->push([
                    'control_name'  => $doc->controls?->short_name ?? '—',
                    'document_name' => $policy->document_name,
                    'planned_date'  => $plannedDate ? Carbon::parse($plannedDate)->format('Y-m-d') : null,
                    'review_date'   => !empty($policyMeta['updated_at']) ? Carbon::parse($policyMeta['updated_at'])->format('Y-m-d') : null,
                    'reviewer'      => $reviewer,
                    'action'        => $action,
                    'review_notes'  => $policyMeta['note'] ?? null,
                ]);
            }
        }

        $this->evidenceData = $query->toArray();
    }

    public function array(): array
    {
        // Get reviewer names dynamically
        $reviewerNames = '---';
        if (!empty($this->auditData->reviewer_id)) {
            $userIds = explode(',', $this->auditData->reviewer_id);
            $userNames = User::whereIn('id', $userIds)->pluck('name')->toArray();
            $reviewerNames = implode(', ', $userNames) ?: '---';
        }

        // Get version from audit ID
        $version = $this->auditData->id ?? '1';

        // Get date from start_date
        $reviewDate = $this->auditData->start_date ? Carbon::parse($this->auditData->start_date)->format('d/m/Y') : '15/1/2024';

        // Get description
        $description = $this->auditData->description ?? '---';

        $introductionData = [
            [$this->title],
            [$this->description],
            [''],
            [__('report.Document Revision History')],
            [
                __('report.Reviewer'),
                __('report.Version'),
                __('report.Date'),
                __('report.Description')
            ],
            [$reviewerNames, $version, $reviewDate, $description],
            ['', '', '', ''],
            ['', '', '', ''],
            [__('report.Audit Purpose') . ':'],
            [__('report.Audit Purpose Description 1')],
            [__('report.Audit Purpose Description 2')],
            ['', '', '', ''],
            [__('report.Report Generated on') . ': ' . Carbon::now()->format('F j, Y')],
            [__('report.Generated By') . ': ' . (auth()->user()->name ?? __('report.System'))],
            ['', '', '', ''],
            ['', '', '', ''],
            ['', '', '', ''],
        ];

        $headerRow = [
            [
                __('report.Control Name'),
                __('report.Document Name'),
                __('report.Planned Date'),
                __('report.Review Date'),
                __('report.Reviewer'),
                __('report.Action'),
                __('report.Review Notes'),
            ]
        ];

        return array_merge($introductionData, $headerRow, $this->evidenceData);
    }

    public function startCell(): string
    {
        return 'A1';
    }

    public function styles(Worksheet $sheet)
    {
        $totalDataRows = count($this->evidenceData);
        $dataStartRow = 18; // After introduction (updated for title and description)
        $horizontalAlignment = $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_LEFT;

        return [
            // Title
            1 => [
                'font' => ['bold' => true, 'size' => 16, 'color' => ['rgb' => '333333']],
                'alignment' => ['horizontal' => $horizontalAlignment]
            ],

            // Description
            2 => [
                'font' => ['size' => 10, 'italic' => true, 'color' => ['rgb' => '666666']],
                'alignment' => ['horizontal' => $horizontalAlignment]
            ],

            // Revision header
            4 => [
                'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
                'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => '555555']]
            ],

            // Revision data row
            5 => [
                'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => 'F5F5F5']]
            ],

            // Purpose
            9 => [
                'font' => ['bold' => true, 'size' => 12, 'color' => ['rgb' => '444444']],
            ],

            // Generated info
            13 => [
                'font' => ['italic' => true, 'color' => ['rgb' => '666666']],
            ],

            // Header row
            $dataStartRow => [
                'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
                'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER, 'vertical' => Alignment::VERTICAL_CENTER],
                'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => '444444']]
            ],

            // Data rows
            'A' . ($dataStartRow + 1) . ':G' . ($totalDataRows + $dataStartRow) => [
                'alignment' => ['vertical' => Alignment::VERTICAL_CENTER, 'horizontal' => $horizontalAlignment],
                'borders' => ['allBorders' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => 'D9D9D9']]]
            ],

            // Notes column specific style
            'G' . ($dataStartRow + 1) . ':G' . ($totalDataRows + $dataStartRow) => [
                'alignment' => ['vertical' => Alignment::VERTICAL_CENTER, 'horizontal' => $horizontalAlignment, 'wrapText' => true]
            ],

            // Action column specific style
            'F' . ($dataStartRow + 1) . ':F' . ($totalDataRows + $dataStartRow) => [
                'alignment' => ['vertical' => Alignment::VERTICAL_CENTER, 'horizontal' => Alignment::HORIZONTAL_CENTER]
            ],

            // All introduction cells
            'A1:G17' => [
                'alignment' => ['vertical' => Alignment::VERTICAL_TOP, 'horizontal' => $horizontalAlignment],
            ],
        ];
    }

    public function columnWidths(): array
    {
        if ($this->isRTL) {
            return [
                'A' => 25,
                'B' => 40,
                'C' => 15,
                'D' => 15,
                'E' => 30,
                'F' => 15,
                'G' => 45
            ];
        }

        return [
            'A' => 25,
            'B' => 35,
            'C' => 15,
            'D' => 15,
            'E' => 25,
            'F' => 15,
            'G' => 40
        ];
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event) {
                $sheet = $event->sheet->getDelegate();
                $totalDataRows = count($this->evidenceData);
                $dataStartRow = 19; // After introduction (updated for title and description)
                $horizontalAlignment = $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_LEFT;

                // Set sheet direction for RTL
                if ($this->isRTL) {
                    $sheet->setRightToLeft(true);
                }

                // Add logo
                $this->addLogo($sheet);

                // Style title and description
                $this->styleTitleAndDescription($sheet);

                // Add borders to revision history
                $sheet->getStyle('A4:D6')->applyFromArray([
                    'borders' => ['allBorders' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => 'CCCCCC']]]
                ]);

                // Format revision history header
                $sheet->getStyle('A4:D4')->applyFromArray([
                    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER]
                ]);

                // Format revision history data
                $sheet->getStyle('A5:D5')->applyFromArray([
                    'alignment' => ['horizontal' => $horizontalAlignment]
                ]);

                // Apply zebra striping to data rows
                for ($i = $dataStartRow + 1; $i < $totalDataRows + $dataStartRow + 1; $i++) {
                    if ($i % 2 == 0) {
                        $sheet->getStyle('A' . $i . ':G' . $i)->applyFromArray([
                            'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => 'F9F9F9']]
                        ]);
                    }
                }

                // Format date columns
                $sheet->getStyle('C' . ($dataStartRow + 1) . ':D' . ($totalDataRows + $dataStartRow))->applyFromArray([
                    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
                    'numberFormat' => ['formatCode' => 'yyyy-mm-dd']
                ]);

                // Add summary section
                $this->addSummarySection($sheet, $totalDataRows, $dataStartRow, $horizontalAlignment);
            },
        ];
    }

    protected function addLogo($sheet)
    {
        try {
            $drawing = new Drawing();
            $drawing->setName('Logo');
            $drawing->setDescription('Logo');
            $drawing->setPath(public_path('images/ksu-logo.png'));
            $drawing->setHeight(60);
            $drawing->setCoordinates('G1');
            $drawing->setWorksheet($sheet);
            $sheet->getColumnDimension('G')->setWidth(25);
        } catch (\Exception $e) {
            // Logo might not exist, continue without it
        }
    }

    protected function styleTitleAndDescription($sheet)
    {
        $horizontalAlignment = $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_CENTER;

        // Title styling - Dark Gray
        $sheet->mergeCells('A1:G1');
        $sheet->getStyle('A1:G1')->applyFromArray([
            'font' => ['bold' => true, 'size' => 18, 'color' => ['rgb' => 'FFFFFF']],
            'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => '333333']],
            'alignment' => ['horizontal' => $horizontalAlignment, 'vertical' => Alignment::VERTICAL_CENTER]
        ]);
        $sheet->getRowDimension(1)->setRowHeight(35);

        // Description styling - Light Gray
        $sheet->mergeCells('A2:G2');
        $sheet->getStyle('A2:G2')->applyFromArray([
            'font' => ['size' => 10, 'italic' => true, 'color' => ['rgb' => '666666']],
            'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'F5F5F5']],
            'alignment' => ['horizontal' => $horizontalAlignment, 'vertical' => Alignment::VERTICAL_CENTER]
        ]);
        $sheet->getRowDimension(2)->setRowHeight(25);

        // Company name styling
        $sheet->mergeCells('A3:G3');
        $sheet->getStyle('A3:G3')->applyFromArray([
            'font' => ['bold' => true, 'size' => 12, 'color' => ['rgb' => '555555']],
            'alignment' => ['horizontal' => $horizontalAlignment, 'vertical' => Alignment::VERTICAL_CENTER],
            'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'EEEEEE']]
        ]);
        $sheet->getRowDimension(3)->setRowHeight(20);
    }

    protected function addSummarySection($sheet, $totalDataRows, $dataStartRow, $horizontalAlignment)
    {
        $summaryRow = $totalDataRows + $dataStartRow + 2;

        // Summary title - Dark Gray
        $sheet->setCellValue('A' . $summaryRow, __('report.Summary'));
        $sheet->getStyle('A' . $summaryRow)->applyFromArray([
            'font' => ['bold' => true, 'size' => 14, 'color' => ['rgb' => 'FFFFFF']],
            'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => '555555']]
        ]);
        $sheet->mergeCells('A' . $summaryRow . ':G' . $summaryRow);
        $sheet->getStyle('A' . $summaryRow . ':G' . $summaryRow)->applyFromArray([
            'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
            'borders' => ['outline' => ['borderStyle' => Border::BORDER_MEDIUM, 'color' => ['rgb' => '555555']]]
        ]);

        // Approved count
        $approvedCount = count(array_filter($this->evidenceData, function ($item) {
            return strpos($item['action'], '✔') !== false;
        }));

        $sheet->setCellValue('A' . ($summaryRow + 1), __('report.Approved Documents') . ':');
        $sheet->setCellValue('B' . ($summaryRow + 1), $approvedCount);
        $sheet->getStyle('A' . ($summaryRow + 1) . ':B' . ($summaryRow + 1))->applyFromArray([
            'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => 'E8F5E9']],
            'borders' => ['outline' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => 'A5D6A7']]],
            'alignment' => ['horizontal' => $horizontalAlignment]
        ]);
        $sheet->getStyle('B' . ($summaryRow + 1))->applyFromArray([
            'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
            'font' => ['bold' => true, 'size' => 12, 'color' => ['rgb' => '2E7D32']]
        ]);

        // Rejected count
        $rejectedCount = count(array_filter($this->evidenceData, function ($item) {
            return strpos($item['action'], '✘') !== false;
        }));

        $sheet->setCellValue('D' . ($summaryRow + 1), __('report.Rejected Documents') . ':');
        $sheet->setCellValue('E' . ($summaryRow + 1), $rejectedCount);
        $sheet->getStyle('D' . ($summaryRow + 1) . ':E' . ($summaryRow + 1))->applyFromArray([
            'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => 'FFEBEE']],
            'borders' => ['outline' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => 'EF9A9A']]],
            'alignment' => ['horizontal' => $horizontalAlignment]
        ]);
        $sheet->getStyle('E' . ($summaryRow + 1))->applyFromArray([
            'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
            'font' => ['bold' => true, 'size' => 12, 'color' => ['rgb' => 'C62828']]
        ]);

        // Pending count
        $pendingCount = count(array_filter($this->evidenceData, function ($item) {
            return strpos($item['action'], __('report.Pending')) !== false;
        }));

        $sheet->setCellValue('A' . ($summaryRow + 2), __('report.Pending Documents') . ':');
        $sheet->setCellValue('B' . ($summaryRow + 2), $pendingCount);
        $sheet->getStyle('A' . ($summaryRow + 2) . ':B' . ($summaryRow + 2))->applyFromArray([
            'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => 'FFF8E1']],
            'borders' => ['outline' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => 'FFE082']]],
            'alignment' => ['horizontal' => $horizontalAlignment]
        ]);
        $sheet->getStyle('B' . ($summaryRow + 2))->applyFromArray([
            'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
            'font' => ['bold' => true, 'size' => 12, 'color' => ['rgb' => 'F57C00']]
        ]);

        // Total count
        $sheet->setCellValue('D' . ($summaryRow + 2), __('report.Total Documents') . ':');
        $sheet->setCellValue('E' . ($summaryRow + 2), $totalDataRows);
        $sheet->getStyle('D' . ($summaryRow + 2) . ':E' . ($summaryRow + 2))->applyFromArray([
            'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => 'EEEEEE']],
            'borders' => ['outline' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => 'BDBDBD']]],
            'alignment' => ['horizontal' => $horizontalAlignment]
        ]);
        $sheet->getStyle('E' . ($summaryRow + 2))->applyFromArray([
            'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
            'font' => ['bold' => true, 'size' => 12, 'color' => ['rgb' => '333333']]
        ]);

        // Add percentage summary
        if ($totalDataRows > 0) {
            $approvalRate = round(($approvedCount / $totalDataRows) * 100, 2);

            $sheet->setCellValue('A' . ($summaryRow + 4), __('report.Approval Rate') . ':');
            $sheet->setCellValue('B' . ($summaryRow + 4), $approvalRate . '%');
            $sheet->getStyle('A' . ($summaryRow + 4) . ':B' . ($summaryRow + 4))->applyFromArray([
                'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => 'E8F5E9']],
                'borders' => ['outline' => ['borderStyle' => Border::BORDER_MEDIUM, 'color' => ['rgb' => 'A5D6A7']]],
                'font' => ['bold' => true, 'color' => ['rgb' => '2E7D32']],
                'alignment' => ['horizontal' => $horizontalAlignment]
            ]);
            $sheet->getStyle('B' . ($summaryRow + 4))->applyFromArray([
                'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER]
            ]);
        }

        // Freeze panes
        $sheet->freezePane('A' . ($dataStartRow + 1));
    }
}
