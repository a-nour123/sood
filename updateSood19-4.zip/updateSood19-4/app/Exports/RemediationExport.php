<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithColumnWidths;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithCustomStartCell;
use Maatwebsite\Excel\Events\AfterSheet;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;
use App\Models\AuditResponsible;
use App\Models\RemediationDetail;
use Carbon\Carbon;
use Illuminate\Support\Facades\App;

class RemediationExport implements FromArray, WithStyles, WithColumnWidths, WithEvents, WithCustomStartCell
{
    protected $frameworkId;
    protected $auditId;
    protected $remediationData = [];
    protected $companyName;
    protected $auditName;
    protected $frameworkName;
    protected $statistics = [];
    protected $isRTL = false;
    protected $title;
    protected $description;

    public function __construct($frameworkId, $auditId, $companyName = "King Saud University")
    {
        $this->frameworkId = $frameworkId;
        $this->auditId = $auditId;
        $this->companyName = $companyName;

        // Check if current locale is Arabic (RTL)
        $this->isRTL = App::getLocale() == 'ar';

        $this->prepareData();
        $this->calculateStatistics();
        
        // Set title and description
        $this->title = __('report.Remediation Plan Report');
        $this->description = sprintf(
            '%s - %s | %s | %s: %s',
            $this->companyName,
            $this->frameworkName,
            $this->auditName,
            __('report.Generated'),
            Carbon::now()->format('F j, Y H:i')
        );
    }

    protected function prepareData()
    {
        // Load AuditResponsible
        $audit = AuditResponsible::with(['frameworkaduit:id,name'])
            ->where('framework_id', $this->frameworkId)
            ->where('id', $this->auditId)
            ->first();

        if (!$audit) {
            $this->remediationData = [];
            return;
        }

        $this->auditName = $audit->audit_name;
        $this->frameworkName = $audit->frameworkaduit->name ?? '';

        // Load remediation details separately
        $remediationDetails = RemediationDetail::with([
            'user:id,name,department_id',
            'user.department:id,name',
            'controlTestAudit.frameworkControl:id,short_name',
            'controlTestAudit.auditResponsible:id,audit_name',
        ])
            ->whereHas('controlTestAudit', function ($query) use ($audit) {
                $query->where('audit_id', $audit->id);
            })
            ->get();

        $rows = collect();

        foreach ($remediationDetails as $remediation) {
            $controlTestAudit = $remediation->controlTestAudit;

            if (!$controlTestAudit) {
                continue;
            }

            $rows->push([
                __('report.Framework Name')          => $this->frameworkName,
                __('report.Audit Name')              => $this->auditName,
                __('report.Control Name')            => $controlTestAudit->frameworkControl->name ?? $controlTestAudit->name ?? '',
                __('report.Control Short Name')      => $controlTestAudit->frameworkControl->short_name ?? '',
                __('report.Responsible User')        => $remediation->user->name ?? '',
                __('report.Department')              => $remediation->user->department->name ?? '',
                __('report.Corrective Action Plan')  => strip_tags($remediation->corrective_action_plan ?? ''),
                __('report.Budgetary')               => $this->formatBudgetary($remediation->budgetary ?? ''),
                __('report.Status')                  => $this->getStatusText($remediation->status ?? ''),
                __('report.Due Date')                => $remediation?->due_date ? Carbon::parse($remediation->due_date)->format('Y-m-d') : '',
                __('report.Comments')                => $remediation->comments ?? '',
                'Is Overdue'                         => $this->isOverdue($remediation),
            ]);
        }

        $this->remediationData = $rows->toArray();
    }

    protected function calculateStatistics()
    {
        $totalRemediations = count($this->remediationData);

        // Count by status
        $approvedCount = 0;
        $rejectedCount = 0;
        $pendingCount = 0;
        $overdueCount = 0;
        $totalBudget = 0;

        foreach ($this->remediationData as $item) {
            switch ($item[__('report.Status')]) {
                case __('report.Approved'):
                    $approvedCount++;
                    break;
                case __('report.Rejected'):
                    $rejectedCount++;
                    break;
                case __('report.Pending'):
                    $pendingCount++;
                    break;
            }

            // Calculate overdue
            if ($item['Is Overdue']) {
                $overdueCount++;
            }

            // Calculate budget
            $budgetValue = $item[__('report.Budgetary')] ?? '';
            if (!empty($budgetValue) && is_numeric(str_replace(['$', ',', ' '], '', $budgetValue))) {
                $totalBudget += floatval(str_replace(['$', ',', ' '], '', $budgetValue));
            }
        }

        // Calculate percentages
        $completionRate = $totalRemediations > 0 ?
            round((($approvedCount + $rejectedCount) / $totalRemediations) * 100, 2) : 0;

        $approvalRate = $totalRemediations > 0 ?
            round(($approvedCount / $totalRemediations) * 100, 2) : 0;

        $this->statistics = [
            'total_remediations' => $totalRemediations,
            'approved_count' => $approvedCount,
            'rejected_count' => $rejectedCount,
            'pending_count' => $pendingCount,
            'overdue_count' => $overdueCount,
            'total_budget' => $totalBudget,
            'completion_rate' => $completionRate,
            'approval_rate' => $approvalRate,
        ];
    }

    protected function getStatusText($status)
    {
        return match ($status) {
            1 => __('report.Approved'),
            2 => __('report.Rejected'),
            default => __('report.Pending'),
        };
    }

    protected function formatBudgetary($budgetary)
    {
        if (empty($budgetary)) return '';

        if (is_numeric(str_replace(['$', ',', ' '], '', $budgetary))) {
            $value = floatval(str_replace(['$', ',', ' '], '', $budgetary));
            return '$' . number_format($value, 2);
        }

        return $budgetary;
    }

    protected function isOverdue($remediation)
    {
        if (!$remediation || empty($remediation->due_date)) {
            return false;
        }

        $dueDate = Carbon::parse($remediation->due_date);
        $status = $remediation->status;

        return ($status != 1 && $status != 2) && $dueDate->isPast();
    }

    public function array(): array
    {
        // If no data, return empty with message
        if (empty($this->remediationData)) {
            return [
                [$this->title],
                [$this->description],
                [''],
                [__('report.No remediation data found for the selected audit.')],
                [''],
                [__('report.Framework') . ': ' . $this->frameworkName],
                [__('report.Audit') . ': ' . $this->auditName],
                [__('report.Generated on') . ': ' . Carbon::now()->format('F j, Y H:i')],
            ];
        }

        // Introduction section
        $introductionData = [
            [$this->title],
            [$this->description],
            [''],
            [__('report.Audit Remediation Details - Controls with Remediation Actions')],
            ['', '', '', '', '', '', '', '', '', ''],
            [__('report.Report Information')],
            [
                __('report.Framework'),
                __('report.Audit'),
                __('report.Total Controls with Remediation'),
                __('report.Generated By'),
                __('report.Generation Date')
            ],
            [
                $this->frameworkName,
                $this->auditName,
                count($this->remediationData),
                auth()->user()->name ?? __('report.System'),
                Carbon::now()->format('d/m/Y H:i')
            ],
            ['', '', '', '', ''],
            ['', '', '', '', ''],
            [__('report.Report Purpose') . ':'],
            [__('report.This report provides detailed information about remediation plans and corrective actions for audit findings.')],
            [__('report.It includes only controls that have remediation actions assigned, with assigned responsibilities, budgetary requirements, and implementation timelines.')],
            ['', '', '', '', '', '', '', '', '', ''],
            ['', '', '', '', '', '', '', '', '', ''],
            ['', '', '', '', '', '', '', '', '', ''],
        ];

        $headerRow = [[
            __('report.Framework Name'),
            __('report.Audit Name'),
            __('report.Control Name'),
            __('report.Control Short Name'),
            __('report.Responsible User'),
            __('report.Department'),
            __('report.Corrective Action Plan'),
            __('report.Budgetary'),
            __('report.Status'),
            __('report.Due Date'),
            __('report.Comments')
        ]];

        return array_merge($introductionData, $headerRow, $this->remediationData);
    }

    public function startCell(): string
    {
        return 'A1';
    }

    public function styles(Worksheet $sheet)
    {
        $totalDataRows = count($this->remediationData);
        $horizontalAlignment = $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_LEFT;

        // If no data, style the message
        if ($totalDataRows === 0) {
            return [
                1 => [
                    'font' => ['bold' => true, 'size' => 18, 'color' => ['rgb' => '333333']],
                    'alignment' => ['horizontal' => $horizontalAlignment]
                ],
                2 => [
                    'font' => ['size' => 10, 'italic' => true, 'color' => ['rgb' => '666666']],
                    'alignment' => ['horizontal' => $horizontalAlignment]
                ],
                'A1:E8' => [
                    'alignment' => ['horizontal' => $horizontalAlignment, 'vertical' => Alignment::VERTICAL_CENTER],
                ],
            ];
        }

        $dataStartRow = 19; // After introduction (updated for title and description)

        return [
            // Main title
            1 => [
                'font' => ['bold' => true, 'size' => 18, 'color' => ['rgb' => 'FFFFFF']],
                'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => '333333']],
                'alignment' => ['horizontal' => $horizontalAlignment]
            ],

            // Description
            2 => [
                'font' => ['size' => 10, 'italic' => true, 'color' => ['rgb' => '666666']],
                'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => 'F5F5F5']],
                'alignment' => ['horizontal' => $horizontalAlignment]
            ],

            // Subtitle
            4 => [
                'font' => ['bold' => true, 'size' => 14, 'color' => ['rgb' => '555555']],
                'alignment' => ['horizontal' => $horizontalAlignment]
            ],

            // Report Information header
            6 => [
                'font' => ['bold' => true, 'size' => 12, 'color' => ['rgb' => '444444']],
                'alignment' => ['horizontal' => $horizontalAlignment]
            ],

            // Report Information column headers
            7 => [
                'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
                'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => '555555']],
                'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER]
            ],

            // Report Information data row
            8 => [
                'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => 'F9F9F9']],
                'alignment' => ['horizontal' => $horizontalAlignment]
            ],

            // Purpose header
            11 => [
                'font' => ['bold' => true, 'size' => 12, 'color' => ['rgb' => '444444']],
                'alignment' => ['horizontal' => $horizontalAlignment]
            ],

            // Purpose descriptions
            12 => ['alignment' => ['wrapText' => true, 'horizontal' => $horizontalAlignment]],
            13 => ['alignment' => ['wrapText' => true, 'horizontal' => $horizontalAlignment]],

            // Header row
            $dataStartRow => [
                'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
                'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER, 'vertical' => Alignment::VERTICAL_CENTER],
                'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => '444444']]
            ],

            // Data rows
            'A' . ($dataStartRow + 1) . ':K' . ($totalDataRows + $dataStartRow) => [
                'alignment' => ['vertical' => Alignment::VERTICAL_CENTER, 'horizontal' => $horizontalAlignment],
                'borders' => ['allBorders' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => 'D9D9D9']]]
            ],

            // Wrap text columns
            'G' . ($dataStartRow + 1) . ':G' . ($totalDataRows + $dataStartRow) => [
                'alignment' => ['wrapText' => true, 'horizontal' => $horizontalAlignment]
            ],
            'K' . ($dataStartRow + 1) . ':K' . ($totalDataRows + $dataStartRow) => [
                'alignment' => ['wrapText' => true, 'horizontal' => $horizontalAlignment]
            ],

            // Center align for specific columns
            'D' . ($dataStartRow + 1) . ':D' . ($totalDataRows + $dataStartRow) => [
                'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER]
            ],
            'H' . ($dataStartRow + 1) . ':H' . ($totalDataRows + $dataStartRow) => [
                'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER]
            ],
            'I' . ($dataStartRow + 1) . ':I' . ($totalDataRows + $dataStartRow) => [
                'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER]
            ],
            'J' . ($dataStartRow + 1) . ':J' . ($totalDataRows + $dataStartRow) => [
                'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER, 'vertical' => Alignment::VERTICAL_CENTER]
            ],

            // All introduction cells
            'A1:K18' => [
                'alignment' => ['vertical' => Alignment::VERTICAL_TOP, 'horizontal' => $horizontalAlignment],
            ],
        ];
    }

    public function columnWidths(): array
    {
        if ($this->isRTL) {
            return [
                'A' => 25, 'B' => 25, 'C' => 35, 'D' => 20, 'E' => 25,
                'F' => 25, 'G' => 45, 'H' => 15, 'I' => 15, 'J' => 15, 'K' => 40
            ];
        }

        return [
            'A' => 25, 'B' => 25, 'C' => 30, 'D' => 20, 'E' => 20,
            'F' => 40, 'G' => 15, 'H' => 15, 'I' => 15, 'J' => 35
        ];
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event) {
                $sheet = $event->sheet->getDelegate();
                $totalDataRows = count($this->remediationData);
                $horizontalAlignment = $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_LEFT;

                // Set sheet direction for RTL
                if ($this->isRTL) {
                    $sheet->setRightToLeft(true);
                }

                // Add logo
                $this->addLogo($sheet);

                // Style title and description
                $this->styleTitleAndDescription($sheet);

                // If no data, just return
                if ($totalDataRows === 0) {
                    return;
                }

                $dataStartRow = 20; // After introduction (updated for title and description)

                // Add borders to report information section
                $sheet->getStyle('A7:E8')->applyFromArray([
                    'borders' => ['allBorders' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => 'CCCCCC']]]
                ]);

                // Format report information header
                $sheet->getStyle('A7:E7')->applyFromArray([
                    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER]
                ]);

                // Format report information data
                $sheet->getStyle('A8:E8')->applyFromArray([
                    'alignment' => ['horizontal' => $horizontalAlignment]
                ]);

                // Apply zebra striping to data rows
                for ($i = $dataStartRow + 1; $i < $totalDataRows + $dataStartRow + 1; $i++) {
                    if ($i % 2 == 0) {
                        $sheet->getStyle('A' . $i . ':K' . $i)->applyFromArray([
                            'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => 'F9F9F9']]
                        ]);
                    }
                }

                // Format date column
                $sheet->getStyle('J' . ($dataStartRow + 1) . ':J' . ($totalDataRows + $dataStartRow))->applyFromArray([
                    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
                    'numberFormat' => ['formatCode' => 'yyyy-mm-dd']
                ]);

                // Format budgetary column as currency
                $sheet->getStyle('H' . ($dataStartRow + 1) . ':H' . ($totalDataRows + $dataStartRow))->applyFromArray([
                    'numberFormat' => ['formatCode' => '#,##0.00"$"']
                ]);

                // Color code status column
                $this->applyStatusColorCoding($sheet, $dataStartRow, $totalDataRows);

                // Add summary section with statistics
                $this->addSummarySection($sheet, $dataStartRow, $totalDataRows, $horizontalAlignment);

                // Freeze panes
                $sheet->freezePane('A' . ($dataStartRow + 1));

                // Set auto filter on header
                $sheet->setAutoFilter('A' . $dataStartRow . ':K' . $dataStartRow);
            },
        ];
    }

    protected function addLogo($sheet)
    {
        try {
            $drawing = new Drawing();
            $drawing->setName('Logo');
            $drawing->setDescription('Logo');
            $drawing->setPath(public_path('images/ksu-logo.png'));
            $drawing->setHeight(60);
            $drawing->setCoordinates('K1');
            $drawing->setWorksheet($sheet);
            $sheet->getColumnDimension('K')->setWidth(25);
        } catch (\Exception $e) {
            // Logo might not exist, continue without it
        }
    }

    protected function styleTitleAndDescription($sheet)
    {
        $horizontalAlignment = $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_CENTER;
        
        // Title styling - Dark Gray
        $sheet->mergeCells('A1:K1');
        $sheet->getStyle('A1:K1')->applyFromArray([
            'font' => ['bold' => true, 'size' => 18, 'color' => ['rgb' => 'FFFFFF']],
            'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => '333333']],
            'alignment' => ['horizontal' => $horizontalAlignment, 'vertical' => Alignment::VERTICAL_CENTER]
        ]);
        $sheet->getRowDimension(1)->setRowHeight(35);
        
        // Description styling - Light Gray
        $sheet->mergeCells('A2:K2');
        $sheet->getStyle('A2:K2')->applyFromArray([
            'font' => ['size' => 10, 'italic' => true, 'color' => ['rgb' => '666666']],
            'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'F5F5F5']],
            'alignment' => ['horizontal' => $horizontalAlignment, 'vertical' => Alignment::VERTICAL_CENTER]
        ]);
        $sheet->getRowDimension(2)->setRowHeight(25);
        
        // Company name styling
        $sheet->setCellValue('A3', $this->companyName);
        $sheet->mergeCells('A3:K3');
        $sheet->getStyle('A3:K3')->applyFromArray([
            'font' => ['bold' => true, 'size' => 12, 'color' => ['rgb' => '555555']],
            'alignment' => ['horizontal' => $horizontalAlignment, 'vertical' => Alignment::VERTICAL_CENTER],
            'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'EEEEEE']]
        ]);
        $sheet->getRowDimension(3)->setRowHeight(20);
    }

    protected function applyStatusColorCoding($sheet, $dataStartRow, $totalDataRows)
    {
        for ($i = $dataStartRow + 1; $i <= $totalDataRows + $dataStartRow; $i++) {
            $statusCell = 'I' . $i;
            $statusValue = $sheet->getCell($statusCell)->getValue();

            if ($statusValue === __('report.Approved')) {
                $sheet->getStyle($statusCell)->applyFromArray([
                    'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => 'E8F5E9']],
                    'font' => ['color' => ['rgb' => '2E7D32'], 'bold' => true]
                ]);
            } elseif ($statusValue === __('report.Rejected')) {
                $sheet->getStyle($statusCell)->applyFromArray([
                    'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => 'FFEBEE']],
                    'font' => ['color' => ['rgb' => 'C62828'], 'bold' => true]
                ]);
            } elseif ($statusValue === __('report.Pending')) {
                $sheet->getStyle($statusCell)->applyFromArray([
                    'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => 'FFF8E1']],
                    'font' => ['color' => ['rgb' => 'F57C00'], 'bold' => true]
                ]);
            }
        }
    }

    protected function addSummarySection($sheet, $dataStartRow, $totalDataRows, $horizontalAlignment)
    {
        $summaryRow = $totalDataRows + $dataStartRow + 2;

        // Summary title - Dark Gray
        $sheet->setCellValue('A' . $summaryRow, __('report.Remediation Summary - Statistics'));
        $sheet->getStyle('A' . $summaryRow)->applyFromArray([
            'font' => ['bold' => true, 'size' => 14, 'color' => ['rgb' => 'FFFFFF']],
            'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => '555555']]
        ]);
        $sheet->mergeCells('A' . $summaryRow . ':K' . $summaryRow);
        $sheet->getStyle('A' . $summaryRow . ':K' . $summaryRow)->applyFromArray([
            'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
            'borders' => ['outline' => ['borderStyle' => Border::BORDER_MEDIUM, 'color' => ['rgb' => '555555']]]
        ]);

        // Total Remediations
        $sheet->setCellValue('A' . ($summaryRow + 1), __('report.Total Remediation Items') . ':');
        $sheet->setCellValue('B' . ($summaryRow + 1), $this->statistics['total_remediations']);
        $sheet->getStyle('A' . ($summaryRow + 1) . ':B' . ($summaryRow + 1))->applyFromArray([
            'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => 'EEEEEE']],
            'borders' => ['outline' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => 'BDBDBD']]],
            'alignment' => ['horizontal' => $horizontalAlignment]
        ]);
        $sheet->getStyle('B' . ($summaryRow + 1))->applyFromArray([
            'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
            'font' => ['bold' => true, 'size' => 12, 'color' => ['rgb' => '333333']]
        ]);

        // Approved count
        $sheet->setCellValue('D' . ($summaryRow + 1), __('report.Approved Remediations') . ':');
        $sheet->setCellValue('E' . ($summaryRow + 1), $this->statistics['approved_count']);
        $sheet->getStyle('D' . ($summaryRow + 1) . ':E' . ($summaryRow + 1))->applyFromArray([
            'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => 'E8F5E9']],
            'borders' => ['outline' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => 'A5D6A7']]],
            'alignment' => ['horizontal' => $horizontalAlignment]
        ]);
        $sheet->getStyle('E' . ($summaryRow + 1))->applyFromArray([
            'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
            'font' => ['bold' => true, 'size' => 12, 'color' => ['rgb' => '2E7D32']]
        ]);

        // Rejected count
        $sheet->setCellValue('G' . ($summaryRow + 1), __('report.Rejected Remediations') . ':');
        $sheet->setCellValue('H' . ($summaryRow + 1), $this->statistics['rejected_count']);
        $sheet->getStyle('G' . ($summaryRow + 1) . ':H' . ($summaryRow + 1))->applyFromArray([
            'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => 'FFEBEE']],
            'borders' => ['outline' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => 'EF9A9A']]],
            'alignment' => ['horizontal' => $horizontalAlignment]
        ]);
        $sheet->getStyle('H' . ($summaryRow + 1))->applyFromArray([
            'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
            'font' => ['bold' => true, 'size' => 12, 'color' => ['rgb' => 'C62828']]
        ]);

        // Pending count
        $sheet->setCellValue('A' . ($summaryRow + 2), __('report.Pending Remediations') . ':');
        $sheet->setCellValue('B' . ($summaryRow + 2), $this->statistics['pending_count']);
        $sheet->getStyle('A' . ($summaryRow + 2) . ':B' . ($summaryRow + 2))->applyFromArray([
            'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => 'FFF8E1']],
            'borders' => ['outline' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => 'FFE082']]],
            'alignment' => ['horizontal' => $horizontalAlignment]
        ]);
        $sheet->getStyle('B' . ($summaryRow + 2))->applyFromArray([
            'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
            'font' => ['bold' => true, 'size' => 12, 'color' => ['rgb' => 'F57C00']]
        ]);

        // Overdue count
        $sheet->setCellValue('D' . ($summaryRow + 2), __('report.Overdue Remediations') . ':');
        $sheet->setCellValue('E' . ($summaryRow + 2), $this->statistics['overdue_count']);
        $sheet->getStyle('D' . ($summaryRow + 2) . ':E' . ($summaryRow + 2))->applyFromArray([
            'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => 'FFEBEE']],
            'borders' => ['outline' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => 'EF9A9A']]],
            'alignment' => ['horizontal' => $horizontalAlignment]
        ]);
        $sheet->getStyle('E' . ($summaryRow + 2))->applyFromArray([
            'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
            'font' => ['bold' => true, 'size' => 12, 'color' => ['rgb' => 'C62828']]
        ]);

        // Budget summary
        $sheet->setCellValue('G' . ($summaryRow + 2), __('report.Total Budget Required') . ':');
        $sheet->setCellValue('H' . ($summaryRow + 2), '$' . number_format($this->statistics['total_budget'], 2));
        $sheet->getStyle('G' . ($summaryRow + 2) . ':H' . ($summaryRow + 2))->applyFromArray([
            'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => 'EEEEEE']],
            'borders' => ['outline' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => 'BDBDBD']]],
            'alignment' => ['horizontal' => $horizontalAlignment]
        ]);
        $sheet->getStyle('H' . ($summaryRow + 2))->applyFromArray([
            'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
            'font' => ['bold' => true, 'size' => 12, 'color' => ['rgb' => '333333']],
            'numberFormat' => ['formatCode' => '#,##0.00"$"']
        ]);

        // Completion Rate
        $sheet->setCellValue('A' . ($summaryRow + 3), __('report.Completion Rate') . ':');
        $sheet->setCellValue('B' . ($summaryRow + 3), $this->statistics['completion_rate'] . '%');
        $sheet->getStyle('A' . ($summaryRow + 3) . ':B' . ($summaryRow + 3))->applyFromArray([
            'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => 'EEEEEE']],
            'borders' => ['outline' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => 'BDBDBD']]],
            'alignment' => ['horizontal' => $horizontalAlignment]
        ]);
        $sheet->getStyle('B' . ($summaryRow + 3))->applyFromArray([
            'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
            'font' => ['bold' => true, 'size' => 12, 'color' => ['rgb' => '333333']]
        ]);

        // Approval Rate
        $sheet->setCellValue('D' . ($summaryRow + 3), __('report.Approval Rate') . ':');
        $sheet->setCellValue('E' . ($summaryRow + 3), $this->statistics['approval_rate'] . '%');
        $sheet->getStyle('D' . ($summaryRow + 3) . ':E' . ($summaryRow + 3))->applyFromArray([
            'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => 'E8F5E9']],
            'borders' => ['outline' => ['borderStyle' => Border::BORDER_MEDIUM, 'color' => ['rgb' => 'A5D6A7']]],
            'font' => ['bold' => true, 'color' => ['rgb' => '2E7D32']],
            'alignment' => ['horizontal' => $horizontalAlignment]
        ]);
        $sheet->getStyle('E' . ($summaryRow + 3))->applyFromArray([
            'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER]
        ]);

        // Report footer
        $footerRow = $summaryRow + 5;
        $sheet->setCellValue('A' . $footerRow, __('report.Report generated on') . ': ' . Carbon::now()->format('F j, Y H:i:s'));
        $sheet->getStyle('A' . $footerRow)->applyFromArray([
            'font' => ['italic' => true, 'size' => 10, 'color' => ['rgb' => '666666']],
            'alignment' => ['horizontal' => $horizontalAlignment]
        ]);
        $sheet->mergeCells('A' . $footerRow . ':K' . $footerRow);
    }
}