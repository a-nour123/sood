<?php

namespace App\Exports;

use App\Models\CenterPolicy;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use Illuminate\Support\Facades\App;

class PolicyClauseExport extends BaseExportTemplate
{
    private $locale;
    private array $rows = [];

    public function __construct($locale = null)
    {
        $this->locale = $locale ?? App::getLocale();

        $title = __('locale.Policy Clauses Report');
        $description = __('locale.This report contains all policy clauses with their translations and associated documents');

        parent::__construct($this->locale, $title, $description);

        // Load and process policies
        $policies = CenterPolicy::with(['documents'])->get();

        foreach ($policies as $policy) {
            $this->rows[] = $this->processPolicy($policy);
        }
    }
    /**
     * Process a single policy
     */
    private function processPolicy($policy)
    {
        // Get document names
        $documentNames = $policy->documents->pluck('document_name')->filter()->toArray();

        $documentsList = !empty($documentNames)
            ? implode(', ', $documentNames)
            : __('locale.No documents attached');

        // Get document count
        $documentCount = count($documentNames);

        // Handle policy_name as array or JSON
        $policyNameEn = '';
        $policyNameAr = '';
        $policyNameRaw = $policy->getRawOriginal('policy_name');

        if (is_array($policyNameRaw)) {
            $policyNameEn = $policyNameRaw['en'] ?? '';
            $policyNameAr = $policyNameRaw['ar'] ?? '';
        } elseif (is_string($policyNameRaw)) {
            $decoded = json_decode($policyNameRaw, true);
            if (is_array($decoded)) {
                $policyNameEn = $decoded['en'] ?? '';
                $policyNameAr = $decoded['ar'] ?? '';
            } else {
                // If it's a plain string, use it for both or assign appropriately based on locale
                $policyNameEn = $policyNameRaw;
                $policyNameAr = $policyNameRaw;
            }
        }

        // Clean and format policy names
        $policyNameEn = $this->cleanPolicyName($policyNameEn);
        $policyNameAr = $this->cleanPolicyName($policyNameAr);

        // Add fallbacks if names are empty
        $policyNameEn = !empty($policyNameEn)
            ? $policyNameEn
            : __('locale.No English clause name');

        $policyNameAr = !empty($policyNameAr)
            ? $policyNameAr
            : __('locale.No Arabic clause name');

        return (object)[
            'policy_en' => $policyNameEn,
            'policy_ar' => $policyNameAr,
            'documents' => $documentsList,
            'document_count' => $documentCount,
            'policy_id' => $policy->id,
        ];
    }

    /**
     * Clean policy name by stripping HTML tags and trimming
     */
    private function cleanPolicyName($name)
    {
        if (empty($name)) {
            return '';
        }

        // Strip HTML tags if any
        $cleaned = strip_tags($name);

        // Trim whitespace
        $cleaned = trim($cleaned);

        return $cleaned;
    }

    /**
     * Return collection
     */
    public function collection()
    {
        return collect($this->rows);
    }

    /**
     * Map each row
     */
    public function map($row): array
    {
        return [
            $this->getCounter(),
            $row->policy_en,
            $row->policy_ar,
            $row->documents,
        ];
    }

    /**
     * Column headings
     */
    public function headings(): array
    {
        if ($this->isRTL) {
            return [
                '#',
                __('locale.PolicyClauseEn'),
                __('locale.PolicyClauseAr'),
                __('locale.Document'),
            ];
        }

        return [
            '#',
            __('locale.Policy Clause (English)'),
            __('locale.Policy Clause (Arabic)'),
            __('locale.Associated Documents'),
        ];
    }

    /**
     * Column widths
     * 
     * Data starts at column A:
     *   A = # (counter)
     *   B = Policy Clause (English)
     *   C = Policy Clause (Arabic)
     *   D = Associated Documents
     */
    public function columnWidths(): array
    {
        return [
            'A' => 6,   // #
            'B' => 45,  // Policy Clause (English)
            'C' => 45,  // Policy Clause (Arabic)
            'D' => 50,  // Associated Documents
        ];
    }

    /**
     * Apply wrap text
     */
    protected function applyCustomStyles(Worksheet $sheet)
    {
        $highestRow = $sheet->getHighestRow();

        // Determine header row number (accounting for title and description)
        $headerRow = 1;
        if ($this->title) {
            $headerRow = $this->description ? 3 : 2;
        }
        $dataStartRow = $headerRow + 1;

        // Wrap text for all content columns
        $wrapColumns = ['B', 'C', 'D'];
        foreach ($wrapColumns as $col) {
            $sheet->getStyle("{$col}{$dataStartRow}:{$col}{$highestRow}")
                ->getAlignment()
                ->setWrapText(true);
        }

        // Auto row heights for data rows
        for ($row = $dataStartRow; $row <= $highestRow; $row++) {
            $sheet->getRowDimension($row)->setRowHeight(-1);
        }
    }
}
