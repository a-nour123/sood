<?php

namespace App\Exports;

use App\Models\User;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Color;
use Illuminate\Support\Facades\App;

class UsersExport extends BaseExportTemplate
{
    private $locale;
    private array $rows = [];

    public function __construct(?string $locale = null)
    {
        $this->locale = $locale ?? App::getLocale();

        $title = __('locale.Users Report');
        $description = __('locale.This report contains all system users with their roles, permissions, and account status');

        parent::__construct($this->locale, $title, $description);

        // Load and process users
        $users = User::with(['role', 'department'])->get();

        foreach ($users as $user) {
            $this->rows[] = $this->processUser($user);
        }
    }

    /**
     * Process a single user
     */
    private function processUser($user)
    {
        // Translate user type
        $userType = $this->translateUserType($user->type);

        // Get role name with fallback
        $roleName = $user->role->name ?? __('locale.No Role Assigned');

        // Get department name with fallback
        $departmentName = $user->department ? $user->department->name : __('locale.No Department');

        // Format region
        $region = $user->ldap_region ?? __('locale.Not specified');

        // Get status indicators
        $isAdmin = $user->admin ? '✓' : '✗';
        $isEnabled = $user->enabled ? '✓' : '✗';

        // Get user statistics
        $userStats = $this->getUserStatistics($user);

        // Format dates if available
        $lastLogin = $user->last_login_at
            ? date('Y-m-d H:i', strtotime($user->last_login_at))
            : __('locale.Never');

        $createdAt = $user->created_at
            ? $user->created_at->format('Y-m-d H:i')
            : __('locale.N/A');

        return (object)[
            'type' => $userType,
            'type_raw' => $user->type,
            'username' => $user->username ?? __('locale.N/A'),
            'name' => $user->name ?? __('locale.Unknown'),
            'email' => $user->email ?? __('locale.No email'),
            'role' => $roleName,
            'is_admin' => $isAdmin,
            'is_admin_raw' => $user->admin,
            'is_enabled' => $isEnabled,
            'is_enabled_raw' => $user->enabled,
            'department' => $departmentName,
            'region' => $region,
            'last_login' => $lastLogin,
            'created_at' => $createdAt,
            'task_count' => $userStats['task_count'],
            'created_task_count' => $userStats['created_task_count'],
        ];
    }

    /**
     * Translate user type
     */
    private function translateUserType($type)
    {
        if (empty($type)) {
            return __('locale.Standard');
        }

        $typeMap = [
            'admin' => 'locale.Administrator',
            'manager' => 'locale.Manager',
            'user' => 'locale.Standard User',
            'viewer' => 'locale.Viewer',
            'auditor' => 'locale.Auditor',
        ];

        $key = $typeMap[$type] ?? 'locale.' . ucfirst($type);
        $translated = __($key);

        if ($translated == $key) {
            $translated = ucfirst($type);
        }

        return $translated;
    }

    /**
     * Get user statistics
     */
    private function getUserStatistics($user)
    {
        return [
            'task_count' => $user->tasks()->count(),
            'created_task_count' => $user->createdTasks()->count(),
        ];
    }

    /**
     * Return collection
     */
    public function collection()
    {
        return collect($this->rows);
    }

    /**
     * Map each user to an export row
     */
    public function map($user): array
    {
        return [
            $this->getCounter(),
            $user->type,
            $user->username,
            $user->name,
            $user->email,
            $user->role,
            $user->is_admin,
            $user->is_enabled,
            $user->department,
            $user->region,
        ];
    }

    /**
     * Column headings
     */
    public function headings(): array
    {
        if ($this->isRTL) {
            return [
                '#',
                __('locale.Type'),
                __('locale.Username'),
                __('locale.Name'),
                __('locale.Email'),
                __('locale.Role'),
                __('locale.Admin'),
                __('locale.Active'),
                __('locale.Department'),
                __('configure.Region')
            ];
        }

        return [
            '#',
            __('locale.User Type'),
            __('locale.Username'),
            __('locale.Full Name'),
            __('locale.Email Address'),
            __('locale.Role'),
            __('locale.Administrator'),
            __('locale.Account Active'),
            __('locale.Department'),
            __('locale.Region'),
        ];
    }

    /**
     * Column widths
     * 
     * Data starts at column A:
     *   A = # (counter)
     *   B = User Type
     *   C = Username
     *   D = Full Name
     *   E = Email Address
     *   F = Role
     *   G = Administrator
     *   H = Account Active
     *   I = Department
     *   J = Region
     */
    public function columnWidths(): array
    {
        return [
            'A' => 6,   // #
            'B' => 18,  // User Type
            'C' => 25,  // Username
            'D' => 28,  // Full Name
            'E' => 35,  // Email Address
            'F' => 22,  // Role
            'G' => 14,  // Administrator
            'H' => 16,  // Account Active
            'I' => 28,  // Department
            'J' => 22,  // Region
        ];
    }

    /**
     * Apply wrap text for relevant columns
     */
    protected function applyCustomStyles(Worksheet $sheet)
    {
        $highestRow = $sheet->getHighestRow();

        // Determine header row number (accounting for title and description)
        $headerRow = 1;
        if ($this->title) {
            $headerRow = $this->description ? 3 : 2;
        }
        $dataStartRow = $headerRow + 1;

        // Wrap text for long text columns
        $wrapColumns = ['B', 'D', 'J'];
        foreach ($wrapColumns as $col) {
            $sheet->getStyle("{$col}{$dataStartRow}:{$col}{$highestRow}")
                ->getAlignment()
                ->setWrapText(true);
        }

        // Auto row heights for data rows
        for ($row = $dataStartRow; $row <= $highestRow; $row++) {
            $sheet->getRowDimension($row)->setRowHeight(-1);
        }
    }
}
