<?php

namespace App\Exports;

use App\Models\Department;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use Illuminate\Support\Facades\App;

class DepartmentsExport extends BaseExportTemplate
{
    private $locale;
    private array $rows = [];

    /**
     * Constructor
     */
    public function __construct($locale = null)
    {
        $this->locale = $locale ?? App::getLocale();

        $title = __('locale.Departments Report');
        $description = __('locale.This report contains all departments with their hierarchy, staffing, and management information');

        parent::__construct($this->locale, $title, $description);

        // Load and process departments
        $departments = Department::with('manager', 'parentDepartment', 'departments', 'employees', 'color')->get();
        
        foreach ($departments as $department) {
            $this->rows[] = $this->processDepartment($department);
        }
    }

    /**
     * Process a single department
     */
    private function processDepartment($department)
    {
        // Get child departments names
        $childrenNames = $department->departments->pluck('name')->filter()->toArray();
        $children = !empty($childrenNames) 
            ? implode(', ', $childrenNames) 
            : __('locale.No Child Departments');

        // Get parent department name
        $parentDepartment = optional($department->parentDepartment)->name ?? __('locale.N/A');
        
        // Get manager name
        $manager = optional($department->manager)->name ?? __('locale.Not Assigned');
        
        // Get color name
        $color = optional($department->color)->name ?? __('locale.No Color');
        
        // Get employee counts
        $requiredEmployees = $department->required_num_emplyees ?? 0;
        $actualEmployees = $department->employees()->count();
        
        // Calculate staffing status
        $staffingStatus = $this->getStaffingStatus($requiredEmployees, $actualEmployees);

        return (object)[
            'name' => $department->name,
            'code' => $department->code ?? __('locale.N/A'),
            'parent_department' => $parentDepartment,
            'child_departments' => $children,
            'required_employees' => $requiredEmployees,
            'actual_employees' => $actualEmployees,
            'staffing_status' => $staffingStatus,
            'manager' => $manager,
            'color' => $color,
            'created_date' => optional($department->created_at)->format('Y-m-d H:i') ?: __('locale.N/A'),
        ];
    }

    /**
     * Get staffing status with translation
     */
    private function getStaffingStatus($required, $actual)
    {
        if ($required == 0) {
            return __('locale.No Requirement');
        }
        
        $percentage = ($actual / $required) * 100;
        
        if ($percentage >= 100) {
            return __('locale.Fully Staffed');
        } elseif ($percentage >= 75) {
            return __('locale.Well Staffed');
        } elseif ($percentage >= 50) {
            return __('locale.Partially Staffed');
        } elseif ($percentage >= 25) {
            return __('locale.Understaffed');
        } else {
            return __('locale.Critically Understaffed');
        }
    }

    /**
     * Get all departments with relationships
     */
    public function collection()
    {
        return collect($this->rows);
    }

    /**
     * Map each department to an array for export
     */
    public function map($row): array
    {
        return [
            $this->getCounter(),
            $row->name,
            $row->code,
            $row->parent_department,
            $row->child_departments,
            $row->required_employees,
            $row->actual_employees,
            $row->staffing_status,
            $row->manager,
            $row->color,
            $row->created_date,
        ];
    }

    /**
     * Column headings
     */
    public function headings(): array
    {
        if ($this->isRTL) {
            return [
                '#',
                __('locale.Name'),
                __('locale.Code'),
                __('locale.ParentDepartment'),
                __('locale.ChildDepartments'),
                __('locale.RequiredNumberOfEmplyees'),
                __('locale.ActualNumberOfEmplyees'),
                __('locale.StaffingStatus'),
                __('locale.Manager'),
                __('locale.Color'),
                __('locale.CreatedDate')
            ];
        }

        return [
            '#',
            __('locale.Name'),
            __('locale.Code'),
            __('locale.Parent Department'),
            __('locale.Child Departments'),
            __('locale.Required Employees'),
            __('locale.Actual Employees'),
            __('locale.Staffing Status'),
            __('locale.Manager'),
            __('locale.Color'),
            __('locale.Created Date')
        ];
    }

    /**
     * Column widths
     * 
     * Data starts at column A:
     *   A = # (counter)
     *   B = Name
     *   C = Code
     *   D = Parent Department
     *   E = Child Departments
     *   F = Required Employees
     *   G = Actual Employees
     *   H = Staffing Status
     *   I = Manager
     *   J = Color
     *   K = Created Date
     */
    public function columnWidths(): array
    {
        return [
            'A' => 6,   // #
            'B' => 30,  // Name
            'C' => 15,  // Code
            'D' => 30,  // Parent Department
            'E' => 40,  // Child Departments
            'F' => 18,  // Required Employees
            'G' => 18,  // Actual Employees
            'H' => 22,  // Staffing Status
            'I' => 25,  // Manager
            'J' => 15,  // Color
            'K' => 20,  // Created Date
        ];
    }

    /**
     * Custom styles for wrap text
     */
protected function applyCustomStyles(Worksheet $sheet)
{
    $highestRow = $sheet->getHighestRow();

    // Determine header row number (accounting for title and description)
    $headerRow = 1;
    if ($this->title) {
        $headerRow = $this->description ? 3 : 2;
    }
    $dataStartRow = $headerRow + 1;

    // Wrap text for relevant columns
    $wrapColumns = ['B', 'D', 'E', 'I'];
    foreach ($wrapColumns as $col) {
        $sheet->getStyle("{$col}{$dataStartRow}:{$col}{$highestRow}")
            ->getAlignment()
            ->setWrapText(true);
    }

    // Auto row heights for data rows
    for ($row = $dataStartRow; $row <= $highestRow; $row++) {
        $sheet->getRowDimension($row)->setRowHeight(-1);
    }
}
}