<?php

namespace App\Exports;

use App\Models\Family;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use Illuminate\Support\Facades\App;

class DomainsExport extends BaseExportTemplate
{
    private $locale;
    private array $rows = [];

    /**
     * Constructor
     */
    public function __construct($locale = null)
    {
        $this->locale = $locale ?? App::getLocale();

        $title = __('locale.Domains Report');
        $description = __('locale.This report contains all domains with their hierarchical structure and sub-domains');

        parent::__construct($this->locale, $title, $description);

        // Load and process domains (families)
        $domains = Family::with('parentFamily', 'families')->get();

        foreach ($domains as $domain) {
            $this->rows[] = $this->processDomain($domain);
        }
    }

    /**
     * Process a single domain (family)
     */
    private function processDomain($domain)
    {
        // Get sub-domains names (only direct children, not all descendants)
        $subDomains = $domain->familiesOlny()->pluck('name')->filter()->toArray();

        $subDomainsNames = !empty($subDomains)
            ? implode(', ', $subDomains)
            : __('locale.No Sub-domains');

        // Get parent domain name
        $parentDomain = optional($domain->parentFamily)->name ?? __('locale.No Parent Domain');

        // Get domain level (depth in hierarchy)
        $level = $this->getDomainLevel($domain);

        return (object)[
            'name' => $domain->name,
            'order' => $domain->order ?? 0,
            'parent_domain' => $parentDomain,
            'sub_domains' => $subDomainsNames,
            'level' => $level,
            'has_children' => $domain->families->count() > 0,
            'children_count' => $domain->families->count(),
        ];
    }

    /**
     * Get domain level in hierarchy
     */
    private function getDomainLevel($domain, $currentLevel = 0)
    {
        if (!$domain->parentFamily) {
            return $currentLevel;
        }

        return $this->getDomainLevel($domain->parentFamily, $currentLevel + 1);
    }

    /**
     * Get all families (domains) with relationships
     */
    public function collection()
    {
        return collect($this->rows);
    }

    /**
     * Map each family (domain) to an array for export
     */
    public function map($row): array
    {
        return [
            $this->getCounter(),
            $row->name,
            $row->order,
            $row->parent_domain,
            $row->sub_domains,
        ];
    }

    /**
     * Column headings
     */
    public function headings(): array
    {
        if ($this->isRTL) {
            return [
                '#',
                __('locale.Name'),
                __('locale.Order'),
                __('locale.Domain'),
                __('locale.sub_domains')
            ];
        }

        return [
            '#',
            __('locale.Name'),
            __('locale.Order'),
            __('locale.Parent Domain'),
            __('locale.Sub-domains')
        ];
    }

    /**
     * Column widths
     * 
     * Data starts at column A:
     *   A = # (counter)
     *   B = Name
     *   C = Order
     *   D = Parent Domain
     *   E = Sub-domains
     */
    public function columnWidths(): array
    {
        return [
            'A' => 6,   // #
            'B' => 35,  // Name
            'C' => 12,  // Order
            'D' => 35,  // Parent Domain
            'E' => 50,  // Sub-domains
        ];
    }

    /**
     * Custom styles for wrap text
     */
    protected function applyCustomStyles(Worksheet $sheet)
    {
        $highestRow = $sheet->getHighestRow();

        // Determine header row number (accounting for title and description)
        $headerRow = 1;
        if ($this->title) {
            $headerRow = $this->description ? 3 : 2;
        }
        $dataStartRow = $headerRow + 1;

        // Wrap text for Name, Parent Domain, and Sub-domains columns
        $wrapColumns = ['B', 'D', 'E'];
        foreach ($wrapColumns as $col) {
            $sheet->getStyle("{$col}{$dataStartRow}:{$col}{$highestRow}")
                ->getAlignment()
                ->setWrapText(true);
        }

        // Auto row heights for data rows
        for ($row = $dataStartRow; $row <= $highestRow; $row++) {
            $sheet->getRowDimension($row)->setRowHeight(-1);
        }
    }
}
