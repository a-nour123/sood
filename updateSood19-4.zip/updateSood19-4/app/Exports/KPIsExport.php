<?php

namespace App\Exports;

use App\Models\KPI;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use App\Traits\LaravelExportPropertiesTrait;
use Illuminate\Support\Facades\App;

class KPIsExport extends BaseExportTemplate
{
    use LaravelExportPropertiesTrait;

    private array $rows = [];
    private $locale;

    public function __construct($locale = null)
    {
        $this->locale = $locale ?? App::getLocale();

        $title = __('locale.KPIs Report');
        $description = __('locale.This report contains all KPIs with their assessments and performance metrics');

        parent::__construct($this->locale, $title, $description);

        $kpis = KPI::with([
            'department:id,name',
            'created_by_user:id,username',
            'assessments.created_by_user:id,username',
            'assessments.action_by_user:id,username'
        ])->withCount('assessments')->get();

        foreach ($kpis as $kpi) {
            $assessmentValues = $kpi->assessments->whereNotNull('assessment_value')->pluck('assessment_value');

            // Value type translation
            $valueType = $this->translateValueType($kpi->value_type);

            // Period translation
            $period = $kpi->period_of_assessment . ' ' . __('locale.Months');

            if ($assessmentValues->isEmpty()) {
                $this->rows[] = (object)[
                    'title' => $kpi->title,
                    'description' => $kpi->description,
                    'value_type' => $valueType,
                    'value' => $kpi->value,
                    'assessment_value' => __('locale.No Assessments'),
                    'period' => $period,
                    'department' => $kpi->department?->name ?? __('locale.N/A'),
                    'created_at' => $kpi->created_at->format('Y-m-d H:i'),
                    'created_by' => $kpi->created_by_user?->username ?? __('locale.N/A'),
                    'assessments_count' => $kpi->assessments_count,
                ];
            } else {
                foreach ($assessmentValues as $value) {
                    $this->rows[] = (object)[
                        'title' => $kpi->title,
                        'description' => $kpi->description,
                        'value_type' => $valueType,
                        'value' => $kpi->value,
                        'assessment_value' => $value,
                        'period' => $period,
                        'department' => $kpi->department?->name ?? __('locale.N/A'),
                        'created_at' => $kpi->created_at->format('Y-m-d H:i'),
                        'created_by' => $kpi->created_by_user?->username ?? __('locale.N/A'),
                        'assessments_count' => $kpi->assessments_count,
                    ];
                }
            }
        }
    }
    /**
     * Translate value type
     */
    private function translateValueType($valueType)
    {
        $types = [
            'percentage' => 'locale.Percentage',
            'number' => 'locale.Number',
            'currency' => 'locale.Currency',
            'boolean' => 'locale.Boolean',
        ];

        $key = $types[$valueType] ?? 'locale.' . ucfirst($valueType);
        return __($key);
    }

    /**
     * Return collection
     */
    public function collection()
    {
        return collect($this->rows);
    }

    /**
     * Map each row
     */
    public function map($row): array
    {
        return [
            $this->getCounter(),
            $row->title,
            $row->description,
            $row->value_type,
            $row->value,
            $row->assessment_value,
            $row->period,
            $row->department,
            $row->created_by,
            $row->created_at,
            $row->assessments_count,
        ];
    }

    /**
     * Headings
     */
    public function headings(): array
    {
        if ($this->isRTL) {
            return [
                '#',
                __('locale.Title'),
                __('locale.Description'),
                __('locale.Type'),
                __('locale.Value'),
                __('locale.AssessmentValue'),
                __('locale.Period'),
                __('locale.Department'),
                __('locale.CreatedBy'),
                __('locale.CreatedDate'),
                __('locale.AssessmentsCount'),
            ];
        }

        return [
            '#',
            __('locale.Title'),
            __('locale.Description'),
            __('locale.Type'),
            __('locale.Value'),
            __('locale.Assessment Value'),
            __('locale.Period'),
            __('locale.Department'),
            __('locale.Created By'),
            __('locale.Created Date'),
            __('locale.Assessments Count'),
        ];
    }

    /**
     * Column widths
     *
     * Data starts at column A:
     *   A  = # (counter)
     *   B  = Title
     *   C  = Description
     *   D  = Type
     *   E  = Value
     *   F  = Assessment Value
     *   G  = Period
     *   H  = Department
     *   I  = Created By
     *   J  = Created Date
     *   K  = Assessments Count
     */
    public function columnWidths(): array
    {
        return [
            'A' => 6,   // #
            'B' => 30,  // Title
            'C' => 50,  // Description
            'D' => 15,  // Type
            'E' => 15,  // Value
            'F' => 20,  // Assessment Value
            'G' => 15,  // Period
            'H' => 25,  // Department
            'I' => 25,  // Created By
            'J' => 20,  // Created Date
            'K' => 20,  // Assessments Count
        ];
    }

    /**
     * Apply custom styles for the KPIs export
     */
    protected function applyCustomStyles(Worksheet $sheet)
    {
        $highestRow = $sheet->getHighestRow();

        // Determine header row number (accounting for title and description)
        $headerRow = 1;
        if ($this->title) {
            $headerRow = $this->description ? 3 : 2;
        }
        $dataStartRow = $headerRow + 1;

        // Wrap text for Description and Department columns
        $wrapColumns = ['C', 'H'];
        foreach ($wrapColumns as $col) {
            $sheet->getStyle("{$col}{$dataStartRow}:{$col}{$highestRow}")
                ->getAlignment()
                ->setWrapText(true);
        }

        // Auto row heights for data rows
        for ($row = $dataStartRow; $row <= $highestRow; $row++) {
            $sheet->getRowDimension($row)->setRowHeight(-1);
        }
    }
}
