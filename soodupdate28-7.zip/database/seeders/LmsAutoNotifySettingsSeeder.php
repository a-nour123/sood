<?php

namespace Database\Seeders;

use App\Models\Action;
use App\Models\AutoNotify;
use App\Models\MailAutoNotify;
use App\Models\NotificationRole;
use Illuminate\Database\Seeder;

/**
 * Enables LMSAutoNotify (Action 129) auto-notify settings used by
 * lms:send-due-date-reminders.
 */
class LmsAutoNotifySettingsSeeder extends Seeder
{
    public function run(): void
    {
        $action = Action::where('name', 'LMSAutoNotify')->first();
        if (!$action) {
            return;
        }

        $actionId = $action->id;

        // Remind 7, 3, and 1 day(s) before the assignment due date.
        $auto = AutoNotify::updateOrCreate(
            ['action_id' => $actionId],
            [
                'message' => 'Reminder: training "{name}" (course: {course_name}) is due soon. Days until due: {days_until_due}.',
                'date' => json_encode([7, 3, 1]),
                'status' => 1,
            ]
        );

        NotificationRole::where('notifiable_type', AutoNotify::class)
            ->where('notifiable_id', $auto->id)
            ->delete();

        NotificationRole::create([
            'role' => 'assigned-users',
            'notifiable_id' => $auto->id,
            'notifiable_type' => AutoNotify::class,
        ]);

        $mail = MailAutoNotify::updateOrCreate(
            ['action_id' => $actionId],
            [
                'subject' => 'LMS reminder: {name} due soon',
                'status' => 1,
            ]
        );

        // MailAutoNotify may not use the same roles table pattern; keep AutoNotify roles as source of truth.
        if (method_exists($mail, 'roles')) {
            NotificationRole::where('notifiable_type', MailAutoNotify::class)
                ->where('notifiable_id', $mail->id)
                ->delete();

            NotificationRole::create([
                'role' => 'assigned-users',
                'notifiable_id' => $mail->id,
                'notifiable_type' => MailAutoNotify::class,
            ]);
        }
    }
}
