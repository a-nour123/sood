<?php

namespace Database\Seeders;

use App\Models\Action;
use App\Models\MailSetting;
use App\Models\NotificationRole;
use App\Models\SmsSetting;
use App\Models\SystemNotificationSetting;
use Illuminate\Database\Seeder;

/**
 * Enables ApproveCampaign (131) notification settings so campaign employees
 * receive system + mail notifications when a campaign is approved.
 */
class ApproveCampaignNotificationSettingsSeeder extends Seeder
{
    public function run(): void
    {
        $action = Action::where('name', 'ApproveCampaign')->first();
        if (!$action) {
            return;
        }

        $actionId = $action->id;

        $system = SystemNotificationSetting::updateOrCreate(
            ['action_id' => $actionId],
            [
                'message' => 'Campaign "{campaign_name}" ({campaign_type}) has been approved and is now available for you.',
                'status' => 1,
            ]
        );
        $this->syncRoles($system, SystemNotificationSetting::class, ['employees']);

        $mail = MailSetting::updateOrCreate(
            ['action_id' => $actionId],
            [
                'subject' => 'Campaign approved: {campaign_name}',
                'body' => 'Hello, the campaign "{campaign_name}" ({campaign_type}) has been approved. Please check your assigned training / phishing tasks.',
                'status' => 1,
            ]
        );
        $this->syncRoles($mail, MailSetting::class, ['employees']);

        // SMS available but off by default.
        $sms = SmsSetting::updateOrCreate(
            ['action_id' => $actionId],
            [
                'message' => 'Campaign {campaign_name} approved.',
                'status' => 0,
            ]
        );
        $this->syncRoles($sms, SmsSetting::class, ['employees']);
    }

    private function syncRoles($setting, string $type, array $roles): void
    {
        NotificationRole::where('notifiable_type', $type)
            ->where('notifiable_id', $setting->id)
            ->delete();

        foreach ($roles as $role) {
            NotificationRole::create([
                'role' => $role,
                'notifiable_id' => $setting->id,
                'notifiable_type' => $type,
            ]);
        }
    }
}
