<?php

namespace Database\Seeders;

use App\Models\Action;
use Illuminate\Database\Seeder;

class PhysicalCourseRequestActionSeeder extends Seeder
{
    /**
     * Seed notification Actions used by Physical Courses request
     * approve / reject / transfer flows.
     */
    public function run(): void
    {
        $actions = [
            ['id' => 180, 'name' => 'approve_physical_course_request'],
            ['id' => 181, 'name' => 'reject_physical_course_request'],
            ['id' => 182, 'name' => 'transfer_physical_course_request'],
        ];

        foreach ($actions as $action) {
            Action::firstOrCreate(
                ['id' => $action['id']],
                ['name' => $action['name']]
            );
        }
    }
}
