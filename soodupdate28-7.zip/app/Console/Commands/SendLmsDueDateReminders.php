<?php

namespace App\Console\Commands;

use App\Http\Traits\NotificationHandlingTrait;
use App\Models\Action;
use App\Models\AutoNotify;
use App\Models\LMSTrainingModule;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

/**
 * LMS Auto-Notify (Action 129 / LMSAutoNotify).
 *
 * Scans incomplete training assignments with days_until_due and schedules /
 * fires reminders via NotificationHandlingTrait::handleAutoNotifyBeforeDueDate.
 * The daily Kernel NotifyAtDateModel pass will also re-fire stored reminder dates.
 */
class SendLmsDueDateReminders extends Command
{
    use NotificationHandlingTrait;

    protected $signature = 'lms:send-due-date-reminders';

    protected $description = 'Schedule and send LMS training due-date reminders (Action 129 - LMSAutoNotify)';

    public function handle()
    {
        $action = Action::where('name', 'LMSAutoNotify')->first();
        if (!$action) {
            $this->warn('Action LMSAutoNotify (129) not found.');
            return Command::SUCCESS;
        }

        $actionId2 = (int) $action->id;

        $autoNotify = AutoNotify::where('action_id', $actionId2)->where('status', 1)->first();
        if (!$autoNotify) {
            $this->info('LMSAutoNotify is disabled or not configured in notification settings.');
            return Command::SUCCESS;
        }

        $offsets = json_decode($autoNotify->date ?? '[]', true);
        if (!is_array($offsets) || empty($offsets)) {
            $this->warn('LMSAutoNotify has no reminder day offsets configured (auto_notifies.date).');
            return Command::SUCCESS;
        }

        $link = ['link' => route('user.lms.training.modules.index')];
        $processed = 0;
        $today = Carbon::today()->toDateString();

        // Incomplete assignments that have a due window.
        DB::table('l_m_s_user_training_modules as utm')
            ->join('l_m_s_training_modules as tm', 'utm.training_module_id', '=', 'tm.id')
            ->whereNull('tm.deleted_at')
            ->whereNull('utm.completed_at')
            ->whereNotNull('utm.days_until_due')
            ->where('utm.days_until_due', '>', 0)
            ->select([
                'utm.id as assignment_id',
                'utm.user_id',
                'utm.training_module_id',
                'utm.days_until_due',
                'utm.created_at as assigned_at',
            ])
            ->orderBy('utm.id')
            ->chunk(200, function ($rows) use ($actionId2, $offsets, $link, &$processed, $today) {
                foreach ($rows as $row) {
                    try {
                        $assignedAt = Carbon::parse($row->assigned_at)->startOfDay();
                        $dueDate = $assignedAt->copy()->addDays((int) $row->days_until_due);

                        // Skip if already past due and no remaining reminder dates today/future.
                        $nextDateNotify = [];
                        foreach ($offsets as $daysBefore) {
                            $nextDateNotify[] = $dueDate->copy()
                                ->subDays((int) $daysBefore)
                                ->format('Y-m-d');
                        }
                        $nextDateNotify = array_values(array_unique($nextDateNotify));

                        // Nothing left to schedule/send for this assignment.
                        $hasTodayOrFuture = collect($nextDateNotify)->contains(function ($date) use ($today) {
                            return $date >= $today;
                        });
                        if (!$hasTodayOrFuture) {
                            continue;
                        }

                        $module = LMSTrainingModule::with('level.course')->find($row->training_module_id);
                        if (!$module) {
                            continue;
                        }

                        // Variables expected by courseNotificationsSettings for action 129.
                        $module->course_name = $module->level?->course?->title ?? '';
                        $module->course_level = $module->level?->title ?? '';
                        $module->days_until_due = (int) $row->days_until_due;

                        $roles = [
                            // Primary recipients: the assigned trainee.
                            'assigned-users' => [(int) $row->user_id],
                            // Optional: only used if selected in settings (pass empty — do not spam all users).
                            'system-users' => [],
                        ];

                        $modelType = 'lmsUserTraining';
                        $modelId = (int) $row->assignment_id;
                        $proccess = 'lms_due_reminder';

                        $this->handleAutoNotifyBeforeDueDate(
                            $actionId2,
                            $link,
                            $module,
                            $roles,
                            $nextDateNotify,
                            $modelId,
                            $modelType,
                            $proccess
                        );

                        $processed++;
                    } catch (\Throwable $e) {
                        Log::error('LMS due-date reminder failed', [
                            'assignment_id' => $row->assignment_id ?? null,
                            'error' => $e->getMessage(),
                        ]);
                    }
                }
            });

        $this->info("LMS due-date reminders processed: {$processed}");

        return Command::SUCCESS;
    }
}
