<?php

namespace App\Listeners;

use App\Events\PublicTrainingModuleCreated;
use App\Http\Traits\NotificationHandlingTrait;
use App\Models\Action;
use App\Models\LMSTrainingModule;
use App\Models\User;

class PublicTrainingModuleCreatedListener
{
    use NotificationHandlingTrait;

    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event (Action 161 - create_training).
     *
     * Targets all enabled users via the system-users role, respecting
     * courseNotificationsSettings. Dispatched after the HTTP response so
     * large user lists do not block module create/update.
     *
     * @param  \App\Events\PublicTrainingModuleCreated  $event
     * @return void
     */
    public function handle(PublicTrainingModuleCreated $event)
    {
        $action1 = Action::where('name', 'create_training')->first();
        if (!$action1) {
            return;
        }

        $trainingModule = $event->trainingModule;
        if (!$trainingModule || !$trainingModule->id) {
            return;
        }

        $actionId = $action1->id;
        $moduleId = $trainingModule->id;

        // Defer so create/update responses stay fast with many system users.
        dispatch(function () use ($actionId, $moduleId) {
            $listener = app(PublicTrainingModuleCreatedListener::class);
            $listener->notifyPublicTrainingCreated($actionId, $moduleId);
        })->afterResponse();
    }

    /**
     * Build roles / model variables and send notifications for Action 161.
     */
    public function notifyPublicTrainingCreated(int $actionId, int $moduleId): void
    {
        $trainingModule = LMSTrainingModule::with('level.course')->find($moduleId);
        if (!$trainingModule) {
            return;
        }

        $trainingModule->course_name = $trainingModule->level?->course?->title ?? '';
        $trainingModule->course_level = $trainingModule->level?->title ?? '';

        // Chunk to avoid loading the full users table into memory at once.
        $userIds = [];
        User::query()
            ->where('enabled', 1)
            ->select('id')
            ->orderBy('id')
            ->chunkById(500, function ($users) use (&$userIds) {
                foreach ($users as $user) {
                    $userIds[] = (int) $user->id;
                }
            });

        $roles = [
            // Always an array (never null) so handleReceivers can foreach safely.
            'system-users' => $userIds,
        ];

        $link = ['link' => route('user.lms.training.modules.index')];

        $this->sendNotificationForAction(
            $actionId,
            null,
            $link,
            $trainingModule,
            $roles,
            null,
            $moduleId,
            null,
            null
        );
    }
}
