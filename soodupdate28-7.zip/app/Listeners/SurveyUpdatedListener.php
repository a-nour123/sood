<?php

namespace App\Listeners;

use App\Events\SurveyUpdated;
use App\Models\User;
use App\Models\Team;
use App\Models\Action;
use App\Http\Traits\NotificationHandlingTrait;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class SurveyUpdatedListener
{
    use NotificationHandlingTrait;

    public function __construct()
    {
        //
    }

    public function handle(SurveyUpdated $event)
    {
        try {
            $action1 = Action::where('name', 'survey_update')->first();
            if (!$action1) {
                return;
            }
            $actionId1 = $action1->id;

            $action2 = Action::where('name', 'Survey_Notify_Before_Last_Review_Date')->first();
            $actionId2 = $action2?->id;

            $awarenessSurvey = $event->awarenessSurvey;
            $awarenessSurvey->loadMissing(['status', 'test_priv', 'created_by_user']);

            $teams2 = [];
            $teamsNames = '';
            if (!empty($awarenessSurvey->team)) {
                foreach (array_filter(explode(',', $awarenessSurvey->team)) as $teamId) {
                    $team = Team::find($teamId);
                    if (!$team) {
                        continue;
                    }
                    $teams2[] = $teamId;
                    $teamsNames .= $team->name . ', ';
                }
                $teamsNames = $teamsNames !== '' ? '(' . rtrim($teamsNames, ', ') . ')' : '';
            }

            $stakeholders2 = [];
            $stakeholdersNames = '';
            if (!empty($awarenessSurvey->additional_stakeholder)) {
                foreach (array_filter(explode(',', $awarenessSurvey->additional_stakeholder)) as $stakeholderId) {
                    $stakeholder = User::find($stakeholderId);
                    if (!$stakeholder) {
                        continue;
                    }
                    $stakeholders2[] = $stakeholderId;
                    $stakeholdersNames .= $stakeholder->name . ', ';
                }
                $stakeholdersNames = $stakeholdersNames !== '' ? '(' . rtrim($stakeholdersNames, ', ') . ')' : '';
            }

            $reviewer2 = [];
            $reviewersNames = '';
            if (!empty($awarenessSurvey->reviewer)) {
                foreach (array_filter(explode(',', $awarenessSurvey->reviewer)) as $review) {
                    $reviewerPerson = User::find($review);
                    if (!$reviewerPerson) {
                        continue;
                    }
                    $reviewer2[] = $review;
                    $reviewersNames .= $reviewerPerson->name . ', ';
                }
                $reviewersNames = $reviewersNames !== '' ? '(' . rtrim($reviewersNames, ', ') . ')' : '';
            }

            $roles = [
                'creator' => array_values(array_filter(array_map('intval', [$awarenessSurvey->created_by]))),
                'Team-teams' => array_values(array_map('intval', $teams2)),
                'Stakeholder-teams' => array_values(array_map('intval', $stakeholders2)),
                'reviewers-teams' => array_values(array_map('intval', $reviewer2)),
            ];

            $awarenessSurvey->Name = $awarenessSurvey->name;
            $awarenessSurvey->Status = $awarenessSurvey->status?->name;
            $awarenessSurvey->Description = $awarenessSurvey->description;
            $awarenessSurvey->Created_By = $awarenessSurvey->created_by_user?->name;
            $awarenessSurvey->Teams = $teamsNames;
            $awarenessSurvey->Additional_Stakeholder = $stakeholdersNames;
            $awarenessSurvey->Privacy = $awarenessSurvey->test_priv?->title;
            $awarenessSurvey->Reviewer = $reviewersNames;
            $awarenessSurvey->Next_Review_Date = $awarenessSurvey->next_review_date;

            $modelId = $awarenessSurvey->id;
            $proccess = 'update';
            $modelType = 'survey';
            $nextDateNotify = null;

            $NumbersOfDays = DB::table('auto_notifies')
                ->join('actions', 'auto_notifies.action_id', '=', 'actions.id')
                ->where('actions.name', 'Survey_Notify_Before_Last_Review_Date')
                ->select('auto_notifies.date')
                ->first();

            if ($NumbersOfDays && !empty($awarenessSurvey->next_review_date)) {
                $datesArray = json_decode($NumbersOfDays->date, true);
                if (is_array($datesArray)) {
                    $nextDateNotify = [];
                    foreach ($datesArray as $days) {
                        $nextDateNotify[] = Carbon::parse($awarenessSurvey->next_review_date)
                            ->subDays((int) $days)
                            ->format('Y-m-d');
                    }
                }
            }

            $link = ['link' => route('admin.awarness_survey.index')];

            $this->sendNotificationForAction(
                $actionId1,
                $actionId2,
                $link,
                $awarenessSurvey,
                $roles,
                $nextDateNotify,
                $modelId,
                $modelType,
                $proccess
            );
        } catch (\Throwable $e) {
            Log::error('SurveyUpdatedListener failed', [
                'error' => $e->getMessage(),
                'survey_id' => $event->awarenessSurvey->id ?? null,
            ]);
        }
    }
}
