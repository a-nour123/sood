<?php

namespace App\Listeners;

use App\Events\CampaignApproved;
use App\Http\Traits\NotificationHandlingTrait;
use App\Models\Action;

class HandleCampaignApproved
{
    use NotificationHandlingTrait;

    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * Notifies only the employees assigned to this campaign (role key: employees),
     * according to ApproveCampaign (action 131) notification settings.
     *
     * @param  \App\Events\CampaignApproved  $event
     * @return void
     */
    public function handle(CampaignApproved $event)
    {
        $action1 = Action::where('name', 'ApproveCampaign')->first();
        if (!$action1) {
            return;
        }

        $phishingCampaign = $event->phishingCampaign;

        // Always resolve this campaign's assigned employees (never null — empty array if none).
        $phishingCampaign->load('employees');
        $employeeIds = $phishingCampaign->employees()
            ->pluck('users.id')
            ->filter()
            ->unique()
            ->values()
            ->all();

        $roles = [
            'employees' => $employeeIds,
        ];

        // Variables used by phishing notification templates ({campaign_name}, {campaign_type}).
        if (empty($phishingCampaign->campaign_name)) {
            $phishingCampaign->campaign_name = $phishingCampaign->name;
        }

        // Awareness / training participants land on their training list; others keep campaigns index.
        $awarenessTypes = ['security_awareness', 'simulated_phishing_and_security_awareness'];
        $link = [
            'link' => in_array($phishingCampaign->campaign_type, $awarenessTypes, true)
                ? route('user.lms.training.modules.index')
                : route('admin.phishing.campaign.index'),
        ];

        $this->sendNotificationForAction(
            $action1->id,
            null,
            $link,
            $phishingCampaign,
            $roles,
            null,
            $phishingCampaign->id,
            null,
            null
        );
    }
}
