<?php

namespace Database\Seeders;

use App\Models\Permission;
use App\Models\PermissionGroup;
use App\Models\RoleResponsibility;
use App\Models\Subgroup;
use Illuminate\Database\Seeder;

class AddCurrentNotifyPermissionSeeder extends Seeder
{
    public function run()
    {
        $mainPermission = 'current_notify.';

        // Get Configuration Group
        $permissionGroups = PermissionGroup::pluck('id', 'name');

        $configurationGroupId = $permissionGroups['Configuration'] ?? null;

        if (!$configurationGroupId) {
            $this->command->error('Configuration group not found.');
            return;
        }

        // Create subgroup under Configuration
        $subgroup = Subgroup::firstOrCreate([
            'name' => 'current_notify',
            'permission_group_id' => $configurationGroupId,
        ]);

        $permissions = [
            'list',
            'create',
        ];

        foreach ($permissions as $permissionStatus) {

            $permission = Permission::firstOrCreate([
                'key' => $mainPermission . $permissionStatus,
            ], [
                'name' => $permissionStatus,
                'subgroup_id' => $subgroup->id,
            ]);

            // Assign permission to Super Admin
            RoleResponsibility::firstOrCreate([
                'role_id' => 1,
                'permission_id' => $permission->id,
            ]);
        }

        $this->command->info('Current Notify permissions seeded successfully.');
    }
}