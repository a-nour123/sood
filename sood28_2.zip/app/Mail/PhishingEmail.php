<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class PhishingEmail extends Mailable
{
    use Queueable, SerializesModels;

    public $emailData;
    public $employee;
    public $campaign_id;

    public function __construct($emailData, $employee, $campaign_id = null)
    {
        $this->emailData = $emailData;
        $this->employee = $employee;
        $this->campaign_id = $campaign_id;
    }

    public function build()
    {
        $body = view('emails.phishing.email')
            ->with([
                'campaign_id' => $this->campaign_id,
                'emailData' => $this->emailData,
                'employee' => $this->employee,
            ])
            ->render();

        $body = str_replace('$$emailId', $this->emailData['id'], $body);
        $body = str_replace('$$employeeId', $this->employee->id, $body);

        $clickUrl = $this->buildClickUrl();
        $body = str_replace('{PhishWebsitePage}', $clickUrl, $body);
        $body = str_replace('$$NAME$$', $this->employee->name, $body);
        $body = $this->normalizeOutboundEmailBody($body);

        if ($this->emailData['mail_attachment']) {
            $attachmentHtml = view('emails.phishing.partial')
                ->with([
                    'campaign_id' => $this->campaign_id,
                    'fileName' => $this->emailData['mail_attachment'],
                    'emailId' => $this->emailData['id'],
                    'employeeId' => $this->employee->id,
                ])
                ->render();

            $body .= $attachmentHtml;
        }

        return $this->html($body);
    }

    /**
     * Build click URL using the selected phishing website page host (not APP_URL).
     */
    protected function buildClickUrl(): string
    {
        $website = $this->resolveWebsite();
        $websiteId = $website->id ?? data_get($this->emailData, 'website.id') ?? data_get($this->emailData, 'phishing_website_id');
        $baseHost = $this->resolveWebsiteBaseHost($website);

        return $this->ensureAbsoluteUrl($baseHost)
            . '/PWPI/' . $websiteId
            . '/click?PMTI=' . $this->emailData['id']
            . '&PEI=' . $this->employee->id
            . '&PCI=' . $this->campaign_id;
    }

    /**
     * @return \App\Models\PhishingWebsitePage|null
     */
    protected function resolveWebsite()
    {
        $website = $this->emailData->website ?? null;
        if ($website) {
            if (method_exists($website, 'loadMissing')) {
                $website->loadMissing('domain');
            }

            return $website;
        }

        $websiteId = data_get($this->emailData, 'phishing_website_id');
        if ($websiteId) {
            return \App\Models\PhishingWebsitePage::with('domain')->find($websiteId);
        }

        return null;
    }

    /**
     * Host/domain from phishing website page settings.
     */
    protected function resolveWebsiteBaseHost($website): string
    {
        if (!$website) {
            return (string) config('app.url');
        }

        // managed: subdomain + linked domain
        $linkedDomain = $website->domain->name ?? null;
        if (!empty($linkedDomain)) {
            $subdomain = trim((string) ($website->from_address_name ?? ''), '.@');
            $domain = ltrim((string) $linkedDomain, '@.');

            if ($subdomain !== '' && $domain !== '') {
                if (str_contains($subdomain, '.')) {
                    return $subdomain;
                }

                return $subdomain . '.' . $domain;
            }

            if ($domain !== '') {
                return $domain;
            }
        }

        // unmanaged / full host in from_address_name
        $from = trim((string) ($website->from_address_name ?? ''), '.@');
        if ($from !== '' && str_contains($from, '.')) {
            return $from;
        }

        // website_url host if configured
        $websiteUrl = trim((string) ($website->website_url ?? ''));
        if ($websiteUrl !== '') {
            $host = parse_url($this->ensureAbsoluteUrl($websiteUrl), PHP_URL_HOST);
            if (!empty($host)) {
                return $host;
            }
        }

        // dropdown name often stores the domain (e.g. WWW.WeBock.com)
        $name = trim((string) ($website->name ?? ''), '.@');
        if ($name !== '' && str_contains($name, '.')) {
            return $name;
        }

        if ($from !== '') {
            return $from;
        }

        return (string) config('app.url');
    }

    /**
     * Ensure URL has http/https so webmail treats <a href> as clickable.
     */
    protected function ensureAbsoluteUrl(?string $url): string
    {
        $url = trim((string) $url);
        $url = rtrim($url, '/');
        // Strip trailing :port from host only (e.g. http://host:8000)
        $url = preg_replace('#^(https?://[^/]+):\d+$#i', '$1', $url);

        if ($url === '') {
            return 'https://localhost';
        }

        if (!preg_match('#^https?://#i', $url)) {
            $url = 'https://' . ltrim($url, '/');
        }

        return $url;
    }

    /**
     * Make sure every phishing link in the outbound HTML is a valid absolute URL.
     */
    protected function normalizeOutboundEmailBody(string $body): string
    {
        // Remove spaces after href="
        $body = preg_replace('/href="\s+/i', 'href="', $body);

        // Fix double protocol: https://https://... or https://http://...
        $body = preg_replace('/href="https?:\/\/\s*(https?:\/\/)/i', 'href="$1', $body);

        // Add https:// to href values that look like domains/paths without a scheme
        $body = preg_replace_callback(
            '/href="(?!https?:\/\/|mailto:|tel:|#|\{)([^"]+)"/i',
            function ($matches) {
                $target = trim($matches[1]);
                if ($target === '') {
                    return 'href="#"';
                }
                if (preg_match('#^https?://#i', $target)) {
                    return 'href="' . $target . '"';
                }

                return 'href="https://' . ltrim($target, '/') . '"';
            },
            $body
        );

        return $body;
    }

    public function getMailWebsiteUrl()
    {
        $website = $this->resolveWebsite();
        $baseHost = $this->resolveWebsiteBaseHost($website);
        $websiteId = $website->id ?? data_get($this->emailData, 'website.id');

        return $this->ensureAbsoluteUrl($baseHost)
            . '/PWPI/' . $websiteId
            . '?PMTI=' . $this->emailData->id
            . '&PEI=' . $this->employee->id;
    }
}
