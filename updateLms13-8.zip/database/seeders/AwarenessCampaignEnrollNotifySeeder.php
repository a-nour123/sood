<?php

namespace Database\Seeders;

use App\Models\Action;
use App\Models\MailSetting;
use App\Models\NotificationRole;
use App\Models\SystemNotificationSetting;
use Illuminate\Database\Seeder;

/**
 * Action 183: manual enroll-link notify for approved awareness campaigns.
 * Safe to re-run (updateOrCreate / no truncate).
 */
class AwarenessCampaignEnrollNotifySeeder extends Seeder
{
    public function run(): void
    {
        $action = Action::updateOrCreate(
            ['id' => 183],
            ['name' => 'AwarenessCampaignEnrollNotify']
        );

        $actionId = $action->id;

        $system = SystemNotificationSetting::updateOrCreate(
            ['action_id' => $actionId],
            [
                'message' => 'Please enroll in the training for campaign "{campaign_name}". Course: {training_name}. {training_enrollment_link}',
                'status' => 1,
            ]
        );
        $this->syncRoles($system, SystemNotificationSetting::class, ['employees']);

        $mail = MailSetting::updateOrCreate(
            ['action_id' => $actionId],
            [
                'subject' => 'Enroll in training: {campaign_name}',
                'body' => '<p>Hello,</p><p>The awareness campaign "<strong>{campaign_name}</strong>" has a training course for you: <strong>{training_name}</strong>.</p><p>{training_enrollment_link}</p>',
                'status' => 1,
            ]
        );
        $this->syncRoles($mail, MailSetting::class, ['employees']);
    }

    private function syncRoles($setting, string $type, array $roles): void
    {
        NotificationRole::where('notifiable_type', $type)
            ->where('notifiable_id', $setting->id)
            ->delete();

        foreach ($roles as $role) {
            NotificationRole::create([
                'role' => $role,
                'notifiable_id' => $setting->id,
                'notifiable_type' => $type,
            ]);
        }
    }
}
