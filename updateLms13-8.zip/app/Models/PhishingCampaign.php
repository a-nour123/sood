<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class PhishingCampaign extends Model
{
    use HasFactory, SoftDeletes;
    protected $table = 'phishing_campaigns';
    protected $guarded = [];

    public function emailTemplates()
    {
        return $this->belongsToMany(PhishingTemplate::class, 'phishing_campaign_email_template', 'campaign_id', 'email_template_id');
    }

    public function employees()
    {
        return $this->belongsToMany(User::class, 'phishing_campaign_employee_list', 'campaign_id', 'employee_id');
    }

    public function deliverdEmailTemplates()
    {
        return $this->belongsToMany(PhishingTemplate::class, 'phishing_campaign_email_template', 'campaign_id', 'email_template_id')->wherePivot('is_delivered', 1);
    }

    public function deliverdEmployees()
    {
        return $this->belongsToMany(User::class, 'phishing_campaign_employee_list', 'campaign_id', 'employee_id')->wherePivot('is_delivered', 1);
    }

    public function notDeliverdEmailTemplates()
    {
        return $this->belongsToMany(PhishingTemplate::class, 'phishing_campaign_email_template', 'campaign_id', 'email_template_id')->wherePivot('is_delivered', 0);
    }

    public function notDeliverdEmployees()
    {
        return $this->belongsToMany(User::class, 'phishing_campaign_employee_list', 'campaign_id', 'employee_id')->wherePivot('is_delivered', 0);
    }


    //  Campaign Trackings
    public function emailTrackings()
    {
        return $this->hasMany(PhishingMailTracking::class, 'campaign_id');
    }

    public function openedTrackings()
    {
        return $this->emailTrackings()->whereNotNull('opened_at');
    }

    public function downloadedTrackings()
    {
        return $this->emailTrackings()->whereNotNull('downloaded_at');
    }

    public function clickedTrackings()
    {
        return $this->emailTrackings()->whereNotNull('Page_link_clicked_at');
    }

    public function submittedTrackings()
    {
        return $this->emailTrackings()->whereNotNull('submited_at');
    }


    // LMS
    public function trainingModules()
    {
        return $this->belongsToMany(LMSTrainingModule::class, 'phising_campaign_training_module', 'campaign_id', 'training_module_id');
    }

    public function userTraining()
    {
        return $this->belongsToMany(User::class, 'l_m_s_user_training_modules', 'campaign_id', 'user_id');
    }

    /**
     * Awareness / phishing+training campaign types that include LMS courses.
     */
    public static function awarenessCampaignTypes(): array
    {
        return ['security_awareness', 'simulated_phishing_and_security_awareness'];
    }

    public function isAwarenessCampaign(): bool
    {
        return in_array($this->campaign_type, self::awarenessCampaignTypes(), true);
    }

    /**
     * URL where campaign employees can open/enroll in the campaign training.
     */
    public function getTrainingEnrollmentUrl(): string
    {
        $this->loadMissing('trainingModules');
        $modules = $this->trainingModules;

        if ($modules->count() === 1) {
            return route('user.lms.training.modules.getQuiz', $modules->first()->id);
        }

        return route('user.lms.training.modules.index');
    }

    /**
     * Attach placeholder attributes used by notification templates.
     */
    public function applyEnrollmentNotificationVariables(): self
    {
        $this->loadMissing('trainingModules');

        if (empty($this->campaign_name)) {
            $this->campaign_name = $this->name;
        }

        $names = $this->trainingModules->pluck('name')->filter()->values();
        $url = $this->getTrainingEnrollmentUrl();
        $label = __('lms.EnrollInTraining');

        $this->setAttribute('training_name', $names->isNotEmpty() ? $names->implode(', ') : __('lms.Training'));
        $this->setAttribute('training_enrollment_url', $url);
        $this->setAttribute(
            'training_enrollment_link',
            '<a href="' . e($url) . '" target="_blank" rel="noopener">' . e($label) . '</a>'
        );

        return $this;
    }

    // certificates
    public function certificates(): HasMany
    {
        return $this->hasMany(LMSTrainingModuleCertificate::class);
    }


}
