<?php

namespace App\View\Components\Admin\Notification_setting;

use Illuminate\View\Component;

class MailForm extends Component
{
    public $id;
    public $title;
    public $users;
    public $awarenessCampaigns;

    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct($id, $title, $users, $awarenessCampaigns = null)
    {
        $this->id = $id;
        $this->title = $title;
        $this->users = $users;
        $this->awarenessCampaigns = $awarenessCampaigns ?? collect();
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        return view('components.admin.notification_setting.mail-form');
    }
}
