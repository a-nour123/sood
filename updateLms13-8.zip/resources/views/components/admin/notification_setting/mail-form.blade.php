<div class="modal fade" tabindex="-1" role="dialog"
    aria-labelledby="mailSettingsModalTitle" aria-hidden="true" id="{{ $id }}">
    <div class="modal-dialog modal-xl modal-dialog-scrollable modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="mailSettingsModalTitle">{{ $title }}</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST">
                @csrf
                <input type="hidden" name="action_id">
                <input type="hidden" name="mail_setting_id">
                <div class="modal-body">
                    <style>
                        #{{ $id }}.modal {
                            position: fixed;
                            z-index: 1055;
                        }
                        #{{ $id }}.modal .modal-dialog {
                            max-height: calc(100vh - 2rem);
                            margin: 1rem auto;
                        }
                        #{{ $id }} .modal-content {
                            max-height: calc(100vh - 2rem);
                        }
                        #{{ $id }} .modal-body {
                            overflow-y: auto !important;
                            max-height: calc(100vh - 10rem);
                            -webkit-overflow-scrolling: touch;
                        }
                        #{{ $id }} #editor.ql-container {
                            max-height: 160px;
                            overflow-y: auto;
                        }
                        #{{ $id }} #editor .ql-editor {
                            max-height: 140px;
                            overflow-y: auto;
                        }
                        #mailAwarenessEnrollSection .select2-container {
                            width: 100% !important;
                            max-width: 100%;
                        }
                        #mailAwarenessEnrollSection .select2-selection--multiple {
                            max-height: 88px !important;
                            overflow-y: auto !important;
                            min-height: 38px;
                        }
                        #mailAwarenessEnrollSection .select2-selection__choice {
                            max-width: 100%;
                            overflow: hidden;
                            text-overflow: ellipsis;
                            white-space: nowrap;
                        }
                    </style>

                    {{-- subject --}}
                    <div class="mb-1">
                        <label class="form-label">{{ __('locale.Subject') }}</label>
                        <input class="form-control" name="subject" type="text" />
                        <span class="error error-subject"></span>
                    </div>

                    {{-- body --}}
                    <div class="mb-1">
                        <label class="form-label">{{ __('locale.Body') }}</label>
                        <div id="editor" class="form-control" rows="3"></div>
                        <input type="hidden" name="body" id="mail_body_input">
                        <span class="error error-body"></span>

                        <div id="variables_container" style="display: none">
                            <strong style="font-size: larger">{{ __('locale.ClickOnVariableYouWantToAdd') }} :</strong>
                            <div id="variables"></div>
                        </div>
                    </div>

                    @if (($awarenessCampaigns ?? collect())->isNotEmpty())
                        <div id="mailAwarenessEnrollSection" class="mb-1 d-none">
                            <hr>
                            <p class="text-muted mb-1">{{ __('lms.SendAwarenessEnrollNotificationHint') }}</p>
                            <div class="mb-1">
                                <label class="form-label" for="mail_awareness_campaign_id">{{ __('lms.ApprovedAwarenessCampaigns') }}</label>
                                <select id="mail_awareness_campaign_id" class="form-select">
                                    <option value="">{{ __('locale.select-option') }}</option>
                                    @foreach ($awarenessCampaigns as $campaign)
                                        <option value="{{ $campaign->id }}">
                                            {{ $campaign->campaign_name }}
                                            ({{ $campaign->campaign_type }})
                                            — {{ $campaign->employees_count }} {{ __('lms.employees') }}
                                            / {{ $campaign->training_modules_count }} {{ __('lms.trainings') }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                            <div id="mailAwarenessRecipientsBox" class="d-none">
                                <div class="mb-1">
                                    <label class="form-label" for="mail_awareness_group_ids">{{ __('lms.CampaignGroups') }}</label>
                                    <select id="mail_awareness_group_ids" class="form-select" multiple></select>
                                    <small class="text-muted d-block">{{ __('lms.CampaignGroupsHint') }}</small>
                                </div>
                                <div class="mb-1">
                                    <label class="form-label" for="mail_awareness_user_ids">{{ __('lms.CampaignUsers') }}</label>
                                    <select id="mail_awareness_user_ids" class="form-select" multiple></select>
                                    <small class="text-muted d-block">{{ __('lms.CampaignUsersHint') }}</small>
                                </div>
                                <div class="mb-1 text-muted small">
                                    <span class="badge bg-light-primary" id="mailAwarenessSelectedCount">0</span>
                                    {{ __('lms.SelectedRecipients') }}
                                    <span class="mx-1">|</span>
                                    <span id="mailAwarenessTrainingsLabel"></span>
                                </div>
                            </div>
                            <hr>
                        </div>
                    @endif

                    {{-- users --}}
                    <div class="mb-1" id="mailGenericUsersBox">
                        <label class="form-label">{{ __('locale.Users') }}</label>
                        <select name="users[]" class="form-select multiple-select2 select2" multiple="multiple">
                            <option value="" disabled hidden>{{ __('locale.select-option') }}</option>
                            @foreach ($users as $user)
                                <option value="{{ $user->id }}">{{ $user->name }}</option>
                            @endforeach
                        </select>
                        <span class="error error-users"></span>
                    </div>

                    {{-- roles --}}
                    <div class="mb-1">
                        <label class="form-label">{{ __('locale.Roles') }}</label>
                        <select name="roles[]" class="form-select multiple-select2 select2" multiple="multiple"
                            id="mailActionRoles">
                            <option value="" disabled hidden>{{ __('locale.select-option') }}</option>
                        </select>
                        <span class="error error-roles"></span>
                    </div>

                    {{-- status --}}
                    <div class="mb-1">
                        <div class="d-flex flex-column">
                            <label class="form-label">{{ __('locale.Active') }}</label>
                            <div class="form-check form-switch form-check-success">
                                <input type="checkbox" name="status" class="form-check-input" id="mailStatus" />
                                <label class="form-check-label" for="mailStatus">
                                    <span class="switch-icon-left"><i data-feather="check"></i></span>
                                    <span class="switch-icon-right"><i data-feather="x"></i></span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="Submit" class="btn btn-primary data-submit">{{ __('locale.Submit') }}</button>
                </div>
            </form>
        </div>
    </div>
</div>
