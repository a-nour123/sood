<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class PhishingEmail extends Mailable
{
    use Queueable, SerializesModels;

    public $emailData;
    public $employee;
    public $campaign_id;

    public function __construct($emailData, $employee, $campaign_id = null)
    {
        $this->emailData = $emailData;
        $this->employee = $employee;
        $this->campaign_id = $campaign_id;
    }

    public function build()
    {
        $body = view('emails.phishing.email')
            ->with([
                'campaign_id' => $this->campaign_id,
                'emailData' => $this->emailData,
                'employee' => $this->employee,
            ])
            ->render();

        $body = str_replace('$$emailId', $this->emailData['id'], $body);
        $body = str_replace('$$employeeId', $this->employee->id, $body);

        $clickUrl = $this->buildClickUrl();
        $body = str_replace('{PhishWebsitePage}', $clickUrl, $body);
        $body = str_replace('$$NAME$$', $this->employee->name, $body);
        $body = $this->normalizeOutboundEmailBody($body);

        if ($this->emailData['mail_attachment']) {
            $attachmentHtml = view('emails.phishing.partial')
                ->with([
                    'campaign_id' => $this->campaign_id,
                    'fileName' => $this->emailData['mail_attachment'],
                    'emailId' => $this->emailData['id'],
                    'employeeId' => $this->employee->id,
                ])
                ->render();

            $body .= $attachmentHtml;
        }

        return $this->html($body);
    }

    /**
     * Build an absolute https click-tracking URL for email clients.
     */
    protected function buildClickUrl(): string
    {
        $baseUrl = $this->ensureAbsoluteUrl(config('app.url'));
        $websiteId = $this->emailData->website->id ?? data_get($this->emailData, 'website.id');

        return $baseUrl
            . '/PWPI/' . $websiteId
            . '/click?PMTI=' . $this->emailData['id']
            . '&PEI=' . $this->employee->id
            . '&PCI=' . $this->campaign_id;
    }

    /**
     * Ensure URL has http/https so webmail treats <a href> as clickable.
     */
    protected function ensureAbsoluteUrl(?string $url): string
    {
        $url = trim((string) $url);
        $url = rtrim($url, '/');
        // Strip trailing :port from host only (e.g. http://host:8000)
        $url = preg_replace('#^(https?://[^/]+):\d+$#i', '$1', $url);

        if ($url === '') {
            return 'https://localhost';
        }

        if (!preg_match('#^https?://#i', $url)) {
            $url = 'https://' . ltrim($url, '/');
        }

        return $url;
    }

    /**
     * Make sure every phishing link in the outbound HTML is a valid absolute URL.
     */
    protected function normalizeOutboundEmailBody(string $body): string
    {
        // Remove spaces after href="
        $body = preg_replace('/href="\s+/i', 'href="', $body);

        // Fix double protocol: https://https://... or https://http://...
        $body = preg_replace('/href="https?:\/\/\s*(https?:\/\/)/i', 'href="$1', $body);

        // Add https:// to href values that look like domains/paths without a scheme
        $body = preg_replace_callback(
            '/href="(?!https?:\/\/|mailto:|tel:|#|\{)([^"]+)"/i',
            function ($matches) {
                $target = trim($matches[1]);
                if ($target === '') {
                    return 'href="#"';
                }
                if (preg_match('#^https?://#i', $target)) {
                    return 'href="' . $target . '"';
                }

                return 'href="https://' . ltrim($target, '/') . '"';
            },
            $body
        );

        return $body;
    }

    public function getMailWebsiteUrl()
    {
        $website = $this->emailData->website;
        if ($website->domain()->exists()) {
            $subdomain = $website->from_address_name;
            $domain = ltrim($website->domain->name, '@');
            $dynamicUrl = "{$subdomain}.{$domain}/PWPI/{$website->id}?PMTI={$this->emailData->id}&PEI={$this->employee->id}";
        } else {
            $domain = $website->from_address_name;
            $dynamicUrl = "{$domain}/PWPI/{$website->id}?PMTI={$this->emailData->id}&PEI={$this->employee->id}";
        }

        return $this->ensureAbsoluteUrl($dynamicUrl);
    }
}
