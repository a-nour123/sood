<?php

namespace App\Services\Mail;

use PHPMailer\PHPMailer\PHPMailer;

/**
 * Shared KSU / cybersecurity branded HTML shell for all PHPMailer SMTP emails.
 * Idempotent: bodies already containing the shell marker are not wrapped twice.
 */
final class KsuSmtpEmailTemplate
{
    public const MARKER = 'ksu-grc-mail-shell';

    public static function wrap(string $body): string
    {
        if (str_contains($body, self::MARKER)) {
            return $body;
        }

        $logoPath = public_path('images/ksu-logo.png');
        $logoSrc = is_file($logoPath) ? 'cid:ksu_logo' : e(asset('images/ksu-logo.png'));

        $shell = <<<'HTML'
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<!-- ksu-grc-mail-shell -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="color-scheme" content="light">
<meta name="supported-color-schemes" content="light">
</head>
<body style="margin:0;padding:0;background-color:#e8eaed; direction:rtl !important;">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color:#e8eaed;padding:24px 12px;">
<tr>
<td align="center">
<table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width:600px;width:100%;border-collapse:separate;border-spacing:0;border-radius:10px;overflow:hidden;background:#ffffff;box-shadow:0 1px 3px rgba(60,64,67,0.12);">
<tr>
<td style="padding:0;background-color:#FFFF;">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" dir="ltr">
<tr>
<td style="vertical-align:middle;text-align:left;padding:22px 20px 22px 24px;">
<p style="margin:0;color:black;font-size:22px;font-weight:700;line-height:1.35;font-family:'Segoe UI',Tahoma,'Arabic UI Text','Noto Naskh Arabic',Arial,sans-serif;">الادارة العامة للامن السيبراني</p>
</td>
<td style="vertical-align:middle;text-align:right;width:1%;padding:18px 24px 18px 12px;">
<img src="__LOGO_SRC__" alt="جامعة الملك سعود" width="130" style="display:block;border:0;margin-left:auto;max-width:130px;height:auto;">
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="padding:32px 28px 36px 28px;background:#ffffff;color:#202124;font-size:15px;line-height:1.75;font-family:'Segoe UI',Tahoma,'Arabic UI Text','Noto Naskh Arabic',Arial,sans-serif;">
__BODY__
</td>
</tr>
<tr>
<td style="padding:14px 24px;background:#f3f4f6;border-top:1px solid #e8eaed;text-align:center;">
<p style="margin:0;color:#9aa0a6;font-size:11px;line-height:1.5;font-family:'Segoe UI',Tahoma,'Arabic UI Text',Arial,sans-serif;">هذه رسالة آلية — يرجى عدم الرد على هذا البريد.</p>
</td>
</tr>
</table>
</td>
</tr>
</table>
</body>
</html>
HTML;

        return str_replace(
            ['__LOGO_SRC__', '__BODY__'],
            [$logoSrc, $body],
            $shell
        );
    }

    public static function embedKsuLogo(PHPMailer $mail): void
    {
        $ksuLogo = public_path('images/ksu-logo.png');
        if (is_file($ksuLogo) && str_contains((string) $mail->Body, 'cid:ksu_logo')) {
            $mail->addEmbeddedImage($ksuLogo, 'ksu_logo', 'ksu-logo.png');
        }
    }
}
