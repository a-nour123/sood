<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Phishing Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple Phishing links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */
    'lms_managment' => 'LMS Management',
    'Courses' => 'Courses',
    'Course' => 'Course',

    'Quizes' => 'Quizes',
    'Training_modules' => 'Training Modules',
    'search_by_course_name' => 'Search By Course Name',

    'last_updated' => 'Last Updated',
    'Levels' => 'Levels',
    'Training modules' => 'Training modules',
    'Questions' => 'Questions',
    'Statements' => 'Statements',
    'Manage Course' => 'Manage Course',
    'Finish Preview' => 'Finish Preview',

    'Add Level' => 'Add Level',
    'Course Details' => 'Course Details',

    'Course Title' => ' Course Title',
    'Course Description' => ' Course Description',
    'Course Image' => 'Course Image ',
    'Course Update' => 'Course Update ',
    'Close' => 'Close',

    'Add New Course' => 'Add New Course',
    'Save' => 'Save',
    'Update' => 'Update',


    'Add New Level' => 'Add New Level',
    'Level Title' => 'Level Title',
    'Level Order' => 'Level Order',
    'Edit Level' => 'Edit Level',


    'Add Training Module' => 'Add Training Module',
    'Training Name' => 'Training Name',
    'Passing Score' => 'Passing Score',
    'Module Order' => 'Module Order',
    'Cover Image' => 'Cover Image',
    'Cover Image URL' => 'Cover Image URL',
    'Completion Time' => 'Completion Time',
    'Compliance Mapping' => 'Compliance Mapping',
    'Training Pages' => 'Training Pages',
    'Add Question' => 'Add Question',
    'Add Statement' => 'Add Statement',
    'Statement' => 'Statement',
    'Page' => 'Page',
    'Remove Statement' => 'Remove Statement',
    'Statement Title' => 'Statement Title',
    'Statement Content' => 'Statement Content',
    'Additional Content' => 'Additional Content',
    'No Additional Content' => 'No Additional Content',
    'Embedded Video Url' => 'Embedded Video Url',
    'Embedded Image Content' => 'Embedded Image Content',
    'Spot The Phish Guided' => 'Spot The Phish Guided',
    'Navbar Content' => 'Navbar Content',
    'Embedded Video URL English' => 'Embedded Video URL English',
    'Choose Statement Image' => 'Choose Statement Image',
    'Embedded Image URL' => 'Embedded Image URL',
    'Total Questions' => 'Total Questions',
    'Total Statements' => 'Total Statements',
    'Total Pages' => 'Total Pages',
    'Cancel' => 'Cancel',

    'Edit Training Module' => 'Edit Training Module',
    'Level' => 'Level',
    'Delete Level' => 'Delete Level',


    'Remove Question' => 'Remove Question',
    'Question' => 'Question',
    'Question Type' => 'Question Type',
    'Multi Choice' => 'Multi Choice',
    'True or False' => 'True or False',
    'Option' => 'Option',
    'Answer' => 'Answer',
    'True' => 'True',
    'False' => 'False',
    'Answer Description' => 'Answer Description',


    'Start Train' => 'Start Train',
    'Passed' => 'Passed',
    'Over Due' => 'Over Due',
    'Failed' => 'Failed',
    'Due Date' => 'Due Date',

    'Important Notice' => 'Important Notice',
    'If you proceed to training and refresh the page, your score will be calculated and you will not be able to Re-exercise. Are you sure you want to continue ?' => 'If you proceed to training and refresh the page, your score will be calculated and you will not be able to Re-exercise. Are you sure you want to continue ?',
    'Yes, proceed' => 'Yes, proceed',

    'Back' => 'Back',
    'Next' => 'Next',
    'Submit' => 'Submit',

    'View Options Again' => 'View Options Again',
    'Sorry ! You Have Failed. Your Score is' => 'Sorry ! You Have Failed. Your Score is',
    'Congratulation ! You Have Success. Your Score is' => 'Congratulation ! You Have Success. Your Score is',

    'Trainings' => 'Trainings',
    'Locked' => 'Locked',
    'Public' => 'Public',
    'Campaign' => 'Campaign',
    'Attempts' => 'Attempts',
    'No Attempts' => 'No Attempts',
    'No training modules available for this level' => 'No training modules available for this level',
    'No levels available for this course' => 'No levels available for this course',
    'No training courses available' => 'No training courses available',
    'Please contact your administrator to assign training courses' => 'Please contact your administrator to assign training courses',


    'Quiz Summary' => 'Quiz Summary',
    'Congratulations!' => 'Congratulations!',
    'Try Again' => 'Try Again',
    'You have successfully passed the training!' => 'You have successfully passed the training!',
    'You need more practice. Keep learning!' => 'You need more practice. Keep learning!',
    'Correct Answers' => 'Correct Answers',
    'Incorrect Answers' => 'Incorrect Answers',
    'Detailed Answers Review' => 'Detailed Answers Review',
    'Correct' => 'Correct',
    'Incorrect' => 'Incorrect',
    'Your Answer' => 'Your Answer',
    'Correct Answer' => 'Correct Answer',
    'No answer provided' => 'No answer provided',
    'Complete Survey' => 'Complete Survey',
    'attempts left' => 'attempts left',
    'Back to Training Modules' => 'Back to Training Modules',
    'No questions found' => 'No questions found',
    'You have not attempted this training yet' => 'You have not attempted this training yet',

    'survey_draft_saved' => 'Survey draft saved successfully',
    'survey_submitted_successfully' => 'Survey submitted successfully',
    'Certificates' => 'Certificates',

    // Dashboard translations
    'Training Dashboard' => 'Training Dashboard',
    'Public Trainings' => 'Public Trainings',
    'Campaign Trainings' => 'Campaign Trainings',
    'Total Public Trainings' => 'Total Public Trainings',
    'Total Campaign Trainings' => 'Total Campaign Trainings',
    'Total Enrollments' => 'Total Enrollments',
    'Success Rate' => 'Success Rate',
    'Completion Trend (Last 12 Months)' => 'Completion Trend (Last 12 Months)',
    'Top Performers' => 'Top Performers',
    'trainings' => 'trainings',
    'avg score' => 'avg score',
    'Trainings by Course' => 'Trainings by Course',
    'Enrollments' => 'Enrollments',
    'Completed' => 'Completed',
    'complete' => 'complete',
    'Recent Completions (Last 30 Days)' => 'Recent Completions (Last 30 Days)',
    'User' => 'User',
    'Training' => 'Training',
    'Score' => 'Score',
    'Status' => 'Status',
    'Completed At' => 'Completed At',
    'Average Scores by Training' => 'Average Scores by Training',
    'Total Completions' => 'Total Completions',
    'Average Score' => 'Average Score',

];
