<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Phishing Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple Phishing links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */
    'lms_managment' => 'ادارة المحتوي التعليمي',
    'Courses' => 'الكورسات',
    'Course' => 'الكورس',
    'Quizes' => 'الكويزات',
    'Training_modules' => 'الدورات التدريبية',

    'search_by_course_name' => 'بحث باسم الكورس',

    'last_updated' => 'أخر تحديث',
    'Levels' => 'المستويات',
    'Training modules' => 'الدورات التدريبية',
    'Questions' => 'الاسئلة',
    'Statements' => 'المقالات',
    'Manage Course' => 'ادارة الكورس',

    'Add Level' => 'اضافة مستوي',
    'Course Details' => 'تفاصيل الكورس',
    'Finish Preview' => 'انهاء المعاينة',



    'Course Title' => 'اسم الكورس',
    'Course Description' => 'وصف الكورس',
    'Course Image' => 'صورة الكورس',
    'Course Update' => 'تعديل الكورس',
    'Close' => 'اغلاق',

    'Add New Course' => 'اضافة كورس جديد',
    'Save' => 'حفظ',
    'Update' => 'تعديل',

    'Add New Level' => 'اضافة مستوي جديد',
    'Level Title' => 'اسم المستوي',
    'Level Order' => 'ترتيب المستوي',

    'Edit Level' => 'تعديل المستوي',




    'Add Training Module' => 'اضافة تدريب',
    'Training Name' => 'اسم التدريب',
    'Passing Score' => 'درجة النجاح',
    'Module Order' => 'ترتيب التدريب',
    'Cover Image' => 'صورة الغلاف',
    'Cover Image URL' => 'رابط صورة الغلاف',
    'Completion Time' => 'وقت الإكمال',
    'Compliance Mapping' => 'توافق التدريب',
    'Training Pages' => 'صفحات التدريب',
    'Add Question' => 'إضافة سؤال',
    'Add Statement' => 'إضافة بيان',
    'Statement' => 'البيان',
    'Page' => 'الصفحة',
    'Remove Statement' => 'حذف البيان',
    'Statement Title' => 'عنوان البيان',
    'Statement Content' => 'محتوى البيان',
    'Additional Content' => 'محتوى إضافي',
    'No Additional Content' => 'لا يوجد محتوى إضافي',
    'Embedded Video Url' => 'رابط فيديو مدمج',
    'Embedded Image Content' => 'محتوى الصورة المدمجة',
    'Spot The Phish Guided' => 'حدد التصيد الموجه',
    'Navbar Content' => 'محتوى شريط التنقل',
    'Embedded Video URL English' => 'رابط فيديو مدمج باللغة الإنجليزية',
    'Choose Statement Image' => 'اختر صورة البيان',
    'Embedded Image URL' => 'رابط الصورة المدمجة',
    'Total Questions' => 'إجمالي الأسئلة',
    'Total Statements' => 'إجمالي البيانات',
    'Total Pages' => 'إجمالي الصفحات',
    'Cancel' => 'إلغاء',


    'Edit Training Module' => 'تعديل التدريب',
    'Level' => 'المستوي',
    'Delete Level' => 'حذف المستوي',



    'Remove Question' => 'حذف السؤال',
    'Question' => 'السؤال',
    'Question Type' => 'نوع السؤال',
    'Multi Choice' => 'اختيار متعدد',
    'True or False' => 'صح أو خطأ',
    'Option' => 'الخيار',
    'Answer' => 'الإجابة',
    'True' => 'صح',
    'False' => 'خطأ',
    'Answer Description' => 'وصف الإجابة',

    'Start Train' => 'ابدأ التدريب',
    'Passed' => 'ناجح',
    'Over Due' => 'متأخر',
    'Failed' => 'راسب',
    'Due Date' => 'تاريخ الاستحقاق',




    'Important Notice' => 'تنويه هام',
    'If you proceed to training and refresh the page, your score will be calculated and you will not be able to Re-exercise. Are you sure you want to continue ?' => 'إذا واصلت التدريب وقمت بتحديث الصفحة، سيتم احتساب نتيجتك ولن تتمكن من إعادة المحاولة. هل أنت متأكد أنك تريد الاستمرار؟',
    'Yes, proceed' => 'نعم، استمر',



    'Back' => 'رجوع',
    'Next' => 'التالي',
    'Submit' => 'ارسال',
    'View Options Again' => 'عرض الخيارات مرة أخرى',

    'Sorry ! You Have Failed. Your Score is' => 'عذرًا! لقد رسبت. نتيجتك هي',
    'Congratulation ! You Have Success. Your Score is' => 'تهانينا! لقد نجحت. نتيجتك هي',

    'Trainings' => 'التدريبات',
    'Locked' => 'مغلق',
    'Public' => 'عام',
    'Campaign' => 'حملة',
    'Attempts' => 'محاولات',
    'No Attempts' => 'لا توجد محاولات',
    'No training modules available for this level' => 'لا توجد تدريبات متاحة لهذا المستوى',
    'No levels available for this course' => 'لا توجد مستويات متاحة لهذه الدورة',
    'No training courses available' => 'لا توجد دورات تدريبية متاحة',
    'Please contact your administrator to assign training courses' => 'يرجى التواصل مع المسؤول لتعيين دورات تدريبية',

    'Quiz Summary' => 'ملخص الاختبار',
    'Congratulations!' => 'تهانينا!',
    'Try Again' => 'حاول مرة أخرى',
    'You have successfully passed the training!' => 'لقد نجحت في اجتياز التدريب!',
    'You need more practice. Keep learning!' => 'تحتاج إلى مزيد من الممارسة. استمر في التعلم!',
    'Correct Answers' => 'الإجابات الصحيحة',
    'Incorrect Answers' => 'الإجابات الخاطئة',
    'Detailed Answers Review' => 'مراجعة تفصيلية للإجابات',
    'Correct' => 'صحيح',
    'Incorrect' => 'خاطئ',
    'Your Answer' => 'إجابتك',
    'Correct Answer' => 'الإجابة الصحيحة',
    'No answer provided' => 'لم يتم تقديم إجابة',
    'Complete Survey' => 'إكمال الاستبيان',
    'attempts left' => 'محاولات متبقية',
    'Back to Training Modules' => 'العودة إلى وحدات التدريب',
    'No questions found' => 'لم يتم العثور على أسئلة',
    'You have not attempted this training yet' => 'لم تحاول هذا التدريب بعد',

    'survey_draft_saved' => 'تم حفظ مسودة الاستبيان',
    'survey_submitted_successfully' => 'تم تقديم الاستبيان بنجاح',
    'Certificates' => 'الشهادات',

    // Dashboard translations
    'Training Dashboard' => 'لوحة تحكم التدريب',
    'Public Trainings' => 'التدريبات العامة',
    'Campaign Trainings' => 'تدريبات الحملات',
    'Total Public Trainings' => 'إجمالي التدريبات العامة',
    'Total Campaign Trainings' => 'إجمالي تدريبات الحملات',
    'Total Enrollments' => 'إجمالي التسجيلات',
    'Success Rate' => 'معدل النجاح',
    'Completion Trend (Last 12 Months)' => 'اتجاه الإكمال (آخر 12 شهرًا)',
    'Top Performers' => 'أفضل الأداء',
    'trainings' => 'تدريبات',
    'avg score' => 'متوسط النتيجة',
    'Trainings by Course' => 'التدريبات حسب الكورس',
    'Enrollments' => 'التسجيلات',
    'Completed' => 'مكتمل',
    'complete' => 'مكتمل',
    'Recent Completions (Last 30 Days)' => 'الإكمالات الأخيرة (آخر 30 يومًا)',
    'User' => 'المستخدم',
    'Training' => 'التدريب',
    'Score' => 'النتيجة',
    'Status' => 'الحالة',
    'Completed At' => 'تاريخ الإكمال',
    'Average Scores by Training' => 'متوسط النتائج حسب التدريب',
    'Total Completions' => 'إجمالي الإكمالات',
    'Average Score' => 'متوسط النتيجة',














];
