@extends('admin/layouts/contentLayoutMaster')

@section('title', __('phishing.CISO_Phishing_Report'))

@section('vendor-style')
@endsection

@section('page-style')
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .page-wrapper.compact-small .page-body-wrapper .page-body {
            margin-left: 0 !important;
        }
        .page-wrapper .page-body-wrapper .page-body {
            padding: 0 !important;
        }
        .highcharts-credits {
            display: none;
        }
        .card {
            border-radius: 10px;
            transition: all 0.3s ease;
        }
        .card:hover {
            box-shadow: 0 5px 15px rgba(0,0,0,0.1) !important;
        }
        .widget-1 {
            transition: all 0.3s ease;
        }
        .widget-1:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.15) !important;
        }
        .table tbody tr {
            transition: all 0.2s ease;
        }
        .table tbody tr:hover {
            background-color: #f8f9fa;
        }
        .progress {
            border-radius: 10px;
        }
        .widget-round.secondary .bg-round {
            background: linear-gradient(135deg, #6c757d 0%, #495057 100%);
        }
    </style>
@endsection

@section('content')
    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">
            <div class="row breadcrumbs-top widget-grid">
                <div class="col-12">
                    <div class="page-title mt-2">
                        <div class="row">
                            <div class="col-sm-12 ps-0">
                                @if (@isset($breadcrumbs))
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}" style="display: flex;">
                                            <svg class="stroke-icon">
                                                <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}"></use>
                                            </svg></a></li>
                                        @foreach ($breadcrumbs as $breadcrumb)
                                            <li class="breadcrumb-item">
                                                @if (isset($breadcrumb['link']))
                                                    <a href="{{ $breadcrumb['link'] == 'javascript:void(0)' ? $breadcrumb['link'] : url($breadcrumb['link']) }}">
                                                @endif
                                                {{ $breadcrumb['name'] }}
                                                @if (isset($breadcrumb['link']))
                                                    </a>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ol>
                                @endisset
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="page-wrapper" id="pageWrapper">
        <div class="page-body-wrapper">
            <div class="page-body">
                <div class="container-fluid"></div>
                <div class="container-fluid dashboard_default">
                    <div class="row widget-grid">

                        {{-- Date Range Filter --}}
                        <div class="col-12 mb-3">
                            <div class="card">
                                <div class="card-body">
                                    <form method="GET" action="{{ route('admin.phishing.ciso.phishing-report') }}" id="date-filter-form" class="row g-3 align-items-end">
                                        <div class="col-md-3">
                                            <label for="start_date" class="form-label">{{ __('phishing.Start_Date') }}</label>
                                            <input type="date" name="start_date" id="start_date" class="form-control" 
                                                   value="{{ request('start_date', \Carbon\Carbon::now()->subYear()->format('Y-m-d')) }}">
                                        </div>
                                        <div class="col-md-3">
                                            <label for="end_date" class="form-label">{{ __('phishing.End_Date') }}</label>
                                            <input type="date" name="end_date" id="end_date" class="form-control" 
                                                   value="{{ request('end_date', \Carbon\Carbon::now()->format('Y-m-d')) }}">
                                        </div>
                                        <div class="col-md-3">
                                            <button type="submit" class="btn btn-primary">{{ __('phishing.Filter') }}</button>
                                            <a href="{{ route('admin.phishing.ciso.phishing-report') }}" class="btn btn-secondary">{{ __('phishing.Reset') }}</a>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        {{-- Summary Statistics --}}
                        <div class="row mb-4">
                            <div class="col-xl-3 col-md-6 mb-3">
                                <div class="card widget-1 border-0 shadow-sm">
                                    <div class="card-body">
                                        <div class="widget-content">
                                            <div class="widget-round primary">
                                                <div class="bg-round">
                                                    <i class="fa fa-bullhorn"></i>
                                                    <svg class="half-circle svg-fill">
                                                        <use href="{{ asset('fonts/icons/icon-sprite.svg#halfcircle') }}"></use>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div>
                                                <h4>{{ $totalCampaigns }}</h4>
                                                <span class="f-light">{{ __('phishing.Phishing_Campaigns_Count') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-md-6 mb-3">
                                <div class="card widget-1 border-0 shadow-sm">
                                    <div class="card-body">
                                        <div class="widget-content">
                                            <div class="widget-round success">
                                                <div class="bg-round">
                                                    <i class="fa fa-envelope"></i>
                                                    <svg class="half-circle svg-fill">
                                                        <use href="{{ asset('fonts/icons/icon-sprite.svg#halfcircle') }}"></use>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div>
                                                <h4>{{ $totalEmails }}</h4>
                                                <span class="f-light">{{ __('phishing.Total_Emails_Delivered') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-md-6 mb-3">
                                <div class="card widget-1 border-0 shadow-sm">
                                    <div class="card-body">
                                        <div class="widget-content">
                                            <div class="widget-round warning">
                                                <div class="bg-round">
                                                    <i class="fa fa-users"></i>
                                                    <svg class="half-circle svg-fill">
                                                        <use href="{{ asset('fonts/icons/icon-sprite.svg#halfcircle') }}"></use>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div>
                                                <h4>{{ $totalEmployees }}</h4>
                                                <span class="f-light">{{ __('phishing.Total_Employees_Targeted') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-md-6 mb-3">
                                <div class="card widget-1 border-0 shadow-sm">
                                    <div class="card-body">
                                        <div class="widget-content">
                                            <div class="widget-round info">
                                                <div class="bg-round">
                                                    <i class="fa fa-mouse-pointer"></i>
                                                    <svg class="half-circle svg-fill">
                                                        <use href="{{ asset('fonts/icons/icon-sprite.svg#halfcircle') }}"></use>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div>
                                                <h4>{{ $usersClicked }}</h4>
                                                <span class="f-light">{{ __('phishing.Users_Who_Clicked') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-md-6 mb-3">
                                <div class="card widget-1 border-0 shadow-sm">
                                    <div class="card-body">
                                        <div class="widget-content">
                                            <div class="widget-round danger">
                                                <div class="bg-round">
                                                    <i class="fa fa-file-download"></i>
                                                    <svg class="half-circle svg-fill">
                                                        <use href="{{ asset('fonts/icons/icon-sprite.svg#halfcircle') }}"></use>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div>
                                                <h4>{{ $usersDownloaded }}</h4>
                                                <span class="f-light">{{ __('phishing.Users_Who_Downloaded') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-md-6 mb-3">
                                <div class="card widget-1 border-0 shadow-sm">
                                    <div class="card-body">
                                        <div class="widget-content">
                                            <div class="widget-round secondary">
                                                <div class="bg-round">
                                                    <i class="fa fa-percentage"></i>
                                                    <svg class="half-circle svg-fill">
                                                        <use href="{{ asset('fonts/icons/icon-sprite.svg#halfcircle') }}"></use>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div>
                                                <h4>{{ $totalEmployees > 0 ? number_format(($usersClicked / $totalEmployees) * 100, 2) : 0 }}%</h4>
                                                <span class="f-light">{{ __('phishing.Click_Rate') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- Campaigns Table --}}
                        <div class="col-12">
                            <div class="card border-0 shadow-sm">
                                <div class="card-header bg-white border-bottom pb-3">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <h4 class="mb-0">
                                            <i class="fa fa-list-alt me-2 text-primary"></i>
                                            {{ __('phishing.Campaigns_Statistic') }}
                                        </h4>
                                        <span class="badge bg-primary">{{ $campaigns->count() }}</span>
                                    </div>
                                </div>
                                <div class="card-body p-0">
                                    <div class="table-responsive">
                                        <table class="table table-hover mb-0">
                                            <thead class="table-light">
                                                <tr>
                                                    <th class="text-center">{{ __('phishing.CAMPAIGN_NAME') }}</th>
                                                    <th class="text-center">{{ __('phishing.Total_Emails_Delivered') }}</th>
                                                    <th class="text-center">{{ __('phishing.Total_Employees_Targeted') }}</th>
                                                    <th class="text-center">{{ __('phishing.clicked_link_count') }}</th>
                                                    <th class="text-center">{{ __('phishing.file_downloaded_count') }}</th>
                                                    <th class="text-center">{{ __('phishing.Click_Rate') }}</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @forelse($campaigns as $campaign)
                                                    @php
                                                        $clickRate = $campaign->deliverd_employees_count > 0 
                                                            ? number_format(($campaign->clicked_trackings_count / $campaign->deliverd_employees_count) * 100, 2) 
                                                            : 0;
                                                    @endphp
                                                    <tr>
                                                        <td class="text-center fw-bold">{{ $campaign->campaign_name }}</td>
                                                        <td class="text-center">
                                                            <span class="badge bg-info">{{ $campaign->deliverd_email_templates_count }}</span>
                                                        </td>
                                                        <td class="text-center">
                                                            <span class="badge bg-warning">{{ $campaign->deliverd_employees_count }}</span>
                                                        </td>
                                                        <td class="text-center">
                                                            <span class="badge bg-success">{{ $campaign->clicked_trackings_count }}</span>
                                                        </td>
                                                        <td class="text-center">
                                                            <span class="badge bg-danger">{{ $campaign->downloaded_trackings_count }}</span>
                                                        </td>
                                                        <td class="text-center">
                                                            <div class="d-flex align-items-center justify-content-center">
                                                                <span class="badge {{ $clickRate >= 50 ? 'bg-danger' : ($clickRate >= 30 ? 'bg-warning' : 'bg-success') }} me-2">
                                                                    {{ $clickRate }}%
                                                                </span>
                                                                <div class="progress" style="width: 100px; height: 8px;">
                                                                    <div class="progress-bar {{ $clickRate >= 50 ? 'bg-danger' : ($clickRate >= 30 ? 'bg-warning' : 'bg-success') }}" 
                                                                         role="progressbar" 
                                                                         style="width: {{ $clickRate }}%"
                                                                         aria-valuenow="{{ $clickRate }}" 
                                                                         aria-valuemin="0" 
                                                                         aria-valuemax="100"></div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                @empty
                                                    <tr>
                                                        <td colspan="6" class="text-center py-4">
                                                            <i class="fa fa-inbox fa-3x text-muted mb-2"></i>
                                                            <p class="text-muted">{{ __('locale.NoDataAvailable') }}</p>
                                                        </td>
                                                    </tr>
                                                @endforelse
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('vendor-script')
@endsection

@section('page-script')
    <script src="{{ asset('js/scripts/config.js') }}"></script>
@endsection
