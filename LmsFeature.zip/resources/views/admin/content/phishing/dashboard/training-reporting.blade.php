@extends('admin/layouts/contentLayoutMaster')

@section('title', __('Phishing.domains'))

@section('vendor-style')
<link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/buttons.bootstrap5.min.css')) }}">

@endsection


@section('page-style')
<link rel="stylesheet" href="{{ asset('cdn/buttons.dataTables.min.css') }}">

<style>
    .page-wrapper.compact-small .page-body-wrapper .page-body {
        margin-left: 0 !important;
    }
    .page-wrapper .page-body-wrapper .page-body{
        padding: 0 !important
    }

    button.dt-button, div.dt-button, a.dt-button, input.dt-button{
        background-color: #7ae3ee !important;
        color: white !important;
    }

    .text-center{
        text-align: center;
    }

    .highcharts-credits{
        display: none;
    }
    
    /* Modal Improvements */
    .modal {
        overflow-y: auto !important;
    }
    
    .modal.show {
        display: block !important;
        overflow-x: hidden;
        overflow-y: auto;
    }
    
    body.modal-open {
        overflow: hidden !important;
        padding-right: 0 !important;
    }

    .modal-content {
        border-radius: 10px;
        border: none;
        box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        max-height: 90vh;
        display: flex;
        flex-direction: column;
    }

    .modal-header {
        border-radius: 10px 10px 0 0;
        padding: 1.25rem 1.5rem;
        flex-shrink: 0;
    }

    .modal-body {
        padding: 1.5rem;
        overflow-y: auto;
        overflow-x: hidden;
        max-height: calc(90vh - 150px);
        flex: 1 1 auto;
    }

    .modal-footer {
        border-radius: 0 0 10px 10px;
        padding: 1rem 1.5rem;
        flex-shrink: 0;
    }
    
    /* Hide table headers in reports */
    .table thead.d-none {
        display: none !important;
    }
</style>
@endsection
@section('content')

    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">

            <div class="row breadcrumbs-top  widget-grid">
                <div class="col-12">
                    <div class="page-title mt-2">
                        <div class="row">
                            <div class="col-sm-6 ps-0">
                                @if (@isset($breadcrumbs))
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}"
                                                style="display: flex;">
                                                <svg class="stroke-icon">
                                                    <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}">
                                                    </use>
                                                </svg></a></li>
                                        @foreach ($breadcrumbs as $breadcrumb)
                                            <li class="breadcrumb-item">
                                                @if (isset($breadcrumb['link']))
                                                    <a
                                                        href="{{ $breadcrumb['link'] == 'javascript:void(0)' ? $breadcrumb['link'] : url($breadcrumb['link']) }}">
                                                @endif
                                                {{ $breadcrumb['name'] }}
                                                @if (isset($breadcrumb['link']))
                                                    </a>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ol>
                                @endisset
                        </div>

                    </div>
                </div>
            </div>

        </div>
    </div>



    <!-- Modal Email Template Data -->
    <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
 aria-labelledby="myExtraLargeModal" aria-hidden="true" id="campaign-employees-data-modal">
    <div class="modal-dialog modal-xl">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title" id="myExtraLargeModal">Campaign Employees</h4>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
    <!-- <div class="modal fade" style="z-index: 99999999; top: 150px;" id="campaign-employees-data-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"       aria-hidden="true">
        <div class="modal-dialog modal-xl" role="document"> -->
        <div class="modal-content">

            <!-- <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Campaign Employees</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div> -->

            <div class="modal-body">
                <section id="advanced-search-datatable">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="row align-items-center text-center text-md-left">
                                    <div class="col-lg-12 mt-lg-0 mt-3">
                                        <div id="dt-btns-employee" class="tableAdminOption">
                                        </div>
                                    </div>
                                </div>
                                <div class="card-datatable table-responsive">
                                    <table class="employee-dt-advanced-server-search table">
                                        <thead>
                                            <tr>
                                                <th></th>
                                                <th class="all">Name </th>
                                                <th class="all">Email</th>
                                                <th class="all">Mail Delivered</th>
                                                <th class="all">Mail Opened</th>
                                                <th class="all">Download File</th>
                                                <th class="all">Submit Data</th>
                                                <th class="all">{{ __('Actions') }}</th>
                                            </tr>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>

            <div class="modal-footer">
            <button type="button" class="btn btn-secondary"  data-bs-dismiss="modal">Close</button>
            </div>
        </div>
        </div>
    </div>
    </div>



    <!-- Modal Training data -->
    <div class="modal fade" style="z-index: 99999999; top: 150px;" id="training-employees-data-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"       aria-hidden="true">
        <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">

            <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Campaign Employees</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <section id="advanced-search-datatable">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="row align-items-center text-center text-md-left">
                                    <div class="col-lg-12 mt-lg-0 mt-3">
                                        <div id="dt-btns-training-employee" class="tableAdminOption">
                                        </div>
                                    </div>
                                </div>
                                <div class="card-datatable table-responsive">
                                    <table class="training-employee-dt-advanced-server-search table">
                                        <thead>
                                            <tr>
                                                <th class="all">{{ __('phishing.Email') }}</th>
                                                <th class="all">{{ __('phishing.Name') }} </th>
                                                <th class="all">{{ __('phishing.Training_Name') }}</th>
                                                <th class="all">{{ __('phishing.Date_Assigned') }}</th>
                                                <th class="all">{{ __('phishing.Days_Until_Due') }}</th>
                                                <th class="all">{{ __('phishing.Score') }}</th>
                                                <th class="all">{{ __('phishing.Passed') }}</th>
                                                <th class="all">{{ __('phishing.Failed') }}</th>
                                                <th class="all">{{ __('phishing.Passed_After_Overdue') }}</th>
                                                <th class="all">{{ __('phishing.OverDue') }}</th>
                                            </tr>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>

            <div class="modal-footer">
            <button type="button" class="btn btn-secondary"  data-bs-dismiss="modal">Close</button>
            </div>
        </div>
        </div>
    </div>


    <!-- Modal Details Employee Data Table -->
    <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
 aria-labelledby="myExtraLargeModal" aria-hidden="true" id="details-employees-data-modal">
    <div class="modal-dialog modal-xl">
      <div class="modal-content">
        <!-- <div class="modal-header">
          <h4 class="modal-title" id="myExtraLargeModal">Campaign Employees</h4>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div> -->
    <!-- <div class="modal fade" style="z-index: 99999999; top: 150px;" id="details-employees-data-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"       aria-hidden="true">
        <div class="modal-dialog modal-xl" role="document"> -->
        <div class="modal-content">

            <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel" class="employee-name">Campaign Employees</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <div class="col-xxl-12 col-xl-12 col-md-12 box-col-12">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        {{-- <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="employee-campaign-tab" data-bs-toggle="tab" data-bs-target="#employee-campaign" type="button" role="tab" aria-controls="employee-campaign" aria-selected="true"> Phishing Campaigns </button>
                        </li> --}}

                         <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="employee-training-tab" data-bs-toggle="tab" data-bs-target="#employee-training" type="button" role="tab" aria-controls="employee-training" aria-selected="false"> Training Assignments</button>
                        </li>
                    </ul>
                </div>

                <div class="tab-content my-3" id="myTabContent">
                    {{-- Employee Training Information --}}
                    <div class="tab-pane fade show" id="employee-campaign" role="tabpanel" aria-labelledby="employee-campaign-tab">
                        <div class="card invoice-card">
                            <div class="card-header pb-0">
                              <h3 class="my-3">Employee Campaigns</h3>
                            </div>
                            <div class="card-body transaction-card">
                              <div class="table-responsive theme-scrollbar">
                                <div class="row align-items-center text-center text-md-left">
                                    <div class="col-lg-12 mt-lg-0 mt-3">
                                        <div id="dt-btns-employee-details-phishing" class="tableAdminOption">
                                        </div>
                                    </div>
                                </div>
                                <table class="display employee-details-phishing-dt-advanced-server-search" id="recent-order-employee-details-phishing" style="width:100%">
                                  <thead>
                                    <tr>
                                        <th class="text-center">CAMPAIGN NAME</th>
                                        <th class="text-center">Mail Template</th>
                                        <th class="text-center">Mail Opened</th>
                                        <th class="text-center">Link Clicked</th>
                                        <th class="text-center">File Downloaded</th>
                                        <th class="text-center">Data Submitted</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                  </tbody>
                                </table>
                              </div>
                            </div>
                        </div>
                    </div>
                    </div>
                    </div>

                    {{-- Employee Training Information --}}
                    <div class="tab-pane fade show active" id="employee-training" role="tabpanel" aria-labelledby="employee-training-tab">
                        <div class="card invoice-card">
                            <div class="card-header pb-0">
                              <h3 class="my-3">Employee Training Campaigns</h3>
                            </div>
                            <div class="card-body transaction-card">
                              <div class="table-responsive theme-scrollbar">

                                <div class="row align-items-center text-center text-md-left">
                                    <div class="col-lg-12 mt-lg-0 mt-3">
                                        <div id="dt-btns-employee-details-training" class="tableAdminOption">
                                        </div>
                                    </div>
                                </div>

                                <table class="display employee-details-training-dt-advanced-server-search" id="recent-order-employee-details-training" style="width:100%">
                                  <thead>
                                    <tr>
                                        <th class="text-center">CAMPAIGN NAME</th>
                                        <th class="text-center">TRAINING NAME</th>
                                        <th class="text-center">SCORE</th>
                                        <th class="text-center"> COMPLETED</th>
                                        <th class="text-center"> OVERDUE</th>
                                        <th class="text-center"> PASSED</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                  </tbody>
                                </table>
                              </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal-footer">
            <button type="button" class="btn btn-secondary"  data-bs-dismiss="modal">Close</button>
            </div>
        </div>
        </div>
    </div>



    {{-- Dashboard --}}

    <div class="page-wrapper" id="pageWrapper">
        <!-- Page Body Start-->
        <div class="page-body-wrapper">
          <!-- Page Sidebar Ends-->
          <div class="page-body">
            <div class="container-fluid"></div>
            <!-- Container-fluid starts-->
            <div class="container-fluid dashboard_default">
              <div class="row widget-grid">

                {{-- Date Range Filter --}}
                <div class="col-12 mb-3">
                    <div class="card">
                        <div class="card-body">
                            <form method="GET" action="{{ route('admin.phishing.training-reporting') }}" id="date-filter-form" class="row g-3 align-items-end">
                                <div class="col-md-3">
                                    <label for="start_date" class="form-label">{{ __('phishing.Start_Date') }}</label>
                                    <input type="date" name="start_date" id="start_date" class="form-control" 
                                           value="{{ request('start_date', \Carbon\Carbon::now()->subYear()->format('Y-m-d')) }}">
                                </div>
                                <div class="col-md-3">
                                    <label for="end_date" class="form-label">{{ __('phishing.End_Date') }}</label>
                                    <input type="date" name="end_date" id="end_date" class="form-control" 
                                           value="{{ request('end_date', \Carbon\Carbon::now()->format('Y-m-d')) }}">
                                </div>
                                <div class="col-md-3">
                                    <button type="submit" class="btn btn-primary">{{ __('phishing.Filter') }}</button>
                                    <a href="{{ route('admin.phishing.training-reporting') }}" class="btn btn-secondary">{{ __('phishing.Reset') }}</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>




                <div class="col-xxl-12 col-xl-12 col-md-12 box-col-12">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        {{-- <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true"> Phishing Statistics </button>
                        </li> --}}

                         <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">{{ __('phishing.Training_Information') }}</button>
                        </li>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="ciso-training-tab" data-bs-toggle="tab" data-bs-target="#ciso-training" type="button" role="tab" aria-controls="ciso-training" aria-selected="false">{{ __('phishing.CISO_Training_Report') }}</button>
                        </li>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="employee-tab" data-bs-toggle="tab" data-bs-target="#employee" type="button" role="tab" aria-controls="employee" aria-selected="false">{{ __('phishing.Employee_Information') }}</button>
                        </li>
                    </ul>
                </div>


                <div class="tab-content my-3" id="myTabContent">
                    <div class="tab-pane fade" id="home" role="tabpanel" aria-labelledby="home-tab">

                        <div class="card">
                            <div class="card-header pb-0">
                              <h3 class="m-0">{{ __('phishing.Phishing_Emails_Delivered') }} ({{ __('phishing.Past_Year') }})</h3>
                            </div>
                            <div class="card-body row p-2">
                                <div id="chart-container"></div>
                            </div>
                        </div>

                        {{-- campaign chart --}}
                        <div class="card">
                            <div class="card-header pb-0">
                              <h3 class="m-0">{{ __('phishing.Campaigns_Statistic') }}</h3>
                            </div>
                            <div class="card-body row p-2">
                              <div class="col-lg-12">
                                <div id="campaign-chart-container"></div>
                              </div>
                            </div>
                        </div>

                        {{-- Groups chart --}}
                        <div class="card">
                            <div class="card-header pb-0">
                              <h3 class="m-0">Groups Statistic</h3>
                            </div>
                            <div class="card-body row p-2">
                              <div class="col-lg-12">
                                <div id="groups-chart-container"></div>
                              </div>
                            </div>
                        </div>


                        {{-- Employees chart --}}
                        <div class="card">
                            <div class="card-header pb-0">
                              <h3 class="m-0">Employees Statistic</h3>
                            </div>
                            <div class="card-body row p-2">
                              <div class="col-lg-12">
                                <div id="employees-chart-container"></div>
                              </div>
                            </div>
                        </div>



                        <div class="card invoice-card">
                            <div class="card-header pb-0">
                              <h3 class="my-3">Active Campaigns</h3>
                            </div>
                            <div class="card-body transaction-card">
                              <div class="table-responsive theme-scrollbar">
                                <div class="row align-items-center text-center text-md-left">
                                    <div class="col-lg-12 mt-lg-0 mt-3">
                                        <div id="dt-btns-active-phishing" class="tableAdminOption">
                                        </div>
                                    </div>
                                </div>
                                <table class="display active-phishing-dt-advanced-server-search" id="recent-order-active-phishing" style="width:100%">
                                  <thead>
                                    <tr>
                                        <th class="text-center">#</th>
                                        <th class="text-center">CAMPAIGN NAME</th>
                                        <th class="text-center">STATUS </th>
                                        <th class="text-center">CAMPAIGN TYPE</th>
                                        <th class="text-center">SCEDULE DATE</th>
                                        <th class="text-center"> EMAIL DELIVERED</th>
                                        <th class="text-center"> EMAIL OPENED</th>
                                        <th class="text-center"> EMAIL DOWNLOAD FILE</th>
                                        <th class="text-center"> EMAIL SUBMIT DATA</th>
                                        <th class="text-center"> ACTIONS</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {{-- @foreach ($activeCampaigns as $campaign)
                                        <tr style="cursor: pointer"  onclick="openCampaignEmployees({{$campaign->id}})">
                                            <td class="text-center">{{ $campaign->campaign_name }}</td>
                                            <td class="text-center text-warning">{{ $campaign->status }}</td>
                                            <td class="text-center">{{ $campaign->schedule_date_from }} - {{ $campaign->schedule_date_to }}</td>
                                            <td class="text-center">{{ $campaign->deliverd_email_templates_count }}</td>
                                            <td class="text-center">{{ $campaign->opend_count }}</td>
                                            <td class="text-center">{{ $campaign->submited_count }}</td>
                                            <td class="text-center">{{ $campaign->downloaded_count }}</td>
                                            <td class="text-center">actions</td>
                                        </tr>
                                    @endforeach --}}

                                  </tbody>
                                </table>
                              </div>
                            </div>
                        </div>

                        <div class="card invoice-card">
                        </div>
                    </div>

                    {{-- Training Information --}}
                    <div class="tab-pane fade show active" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                        <div class="card">
                            <div class="card-header pb-0">
                              <h3 class="m-0">{{ __('phishing.Trainings_Assigned') }} ({{ __('phishing.Past_Year') }})</h3>
                            </div>
                            <div class="card-body row p-2">
                              <div class="col-lg-12">
                                <div id="training-chart-container"></div>
                              </div>
                            </div>
                        </div>

                        {{-- Active Training Campaigns --}}
                        <div class="card invoice-card">
                            <div class="card-header pb-0">
                              <h3 class="my-3">Active Training Campaigns</h3>
                            </div>
                            <div class="card-body transaction-card">
                              <div class="table-responsive theme-scrollbar">

                                <div class="row align-items-center text-center text-md-left">
                                    <div class="col-lg-12 mt-lg-0 mt-3">
                                        <div id="dt-btns-active-training" class="tableAdminOption">
                                        </div>
                                    </div>
                                </div>

                                <table class="display active-training-dt-advanced-server-search" id="recent-order-active-training" style="width:100%">
                                  <thead>
                                    <tr>
                                        <th class="text-center">{{ __('phishing.ID') }}</th>
                                        <th class="text-center">{{ __('phishing.CAMPAIGN_NAME') }}</th>
                                        <th class="text-center">{{ __('phishing.STATUS') }} </th>
                                        <th class="text-center">{{ __('phishing.CAMPAIGN_TYPE') }}</th>
                                        <th class="text-center">{{ __('phishing.SCHEDULED_DATE') }}</th>
                                        <th class="text-center"> {{ __('phishing.EMPLOYEE_COUNT') }}</th>
                                        <th class="text-center"> {{ __('phishing.ASSSIGNED') }}</th>
                                        <th class="text-center"> {{ __('phishing.PASSED') }}</th>
                                        <th class="text-center"> {{ __('phishing.FAILED') }}</th>
                                        <th class="text-center"> {{ __('phishing.PASSED_AFTER_OVERDUE') }}</th>
                                        <th class="text-center"> {{ __('phishing.OVERDUE') }}</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                  </tbody>
                                </table>
                              </div>
                            </div>
                        </div>

                        {{-- Archived Training Campaigns --}}
                        <div class="card invoice-card">
                            <div class="card-header pb-0">
                              <h3 class="my-3">Archived Training Campaigns</h3>
                            </div>
                            <div class="card-body transaction-card">
                              <div class="table-responsive theme-scrollbar">

                                <div class="row align-items-center text-center text-md-left">
                                    <div class="col-lg-12 mt-lg-0 mt-3">
                                        <div id="dt-btns-archived-training" class="tableAdminOption">
                                        </div>
                                    </div>
                                </div>

                                <table class="display archived-training-dt-advanced-server-search" id="recent-order-archived-training" style="width:100%">
                                  <thead>
                                    <tr>
                                        <th class="text-center">{{ __('phishing.ID') }}</th>
                                        <th class="text-center">{{ __('phishing.CAMPAIGN_NAME') }}</th>
                                        <th class="text-center">{{ __('phishing.STATUS') }} </th>
                                        <th class="text-center">{{ __('phishing.CAMPAIGN_TYPE') }}</th>
                                        <th class="text-center">{{ __('phishing.SCHEDULED_DATE') }}</th>
                                        <th class="text-center"> {{ __('phishing.EMPLOYEE_COUNT') }}</th>
                                        <th class="text-center"> {{ __('phishing.ASSSIGNED') }}</th>
                                        <th class="text-center"> {{ __('phishing.PASSED') }}</th>
                                        <th class="text-center"> {{ __('phishing.FAILED') }}</th>
                                        <th class="text-center"> {{ __('phishing.PASSED_AFTER_OVERDUE') }}</th>
                                        <th class="text-center"> {{ __('phishing.OVERDUE') }}</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                  </tbody>
                                </table>
                              </div>
                            </div>
                        </div>


                    </div>

                    {{-- CISO Training Report --}}
                    <div class="tab-pane fade" id="ciso-training" role="tabpanel" aria-labelledby="ciso-training-tab">
                        {{-- Summary Statistics --}}
                        <div class="row mb-4">
                            <div class="col-xl-3 col-md-6 mb-3">
                                <div class="card widget-1 border-0 shadow-sm">
                                    <div class="card-body">
                                        <div class="widget-content">
                                            <div class="widget-round primary">
                                                <div class="bg-round">
                                                    <i class="fa fa-users"></i>
                                                    <svg class="half-circle svg-fill">
                                                        <use href="{{ asset('fonts/icons/icon-sprite.svg#halfcircle') }}"></use>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div>
                                                <h4>{{ $cisoGroupStats->sum('total_employees') }}</h4>
                                                <span class="f-light">{{ __('phishing.Total_Employees') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6 mb-3">
                                <div class="card widget-1 border-0 shadow-sm">
                                    <div class="card-body">
                                        <div class="widget-content">
                                            <div class="widget-round success">
                                                <div class="bg-round">
                                                    <i class="fa fa-graduation-cap"></i>
                                                    <svg class="half-circle svg-fill">
                                                        <use href="{{ asset('fonts/icons/icon-sprite.svg#halfcircle') }}"></use>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div>
                                                <h4>{{ $cisoGroupStats->sum('total_campaigns') }}</h4>
                                                <span class="f-light">{{ __('phishing.Total_Training_Campaigns') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6 mb-3">
                                <div class="card widget-1 border-0 shadow-sm">
                                    <div class="card-body">
                                        <div class="widget-content">
                                            <div class="widget-round warning">
                                                <div class="bg-round">
                                                    <i class="fa fa-user-check"></i>
                                                    <svg class="half-circle svg-fill">
                                                        <use href="{{ asset('fonts/icons/icon-sprite.svg#halfcircle') }}"></use>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div>
                                                <h4>{{ $cisoGroupStats->sum('total_assigned') }}</h4>
                                                <span class="f-light">{{ __('phishing.Total_Assigned') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6 mb-3">
                                <div class="card widget-1 border-0 shadow-sm">
                                    <div class="card-body">
                                        <div class="widget-content">
                                            <div class="widget-round info">
                                                <div class="bg-round">
                                                    <i class="fa fa-check-circle"></i>
                                                    <svg class="half-circle svg-fill">
                                                        <use href="{{ asset('fonts/icons/icon-sprite.svg#halfcircle') }}"></use>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div>
                                                <h4>{{ $cisoGroupStats->sum('total_passed') }}</h4>
                                                <span class="f-light">{{ __('phishing.Total_Passed') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- Training Campaigns by Group Table --}}
                        <div class="col-12 mb-4">
                            <div class="card border-0 shadow-sm">
                                <div class="card-header bg-white border-bottom pb-3">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <h4 class="mb-0">
                                            <i class="fa fa-table me-2 text-primary"></i>
                                            {{ __('phishing.Training_Campaigns_By_Group') }}
                                        </h4>
                                        <span class="badge bg-primary">{{ $cisoGroupStats->count() }}</span>
                                    </div>
                                </div>
                                <div class="card-body p-0">
                                    <div class="table-responsive">
                                        <table class="table table-hover mb-0">
                                            <thead class="table-light">
                                                <tr>
                                                    <th class="text-center">{{ __('phishing.Name') }}</th>
                                                    <th class="text-center">{{ __('phishing.Total_Employees') }}</th>
                                                    <th class="text-center">{{ __('phishing.Total_Training_Campaigns') }}</th>
                                                    <th class="text-center">{{ __('phishing.Total_Assigned') }}</th>
                                                    <th class="text-center">{{ __('phishing.Total_Passed') }}</th>
                                                    <th class="text-center">{{ __('phishing.Attendance_Rate') }}</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @forelse($cisoGroupStats as $stat)
                                                    <tr>
                                                        <td class="text-center fw-bold">{{ $stat['group_name'] }}</td>
                                                        <td class="text-center">{{ $stat['total_employees'] }}</td>
                                                        <td class="text-center">
                                                            <span class="badge bg-info">{{ $stat['total_campaigns'] }}</span>
                                                        </td>
                                                        <td class="text-center">
                                                            <span class="badge bg-warning">{{ $stat['total_assigned'] }}</span>
                                                        </td>
                                                        <td class="text-center">
                                                            <span class="badge bg-success">{{ $stat['total_passed'] }}</span>
                                                        </td>
                                                        <td class="text-center">
                                                            <div class="d-flex align-items-center justify-content-center">
                                                                <span class="badge {{ $stat['attendance_rate'] >= 70 ? 'bg-success' : ($stat['attendance_rate'] >= 50 ? 'bg-warning' : 'bg-danger') }} me-2">
                                                                    {{ $stat['attendance_rate'] }}%
                                                                </span>
                                                                <div class="progress" style="width: 100px; height: 8px;">
                                                                    <div class="progress-bar {{ $stat['attendance_rate'] >= 70 ? 'bg-success' : ($stat['attendance_rate'] >= 50 ? 'bg-warning' : 'bg-danger') }}" 
                                                                         role="progressbar" 
                                                                         style="width: {{ $stat['attendance_rate'] }}%"
                                                                         aria-valuenow="{{ $stat['attendance_rate'] }}" 
                                                                         aria-valuemin="0" 
                                                                         aria-valuemax="100"></div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                @empty
                                                    <tr>
                                                        <td colspan="6" class="text-center py-4">
                                                            <i class="fa fa-inbox fa-3x text-muted mb-2"></i>
                                                            <p class="text-muted">{{ __('locale.NoDataAvailable') }}</p>
                                                        </td>
                                                    </tr>
                                                @endforelse
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- Chart Visualization --}}
                        @if($cisoGroupStats->count() > 0)
                        <div class="col-12">
                            <div class="card border-0 shadow-sm">
                                <div class="card-header bg-white border-bottom pb-3">
                                    <h4 class="mb-0">
                                        <i class="fa fa-chart-bar me-2 text-success"></i>
                                        {{ __('phishing.Training_Campaigns_By_Group') }}
                                    </h4>
                                </div>
                                <div class="card-body p-4">
                                    <div id="ciso-training-campaigns-chart" style="min-height: 400px;"></div>
                                </div>
                            </div>
                        </div>
                        @endif
                    </div>

                    {{-- Employee Information --}}
                    <div class="tab-pane fade" id="employee" role="tabpanel" aria-labelledby="employee-tab">
                        <div class="card invoice-card">
                            <div class="card-header pb-0">
                              <h3 class="my-3">Employee Statistics</h3>
                            </div>
                            <div class="card-body transaction-card">
                                <div class="table-responsive theme-scrollbar">

                                    <div class="row align-items-center text-center text-md-left">
                                        <div class="col-lg-12 mt-lg-0 mt-3">
                                            <div id="dt-btns-employee-statistics" class="tableAdminOption">
                                            </div>
                                        </div>
                                    </div>

                                    <table class="display employee-statistics-dt-advanced-server-search" id="recent-order-employee-statistics" style="width:100%">
                                      <thead>
                                        <tr>
                                            <th class="text-center"> ID</th>
                                            <th class="text-center"> EMAIL</th>
                                            <th class="text-center"> NAME</th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                      </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

              </div>
            </div>
          </div>
        </div>
    </div>
@endsection

@section('vendor-script')
@endsection

@section('page-script')
{{--  <script src="{{ asset('js/scripts/highcharts/highcharts.js') }}"></script>  --}}
<script src="{{ asset('js/scripts/config.js') }}"></script>
<script src="{{ asset('new_d/js/datatable/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{ asset('new_d/js/datatable/datatables/datatable.custom.js')}}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/datatables.buttons.min.js')) }}"></script>
{{-- DataTable Buttons Excel - Pdf - Print -.... --}}
<script src="{{ asset(mix('vendors/js/tables/datatable/jszip.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/pdfmake.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/vfs_fonts.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/buttons.html5.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/buttons.print.min.js')) }}"></script>
<script src="{{ asset('ajax-files/asset_management/asset/index.js') }}"></script>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>
<script src="https://code.highcharts.com/modules/offline-exporting.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // ************************************* Phishing charts *************************************
        Highcharts.chart('chart-container', {
            chart: {
                type: 'column'
            },
            title: {
                text: ' Campaign Mails Statistic'
            },
            xAxis: {
                categories: {!! $labels->toJson(JSON_UNESCAPED_UNICODE) !!},
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Mail Statistic'
                },
                stackLabels: {
                    enabled: true,
                    style: {
                        fontWeight: 'bold',
                        color: ( // theme
                            Highcharts.defaultOptions.title.style &&
                            Highcharts.defaultOptions.title.style.color
                        ) || 'gray'
                    }
                }
            },
            legend: {
                align: 'right',
                x: -30,
                verticalAlign: 'top',
                y: 25,
                floating: true,
                backgroundColor: Highcharts.defaultOptions.legend.backgroundColor || 'white',
                borderColor: '#CCC',
                borderWidth: 1,
                shadow: false
            },
            tooltip: {
                headerFormat: '<b>{point.x}</b>',
                pointFormat: ': {point.stackTotal}'
            },
            plotOptions: {
                column: {
                    stacking: null,
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            series: [
                {
                    name: 'opened count',
                    color: 'green',
                    data: {!! $opened_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },

                {
                    name: 'form submited count',
                    color: 'red',
                    data: {!! $submited_count->toJson(JSON_UNESCAPED_UNICODE) !!}

                },

                {
                    name: 'file downloaded count',
                    color: 'yellow',
                    data: {!! $downloaded_count->toJson(JSON_UNESCAPED_UNICODE) !!}

                },
            ]
        })

        // #-2 Campaign chart
        Highcharts.chart('campaign-chart-container', {
            chart: {
                type: 'column'
            },
            title: {
                text: ' Campaign Mails And Employee Statistic',
                style: {
                    marginBottom: '120px',
                }
            },
            xAxis: {
                categories: {!! $campaig_labels->toJson(JSON_UNESCAPED_UNICODE) !!},
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Campaign Mails And Employee Statistic'
                },
                stackLabels: {
                    enabled: true,
                    style: {
                        fontWeight: 'bold',
                        color: ( // theme
                            Highcharts.defaultOptions.title.style &&
                            Highcharts.defaultOptions.title.style.color
                        ) || 'gray'
                    }
                }
            },
            legend: {
                align: 'right',
                x: -30,
                verticalAlign: 'top',
                y: 25,
                floating: true,
                backgroundColor: Highcharts.defaultOptions.legend.backgroundColor || 'white',
                borderColor: '#CCC',
                borderWidth: 1,
                shadow: false
            },
            tooltip: {
                headerFormat: '<b>{point.x}</b>',
                pointFormat: ': {point.stackTotal}'
            },
            plotOptions: {
                column: {
                    stacking: null,
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            series: [
                {
                    name: 'Deliverd email',
                    color: '#33bcbc',
                    data: {!! $deliverd_email_templates_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },

                {
                    name: 'Deliverd employees',
                    color: '#0dcaf0',
                    data: {!! $deliverd_employees_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },

                {
                    name: 'Not Deliverd email',
                    color: '#6c757d',
                    data: {!! $not_deliverd_email_templates_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },

                {
                    name: 'Not Deliverd employees',
                    color: '#9560dd',
                    data: {!! $not_deliverd_employees_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },
            ]
        })

        // #-3 Groups chart
        Highcharts.chart('groups-chart-container', {
            chart: {
                type: 'column'
            },
            title: {
                text: 'Groups Statistic',
                style: {
                    marginBottom: '120px',
                }
            },
            xAxis: {
                categories: {!! $phish_groups_labels->toJson(JSON_UNESCAPED_UNICODE) !!},
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Groups Statistic'
                },
                stackLabels: {
                    enabled: true,
                    style: {
                        fontWeight: 'bold',
                        color: ( // theme
                            Highcharts.defaultOptions.title.style &&
                            Highcharts.defaultOptions.title.style.color
                        ) || 'gray'
                    }
                }
            },
            legend: {
                align: 'right',
                x: -30,
                verticalAlign: 'top',
                y: 25,
                floating: true,
                backgroundColor: Highcharts.defaultOptions.legend.backgroundColor || 'white',
                borderColor: '#CCC',
                borderWidth: 1,
                shadow: false
            },
            tooltip: {
                headerFormat: '<b>{point.x}</b>',
                pointFormat: ': {point.stackTotal}'
            },
            plotOptions: {
                column: {
                    stacking: null,
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            series: [
                {
                    name: 'Employee',
                    color: '#33bcbc',
                    data: {!! $phish_groups_employee_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },

                {
                    name: 'Campaigns',
                    color: '#0dcaf0',
                    data: {!! $phish_groups_campaign_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },

                {
                    name: 'Deliverd email',
                    color: '#6c757d',
                    data: {!! $phish_groups_deliverd_email_templates_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },

                {
                    name: 'Deliverd employees',
                    color: '#9560dd',
                    data: {!! $phish_groups_deliverd_employees_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },

                {
                    name: 'Not Deliverd email',
                    color: 'orange',
                    data: {!! $phish_groups_not_deliverd_email_templates_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },

                {
                    name: 'Not Deliverd employees',
                    color: 'yellow',
                    data: {!! $phish_groups_not_deliverd_employees_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },

                {
                    name: 'Mail opened',
                    color: 'pink',
                    data: {!! $phish_groups_opened_mails_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },


                {
                    name: 'Form submited',
                    color: 'red',
                    data: {!! $phish_groups_submited_data_in_mails_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },
                {
                    name: 'File download',
                    color: 'brown',
                    data: {!! $phish_groups_downloaded_file_in_mails_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },
            ]
        })

        // #-4 Employees chart
        Highcharts.chart('employees-chart-container', {
            chart: {
                type: 'column'
            },
            title: {
                text: 'Employees Statistic',
                style: {
                    marginBottom: '120px',
                }
            },
            xAxis: {
                categories: {!! $employees_labels->toJson(JSON_UNESCAPED_UNICODE) !!},
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Employees Statistic'
                },
                stackLabels: {
                    enabled: true,
                    style: {
                        fontWeight: 'bold',
                        color: ( // theme
                            Highcharts.defaultOptions.title.style &&
                            Highcharts.defaultOptions.title.style.color
                        ) || 'gray'
                    }
                }
            },
            legend: {
                align: 'right',
                x: -30,
                verticalAlign: 'top',
                y: 25,
                floating: true,
                backgroundColor: Highcharts.defaultOptions.legend.backgroundColor || 'white',
                borderColor: '#CCC',
                borderWidth: 1,
                shadow: false
            },
            tooltip: {
                headerFormat: '<b>{point.x}</b>',
                pointFormat: ': {point.stackTotal}'
            },
            plotOptions: {
                column: {
                    stacking: null,
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            series: [
                {
                    name: 'Campaigns',
                    color: '#0dcaf0',
                    data: {!! $employees_campaigns_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },

                {
                    name: 'Mail opened',
                    color: 'pink',
                    data: {!! $employee_opened_mails_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },

                {
                    name: 'Form submited',
                    color: 'red',
                    data: {!! $employee_submited_data_in_mails_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },
                {
                    name: 'File download',
                    color: 'brown',
                    data: {!! $employee_downloaded_file_in_mails_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },
            ]
        })

        // ************************************* Training charts *************************************
        Highcharts.chart('training-chart-container', {
            chart: {
                type: 'column'
            },
            title: {
                text: 'Training Employee Statistic'
            },
            xAxis: {
                categories: {!! $training_labels->toJson(JSON_UNESCAPED_UNICODE) !!},
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Training Employee Statistic'
                },
                stackLabels: {
                    enabled: true,
                    style: {
                        fontWeight: 'bold',
                        color: ( // theme
                            Highcharts.defaultOptions.title.style &&
                            Highcharts.defaultOptions.title.style.color
                        ) || 'gray'
                    }
                }
            },
            legend: {
                align: 'right',
                x: -30,
                verticalAlign: 'top',
                y: 25,
                floating: true,
                backgroundColor: Highcharts.defaultOptions.legend.backgroundColor || 'white',
                borderColor: '#CCC',
                borderWidth: 1,
                shadow: false
            },
            tooltip: {
                headerFormat: '<b>{point.x}</b>',
                pointFormat: ': {point.stackTotal}'
            },
            plotOptions: {
                column: {
                    stacking: null,
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            series: [

                {
                    name: 'Training Employee Delivered',
                    color: 'blue',
                    data: {!! $training_total_recieved_users->toJson(JSON_UNESCAPED_UNICODE) !!}
                },

                {
                    name: '{{ __('phishing.Training_Passed_Employee') }}',
                    color: 'green',
                    data: {!! $training_total_passed_users->toJson(JSON_UNESCAPED_UNICODE) !!}
                },

                {
                    name: '{{ __('phishing.Training_Failed_Employee') }}',
                    color: 'black',
                    data: {!! $training_total_failed_users->toJson(JSON_UNESCAPED_UNICODE) !!}
                },

                {
                    name: '{{ __('phishing.Training_Over_Due_Employee') }}',
                    color: 'red',
                    data: {!! $training_total_overdue_users->toJson(JSON_UNESCAPED_UNICODE) !!}

                },
            ]
        })

        // ************************************* CISO Training Chart *************************************
        @if(isset($cisoGroupStats) && $cisoGroupStats->count() > 0)
        Highcharts.chart('ciso-training-campaigns-chart', {
            chart: {
                type: 'column'
            },
            title: {
                text: '{{ __('phishing.Training_Campaigns_By_Group') }}'
            },
            xAxis: {
                categories: {!! json_encode($cisoGroupStats->pluck('group_name')->toArray(), JSON_UNESCAPED_UNICODE) !!}
            },
            yAxis: {
                min: 0,
                title: {
                    text: '{{ __('phishing.Count') }}'
                }
            },
            legend: {
                enabled: true
            },
            tooltip: {
                shared: true
            },
            plotOptions: {
                column: {
                    stacking: null,
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            series: [
                {
                    name: '{{ __('phishing.Total_Training_Campaigns') }}',
                    data: {!! json_encode($cisoGroupStats->pluck('total_campaigns')->toArray(), JSON_UNESCAPED_UNICODE) !!}
                },
                {
                    name: '{{ __('phishing.Total_Assigned') }}',
                    data: {!! json_encode($cisoGroupStats->pluck('total_assigned')->toArray(), JSON_UNESCAPED_UNICODE) !!}
                },
                {
                    name: '{{ __('phishing.Total_Passed') }}',
                    data: {!! json_encode($cisoGroupStats->pluck('total_passed')->toArray(), JSON_UNESCAPED_UNICODE) !!}
                }
            ]
        });
        @endif
    });


    // ************************************* Phishing Modal *************************************
    function openCampaignEmployees(id){
        console.log('campaign id is ' + id)
        getCampaignEmployeesDataTable(id);
        var modal = $('#campaign-employees-data-modal');
        modal.modal('show');
        // Prevent page scroll
        $('body').addClass('modal-open');
        $('body').css('overflow', 'hidden');
        $('body').css('padding-right', '0');
    }

    function getCampaignEmployeesDataTable(campaign_id) {
        if ($.fn.DataTable.isDataTable('.employee-dt-advanced-server-search')) {
            $('.employee-dt-advanced-server-search').DataTable().destroy();
        }

        var table = $('.employee-dt-advanced-server-search').DataTable({
            "language": {
                buttons: {
                    excelHtml5: "Excel",
                    print: "Print",
                    pageLength: "Show",
                    // csvHtml5: "csvHtml5",
                    //pdfHtml5: "pdfHtml5",
                }
            },
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "الكل"]
            ],
            dom: 'Bfrtip',
            buttons: [
                'excelHtml5',
                // 'csvHtml5',
                //'pdfHtml5',
                'print',
                'pageLength'
            ],
            lengthChange: true,
            processing: true,
            serverSide: true,
            ajax: {
                url: "{{ route('admin.phishing.campaign.getCampaignData', ':id') }}".replace(':id', campaign_id),
            },
            columns: [
                { name: "id", data: "id", sortable: false, searchable: false, orderable: false },
                { name: "name", data: "name" },
                { name: "email", data: "email", searchable: true },
                { name: "delivered", data: "delivered", searchable: true },
                { name: "count_of_opened", data: "count_of_opened", searchable: true },
                { name: "count_of_submited", data: "count_of_submited", searchable: true },
                { name: "count_of_downloaded", data: "count_of_downloaded", searchable: true },
                { name: "actions", data: "actions", searchable: false }
            ],
            "initComplete": function (settings, json) {
                table.buttons().container().appendTo('#dt-btns-employee');
                $('.buttons-excel, .buttons-print, .buttons-collection').addClass('no-transition custom-btn');
                $('.tableAdminOption span, button.dt-button').tooltip();
            }
        });
    }


    // ************************************* Training Modal *************************************
    function openTrainingEmployees(id){
        console.log('campaign id is ' + id)
        getTrainingEmployeesDataTable(id);
        var modal = $('#training-employees-data-modal');
        modal.modal('show');
        // Prevent page scroll
        $('body').addClass('modal-open');
        $('body').css('overflow', 'hidden');
        $('body').css('padding-right', '0');
    }

    function getTrainingEmployeesDataTable(campaign_id) {
        if ($.fn.DataTable.isDataTable('.training-employee-dt-advanced-server-search')) {
            $('.training-employee-dt-advanced-server-search').DataTable().destroy();
        }

        var table = $('.training-employee-dt-advanced-server-search').DataTable({
            "language": {
                buttons: {
                    excelHtml5: "Excel",
                    print: "Print",
                    pageLength: "Show",
                    // csvHtml5: "csvHtml5",
                    //pdfHtml5: "pdfHtml5",
                }
            },
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "الكل"]
            ],
            dom: 'Bfrtip',
            buttons: [
                'excelHtml5',
                // 'csvHtml5',
                //'pdfHtml5',
                'print',
                'pageLength'
            ],
            lengthChange: true,
            processing: true,
            serverSide: true,
            ajax: {
                url: "{{ route('admin.phishing.campaign.getEmployeeOfTrainingCampaign', ':id') }}".replace(':id', campaign_id),
            },
            columns: [

                { name: "user_email", data: "user_email",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "user_name", data: "user_name",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "training_name", data: "training_name",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "date_assigned", data: "date_assigned", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "days_until_due", data: "days_until_due", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "score", data: "score", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "passed", data: "passed", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "failed", data: "failed", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "passed_after_overdue", data: "passed_after_overdue", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "overdue", data: "overdue", sortable: true, searchable: true, orderable: true,className: "text-center"},


            ],
            "initComplete": function (settings, json) {
                table.buttons().container().appendTo('#dt-btns-training-employee');
                $('.buttons-excel, .buttons-print, .buttons-collection').addClass('no-transition custom-btn');
                $('.tableAdminOption span, button.dt-button').tooltip();
            }
        });
    }


    // ************************************* Employee Details Modal *************************************
    function openDetailsForEmployee(id){
        console.log('employee id is ' + id)
        getDetailsEmployeeDataTable(id);
        var modal = $('#details-employees-data-modal');
        modal.modal('show');
        // Prevent page scroll
        $('body').addClass('modal-open');
        $('body').css('overflow', 'hidden');
        $('body').css('padding-right', '0');
    }
    
    // Prevent page scroll when modal closes
    $(document).on('hidden.bs.modal', '.modal', function () {
        $('body').removeClass('modal-open');
        $('body').css('overflow', '');
        $('body').css('padding-right', '');
    });

    function getDetailsEmployeeDataTable(employee_id) {
        if ($.fn.DataTable.isDataTable('.employee-details-phishing-dt-advanced-server-search')) {
            $('.employee-details-phishing-dt-advanced-server-search').DataTable().destroy();
        }

        if ($.fn.DataTable.isDataTable('.employee-details-training-dt-advanced-server-search')) {
            $('.employee-details-training-dt-advanced-server-search').DataTable().destroy();
        }

        // Phishing
        var employeePhishingTable = $('.employee-details-phishing-dt-advanced-server-search').DataTable({
            "language": {
                buttons: {
                    excelHtml5: "Excel",
                    print: "Print",
                    pageLength: "Show",
                    //pdfHtml5: "pdfHtml5",
                }
            },
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "الكل"]
            ],
            dom: 'Bfrtip',
            buttons: [
                'excelHtml5',
                // 'csvHtml5',
                //'pdfHtml5',
                'print',
                'pageLength'
            ],
            lengthChange: true,
            processing: true,
            serverSide: true,
            ajax: {
                url: "{{ route('admin.phishing.campaign.getEmployeePhishingDataTable',':id') }}".replace(':id',employee_id),
            },
            columns: [
                { name: "campaign_name", data: "campaign_name",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "template_name", data: "template_name", sortable: true, searchable: true, orderable: true,className: "text-center"},

                { name: "is_opened", data: "is_opened", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "is_link_clicked", data: "is_link_clicked", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "is_file_downloaded", data: "is_file_downloaded", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "is_data_submitted", data: "is_data_submitted", sortable: true, searchable: true, orderable: true,className: "text-center"},
            ],
            "initComplete": function (settings, json) {
                employeePhishingTable.buttons().container().appendTo('#dt-btns-employee-details-phishing');
                $('.buttons-excel, .buttons-print, .buttons-collection').addClass('no-transition custom-btn');
                $('.tableAdminOption span, button.dt-button').tooltip();
            }
        });

        // Training
        var employeeTrainingTable = $('.employee-details-training-dt-advanced-server-search').DataTable({
            "language": {
                buttons: {
                    excelHtml5: "Excel",
                    print: "Print",
                    pageLength: "Show",
                    //pdfHtml5: "pdfHtml5",
                }
            },
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "الكل"]
            ],
            dom: 'Bfrtip',
            buttons: [
                'excelHtml5',
                // 'csvHtml5',
                //'pdfHtml5',
                'print',
                'pageLength'
            ],
            lengthChange: true,
            processing: true,
            serverSide: true,
            ajax: {
                url: "{{ route('admin.phishing.campaign.getEmployeeTrainingCampaignData',':id') }}".replace(':id',employee_id),
            },
            columns: [
                { name: "campaign_name", data: "campaign_name",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "training_name", data: "training_name", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "score", data: "score", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "completed", data: "completed", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "overdue", data: "overdue", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "passed", data: "passed", sortable: true, searchable: true, orderable: true,className: "text-center"},
            ],
            "initComplete": function (settings, json) {
                employeeTrainingTable.buttons().container().appendTo('#dt-btns-employee-details-training');
                $('.buttons-excel, .buttons-print, .buttons-collection').addClass('no-transition custom-btn');
                $('.tableAdminOption span, button.dt-button').tooltip();
            }
        });


    }




    $(document).ready(function(){

        // ************************************* Phishing Data Tables *************************************
        var activePhishingTable = $('.active-phishing-dt-advanced-server-search').DataTable({
            "language": {
                buttons: {
                    excelHtml5: "Excel",
                    print: "Print",
                    pageLength: "Show",
                    //pdfHtml5: "pdfHtml5",
                }
            },
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "الكل"]
            ],
            dom: 'Bfrtip',
            buttons: [
                'excelHtml5',
                // 'csvHtml5',
                //'pdfHtml5',
                'print',
                'pageLength'
            ],
            lengthChange: true,
            processing: true,
            serverSide: true,
            ajax: {
                url: "{{ route('admin.phishing.campaign.getActivePhishingDataTable') }}",
                data: function (d) {
                    d.start_date = $('#start_date').val();
                    d.end_date = $('#end_date').val();
                }
            },
            columns: [
                { name: "id", data: "id", sortable: false, searchable: false, orderable: false,className: "text-center"},
                { name: "campaign_name", data: "campaign_name",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "status", data: "status", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "campaign_type", data: "campaign_type", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "schedule_date", data: "schedule_date", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "deliverd_email_templates_count", data: "deliverd_email_templates_count", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "opend_count", data: "opend_count", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "downloaded_count", data: "downloaded_count", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "submited_count", data: "submited_count", sortable: true, searchable: true, orderable: true,className: "text-center"},
            ],
            "initComplete": function (settings, json) {
                activePhishingTable.buttons().container().appendTo('#dt-btns-active-phishing');
                $('.buttons-excel, .buttons-print, .buttons-collection').addClass('no-transition custom-btn');
                $('.tableAdminOption span, button.dt-button').tooltip();
            }
        });

        $('.active-phishing-dt-advanced-server-search tbody').on('click', 'tr', function () {
            var data = activePhishingTable.row(this).data();
            if (data) {
                openCampaignEmployees(data.id);
            }
        });

        var archivedPhishingTable = $('.archived-phishing-dt-advanced-server-search').DataTable({
            "language": {
                buttons: {
                    excelHtml5: "Excel",
                    print: "Print",
                    pageLength: "Show",
                    //pdfHtml5: "pdfHtml5",
                }
            },
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "الكل"]
            ],
            dom: 'Bfrtip',
            buttons: [
                'excelHtml5',
                // 'csvHtml5',
                //'pdfHtml5',
                'print',
                'pageLength'
            ],
            lengthChange: true,
            processing: true,
            serverSide: true,
            ajax: {
                url: "{{ route('admin.phishing.campaign.getArchivedPhishingDataTable') }}",
                data: function (d) {
                    d.start_date = $('#start_date').val();
                    d.end_date = $('#end_date').val();
                }
            },
            columns: [
                { name: "id", data: "id", sortable: false, searchable: false, orderable: false,className: "text-center"},
                { name: "campaign_name", data: "campaign_name",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "status", data: "status", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "campaign_type", data: "campaign_type", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "schedule_date", data: "schedule_date", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "deliverd_email_templates_count", data: "deliverd_email_templates_count", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "opend_count", data: "opend_count", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "downloaded_count", data: "downloaded_count", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "submited_count", data: "submited_count", sortable: true, searchable: true, orderable: true,className: "text-center"},
            ],
            "initComplete": function (settings, json) {
                archivedPhishingTable.buttons().container().appendTo('#dt-btns-archived-phishing');
                $('.buttons-excel, .buttons-print, .buttons-collection').addClass('no-transition custom-btn');
                $('.tableAdminOption span, button.dt-button').tooltip();
            }
        });

        $('.archived-phishing-dt-advanced-server-search tbody').on('click', 'tr', function () {
            var data = archivedPhishingTable.row(this).data();
            if (data) {
                openCampaignEmployees(data.id);
            }
        });


        // ************************************* Training Data Tables *************************************
        var activeTable = $('.active-training-dt-advanced-server-search').DataTable({
            "language": {
                buttons: {
                    excelHtml5: "Excel",
                    print: "Print",
                    pageLength: "Show",
                    //pdfHtml5: "pdfHtml5",
                }
            },
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "الكل"]
            ],
            dom: 'Bfrtip',
            buttons: [
                'excelHtml5',
                // 'csvHtml5',
                //'pdfHtml5',
                'print',
                'pageLength'
            ],
            lengthChange: true,
            processing: true,
            serverSide: true,
            ajax: {
                url: "{{ route('admin.phishing.campaign.getActiveTrainingCampaignData') }}",
                data: function (d) {
                    d.start_date = $('#start_date').val();
                    d.end_date = $('#end_date').val();
                }
            },
            columns: [
                { name: "id", data: "id", sortable: false, searchable: false, orderable: false,className: "text-center"},
                { name: "campaign_name", data: "campaign_name",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "status", data: "status", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "campaign_type", data: "campaign_type", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "schedule_date", data: "schedule_date", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "employee_count", data: "employee_count", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "assigned", data: "assigned", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "passed", data: "passed", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "failed", data: "failed", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "passed_after_overdue", data: "passed_after_overdue", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "overdue", data: "overdue", sortable: true, searchable: true, orderable: true,className: "text-center"},
            ],
            "initComplete": function (settings, json) {
                activeTable.buttons().container().appendTo('#dt-btns-active-training');
                $('.buttons-excel, .buttons-print, .buttons-collection').addClass('no-transition custom-btn');
                $('.tableAdminOption span, button.dt-button').tooltip();
            }
        });

        $('.active-training-dt-advanced-server-search tbody').on('click', 'tr', function () {
            var data = activeTable.row(this).data();
            if (data) {
                openTrainingEmployees(data.id);
            }
        });

        var archivedTable = $('.archived-training-dt-advanced-server-search').DataTable({
            "language": {
                buttons: {
                    excelHtml5: "Excel",
                    print: "Print",
                    pageLength: "Show",
                    //pdfHtml5: "pdfHtml5",
                }
            },
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "الكل"]
            ],
            dom: 'Bfrtip',
            buttons: [
                'excelHtml5',
                // 'csvHtml5',
                //'pdfHtml5',
                'print',
                'pageLength'
            ],
            lengthChange: true,
            processing: true,
            serverSide: true,
            ajax: {
                url: "{{ route('admin.phishing.campaign.getArchivedTrainingCampaignData') }}",
                data: function (d) {
                    d.start_date = $('#start_date').val();
                    d.end_date = $('#end_date').val();
                }
            },
            columns: [
                { name: "id", data: "id", sortable: false, searchable: false, orderable: false,className: "text-center"},
                { name: "campaign_name", data: "campaign_name",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "status", data: "status",sortable: true, searchable: true, orderable: true,className: "text-center" },
                { name: "campaign_type", data: "campaign_type",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "schedule_date", data: "schedule_date",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "employee_count", data: "employee_count",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "assigned", data: "assigned",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "passed", data: "passed",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "failed", data: "failed",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "passed_after_overdue", data: "passed_after_overdue",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "overdue", data: "overdue",sortable: true, searchable: true, orderable: true,className: "text-center"},
            ],
            "initComplete": function (settings, json) {
                archivedTable.buttons().container().appendTo('#dt-btns-archived-training');
                $('.buttons-excel, .buttons-print, .buttons-collection').addClass('no-transition custom-btn');
                $('.tableAdminOption span, button.dt-button').tooltip();
            }
        });

        $('.archived-training-dt-advanced-server-search tbody').on('click', 'tr', function () {
            var data = archivedTable.row(this).data();
            if (data) {
                openTrainingEmployees(data.id);
            }
        });

        // ************************************* Employee Statistics Data Tables *************************************
        var employeeStatisticTable = $('.employee-statistics-dt-advanced-server-search').DataTable({
            "language": {
                buttons: {
                    excelHtml5: "Excel",
                    print: "Print",
                    pageLength: "Show",
                    //pdfHtml5: "pdfHtml5",
                }
            },
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "الكل"]
            ],
            dom: 'Bfrtip',
            buttons: [
                'excelHtml5',
                // 'csvHtml5',
                //'pdfHtml5',
                'print',
                'pageLength'
            ],
            lengthChange: true,
            processing: true,
            serverSide: true,
            ajax: {
                url: "{{ route('admin.phishing.campaign.getTrainingEmployee') }}",
                data: function (d) {
                    d.start_date = $('#start_date').val();
                    d.end_date = $('#end_date').val();
                }
            },
            columns: [
                { name: "id", data: "user_id", searchable: true,className:'text-center' },
                { name: "email", data: "email", searchable: true,className:'text-center' },
                { name: "name", data: "name",searchable: true,className:'text-center' },
                // { name: "average_percentage", data: "average_percentage",searchable: true,className:'text-center'},
            ],
            "initComplete": function (settings, json) {
                employeeStatisticTable.buttons().container().appendTo('#dt-btns-employee-statistics');
                $('.buttons-excel, .buttons-print, .buttons-collection').addClass('no-transition custom-btn');
                $('.tableAdminOption span, button.dt-button').tooltip();
            }
        });

        $('.employee-statistics-dt-advanced-server-search tbody').on('click', 'tr', function () {
            var data = employeeStatisticTable.row(this).data();
            if (data) {
                openDetailsForEmployee(data.user_id);
            }
        });

        // Date filter form submission handler
        $('#date-filter-form').on('submit', function(e) {
            e.preventDefault();
            // Reload all DataTables with new filter parameters
            setTimeout(function() {
                if ($.fn.DataTable.isDataTable('.active-phishing-dt-advanced-server-search')) {
                    $('.active-phishing-dt-advanced-server-search').DataTable().ajax.reload(null, false);
                }
                if ($.fn.DataTable.isDataTable('.archived-phishing-dt-advanced-server-search')) {
                    $('.archived-phishing-dt-advanced-server-search').DataTable().ajax.reload(null, false);
                }
                if ($.fn.DataTable.isDataTable('.active-training-dt-advanced-server-search')) {
                    $('.active-training-dt-advanced-server-search').DataTable().ajax.reload(null, false);
                }
                if ($.fn.DataTable.isDataTable('.archived-training-dt-advanced-server-search')) {
                    $('.archived-training-dt-advanced-server-search').DataTable().ajax.reload(null, false);
                }
                if ($.fn.DataTable.isDataTable('.employee-statistics-dt-advanced-server-search')) {
                    $('.employee-statistics-dt-advanced-server-search').DataTable().ajax.reload(null, false);
                }
            }, 500);
        });

    })

</script>
@endsection
