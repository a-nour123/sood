@extends('admin/layouts/contentLayoutMaster')

@section('title', __('phishing.CISO_Training_Report'))

@section('vendor-style')
@endsection

@section('page-style')
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .page-wrapper.compact-small .page-body-wrapper .page-body {
            margin-left: 0 !important;
        }
        .page-wrapper .page-body-wrapper .page-body {
            padding: 0 !important;
        }
        .highcharts-credits {
            display: none;
        }
        .card {
            border-radius: 10px;
            transition: all 0.3s ease;
        }
        .card:hover {
            box-shadow: 0 5px 15px rgba(0,0,0,0.1) !important;
        }
        .widget-1 {
            transition: all 0.3s ease;
        }
        .widget-1:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.15) !important;
        }
        .table tbody tr {
            transition: all 0.2s ease;
        }
        .table tbody tr:hover {
            background-color: #f8f9fa;
        }
        .progress {
            border-radius: 10px;
        }
    </style>
@endsection

@section('content')
    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">
            <div class="row breadcrumbs-top widget-grid">
                <div class="col-12">
                    <div class="page-title mt-2">
                        <div class="row">
                            <div class="col-sm-12 ps-0">
                                @if (@isset($breadcrumbs))
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}" style="display: flex;">
                                            <svg class="stroke-icon">
                                                <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}"></use>
                                            </svg></a></li>
                                        @foreach ($breadcrumbs as $breadcrumb)
                                            <li class="breadcrumb-item">
                                                @if (isset($breadcrumb['link']))
                                                    <a href="{{ $breadcrumb['link'] == 'javascript:void(0)' ? $breadcrumb['link'] : url($breadcrumb['link']) }}">
                                                @endif
                                                {{ $breadcrumb['name'] }}
                                                @if (isset($breadcrumb['link']))
                                                    </a>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ol>
                                @endisset
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="page-wrapper" id="pageWrapper">
        <div class="page-body-wrapper">
            <div class="page-body">
                <div class="container-fluid"></div>
                <div class="container-fluid dashboard_default">
                    <div class="row widget-grid">

                        {{-- Date Range Filter --}}
                        <div class="col-12 mb-3">
                            <div class="card">
                                <div class="card-body">
                                    <form method="GET" action="{{ route('admin.phishing.ciso.training-report') }}" id="date-filter-form" class="row g-3 align-items-end">
                                        <div class="col-md-3">
                                            <label for="start_date" class="form-label">{{ __('phishing.Start_Date') }}</label>
                                            <input type="date" name="start_date" id="start_date" class="form-control" 
                                                   value="{{ request('start_date', \Carbon\Carbon::now()->subYear()->format('Y-m-d')) }}">
                                        </div>
                                        <div class="col-md-3">
                                            <label for="end_date" class="form-label">{{ __('phishing.End_Date') }}</label>
                                            <input type="date" name="end_date" id="end_date" class="form-control" 
                                                   value="{{ request('end_date', \Carbon\Carbon::now()->format('Y-m-d')) }}">
                                        </div>
                                        <div class="col-md-3">
                                            <button type="submit" class="btn btn-primary">{{ __('phishing.Filter') }}</button>
                                            <a href="{{ route('admin.phishing.ciso.training-report') }}" class="btn btn-secondary">{{ __('phishing.Reset') }}</a>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        {{-- Summary Statistics --}}
                        <div class="row mb-4">
                            <div class="col-xl-3 col-md-6 mb-3">
                                <div class="card widget-1 border-0 shadow-sm">
                                    <div class="card-body">
                                        <div class="widget-content">
                                            <div class="widget-round primary">
                                                <div class="bg-round">
                                                    <i class="fa fa-users"></i>
                                                    <svg class="half-circle svg-fill">
                                                        <use href="{{ asset('fonts/icons/icon-sprite.svg#halfcircle') }}"></use>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div>
                                                <h4>{{ $groupStats->sum('total_employees') }}</h4>
                                                <span class="f-light">{{ __('phishing.Total_Employees') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6 mb-3">
                                <div class="card widget-1 border-0 shadow-sm">
                                    <div class="card-body">
                                        <div class="widget-content">
                                            <div class="widget-round success">
                                                <div class="bg-round">
                                                    <i class="fa fa-graduation-cap"></i>
                                                    <svg class="half-circle svg-fill">
                                                        <use href="{{ asset('fonts/icons/icon-sprite.svg#halfcircle') }}"></use>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div>
                                                <h4>{{ $groupStats->sum('total_campaigns') }}</h4>
                                                <span class="f-light">{{ __('phishing.Total_Training_Campaigns') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6 mb-3">
                                <div class="card widget-1 border-0 shadow-sm">
                                    <div class="card-body">
                                        <div class="widget-content">
                                            <div class="widget-round warning">
                                                <div class="bg-round">
                                                    <i class="fa fa-user-check"></i>
                                                    <svg class="half-circle svg-fill">
                                                        <use href="{{ asset('fonts/icons/icon-sprite.svg#halfcircle') }}"></use>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div>
                                                <h4>{{ $groupStats->sum('total_assigned') }}</h4>
                                                <span class="f-light">{{ __('phishing.Total_Assigned') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6 mb-3">
                                <div class="card widget-1 border-0 shadow-sm">
                                    <div class="card-body">
                                        <div class="widget-content">
                                            <div class="widget-round info">
                                                <div class="bg-round">
                                                    <i class="fa fa-check-circle"></i>
                                                    <svg class="half-circle svg-fill">
                                                        <use href="{{ asset('fonts/icons/icon-sprite.svg#halfcircle') }}"></use>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div>
                                                <h4>{{ $groupStats->sum('total_passed') }}</h4>
                                                <span class="f-light">{{ __('phishing.Total_Passed') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- Training Campaigns by Group Table --}}
                        <div class="col-12 mb-4">
                            <div class="card border-0 shadow-sm">
                                <div class="card-header bg-white border-bottom pb-3">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <h4 class="mb-0">
                                            <i class="fa fa-table me-2 text-primary"></i>
                                            {{ __('phishing.Training_Campaigns_By_Group') }}
                                        </h4>
                                        <span class="badge bg-primary">{{ $groupStats->count() }}</span>
                                    </div>
                                </div>
                                <div class="card-body p-0">
                                    <div class="table-responsive">
                                        <table class="table table-hover mb-0">
                                            <thead class="table-light">
                                                <tr>
                                                    <th class="text-center">{{ __('phishing.Name') }}</th>
                                                    <th class="text-center">{{ __('phishing.Total_Employees') }}</th>
                                                    <th class="text-center">{{ __('phishing.Total_Training_Campaigns') }}</th>
                                                    <th class="text-center">{{ __('phishing.Total_Assigned') }}</th>
                                                    <th class="text-center">{{ __('phishing.Total_Passed') }}</th>
                                                    <th class="text-center">{{ __('phishing.Attendance_Rate') }}</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @forelse($groupStats as $stat)
                                                    <tr>
                                                        <td class="text-center fw-bold">{{ $stat['group_name'] }}</td>
                                                        <td class="text-center">{{ $stat['total_employees'] }}</td>
                                                        <td class="text-center">
                                                            <span class="badge bg-info">{{ $stat['total_campaigns'] }}</span>
                                                        </td>
                                                        <td class="text-center">
                                                            <span class="badge bg-warning">{{ $stat['total_assigned'] }}</span>
                                                        </td>
                                                        <td class="text-center">
                                                            <span class="badge bg-success">{{ $stat['total_passed'] }}</span>
                                                        </td>
                                                        <td class="text-center">
                                                            <div class="d-flex align-items-center justify-content-center">
                                                                <span class="badge {{ $stat['attendance_rate'] >= 70 ? 'bg-success' : ($stat['attendance_rate'] >= 50 ? 'bg-warning' : 'bg-danger') }} me-2">
                                                                    {{ $stat['attendance_rate'] }}%
                                                                </span>
                                                                <div class="progress" style="width: 100px; height: 8px;">
                                                                    <div class="progress-bar {{ $stat['attendance_rate'] >= 70 ? 'bg-success' : ($stat['attendance_rate'] >= 50 ? 'bg-warning' : 'bg-danger') }}" 
                                                                         role="progressbar" 
                                                                         style="width: {{ $stat['attendance_rate'] }}%"
                                                                         aria-valuenow="{{ $stat['attendance_rate'] }}" 
                                                                         aria-valuemin="0" 
                                                                         aria-valuemax="100"></div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                @empty
                                                    <tr>
                                                        <td colspan="6" class="text-center py-4">
                                                            <i class="fa fa-inbox fa-3x text-muted mb-2"></i>
                                                            <p class="text-muted">{{ __('locale.NoDataAvailable') }}</p>
                                                        </td>
                                                    </tr>
                                                @endforelse
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- Chart Visualization --}}
                        @if($groupStats->count() > 0)
                        <div class="col-12">
                            <div class="card border-0 shadow-sm">
                                <div class="card-header bg-white border-bottom pb-3">
                                    <h4 class="mb-0">
                                        <i class="fa fa-chart-bar me-2 text-success"></i>
                                        {{ __('phishing.Training_Campaigns_By_Group') }}
                                    </h4>
                                </div>
                                <div class="card-body p-4">
                                    <div id="training-campaigns-chart" style="min-height: 400px;"></div>
                                </div>
                            </div>
                        </div>
                        @endif

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('vendor-script')
@endsection

@section('page-script')
    <script src="{{ asset('js/scripts/config.js') }}"></script>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="https://code.highcharts.com/modules/export-data.js"></script>
    
    @if($groupStats->count() > 0)
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            Highcharts.chart('training-campaigns-chart', {
                chart: {
                    type: 'column'
                },
                title: {
                    text: '{{ __('phishing.Training_Campaigns_By_Group') }}'
                },
                xAxis: {
                    categories: {!! json_encode($groupStats->pluck('group_name')->toArray(), JSON_UNESCAPED_UNICODE) !!}
                },
                yAxis: {
                    min: 0,
                    title: {
                        text: '{{ __('phishing.Count') }}'
                    }
                },
                legend: {
                    enabled: true
                },
                tooltip: {
                    shared: true
                },
                plotOptions: {
                    column: {
                        stacking: null,
                        dataLabels: {
                            enabled: true
                        }
                    }
                },
                series: [
                    {
                        name: '{{ __('phishing.Total_Training_Campaigns') }}',
                        data: {!! json_encode($groupStats->pluck('total_campaigns')->toArray(), JSON_UNESCAPED_UNICODE) !!}
                    },
                    {
                        name: '{{ __('phishing.Total_Assigned') }}',
                        data: {!! json_encode($groupStats->pluck('total_assigned')->toArray(), JSON_UNESCAPED_UNICODE) !!}
                    },
                    {
                        name: '{{ __('phishing.Total_Passed') }}',
                        data: {!! json_encode($groupStats->pluck('total_passed')->toArray(), JSON_UNESCAPED_UNICODE) !!}
                    }
                ]
            });
        });
    </script>
    @endif
@endsection
