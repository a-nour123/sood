@extends('admin/layouts/contentLayoutMaster')

@section('title', __('lms.Training Dashboard'))

@section('vendor-style')
<link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
<link rel="stylesheet" href="{{ asset(mix('vendors/css/charts/apexcharts.css')) }}">
<link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
@endsection

@section('page-style')
<link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
<style>
    .stats-card {
        border-radius: 10px;
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        transition: transform 0.3s ease;
    }

    .stats-card:hover {
        transform: translateY(-5px);
    }

    .stats-card .icon {
        font-size: 2.5rem;
        margin-bottom: 15px;
    }

    .stats-card h3 {
        font-size: 2rem;
        font-weight: bold;
        margin: 10px 0;
    }

    .stats-card p {
        color: #6c757d;
        margin: 0;
    }

    .training-item {
        border: 1px solid #e9ecef;
        border-radius: 8px;
        padding: 15px;
        margin-bottom: 15px;
        transition: all 0.3s ease;
    }

    .training-item:hover {
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    .progress-custom {
        height: 8px;
        border-radius: 4px;
    }

    .table-recent {
        font-size: 0.9rem;
    }

    .badge-status {
        padding: 5px 10px;
        border-radius: 15px;
        font-size: 0.85rem;
    }

    /* Custom Tabs Styling */
    .nav-tabs-custom {
        border-bottom: 2px solid #e9ecef;
        margin-bottom: 30px;
    }

    .nav-tabs-custom .nav-link {
        border: none;
        color: #6c757d;
        font-weight: 600;
        font-size: 1.1rem;
        padding: 15px 30px;
        border-bottom: 3px solid transparent;
        transition: all 0.3s ease;
    }

    .nav-tabs-custom .nav-link:hover {
        color: #7367f0;
        border-bottom-color: #7367f0;
    }

    .nav-tabs-custom .nav-link.active {
        color: #7367f0;
        border-bottom-color: #7367f0;
        background-color: transparent;
    }
</style>
@endsection

@section('content')

<!-- Breadcrumb -->
<div class="content-header row">
    <div class="content-header-left col-12 mb-2">
        <div class="row breadcrumbs-top">
            <div class="col-12">
                <div class="page-title mt-2">
                    <div class="row">
                        <div class="col-sm-6 ps-0">
                            @if(isset($breadcrumbs))
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="{{ route('admin.dashboard') }}" style="display: flex;">
                                        <svg class="stroke-icon">
                                            <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}"></use>
                                        </svg>
                                    </a>
                                </li>
                                @foreach($breadcrumbs as $breadcrumb)
                                <li class="breadcrumb-item">
                                    @if(isset($breadcrumb['link']))
                                    <a href="{{ $breadcrumb['link'] }}">
                                        @endif
                                        {{ $breadcrumb['name'] }}
                                        @if(isset($breadcrumb['link']))
                                    </a>
                                    @endif
                                </li>
                                @endforeach
                            </ol>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Tabs Navigation -->
<ul class="nav nav-tabs nav-tabs-custom my-5" id="trainingTabs" role="tablist">
    <li class="nav-item" role="presentation">
        <button class="nav-link active" id="public-tab" data-bs-toggle="tab" data-bs-target="#public-content" type="button" role="tab">
            <i class="fas fa-globe"></i> {{ __('lms.Public Trainings') }}
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" id="campaign-tab" data-bs-toggle="tab" data-bs-target="#campaign-content" type="button" role="tab">
            <i class="fas fa-bullhorn"></i> {{ __('lms.Campaign Trainings') }}
        </button>
    </li>
</ul>

<!-- Tabs Content -->
<div class="tab-content" id="trainingTabsContent">

    <!-- PUBLIC TRAININGS TAB -->
    <div class="tab-pane fade show active" id="public-content" role="tabpanel">

        <!-- Statistics Cards -->
        <section class="stats-section">
            <div class="row">
                <!-- Total Trainings -->
                <div class="col-xl-4 col-md-6">
                    <div class="stats-card bg-primary text-white">
                        <div class="icon">
                            <i class="fas fa-book"></i>
                        </div>
                        <h3 class="text-white">{{ $totalPublicTrainings }}</h3>
                        <p class="text-white">{{ __('lms.Total Public Trainings') }}</p>
                    </div>
                </div>

                <!-- Total Enrollments -->
                <div class="col-xl-4 col-md-6">
                    <div class="stats-card bg-info text-white">
                        <div class="icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <h3 class="text-white">{{ $totalPublicEnrollments }}</h3>
                        <p class="text-white">{{ __('lms.Total Enrollments') }}</p>
                    </div>
                </div>

                <!-- Completion Rate -->
                <div class="col-xl-4 col-md-6">
                    <div class="stats-card bg-success text-white">
                        <div class="icon">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <h3 class="text-white">{{ $publicCompletionRate }}%</h3>
                        <p class="text-white">{{ __('lms.Success Rate') }}</p>
                    </div>
                </div>
            </div>

            <!-- Secondary Stats -->
            <div class="row mt-3">
                <div class="col-xl-6 col-md-6">
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="fas fa-check text-success" style="font-size: 2rem;"></i>
                            <h4 class="mt-2">{{ $totalPublicCompleted }}</h4>
                            <p class="text-muted">{{ __('lms.Passed') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 col-md-6">
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="fas fa-times text-danger" style="font-size: 2rem;"></i>
                            <h4 class="mt-2">{{ $totalPublicFailed }}</h4>
                            <p class="text-muted">{{ __('lms.Failed') }}</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Charts Section -->
        <section class="charts-section mt-4">
            <div class="row">
                <!-- Monthly Trend Chart -->
                <div class="col-xl-8">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">{{ __('lms.Completion Trend (Last 12 Months)') }}</h4>
                        </div>
                        <div class="card-body">
                            <div id="public-monthly-trend-chart"></div>
                        </div>
                    </div>
                </div>

                <!-- Top Users -->
                <div class="col-xl-4">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">{{ __('lms.Top Performers') }}</h4>
                        </div>
                        <div class="card-body">
                            <div class="list-group">
                                @foreach($publicTopUsers as $user)
                                <div class="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong>{{ $user->name }}</strong>
                                        <br>
                                        <small class="text-muted">
                                            {{ $user->completed_trainings }} {{ __('lms.trainings') }} |
                                            {{ number_format($user->avg_score, 1) }}% {{ __('lms.avg score') }}
                                        </small>
                                    </div>
                                    <span class="badge bg-success">
                                        <i class="fas fa-trophy"></i>
                                    </span>
                                </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Training Modules by Course -->
        <section class="trainings-section mt-4">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">{{ __('lms.Trainings by Course') }}</h4>
                </div>
                <div class="card-body">
                    @foreach($publicTrainingsByCourse as $course)
                    <div class="training-item">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <h5 class="mb-0">
                                <i class="fas fa-book-open text-primary"></i> {{ $course->title }}
                            </h5>
                        </div>

                        <div class="row mt-3">
                            @foreach($course->levels as $level)
                            @foreach($level->training_modules as $module)
                            <div class="col-md-6 mb-3">
                                <div class="card">
                                    <div class="card-body">
                                        <h6>{{ $module->name }}</h6>
                                        <div class="d-flex justify-content-between mb-2">
                                            <small>{{ __('lms.Enrollments') }}: {{ $module->users_count }}</small>
                                            <small>{{ __('lms.Completed') }}: {{ $module->completed_users_count }}</small>
                                        </div>
                                        @php
                                        $moduleCompletionRate = $module->users_count > 0
                                        ? ($module->completed_users_count / $module->users_count) * 100
                                        : 0;
                                        @endphp
                                        <div class="progress progress-custom">
                                            <div class="progress-bar bg-success" role="progressbar"
                                                style="width: {{ $moduleCompletionRate }}%"
                                                aria-valuenow="{{ $moduleCompletionRate }}"
                                                aria-valuemin="0" aria-valuemax="100">
                                            </div>
                                        </div>
                                        <small class="text-muted">{{ number_format($moduleCompletionRate, 1) }}% {{ __('lms.complete') }}</small>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                            @endforeach
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </section>

        <!-- Recent Completions -->
        <section class="recent-section mt-4">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">{{ __('lms.Recent Completions (Last 30 Days)') }}</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-recent table-hover">
                            <thead>
                                <tr>
                                    <th>{{ __('lms.User') }}</th>
                                    <th>{{ __('lms.Training') }}</th>
                                    <th>{{ __('lms.Score') }}</th>
                                    <th>{{ __('lms.Status') }}</th>
                                    <th>{{ __('lms.Completed At') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($publicRecentCompletions as $completion)
                                <tr>
                                    <td>{{ $completion->user_name }}</td>
                                    <td>{{ $completion->training_name }}</td>
                                    <td>
                                        <strong>{{ number_format($completion->score, 2) }}%</strong>
                                    </td>
                                    <td>
                                        @if($completion->passed)
                                        <span class="badge badge-status bg-success">
                                            <i class="fas fa-check"></i> {{ __('lms.Passed') }}
                                        </span>
                                        @else
                                        <span class="badge badge-status bg-danger">
                                            <i class="fas fa-times"></i> {{ __('lms.Failed') }}
                                        </span>
                                        @endif
                                    </td>
                                    <td>{{ \Carbon\Carbon::parse($completion->completed_at)->format('Y-m-d H:i') }}</td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>

        <!-- Average Scores -->
        <section class="scores-section mt-4">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">{{ __('lms.Average Scores by Training') }}</h4>
                </div>
                <div class="card-body">
                    <div id="public-average-scores-chart"></div>
                </div>
            </div>
        </section>

    </div>

    <!-- CAMPAIGN TRAININGS TAB -->
    <div class="tab-pane fade" id="campaign-content" role="tabpanel">

        <!-- Statistics Cards -->
        <section class="stats-section">
            <div class="row">
                <!-- Total Trainings -->
                <div class="col-xl-4 col-md-6">
                    <div class="stats-card bg-primary text-white">
                        <div class="icon">
                            <i class="fas fa-bullhorn"></i>
                        </div>
                        <h3 class="text-white">{{ $totalCampaignTrainings }}</h3>
                        <p class="text-white">{{ __('lms.Total Campaign Trainings') }}</p>
                    </div>
                </div>

                <!-- Total Enrollments -->
                <div class="col-xl-4 col-md-6">
                    <div class="stats-card bg-info text-white">
                        <div class="icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <h3 class="text-white">{{ $totalCampaignEnrollments }}</h3>
                        <p class="text-white">{{ __('lms.Total Enrollments') }}</p>
                    </div>
                </div>

                <!-- Completion Rate -->
                <div class="col-xl-4 col-md-6">
                    <div class="stats-card bg-success text-white">
                        <div class="icon">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <h3 class="text-white">{{ $campaignCompletionRate }}%</h3>
                        <p class="text-white">{{ __('lms.Success Rate') }}</p>
                    </div>
                </div>
            </div>

            <!-- Secondary Stats -->
            <div class="row mt-3">
                <div class="col-xl-6 col-md-6">
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="fas fa-check text-success" style="font-size: 2rem;"></i>
                            <h4 class="mt-2">{{ $totalCampaignCompleted }}</h4>
                            <p class="text-muted">{{ __('lms.Passed') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 col-md-6">
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="fas fa-times text-danger" style="font-size: 2rem;"></i>
                            <h4 class="mt-2">{{ $totalCampaignFailed }}</h4>
                            <p class="text-muted">{{ __('lms.Failed') }}</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Charts Section -->
        <section class="charts-section mt-4">
            <div class="row">
                <!-- Monthly Trend Chart -->
                <div class="col-xl-8">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">{{ __('lms.Completion Trend (Last 12 Months)') }}</h4>
                        </div>
                        <div class="card-body">
                            <div id="campaign-monthly-trend-chart"></div>
                        </div>
                    </div>
                </div>

                <!-- Top Users -->
                <div class="col-xl-4">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">{{ __('lms.Top Performers') }}</h4>
                        </div>
                        <div class="card-body">
                            <div class="list-group">
                                @foreach($campaignTopUsers as $user)
                                <div class="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong>{{ $user->name }}</strong>
                                        <br>
                                        <small class="text-muted">
                                            {{ $user->completed_trainings }} {{ __('lms.trainings') }} |
                                            {{ number_format($user->avg_score, 1) }}% {{ __('lms.avg score') }}
                                        </small>
                                    </div>
                                    <span class="badge bg-success">
                                        <i class="fas fa-trophy"></i>
                                    </span>
                                </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Training Modules by Course -->
        <section class="trainings-section mt-4">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">{{ __('lms.Trainings by Course') }}</h4>
                </div>
                <div class="card-body">
                    @foreach($campaignTrainingsByCourse as $course)
                    <div class="training-item">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <h5 class="mb-0">
                                <i class="fas fa-book-open text-primary"></i> {{ $course->title }}
                            </h5>
                        </div>

                        <div class="row mt-3">
                            @foreach($course->levels as $level)
                            @foreach($level->training_modules as $module)
                            <div class="col-md-6 mb-3">
                                <div class="card">
                                    <div class="card-body">
                                        <h6>{{ $module->name }}</h6>
                                        <div class="d-flex justify-content-between mb-2">
                                            <small>{{ __('lms.Enrollments') }}: {{ $module->users_count }}</small>
                                            <small>{{ __('lms.Completed') }}: {{ $module->completed_users_count }}</small>
                                        </div>
                                        @php
                                        $moduleCompletionRate = $module->users_count > 0
                                        ? ($module->completed_users_count / $module->users_count) * 100
                                        : 0;
                                        @endphp
                                        <div class="progress progress-custom">
                                            <div class="progress-bar bg-success" role="progressbar"
                                                style="width: {{ $moduleCompletionRate }}%"
                                                aria-valuenow="{{ $moduleCompletionRate }}"
                                                aria-valuemin="0" aria-valuemax="100">
                                            </div>
                                        </div>
                                        <small class="text-muted">{{ number_format($moduleCompletionRate, 1) }}% {{ __('lms.complete') }}</small>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                            @endforeach
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </section>

        <!-- Recent Completions -->
        <section class="recent-section mt-4">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">{{ __('lms.Recent Completions (Last 30 Days)') }}</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-recent table-hover">
                            <thead>
                                <tr>
                                    <th>{{ __('lms.User') }}</th>
                                    <th>{{ __('lms.Training') }}</th>
                                    <th>{{ __('lms.Score') }}</th>
                                    <th>{{ __('lms.Status') }}</th>
                                    <th>{{ __('lms.Completed At') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($campaignRecentCompletions as $completion)
                                <tr>
                                    <td>{{ $completion->user_name }}</td>
                                    <td>{{ $completion->training_name }}</td>
                                    <td>
                                        <strong>{{ number_format($completion->score, 2) }}%</strong>
                                    </td>
                                    <td>
                                        @if($completion->passed)
                                        <span class="badge badge-status bg-success">
                                            <i class="fas fa-check"></i> {{ __('lms.Passed') }}
                                        </span>
                                        @else
                                        <span class="badge badge-status bg-danger">
                                            <i class="fas fa-times"></i> {{ __('lms.Failed') }}
                                        </span>
                                        @endif
                                    </td>
                                    <td>{{ \Carbon\Carbon::parse($completion->completed_at)->format('Y-m-d H:i') }}</td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>

        <!-- Average Scores -->
        <section class="scores-section mt-4">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">{{ __('lms.Average Scores by Training') }}</h4>
                </div>
                <div class="card-body">
                    <div id="campaign-average-scores-chart"></div>
                </div>
            </div>
        </section>

    </div>
</div>

@endsection

@section('vendor-script')
<script src="{{ asset(mix('vendors/js/charts/apexcharts.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
@endsection

@section('page-script')
<script>
    $(document).ready(function() {

        // ==================== PUBLIC CHARTS ====================

        // Public Monthly Trend Chart
        var publicMonthlyTrendData = @json($publicMonthlyTrend);
        var publicMonths = publicMonthlyTrendData.map(item => item.month);
        var publicCompletions = publicMonthlyTrendData.map(item => item.completions);
        var publicPassed = publicMonthlyTrendData.map(item => item.passed);

        var publicMonthlyTrendOptions = {
            series: [{
                name: '{{ __("lms.Total Completions") }}',
                data: publicCompletions
            }, {
                name: '{{ __("lms.Passed") }}',
                data: publicPassed
            }],
            chart: {
                height: 350,
                type: 'bar',
                toolbar: {
                    show: false
                }
            },
            dataLabels: {
                enabled: false
            },
            stroke: {
                curve: 'smooth',
                width: 2
            },
            xaxis: {
                categories: publicMonths
            },
            colors: ['#7367f0', '#28c76f'],
            fill: {
                type: 'gradient',
                gradient: {
                    shadeIntensity: 1,
                    opacityFrom: 0.7,
                    opacityTo: 0.3,
                }
            }
        };

        var publicMonthlyTrendChart = new ApexCharts(
            document.querySelector("#public-monthly-trend-chart"),
            publicMonthlyTrendOptions
        );
        publicMonthlyTrendChart.render();

        // Public Average Scores Chart
        var publicAverageScoresData = @json($publicAverageScores);
        var publicTrainingNames = publicAverageScoresData.map(item => item.name);
        var publicAvgScores = publicAverageScoresData.map(item => parseFloat(item.avg_score).toFixed(2));

        var publicAvgScoresOptions = {
            series: [{
                name: '{{ __("lms.Average Score") }}',
                data: publicAvgScores
            }],
            chart: {
                height: 350,
                type: 'bar',
                toolbar: {
                    show: false
                }
            },
            plotOptions: {
                bar: {
                    horizontal: true,
                    dataLabels: {
                        position: 'top'
                    }
                }
            },
            dataLabels: {
                enabled: true,
                formatter: function(val) {
                    return val + "%";
                },
                offsetX: -6,
                style: {
                    fontSize: '12px',
                    colors: ['#fff']
                }
            },
            xaxis: {
                categories: publicTrainingNames,
                max: 100
            },
            colors: ['#00cfe8']
        };

        var publicAvgScoresChart = new ApexCharts(
            document.querySelector("#public-average-scores-chart"),
            publicAvgScoresOptions
        );
        publicAvgScoresChart.render();

        // ==================== CAMPAIGN CHARTS ====================

        var campaignMonthlyTrendChart, campaignAvgScoresChart;

        // Initialize Campaign charts when tab is shown
        $('#campaign-tab').on('shown.bs.tab', function () {
            if (!campaignMonthlyTrendChart) {
                // Campaign Monthly Trend Chart
                var campaignMonthlyTrendData = @json($campaignMonthlyTrend);
                var campaignMonths = campaignMonthlyTrendData.map(item => item.month);
                var campaignCompletions = campaignMonthlyTrendData.map(item => item.completions);
                var campaignPassed = campaignMonthlyTrendData.map(item => item.passed);

                var campaignMonthlyTrendOptions = {
                    series: [{
                        name: '{{ __("lms.Total Completions") }}',
                        data: campaignCompletions
                    }, {
                        name: '{{ __("lms.Passed") }}',
                        data: campaignPassed
                    }],
                    chart: {
                        height: 350,
                        type: 'bar',
                        toolbar: {
                            show: false
                        }
                    },
                    dataLabels: {
                        enabled: false
                    },
                    stroke: {
                        curve: 'smooth',
                        width: 2
                    },
                    xaxis: {
                        categories: campaignMonths
                    },
                    colors: ['#7367f0', '#28c76f'],
                    fill: {
                        type: 'gradient',
                        gradient: {
                            shadeIntensity: 1,
                            opacityFrom: 0.7,
                            opacityTo: 0.3,
                        }
                    }
                };

                campaignMonthlyTrendChart = new ApexCharts(
                    document.querySelector("#campaign-monthly-trend-chart"),
                    campaignMonthlyTrendOptions
                );
                campaignMonthlyTrendChart.render();

                // Campaign Average Scores Chart
                var campaignAverageScoresData = @json($campaignAverageScores);
                var campaignTrainingNames = campaignAverageScoresData.map(item => item.name);
                var campaignAvgScores = campaignAverageScoresData.map(item => parseFloat(item.avg_score).toFixed(2));

                var campaignAvgScoresOptions = {
                    series: [{
                        name: '{{ __("lms.Average Score") }}',
                        data: campaignAvgScores
                    }],
                    chart: {
                        height: 350,
                        type: 'bar',
                        toolbar: {
                            show: false
                        }
                    },
                    plotOptions: {
                        bar: {
                            horizontal: true,
                            dataLabels: {
                                position: 'top'
                            }
                        }
                    },
                    dataLabels: {
                        enabled: true,
                        formatter: function(val) {
                            return val + "%";
                        },
                        offsetX: -6,
                        style: {
                            fontSize: '12px',
                            colors: ['#fff']
                        }
                    },
                    xaxis: {
                        categories: campaignTrainingNames,
                        max: 100
                    },
                    colors: ['#ff9f43']
                };

                campaignAvgScoresChart = new ApexCharts(
                    document.querySelector("#campaign-average-scores-chart"),
                    campaignAvgScoresOptions
                );
                campaignAvgScoresChart.render();
            }
        });
    });
</script>
@endsection
