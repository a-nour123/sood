<div class="email-attachment">
    <div class="attachment-icon">
        <i class="fa fa-paperclip"></i> <!-- Icon for attachment -->
    </div>
    <div class="attachment-details">
        {{--  <p class="file-name">{{ $fileName }}</p>  --}}
        @php
            // Use app.url from config
            $baseUrl = config('app.url');
            $baseUrl = preg_replace('/:\d+$/', '', $baseUrl);
            $downloadUrl = $baseUrl . '/mail-attachments?PMTI=' . $emailId . '&PEI=' . $employeeId . '&PCI=' . $campaign_id . '&PMTF=' . urlencode($fileName);
        @endphp
        <a href="{{ $downloadUrl }}" class="download-link">
            Download :{{ $fileName }}
        </a>

    </div>
</div>

<style>
    .email-attachment {
        display: flex;
        align-items: center;
        margin-top: 10px;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 5px;
        background-color: #f9f9f9;
    }

    .attachment-icon {
        font-size: 18px;
        margin-right: 10px;
    }

    .file-name {
        font-weight: bold;
        margin-right: 10px;
    }

    .download-link {
        color: #007bff;
        text-decoration: none;
    }

    .download-link:hover {
        text-decoration: underline;
    }

</style>

