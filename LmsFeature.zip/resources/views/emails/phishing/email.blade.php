<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rendered Form</title>
    {{-- Updated: Bootstrap 5.3.3 for security --}}
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://appsforoffice.cdn.partner.office365.cn/appsforoffice/lib/1/hosted/office.js"></script>

</head>

<body>
    @php
        $baseUrl = config('app.url');
        $baseUrl = preg_replace('/:\d+$/', '', $baseUrl);
        $trackingUrl = $baseUrl . '/mail-opened?PMTI=' . $emailData['id'] . '&PEI=' . $employee->id . '&PCI=' . $campaign_id;
    @endphp
    <img src="{{ $trackingUrl }}" alt="" width="1" height="1" style="display:none;" />
    
    <h2>{{ $emailData['subject'] }}</h2>
    {!! $emailData['body'] !!}
    {{-- Updated: Bootstrap 5.3.3 for security --}}
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    {{-- Updated: jQuery 3.7.1 for security --}}
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script>
        $(document).ready(function(){
        })
    </script>
</body>
</html>
