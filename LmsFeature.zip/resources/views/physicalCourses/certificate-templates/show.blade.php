@extends('admin/layouts/contentLayoutMaster')

@section('title', __('locale.Certificate Templates'))

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">
@endsection

@section('page-style')
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-sweet-alerts.css')) }}">
    <style>
        .template-preview {
            width: 100%;
            height: 400px;
            border: 2px solid #dee2e6;
            border-radius: 8px;
            background: white;
        }
    </style>
@endsection

@section('content')
    <div class="container-fluid">
        <div class="content-header row">
            <div class="content-header-left col-12 mb-2">
                <div class="row breadcrumbs-top widget-grid">
                    <div class="col-12">
                        <div class="page-title mt-2">
                            <div class="row">
                                <div class="col-sm-6 ps-0">
                                    @if (@isset($breadcrumbs))
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="{{ route('admin.dashboard') }}" style="display: flex;">
                                                    <svg class="stroke-icon">
                                                        <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}"></use>
                                                    </svg>
                                                </a>
                                            </li>
                                            @foreach ($breadcrumbs as $breadcrumb)
                                                <li class="breadcrumb-item">
                                                    @if (isset($breadcrumb['link']))
                                                        <a href="{{ $breadcrumb['link'] == 'javascript:void(0)' ? $breadcrumb['link'] : url($breadcrumb['link']) }}">
                                                    @endif
                                                    {{ $breadcrumb['name'] }}
                                                    @if (isset($breadcrumb['link']))
                                                        </a>
                                                    @endif
                                                </li>
                                            @endforeach
                                        </ol>
                                    @endisset
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Page Header -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center bg-white p-3 rounded shadow-sm">
                    <div>
                        <h2 class="h4 mb-0">
                            <i class="fas fa-certificate me-2 text-primary"></i>
                            {{ $template->name }}
                        </h2>
                        <small class="text-muted">{{ __('locale.Certificate Templates') }}</small>
                    </div>
                    <div>
                        <a href="{{ route('admin.physical-courses.certificate-templates.design', $template) }}" class="btn btn-info">
                            <i class="fas fa-palette me-2"></i>{{ __('certificates.design_fields') }}
                        </a>
                        <a href="{{ route('admin.physical-courses.certificate-templates.edit', $template) }}" class="btn btn-warning">
                            <i class="fas fa-edit me-2"></i>{{ __('certificates.edit_template') }}
                        </a>
                        <a href="{{ route('admin.physical-courses.certificate-templates.index') }}" class="btn btn-secondary">
                            <i class="fas fa-arrow-right me-2"></i>{{ __('locale.Back to List') }}
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Main Information -->
            <div class="col-lg-8">
                <!-- Template Details -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-info-circle me-2"></i>{{ __('locale.Basic Template Information') }}
                        </h3>
                        <div class="template-status">
                            @if ($template->is_default)
                                <span class="badge bg-success">{{ __('locale.Default') }}</span>
                            @endif
                            @if ($template->is_active)
                                <span class="badge bg-primary">{{ __('locale.Active') }}</span>
                            @else
                                <span class="badge bg-secondary">{{ __('locale.Inactive') }}</span>
                            @endif
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <strong>{{ __('locale.Template Name') }}:</strong>
                                <p class="mb-0">{{ $template->name }}</p>
                            </div>
                            <div class="col-md-6 mb-3">
                                <strong>{{ __('locale.Certificate Type') }}:</strong>
                                <p class="mb-0">
                                    @php
                                        $certType = $template->certificate_type ?? 'physicalcourse';
                                        $typeLabel = $certType == 'physicalcourse' ? __('locale.Physical Course') : __('locale.Training Module');
                                        $typeBadge = $certType == 'physicalcourse' ? 'primary' : 'success';
                                    @endphp
                                    <span class="badge badge-{{ $typeBadge }}">
                                        <i class="fas fa-{{ $certType == 'physicalcourse' ? 'chalkboard-teacher' : 'graduation-cap' }}"></i>
                                        {{ $typeLabel }}
                                    </span>
                                </p>
                            </div>
                            <div class="col-md-6 mb-3">
                                <strong>{{ __('locale.Template Orientation') }}:</strong>
                                <p class="mb-0">
                                    <span class="badge badge-{{ $template->orientation == 'L' ? 'info' : 'secondary' }}">
                                        <i class="fas fa-{{ $template->orientation == 'L' ? 'arrows-alt-h' : 'arrows-alt-v' }}"></i>
                                        {{ $template->orientation == 'L' ? __('certificates.landscape') : __('certificates.portrait') }}
                                    </span>
                                </p>
                            </div>
                            <div class="col-md-6 mb-3">
                                <strong>{{ __('locale.Description') }}:</strong>
                                <p class="mb-0 text-muted">
                                    {{ $template->description ?? __('certificates.no_description') }}
                                </p>
                            </div>
                            <div class="col-md-6 mb-3">
                                <strong>{{ __('locale.Creation Date') }}:</strong>
                                <p class="mb-0">{{ $template->created_at->format('Y-m-d H:i') }}</p>
                            </div>
                            <div class="col-md-6 mb-3">
                                <strong>{{ __('locale.Last Update') }}:</strong>
                                <p class="mb-0">{{ $template->updated_at->format('Y-m-d H:i') }}</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Template Preview -->
                @if ($template->file_exists && $template->file_url)
                    <div class="card mb-4">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-eye me-2"></i>{{ __('locale.Preview') }}
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="template-preview">
                                <iframe src="{{ $template->file_url }}" 
                                    style="width: 100%; height: 100%; border: none;">
                                </iframe>
                            </div>
                            <div class="mt-3 text-center">
                                <a href="{{ $template->file_url }}" target="_blank" class="btn btn-primary">
                                    <i class="fas fa-external-link-alt me-2"></i>{{ __('locale.Preview') }} {{ __('locale.Full Screen') }}
                                </a>
                            </div>
                        </div>
                    </div>
                @endif

                <!-- Field Positions -->
                @if (!empty($template->field_positions))
                    <div class="card mb-4">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-map-marker-alt me-2"></i>{{ __('locale.Designed Fields') }}
                            </h3>
                        </div>
                        <div class="card-body">
                            <p class="text-muted mb-3">
                                {{ __('locale.Fields currently added to the template') }}:
                            </p>
                            <div class="row">
                                @foreach ($template->field_positions as $field)
                                    @if(isset($availableFields[$field['field']]))
                                        <div class="col-md-6 mb-2">
                                            <div class="d-flex align-items-center">
                                                <i class="fas fa-check-circle text-success me-2"></i>
                                                <div>
                                                    <strong>{{ $availableFields[$field['field']]['label'] ?? $field['field'] }}</strong>
                                                    <br>
                                                    <small class="text-muted">
                                                        X: {{ $field['x'] ?? 0 }}, Y: {{ $field['y'] ?? 0 }}
                                                        | {{ __('locale.Size') }}: {{ $field['width'] ?? 0 }} × {{ $field['height'] ?? 0 }}
                                                    </small>
                                                </div>
                                            </div>
                                        </div>
                                    @endif
                                @endforeach
                            </div>
                            <div class="mt-3">
                                <a href="{{ route('admin.physical-courses.certificate-templates.design', $template) }}" class="btn btn-outline-primary">
                                    <i class="fas fa-edit me-1"></i>{{ __('locale.Edit Design') }}
                                </a>
                            </div>
                        </div>
                    </div>
                @else
                    <div class="card mb-4">
                        <div class="card-body text-center py-5">
                            <i class="fas fa-palette fa-3x text-muted mb-3"></i>
                            <h5 class="text-muted">{{ __('locale.No Fields Designed') }}</h5>
                            <p class="text-muted">{{ __('locale.This template has no fields designed yet') }}</p>
                            <a href="{{ route('admin.physical-courses.certificate-templates.design', $template) }}" class="btn btn-primary">
                                <i class="fas fa-palette me-2"></i>{{ __('certificates.design_fields') }}
                            </a>
                        </div>
                    </div>
                @endif
            </div>

            <!-- Sidebar -->
            <div class="col-lg-4">
                <!-- Statistics -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-chart-bar me-2"></i>{{ __('locale.Usage Statistics') }}
                        </h3>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-certificate fa-2x text-primary"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <div class="fw-bold">{{ $template->certificates->count() ?? 0 }}</div>
                                    <small class="text-muted">{{ __('locale.Certificates Created') }}</small>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-book fa-2x text-info"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <div class="fw-bold">{{ $template->courses->count() ?? 0 }}</div>
                                    <small class="text-muted">{{ __('locale.Associated Courses') }}</small>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-calendar fa-2x text-success"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <div class="fw-bold">{{ $template->created_at->format('Y-m-d') }}</div>
                                    <small class="text-muted">{{ __('locale.Creation Date') }}</small>
                                </div>
                            </div>
                        </div>
                        <div>
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-edit fa-2x text-warning"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <div class="fw-bold">{{ $template->updated_at->diffForHumans() }}</div>
                                    <small class="text-muted">{{ __('locale.Last Update') }}</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Available Fields -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-tags me-2"></i>{{ __('locale.Available Fields') }}
                        </h3>
                    </div>
                    <div class="card-body">
                        <p class="text-muted mb-3">
                            {{ __('locale.These are the fields that can be added to the certificate during design') }}:
                        </p>
                        <div class="available-fields">
                            @foreach ($availableFields as $fieldKey => $fieldData)
                                <div class="d-flex align-items-center mb-2 p-2 bg-light rounded">
                                    <i class="{{ $fieldData['icon'] ?? 'fas fa-text-width' }} me-2 text-primary"></i>
                                    <span>{{ $fieldData['label'] }}</span>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>

                <!-- Template Settings -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-cogs me-2"></i>{{ __('locale.Template Settings') }}
                        </h3>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <strong>{{ __('locale.Background Color') }}:</strong>
                            <div class="d-flex align-items-center mt-2">
                                <div class="color-preview me-2" style="background-color: {{ $template->background_color ?? '#FFFFFF' }}; width: 40px; height: 40px; border: 1px solid #ddd; border-radius: 4px;"></div>
                                <span>{{ $template->background_color ?? '#FFFFFF' }}</span>
                            </div>
                        </div>
                        <div class="mb-3">
                            <strong>{{ __('locale.Auto Send') }}:</strong>
                            <p class="mb-0">
                                @if ($template->auto_send)
                                    <span class="badge badge-success">{{ __('locale.Yes') }}</span>
                                @else
                                    <span class="badge badge-secondary">{{ __('locale.No') }}</span>
                                @endif
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>
@endsection

@section('page-script')
    <script>
        $(document).ready(function() {
            // Initialize tooltips
            $('[data-toggle="tooltip"]').tooltip();
        });
    </script>
@endsection
