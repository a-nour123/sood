@extends('admin/layouts/contentLayoutMaster')

@section('title', __('LMS.Quizes'))

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/pickadate/pickadate.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/flatpickr/flatpickr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/dataTables.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/responsive.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/buttons.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/pickadate/pickadate.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/flatpickr/flatpickr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/animate/animate.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">

@endsection

@section('page-style')
    {{-- <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}"> --}}
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/base/plugins/forms/pickers/form-flat-pickr.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/forms/pickers/form-flat-pickr.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/forms/pickers/form-pickadate.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-sweet-alerts.css')) }}">
    <link rel="stylesheet" type="text/css" href="{{ asset(mix('vendors/css/forms/wizard/bs-stepper.min.css')) }}">
    <link rel="stylesheet" type="text/css" href="{{ asset(mix('css/base/plugins/forms/form-wizard.css')) }}">

    <link rel="stylesheet" type="text/css" href="{{ asset('new_d/course_addon.css') }}">

    <link rel="stylesheet" href="{{ asset('lms-quizes/quiz/css/all.css') }}">
    <!-- Google fonts include -->

    <link rel="shortcut icon" href="{{ asset('lms-quizes/assets/images/favicon.svg') }}">
    <!-- Bootstrap-css include -->
    <link rel="stylesheet" href="{{ asset('assets/css/theme.min.css') }}">
    <link rel="stylesheet" href="{{ asset('lms-quizes/quiz/css/bootstrap.min.css') }}">
    <!-- Animate-css include -->
    <link rel="stylesheet" href="{{ asset('lms-quizes/quiz/css/animate.min.css') }}">
    <!-- Main-StyleSheet include -->
    <link rel="stylesheet" href="{{ asset('lms-quizes/quiz/css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('lms-quizes/introjs/introjs.css') }}">

    <style>
        .modal-body {
            background-color: #f8f9fa;
        }

        .accordion-button {
            background-color: #e9ecef;
            color: #000;
        }

        .accordion-body {
            padding: 10px;
        }

        .img-fluid {
            margin-bottom: 10px;
            border-radius: 10px;
        }
    </style>

    <style>
        /* Base style for all dropdown toggles */
        .dropdown-toggle::after {
            display: inline-block;
            width: 1rem;
            height: 1rem;
            margin-left: auto;
            padding-left: 1.25rem;
            content: "";
            transition: background-image 0.2s ease-in-out;
        }

        /* Override for .btn-light dropdowns */
        .btn-light.dropdown-toggle::after {
            border: none;
        }

        /* Optional: Add a hover effect to change the icon color */



        .schemeItem {
            border: 1px solid rgba(0, 0, 0, .125);
            transition: border-color 0.3s ease;
            /* Add transition for smooth effect */
        }

        .schemeItem:hover {
            border-color: #0d6efd;
            /* Change border color on hover */
        }

        .schemeItemNotSelected {
            background-color: white;
        }

        .schemeItemSelected {
            background-color: #0d6efd;
            border-color: #0d6efd;
            color: white;
            pointer-events: none;
        }

        .darkBackground {
            background-color: #fff
        }

        .nav-tabs .nav-link-light {
            color: white;
        }

        .nav-tabs .nav-link-dark {
            color: #212529;
        }

        .lightNavBackground {}

        .darkNavBackground {
            background: 0 0;
        }

        h1,
        label {
            color: #44225c !important;
        }

        @media screen and (min-width: 0px) and (max-width: 770px) {
            /*.scenarioQuestions {
                                                                                                                                                                                                    overflow-y: scroll !important;
                                                                                                                                                                                                    height: 45vh !important;
                                                                                                                                                                                                }*/

            .stepItemMobile {
                overflow-y: scroll !important;
                height: 70vh !important;
            }

            .rounded-pill {
                border-radius: 0rem !important;
            }

            /* show it on large screen */
        }

        .fslightbox-slide-btn-container {
            display: none !important;
        }
    </style>

@endsection
@section('content')

    @php
        // Helper function to get content with fallback
        function getContentWithFallback($content, $field, $fallbackField = null)
        {
            $currentLocale = app()->getLocale();

            if ($currentLocale === 'ar') {
                $primaryField = $field . '_ar';
                $fallbackField = $fallbackField ?: $field;
            } else {
                $primaryField = $field;
                $fallbackField = $field . '_ar';
            }

            // Check if primary field exists and is not empty
            if (isset($content[$primaryField]) && !empty(trim($content[$primaryField]))) {
                return $content[$primaryField];
            }

            // Return fallback if primary is empty
            if (isset($content[$fallbackField]) && !empty(trim($content[$fallbackField]))) {
                return $content[$fallbackField];
            }

            // Return empty string if both are empty
            return '';
        }

        // function getMediaWithFallback($content, $field)
        // {
        //     $currentLocale = app()->getLocale();

        //     if ($currentLocale === 'ar') {
        //         $primaryField = $field . '_ar';
        //         $fallbackField = $field;
        //     } else {
        //         $primaryField = $field;
        //         $fallbackField = $field . '_ar';
        //     }

        //     $checkFileExists = function ($fieldName) use ($content) {
        //         return isset($content[$fieldName]) &&
        //             !empty($content[$fieldName]) &&
        //             file_exists(storage_path('app/public/' . $content[$fieldName]));
        //     };

        //     if ($checkFileExists($primaryField)) {
        //         return $content[$primaryField];
        //     }

        //     if ($checkFileExists($fallbackField)) {
        //         return $content[$fallbackField];
        //     }

        //     $alternativeFields = [];

        //     if ($field === 'video_or_image_url') {
        //         $alternativeFields = ['video_or_image_url_en', 'image', 'image_ar'];
        //     } elseif ($field === 'image') {
        //         $alternativeFields = [
        //             'image_ar',
        //             'video_or_image_url',
        //             'video_or_image_url_ar',
        //             'video_or_image_url_en',
        //         ];
        //     }

        //     foreach ($alternativeFields as $altField) {
        //         if ($checkFileExists($altField)) {
        //             return $content[$altField];
        //         }
        //     }

        //     return null;
        // }

        function getMediaWithFallback($content, $field)
        {
            $currentLocale = app()->getLocale();

            $checkFileExists = function ($fieldName) use ($content) {
                return isset($content[$fieldName]) &&
                    !empty($content[$fieldName]) &&
                    file_exists(storage_path('app/public/' . $content[$fieldName]));
            };

            $primaryFields = [];
            $fallbackFields = [];

            if ($currentLocale === 'ar') {
                if ($field === 'video_or_image_url') {
                    $primaryFields = ['video_or_image_url', 'image_ar'];
                    $fallbackFields = ['video_or_image_url_en', 'image'];
                } else {
                    $primaryFields = ['image_ar', 'video_or_image_url'];
                    $fallbackFields = ['image', 'video_or_image_url_en'];
                }
            } else {
                if ($field === 'video_or_image_url') {
                    $primaryFields = ['video_or_image_url_en', 'image'];
                    $fallbackFields = ['video_or_image_url', 'image_ar'];
                } else {
                    $primaryFields = ['image', 'video_or_image_url_en'];
                    $fallbackFields = ['image_ar', 'video_or_image_url'];
                }
            }

            foreach ($primaryFields as $fieldName) {
                if ($checkFileExists($fieldName)) {
                    return $content[$fieldName];
                }
            }

            foreach ($fallbackFields as $fieldName) {
                if ($checkFileExists($fieldName)) {
                    return $content[$fieldName];
                }
            }

            return null;
        }
        function getMediaType($filePath)
        {
            if (!$filePath) {
                return null;
            }

            $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));

            $videoExtensions = ['mp4', 'mov', 'avi', 'mkv', 'webm'];
            $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'];

            if (in_array($extension, $videoExtensions)) {
                return 'video';
            } elseif (in_array($extension, $imageExtensions)) {
                return 'image';
            }

            return 'unknown';
        }

    @endphp

    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">

            <div class="row breadcrumbs-top  widget-grid">
                <div class="col-12">
                    <div class="page-title mt-2">
                        <div class="row">
                            <div class="col-sm-6 ps-0">
                                @if (@isset($breadcrumbs))
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="" style="display: flex;">
                                                <svg class="stroke-icon">
                                                    <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}">
                                                    </use>
                                                </svg></a></li>
                                        @foreach ($breadcrumbs as $breadcrumb)
                                            <li class="breadcrumb-item">
                                                @if (isset($breadcrumb['link']))
                                                    <a
                                                        href="{{ $breadcrumb['link'] == 'javascript:void(0)' ? $breadcrumb['link'] : url($breadcrumb['link']) }}">
                                                @endif
                                                {{ $breadcrumb['name'] }}
                                                @if (isset($breadcrumb['link']))
                                                    </a>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ol>
                                @endisset
                        </div>
                        <div class="col-sm-6 pe-0" style="text-align: end;">

                            <div class="action-content">

                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <div id="quill-service-content" class="d-none"></div>
</div>




    @if (session()->has('info'))
        <div
            class="alert alert-warning alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i>
            {{ session()->get('info') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif


    @if (session()->has('error'))
        <div
            class="alert alert-warning alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i>
            {{ session()->get('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif



<div>
    <section class="">
        <div class="container">
            <div class="row">
                <form class="multisteps_form" style="text-align:center" id="wizard">
                    @foreach ($pages as $index => $page)
                        <input type="hidden" id="pageType_{{ $index }}" name="pageType"
                            value="{{ $page['type'] }}">
                        @if ($page['type'] == 'statement')
                            <div class="multisteps_form_panel step">
                                <div class="col-md-7 m-auto">
                                    <div class="content_box py-2 ps-5 position-relative stepItemMobile text-center">
                                        <!-- Step-progress-bar -->
                                        <div class="step_progress_bar mb-3">
                                            <div class="progress rounded-pill">
                                                @php
                                                    $totalPages = count($pages);
                                                    $progressPercent = (($index + 1) * 100) / $totalPages;
                                                @endphp
                                                <div class="progress-bar mx-2 rounded-pill" role="progressbar"
                                                    style="width: {{ $progressPercent }}%;"
                                                    aria-valuenow="{{ $progressPercent }}"
                                                    aria-valuemin="0" aria-valuemax="100">
                                                    {{ number_format($progressPercent, 1) }}%</div>
                                            </div>
                                        </div>
                                        <div class="question_title py-3 ">
                                            <h1>{{ getContentWithFallback($page['content'], 'title') }}</h1>
                                        </div>
                                        <label
                                            class="animate__animated animate__fadeInRight animate_25ms position-relative rounded-pill #44225c"
                                            style="font-size:1.25rem; font-family:system-ui !important;">
                                            {!! getContentWithFallback($page['content'], 'content') !!}
                                        </label>
                                        <div class="pt-2 animate__animated animate__fadeInRight animate_25ms">

                                            @if ($page['content']['additional_content'] == 'video')
                                                @php
                                                    $videoUrl = getMediaWithFallback(
                                                        $page['content'],
                                                        'video_or_image_url',
                                                    );

                                                    if ($videoUrl && getMediaType($videoUrl) !== 'video') {
                                                        $videoUrl = null;
                                                    }
                                                @endphp
                                                @if ($videoUrl)
                                                    <video class="videoStatement" style="width: 100%;" controls
                                                        height="400px">
                                                        <source src="{{ asset('storage/' . $videoUrl) }}"
                                                            type="video/mp4">
                                                    </video>
                                                @endif
                                            @endif

                                            @if ($page['content']['additional_content'] == 'image')
                                                @php
                                                    $imageUrl = getMediaWithFallback($page['content'], 'image');
                                                    if (!$imageUrl) {
                                                        $imageUrl = getMediaWithFallback(
                                                            $page['content'],
                                                            'video_or_image_url',
                                                        );

                                                        if ($imageUrl && getMediaType($imageUrl) !== 'image') {
                                                            $imageUrl = null;
                                                        }
                                                    }
                                                @endphp
                                                @if ($imageUrl)
                                                    <img src="{{ asset('storage/' . $imageUrl) }}" class=""
                                                        style="width: 100%;" controls />
                                                @endif
                                            @endif

                                        </div>
                                    </div>
                                </div>
                            </div>
                        @else
                            <div class="multisteps_form_panel step">
                                <div class="col-md-7 m-auto">
                                    <div class="content_box py-2 ps-5 position-relative stepItemMobile text-center">
                                        <div class="progress-showcase mb-3">
                                            <div class="progress align-items-center "
                                                style=" height: 15px; padding: 0; margin: 0;">
                                                @php
                                                    $totalPages = count($pages);
                                                    $progressPercent = (($index + 1) * 100) / $totalPages;
                                                @endphp
                                                <!-- <span><i class="far fa-solid fa-user-shield"></i></span> -->
                                                <div class="progress-bar mx-2 " role="progressbar"
                                                    style="width: {{ $progressPercent }}%;height: 15px;line-height: 15px; margin: 0;"
                                                    aria-valuenow="{{ $progressPercent }}"
                                                    aria-valuemin="0" aria-valuemax="100">
                                                    {{ number_format($progressPercent, 1) }}%</div>
                                            </div>
                                        </div>


                                    </div>

                                    {{-- question  --}}
                                    {{-- saveAnswerForQuestion --}}
                                    <div class="question_title py-3 text-center">
                                        <input type="hidden" class="question_id_{{ $index }}"
                                            id="question_id_{{ $index }}" name="question_id"
                                            value="{{ $page['content']['id'] }}">
                                        <input type="hidden" class="question_type_{{ $index }}"
                                            id="question_type_{{ $index }}" name="question_type"
                                            value="{{ $page['content']['question_type'] }}">
                                        <h1 class="#44225c">{{ getContentWithFallback($page['content'], 'question') }}
                                        </h1>
                                    </div>

                                    <div class="form_items scenarioQuestions text-center">
                                        {{-- question answer description --}}
                                        {{-- <div id="answerDescription{{ $index }}" class="pt-3"
                                            style="text-align:center">
                                            <h3 style="font-weight:400" id="answer{{ $index }}"></h3>
                                            <h6 class="#44225c"
                                                style="font-size:1.25rem; font-family:system-ui !important; font-weight:400">
                                                {{ getContentWithFallback($page['content'], 'answer_description') }}
                                            </h6>
                                            <a href="#"
                                                onclick='showAnswer({{ $index }});'>{{ __('lms.View Options Again') }}</a>
                                        </div> --}}

                                        {{-- question options  --}}

                                        <div id="answerQuestions{{ $index }}">
                                            @if ($page['content']['question_type'] == 'multi_choise')
                                                @foreach ($page['options'] as $optIndex => $option)
                                                    @php
                                                        // Get user answer - only disable if answer exists and is saved in database
                                                        $userAnswer = isset($page['user_answer']) && $page['user_answer'] ? $page['user_answer'] : null;
                                                        // Check if option still exists (might have been deleted after user answered)
                                                        $optionExists = isset($option['id']) && $option['id'];
                                                        $isSelected = $userAnswer && $optionExists && $userAnswer->option_id == $option['id'];

                                                        // Only disable if:
                                                        // 1. User has an answer saved
                                                        // 2. The option they selected still exists in current options
                                                        // 3. This specific option matches their saved answer
                                                        // 4. AND there are NO remaining attempts (user cannot retry)
                                                        $userSelectedOptionExists = false;
                                                        if ($userAnswer && $userAnswer->option_id) {
                                                            // Check if the option_id from user's answer exists in current options
                                                            $userSelectedOptionExists = collect($page['options'])->contains(function ($opt) use ($userAnswer) {
                                                                return isset($opt['id']) && $opt['id'] == $userAnswer->option_id;
                                                            });
                                                        }

                                                        // Only disable if user's selected option still exists AND no remaining attempts
                                                        $isDisabled = $userAnswer !== null && $userAnswer !== false && $userSelectedOptionExists && (isset($remainingAttempts) && $remainingAttempts <= 0);
                                                    @endphp

                                                    <label for="opt_{{ $index }}_{{ $optIndex }}"
                                                        class="step_{{ $index }} animate__animated animate__fadeInRight animate_25ms position-relative rounded-pill text-start #44225c darkBackground
            {{ $isSelected ? 'active' : '' }} {{ $isDisabled ? 'disabled' : '' }}"
                                                        data-toggle="modal" data-target="#answerModal"
                                                        data-whatever="mdo"
                                                        style="{{ $isDisabled ? 'pointer-events: none; opacity: 0.7;' : '' }}">

                                                        {{ getContentWithFallback($option, 'option_text') }}
                                                        <i class="step_{{ $index }}_selected fa fa-user-lock"
                                                            style="{{ $isSelected ? 'display: inline;' : 'display: none;' }}"></i>

                                                        <input id="opt_{{ $index }}_{{ $optIndex }}"
                                                            type="radio"
                                                            name="stp_{{ $index }}_select_option"
                                                            value="{{ $option['id'] }}"
                                                            class="option_id_{{ $index }}"
                                                            {{ $isSelected ? 'checked' : '' }}
                                                            {{ $isDisabled ? 'disabled' : '' }}>
                                                    </label>
                                                @endforeach

                                                {{-- True/False Questions --}}
                                            @else
                                                @php
                                                    // Get user answer - only disable if answer exists and is saved in database
                                                    $userAnswer = isset($page['user_answer']) && $page['user_answer'] ? $page['user_answer'] : null;
                                                    // Only disable if answer is actually saved in database (not null) AND no remaining attempts
                                                    $isDisabled = $userAnswer !== null && $userAnswer !== false && (isset($remainingAttempts) && $remainingAttempts <= 0);
                                                    $isTrueSelected = $userAnswer && $userAnswer->true_or_false == 1;
                                                    $isFalseSelected = $userAnswer && $userAnswer->true_or_false == 0;
                                                @endphp

                                                {{-- True Option --}}
                                                <label for="opt_true_{{ $index }}"
                                                    class="step_{{ $index }} animate__animated animate__fadeInRight animate_25ms position-relative rounded-pill text-start #44225c darkBackground
        {{ $isTrueSelected ? 'active' : '' }} {{ $isDisabled ? 'disabled' : '' }}"
                                                    data-toggle="modal" data-target="#answerModal"
                                                    data-whatever="mdo"
                                                    style="{{ $isDisabled ? 'pointer-events: none; opacity: 0.7;' : '' }}">

                                                    {{ __('lms.True') }}
                                                    <i class="step_{{ $index }}_selected fa fa-user-lock"
                                                        style="{{ $isTrueSelected ? 'display: inline;' : 'display: none;' }}"></i>

                                                    <input id="opt_true_{{ $index }}" type="radio"
                                                        name="stp_{{ $index }}_select_option" value="true"
                                                        class="true_or_false_option_id_{{ $index }}"
                                                        {{ $isTrueSelected ? 'checked' : '' }}
                                                        {{ $isDisabled ? 'disabled' : '' }}>
                                                </label>

                                                {{-- False Option --}}
                                                <label for="opt_false_{{ $index }}"
                                                    class="step_{{ $index }} animate__animated animate__fadeInRight animate_25ms position-relative rounded-pill text-start #44225c darkBackground
        {{ $isFalseSelected ? 'active' : '' }} {{ $isDisabled ? 'disabled' : '' }}"
                                                    data-toggle="modal" data-target="#answerModal"
                                                    data-whatever="mdo"
                                                    style="{{ $isDisabled ? 'pointer-events: none; opacity: 0.7;' : '' }}">

                                                    {{ __('lms.False') }}
                                                    <i class="step_{{ $index }}_selected fa fa-user-lock"
                                                        style="{{ $isFalseSelected ? 'display: inline;' : 'display: none;' }}"></i>

                                                    <input id="opt_false_{{ $index }}" type="radio"
                                                        name="stp_{{ $index }}_select_option" value="false"
                                                        class="true_or_false_option_id_{{ $index }}"
                                                        {{ $isFalseSelected ? 'checked' : '' }}
                                                        {{ $isDisabled ? 'disabled' : '' }}>
                                                </label>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
            </div>
            @endif
            @endforeach

            <!------------------------- Form button ----------------------------->
            <div class="form_btn">
                <button type="button"
                    class="f_btn rounded-pill prev_btn text-uppercase #44225c position-absolute text-white"
                    id="prevBtn" onclick="nextPrev(-1)"> {{ __('lms.Back') }}</button>
                <button type="button"
                    class="f_btn rounded-pill next_btn text-uppercase #44225c position-absolute text-white"
                    id="nextBtn" onclick="nextPrev(1)">
                    {{ __('lms.Next') }} <i class="fa-user-shield"></i>
                </button>
            </div>
            </form>
        </div>
</div>
</section>
</div>

@endsection

@section('vendor-script')
<script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/pickers/flatpickr/flatpickr.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>
<script src="{{ asset('vendors/js/extensions/quill.min.js') }}"></script>
@endsection

@section('page-script')
<script src="{{ asset('new_d/js/form-wizard/image-upload.js') }}"></script>
<script src="{{ asset('ajax-files/asset_management/asset/index.js') }}"></script>
<script src="{{ asset(mix('js/scripts/forms/form-select2.js')) }}"></script>



<script src="{{ asset('lms-quizes/quiz/js/jquery-3.6.0.min.js') }}"></script>
<script src="{{ asset('lms-quizes/quiz/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('lms-quizes/quiz/js/jquery.validate.min.js') }}"></script>
<script src="{{ asset('lms-quizes/assets/vendor/jquery/dist/jquery.min.js') }}"></script>
<script src="{{ asset('lms-quizes/front4/vendor/fslightbox/index.js') }}"></script>
<script src="{{ asset('lms-quizes/introjs/intro.js') }}"></script>
<script src="{{ asset('lms-quizes/assets/libs/sweetalert2/dist/sweetalert2.all.min.js') }}"></script>
<script src="{{ asset('lms-quizes/assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js') }}"></script>


{{-- <script>
    for (let index = 1; index <= 100; index++) {
        $(`#answerDescription${index}`).hide();
        $(`.step_${index}_selected`).hide();
    }
</script> --}}

<script>
    // Initialize quiz with previous answers
    $(document).ready(function() {
        initializePreviousAnswers();

        $('input[type="radio"]').on('change', function() {
            const stepMatch = $(this).attr('name').match(/stp_(\d+)_select_option/);
            if (stepMatch) {
                const stepIndex = parseInt(stepMatch[1]);
                $(`.step_${stepIndex}`).removeClass("active");
                $(this).closest('label').addClass("active");
                updateButtonStates();
            }
        });

        setTimeout(function() {
            updateButtonStates();
        }, 100);
    });

    function initializePreviousAnswers() {
        @foreach ($pages as $index => $page)
            @if ($page['type'] == 'question' && isset($page['user_answer']) && $page['user_answer'])
                answeredSteps[{{ $index }}] = true;
                @if ($page['content']['question_type'] == 'multi_choise')
                    @if ($page['user_answer']->option_id)
                        @php
                            // Find the option index - handle case where option might have been deleted
                            $optionIndex = collect($page['options'])->search(function ($option) use ($page) {
                                return isset($option['id']) && $option['id'] == $page['user_answer']->option_id;
                            });
                        @endphp
                        @if ($optionIndex !== false)
                            $('#opt_{{ $index }}_{{ $optionIndex }}')
                                .prop('checked', true);
                            // Only disable if no remaining attempts
                            if (remainingAttempts <= 0) {
                                disableQuestionOptions({{ $index }});
                            } else {
                                // Keep options enabled if user has remaining attempts
                                enableQuestionOptions({{ $index }});
                            }
                        @endif
                    @endif
                @else
                    @if ($page['user_answer']->true_or_false !== null)
                        @if ($page['user_answer']->true_or_false == 1)
                            $('#opt_true_{{ $index }}').prop('checked', true);
                        @else
                            $('#opt_false_{{ $index }}').prop('checked', true);
                        @endif
                        // Only disable if no remaining attempts
                        if (remainingAttempts <= 0) {
                            disableQuestionOptions({{ $index }});
                        } else {
                            // Keep options enabled if user has remaining attempts
                            enableQuestionOptions({{ $index }});
                        }
                    @endif
                @endif
            @endif
        @endforeach
    }

    var qCount = 7;
    var qCorrect = 0;
    var qIncorrect = 0;

    // Initialize tracking array
    var answeredSteps = new Array(100).fill(false);

    // Get remaining attempts from server
    var remainingAttempts = {{ isset($remainingAttempts) ? $remainingAttempts : 0 }};

    $(function() {
        // Mark previously answered questions from database
        @foreach ($pages as $index => $page)
            @if ($page['type'] == 'question' && isset($page['user_answer']) && $page['user_answer'])
                answeredSteps[{{ $index }}] = true;
            @endif
            @if ($page['type'] == 'statement')
                answeredSteps[{{ $index }}] = true;
            @endif
        @endforeach

        for (let index = 0; index <= 100; index++) {
            $(`.step_${index}`).on('click', function() {
                const $input = $(this).find('input[type="radio"]');
                if (!$(this).hasClass('disabled') && !$input.prop('disabled')) {
                    $(`.step_${index}`).removeClass("active");
                    $(this).addClass("active");
                    updateButtonStates();
                }
            });
        }
    });

    var currentTab = {{ $lastAnsweredIndex ?? 0 }};
    showTab(currentTab);

    function showTab(n) {
        var x = document.getElementsByClassName("multisteps_form_panel");
        var totalPanels = x.length;

        for (let i = 0; i < totalPanels; i++) {
            x[i].style.display = "none";
        }

        if (n >= totalPanels) {
            return;
        }

        if (n < totalPanels && n >= 0) {
            x[n].style.display = "block";
        }

        if (n == 0) {
            document.getElementById("prevBtn").style.display = "none";
        } else {
            document.getElementById("prevBtn").style.display = "inline";
        }

        if (n >= (totalPanels - 1)) {
            document.getElementById("nextBtn").innerHTML = "Submit";
        } else {
            document.getElementById("nextBtn").innerHTML = "{{ __('lms.Next') }}";
        }

        document.getElementById("prevBtn").innerHTML = "{{ __('lms.Back') }}";

        setTimeout(function() {
            updateButtonStates();
        }, 50);

        fixStepIndicator(n);
    }

    function updateButtonStates() {
        const nextBtn = document.getElementById("nextBtn");
        const prevBtn = document.getElementById("prevBtn");

        if (!nextBtn) return;

        const pageTypeInput = document.getElementById(`pageType_${currentTab}`);
        const pageType = pageTypeInput ? pageTypeInput.value : null;

        if (pageType === 'statement') {
            nextBtn.disabled = false;
            nextBtn.style.opacity = "1";
            nextBtn.style.cursor = "pointer";
            nextBtn.style.pointerEvents = "auto";
        } else if (pageType === 'question') {
            const isAnswered = checkIfCurrentPageAnswered();

            if (isAnswered) {
                nextBtn.disabled = false;
                nextBtn.style.opacity = "1";
                nextBtn.style.cursor = "pointer";
                nextBtn.style.pointerEvents = "auto";
            } else {
                nextBtn.disabled = true;
                nextBtn.style.opacity = "0.5";
                nextBtn.style.cursor = "not-allowed";
                nextBtn.style.pointerEvents = "none";
            }
        }
    }

    function checkIfCurrentPageAnswered() {
        // Check if there's a selected answer that is not disabled
        const multiChoiceChecked = $(`.option_id_${currentTab}:checked:not(:disabled)`).length > 0;
        const trueOrFalseChecked = $(`.true_or_false_option_id_${currentTab}:checked:not(:disabled)`).length > 0;

        return multiChoiceChecked || trueOrFalseChecked;
    }

    function nextPrev(n) {
        var x = document.getElementsByClassName("multisteps_form_panel");
        var totalPanels = x.length;

        if (n > 0) {
            if (!validateForm()) {
                const pageTypeInput = document.getElementById(`pageType_${currentTab}`);
                if (pageTypeInput && pageTypeInput.value === 'question') {
                    toastr.warning('{{ __('lms.Please select an answer before proceeding') }}',
                        '{{ __('lms.Warning') }}');
                }
                return false;
            }

            if (currentTab >= (totalPanels - 1)) {
                const currentPageType = $(`#pageType_${currentTab}`).val();
                if (currentPageType == 'question') {
                    // Check if there's a selected answer (not disabled)
                    const hasSelectedAnswer = checkIfCurrentPageAnswered();

                    // If user has remaining attempts and changed answer, save it
                    // Otherwise, if not answered yet, save it
                    // If already answered and no remaining attempts, finish directly
                    if (!answeredSteps[currentTab] || (remainingAttempts > 0 && hasSelectedAnswer)) {
                        saveAnswerForQuestion(currentTab, true);
                    } else {
                        finishTrainingDirectly();
                    }
                } else {
                    submitLearning(currentTab);
                }
                return false;
            }
        }

        if (n > 0 && currentTab < (totalPanels - 1)) {
            const currentPageType = $(`#pageType_${currentTab}`).val();
            if (currentPageType == 'question') {
                // Check if there's a selected answer (not disabled)
                const hasSelectedAnswer = checkIfCurrentPageAnswered();

                // If user has remaining attempts, allow saving even if already answered before
                // Otherwise, only save if not answered yet
                if (!answeredSteps[currentTab] || (remainingAttempts > 0 && hasSelectedAnswer)) {
                    saveAnswerForQuestion(currentTab, false);
                    return false;
                }
            }
        }

        x[currentTab].style.display = "none";
        currentTab = currentTab + n;
        showTab(currentTab);

        return true;
    }

    function saveAnswerForQuestion(pageIndex, finish) {
        $('#nextBtn').html('<i class="fa fa-spinner fa-spin"></i> Saving...');
        $('#nextBtn').prop('disabled', true);

        const optionId = $(`.option_id_${pageIndex}:checked`).val();
        const trueOrFalse = $(`.true_or_false_option_id_${pageIndex}:checked`).val();

        if (!optionId && !trueOrFalse) {
            toastr.error('{{ __('lms.Please select an answer before proceeding') }}', '{{ __('lms.Error') }}');
            $('#nextBtn').html(finish ? "{{ __('lms.Submit') }}" : "{{ __('lms.Next') }}");
            $('#nextBtn').prop('disabled', false);
            return false;
        }

        $.ajax({
            url: "{{ route('user.lms.training.modules.storeAnswer') }}",
            type: "POST",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: {
                'training_module_id': "{{ $id }}",
                'finish_training': finish,
                'pageType': $(`#pageType_${pageIndex}`).val(),
                'question_type': $(`#question_type_${pageIndex}`).val(),
                'question_id': $(`#question_id_${pageIndex}`).val(),
                'option_id': optionId,
                'true_or_false': trueOrFalse,
            },
            success: function(data) {
                answeredSteps[pageIndex] = true;
                // Only disable options if no remaining attempts
                if (remainingAttempts <= 0) {
                    disableQuestionOptions(pageIndex);
                } else {
                    // If user has remaining attempts, keep options enabled
                    enableQuestionOptions(pageIndex);
                }

                $('#nextBtn').html("{{ __('lms.Next') }}");
                $('#nextBtn').prop('disabled', false);

                if (data.completeTrain) {
                    window.location.href = data.redirect;
                } else {
                    if (!finish) {
                        var x = document.getElementsByClassName("multisteps_form_panel");
                        x[currentTab].style.display = "none";
                        currentTab = currentTab + 1;
                        showTab(currentTab);
                    }
                }
            },
            error: function(response, data) {
                $('#nextBtn').html("{{ __('lms.Next') }}");
                $('#nextBtn').prop('disabled', false);
                toastr.error('There is a problem saving your answer. Please try again.', 'Error');
            }
        });
    }

    function disableQuestionOptions(pageIndex) {
        $(`.step_${pageIndex}`).addClass('disabled');
        $(`.step_${pageIndex} input[type="radio"]`).prop('disabled', true);
        $(`.step_${pageIndex}`).css('pointer-events', 'none');
        $(`.step_${pageIndex}`).css('opacity', '0.7');
        $(`.step_${pageIndex}`).css('cursor', 'not-allowed');
    }

    function enableQuestionOptions(pageIndex) {
        $(`.step_${pageIndex}`).removeClass('disabled');
        $(`.step_${pageIndex} input[type="radio"]`).prop('disabled', false);
        $(`.step_${pageIndex}`).css('pointer-events', 'auto');
        $(`.step_${pageIndex}`).css('opacity', '1');
        $(`.step_${pageIndex}`).css('cursor', 'pointer');
    }

    function submitLearning(currentTabIndex) {
        $('#nextBtn').html('<i class="fa fa-spinner fa-spin"></i>');
        $('#nextBtn').prop('disabled', true);
        const currentPageType = $(`#pageType_${currentTabIndex}`).val();
        if (currentPageType == 'question') {
            saveAnswerForQuestion(currentTabIndex, true);
        } else {
            finishTrainingDirectly();
        }
    }

    function finishTrainingDirectly() {
        $.ajax({
            url: "{{ route('user.lms.training.modules.storeAnswer') }}",
            type: "POST",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: {
                'training_module_id': "{{ $id }}",
                'finish_training': true,
                'pageType': 'statement',
            },
            success: function(data) {
                if (data.completeTrain) {
                    window.location.href = data.redirect;
                } else {
                    window.location.href = "{{ route('user.lms.training.modules.index') }}";
                }
            },
            error: function(response) {
                toastr.error('There is a problem finishing training. Please try again.', 'Error');
                $('#nextBtn').html("{{ __('lms.Submit') }}");
                $('#nextBtn').prop('disabled', false);
            }
        });
    }

    function validateAnswer(answer, stepNumber) {
        updateButtonStates();
    }

    function validateTrueOrFalseAnswer(trueOrFalse, answer, stepNumber) {
        updateButtonStates();
    }

    function validateForm() {
        var x = document.getElementsByClassName("multisteps_form_panel");
        var y = x[currentTab].getElementsByTagName("input");
        var valid = true;

        const pageTypeInput = document.getElementById(`pageType_${currentTab}`);
        if (pageTypeInput && pageTypeInput.value === 'statement') {
            return true;
        }

        let allDisabled = true;
        for (let i = 0; i < y.length; i++) {
            if (y[i].type === 'radio' && !y[i].disabled) {
                allDisabled = false;
                break;
            }
        }

        if (allDisabled) {
            return true;
        }

        valid = false;
        for (let i = 0; i < y.length; i++) {
            if (y[i].type === 'radio' && y[i].checked && !y[i].disabled) {
                valid = true;
                break;
            }
        }

        return valid;
    }

    function fixStepIndicator(n) {
        var i, x = document.getElementsByClassName("step");
        for (i = 0; i < x.length; i++) {
            x[i].className = x[i].className.replace(" active", "");
        }
        if (x[n]) {
            x[n].className += " active";
        }
    }

    function showAnswer(qStep) {
        $("#answerDescription" + qStep).hide();
        $("#answerQuestions" + qStep).show();
    }
</script>
@endsection
