@extends('admin/layouts/contentLayoutMaster')

@section('title', __('lms.Quiz Summary'))

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
@endsection

@section('page-style')
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <style>
        .summary-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .result-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px;
            border-radius: 15px;
            text-align: center;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }

        .result-header.passed {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
        }

        .result-header.failed {
            background: linear-gradient(135deg, #dc3545 0%, #fd7e14 100%);
        }

        .score-circle {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 3rem;
            font-weight: bold;
            border: 5px solid rgba(255, 255, 255, 0.3);
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            text-align: center;
            transition: transform 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            font-size: 1.8rem;
        }

        .stat-icon.correct {
            background: rgba(40, 167, 69, 0.1);
            color: #28a745;
        }

        .stat-icon.incorrect {
            background: rgba(220, 53, 69, 0.1);
            color: #dc3545;
        }

        .stat-icon.total {
            background: rgba(0, 123, 255, 0.1);
            color: #007bff;
        }

        .stat-number {
            font-size: 2.5rem;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 5px;
        }

        .stat-label {
            color: #6c757d;
            font-size: 0.9rem;
            font-weight: 500;
        }

        .answers-section {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
        }

        .section-title {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 25px;
            color: #2c3e50;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .question-item {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            border-left: 5px solid #6c757d;
            transition: all 0.3s ease;
        }

        .question-item.correct {
            border-left-color: #28a745;
            background: rgba(40, 167, 69, 0.05);
        }

        .question-item.incorrect {
            border-left-color: #dc3545;
            background: rgba(220, 53, 69, 0.05);
        }

        .question-header {
            display: flex;
            justify-content: space-between;
            align-items: start;
            margin-bottom: 15px;
        }

        .question-number {
            background: #667eea;
            color: white;
            border-radius: 50%;
            width: 35px;
            height: 35px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            flex-shrink: 0;
        }

        .question-text {
            flex: 1;
            margin: 0 15px;
            font-size: 1.1rem;
            font-weight: 500;
            color: #2c3e50;
        }

        .question-status {
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .question-status.correct {
            background: #28a745;
            color: white;
        }

        .question-status.incorrect {
            background: #dc3545;
            color: white;
        }

        .answer-box {
            margin-top: 15px;
            padding: 15px;
            background: white;
            border-radius: 8px;
        }

        .answer-label {
            font-size: 0.9rem;
            font-weight: 600;
            color: #6c757d;
            margin-bottom: 8px;
            display: block;
        }

        .answer-text {
            padding: 10px 15px;
            border-radius: 6px;
            font-size: 1rem;
        }

        .your-answer {
            background: rgba(0, 123, 255, 0.1);
            border: 2px solid #007bff;
            color: #004085;
        }

        .your-answer.wrong {
            background: rgba(220, 53, 69, 0.1);
            border: 2px solid #dc3545;
            color: #721c24;
        }

        .correct-answer {
            background: rgba(40, 167, 69, 0.1);
            border: 2px solid #28a745;
            color: #155724;
            margin-top: 10px;
        }

        .action-buttons {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 30px;
            flex-wrap: wrap;
        }

        .btn-custom {
            padding: 12px 30px;
            border-radius: 25px;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }

        .btn-primary-custom {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .btn-primary-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        .btn-success-custom {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
        }

        .btn-success-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(40, 167, 69, 0.4);
        }

        .btn-secondary-custom {
            background: #6c757d;
            color: white;
        }

        .btn-secondary-custom:hover {
            background: #5a6268;
            transform: translateY(-2px);
        }

        @media (max-width: 768px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }

            .question-header {
                flex-direction: column;
                gap: 10px;
            }

            .question-text {
                margin: 10px 0;
            }

            .action-buttons {
                flex-direction: column;
            }

            .btn-custom {
                width: 100%;
                justify-content: center;
            }
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6c757d;
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 20px;
            opacity: 0.5;
        }
    </style>
@endsection

@section('content')
    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">
            <div class="row breadcrumbs-top widget-grid">
                <div class="col-12">
                    <div class="page-title mt-2">
                        <div class="row">
                            <div class="col-sm-12 ps-0">
                                @if (@isset($breadcrumbs))
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item">
                                            <a href="" style="display: flex;">
                                                <svg class="stroke-icon">
                                                    <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}">
                                                    </use>
                                                </svg>
                                            </a>
                                        </li>
                                        @foreach ($breadcrumbs as $breadcrumb)
                                            <li class="breadcrumb-item">
                                                @if (isset($breadcrumb['link']))
                                                    <a href="{{ $breadcrumb['link'] == 'javascript:void(0)' ? $breadcrumb['link'] : url($breadcrumb['link']) }}">
                                                @endif
                                                {{ $breadcrumb['name'] }}
                                                @if (isset($breadcrumb['link']))
                                                    </a>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ol>
                                @endisset
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="summary-container">
        <!-- Survey Completion Notice -->
        @if (session('success'))
            <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
                <i class="fas fa-check-circle me-2"></i>
                <strong>{{ session('success') }}</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

        <!-- Result Header -->
        <div class="result-header {{ $isPassed ? 'passed' : 'failed' }}">
            <div class="score-circle">
                {{ number_format($score, 1) }}%
            </div>
            <h2>
                @if ($isPassed)
                    <i class="fas fa-trophy"></i> {{ __('lms.Congratulations!') }}
                @else
                    <i class="fas fa-times-circle"></i> {{ __('lms.Try Again') }}
                @endif
            </h2>
            <p class="mb-0 mt-2" style="font-size: 1.2rem;">
                @if ($isPassed)
                    {{ __('lms.You have successfully passed the training!') }}
                @else
                    {{ __('lms.You need more practice. Keep learning!') }}
                @endif
            </p>
        </div>

        <!-- Statistics Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon total">
                    <i class="fas fa-question-circle"></i>
                </div>
                <div class="stat-number">{{ $totalQuestions }}</div>
                <div class="stat-label">{{ __('lms.Total Questions') }}</div>
            </div>

            <div class="stat-card">
                <div class="stat-icon correct">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div class="stat-number">{{ $correctAnswers }}</div>
                <div class="stat-label">{{ __('lms.Correct Answers') }}</div>
            </div>

            <div class="stat-card">
                <div class="stat-icon incorrect">
                    <i class="fas fa-times-circle"></i>
                </div>
                <div class="stat-number">{{ $incorrectAnswers }}</div>
                <div class="stat-label">{{ __('lms.Incorrect Answers') }}</div>
            </div>
        </div>

        <!-- Detailed Answers Section -->
        <div class="answers-section">
            <h3 class="section-title">
                <i class="fas fa-list-check"></i>
                {{ __('lms.Detailed Answers Review') }}
            </h3>

            @if (count($questionsWithAnswers) > 0)
                @foreach ($questionsWithAnswers as $index => $item)
                    <div class="question-item {{ $item['is_correct'] ? 'correct' : 'incorrect' }}">
                        <div class="question-header">
                            <span class="question-number">{{ $index + 1 }}</span>
                            <div class="question-text">{{ $item['question']->localized_question ?? $item['question']->question }}</div>
                            <span class="question-status {{ $item['is_correct'] ? 'correct' : 'incorrect' }}">
                                @if ($item['is_correct'])
                                    <i class="fas fa-check"></i> {{ __('lms.Correct') }}
                                @else
                                    <i class="fas fa-times"></i> {{ __('lms.Incorrect') }}
                                @endif
                            </span>
                        </div>

                        <div class="answer-box">
                            <!-- Your Answer -->
                            <span class="answer-label">
                                <i class="fas fa-user"></i> {{ __('lms.Your Answer') }}:
                            </span>
                            <div class="answer-text your-answer {{ !$item['is_correct'] ? 'wrong' : '' }}">
                                @if ($item['question']->question_type == 'multi_choise')
                                    {{ $item['user_answer_text'] ?? __('lms.No answer provided') }}
                                @else
                                    {{ $item['user_answer'] == 1 ? __('lms.True') : __('lms.False') }}
                                @endif
                            </div>

                            <!-- Correct Answer (only show if wrong) -->
                            @if (!$item['is_correct'])
                                <span class="answer-label mt-3">
                                    <i class="fas fa-check-circle"></i> {{ __('lms.Correct Answer') }}:
                                </span>
                                <div class="answer-text correct-answer">
                                    @if ($item['question']->question_type == 'multi_choise')
                                        {{ $item['correct_answer_text'] }}
                                    @else
                                        {{ $item['question']->correct_answer == 1 ? __('lms.True') : __('lms.False') }}
                                    @endif
                                </div>
                            @endif
                        </div>
                    </div>
                @endforeach
            @else
                <div class="empty-state">
                    <i class="fas fa-inbox"></i>
                    <p>{{ __('lms.No questions found') }}</p>
                </div>
            @endif
        </div>

        <!-- Action Buttons -->
        <div class="action-buttons">
            @if (!$isPassed && $remainingAttempts > 0)
                <a href="{{ route('user.lms.training.modules.getQuiz', $trainingModule->id) }}"
                   class="btn-custom btn-primary-custom">
                    <i class="fas fa-redo"></i>
                    {{ __('lms.Try Again') }} ({{ $remainingAttempts }} {{ __('lms.attempts left') }})
                </a>
            @endif

            <a href="{{ route('user.lms.training.modules.index') }}" class="btn-custom btn-secondary-custom">
                <i class="fas fa-home"></i>
                {{ __('lms.Back to Training Modules') }}
            </a>
        </div>
    </div>
@endsection

@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
@endsection

@section('page-script')
    <script>
        $(document).ready(function() {
            // Animate stats on page load
            $('.stat-number').each(function() {
                const $this = $(this);
                const countTo = parseInt($this.text());

                $({ countNum: 0 }).animate({
                    countNum: countTo
                }, {
                    duration: 1500,
                    easing: 'swing',
                    step: function() {
                        $this.text(Math.floor(this.countNum));
                    },
                    complete: function() {
                        $this.text(this.countNum);
                    }
                });
            });

            // Animate question items
            $('.question-item').each(function(index) {
                $(this).css({
                    'opacity': '0',
                    'transform': 'translateY(20px)'
                });

                setTimeout(() => {
                    $(this).css({
                        'transition': 'all 0.5s ease',
                        'opacity': '1',
                        'transform': 'translateY(0)'
                    });
                }, index * 100);
            });
        });
    </script>
@endsection
