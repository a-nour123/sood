<?php

namespace App\Jobs;

use App\Http\Traits\PhishingMailTrait;
use App\Mail\PhishingEmail;
use App\Models\PhishingEmployeeList;
use App\Models\PhishingMailTracking;
use App\Models\PhishingTemplate;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\PHPMailer;

class SendCampaignEmailsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, SerializesModels, PhishingMailTrait;

    protected $campaign;
    protected $employees;
    protected $emailTemplates;

    public function __construct($campaign,$employees, $emailTemplates)
    {
        $this->employees = $employees;
        $this->campaign = $campaign;
        $this->emailTemplates = $emailTemplates;
    }

    public function handle()
    {
        // Load all necessary relationships if not already loaded
        $this->emailTemplates->load([
            'senderProfile.domain',
            'website.domain'
        ]);
        
        foreach ($this->emailTemplates as $mail) {
            // Validate sender profile exists
            if (!$mail->senderProfile) {
                Log::error('Email template missing sender profile', [
                    'template_id' => $mail->id,
                    'campaign_id' => $this->campaign->id
                ]);
                continue; // Skip this template
            }

            $emailCount = 0;
            $maxRetries = 2;
            
            foreach ($this->employees as $employee) {
                $retryCount = 0;
                $emailSent = false;
                
                while ($retryCount < $maxRetries && !$emailSent) {
                    try {
                        // Minimal delay between emails (2 seconds default, configurable via .env)
                        if ($emailCount > 0) {
                            $delaySeconds = (int)env('PHISHING_EMAIL_DELAY', 2);
                            if ($delaySeconds > 0) {
                                sleep($delaySeconds);
                            }
                        }
                        
                        $mailObject = new PhishingEmail($mail, $employee, $this->campaign->id);
                        $senderEmail = $this->getSenderEmail($mail);
                        $isSent = $this->sendPhishingMail2($senderEmail, $mail, $employee->email, $mailObject);
                        
                        if ($isSent) {
                            PhishingMailTracking::updateOrCreate([
                                'campaign_id' => $this->campaign->id,
                                'email_id' => $mail->id,
                                'employee_id' => $employee->id,
                            ]);
                            
                            $this->updateCampaignStatus($mail, $employee);
                            $emailCount++;
                            $emailSent = true;
                        } else {
                            $retryCount++;
                            if ($retryCount < $maxRetries) {
                                sleep(2);
                            }
                        }
                    } catch (\Exception $e) {
                        $errorMessage = $e->getMessage();
                        $isRateLimit = strpos($errorMessage, 'rate') !== false || 
                                      strpos($errorMessage, '421') !== false ||
                                      strpos($errorMessage, '4.4.2') !== false;
                        
                        if ($isRateLimit && $retryCount < $maxRetries) {
                            // For rate limit, wait shorter time and retry
                            $waitSeconds = 15 * ($retryCount + 1);
                            sleep($waitSeconds);
                            $retryCount++;
                        } else {
                            $retryCount++;
                            if ($retryCount < $maxRetries) {
                                sleep(1);
                            }
                        }
                    }
                }
                
                if (!$emailSent) {
                    Log::error('Failed to send email after all retries', [
                        'template_id' => $mail->id,
                        'employee_id' => $employee->id,
                        'campaign_id' => $this->campaign->id
                    ]);
                }
            }
        }
    }

    /**
     * Get sender email from template's sender profile
     */
    protected function getSenderEmail($mail)
    {
        if (!$mail->senderProfile) {
            Log::error('Sender profile not found for template', ['template_id' => $mail->id]);
            return config('mail.from.address', 'noreply@example.com'); // Fallback
        }

        if ($mail->senderProfile->type === 'managed') {
            $domain = DB::table('phishing_domains')
                ->where('id', $mail->senderProfile->website_domain_id)
                ->value('name');
            
            if (!$domain) {
                Log::error('Domain not found for managed sender profile', [
                    'sender_profile_id' => $mail->senderProfile->id,
                    'domain_id' => $mail->senderProfile->website_domain_id
                ]);
                return config('mail.from.address', 'noreply@example.com'); // Fallback
            }
            
            return $mail->senderProfile->from_address_name . $domain;
        } else {
            return $mail->senderProfile->from_address_name;
        }
    }

    protected function updateCampaignStatus($mail, $employee)
    {
        try {
            switch ($this->campaign->campaign_type) {
                case "simulated_phishing":
                    $this->updateSimulatedPhishing($mail, $employee);
                    break;

                case "simulated_phishing_and_security_awareness":
                    $this->updateSimulatedPhishingAndAwareness($mail, $employee);
                    break;
                default:
                    Log::error("Failed to update PhishingEmployeeList records: Invalid campaign type.", [
                        'campaign_id' => $this->campaign->id ?? null,
                        'campaign_type' => $this->campaign->campaign_type ?? null
                    ]);
            }
        } catch (\Exception $e) {
            Log::error("Failed to update PhishingEmployeeList records", [
                'campaign_id' => $this->campaign->id ?? null,
                'mail_id' => $mail->id ?? null,
                'employee_id' => $employee->id ?? null,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
        }
    }

    protected function updateSimulatedPhishing($mail, $employee)
    {
        DB::beginTransaction(); // Start a transaction

        try {
            // Update the phishing_campaign_employee_list table
            $updateEmployee = DB::table('phishing_campaign_employee_list')
                ->where('campaign_id', $this->campaign->id)
                ->where('employee_id', $employee->id)
                ->update(['is_delivered' => 1]);

            // Check if the first query was successful
            if ($updateEmployee === false) {
                throw new \Exception('Failed to update phishing_campaign_employee_list');
            }

            // Update the phishing_campaign_email_template table
            $updateTemplate = DB::table('phishing_campaign_email_template')
                ->where('campaign_id', $this->campaign->id)
                ->where('email_template_id', $mail->id)
                ->update(['is_delivered' => 1]);

            // Check if the second query was successful
            if ($updateTemplate === false) {
                throw new \Exception('Failed to update phishing_campaign_email_template');
            }

            // Check if all emails and employees have been delivered before updating delivery_status
            $totalEmployees = DB::table('phishing_campaign_employee_list')
                ->where('campaign_id', $this->campaign->id)
                ->count();
            
            $deliveredEmployees = DB::table('phishing_campaign_employee_list')
                ->where('campaign_id', $this->campaign->id)
                ->where('is_delivered', 1)
                ->count();

            $totalTemplates = DB::table('phishing_campaign_email_template')
                ->where('campaign_id', $this->campaign->id)
                ->count();
            
            $deliveredTemplates = DB::table('phishing_campaign_email_template')
                ->where('campaign_id', $this->campaign->id)
                ->where('is_delivered', 1)
                ->count();

            // Only update delivery_status if ALL emails have been sent to ALL employees
            $totalExpected = $totalEmployees * $totalTemplates;
            $totalDelivered = $deliveredEmployees * $deliveredTemplates;

            if ($totalDelivered >= $totalExpected && $totalExpected > 0) {
                // Get campaign to check frequency
                $campaign = DB::table('phishing_campaigns')->where('id', $this->campaign->id)->first();
                
                // For recurring campaigns, reset delivery_status to 0 for next send
                // For one-time campaigns, set delivery_status to 1 and status to finished
                if ($campaign && in_array($campaign->campaign_frequency, ['weekly', 'monthly', 'quarterly'])) {
                    // Recurring campaign: reset delivery_status and keep status as inProgress
                    $updateCampaign = DB::table('phishing_campaigns')
                        ->where('id', $this->campaign->id)
                        ->update([
                            'delivery_status' => 0, // Reset for next send
                            'status' => 'inProgress' // Keep as inProgress for recurring campaigns
                        ]);
                } else {
                    // One-time campaign: mark as delivered and finished
                    $updateCampaign = DB::table('phishing_campaigns')
                        ->where('id', $this->campaign->id)
                        ->update([
                            'delivery_status' => 1,
                            'status' => 'finsihed' // Mark as finished
                        ]);
                }

                // Check if the update was successful
                if ($updateCampaign === false) {
                    throw new \Exception('Failed to update phishing_campaigns');
                }
            }

            // Commit the transaction if all queries are successful
            DB::commit();
            return true; // All queries were successful

        } catch (\Exception $e) {
            // Rollback the transaction if any query fails
            DB::rollBack();

            // Log the error for debugging
            Log::error('Error in updateSimulatedPhishing (Job)', [
                'error' => $e->getMessage(),
                'campaign_id' => $this->campaign->id ?? null,
                'mail_id' => $mail->id ?? null,
                'employee_id' => $employee->id ?? null,
                'trace' => $e->getTraceAsString()
            ]);

            return false; // Indicate failure
        }
    }

    protected function updateSimulatedPhishingAndAwareness($mail, $employee)
    {
        DB::beginTransaction();

        try {
            DB::table('phishing_campaign_employee_list')
                ->where('campaign_id', $this->campaign->id)
                ->where('employee_id', $employee->id)
                ->update(['is_delivered' => 1]);

            DB::table('phishing_campaign_email_template')
                ->where('campaign_id', $this->campaign->id)
                ->where('email_template_id', $mail->id)
                ->update(['is_delivered' => 1]);

            // Check if all emails and employees have been delivered
            $totalEmployees = DB::table('phishing_campaign_employee_list')
                ->where('campaign_id', $this->campaign->id)
                ->count();
            
            $deliveredEmployees = DB::table('phishing_campaign_employee_list')
                ->where('campaign_id', $this->campaign->id)
                ->where('is_delivered', 1)
                ->count();

            $totalTemplates = DB::table('phishing_campaign_email_template')
                ->where('campaign_id', $this->campaign->id)
                ->count();
            
            $deliveredTemplates = DB::table('phishing_campaign_email_template')
                ->where('campaign_id', $this->campaign->id)
                ->where('is_delivered', 1)
                ->count();

            // Only update training modules and delivery_status if all emails are delivered
            if ($deliveredEmployees >= $totalEmployees && $deliveredTemplates >= $totalTemplates && $totalEmployees > 0 && $totalTemplates > 0) {
                DB::table('phising_campaign_training_module')
                    ->where('campaign_id', $this->campaign->id)
                    ->update(['is_delivered' => 1]);

                // Get campaign to check frequency
                $campaign = DB::table('phishing_campaigns')->where('id', $this->campaign->id)->first();
                
                // For recurring campaigns, reset delivery_status to 0 for next send
                // For one-time campaigns, set delivery_status to 1 and status to finished
                if ($campaign && in_array($campaign->campaign_frequency, ['weekly', 'monthly', 'quarterly'])) {
                    // Recurring campaign: reset delivery_status and keep status as inProgress
                    DB::table('phishing_campaigns')
                        ->where('id', $this->campaign->id)
                        ->update([
                            'delivery_status' => 0, // Reset for next send
                            'status' => 'inProgress' // Keep as inProgress for recurring campaigns
                        ]);
                } else {
                    // One-time campaign: mark as delivered and finished
                    DB::table('phishing_campaigns')
                        ->where('id', $this->campaign->id)
                        ->update([
                            'delivery_status' => 1,
                            'status' => 'finsihed' // Mark as finished
                        ]);
                }
            }

            DB::commit();
            return true;
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error in updateSimulatedPhishingAndAwareness (Job)', [
                'error' => $e->getMessage(),
                'campaign_id' => $this->campaign->id ?? null,
                'mail_id' => $mail->id ?? null,
                'employee_id' => $employee->id ?? null,
                'trace' => $e->getTraceAsString()
            ]);
            return false;
        }
    }


}
