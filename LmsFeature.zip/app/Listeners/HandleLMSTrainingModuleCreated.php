<?php

namespace App\Listeners;

use App\Events\LMSTrainingModuleCreated;
use App\Http\Traits\NotificationHandlingTrait;
use App\Models\Action;
use App\Models\User;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class HandleLMSTrainingModuleCreated
{
    use NotificationHandlingTrait;

    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  object  $event
     * @return void
     */
    public function handle(LMSTrainingModuleCreated $event)
    {
        // getting the action id of event
        $action1 = Action::where('name', 'AddNewLMSTrainingModule')->first();
        $actionId1 = $action1['id'];
        // Getting the model from the event
        $lmsTrainingModule = $event->lmsTrainingModule;

        $lmsTrainingModule->load('level.course');
         // Define the roles array for notification
        $roles = [];
        // $lmsTrainingModule->course_name = $lmsTrainingModule->level?->course?->title ?? '';
        $lmsTrainingModule->course_name = optional(optional($lmsTrainingModule->level)->course)->title ?? '';
        // $lmsTrainingModule->course_level = $lmsTrainingModule->level?->title ?? '';
        $lmsTrainingModule->course_level = optional($lmsTrainingModule->level)->title ?? '';

        // defining the link we want the user to be redirected to after clicking the system notification
        $link = ['link' => route('admin.lms.courses.index')];
        // dd($action1,$link ,$policy, $roles, $action1);

        $actionId2 = null;
        $nextDateNotify = null;
        $modelId = null;
        $modelType = null;
        $proccess = null;
        // handling different kinds of notifications using  "sendNotificationForAction" function from "NotificationHandlingTrait"
        $this->sendNotificationForAction($actionId1, $actionId2 = null, $link, $lmsTrainingModule, $roles, $nextDateNotify = null, $modelId = null, $modelType = null, $proccess = null);
    }
}
