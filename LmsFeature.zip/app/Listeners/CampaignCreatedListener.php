<?php

namespace App\Listeners;

use App\Events\CampaignCreated;
use App\Http\Traits\NotificationHandlingTrait;
use App\Models\Action;
use App\Models\User;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class CampaignCreatedListener
{
    use NotificationHandlingTrait;
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  object  $event
     * @return void
     */
    public function handle(CampaignCreated $event)
    {
        // getting the action id of event
        $action1 = Action::where('name', 'create_campaign')->first();
        $actionId1 = $action1['id'];
        // Getting the model from the event
        $phishingCampaign = $event->phishingCampaign;

        $usersId = User::select('id')->where('enabled', 1)->pluck('id')->toArray();

        // Define the roles array for notification
        $roles = [
            'system-users' => $usersId ?? null,
        ];

        // defining the link we want the user to be redirected to after clicking the system notification
        $link = ['link' => route('admin.phishing.campaign.index')];
        // dd($action1,$link ,$policy, $roles, $action1);

        $actionId2 = null;
        $nextDateNotify = null;
        $modelId = null;
        $modelType = null;
        $proccess = null;
        // handling different kinds of notifications using  "sendNotificationForAction" function from "NotificationHandlingTrait"
        $this->sendNotificationForAction($actionId1, $actionId2 = null, $link, $phishingCampaign, $roles, $nextDateNotify = null, $modelId = null, $modelType = null, $proccess = null);
    }
}
