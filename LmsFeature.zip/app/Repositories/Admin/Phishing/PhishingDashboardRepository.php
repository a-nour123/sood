<?php

namespace App\Repositories\Admin\Phishing;

use App\Interfaces\Admin\Phishing\PhishingDashboardInterface;
use App\Models\LMSCourse;
use App\Models\LMSTrainingModule;
use App\Models\PhishingCampaign;
use App\Models\PhishingDomains;
use App\Models\PhishingGroup;
use App\Models\PhishingTemplate;
use App\Models\PhishingWebsitePage;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class PhishingDashboardRepository implements PhishingDashboardInterface
{
    /**
     * Get date range from request or use defaults
     */
    protected function getDateRange(Request $request = null)
    {
        $startDate = $request && $request->has('start_date')
            ? Carbon::parse($request->start_date)->startOfDay()
            : Carbon::now()->subYear()->startOfDay();

        $endDate = $request && $request->has('end_date')
            ? Carbon::parse($request->end_date)->endOfDay()
            : Carbon::now()->endOfDay();

        return [$startDate, $endDate];
    }
    public function index()
    {
        $breadcrumbs = [
            ['link' => route('admin.phishing.dashboard'), 'name' => __('locale.Dashboard')],
            ['link' => route('admin.phishing.campaign.index'), 'name' => __('phishing.campaign')],
            ['name' => __('phishing.campaign_pdf')],
        ];
        $websites = PhishingWebsitePage::withoutTrashed()->count();

        // $campaigns = PhishingCampaign::withoutTrashed()->count();
        // $phishingCampaigns = PhishingCampaign::withoutTrashed()->where('campaign_type','simulated_phishing')->count();
        // $awarenessCampaigns = PhishingCampaign::withoutTrashed()->where('campaign_type','security_awareness')->count();
        // $pendingCampaigns = PhishingCampaign::withoutTrashed()->where('approve',0)->count();
        // $approveCampaigns = PhishingCampaign::withoutTrashed()->where('approve',1)->count();
        // $scheduledCampaigns = PhishingCampaign::withoutTrashed()->where('delivery_type','setup')->count();


        $campaigns_count = PhishingCampaign::withoutTrashed()->count();
        $campaigns_approve = PhishingCampaign::withoutTrashed()->where('campaign_type','simulated_phishing')->where('approve',1)->count();
        $campaigns_pending = PhishingCampaign::withoutTrashed()->where('campaign_type','simulated_phishing')->where('approve',0)->count();
        $campaigns_complete = PhishingCampaign::withoutTrashed()->where('campaign_type','simulated_phishing')->where('delivery_status',1)->count();
        $campaigns_later = PhishingCampaign::withoutTrashed()->where('campaign_type','simulated_phishing')->where('delivery_type','later')->where('approve',0)->count();


        $now = Carbon::now();
        $campaigns_soon = PhishingCampaign::withoutTrashed()
        ->where('campaign_type','simulated_phishing')
        ->where('delivery_type', 'setup')
        ->where(function ($query) use ($now) {
            $query->where('schedule_date_from', '>', $now->toDateString())
                ->orWhere(function ($query) use ($now) {
                    $query->where('schedule_date_from', '=', $now->toDateString())
                          ->where('schedule_time_from', '>', $now->toTimeString());
                });
        })
        ->count();


        $mailTemplates = PhishingTemplate::withoutTrashed()->count();
        $employees = DB::table('phishing_campaign_employee_list')->distinct('employee_id')->count('employee_id');
        $top_phished_employees = $this->getTopPhisedEmployee();

        $phishingemployees = DB::table('phishing_campaign_employee_list')->distinct('employee_id')->count('employee_id');
        $trainingemployees = DB::table('l_m_s_user_training_modules')->distinct('user_id')->count('user_id');
        $allTargetedEmployees = $phishingemployees + $trainingemployees;

        // dd($top_phished_employees[0]);

        $courses = LMSCourse::withoutTrashed()->count();
        $trainings = LMSTrainingModule::withoutTrashed()->count();

        // Mail statistics
        $mail_statistic = PhishingTemplate::withoutTrashed()
        ->with(['campaignes' => function ($query) {
            $query->withCount('deliverdEmployees');
        }])
        ->withCount('openedMails','clickedOnLink','submitedDataInMails','downloadedFileInMails','mailTracking')->get();
        $email_labels = $mail_statistic->pluck('name');
        $opened_mails_count = $mail_statistic->pluck('opened_mails_count');
        $clicked_link_count = $mail_statistic->pluck('clicked_on_link_count');
        $submited_data_in_mails_count = $mail_statistic->pluck('submited_data_in_mails_count');
        $downloaded_file_in_mails_count = $mail_statistic->pluck('downloaded_file_in_mails_count');
        $employee_count = $mail_statistic->map(function ($template) {
            return $template->campaignes->sum('deliverd_employees_count');
        });

        // Training Statistic
        $trainings_statistic = $this->getTrainingStatistics();
        $training_labels = $trainings_statistic->pluck('month');
        $training_total_recieved_users = $trainings_statistic->pluck('total_recieved_users');
        $training_total_passed_users = $trainings_statistic->pluck('total_passed_users');
        $training_total_failed_users = $trainings_statistic->pluck('total_failed_users');
        $training_total_overdue_users = $trainings_statistic->pluck('total_overdue_users');

        return view('admin.content.phishing.dashboard.index', get_defined_vars());
    }

    public function getMailStatistic(Request $request = null)
    {
        [$startDate, $endDate] = $this->getDateRange($request);

        return DB::table('phishing_mail_trackings')
            ->selectRaw("
                DATE_FORMAT(created_at, '%b \'%y') as month,
                COUNT(CASE WHEN Page_link_clicked_at IS NOT NULL THEN 1 END) AS clicked_link,
                COUNT(CASE WHEN opened_at IS NOT NULL THEN 1 END) AS mails_opened,
                COUNT(CASE WHEN submited_at IS NOT NULL THEN 1 END) AS mails_submitted,
                COUNT(CASE WHEN downloaded_at IS NOT NULL THEN 1 END) AS mails_downloaded
            ")
            ->whereBetween('created_at', [$startDate, $endDate])
            ->where(function($query) {
                $query->whereNotNull('opened_at')->orWhereNotNull('submited_at')->orWhereNotNull('downloaded_at');
            })
            ->groupBy('month')
            ->orderBy(DB::raw("STR_TO_DATE(month, '%b \'%y')"), 'ASC')
            ->get();
    }

    public function getTopPhisedEmployee()
    {
        return DB::table('phishing_mail_trackings')
            ->join('users', 'phishing_mail_trackings.employee_id', '=', 'users.id')
            ->select(
                'phishing_mail_trackings.employee_id',
                'users.name','users.email',
                DB::raw('
                    COUNT(*) as total_rows,
                    SUM(
                        CASE
                            WHEN opened_at IS NOT NULL AND submited_at IS NOT NULL AND downloaded_at IS NOT NULL AND Page_link_clicked_at IS NOT NULL THEN 100
                            ELSE
                                (CASE WHEN opened_at IS NOT NULL THEN 25 ELSE 0 END) +
                                (CASE WHEN submited_at IS NOT NULL THEN 25 ELSE 0 END) +
                                (CASE WHEN Page_link_clicked_at IS NOT NULL THEN 25 ELSE 0 END) +
                                (CASE WHEN downloaded_at IS NOT NULL THEN 25 ELSE 0 END)
                        END
                    ) AS total_points
                ')
            )
            ->groupBy('phishing_mail_trackings.employee_id')
            ->orderByDesc('total_points')
            ->limit(5)
            ->get()
            ->map(function ($employee) {
                // $maxPossiblePoints = $employee->total_rows * 250;
                // $employee->average_percentage = number_format(($employee->total_points / $maxPossiblePoints) * 100,2);

                $maxPossiblePoints = $employee->total_rows * 100;
                $employee->average_percentage = number_format(($employee->total_points / $maxPossiblePoints) * 100,2);
                return $employee;
            })
            ->sortByDesc('average_percentage')
            ->values()
            ->take(5);

    }


    public function getPhisedEmployee(Request $request = null)
    {
        [$startDate, $endDate] = $this->getDateRange($request);

        return DB::table('phishing_mail_trackings')
            ->join('users', 'phishing_mail_trackings.employee_id', '=', 'users.id')
            ->whereBetween('phishing_mail_trackings.created_at', [$startDate, $endDate])
            ->select(
                'phishing_mail_trackings.employee_id',
                'users.name','users.email',
                DB::raw('
                    COUNT(*) as total_rows,
                    SUM(
                        CASE
                            WHEN opened_at IS NOT NULL AND submited_at IS NOT NULL AND downloaded_at IS NOT NULL AND Page_link_clicked_at IS NOT NULL THEN 100
                            ELSE
                                (CASE WHEN opened_at IS NOT NULL THEN 25 ELSE 0 END) +
                                (CASE WHEN submited_at IS NOT NULL THEN 25 ELSE 0 END) +
                                (CASE WHEN Page_link_clicked_at IS NOT NULL THEN 25 ELSE 0 END) +
                                (CASE WHEN downloaded_at IS NOT NULL THEN 25 ELSE 0 END)
                        END
                    ) AS total_points
                ')
            )
            ->groupBy('phishing_mail_trackings.employee_id')
            ->orderByDesc('total_points')
            ->get()
            ->map(function ($employee) {
                $maxPossiblePoints = $employee->total_rows * 100;
                $employee->average_percentage = number_format(($employee->total_points / $maxPossiblePoints) * 100,2);
                return $employee;
            })
            ->sortByDesc('average_percentage')
            ->values();
    }

    public function reporting(Request $request = null)
    {
        $breadcrumbs = [
            ['link' => route('admin.phishing.dashboard'), 'name' => __('locale.Dashboard')],
        ];
        [$startDate, $endDate] = $this->getDateRange($request);

        $campaigns = PhishingCampaign::withoutTrashed()
            ->whereBetween('created_at', [$startDate, $endDate])
            ->count();
        $mailTemplates = PhishingTemplate::withoutTrashed()->count();

        // **************************** Mail statistics *******************************
        $mail_statistic = $this->getMailStatistic($request);
        $labels = $mail_statistic->pluck('month');
        $opened_count = $mail_statistic->pluck('mails_opened');
        $clicked_link_count = $mail_statistic->pluck('clicked_link');
        $submited_count = $mail_statistic->pluck('mails_submitted');
        $downloaded_count = $mail_statistic->pluck('mails_downloaded');

        // Additional Statistics
        $totalEmailsOpened = $mail_statistic->sum('mails_opened');
        $totalLinksClicked = $mail_statistic->sum('clicked_link');
        $totalFilesDownloaded = $mail_statistic->sum('mails_downloaded');
        $totalFormsSubmitted = $mail_statistic->sum('mails_submitted');

        // Get total unique employees targeted
        $totalEmployeesTargeted = DB::table('phishing_campaign_employee_list')
            ->whereBetween('created_at', [$startDate, $endDate])
            ->distinct('employee_id')
            ->count('employee_id');

        // Get total emails delivered
        $totalEmailsDelivered = DB::table('phishing_mail_trackings')
            ->whereBetween('created_at', [$startDate, $endDate])
            ->count();

        $activeCampaigns = $this->getActiveCampaignMailStatistic($request);
        $archivedCampaigns =  $this->getArchivedCampaignMailStatistic($request);


        // ************************* Campaign statistics *********************************
        $campaignChart = PhishingCampaign::where("campaign_type","simulated_phishing")
            ->withoutTrashed()
            ->whereBetween('created_at', [$startDate, $endDate])
            ->withCount([
                'deliverdEmailTemplates',
                'deliverdEmployees',
                'notDeliverdEmailTemplates',
                'notDeliverdEmployees',
                'openedTrackings',
                'downloadedTrackings',
                'clickedTrackings',
                'submittedTrackings'
            ])
            ->get();

        $campaig_labels = $campaignChart->pluck('campaign_name');
        $deliverd_email_templates_count = $campaignChart->pluck('deliverd_email_templates_count');
        $deliverd_employees_count = $campaignChart->pluck('deliverd_employees_count');
        $not_deliverd_email_templates_count = $campaignChart->pluck('not_deliverd_email_templates_count');
        $not_deliverd_employees_count = $campaignChart->pluck('not_deliverd_employees_count');
        $campaign_opened_mails_count = $campaignChart->pluck('opened_trackings_count');
        $campaign_clicked_link_mails_count = $campaignChart->pluck('clicked_trackings_count');
        $campaign_download_files_mails_count = $campaignChart->pluck('downloaded_trackings_count');
        $campaign_submit_data_mails_count = $campaignChart->pluck('submitted_trackings_count');


        // *********************** organization statistics Way 1 ***************************

        // $phishGroups = PhishingGroup::withoutTrashed()
        // ->withCount('users')
        // ->with(['users.deliverdCampaigns.deliverdEmailTemplates' => function ($query) {
        //     $query->withCount(['openedMails','submitedDataInMails','clickedOnLink','downloadedFileInMails']);
        // }])
        // ->with(['users.deliverdCampaigns' => function ($query) {
        //     $query->withCount(['deliverdEmailTemplates','deliverdEmployees','notDeliverdEmailTemplates','notDeliverdEmployees']);
        // }])
        // ->with(['users' => function ($query) {
        //     $query->withCount('deliverdCampaigns');
        // }])
        // ->get();
        // $phish_groups_labels = $phishGroups->pluck('name');
        // $phish_groups_employee_count = $phishGroups->pluck('users_count');
        // $phish_groups_campaign_count = $phishGroups->map(function ($group) {
        //     return $group->users->sum('deliverd_campaigns_count');
        // });

        // $phish_groups_deliverd_email_templates_count = $phishGroups->map(function ($group) {
        //     return $group->users->sum(function ($user) {
        //         return $user->deliverdCampaigns->sum('deliverd_email_templates_count');
        //     });
        // });

        // $phish_groups_deliverd_employees_count = $phishGroups->map(function ($group) {
        //     return $group->users->sum(function ($user) {
        //         return $user->deliverdCampaigns->sum('deliverd_employees_count');
        //     });
        // });

        // $phish_groups_not_deliverd_email_templates_count = $phishGroups->map(function ($group) {
        //     return $group->users->sum(function ($user) {
        //         return $user->deliverdCampaigns->sum('not_deliverd_email_templates_count');
        //     });
        // });

        // $phish_groups_not_deliverd_employees_count = $phishGroups->map(function ($group) {
        //     return $group->users->sum(function ($user) {
        //         return $user->deliverdCampaigns->sum('not_deliverd_employees_count');
        //     });
        // });

        // $phish_groups_opened_mails_count = $phishGroups->map(function ($group) {
        //     return $group->users->sum(function ($user) {
        //         return $user->deliverdCampaigns->sum(function ($campaign) {
        //             return $campaign->deliverdEmailTemplates->sum('opened_mails_count');
        //         });
        //     });
        // });

        // $phish_groups_submited_data_in_mails_count = $phishGroups->map(function ($group) {
        //     return $group->users->sum(function ($user) {
        //         return $user->deliverdCampaigns->sum(function ($campaign) {
        //             return $campaign->deliverdEmailTemplates->sum('submited_data_in_mails_count');
        //         });
        //     });
        // });

        // $phish_groups_downloaded_file_in_mails_count = $phishGroups->map(function ($group) {
        //     return $group->users->sum(function ($user) {
        //         return $user->deliverdCampaigns->sum(function ($campaign) {
        //             return $campaign->deliverdEmailTemplates->sum('downloaded_file_in_mails_count');
        //         });
        //     });
        // });
        // $phish_groups_click_link_in_mails_count = $phishGroups->map(function ($group) {
        //     return $group->users->sum(function ($user) {
        //         return $user->deliverdCampaigns->sum(function ($campaign) {
        //             return $campaign->deliverdEmailTemplates->sum('clicked_on_link_count');
        //         });
        //     });
        // });

        // *********************** organization statistics Way 2 ***************************
        $phishGroups = PhishingGroup::withoutTrashed()
        ->withCount('users')
        ->with([
            'users' => function ($query) use ($startDate, $endDate) {
                $query->withCount([
                    'deliverdCampaigns' => function ($q) use ($startDate, $endDate) {
                        $q->where('phishing_campaigns.campaign_type', 'simulated_phishing')
                          ->whereBetween('phishing_campaigns.created_at', [$startDate, $endDate]);
                    }
                ])
                ->with(['deliverdCampaigns' => function ($query) use ($startDate, $endDate) {
                    $query->where('phishing_campaigns.campaign_type', 'simulated_phishing')
                          ->whereBetween('phishing_campaigns.created_at', [$startDate, $endDate])
                          ->withCount([
                              'deliverdEmailTemplates as deliverd_email_templates_count',
                              'deliverdEmployees as deliverd_employees_count',
                              'notDeliverdEmailTemplates as not_deliverd_email_templates_count',
                              'notDeliverdEmployees as not_deliverd_employees_count'
                          ]);
                }]);
            },
        ])
        ->get();

        // Get phishing campaign IDs in date range to filter tracking data
        $campaignIdsInRange = PhishingCampaign::where('campaign_type', 'simulated_phishing')
            ->whereBetween('created_at', [$startDate, $endDate])
            ->pluck('id')
            ->toArray();

        // Calculate filtered counts manually
        $phishGroups = $phishGroups->map(function ($group) use ($startDate, $endDate, $campaignIdsInRange) {
            $group->users->each(function ($user) use ($startDate, $endDate, $campaignIdsInRange) {
                $user->opened_mails_count = $user->openedMails()
                    ->whereIn('phishing_mail_trackings.campaign_id', $campaignIdsInRange)
                    ->whereBetween('phishing_mail_trackings.opened_at', [$startDate, $endDate])
                    ->count();
                $user->submited_data_in_mails_count = $user->submitedDataInMails()
                    ->whereIn('phishing_mail_trackings.campaign_id', $campaignIdsInRange)
                    ->whereBetween('phishing_mail_trackings.submited_at', [$startDate, $endDate])
                    ->count();
                $user->downloaded_file_in_mails_count = $user->downloadedFileInMails()
                    ->whereIn('phishing_mail_trackings.campaign_id', $campaignIdsInRange)
                    ->whereBetween('phishing_mail_trackings.downloaded_at', [$startDate, $endDate])
                    ->count();
                $user->clicked_link_in_mails_count = $user->clickedLinkInMails()
                    ->whereIn('phishing_mail_trackings.campaign_id', $campaignIdsInRange)
                    ->whereBetween('phishing_mail_trackings.Page_link_clicked_at', [$startDate, $endDate])
                    ->count();
            });
            return $group;
        });

        $phish_groups_labels = $phishGroups->pluck('name');
        $phish_groups_employee_count = $phishGroups->pluck('users_count');

        $phish_groups_campaign_count = $phishGroups->map(function ($group) {
            $campaigns = $group->users
                ->flatMap(function ($user) {
                    return $user->deliverdCampaigns;
                })
                ->unique('id');

            return $campaigns->count();
        });

        $phish_groups_deliverd_email_templates_count = $phishGroups->map(function ($group) {
            $campaigns = $group->users
                ->flatMap(function ($user) {
                    return $user->deliverdCampaigns;
                })
                ->unique('id');

            return $campaigns->sum('deliverd_email_templates_count');
        });

        $phish_groups_deliverd_employees_count = $phishGroups->map(function ($group) {
            return $group->users
                ->filter(function ($user) {
                    return $user->deliverdCampaigns->isNotEmpty();
                })
                ->count();
        });

        $phish_groups_not_deliverd_email_templates_count = $phishGroups->map(function ($group) {
            return $group->users->sum('not_deliverd_email_templates_count');
        });

        $phish_groups_not_deliverd_employees_count = $phishGroups->map(function ($group) {
            return $group->users->sum('not_deliverd_employees_count');
        });

        $phish_groups_opened_mails_count = $phishGroups->map(function ($group) {
            return $group->users->sum('opened_mails_count');
        });

        $phish_groups_submited_data_in_mails_count = $phishGroups->map(function ($group) {
            return $group->users->sum('submited_data_in_mails_count');
        });

        $phish_groups_downloaded_file_in_mails_count = $phishGroups->map(function ($group) {
            return $group->users->sum('downloaded_file_in_mails_count');
        });

        $phish_groups_click_link_in_mails_count = $phishGroups->map(function ($group) {
            return $group->users->sum('clicked_link_in_mails_count');
        });


        // ******************************** Employee statistic *********************
        // Get campaign IDs in date range to filter tracking data
        $employeeCampaignIdsInRange = PhishingCampaign::whereBetween('created_at', [$startDate, $endDate])
            ->pluck('id')
            ->toArray();

        $employees_statistic = User::whereHas('deliverdCampaigns', function ($query) use ($startDate, $endDate) {
            $query->whereBetween('phishing_campaigns.created_at', [$startDate, $endDate]);
        })
        ->withCount([
            'deliverdCampaigns' => function ($q) use ($startDate, $endDate) {
                $q->whereBetween('phishing_campaigns.created_at', [$startDate, $endDate]);
            },
            'openedMails' => function ($q) use ($startDate, $endDate, $employeeCampaignIdsInRange) {
                $q->whereIn('phishing_mail_trackings.campaign_id', $employeeCampaignIdsInRange)
                    ->whereBetween('phishing_mail_trackings.opened_at', [$startDate, $endDate]);
            },
            'submitedDataInMails' => function ($q) use ($startDate, $endDate, $employeeCampaignIdsInRange) {
                $q->whereIn('phishing_mail_trackings.campaign_id', $employeeCampaignIdsInRange)
                    ->whereBetween('phishing_mail_trackings.submited_at', [$startDate, $endDate]);
            },
            'downloadedFileInMails' => function ($q) use ($startDate, $endDate, $employeeCampaignIdsInRange) {
                $q->whereIn('phishing_mail_trackings.campaign_id', $employeeCampaignIdsInRange)
                    ->whereBetween('phishing_mail_trackings.downloaded_at', [$startDate, $endDate]);
            },
            'clickedLinkInMails' => function ($q) use ($startDate, $endDate, $employeeCampaignIdsInRange) {
                $q->whereIn('phishing_mail_trackings.campaign_id', $employeeCampaignIdsInRange)
                    ->whereBetween('phishing_mail_trackings.Page_link_clicked_at', [$startDate, $endDate]);
            }
        ])
        ->get();

        $employees_labels = $employees_statistic->pluck('name');
        $employees_campaigns_count = $employees_statistic->pluck('deliverd_campaigns_count');
        $employee_opened_mails_count = $employees_statistic->pluck('opened_mails_count');
        $employee_submited_data_in_mails_count = $employees_statistic->pluck('submited_data_in_mails_count');
        $employee_downloaded_file_in_mails_count = $employees_statistic->pluck('downloaded_file_in_mails_count');
        $employee_click_links_mails_count = $employees_statistic->pluck('clicked_link_in_mails_count');

        // ****************************** Training Statistic **********************
        $trainings_statistic = $this->getTrainingStatistics($request);
        $training_labels = $trainings_statistic->pluck('month');
        $training_total_recieved_users = $trainings_statistic->pluck('total_recieved_users');
        $training_total_passed_users = $trainings_statistic->pluck('total_passed_users');
        $training_total_failed_users = $trainings_statistic->pluck('total_failed_users');
        $training_total_overdue_users = $trainings_statistic->pluck('total_overdue_users');

        // ****************************** CISO Phishing Report Data **********************
        // Get phishing campaigns in date range for CISO report
        $cisoPhishingCampaigns = PhishingCampaign::where('campaign_type', 'simulated_phishing')
            ->withoutTrashed()
            ->whereBetween('created_at', [$startDate, $endDate])
            ->withCount([
                'deliverdEmailTemplates',
                'deliverdEmployees',
                'clickedTrackings',
                'downloadedTrackings'
            ])
            ->get();

        $cisoTotalCampaigns = $cisoPhishingCampaigns->count();
        $cisoTotalEmails = $cisoPhishingCampaigns->sum('deliverd_email_templates_count');
        $cisoTotalEmployees = $cisoPhishingCampaigns->sum('deliverd_employees_count');

        // Get unique users who clicked or downloaded
        $cisoUsersClicked = DB::table('phishing_mail_trackings')
            ->whereIn('campaign_id', $cisoPhishingCampaigns->pluck('id'))
            ->whereNotNull('Page_link_clicked_at')
            ->whereBetween('Page_link_clicked_at', [$startDate, $endDate])
            ->distinct('employee_id')
            ->count('employee_id');

        $cisoUsersDownloaded = DB::table('phishing_mail_trackings')
            ->whereIn('campaign_id', $cisoPhishingCampaigns->pluck('id'))
            ->whereNotNull('downloaded_at')
            ->whereBetween('downloaded_at', [$startDate, $endDate])
            ->distinct('employee_id')
            ->count('employee_id');

        return view('admin.content.phishing.dashboard.reporting', get_defined_vars());
    }

    public function trainingReporting(Request $request = null){
        $breadcrumbs = [
            ['link' => route('admin.phishing.dashboard'), 'name' => __('locale.Dashboard')],
        ];
        [$startDate, $endDate] = $this->getDateRange($request);

        $campaigns = PhishingCampaign::withoutTrashed()
            ->whereBetween('created_at', [$startDate, $endDate])
            ->count();
        $mailTemplates = PhishingTemplate::withoutTrashed()->count();
        $mail_statistic = $this->getMailStatistic($request);
        $labels = $mail_statistic->pluck('month');
        $opened_count = $mail_statistic->pluck('mails_opened');
        $submited_count = $mail_statistic->pluck('mails_submitted');
        $downloaded_count = $mail_statistic->pluck('mails_downloaded');
        $activeCampaigns = $this->getActiveCampaignMailStatistic($request);
        $archivedCampaigns =  $this->getArchivedCampaignMailStatistic($request);

        // Campaign statistics - Fixed to show training campaigns (campaigns with training modules)
        $campaignChart = PhishingCampaign::whereIn('campaign_type', ['simulated_phishing_and_security_awareness', 'security_awareness'])
            ->withoutTrashed()
            ->whereBetween('created_at', [$startDate, $endDate])
            ->whereHas('trainingModules')
            ->withCount([
                'deliverdEmailTemplates',
                'deliverdEmployees',
                'notDeliverdEmailTemplates',
                'notDeliverdEmployees',
                'trainingModules'
            ])
            ->with(['trainingModules' => function($query) {
                $query->withCount(['users' => function($q) {
                    $q->where('passed', 1);
                }]);
            }])
            ->get();
        $campaig_labels = $campaignChart->pluck('campaign_name');
        $deliverd_email_templates_count = $campaignChart->pluck('deliverd_email_templates_count');
        $deliverd_employees_count = $campaignChart->pluck('deliverd_employees_count');
        $not_deliverd_email_templates_count = $campaignChart->pluck('not_deliverd_email_templates_count');
        $not_deliverd_employees_count = $campaignChart->pluck('not_deliverd_employees_count');

        // organization statistics
        $phishGroups = PhishingGroup::withoutTrashed()
        ->withCount('users')
        ->with(['users.campaigns.deliverdEmailTemplates' => function ($query) {
            $query->withCount(['openedMails','submitedDataInMails','downloadedFileInMails']);
        }])
        ->with(['users.campaigns' => function ($query) {
            $query->withCount(['deliverdEmailTemplates','deliverdEmployees','notDeliverdEmailTemplates','notDeliverdEmployees']);
        }])
        ->with(['users' => function ($query) {
            $query->withCount('campaigns');
        }])
        ->get();
        $phish_groups_labels = $phishGroups->pluck('name');
        $phish_groups_employee_count = $phishGroups->pluck('users_count');
        $phish_groups_campaign_count = $phishGroups->map(function ($group) {
            return $group->users->sum('campaigns_count');
        });

        $phish_groups_deliverd_email_templates_count = $phishGroups->map(function ($group) {
            return $group->users->sum(function ($user) {
                return $user->campaigns->sum('deliverd_email_templates_count');
            });
        });

        $phish_groups_deliverd_employees_count = $phishGroups->map(function ($group) {
            return $group->users->sum(function ($user) {
                return $user->campaigns->sum('deliverd_employees_count');
            });
        });

        $phish_groups_not_deliverd_email_templates_count = $phishGroups->map(function ($group) {
            return $group->users->sum(function ($user) {
                return $user->campaigns->sum('not_deliverd_email_templates_count');
            });
        });

        $phish_groups_not_deliverd_employees_count = $phishGroups->map(function ($group) {
            return $group->users->sum(function ($user) {
                return $user->campaigns->sum('not_deliverd_employees_count');
            });
        });

        $phish_groups_opened_mails_count = $phishGroups->map(function ($group) {
            return $group->users->sum(function ($user) {
                return $user->campaigns->sum(function ($campaign) {
                    return $campaign->deliverdEmailTemplates->sum('opened_mails_count');
                });
            });
        });

        $phish_groups_submited_data_in_mails_count = $phishGroups->map(function ($group) {
            return $group->users->sum(function ($user) {
                return $user->campaigns->sum(function ($campaign) {
                    return $campaign->deliverdEmailTemplates->sum('submited_data_in_mails_count');
                });
            });
        });

        $phish_groups_downloaded_file_in_mails_count = $phishGroups->map(function ($group) {
            return $group->users->sum(function ($user) {
                return $user->campaigns->sum(function ($campaign) {
                    return $campaign->deliverdEmailTemplates->sum('downloaded_file_in_mails_count');
                });
            });
        });


        // Employee statistic
        $employees_statistic = User::whereHas('campaigns')
        ->withCount('campaigns')
        ->with(['campaigns.deliverdEmailTemplates' => function ($query) {
            $query->withCount(['openedMails','submitedDataInMails','downloadedFileInMails']);
        }])
        ->get();

        $employees_labels = $employees_statistic->pluck('name');
        $employees_campaigns_count = $employees_statistic->pluck('campaigns_count');
        $employee_opened_mails_count = $employees_statistic->map(function ($user) {
            return $user->campaigns->sum(function ($campaign) {
                return $campaign->deliverdEmailTemplates->sum('opened_mails_count');
            });
        });

        $employee_submited_data_in_mails_count = $employees_statistic->map(function ($user) {
            return $user->campaigns->sum(function ($user) {
                return $user->deliverdEmailTemplates->sum('submited_data_in_mails_count');
            });
        });

        $employee_downloaded_file_in_mails_count = $employees_statistic->map(function ($user) {
            return $user->campaigns->sum(function ($user) {
                return $user->deliverdEmailTemplates->sum('downloaded_file_in_mails_count');
            });
        });

        // Training Statistic
        $trainings_statistic = $this->getTrainingStatistics($request);
        $training_labels = $trainings_statistic->pluck('month');
        $training_total_recieved_users = $trainings_statistic->pluck('total_recieved_users');
        $training_total_passed_users = $trainings_statistic->pluck('total_passed_users');
        $training_total_failed_users = $trainings_statistic->pluck('total_failed_users');
        $training_total_overdue_users = $trainings_statistic->pluck('total_overdue_users');

        // ****************************** CISO Training Report Data **********************
        // Get training campaigns in date range with their training modules
        $cisoTrainingCampaigns = PhishingCampaign::whereIn('campaign_type', ['simulated_phishing_and_security_awareness', 'security_awareness'])
            ->withoutTrashed()
            ->whereBetween('created_at', [$startDate, $endDate])
            ->whereHas('trainingModules')
            ->with(['trainingModules', 'employees'])
            ->get();

        // Get all groups with their users
        $cisoGroups = PhishingGroup::withoutTrashed()
            ->with('users')
            ->withCount('users')
            ->get();

        // Calculate statistics per group
        $cisoGroupStats = $cisoGroups->map(function($group) use ($cisoTrainingCampaigns, $startDate, $endDate) {
            $groupUserIds = $group->users->pluck('id')->toArray();

            // Count campaigns that include this group's users
            $groupCampaigns = $cisoTrainingCampaigns->filter(function($campaign) use ($groupUserIds) {
                return $campaign->employees->whereIn('id', $groupUserIds)->isNotEmpty();
            });

            $totalCampaigns = $groupCampaigns->count();

            // Get training modules assigned to group users in the date range
            $totalAssigned = DB::table('l_m_s_user_training_modules')
                ->whereIn('user_id', $groupUserIds)
                ->whereBetween('created_at', [$startDate, $endDate])
                ->count();

            $totalPassed = DB::table('l_m_s_user_training_modules')
                ->whereIn('user_id', $groupUserIds)
                ->whereBetween('created_at', [$startDate, $endDate])
                ->where('passed', 1)
                ->count();

            return [
                'group_name' => $group->name,
                'total_employees' => $group->users_count ?? 0,
                'total_campaigns' => $totalCampaigns,
                'total_assigned' => $totalAssigned,
                'total_passed' => $totalPassed,
                'attendance_rate' => $totalAssigned > 0 ? round(($totalPassed / $totalAssigned) * 100, 2) : 0
            ];
        })->filter(function($stat) {
            return $stat['total_campaigns'] > 0 || $stat['total_assigned'] > 0;
        });

        return view('admin.content.phishing.dashboard.training-reporting', get_defined_vars());
    }

    public function getActiveCampaignMailStatistic(Request $request = null)
    {
        [$startDate, $endDate] = $this->getDateRange($request);

        return PhishingCampaign::withoutTrashed()
        ->whereBetween('created_at', [$startDate, $endDate])
        ->withCount('deliverdEmailTemplates')
        ->get()
        ->map(function ($campaign) use ($startDate, $endDate) {
            $opend_count = 0;
            $submited_count = 0;
            $downloaded_count = 0;

            $campaign->emailTemplates->each(function ($emailTemplate) use (&$opend_count,&$downloaded_count,&$submited_count, $startDate, $endDate, $campaign) {
                $opend_count += $emailTemplate->openedMails()
                    ->where('phishing_mail_trackings.campaign_id', $campaign->id)
                    ->whereBetween('phishing_mail_trackings.opened_at', [$startDate, $endDate])
                    ->count();
                $submited_count += $emailTemplate->submitedDataInMails()
                    ->where('phishing_mail_trackings.campaign_id', $campaign->id)
                    ->whereBetween('phishing_mail_trackings.submited_at', [$startDate, $endDate])
                    ->count();
                $downloaded_count += $emailTemplate->downloadedFileInMails()
                    ->where('phishing_mail_trackings.campaign_id', $campaign->id)
                    ->whereBetween('phishing_mail_trackings.downloaded_at', [$startDate, $endDate])
                    ->count();
            });

            $campaign->opend_count = $opend_count;
            $campaign->submited_count = $submited_count;
            $campaign->downloaded_count = $downloaded_count;
            return $campaign;
        });
    }

    public function getArchivedCampaignMailStatistic(Request $request = null)
    {
        [$startDate, $endDate] = $this->getDateRange($request);

        return PhishingCampaign::onlyTrashed()
        ->whereBetween('created_at', [$startDate, $endDate])
        ->withCount('deliverdEmailTemplates')
        ->get()
        ->map(function ($campaign) use ($startDate, $endDate) {
            $opend_count = 0;
            $submited_count = 0;
            $downloaded_count = 0;

            $campaign->emailTemplates->each(function ($emailTemplate) use (&$opend_count,&$downloaded_count,&$submited_count, $startDate, $endDate, $campaign) {
                $opend_count += $emailTemplate->openedMails()
                    ->where('phishing_mail_trackings.campaign_id', $campaign->id)
                    ->whereBetween('phishing_mail_trackings.opened_at', [$startDate, $endDate])
                    ->count();
                $submited_count += $emailTemplate->submitedDataInMails()
                    ->where('phishing_mail_trackings.campaign_id', $campaign->id)
                    ->whereBetween('phishing_mail_trackings.submited_at', [$startDate, $endDate])
                    ->count();
                $downloaded_count += $emailTemplate->downloadedFileInMails()
                    ->where('phishing_mail_trackings.campaign_id', $campaign->id)
                    ->whereBetween('phishing_mail_trackings.downloaded_at', [$startDate, $endDate])
                    ->count();
            });

            $campaign->opend_count = $opend_count;
            $campaign->submited_count = $submited_count;
            $campaign->downloaded_count = $downloaded_count;
            return $campaign;
        });
    }

    public function getTrainingStatistics(Request $request = null)
    {
        [$startDate, $endDate] = $this->getDateRange($request);
        $today = Carbon::today()->startOfDay();

        // Get all training campaigns (active + archived) in range with their training modules and users
        $campaigns = PhishingCampaign::withTrashed()
            ->whereIn('campaign_type', ['security_awareness', 'simulated_phishing_and_security_awareness'])
            ->whereBetween('created_at', [$startDate, $endDate])
            ->with(['trainingModules.users'])
            ->get();

        $statsByMonth = [];

        foreach ($campaigns as $campaign) {
            $month = Carbon::parse($campaign->created_at)->format('Y-%m');

            // Assigned = unique users assigned to any training module in this campaign
            $assigned = $campaign->trainingModules
                ->flatMap->users
                ->unique('id')
                ->count();

            // Passed = users who passed at least one module in this campaign
            $passed = $campaign->trainingModules->sum(function ($trainingModule) {
                return $trainingModule->users()
                    ->wherePivot('passed', 1)
                    ->count();
            });

            // Failed = users who entered exam but did not pass
            $failed = $campaign->trainingModules->sum(function ($trainingModule) {
                return $trainingModule->users()
                    ->wherePivot('passed', 0)
                    ->wherePivot('count_of_entering_exam', '>', 0)
                    ->count();
            });

            // Passed after overdue
            $passedAfterOverdue = $campaign->trainingModules->sum(function ($trainingModule) use ($today) {
                return $trainingModule->users()
                    ->wherePivot('passed', 1)
                    ->whereNotNull('l_m_s_user_training_modules.days_until_due')
                    ->get()
                    ->filter(function ($user) use ($today) {
                        $pivot = $user->pivot;
                        $assignedDate = Carbon::parse($pivot->created_at)->startOfDay();
                        $dueDate = $assignedDate->copy()->addDays($pivot->days_until_due)->startOfDay();
                        $completedAt = $pivot->completed_at ? Carbon::parse($pivot->completed_at)->startOfDay() : null;

                        return $completedAt && $completedAt->gt($dueDate);
                    })
                    ->count();
            });

            // Overdue = users who have not passed and are past due date
            $overdue = $campaign->trainingModules->sum(function ($trainingModule) use ($today) {
                return $trainingModule->users()
                    ->wherePivot('passed', 0)
                    ->whereNotNull('l_m_s_user_training_modules.days_until_due')
                    ->get()
                    ->filter(function ($user) use ($today) {
                        $pivot = $user->pivot;
                        $assignedDate = Carbon::parse($pivot->created_at)->startOfDay();
                        $dueDate = $assignedDate->copy()->addDays($pivot->days_until_due)->startOfDay();
                        return $today->gt($dueDate);
                    })
                    ->count();
            });

            if (!isset($statsByMonth[$month])) {
                $statsByMonth[$month] = [
                    'month' => $month,
                    'total_recieved_users' => 0,
                    'total_passed_users' => 0,
                    'total_failed_users' => 0,
                    'total_overdue_users' => 0,
                ];
            }

            $statsByMonth[$month]['total_recieved_users'] += $assigned;
            $statsByMonth[$month]['total_passed_users'] += $passed;
            $statsByMonth[$month]['total_failed_users'] += $failed;
            $statsByMonth[$month]['total_overdue_users'] += $overdue;
        }

        // Return as collection sorted by month
        return collect($statsByMonth)
            ->sortBy('month')
            ->values();
    }

    /**
     * CISO Training Report - Training campaigns by group with attendance
     */
    public function cisoTrainingReport(Request $request = null)
    {
        [$startDate, $endDate] = $this->getDateRange($request);

        $breadcrumbs = [
            ['link' => route('admin.phishing.dashboard'), 'name' => __('locale.Dashboard')],
            ['name' => __('phishing.CISO_Training_Report')],
        ];

        // Get training campaigns in date range with their training modules
        $trainingCampaigns = PhishingCampaign::whereIn('campaign_type', ['simulated_phishing_and_security_awareness', 'security_awareness'])
            ->withoutTrashed()
            ->whereBetween('created_at', [$startDate, $endDate])
            ->whereHas('trainingModules')
            ->with(['trainingModules', 'employees'])
            ->get();

        // Get all groups with their users
        $groups = PhishingGroup::withoutTrashed()
            ->with('users')
            ->withCount('users')
            ->get();

        // Calculate statistics per group
        $groupStats = $groups->map(function($group) use ($trainingCampaigns, $startDate, $endDate) {
            $groupUserIds = $group->users->pluck('id')->toArray();

            // Count campaigns that include this group's users
            $groupCampaigns = $trainingCampaigns->filter(function($campaign) use ($groupUserIds) {
                return $campaign->employees->whereIn('id', $groupUserIds)->isNotEmpty();
            });

            $totalCampaigns = $groupCampaigns->count();

            // Get training modules assigned to group users in the date range
            $totalAssigned = DB::table('l_m_s_user_training_modules')
                ->whereIn('user_id', $groupUserIds)
                ->whereBetween('created_at', [$startDate, $endDate])
                ->count();

            $totalPassed = DB::table('l_m_s_user_training_modules')
                ->whereIn('user_id', $groupUserIds)
                ->whereBetween('created_at', [$startDate, $endDate])
                ->where('passed', 1)
                ->count();

            return [
                'group_name' => $group->name,
                'total_employees' => $group->users_count ?? 0,
                'total_campaigns' => $totalCampaigns,
                'total_assigned' => $totalAssigned,
                'total_passed' => $totalPassed,
                'attendance_rate' => $totalAssigned > 0 ? round(($totalPassed / $totalAssigned) * 100, 2) : 0
            ];
        })->filter(function($stat) {
            return $stat['total_campaigns'] > 0 || $stat['total_assigned'] > 0;
        });

        return view('admin.content.phishing.dashboard.ciso-training-report', get_defined_vars());
    }

    /**
     * CISO Phishing Report
     */
    public function cisoPhishingReport(Request $request = null)
    {
        [$startDate, $endDate] = $this->getDateRange($request);

        $breadcrumbs = [
            ['link' => route('admin.phishing.dashboard'), 'name' => __('locale.Dashboard')],
            ['name' => __('phishing.CISO_Phishing_Report')],
        ];

        // Get phishing campaigns in date range
        $campaigns = PhishingCampaign::where('campaign_type', 'simulated_phishing')
            ->withoutTrashed()
            ->whereBetween('created_at', [$startDate, $endDate])
            ->withCount([
                'deliverdEmailTemplates',
                'deliverdEmployees',
                'clickedTrackings',
                'downloadedTrackings'
            ])
            ->get();

        $totalCampaigns = $campaigns->count();
        $totalEmails = $campaigns->sum('deliverd_email_templates_count');
        $totalEmployees = $campaigns->sum('deliverd_employees_count');

        // Get unique users who clicked or downloaded
        $usersClicked = DB::table('phishing_mail_trackings')
            ->whereIn('campaign_id', $campaigns->pluck('id'))
            ->whereNotNull('Page_link_clicked_at')
            ->whereBetween('Page_link_clicked_at', [$startDate, $endDate])
            ->distinct('employee_id')
            ->count('employee_id');

        $usersDownloaded = DB::table('phishing_mail_trackings')
            ->whereIn('campaign_id', $campaigns->pluck('id'))
            ->whereNotNull('downloaded_at')
            ->whereBetween('downloaded_at', [$startDate, $endDate])
            ->distinct('employee_id')
            ->count('employee_id');

        return view('admin.content.phishing.dashboard.ciso-phishing-report', get_defined_vars());
    }

    /**
     * Awareness Team Report - Detailed training and phishing with logo, editable title, chart/table toggle
     */
    public function awarenessTeamReport(Request $request = null)
    {
        [$startDate, $endDate] = $this->getDateRange($request);

        $breadcrumbs = [
            ['link' => route('admin.phishing.dashboard'), 'name' => __('locale.Dashboard')],
            ['name' => __('phishing.Awareness_Team_Report')],
        ];

        // Get training details
        $trainingDetails = $this->getTrainingStatistics($request);

        // Get phishing details
        $phishingDetails = $this->getMailStatistic($request);

        // Get campaigns details
        $campaignsDetails = PhishingCampaign::where('campaign_type', 'simulated_phishing')
            ->withoutTrashed()
            ->whereBetween('created_at', [$startDate, $endDate])
            ->withCount([
                'deliverdEmailTemplates',
                'deliverdEmployees',
                'openedTrackings',
                'clickedTrackings',
                'downloadedTrackings',
                'submittedTrackings'
            ])
            ->get();

        // Get report title from request or use default
        $reportTitle = $request && $request->has('report_title')
            ? $request->report_title
            : __('phishing.Awareness_Team_Report');

        // Get display mode from request (chart or table)
        $displayMode = $request && $request->has('display_mode')
            ? $request->display_mode
            : 'chart';

        return view('admin.content.phishing.dashboard.awareness-team-report', get_defined_vars());
    }
}
