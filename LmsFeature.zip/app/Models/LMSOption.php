<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class LMSOption extends Model
{
    use HasFactory,SoftDeletes;
    protected $table = 'l_m_s_options';
    protected $guarded = [];
    public function question()
    {
        return $this->belongsTo(LMSQuestion::class,'question_id');
    }

    /**
     * Get localized option text based on current locale
     * Use this method only when you need localized content (e.g., in summary view)
     */
    public function getLocalizedOptionText($locale = null)
    {
        $locale = $locale ?? app()->getLocale();
        
        // Check if option_text is JSON format (new format)
        $optionData = json_decode($this->attributes['option_text'] ?? '{}', true);
        if (is_array($optionData) && isset($optionData[$locale]) && !empty(trim($optionData[$locale]))) {
            return $optionData[$locale];
        }
        
        // If it's a JSON string but not in the expected format, try fallback
        if (is_array($optionData)) {
            // Try to get English fallback if current locale not available
            if ($locale === 'ar' && isset($optionData['en']) && !empty(trim($optionData['en']))) {
                return $optionData['en'];
            } elseif ($locale === 'en' && isset($optionData['ar']) && !empty(trim($optionData['ar']))) {
                return $optionData['ar'];
            }
            // If JSON but no valid locale found, return empty
            return '';
        }
        
        // Fallback to separate columns (old format)
        if ($locale === 'ar') {
            // For Arabic locale, check if option_text_ar exists and is not empty
            if (isset($this->attributes['option_text_ar']) && !empty(trim($this->attributes['option_text_ar']))) {
                return $this->attributes['option_text_ar'];
            }
            // If option_text_ar is empty, fallback to English option_text
            if (!empty(trim($this->attributes['option_text'] ?? ''))) {
                return $this->attributes['option_text'];
            }
            return '';
        }
        
        // For English locale, return option_text column (English)
        return !empty(trim($this->attributes['option_text'] ?? '')) ? $this->attributes['option_text'] : '';
    }
}
