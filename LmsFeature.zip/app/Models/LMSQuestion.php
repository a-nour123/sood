<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class LMSQuestion extends Model
{
    use HasFactory, SoftDeletes;
    protected $table = 'l_m_s_questions';
    protected $guarded = [];

    protected static function booted()
    {
        static::deleting(function ($question) {
            $question->options()->delete();
            $question->answers()->delete();
        });
    }
    public function trainingModule()
    {
        return $this->belongsTo(LMSTrainingModule::class);
    }

    public function options()
    {
        return $this->hasMany(LMSOption::class, 'question_id');
    }

    public function answers()
    {
        return $this->hasMany(LMSAnswer::class, 'question_id');
    }

    /**
     * Get localized question text based on current locale
     * Use this method only when you need localized content (e.g., in summary view)
     */
    public function getLocalizedQuestion($locale = null)
    {
        $locale = $locale ?? app()->getLocale();

        // Check if question is JSON format (new format)
        $questionData = json_decode($this->attributes['question'] ?? '{}', true);
        if (is_array($questionData) && isset($questionData[$locale]) && !empty(trim($questionData[$locale]))) {
            return $questionData[$locale];
        }

        // If it's a JSON string but not in the expected format, try fallback
        if (is_array($questionData)) {
            // Try to get English fallback if current locale not available
            if ($locale === 'ar' && isset($questionData['en']) && !empty(trim($questionData['en']))) {
                return $questionData['en'];
            } elseif ($locale === 'en' && isset($questionData['ar']) && !empty(trim($questionData['ar']))) {
                return $questionData['ar'];
            }
            // If JSON but no valid locale found, return empty
            return '';
        }

        // Fallback to separate columns (old format)
        if ($locale === 'ar') {
            // For Arabic locale, check if question_ar exists and is not empty
            if (isset($this->attributes['question_ar']) && !empty(trim($this->attributes['question_ar']))) {
                return $this->attributes['question_ar'];
            }
            // If question_ar is empty, fallback to English question
            if (!empty(trim($this->attributes['question'] ?? ''))) {
                return $this->attributes['question'];
            }
            return '';
        }

        // For English locale, return question column (English)
        return !empty(trim($this->attributes['question'] ?? '')) ? $this->attributes['question'] : '';
    }
}
