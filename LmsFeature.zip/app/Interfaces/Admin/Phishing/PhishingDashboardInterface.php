<?php


namespace App\Interfaces\Admin\Phishing;

use App\Http\Requests\admin\phishing\PhishingDomainsRequest;
use Illuminate\Http\Request;

interface PhishingDashboardInterface
{
    public function index();
    public function reporting(Request $request = null);
    public function trainingReporting(Request $request = null);
    public function cisoTrainingReport(Request $request = null);
    public function cisoPhishingReport(Request $request = null);
    public function awarenessTeamReport(Request $request = null);
}
