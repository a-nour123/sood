<?php

namespace App\Http\Traits;

use Illuminate\Support\Facades\DB;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

use PHPMailer\PHPMailer\PHPMailer;

trait PhishingMailTrait
{
    public function sendPhishingMail($email_from, $mailData, $email_to, $mailObject)
    {
        try {
            $mail = new PHPMailer(true);
            $mail->CharSet = 'UTF-8';

            $mail->isSMTP();
            $mail->SMTPDebug = false;
            $mail->Mailer = "smtp";
            $mail->SMTPAuth = false;
            $mail->Port = 587;
            $mail->Host = "192.168.1.192";
            $mail->Username = "sayed";
            $mail->Password =   "pk@12345";
            $mail->SMTPSecure = "tls";
            $mail->isHTML(true);
            $mail->addAddress($email_to);
            $mail->setFrom($email_from, "sayed");
            $mail->Subject = $mailData->subject;
            $mail->Body = $mailData->body;
            $mail->SMTPOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                )
            );
            $mail->addCustomHeader('X-PHISHING', 'true');
            $mail->SMTPDebug = 2;

            if ($mail->send($mailObject)) {
                $response = [
                    'status' => true,
                    'message' => __('success'),
                ];
            } else {
                $response = [
                    'status' => false,
                    'message' => __('error_occured'),
                ];
            }
            return $response;
        } catch (\Exception $e) {
            // dd($e->getMessage());
        }
    }

    public function sendPhishingMail2($email_from, $mailData, $email_to, $mailObject)
    {
        try {
            // Validate sender profile exists
            if (!$mailData->senderProfile) {
                \Log::error('Sender profile not found for email template', [
                    'template_id' => $mailData->id ?? null,
                    'email_to' => $email_to
                ]);
                return false;
            }

            $senderProfile = $mailData->senderProfile;

            // Get SMTP username from .env - this is what Exchange Server requires
            $smtpUsername = env('MAIL_USERNAME', 'nour@advanced.sa');

            // Build original from_address_name for Reply-To if needed
            $originalFromAddress = null;
            if ($senderProfile->type === 'managed') {
                $domain = DB::table('phishing_domains')
                    ->where('id', $senderProfile->website_domain_id)
                    ->value('name');

                if (!$domain) {
                    \Log::error('Domain not found for managed sender profile', [
                        'sender_profile_id' => $senderProfile->id,
                        'domain_id' => $senderProfile->website_domain_id
                    ]);
                    return false;
                }

                $originalFromAddress = $senderProfile->from_address_name . $domain;
            } else {
                $originalFromAddress = $senderProfile->from_address_name;
            }

            // Use SMTP username from .env as sender mail if it's a valid email
            // Otherwise, use original from_address_name
            if (filter_var($smtpUsername, FILTER_VALIDATE_EMAIL)) {
                $senderMail = $smtpUsername;
            } else {
                $senderMail = $originalFromAddress;
            }

            $mail = new PHPMailer(true);
            $mail->CharSet = 'UTF-8';
            $mail->SMTPDebug = 0;
            $mail->isSMTP();

            // Use SMTP credentials from .env only
            $mail->Host = env('MAIL_HOST', '192.168.186.137');
            $mail->Port = (int)env('MAIL_PORT', 587);
            $mail->SMTPAuth = true;
            $mail->Username = env('MAIL_USERNAME', 'nour@advanced.sa');
            $mail->Password = env('MAIL_PASSWORD', 'Pk@12345');

            // Set encryption from .env
            $encryption = env('MAIL_ENCRYPTION', 'tls');
            if ($encryption === 'ssl') {
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            } elseif ($encryption === 'tls') {
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            } else {
                $mail->SMTPSecure = '';
            }

            // Set SSL options for better compatibility
            $mail->SMTPOptions = [
                'ssl' => [
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                ]
            ];

            // Exchange Server requires From address to match authenticated SMTP username exactly
            // Always use SMTP username as From address
            $fromAddress = $smtpUsername;
            $fromName = $senderProfile->from_display_name;

            // If original from_address_name is different from SMTP username, set it as Reply-To
            if ($originalFromAddress &&
                filter_var($originalFromAddress, FILTER_VALIDATE_EMAIL) &&
                filter_var($smtpUsername, FILTER_VALIDATE_EMAIL) &&
                strtolower($originalFromAddress) !== strtolower($smtpUsername)) {
                $mail->addReplyTo($originalFromAddress, $senderProfile->from_display_name);
            }

            // Set From address (must match authenticated SMTP user for Exchange Server)
            $mail->setFrom($fromAddress, $fromName);

            $mail->addAddress($email_to, '');
            $mail->isHTML(true);
            $mail->Subject = $mailData->subject;
            $mail->Body = $mailObject->render();

            // Add custom header for tracking
            $mail->addCustomHeader('X-PHISHING', 'true');

            // Additional Exchange Server compatibility settings
            $mail->XMailer = 'PHPMailer';
            $mail->Priority = 3; // Normal priority

            return $mail->send();

        } catch (\Exception $e) {
            $errorDetails = [
                'error' => $e->getMessage(),
                'email_to' => $email_to,
                'email_from' => $senderMail ?? 'unknown',
                'template_id' => $mailData->id ?? null,
                'sender_profile_id' => $senderProfile->id ?? null,
            ];

            // Add PHPMailer specific error if available
            if (isset($mail) && method_exists($mail, 'ErrorInfo')) {
                $errorDetails['phpmailer_error'] = $mail->ErrorInfo;
            }

            // Check for specific Exchange Server errors
            if (strpos($e->getMessage(), 'data not accepted') !== false) {
                $errorDetails['suggestion'] = 'Exchange Server rejected the email. Common causes: From address mismatch with SMTP username, invalid email format, or server policy restrictions.';
            }

            // Check for rate limiting errors
            $isRateLimit = strpos($e->getMessage(), 'rate') !== false ||
                          strpos($e->getMessage(), '421') !== false ||
                          strpos($e->getMessage(), '4.4.2') !== false ||
                          (isset($mail) && method_exists($mail, 'ErrorInfo') &&
                           (strpos($mail->ErrorInfo, 'rate') !== false ||
                            strpos($mail->ErrorInfo, '421') !== false ||
                            strpos($mail->ErrorInfo, '4.4.2') !== false));

            if ($isRateLimit) {
                $errorDetails['suggestion'] = 'Exchange Server rate limit exceeded. The server is limiting the number of emails sent per minute. Consider adding delays between emails or reducing batch size.';
                $errorDetails['is_rate_limit'] = true;
            }

            \Log::error('Mail sending failed', $errorDetails);

            // Re-throw rate limit exceptions so they can be handled by the job
            if ($isRateLimit) {
                throw new \Exception('Rate limit exceeded: ' . $e->getMessage(), 421, $e);
            }

            return false;
        }
    }
}
