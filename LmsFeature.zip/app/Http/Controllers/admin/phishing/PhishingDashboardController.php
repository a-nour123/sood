<?php

namespace App\Http\Controllers\admin\phishing;

use App\Http\Controllers\Controller;
use App\Interfaces\Admin\Phishing\PhishingDashboardInterface;
use Illuminate\Http\Request;

class PhishingDashboardController extends Controller
{
    protected $PhishingDashboardInterface;

    public function __construct(PhishingDashboardInterface $PhishingDashboardInterface)
    {
        $this->PhishingDashboardInterface = $PhishingDashboardInterface;
    }
    public function index()
    {
        return $this->PhishingDashboardInterface->index();
    }

    public function reporting(Request $request)
    {
        return $this->PhishingDashboardInterface->reporting($request);
    }

    public function trainingReporting(Request $request)
    {
        return $this->PhishingDashboardInterface->trainingReporting($request);
    }

    public function cisoTrainingReport(Request $request)
    {
        return $this->PhishingDashboardInterface->cisoTrainingReport($request);
    }

    public function cisoPhishingReport(Request $request)
    {
        return $this->PhishingDashboardInterface->cisoPhishingReport($request);
    }

    public function awarenessTeamReport(Request $request)
    {
        return $this->PhishingDashboardInterface->awarenessTeamReport($request);
    }





}
