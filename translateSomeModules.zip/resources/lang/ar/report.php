<?php

return array(
  'AboveMaturity' => 'فوق الاستحقاق',
  'AdditionalNotes' => 'ملاحظات إضافية',
  'AffectedAssets' => 'الأصول المتأثرة',
  'All Open Risks Assigned to Me' => 'جميع المخاطر المفتوحة المخصصة لي',
  'AssetName' => 'اسم الأصل',
  'AssetSiteLocation' => 'موقع موقع الأصول',
  'AssetTags' => 'علامات الأصول',
  'AssetTeams' => 'فرق الأصول',
  'AssetValue' => 'قيمة الأصول',
  'AssetsByRisk' => 'الأصول حسب المخاطر',
  'AtMaturity' => 'عند النضج',
  'AwarenessSurvey' => 'مسح الوعي',
  'BelowMaturity' => 'أقل من النضج',
  'Category' => 'الفئة',
  'Control' => 'التحكم',
  'Control Gap Analysis' => 'تحليل فجوة التحكم',
  'ControlClass' => 'فئة التحكم',
  'ControlFamily' => 'عائلة التحكم',
  'ControlNumber' => 'رقم التحكم',
  'ControlOwner' => 'مالك التحكم',
  'ControlPhase' => 'مرحلة التحكم',
  'ControlPriority' => 'أولوية التحكم',
  'ControlRegulation' => 'تنظيم التحكم',
  'ControlShortName' => 'الاسم المختصر للضابط',
  'ControlsByRisk' => 'الضوابط حسب المخاطر',
  'CurrentControlMaturity' => 'نضج التحكم الحالي',
  'CurrentImpact' => 'التأثير الحالي',
  'CurrentLikelihood' => 'الاحتمال الحالي',
  'DesiredControlMaturity' => 'نضج السيطرة المرغوب فيه',
  'Done' => 'تم',
  'Draft' => 'مسودة',
  'DynamicRiskReport' => 'تقرير المخاطر الديناميكية',
  'EvidencesCreatedAt' => 'الأدلة التي تم إنشاؤها في',
  'EvidencesUpdatedAt' => 'تم تحديث الأدلة في',
  'ExternalReferenceId' => 'معرف المرجع الخارجي',
  'Framework' => 'الإطار',
  'Impact' => 'التأثير',
  'InherentRisk' => 'الخطر المتأصل',
  'InherentRiskCurrent' => 'تيار المخاطر المتأصل',
  'Likelihood' => 'الاحتمالية',
  'Likelihood and Impact' => 'الاحتمال والتأثير',
  'LikelihoodImpact' => 'التأثير المحتمل',
  'MitigationPercent' => 'نسبة التخفيف',
  'MitigationPlannedVsUnplanned' => 'التخفيف المخطط له مقابل التخفيف غير المخطط له',
  'NoAnswersOnThisExam' => 'لا توجد إجابات في هذا الاختبار',
  'Objective' => 'الهدف',
  'Objectives' => 'الأهداف',
  'OpenedRisks' => 'المخاطر المفتوحة',
  'Overview' => 'نظرة عامة',
  'Report' => 'تقرير',
  'ReviewedVsUnreviewed' => 'المراجعة مقابل غير المراجعة',
  'RiskAssessment' => 'تقييم المخاطر',
  'RiskId' => 'معرف المخاطر',
  'RiskMapping' => 'رسم خرائط المخاطر',
  'RiskMappingColumns' => 'أعمدة تعيين المخاطر',
  'RiskScoringMethod' => 'طريقة تسجيل المخاطر',
  'RisksByAsset' => 'المخاطر حسب الأصول',
  'RisksByControl' => 'المخاطر التي يمكن التحكم فيها',
  'SecurityAwareness' => 'الاستطلاعات',
  'SecurityAwarenessExam' => 'اختبار الوعي الأمني',
  'SumAnswers' => 'مجموع الإجابات',
  'SumEmployeeTakeSurvey' => 'استبيان مجموع الموظفين',
  'SumNotAnswered' => 'لم يتم الرد على المبلغ',
  'SumQuestions' => 'مجموع الأسئلة',
  'Summary' => 'ملخص',
  'SupplementalGuidance' => 'إرشادات تكميلية',
  'SupportingDocumentation' => 'الوثائق الداعمة',
  'Tags' => 'العلامات',
  'The_general_level_of_cybersecurity_assessment_of_the_entity' => 'المستوى العام لتقييم الأمن السيبراني للجهة',
  'ThreatMapping' => 'تخطيط التهديدات',
  'control-framework:' => 'إطار التحكم:',
  'framework_control_compliance_status' => 'حالة الامتثال للتحكم في إطار العمل',
  'summary_of_results_for_evaluation_and_compliance' => 'ملخص نتائج التقييم والامتثال',
  'summary_of_results_for_evaluation_and_compliance_to_the_basic_controls_of_cybersecurity' => 'ملخص نتائج التقييم والامتثال للضوابط الأساسية للأمن السيبراني',
  'Preparing Print' => 'جاري التحضير للطباعة',
  'Please wait' => 'يرجى الانتظار',
  'Print Report' => 'طباعة التقرير',
  'AUDIT COMPLIANCE REPORT' => 'تقرير الامتثال للتدقيق',
  'Audit Name' => 'اسم التدقيق',
  'Audit Type' => 'نوع التدقيق',
  'Audit Function' => 'وظيفة التدقيق',
  'Generated' => 'تم الإنشاء',
  'Responsible' => 'المسؤول',
  'Framework' => 'الإطار',
  'EXECUTIVE SUMMARY' => 'ملخص تنفيذي',
  'Total Controls' => 'إجمالي الضوابط',
  'Passed' => 'تم اجتيازه',
  'Failed' => 'فشل',
  'Compliance Rate' => 'معدل الامتثال',
  'Overall Compliance Status' => 'حالة الامتثال العامة',
  'Domain Compliance Statistics' => 'إحصائيات امتثال النطاق',
  'CONTROL DETAILS' => 'تفاصيل الضوابط',
  'CONTROL' => 'الضابط',
  'STATUS' => 'الحالة',
  'CLOSED' => 'مغلق',
  'OPEN' => 'مفتوح',
  'RESULT' => 'النتيجة',
  'Control ID' => 'معرف الضابط',
  'Objectives' => 'الأهداف',
  'Created Date' => 'تاريخ الإنشاء',
  'Evidence Items' => 'عناصر الأدلة',
  'Last Updated' => 'آخر تحديث',
  'Completion' => 'الإكمال',
  'CONTROL OBJECTIVES' => 'أهداف الضوابط',
  'Objective Name' => 'اسم الهدف',
  'Status' => 'الحالة',
  'Comments' => 'التعليقات',
  'Assessment Date' => 'تاريخ التقييم',
  'APPROVED' => 'موافق عليه',
  'REJECTED' => 'مرفوض',
  'REVIEW' => 'مراجعة',
  'UNKNOWN' => 'غير معروف',
  'SUPPORTING EVIDENCE' => 'الأدلة المساندة',
  'Evidence Name' => 'اسم الدليل',
  'Description' => 'الوصف',
  'Upload Date' => 'تاريخ الرفع',
  'File Type' => 'نوع الملف',
  'File' => 'الملف',
  'View Image' => 'عرض الصورة',
  'Download' => 'تحميل',
  'No File' => 'لا يوجد ملف',
  'Generated by Audit System' => 'تم إنشاؤه بواسطة نظام التدقيق',
  'Confidential' => 'سري',
  'Page 1 of 1' => 'الصفحة 1 من 1',
  'No audits for this framework.' => 'لا توجد تدقيقات لهذا الإطار.',

  // الترجمات الجديدة المضافة
  'Attribute' => 'السمة',
  'Value' => 'القيمة',
  'Metrics' => 'المقاييس',
  'Count' => 'العدد',
  'View File' => 'عرض الملف',
  'File Missing' => 'الملف مفقود',
  'Page' => 'الصفحة',
  'of' => 'من',



  'AUDIT COMPLIANCE REPORT' => 'تقرير الامتثال للتدقيق',
  'EXECUTIVE SUMMARY'      => 'الملخص التنفيذي',
  'CONTROL DETAILS'        => 'تفاصيل الضوابط',
  'CONTROL OBJECTIVES'     => 'أهداف الضبط',
  'SUPPORTING EVIDENCE'    => 'الأدلة الداعمة',

  'Audit Name'        => 'اسم التدقيق',
  'Audit Type'        => 'نوع التدقيق',
  'Audit Function'    => 'وظيفة التدقيق',
  'Generated'         => 'تاريخ الإنشاء',
  'Responsible'       => 'المسؤول',
  'Framework'         => 'الإطار',

  'Total Controls'    => 'إجمالي الضوابط',
  'Passed'            => 'الناجحة',
  'Failed'            => 'غير المطابقة',
  'Compliance Rate'   => 'نسبة الامتثال',

  'CONTROL'           => 'الضابط',
  'STATUS'            => 'الحالة',
  'RESULT'            => 'النتيجة',

  'Attribute'         => 'الخاصية',
  'Value'             => 'القيمة',
  'Metrics'           => 'المؤشرات',
  'Count'             => 'العدد',

  'Control ID'        => 'معرف الضابط',
  'Created Date'      => 'تاريخ الإنشاء',
  'Last Updated'      => 'آخر تحديث',
  'Objectives'        => 'الأهداف',
  'Evidence Items'    => 'عناصر الأدلة',
  'Completion'        => 'نسبة الإنجاز',

  'Objective Name'    => 'اسم الهدف',
  'Status'            => 'الحالة',
  'Comments'          => 'الملاحظات',
  'Assessment Date'   => 'تاريخ التقييم',

  'Evidence Name'     => 'اسم الدليل',
  'Description'       => 'الوصف',
  'Upload Date'       => 'تاريخ الرفع',
  'File Type'         => 'نوع الملف',
  'File'              => 'الملف',

  'View File'         => 'عرض الملف',
  'File Missing'      => 'الملف غير موجود',

  'OPEN'              => 'مفتوح',
  'CLOSED'            => 'مغلق',

  'APPROVED'          => 'معتمد',
  'REJECTED'          => 'مرفوض',
  'REVIEW'            => 'قيد المراجعة',
  'UNKNOWN'           => 'غير معروف',

  'Generated by Audit System' => 'تم الإنشاء بواسطة نظام التدقيق',
  'Confidential'             => 'سري',
  'Page'                     => 'صفحة',
  'of'                       => 'من',

  'Control Document Audit Results' => 'نتائج تدقيق مستندات الضوابط',
  'Document Revision History'      => 'سجل مراجعة المستند',
  'Audit Purpose'                  => 'هدف التدقيق',
  'SUMMARY'                        => 'الملخص',
  'Report Generated on'            => 'تم إنشاء التقرير في',
  'Generated By'                   => 'تم الإنشاء بواسطة',

  /* =========================
       Revision History
    ========================== */

  'Reviewer'    => 'المراجع',
  'Version'     => 'الإصدار',
  'Date'        => 'التاريخ',
  'Description' => 'الوصف',

  /* =========================
       Introduction Text
    ========================== */

  'This report provides a comprehensive overview of the control document audit results.' =>
  'يقدم هذا التقرير نظرة شاملة على نتائج تدقيق مستندات الضوابط.',

  'It includes details about each control, associated documents, review dates, and actions taken.' =>
  'يتضمن تفاصيل كل ضابط، والمستندات المرتبطة به، وتواريخ المراجعة، والإجراءات المتخذة.',

  /* =========================
       Table Headers
    ========================== */

  'Control Name'   => 'اسم الضابط',
  'Document Name'  => 'اسم المستند',
  'Planned Date'   => 'التاريخ المخطط',
  'Review Date'    => 'تاريخ المراجعة',
  'Reviewer'       => 'المراجع',
  'Action'         => 'الإجراء',
  'Review Notes'   => 'ملاحظات المراجعة',

  /* =========================
       Actions / Status
    ========================== */

  'Approved' => 'معتمد',
  'Rejected' => 'مرفوض',
  'Pending'  => 'قيد الانتظار',

  /* =========================
       Summary Section
    ========================== */

  'Approved Documents' => 'المستندات المعتمدة',
  'Rejected Documents' => 'المستندات المرفوضة',
  'Pending Documents'  => 'المستندات قيد الانتظار',
  'Total Documents'    => 'إجمالي المستندات',
  'Approval Rate'      => 'نسبة الاعتماد',


  'Document Revision History' => 'سجل مراجعة المستند',
  'Reviewer'                 => 'المراجع',
  'Version'                  => 'الإصدار',
  'Date'                     => 'التاريخ',
  'Description'              => 'الوصف',

  'Audit Purpose' => 'هدف التدقيق',

  'Audit Purpose Description 1' =>
  'يقدم هذا التقرير نظرة شاملة على نتائج تدقيق مستندات الضوابط.',

  'Audit Purpose Description 2' =>
  'يتضمن تفاصيل كل ضابط، والمستندات المرتبطة به، وتواريخ المراجعة، والإجراءات المتخذة.',

  'Report Generated on' => 'تم إنشاء التقرير في',
  'Generated By'        => 'تم الإنشاء بواسطة',
  'System'              => 'النظام',
  'Summary' => 'الملخص',

  'Approved' => 'مقبول',
  'Rejected' => 'مرفوض',
  'Pending'  => 'قيد المراجعة',

  'Approved Documents' => 'المستندات المعتمدة',
  'Rejected Documents' => 'المستندات المرفوضة',
  'Pending Documents'  => 'المستندات قيد المراجعة',
  'Total Documents'    => 'إجمالي المستندات',

  'Approval Rate'      => 'نسبة الاعتماد',
);
