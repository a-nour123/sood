<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ClearTrainingDataSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $tables = [
            // LMS
            'l_m_s_answers',
            'l_m_s_training_module_certificates',
            'l_m_s_user_training_modules',
            'l_m_s_user_levels',

            // Phishing Campaigns
            'phishing_campaign_employee_list',
            'phishing_campaign_email_template',
            'phishing_campaigns',
            'phishing_mail_trackings',

            // Physical Courses
            'course_attendances',
            'course_certificates',
            'course_grades',
            'course_instructor',
            'course_materials',
            'course_requests',
            'course_schedules',
            'courses',
        ];

        DB::statement('SET FOREIGN_KEY_CHECKS = 0');

        try {
            foreach ($tables as $table) {
                DB::statement(
                    'TRUNCATE TABLE `' . $table . '`'
                );

                $this->command->info(
                    "Truncated table: {$table}"
                );
            }
        } finally {
            DB::statement('SET FOREIGN_KEY_CHECKS = 1');
        }

        $this->command->info(
            'All specified tables have been truncated successfully.'
        );
    }
}
