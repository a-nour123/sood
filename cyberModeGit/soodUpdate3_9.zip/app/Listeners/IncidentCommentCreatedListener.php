<?php

namespace App\Listeners;

use App\Events\IncidentCommentCreated;
use App\Http\Traits\NotificationHandlingTrait;
use App\Models\Action;
use App\Models\Incident;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class IncidentCommentCreatedListener
{
    use NotificationHandlingTrait;
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  object  $event
     * @return void
     */
    public function handle(IncidentCommentCreated $event)
    {
        // Get the action ID for Risk_Add
        $action1 = Action::where('name', 'add_incident_comment')->first();
        $actionId1 = $action1['id'];

        // Get the risk object from the event
        $incidentComment = $event->comment;
        $userIds = $incidentComment->incident->playbookUsers->pluck('id')->toArray();
        $tesmIds = $incidentComment->incident?->playbookTeams?->pluck('id')->toArray();

        $roles = [
            'incident_creator' => [$incidentComment?->incident?->created_by ?? null],
            'play_book_user' => $userIds ?? null,
            'Team-teams' => $tesmIds ?? null,
        ];

        $link = ['link' => route('admin.incident.index')];

        $incidentComment->comment = $incidentComment->comment ?? null;

        $incidentComment->Name = $incidentComment?->incident?->summary ?? null;

        $incidentComment->created_by = $incidentComment?->incident?->creator?->name ?? null;
        $incidentComment->play_book_category = $incidentComment?->action?->playBookAction?->category_type ?? null;
        $incidentComment->play_book_title = $incidentComment?->action?->playBookAction?->title ?? null;

        // Call the function to handle different kinds of notifications
        $actionId2 = null;
        $nextDateNotify = null;
        $modelId = null;
        $modelType = null;
        $proccess = null;
        // handling different kinds of notifications using  "sendNotificationForAction" function from "NotificationHandlingTrait"
        $this->sendNotificationForAction($actionId1, $actionId2 = null, $link, $incidentComment, $roles, $nextDateNotify = null, $modelId = null, $modelType = null, $proccess = null);
    }
}