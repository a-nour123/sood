<?php

namespace App\Exports;

use App\Models\FrameworkControl;
use App\Traits\LaravelExportPropertiesTrait;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class FrameworkControlsExport extends BaseExportTemplate
{
    use LaravelExportPropertiesTrait;

    /**
     * Get all framework controls with relationships and mapped objects
     */
    public function collection()
    {
        return FrameworkControl::withCount('frameworkControls')
            ->with([
                'family_with_parent:id,name,parent_id',
                'parentFrameworkControl:id,short_name',
                'phase',
                'priority',
                'maturity',
                'type',
                'class',
                'ControlDesiredMaturity:id,name',
                'custom_test:framework_control_id,name,test_frequency,last_date,tester',
                'Frameworks:id,name',
                'owner:id,name'
            ])
            ->get()
            ->map(function ($control) {
                // Handle raw description
                $rawDescription = $control->getRawOriginal('description');
                if (is_string($rawDescription)) {
                    $description = json_decode($rawDescription, true) ?? [];
                } else {
                    $description = $rawDescription;
                }

                $description_en = $description['en'] ?? '';
                $description_ar = $description['ar'] ?? '';

                $controlFrameworksNames = $control->Frameworks->pluck('name')->implode(', ');

                return (object)[
                    'short_name' => $control->short_name,
                    'long_name' => $control->long_name,
                    'description_en' => $description_en,
                    'description_ar' => $description_ar,
                    'control_number' => $control->control_number,
                    'frame_name' => $controlFrameworksNames,
                    'family_name' => $control->family_with_parent?->name,
                    'family_name_parent' => $control->family_with_parent?->parentFamily?->name,
                    'parent_control' => $control->parentFrameworkControl?->short_name ?? '',
                    'mitigation_percent' => $control->mitigation_percent,
                    'supplemental_guidance' => $control->supplemental_guidance,
                    'priority' => $control->priority->name ?? '',
                    'phase' => $control->phase->name ?? '',
                    'type' => $control->type->name ?? '',
                    'maturity' => $control->maturity->name ?? '',
                    'class' => $control->class->name ?? '',
                    'desired_maturity' => $control->ControlDesiredMaturity->name ?? '',
                    'control_status' => $control->control_status,
                    'owner' => $control->owner?->name,
                    'tester' => $control->custom_test?->UserTester?->name ?? '',
                    'test_name' => $control->custom_test?->name ?? '',
                    'test_frequency' => $control->custom_test?->test_frequency ?? '',
                    'last_test_date' => $control->custom_test?->last_date ?? '',
                ];
            });
    }

    /**
     * Map each control to an array
     */
    public function map($control): array
    {
        return [
            $this->getCounter(),
            $control->short_name,
            $control->long_name,
            $control->description_en,
            $control->description_ar,
            $control->control_number,
            $control->frame_name,
            $control->family_name_parent,
            $control->family_name,
            $control->parent_control,
            $control->mitigation_percent,
            $control->supplemental_guidance,
            $control->priority,
            $control->phase,
            $control->type,
            $control->maturity,
            $control->class,
            $control->desired_maturity,
            $control->control_status,
            $control->owner,
            $control->tester,
            $control->test_name,
            $control->test_frequency,
            $control->last_test_date
        ];
    }

    /**
     * Column headings
     */
    public function headings(): array
    {
        return [
            __('locale.#'),
            __('locale.ControlShortName'),
            __('locale.ControlLongName'),
            __('locale.DescriptionEnglish'),
            __('locale.DescriptionArabic'),
            __('locale.ControlNumber'),
            __('locale.Framework'),
            __('locale.Domain'),
            __('locale.sub_domain'),
            __('locale.ParentControlFramework'),
            __('locale.MitigationPercent'),
            __('locale.SupplementalGuidance'),
            __('locale.ControlPriority'),
            __('locale.ControlPhase'),
            __('locale.ControlType'),
            __('locale.ControlMaturity'),
            __('locale.ControlClass'),
            __('locale.ControlDesiredMaturity'),
            __('locale.ControlStatus'),
            __('locale.ControlOwner'),
            __('locale.Tester'),
            __('locale.TestName'),
            __('locale.TestFrequency') . "(" . __('locale.days') . ")",
            __('locale.LastTestDate')
        ];
    }

    /**
     * Column widths (optional, adjust as needed)
     */
    public function columnWidths(): array
    {
        return [
            'A' => 6,
            'B' => 25,
            'C' => 40,
            'D' => 40,
            'E' => 40,
            'F' => 15,
            'G' => 30,
            'H' => 25,
            'I' => 25,
            'J' => 25,
            'K' => 20,
            'L' => 40,
            'M' => 20,
            'N' => 20,
            'O' => 20,
            'P' => 20,
            'Q' => 20,
            'R' => 20,
            'S' => 15,
            'T' => 25,
            'U' => 25,
            'V' => 30,
            'W' => 20,
            'X' => 20
        ];
    }

    /**
     * Custom styles for wrap text
     */
    protected function applyCustomStyles(Worksheet $sheet)
    {
        $totalRows = $this->collection()->count() + 1;

        // Wrap text for columns that may have long text
        foreach (['C', 'D', 'E', 'L'] as $col) {
            $sheet->getStyle("{$col}2:{$col}{$totalRows}")
                ->getAlignment()
                ->setWrapText(true);
        }
    }
}
