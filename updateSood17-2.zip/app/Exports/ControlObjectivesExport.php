<?php

namespace App\Exports;

use App\Models\ControlObjective;
use App\Models\Framework;
use App\Models\FrameworkControl;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class ControlObjectivesExport extends BaseExportTemplate
{
    private $rows;
    private $frameworks;
    private $controls;

    public function __construct($locale = null)
    {
        parent::__construct($locale);

        /**
         * preload frameworks
         */
        $this->frameworks = Framework::pluck('name','id')
            ->mapWithKeys(fn($name,$id)=>[trim($id)=>$name]);

        /**
         * preload controls
         */
        $this->controls = FrameworkControl::pluck('short_name','id')
            ->mapWithKeys(fn($name,$id)=>[trim($id)=>$name]);

        /**
         * load rows
         */
        $this->rows = ControlObjective::get();
    }

    /**
     * collection
     */
    public function collection()
    {
        return $this->rows;
    }

    /**
     * map
     */
    public function map($row): array
    {
        $frameworkIds = explode(',', str_replace(' ','',$row->framework_id));
        $controlIds   = explode(',', str_replace(' ','',$row->control_id));

        /**
         * names
         */
        $frameworkNames = array_map(
            fn($id)=> $this->frameworks[$id] ?? $id,
            $frameworkIds
        );

        $controlNames = array_map(
            fn($id)=> $this->controls[$id] ?? $id,
            $controlIds
        );

        /**
         * decode json description
         */
        $descArr = json_decode($row->getRawOriginal('description'),true) ?? [];

        $desc_en = isset($descArr['en'])
            ? strip_tags($descArr['en'])
            : '';

        $desc_ar = isset($descArr['ar'])
            ? strip_tags($descArr['ar'])
            : '';

        return [
            $this->getCounter(),
            $row->name,
            $desc_en,
            $desc_ar,
            implode(', ', $frameworkNames),
            implode(', ', $controlNames),
            $row->created_at->format('Y-m-d H:i')
        ];
    }

    /**
     * headers
     */
    public function headings(): array
    {
        return [
            __('locale.#'),
            __('locale.Name'),
            __('locale.Description_English'),
            __('locale.Description_Arabic'),
            __('locale.Framework'),
            __('locale.Controls'),
            __('locale.CreatedDate')
        ];
    }

    /**
     * widths
     */
    public function columnWidths(): array
    {
        return [
            'A'=>6,
            'B'=>30,
            'C'=>60,
            'D'=>60,
            'E'=>40,
            'F'=>40,
            'G'=>20,
        ];
    }

    /**
     * styling
     */
    protected function applyCustomStyles(Worksheet $sheet)
    {
        foreach (['B','C','D','E','F'] as $col) {
            $sheet->getStyle($col)
                ->getAlignment()
                ->setWrapText(true);
        }
    }
}
