<?php

namespace App\Exports;

use App\Models\User;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use App\Traits\LaravelExportPropertiesTrait;

class UsersExport extends BaseExportTemplate
{
    use LaravelExportPropertiesTrait;

    private $rows = [];

    public function __construct(?string $locale = null)
    {
        parent::__construct($locale);

        $this->rows = User::with(['role', 'department'])->get();
    }

    public function collection()
    {
        return collect($this->rows);
    }

    /**
     * Map each user to an export row
     *
     * @var User $user
     */
    public function map($user): array
    {
        return [
            $this->getCounter(),
            $user->type,
            $user->username,
            $user->name,
            $user->email,
            $user->role->name ?? '',
            $user->admin ? '✔' : '✘',
            $user->enabled ? '✔' : '✘',
            $user->department ? $user->department->name : '',
            $user->ldap_region ?? '',
        ];
    }

    public function headings(): array
    {
        return [
            __('locale.#'),
            __('locale.Type'),
            __('locale.Username'),
            __('locale.Name'),
            __('locale.Email'),
            __('locale.Role'),
            __('locale.Admin'),
            __('locale.Active'),
            __('locale.Department'),
            __('configure.Region')
        ];
    }

    /**
     * Column widths
     */
    public function columnWidths(): array
    {
        return [
            'A' => 6,
            'B' => 15,
            'C' => 25,
            'D' => 25,
            'E' => 30,
            'F' => 20,
            'G' => 10,
            'H' => 10,
            'I' => 25,
            'J' => 20,
        ];
    }

    /**
     * Apply wrap text for relevant columns
     */
    protected function applyCustomStyles(Worksheet $sheet)
    {
        $totalRows = count($this->rows) + 1;

        foreach (['C', 'D', 'E', 'I'] as $col) {
            $sheet->getStyle("{$col}2:{$col}{$totalRows}")
                ->getAlignment()
                ->setWrapText(true);
        }
    }
}
