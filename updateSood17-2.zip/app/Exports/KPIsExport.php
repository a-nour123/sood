<?php

namespace App\Exports;

use App\Models\KPI;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use App\Traits\LaravelExportPropertiesTrait;

class KPIsExport extends BaseExportTemplate
{
    use LaravelExportPropertiesTrait;

    private array $rows = [];

    public function __construct($locale = null)
    {
        parent::__construct($locale);

        $kpis = KPI::with([
            'department:id,name',
            'created_by_user:id,username',
            'assessments.created_by_user:id,username',
            'assessments.action_by_user:id,username'
        ])->withCount('assessments')->get();

        foreach ($kpis as $kpi) {
            $assessmentValues = $kpi->assessments->whereNotNull('assessment_value')->pluck('assessment_value');

            if ($assessmentValues->isEmpty()) {
                $this->rows[] = [
                    'title' => $kpi->title,
                    'description' => $kpi->description,
                    'value_type' => $kpi->value_type,
                    'value' => $kpi->value,
                    'assessment_value' => '',
                    'period' => $kpi->period_of_assessment . ' ' . __('locale.Months'),
                    'department' => $kpi->department?->name ?? '',
                    'created_at' => $kpi->created_at->format('Y-m-d H:i'),
                    'created_by' => $kpi->created_by_user?->username ?? '',
                    'assessments_count' => $kpi->assessments_count,
                ];
            } else {
                foreach ($assessmentValues as $value) {
                    $this->rows[] = [
                        'title' => $kpi->title,
                        'description' => $kpi->description,
                        'value_type' => $kpi->value_type,
                        'value' => $kpi->value,
                        'assessment_value' => $value,
                        'period' => $kpi->period_of_assessment . ' ' . __('locale.Months'),
                        'department' => $kpi->department?->name ?? '',
                        'created_at' => $kpi->created_at->format('Y-m-d H:i'),
                        'created_by' => $kpi->created_by_user?->username ?? '',
                        'assessments_count' => $kpi->assessments_count,
                    ];
                }
            }
        }
    }

    /**
     * Return collection
     */
    public function collection()
    {
        return collect($this->rows);
    }

    /**
     * Map each row
     */
    public function map($row): array
    {
        return [
            $this->getCounter(),
            $row['title'],
            $row['description'],
            $row['value_type'],
            $row['value'],
            $row['assessment_value'],
            $row['period'],
            $row['department'],
            $row['created_by'],
            $row['created_at'],
            $row['assessments_count'],
        ];
    }

    /**
     * Headings
     */
    public function headings(): array
    {
        return [
            __('locale.#'),
            __('locale.Title'),
            __('locale.Description'),
            __('locale.Type'),
            __('locale.Value'),
            __('locale.DepartementValue'),
            __('locale.Period'),
            __('locale.Department'),
            __('locale.CreatedBy'),
            __('locale.CreatedDate'),
            __('locale.KPIAssessmentCount'),
        ];
    }

    /**
     * Column widths
     */
    public function columnWidths(): array
    {
        return [
            'A' => 6,
            'B' => 30,
            'C' => 50,
            'D' => 15,
            'E' => 15,
            'F' => 20,
            'G' => 15,
            'H' => 25,
            'I' => 25,
            'J' => 20,
            'K' => 20,
        ];
    }

    /**
     * Apply wrap text
     */
    protected function applyCustomStyles(Worksheet $sheet)
    {
        $totalRows = count($this->rows) + 1;

        foreach (['B','C','F','H','I'] as $col) {
            $sheet->getStyle("{$col}2:{$col}{$totalRows}")
                ->getAlignment()
                ->setWrapText(true);
        }
    }
}
