<?php

namespace App\Exports;

use App\Models\Vulnerability;
use Illuminate\Support\Collection;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Illuminate\Support\Facades\Log;

class VulnerabilitiesExport extends BaseExportTemplate
{
    private Collection $vulnerabilities;

    public function __construct(Collection $vulnerabilities, ?string $locale = null)
    {
        parent::__construct($locale);
        $this->vulnerabilities = $vulnerabilities;
    }

    public function collection()
    {
        return $this->vulnerabilities;
    }

    public function map($vulnerability): array
    {
        try {
            $teamNames   = $vulnerability->teams->pluck('name')->toArray();
            $assetNames  = $vulnerability->assets->pluck('name')->toArray();
            $assetIps    = $vulnerability->assets->pluck('ip')->toArray();
            $assetGroups = $vulnerability->assets->flatMap(fn($asset) => $asset->assetGroups->pluck('name'))->unique()->toArray();
            $regions     = $vulnerability->assets->flatMap(fn($asset) => $asset->hostRegions->pluck('name'))->unique()->toArray();

            return [
                $this->getCounter(),
                $vulnerability->id,
                $vulnerability->name,
                $vulnerability->cve,
                $vulnerability->plugin_id,
                implode(', ', $assetNames),
                implode(', ', $teamNames),
                implode(', ', $assetGroups),
                implode(', ', $regions),
                implode(', ', $assetIps),
                $vulnerability->severity,
                $vulnerability->status,
                $vulnerability->tenable_status,
                $vulnerability->port,
                $vulnerability->exploit,
                $vulnerability->first_discovered,
                $vulnerability->last_observed,
                $vulnerability->description ?? '',
                optional($vulnerability->assets->first())->owner_email ?? '',
            ];
        } catch (\Throwable $e) {
            Log::error('VulnerabilitiesExport map() failed', [
                'vulnerability_id' => $vulnerability->id ?? null,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return array_merge([$this->getCounter(), $vulnerability->id ?? 'N/A', 'Error: ' . $e->getMessage()], array_fill(0, 16, ''));
        }
    }

    public function headings(): array
    {
        return [
            __('locale.#'),
            __('locale.ID'),
            __('locale.Name'),
            __('locale.CVE'),
            __('locale.PluginId'),
            __('locale.Assets'),
            __('locale.Teams'),
            __('locale.AssetCategories'),
            __('locale.Regions'),
            __('locale.AssetIPs'),
            __('locale.Severity'),
            __('locale.OwnerStatus'),
            __('locale.TenableStatus'),
            __('locale.Port'),
            __('locale.Exploit'),
            __('locale.FirstDiscovered'),
            __('locale.LastObserved'),
            __('locale.Description'),
            __('locale.OwnerEmail'),
        ];
    }

/**
 * Implement abstract columnWidths() from BaseExportTemplate
 */
public function columnWidths(): array
{
    return [
        'A' => 5,   // counter
        'B' => 10,  // ID
        'C' => 30,  // Name
        'D' => 15,  // CVE
        'E' => 15,  // PluginId
        'F' => 30,  // Assets
        'G' => 30,  // Teams
        'H' => 25,  // Asset Categories
        'I' => 20,  // Regions
        'J' => 20,  // Asset IPs
        'K' => 12,  // Severity
        'L' => 12,  // Owner Status
        'M' => 15,  // Tenable Status
        'N' => 8,   // Port
        'O' => 15,  // Exploit
        'P' => 18,  // First Discovered
        'Q' => 18,  // Last Observed
        'R' => 50,  // Description
        'S' => 25,  // Owner Email
    ];
}


    protected function applyCustomStyles(Worksheet $sheet)
    {
        $totalRows = $this->vulnerabilities->count() + 1;
        foreach (['C','F','G','H','I','J','R'] as $col) {
            $sheet->getStyle("{$col}2:{$col}{$totalRows}")->getAlignment()->setWrapText(true);
        }
    }
}
