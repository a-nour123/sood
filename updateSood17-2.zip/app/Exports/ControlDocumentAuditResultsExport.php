<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithColumnWidths;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithCustomStartCell;
use Maatwebsite\Excel\Events\AfterSheet;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Font;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;
use App\Models\Document;
use App\Models\MappedControlsCompliance;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\App;

class ControlDocumentAuditResultsExport implements FromArray, WithStyles, WithColumnWidths, WithEvents, WithCustomStartCell
{
    protected $auditData;
    protected $evidenceData = [];
    protected $companyName;
    protected $auditTitle;
    protected $isRTL = false;

    public function __construct($auditId, $companyName = "King Saud University")
    {
        $this->companyName = $companyName;
        $this->auditData = MappedControlsCompliance::with([
            'controlDocuments.controls:id,short_name',
        ])->findOrFail($auditId);

        // Check if current locale is Arabic (RTL)
        $this->isRTL = App::getLocale() == 'ar';

        $this->auditTitle = __('report.Control Document Audit Results');

        $plannedDate = $this->auditData->start_date;
        $query = collect();

        foreach ($this->auditData->controlDocuments as $doc) {
            $policies = $doc->document_actions['policies'] ?? [];

            $normalizedPolicies = collect($policies)->map(function ($p) {
                return is_array($p) ? $p : ['id' => (int) $p];
            });

            $policyIds = $normalizedPolicies->pluck('id')->toArray();
            $policyModels = Document::whereIn('id', $policyIds)->get(['id', 'document_name']);

            foreach ($policyModels as $policy) {
                $policyMeta = $normalizedPolicies->firstWhere('id', $policy->id);

                $reviewer = null;
                if (!empty($policyMeta['updated_by'])) {
                    $user = User::find($policyMeta['updated_by']);
                    $reviewer = $user?->name;
                }

                $action = null;
                $statusColor = 'FFFFFF'; // Default white
                if (($policyMeta['status'] ?? null) === 'approved') {
                    $action = '✔ ' . __('report.Approved');
                } elseif (($policyMeta['status'] ?? null) === 'rejected') {
                    $action = '✘ ' . __('report.Rejected');
                } else {
                    $action = __('report.Pending');
                }

                $query->push([
                    'control_name'  => $doc->controls?->short_name ?? '—',
                    'document_name' => $policy->document_name,
                    'planned_date'  => $plannedDate ? Carbon::parse($plannedDate)->format('Y-m-d') : null,
                    'review_date'   => !empty($policyMeta['updated_at']) ? Carbon::parse($policyMeta['updated_at'])->format('Y-m-d') : null,
                    'reviewer'      => $reviewer,
                    'action'        => $action,
                    'review_notes'  => $policyMeta['note'] ?? null,
                ]);
            }
        }

        $this->evidenceData = $query->toArray();
    }

    public function array(): array
    {
        // Get reviewer names dynamically
        $reviewerNames = '---';
        if (!empty($this->auditData->reviewer_id)) {
            $userIds = explode(',', $this->auditData->reviewer_id);
            $userNames = User::whereIn('id', $userIds)->pluck('name')->toArray();
            $reviewerNames = implode(', ', $userNames) ?: '---';
        }

        // Get version from audit ID
        $version = $this->auditData->id ?? '1';

        // Get date from start_date
        $reviewDate = $this->auditData->start_date ? Carbon::parse($this->auditData->start_date)->format('d/m/Y') : '15/1/2024';

        // Get description
        $description = $this->auditData->description ?? '---';

        $introductionData = [
            [__('report.Document Revision History')],
            [
                __('report.Reviewer'),
                __('report.Version'),
                __('report.Date'),
                __('report.Description')
            ],
            [$reviewerNames, $version, $reviewDate, $description],
            ['', '', '', ''],
            ['', '', '', ''],
            [__('report.Audit Purpose') . ':'],
            [__('report.Audit Purpose Description 1')],
            [__('report.Audit Purpose Description 2')],
            ['', '', '', ''],
            [__('report.Report Generated on') . ': ' . Carbon::now()->format('F j, Y')],
            [__('report.Generated By') . ': ' . (auth()->user()->name ?? __('report.System'))],
            ['', '', '', ''],
            ['', '', '', ''],
            ['', '', '', ''],
        ];

        $headerRow = [
            [
                __('report.Control Name'),
                __('report.Document Name'),
                __('report.Planned Date'),
                __('report.Review Date'),
                __('report.Reviewer'),
                __('report.Action'),
                __('report.Review Notes'),
            ]
        ];

        return array_merge($introductionData, $headerRow, $this->evidenceData);
    }

    public function startCell(): string
    {
        return 'A1';
    }

    public function styles(Worksheet $sheet)
    {
        $totalDataRows = count($this->evidenceData);
        $dataStartRow = 15; // After introduction
        $horizontalAlignment = $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_LEFT;

        return [
            // Title
            1 => [
                'font' => ['bold' => true, 'size' => 16, 'color' => ['rgb' => '1F4E78']],
                'alignment' => ['horizontal' => $horizontalAlignment]
            ],

            // Revision header
            2 => [
                'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'color' => ['rgb' => '1F4E78']
                ]
            ],

            // Revision data row
            3 => [
                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'color' => ['rgb' => 'F2F2F2'] // Light gray background
                ]
            ],

            // Purpose
            6 => [
                'font' => ['bold' => true, 'size' => 12],
            ],

            // Generated info
            10 => [
                'font' => ['italic' => true],
            ],

            // Header row
            $dataStartRow => [
                'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
                'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER, 'vertical' => Alignment::VERTICAL_CENTER],
                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'color' => ['rgb' => '1F4E78'] // Dark blue
                ]
            ],

            // Data rows
            'A' . ($dataStartRow + 1) . ':G' . ($totalDataRows + $dataStartRow) => [
                'alignment' => [
                    'vertical' => Alignment::VERTICAL_CENTER,
                    'horizontal' => $horizontalAlignment,
                ],
                'borders' => [
                    'allBorders' => [
                        'borderStyle' => Border::BORDER_THIN,
                        'color' => ['rgb' => 'D9D9D9']
                    ]
                ]
            ],

            // Notes column specific style
            'G' . ($dataStartRow + 1) . ':G' . ($totalDataRows + $dataStartRow) => [
                'alignment' => [
                    'vertical' => Alignment::VERTICAL_CENTER,
                    'horizontal' => $horizontalAlignment,
                    'wrapText' => true
                ]
            ],

            // Action column specific style
            'F' . ($dataStartRow + 1) . ':F' . ($totalDataRows + $dataStartRow) => [
                'alignment' => [
                    'vertical' => Alignment::VERTICAL_CENTER,
                    'horizontal' => Alignment::HORIZONTAL_CENTER
                ]
            ],

            // All introduction cells
            'A1:D14' => [
                'alignment' => [
                    'vertical' => Alignment::VERTICAL_TOP,
                    'horizontal' => $horizontalAlignment
                ],
            ],
        ];
    }

    public function columnWidths(): array
    {
        if ($this->isRTL) {
            return [
                'A' => 25, // Control Name
                'B' => 40, // Document Name (wider for Arabic)
                'C' => 15, // Planned Date
                'D' => 15, // Review Date
                'E' => 30, // Reviewer (wider for Arabic)
                'F' => 15, // Action
                'G' => 45, // Review Notes (wider for Arabic)
            ];
        }

        return [
            'A' => 25, // Control Name
            'B' => 35, // Document Name
            'C' => 15, // Planned Date
            'D' => 15, // Review Date
            'E' => 25, // Reviewer
            'F' => 15, // Action
            'G' => 40, // Review Notes
        ];
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event) {
                $sheet = $event->sheet->getDelegate();
                $totalDataRows = count($this->evidenceData);
                $dataStartRow = 16; // After introduction
                $horizontalAlignment = $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_LEFT;

                // Set sheet direction for RTL
                if ($this->isRTL) {
                    $sheet->setRightToLeft(true);
                }

                // Add logo - position on the left side visually
                $drawing = new Drawing();
                $drawing->setName('Logo');
                $drawing->setDescription('Logo');
                $drawing->setPath(public_path('images/ksu-logo.png'));
                $drawing->setHeight(70);
                
                // Position logo on the left side visually:
                // - In LTR mode, left side is column A
                // - In RTL mode, left side is the last column (G)
                if ($this->isRTL) {
                    $drawing->setCoordinates('G1'); // Last column in RTL appears on left side
                } else {
                    $drawing->setCoordinates('G1'); // First column in LTR appears on left side
                }
                $drawing->setWorksheet($sheet);

                // // Set company name on the left side visually
                // if ($this->isRTL) {
                //     // For RTL, place company name starting from column E to G to appear on left
                //     $sheet->setCellValue('E3', $this->companyName);
                //     $sheet->mergeCells('E3:G3');
                // } else {
                //     // For LTR, place company name starting from column A to C to appear on left
                //     $sheet->setCellValue('A3', $this->companyName);
                //     $sheet->mergeCells('A3:C3');
                // }
                
                $sheet->getStyle($this->isRTL ? 'E3' : 'A3')->applyFromArray([
                    'font' => ['bold' => true, 'size' => 14, 'color' => ['rgb' => '1F4E78']],
                    'alignment' => ['horizontal' => $horizontalAlignment]
                ]);

                // Add borders to revision history
                $sheet->getStyle('A2:D4')->applyFromArray([
                    'borders' => [
                        'allBorders' => [
                            'borderStyle' => Border::BORDER_THIN,
                            'color' => ['rgb' => '000000']
                        ]
                    ]
                ]);

                // Format revision history header
                $sheet->getStyle('A2:D2')->applyFromArray([
                    'alignment' => [
                        'horizontal' => Alignment::HORIZONTAL_CENTER,
                    ]
                ]);

                // Format revision history data
                $sheet->getStyle('A3:D3')->applyFromArray([
                    'alignment' => [
                        'horizontal' => $horizontalAlignment,
                    ]
                ]);

                // Apply zebra striping to data rows
                for ($i = $dataStartRow + 1; $i < $totalDataRows + $dataStartRow + 1; $i++) {
                    if ($i % 2 == 0) {
                        $sheet->getStyle('A' . $i . ':G' . $i)->applyFromArray([
                            'fill' => [
                                'fillType' => Fill::FILL_SOLID,
                                'color' => ['rgb' => 'F2F2F2'] // Light gray for even rows
                            ]
                        ]);
                    }
                }

                // Format date columns
                $sheet->getStyle('C' . ($dataStartRow + 1) . ':D' . ($totalDataRows + $dataStartRow))->applyFromArray([
                    'alignment' => [
                        'horizontal' => Alignment::HORIZONTAL_CENTER
                    ],
                    'numberFormat' => [
                        'formatCode' => 'yyyy-mm-dd'
                    ]
                ]);

                // Add summary section
                $summaryRow = $totalDataRows + $dataStartRow + 2;
                $sheet->setCellValue('A' . $summaryRow, __('report.Summary'));
                $sheet->getStyle('A' . $summaryRow)->applyFromArray([
                    'font' => ['bold' => true, 'size' => 14, 'color' => ['rgb' => '1F4E78']],
                    'fill' => [
                        'fillType' => Fill::FILL_SOLID,
                        'color' => ['rgb' => 'DDEBF7'] // Light blue
                    ]
                ]);
                $sheet->mergeCells('A' . $summaryRow . ':G' . $summaryRow);
                $sheet->getStyle('A' . $summaryRow . ':G' . $summaryRow)->applyFromArray([
                    'alignment' => [
                        'horizontal' => Alignment::HORIZONTAL_CENTER
                    ],
                    'borders' => [
                        'outline' => [
                            'borderStyle' => Border::BORDER_MEDIUM,
                            'color' => ['rgb' => '1F4E78']
                        ]
                    ]
                ]);

                // Approved count
                $approvedCount = count(array_filter($this->evidenceData, function ($item) {
                    return strpos($item['action'], '✔') !== false;
                }));

                $sheet->setCellValue('A' . ($summaryRow + 1), __('report.Approved Documents') . ':');
                $sheet->setCellValue('B' . ($summaryRow + 1), $approvedCount);
                $sheet->getStyle('A' . ($summaryRow + 1) . ':B' . ($summaryRow + 1))->applyFromArray([
                    'fill' => [
                        'fillType' => Fill::FILL_SOLID,
                        'color' => ['rgb' => 'E2EFDA'] // Very light green
                    ],
                    'borders' => [
                        'outline' => [
                            'borderStyle' => Border::BORDER_THIN,
                            'color' => ['rgb' => 'A9D08E']
                        ]
                    ],
                    'alignment' => [
                        'horizontal' => $horizontalAlignment
                    ]
                ]);
                $sheet->getStyle('B' . ($summaryRow + 1))->applyFromArray([
                    'alignment' => [
                        'horizontal' => Alignment::HORIZONTAL_CENTER
                    ],
                    'font' => ['bold' => true, 'size' => 12]
                ]);

                // Rejected count
                $rejectedCount = count(array_filter($this->evidenceData, function ($item) {
                    return strpos($item['action'], '✘') !== false;
                }));

                $sheet->setCellValue('D' . ($summaryRow + 1), __('report.Rejected Documents') . ':');
                $sheet->setCellValue('E' . ($summaryRow + 1), $rejectedCount);
                
                $sheet->getStyle('D' . ($summaryRow + 1) . ':E' . ($summaryRow + 1))->applyFromArray([
                    'fill' => [
                        'fillType' => Fill::FILL_SOLID,
                        'color' => ['rgb' => 'FCE4D6'] // Very light red
                    ],
                    'borders' => [
                        'outline' => [
                            'borderStyle' => Border::BORDER_THIN,
                            'color' => ['rgb' => 'FF7C80']
                        ]
                    ],
                    'alignment' => [
                        'horizontal' => $horizontalAlignment
                    ]
                ]);
                $sheet->getStyle('E' . ($summaryRow + 1))->applyFromArray([
                    'alignment' => [
                        'horizontal' => Alignment::HORIZONTAL_CENTER
                    ],
                    'font' => ['bold' => true, 'size' => 12]
                ]);

                // Pending count
                $pendingCount = count(array_filter($this->evidenceData, function ($item) {
                    return strpos($item['action'], __('report.Pending')) !== false;
                }));

                $sheet->setCellValue('A' . ($summaryRow + 2), __('report.Pending Documents') . ':');
                $sheet->setCellValue('B' . ($summaryRow + 2), $pendingCount);
                $sheet->getStyle('A' . ($summaryRow + 2) . ':B' . ($summaryRow + 2))->applyFromArray([
                    'fill' => [
                        'fillType' => Fill::FILL_SOLID,
                        'color' => ['rgb' => 'FFF2CC'] // Very light yellow
                    ],
                    'borders' => [
                        'outline' => [
                            'borderStyle' => Border::BORDER_THIN,
                            'color' => ['rgb' => 'FFD966']
                        ]
                    ],
                    'alignment' => [
                        'horizontal' => $horizontalAlignment
                    ]
                ]);
                $sheet->getStyle('B' . ($summaryRow + 2))->applyFromArray([
                    'alignment' => [
                        'horizontal' => Alignment::HORIZONTAL_CENTER
                    ],
                    'font' => ['bold' => true, 'size' => 12]
                ]);

                // Total count
                $sheet->setCellValue('D' . ($summaryRow + 2), __('report.Total Documents') . ':');
                $sheet->setCellValue('E' . ($summaryRow + 2), $totalDataRows);
                $sheet->getStyle('D' . ($summaryRow + 2) . ':E' . ($summaryRow + 2))->applyFromArray([
                    'fill' => [
                        'fillType' => Fill::FILL_SOLID,
                        'color' => ['rgb' => 'DDEBF7'] // Light blue
                    ],
                    'borders' => [
                        'outline' => [
                            'borderStyle' => Border::BORDER_THIN,
                            'color' => ['rgb' => '5B9BD5']
                        ]
                    ],
                    'alignment' => [
                        'horizontal' => $horizontalAlignment
                    ]
                ]);
                $sheet->getStyle('E' . ($summaryRow + 2))->applyFromArray([
                    'alignment' => [
                        'horizontal' => Alignment::HORIZONTAL_CENTER
                    ],
                    'font' => ['bold' => true, 'size' => 12]
                ]);

                // Add percentage summary
                if ($totalDataRows > 0) {
                    $approvalRate = round(($approvedCount / $totalDataRows) * 100, 2);

                    $sheet->setCellValue('A' . ($summaryRow + 4), __('report.Approval Rate') . ':');
                    $sheet->setCellValue('B' . ($summaryRow + 4), $approvalRate . '%');
                    $sheet->getStyle('A' . ($summaryRow + 4) . ':B' . ($summaryRow + 4))->applyFromArray([
                        'fill' => [
                            'fillType' => Fill::FILL_SOLID,
                            'color' => ['rgb' => 'E2EFDA'] // Very light green
                        ],
                        'borders' => [
                            'outline' => [
                                'borderStyle' => Border::BORDER_MEDIUM,
                                'color' => ['rgb' => '70AD47']
                            ]
                        ],
                        'font' => ['bold' => true],
                        'alignment' => [
                            'horizontal' => $horizontalAlignment
                        ]
                    ]);
                    $sheet->getStyle('B' . ($summaryRow + 4))->applyFromArray([
                        'alignment' => [
                            'horizontal' => Alignment::HORIZONTAL_CENTER
                        ]
                    ]);
                }

                // Freeze panes (header row stays visible when scrolling)
                $sheet->freezePane('A' . ($dataStartRow + 1));
            },
        ];
    }
}