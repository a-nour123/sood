<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithColumnWidths;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;

abstract class BaseExportTemplate implements
    FromCollection,
    WithMapping,
    WithHeadings,
    WithStyles,
    WithColumnWidths,
    WithEvents
{
    protected $counter = 1;
    protected $isRTL;
    protected $logoPath;
    protected $logoHeight;

    public function __construct($locale = null)
    {
        $locale = $locale ?? app()->getLocale();
        app()->setLocale($locale);

        $this->isRTL = $locale === 'ar';

        $this->logoPath = public_path('images/ksu-logo.png');
        $this->logoHeight = 70;
    }

    abstract public function collection();
    abstract public function map($item): array;
    abstract public function headings(): array;
    abstract public function columnWidths(): array;

    /**
     * last column letter dynamically
     */
    protected function getLastColumnLetter(): string
    {
        return Coordinate::stringFromColumnIndex(count($this->headings()));
    }

    /**
     * styles
     */
    public function styles(Worksheet $sheet)
    {
        $headerAlignment = $this->isRTL
            ? Alignment::HORIZONTAL_RIGHT
            : Alignment::HORIZONTAL_CENTER;

        $dataAlignment = $this->isRTL
            ? Alignment::HORIZONTAL_RIGHT
            : Alignment::HORIZONTAL_LEFT;

        $lastColumn = $this->getLastColumnLetter();
        $totalRows = $this->collection()->count() + 1;

        return [
            1 => [
                'font' => [
                    'bold' => true,
                    'color' => ['rgb' => '2F5496']
                ],
                'alignment' => [
                    'horizontal' => $headerAlignment,
                    'vertical' => Alignment::VERTICAL_CENTER
                ],
                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'color' => ['rgb' => 'E7E6E6']
                ]
            ],

            "A2:{$lastColumn}{$totalRows}" => [
                'alignment' => [
                    'vertical' => Alignment::VERTICAL_CENTER,
                    'horizontal' => $dataAlignment,
                ],
                'borders' => [
                    'allBorders' => [
                        'borderStyle' => Border::BORDER_THIN,
                        'color' => ['rgb' => 'D9D9D9']
                    ]
                ]
            ],

            "A2:A{$totalRows}" => [
                'alignment' => [
                    'horizontal' => Alignment::HORIZONTAL_CENTER
                ]
            ],
        ];
    }

    /**
     * events
     */
    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event) {

                $sheet = $event->sheet->getDelegate();

                if ($this->isRTL) {
                    $sheet->setRightToLeft(true);
                }

                /**
                 * logo column after last column
                 */
                $lastIndex = Coordinate::columnIndexFromString(
                    $this->getLastColumnLetter()
                );

                $logoColumn = Coordinate::stringFromColumnIndex($lastIndex + 1);

                /**
                 * insert logo
                 */
                if (file_exists($this->logoPath)) {

                    $drawing = new Drawing();
                    $drawing->setName('Logo');
                    $drawing->setDescription('Logo');
                    $drawing->setPath($this->logoPath);
                    $drawing->setHeight($this->logoHeight);
                    $drawing->setCoordinates($logoColumn . '1');
                    $drawing->setOffsetX(10);
                    $drawing->setOffsetY(5);
                    $drawing->setWorksheet($sheet);
                }

                $sheet->getRowDimension(1)->setRowHeight(60);
                $sheet->freezePane('A2');

                $sheet->getColumnDimension($logoColumn)->setWidth(30);

                $this->applyCustomStyles($sheet);
            }
        ];
    }

    /**
     * override if needed
     */
    protected function applyCustomStyles(Worksheet $sheet)
    {
    }

    protected function getCounter(): int
    {
        return $this->counter++;
    }
}
