<?php

namespace App\Exports;

use App\Models\Asset;
use App\Models\Risk;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class ExportData extends BaseExportTemplate
{
    protected $table;

    public function __construct($locale = null)
    {
        parent::__construct($locale);
        $this->table = session()->get('table');
    }

    /**
     * Return collection based on session table
     */
    public function collection()
    {
        if ($this->table === 'assets') {
            return Asset::with('location', 'assetValue')->get();
        } elseif ($this->table === 'risks') {
            return Risk::all();
        }

        return collect(); // empty collection if table is not set
    }

    /**
     * Map each row based on table
     */
    public function map($item): array
    {
        if ($this->table === 'assets') {
            return [
                $this->getCounter(),
                $item->ip,
                $item->name,
                optional($item->assetValue)->min_value,
                optional($item->assetValue)->max_value,
                optional($item->location)->name,
                $item->teams,
                $item->details,
            ];
        } elseif ($this->table === 'risks') {
            return [
                $this->getCounter(),
                $item->subject,
                $item->status,
                $item->regulation,
                $item->subject,
                $item->reference_id,
                $item->regulatio,
                $item->control_id,
                $item->category_id,
                $item->owner_id,
                $item->manager_id,
                $item->assessment,
                $item->notes,
                $item->review_date,
                $item->mitigation_id,
                $item->mgmt_review,
                $item->project_id,
                $item->close_id,
                $item->submitted_by,
                $item->risk_catalog_mapping,
                $item->threat_catalog_mapping,
                $item->template_group_id
            ];
        }
    }

    /**
     * Headings based on table
     */
    public function headings(): array
    {
        if ($this->table === 'assets') {
            return [
                '#',
                'IP',
                'Name',
                'Asset Min Value',
                'Asset Max Value',
                'Location',
                'Team',
                'Details',
            ];
        } elseif ($this->table === 'risks') {
            return [
                '#',
                'Subject',
                'Status',
                'Regulation',
                'Subject',
                'Reference ID',
                'Regulatio',
                'Control ID',
                'Category ID',
                'Owner ID',
                'Manager ID',
                'Assessment',
                'Notes',
                'Review Date',
                'Mitigation ID',
                'Mgmt Review',
                'Project ID',
                'Close ID',
                'Submitted By',
                'Risk Catalog Mapping',
                'Threat Catalog Mapping',
                'Template Group ID'
            ];
        }

        return [];
    }

    /**
     * Column widths (optional, adjust as needed)
     */
    public function columnWidths(): array
    {
        if ($this->table === 'assets') {
            return [
                'A' => 6,
                'B' => 20,
                'C' => 30,
                'D' => 20,
                'E' => 20,
                'F' => 25,
                'G' => 20,
                'H' => 40,
            ];
        } elseif ($this->table === 'risks') {
            return [
                'A' => 6,
                'B' => 30,
                'C' => 15,
                'D' => 20,
                'E' => 30,
                'F' => 15,
                'G' => 20,
                'H' => 15,
                'I' => 15,
                'J' => 15,
                'K' => 15,
                'L' => 20,
                'M' => 40,
                'N' => 20,
                'O' => 15,
                'P' => 15,
                'Q' => 15,
                'R' => 15,
                'S' => 15,
                'T' => 20,
                'U' => 20,
                'V' => 20,
            ];
        }

        return [];
    }

    /**
     * Optional: wrap text for specific columns
     */
    protected function applyCustomStyles(Worksheet $sheet)
    {
        $totalRows = $this->collection()->count() + 1;

        if ($this->table === 'assets') {
            foreach (['C', 'H'] as $col) {
                $sheet->getStyle("{$col}2:{$col}{$totalRows}")
                    ->getAlignment()
                    ->setWrapText(true);
            }
        } elseif ($this->table === 'risks') {
            foreach (['B', 'M'] as $col) {
                $sheet->getStyle("{$col}2:{$col}{$totalRows}")
                    ->getAlignment()
                    ->setWrapText(true);
            }
        }
    }
}
