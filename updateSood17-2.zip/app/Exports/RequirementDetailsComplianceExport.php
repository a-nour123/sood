<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithColumnWidths;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithDrawings;
use Maatwebsite\Excel\Events\AfterSheet;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Font;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;
use App\Models\AuditResponsible;
use App\Models\FrameworkControlTestAudit;
use Carbon\Carbon;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Storage;

class RequirementDetailsComplianceExport implements FromArray, WithStyles, WithColumnWidths, WithEvents, WithDrawings
{
    protected $frameworkId;
    protected $auditId;
    protected $auditData;
    protected $companyName;
    protected $currentRow = 1;
    protected $totalRows = 0;
    protected $drawings = [];
    protected $imagePositions = [];
    protected $isRTL = false;
    protected $testNumber = 'N/A';
    protected $statistics = [];

    public function __construct($frameworkId, $auditId, $companyName = "King Saud University")
    {
        $this->frameworkId = $frameworkId;
        $this->auditId = $auditId;
        $this->companyName = $companyName;
        
        // Check if current locale is Arabic (RTL)
        $this->isRTL = App::getLocale() == 'ar';
        
        $this->prepareData();
        $this->calculateStatistics();
    }

    protected function prepareData()
    {
        // Get audit information with all necessary relationships
        $this->auditData = AuditResponsible::with([
            'frameworkaduit',
            'owner',
            'frameworkControlTestAudits' => function($query) {
                $query->with([
                    'frameworkControl',
                    'frameworkControl.Family',
                    'controlAuditEvidences' => function($q) {
                        $q->with(['evidence.creator']);
                    },
                    'FrameworkControlTestResult.testResult',
                    'UserTester'
                ]);
            }
        ])
        ->where('framework_id', $this->frameworkId)
        ->where('id', $this->auditId)
        ->first();

        if (!$this->auditData) {
            return;
        }

        // Get test number from the first audit
        $firstAudit = $this->auditData->frameworkControlTestAudits->first();
        if ($firstAudit) {
            $testNumberArray = json_decode($firstAudit->test_number, true);
            $this->testNumber = $testNumberArray[0] ?? 'N/A';
        }
    }

    protected function calculateStatistics()
    {
        $totalControls = 0;
        $totalEvidence = 0;
        $approvedEvidence = 0;
        $rejectedEvidence = 0;
        $noActionEvidence = 0;

        foreach ($this->auditData->frameworkControlTestAudits as $testAudit) {
            $totalControls++;
            
            foreach ($testAudit->controlAuditEvidences as $evidence) {
                $totalEvidence++;
                $status = $evidence->evidence_audit_status ?? 'no_action';
                
                switch ($status) {
                    case 'approved':
                        $approvedEvidence++;
                        break;
                    case 'rejected':
                        $rejectedEvidence++;
                        break;
                    case 'no_action':
                    default:
                        $noActionEvidence++;
                        break;
                }
            }
        }

        $complianceRate = $totalEvidence > 0 ? round(($approvedEvidence / $totalEvidence) * 100, 2) : 0;

        $this->statistics = [
            'total_controls' => $totalControls,
            'total_evidence' => $totalEvidence,
            'approved_evidence' => $approvedEvidence,
            'rejected_evidence' => $rejectedEvidence,
            'no_action_evidence' => $noActionEvidence,
            'compliance_rate' => $complianceRate,
        ];
    }

    public function drawings()
    {
        return $this->drawings;
    }

    public function array(): array
    {
        $data = [];
        $currentDataRow = 0;

        // Report Header Section
        $data[] = [__('report.REQUIREMENT DETAILS COMPLIANCE REPORT'), '', '', '', '', '', '', '', ''];
        $data[] = ['', '', '', '', '', '', '', '', ''];
        $currentDataRow += 2;

        // Audit Information Section
        $data[] = [
            __('report.Framework') . ':',
            $this->auditData->frameworkaduit->name ?? 'N/A',
            __('report.Audit Name') . ':',
            $this->auditData->audit_name ?? 'N/A',
            __('report.Test Number') . ':',
            $this->testNumber,
            __('report.Generated') . ':',
            date('Y-m-d H:i:s'),
            ''
        ];
        $data[] = [
            __('report.Responsible') . ':',
            $this->auditData->owner->name ?? 'N/A',
            '',
            __('report.Generated By') . ':',
            auth()->user()->name ?? __('report.System'),
            '',
            '',
            '',
            ''
        ];
        $data[] = ['', '', '', '', '', '', '', '', ''];
        $currentDataRow += 3;

        // Summary Section
        $data[] = [__('report.EXECUTIVE SUMMARY'), '', '', '', '', '', '', '', ''];
        $data[] = ['', '', '', '', '', '', '', '', ''];
        $data[] = [
            __('report.Total Controls') . ':',
            $this->statistics['total_controls'],
            '',
            __('report.Total Evidence') . ':',
            $this->statistics['total_evidence'],
            '',
            __('report.Compliance Rate') . ':',
            $this->statistics['compliance_rate'] . '%',
            ''
        ];
        $data[] = [
            __('report.Approved Evidence') . ':',
            $this->statistics['approved_evidence'],
            '',
            __('report.Rejected Evidence') . ':',
            $this->statistics['rejected_evidence'],
            '',
            __('report.No Action Evidence') . ':',
            $this->statistics['no_action_evidence'],
            ''
        ];
        $data[] = ['', '', '', '', '', '', '', '', ''];
        $currentDataRow += 5;

        // Controls Detail Section
        $data[] = [__('report.CONTROL DETAILS WITH EVIDENCE'), '', '', '', '', '', '', '', ''];
        $data[] = ['', '', '', '', '', '', '', '', ''];
        $currentDataRow += 2;

        $controlIndex = 0;
        foreach ($this->auditData->frameworkControlTestAudits as $testAudit) {
            $controlIndex++;
            $frameworkControl = $testAudit->frameworkControl;
            $familyName = $frameworkControl && $frameworkControl->Family ? $frameworkControl->Family->name : __('report.Uncategorized');

            // Control Header
            $data[] = ['', '', '', '', '', '', '', '', ''];
            $currentDataRow += 1;

            $data[] = [
                __('report.CONTROL') . ' ' . $controlIndex,
                $frameworkControl->short_name ?? 'N/A',
                '',
                __('report.FAMILY') . ':',
                $familyName,
                __('report.STATUS') . ':',
                $this->getTestStatus($testAudit),
                '',
                ''
            ];
            $currentDataRow += 1;

            $data[] = ['', '', '', '', '', '', '', '', ''];
            $currentDataRow += 1;

            // Control Details Table
            $data[] = ['', __('report.Attribute'), __('report.Value'), '', __('report.Metrics'), __('report.Count'), '', '', ''];
            $data[] = ['', __('report.Control ID'), $testAudit->framework_control_id, '', __('report.Total Evidence'), $testAudit->controlAuditEvidences->count(), '', '', ''];
            $data[] = ['', __('report.Tester'), $testAudit->UserTester->name ?? 'N/A', '', __('report.Approved Evidence'), $testAudit->controlAuditEvidences->where('evidence_audit_status', 'approved')->count(), '', '', ''];
            $data[] = ['', __('report.Created Date'), $this->formatDate($testAudit->created_at), '', __('report.Rejected Evidence'), $testAudit->controlAuditEvidences->where('evidence_audit_status', 'rejected')->count(), '', '', ''];
            $data[] = ['', '', '', '', '', '', '', '', ''];
            $currentDataRow += 5;

            // Evidence Section
            if ($testAudit->controlAuditEvidences->count() > 0) {
                $data[] = ['', __('report.SUPPORTING EVIDENCE'), '', '', '', '', '', '', ''];
                $data[] = ['', '', '', '', '', '', '', '', ''];
                $data[] = ['', '#', __('report.Evidence Name'), __('report.Status'), __('report.Description'), __('report.Created By'), __('report.Upload Date'), __('report.Updated Date'), __('report.File')];
                $currentDataRow += 3;

                foreach ($testAudit->controlAuditEvidences as $evIndex => $evidence) {
                    $fileName = $evidence->evidence->file_name ?? 'N/A';
                    $filePath = $evidence->evidence->file_unique_name ?? null;
                    $isImage = $filePath ? $this->isImageFile($filePath) : false;

                    $fileCellValue = '';
                    if ($filePath) {
                        if ($isImage) {
                            $fileCellValue = ''; // Empty for images (will be handled by drawing)
                        } else {
                            $fileCellValue = __('report.View File');
                        }
                    } else {
                        $fileCellValue = __('report.File Missing');
                    }

                    $data[] = [
                        '',
                        $evIndex + 1,
                        $evidence->evidence->description ?? 'N/A',
                        $this->getEvidenceStatus($evidence->evidence_audit_status),
                        $evidence->evidence->description ?? '-',
                        $evidence->evidence->creator->name ?? 'N/A',
                        $this->formatDate($evidence->created_at),
                        $this->formatDate($evidence->updated_at),
                        $fileCellValue
                    ];
                    $currentDataRow += 1;

                    // Handle image files
                    if ($filePath && $isImage && Storage::disk('local')->exists($filePath)) {
                        $this->addImageDrawing($evidence, $currentDataRow);
                    }
                }
                $data[] = ['', '', '', '', '', '', '', '', ''];
                $currentDataRow += 1;
            } else {
                $data[] = ['', __('report.NO EVIDENCE AVAILABLE'), '', '', '', '', '', '', ''];
                $data[] = ['', '', '', '', '', '', '', '', ''];
                $currentDataRow += 2;
            }

            // Add spacer between controls
            $data[] = ['', '', '', '', '', '', '', '', ''];
            $currentDataRow += 1;
        }

        $currentDataRow += 4;
        $this->totalRows = count($data);
        
        return $data;
    }

    protected function addImageDrawing($evidence, $rowNumber)
    {
        $filePath = $evidence->evidence->file_unique_name;
        $fileName = $evidence->evidence->file_name ?? 'image';
        
        $drawing = new Drawing();
        $drawing->setName($fileName);
        $drawing->setDescription($evidence->evidence->description ?? '');
        $drawing->setPath(storage_path('app/' . $filePath));

        // Set image size (max 150x150px, maintaining aspect ratio)
        list($width, $height) = getimagesize(storage_path('app/' . $filePath));
        $ratio = $width / $height;
        if ($ratio > 1) {
            $drawing->setWidth(150);
            $drawing->setHeight(150 / $ratio);
        } else {
            $drawing->setHeight(150);
            $drawing->setWidth(150 * $ratio);
        }

        // Position in the I column (File column)
        $drawing->setCoordinates('I' . $rowNumber);
        $this->imagePositions[] = $rowNumber;
        $this->drawings[] = $drawing;
    }

    public function styles(Worksheet $sheet)
    {
        $horizontalAlignment = $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_LEFT;
        
        return [
            // Default style for all cells
            'A:I' => [
                'font' => ['size' => 10],
                'alignment' => [
                    'vertical' => Alignment::VERTICAL_CENTER,
                    'horizontal' => $horizontalAlignment
                ]
            ]
        ];
    }

    public function columnWidths(): array
    {
        if ($this->isRTL) {
            return [
                'A' => 14,   // Spacer/Index
                'B' => 30,   // Control Name/Main content
                'C' => 25,   // Details
                'D' => 18,   // Labels
                'E' => 25,   // Values/Family
                'F' => 18,   // Status/Metrics
                'G' => 18,   // Counts/Dates
                'H' => 18,   // Additional info
                'I' => 25,   // File column (wider for images)
            ];
        }
        
        return [
            'A' => 14,   // Spacer/Index
            'B' => 25,   // Control Name/Main content
            'C' => 22,   // Details
            'D' => 15,   // Labels
            'E' => 22,   // Values/Family
            'F' => 15,   // Status/Metrics
            'G' => 15,   // Counts/Dates
            'H' => 15,   // Additional info
            'I' => 25,   // File column (wider for images)
        ];
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event) {
                $sheet = $event->sheet->getDelegate();

                // Set default alignment based on locale
                $horizontalAlignment = $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_LEFT;
                
                // Set sheet direction for RTL
                if ($this->isRTL) {
                    $sheet->setRightToLeft(true);
                }

                // Add logo in column J
                $this->addLogo($sheet);

                // Main title styling
                $this->styleMainTitle($sheet);

                // Audit info section
                $this->styleAuditInfo($sheet);

                // Summary section
                $this->styleSummarySection($sheet);

                // Controls section
                $this->styleControlsSection($sheet);

                // Apply borders and general formatting
                $this->applyGeneralFormatting($sheet);

                // Add hyperlinks for non-image files
                for ($row = 1; $row <= $this->totalRows; $row++) {
                    $cellValue = $sheet->getCell('I' . $row)->getValue();
                    if ($cellValue === __('report.View File')) {
                        $sheet->getStyle('I' . $row)
                            ->getFont()
                            ->setColor(new \PhpOffice\PhpSpreadsheet\Style\Color(\PhpOffice\PhpSpreadsheet\Style\Color::COLOR_BLUE))
                            ->setUnderline(true);
                    }
                }

                // Auto-fit row heights for regular rows
                for ($row = 1; $row <= $this->totalRows; $row++) {
                    $sheet->getRowDimension($row)->setRowHeight(-1);
                }

                // Set specific row heights for rows with images
                foreach ($this->imagePositions as $imageRow) {
                    $sheet->getRowDimension($imageRow)->setRowHeight(120);
                }

                // Enable text wrapping
                $sheet->getStyle('A1:I' . $this->totalRows)
                    ->getAlignment()
                    ->setWrapText(true)
                    ->setHorizontal($horizontalAlignment);

                // Add footer
                $sheet->getHeaderFooter()
                    ->setOddFooter('&L' . __('report.Generated by Audit System') . ' &C' . __('report.Confidential') . ' &R' . __('report.Page') . ' &P ' . __('report.of') . ' &N');
            }
        ];
    }

    protected function addLogo($sheet)
    {
        try {
            $drawing = new Drawing();
            $drawing->setName('Logo');
            $drawing->setDescription('Logo');
            $drawing->setPath(public_path('images/ksu-logo.png'));
            $drawing->setHeight(60);
            
            // Position logo in column J (outside data range)
            if ($this->isRTL) {
                // In RTL mode, column J appears on the left side
                $drawing->setCoordinates('J1');
                
            } else {
                // In LTR mode, column J appears on the right side
                $drawing->setCoordinates('J1');
                
            }
            
            $drawing->setWorksheet($sheet);
            
            // Set column J width for logo
            $sheet->getColumnDimension('J')->setWidth(25);
            
        } catch (\Exception $e) {
            // Logo might not exist, continue without it
        }
    }

    private function styleMainTitle($sheet)
    {
        $horizontalAlignment = $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_CENTER;
        
        // Main title (only up to column I)
        $sheet->mergeCells('A1:I1');
        $sheet->getStyle('A1:I1')->applyFromArray([
            'font' => [
                'bold' => true,
                'size' => 18,
                'color' => ['rgb' => 'FFFFFF']
            ],
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'startColor' => ['rgb' => '1B365D']
            ],
            'alignment' => [
                'horizontal' => $horizontalAlignment,
                'vertical' => Alignment::VERTICAL_CENTER
            ]
        ]);
        $sheet->getRowDimension(1)->setRowHeight(35);
    }

    private function styleAuditInfo($sheet)
    {
        if ($this->isRTL) {
            // RTL styling for audit info
            $infoRows = [3, 4];
            foreach ($infoRows as $row) {
                $sheet->getStyle("F{$row}:G{$row}")->applyFromArray([
                    'font' => ['bold' => true, 'color' => ['rgb' => '2F5F8F']],
                    'fill' => [
                        'fillType' => Fill::FILL_SOLID,
                        'startColor' => ['rgb' => 'E6F1FF']
                    ]
                ]);

                $sheet->getStyle("D{$row}:E{$row}")->applyFromArray([
                    'font' => ['bold' => true, 'color' => ['rgb' => '2F5F8F']],
                    'fill' => [
                        'fillType' => Fill::FILL_SOLID,
                        'startColor' => ['rgb' => 'E6F1FF']
                    ]
                ]);

                $sheet->getStyle("A{$row}:B{$row}")->applyFromArray([
                    'font' => ['bold' => true, 'color' => ['rgb' => '2F5F8F']],
                    'fill' => [
                        'fillType' => Fill::FILL_SOLID,
                        'startColor' => ['rgb' => 'E6F1FF']
                    ]
                ]);
            }

            foreach ($infoRows as $row) {
                $sheet->getStyle("G{$row}")->applyFromArray([
                    'font' => ['color' => ['rgb' => '1B365D']]
                ]);
                $sheet->getStyle("E{$row}")->applyFromArray([
                    'font' => ['color' => ['rgb' => '1B365D']]
                ]);
                $sheet->getStyle("B{$row}")->applyFromArray([
                    'font' => ['color' => ['rgb' => '1B365D']]
                ]);
            }
        } else {
            // LTR styling
            $infoRows = [3, 4];
            foreach ($infoRows as $row) {
                $sheet->getStyle("A{$row}:B{$row}")->applyFromArray([
                    'font' => ['bold' => true, 'color' => ['rgb' => '2F5F8F']],
                    'fill' => [
                        'fillType' => Fill::FILL_SOLID,
                        'startColor' => ['rgb' => 'E6F1FF']
                    ]
                ]);

                $sheet->getStyle("D{$row}:E{$row}")->applyFromArray([
                    'font' => ['bold' => true, 'color' => ['rgb' => '2F5F8F']],
                    'fill' => [
                        'fillType' => Fill::FILL_SOLID,
                        'startColor' => ['rgb' => 'E6F1FF']
                    ]
                ]);

                $sheet->getStyle("G{$row}:H{$row}")->applyFromArray([
                    'font' => ['bold' => true, 'color' => ['rgb' => '2F5F8F']],
                    'fill' => [
                        'fillType' => Fill::FILL_SOLID,
                        'startColor' => ['rgb' => 'E6F1FF']
                    ]
                ]);
            }

            foreach ($infoRows as $row) {
                $sheet->getStyle("B{$row}")->applyFromArray([
                    'font' => ['color' => ['rgb' => '1B365D']]
                ]);
                $sheet->getStyle("E{$row}")->applyFromArray([
                    'font' => ['color' => ['rgb' => '1B365D']]
                ]);
                $sheet->getStyle("H{$row}")->applyFromArray([
                    'font' => ['color' => ['rgb' => '1B365D']]
                ]);
            }
        }
    }

    private function styleSummarySection($sheet)
    {
        $horizontalAlignment = $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_CENTER;
        
        // Summary title (row 6) - only up to column I
        $sheet->mergeCells('A6:I6');
        $sheet->getStyle('A6:I6')->applyFromArray([
            'font' => [
                'bold' => true,
                'size' => 14,
                'color' => ['rgb' => 'FFFFFF']
            ],
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'startColor' => ['rgb' => '2E7D32']
            ],
            'alignment' => [
                'horizontal' => $horizontalAlignment,
                'vertical' => Alignment::VERTICAL_CENTER
            ]
        ]);

        // Summary data styling (rows 8-10) - only up to column I
        $sheet->getStyle('A8:I10')->applyFromArray([
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'startColor' => ['rgb' => 'F1F8E9']
            ],
            'font' => ['bold' => true]
        ]);
    }

    private function styleControlsSection($sheet)
    {
        $horizontalAlignment = $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_CENTER;
        
        // Controls section title (row 11) - only up to column I
        $sheet->mergeCells('A11:I11');
        $sheet->getStyle('A11:I11')->applyFromArray([
            'font' => [
                'bold' => true,
                'size' => 14,
                'color' => ['rgb' => 'FFFFFF']
            ],
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'startColor' => ['rgb' => 'D32F2F']
            ],
            'alignment' => [
                'horizontal' => $horizontalAlignment,
                'vertical' => Alignment::VERTICAL_CENTER
            ]
        ]);

        // Style control headers throughout the sheet
        for ($row = 13; $row <= $this->totalRows; $row++) {
            $cellValue = $sheet->getCell('A' . $row)->getValue();

            // Control headers (CONTROL 1, CONTROL 2, etc.)
            if (strpos($cellValue ?? '', __('report.CONTROL') . ' ') === 0) {
                $sheet->getStyle("A{$row}:I{$row}")->applyFromArray([
                    'font' => [
                        'bold' => true,
                        'size' => 12,
                        'color' => ['rgb' => 'FFFFFF']
                    ],
                    'fill' => [
                        'fillType' => Fill::FILL_SOLID,
                        'startColor' => ['rgb' => '3F51B5']
                    ]
                ]);
                $sheet->getRowDimension($row)->setRowHeight(25);
            }

            // Section headers (SUPPORTING EVIDENCE, NO EVIDENCE AVAILABLE)
            $bCellValue = $sheet->getCell('B' . $row)->getValue();
            if (in_array($bCellValue, [__('report.SUPPORTING EVIDENCE'), __('report.NO EVIDENCE AVAILABLE')])) {
                $sheet->getStyle("B{$row}:I{$row}")->applyFromArray([
                    'font' => [
                        'bold' => true,
                        'color' => ['rgb' => 'FFFFFF']
                    ],
                    'fill' => [
                        'fillType' => Fill::FILL_SOLID,
                        'startColor' => ['rgb' => '607D8B']
                    ]
                ]);
            }

            // Table headers
            if ($bCellValue === '#' || $bCellValue === __('report.Attribute')) {
                $sheet->getStyle("A{$row}:I{$row}")->applyFromArray([
                    'font' => ['bold' => true],
                    'fill' => [
                        'fillType' => Fill::FILL_SOLID,
                        'startColor' => ['rgb' => 'CFD8DC']
                    ]
                ]);
            }
        }
    }

    private function applyGeneralFormatting($sheet)
    {
        // Apply borders to main content area (only up to column I)
        $sheet->getStyle('A1:I' . $this->totalRows)
            ->getBorders()
            ->getOutline()
            ->setBorderStyle(Border::BORDER_MEDIUM);

        // Apply thin borders to content cells (only up to column I)
        for ($row = 3; $row <= $this->totalRows; $row++) {
            if (!empty($sheet->getCell('B' . $row)->getValue())) {
                $sheet->getStyle("A{$row}:I{$row}")
                    ->getBorders()
                    ->getAllBorders()
                    ->setBorderStyle(Border::BORDER_THIN);
            }
        }
    }

    private function isImageFile($filePath)
    {
        $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg'];
        $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
        return in_array($extension, $imageExtensions);
    }

    private function getTestStatus($testAudit)
    {
        $testNumberArray = json_decode($testAudit->test_number, true);
        $status = $testNumberArray[1] ?? 'No Action';
        
        if ($status == 'No Action') {
            return '⏳ ' . __('report.No Action');
        } elseif ($status == 'Approved') {
            return '✓ ' . __('report.Approved');
        } elseif ($status == 'Rejected') {
            return '✗ ' . __('report.Rejected');
        }
        return $status;
    }

    private function getEvidenceStatus($status)
    {
        $statuses = [
            'approved' => '✓ ' . __('report.APPROVED'),
            'rejected' => '✗ ' . __('report.REJECTED'),
            'no_action' => '👁 ' . __('report.REVIEW')
        ];
        return $statuses[$status] ?? '❓ ' . strtoupper($status ?? __('report.UNKNOWN'));
    }

    private function formatDate($date)
    {
        if (!$date) return '-';

        if (is_string($date)) {
            try {
                return date('M j, Y', strtotime($date));
            } catch (Exception $e) {
                return $date;
            }
        }

        if (method_exists($date, 'format')) {
            return $date->format('M j, Y');
        }

        return '-';
    }
}