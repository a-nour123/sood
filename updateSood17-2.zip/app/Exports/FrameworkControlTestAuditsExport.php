<?php

namespace App\Exports;

use App\Models\FrameworkControlTestAudit;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use App\Traits\LaravelExportPropertiesTrait;

class FrameworkControlTestAuditsExport extends BaseExportTemplate
{
    use LaravelExportPropertiesTrait;

    private $statusArray = [];

    public function __construct(string $auditType, $locale = null)
    {
        parent::__construct($locale);

        if ($auditType === 'active') {
            $this->statusArray = [1, 2, 3, 4];
        } elseif ($auditType === 'past') {
            $this->statusArray = [5];
        }
    }

    /**
     * Return collection of audits filtered by status
     */
    public function collection()
    {
        return FrameworkControlTestAudit::whereIn('status', $this->statusArray)
            ->with([
                'FrameworkControlWithFramworks:id,short_name,family',
                'FrameworkControlWithFramworks.Frameworks',
                'FrameworkControlWithFramworks.Families',
                'UserTester:id,name'
            ])
            ->orderBy('created_at', 'desc')
            ->get()
            ->map(function ($audit) {
                if ($audit->FrameworkControlWithFramworks) {
                    $controlName = $audit->FrameworkControlWithFramworks->short_name;

                    $frameworkNames = $audit->FrameworkControlWithFramworks->Frameworks->pluck('name')->toArray();
                    if (!empty($frameworkNames)) {
                        $controlName .= ' (' . implode(', ', $frameworkNames) . ')';
                    }
                } else {
                    $controlName = '';
                }

                return (object)[
                    'framework' => $audit->FrameworkControlWithFramworks?->Frameworks ?? collect(),
                    'sub_domain' => $audit->FrameworkControlWithFramworks?->Families ?? collect(),
                    'control' => $controlName,
                    'name' => $audit->name,
                    'tester' => $audit->UserTester?->name ?? '',
                    'last_date' => $audit->last_date,
                    'next_date' => $audit->next_date,
                ];
            });
    }

    /**
     * Map each audit to array for export
     */
    public function map($audit): array
    {
        $frameworkNames = $audit->framework->pluck('name')->toArray();
        $frameworkNames = !empty($frameworkNames) ? implode(', ', $frameworkNames) : '';

        $subDomainNames = $audit->sub_domain->pluck('name')->toArray();
        $subDomainNames = !empty($subDomainNames) ? implode(', ', $subDomainNames) : '';

        return [
            $this->getCounter(),
            $frameworkNames,
            $subDomainNames,
            $audit->control,
            $audit->name,
            $audit->tester,
            $audit->last_date,
            $audit->next_date,
        ];
    }

    /**
     * Column headings
     */
    public function headings(): array
    {
        return [
            __('locale.#'),
            __('locale.Framework'),
            __('locale.control_sub_domain'),
            __('locale.Control'),
            __('locale.TestName'),
            __('locale.Tester'),
            __('locale.LastTestDate'),
            __('locale.NextTestDate'),
        ];
    }

    /**
     * Column widths
     */
    public function columnWidths(): array
    {
        return [
            'A' => 6,
            'B' => 30,
            'C' => 30,
            'D' => 30,
            'E' => 25,
            'F' => 25,
            'G' => 20,
            'H' => 20,
        ];
    }

    /**
     * Apply custom wrap text styles
     */
    protected function applyCustomStyles(Worksheet $sheet)
    {
        $totalRows = $this->collection()->count() + 1;

        foreach (['B', 'C', 'D', 'E'] as $col) {
            $sheet->getStyle("{$col}2:{$col}{$totalRows}")
                ->getAlignment()
                ->setWrapText(true);
        }
    }
}
