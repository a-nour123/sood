<?php

namespace App\Exports;

use App\Models\ChangeRequest;
use App\Models\Department;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class ChangeRequestsExport extends BaseExportTemplate
{
    private $rows;

    public function __construct($locale = null)
    {
        parent::__construct($locale);

        $this->rows = $this->buildCollection();
    }

    /**
     * main data builder
     */
    private function buildCollection()
    {
        $currentUserId = auth()->id();

        $managerIds = Department::pluck('manager_id')->toArray();
        $currentUserIsDepartmentManager = in_array($currentUserId, $managerIds);

        $currentUserIsInResponsibleDepartment =
            auth()->id() == change_requests_responsible_department_manager_id();

        /**
         * queries
         */
        if ($currentUserIsInResponsibleDepartment) {

            $_changeRequests = ChangeRequest::with('created_by_user:id,username')
                ->where('review_cycle', 'Responsible-Department-Review')
                ->get();

        } elseif ($currentUserIsDepartmentManager) {

            $departments = Department::where('manager_id', $currentUserId)->get();

            $employees = [];

            foreach ($departments as $department) {
                $employees = array_merge(
                    $employees,
                    $department->employees()
                        ->where('id','<>',$currentUserId)
                        ->pluck('id')
                        ->toArray()
                );
            }

            $_changeRequests = ChangeRequest::with('created_by_user:id,username,department_id')
                ->whereIn('created_by',$employees)
                ->where('review_cycle','Department-Manager-Review')
                ->orWhere('created_by',$currentUserId)
                ->get();

        } else {

            $_changeRequests = ChangeRequest::with('created_by_user:id,username,department_id')
                ->where('created_by',$currentUserId)
                ->get();
        }

        /**
         * mapping output rows
         */
        return $_changeRequests->map(function ($cr) {

            $creatorName = $cr->created_by_user->username ?? null;

            return (object)[
                'title' => $cr->title,
                'description' => $cr->description,
                'creator' => ($creatorName == auth()->user()->username)
                    ? __('locale.Me')
                    : $creatorName,

                'file' => $cr->display_file_name,
                'status' => __('locale.' . $cr->status),
                'reason' => $cr->rejection_reason,
                'cycle' => __('locale.' . $cr->review_cycle),
                'date' => $cr->created_at->format('Y-m-d H:i'),
            ];
        });
    }

    /**
     * collection
     */
    public function collection()
    {
        return $this->rows;
    }

    /**
     * map rows
     */
    public function map($row): array
    {
        return [
            $this->getCounter(),
            $row->title,
            $row->description,
            $row->creator,
            $row->file,
            $row->status,
            $row->reason,
            $row->cycle,
            $row->date,
        ];
    }

    /**
     * headers
     */
    public function headings(): array
    {
        return [
            __('locale.#'),
            __('locale.Title'),
            __('locale.Description'),
            __('locale.CreatedBy'),
            __('locale.File'),
            __('locale.Status'),
            __('locale.Reason'),
            __('locale.ReviewCycle'),
            __('locale.CreatedDate'),
        ];
    }

    /**
     * column widths
     */
    public function columnWidths(): array
    {
        return [
            'A'=>6,
            'B'=>30,
            'C'=>50,
            'D'=>25,
            'E'=>30,
            'F'=>25,
            'G'=>40,
            'H'=>30,
            'I'=>20,
        ];
    }

    /**
     * custom styling
     */
    protected function applyCustomStyles(Worksheet $sheet)
    {
        foreach (['B','C','G'] as $col) {
            $sheet->getStyle($col)
                ->getAlignment()
                ->setWrapText(true);
        }
    }
}
