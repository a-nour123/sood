<?php

namespace App\Exports;

use App\Models\Framework;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use App\Traits\LaravelExportPropertiesTrait;

class FrameworksExport extends BaseExportTemplate
{
    use LaravelExportPropertiesTrait;

    private array $rows = [];

    public function __construct($locale = null)
    {
        parent::__construct($locale);

        $frameworks = Framework::with(['only_families', 'only_sub_families'])->get();

        foreach ($frameworks as $framework) {
            foreach ($framework->only_families as $family) {
                $subDomains = $framework->only_sub_families
                    ->where('parent_id', $family->id)
                    ->pluck('name')
                    ->toArray();

                $this->rows[] = [
                    'framework' => $framework->name,
                    'description' => $framework->description,
                    'domain' => $family->name,
                    'sub_domains' => implode(', ', $subDomains),
                ];
            }
        }
    }

    /**
     * Return collection for export
     */
    public function collection()
    {
        return collect($this->rows);
    }

    /**
     * Map each row to export format
     */
    public function map($row): array
    {
        return [
            $this->getCounter(),
            $row['framework'],
            $row['description'],
            $row['domain'],
            $row['sub_domains'],
        ];
    }

    /**
     * Column headings
     */
    public function headings(): array
    {
        return [
            __('locale.#'),
            __('locale.FrameworkName'),
            __('locale.Description'),
            __('locale.Domain'),
            __('locale.SubDomains'),
        ];
    }

    /**
     * Column widths
     */
    public function columnWidths(): array
    {
        return [
            'A' => 6,
            'B' => 30,
            'C' => 50,
            'D' => 30,
            'E' => 40,
        ];
    }

    /**
     * Apply custom styles for wrap text
     */
    protected function applyCustomStyles(Worksheet $sheet)
    {
        $totalRows = count($this->rows) + 1;

        foreach (['B', 'C', 'D', 'E'] as $col) {
            $sheet->getStyle("{$col}2:{$col}{$totalRows}")
                ->getAlignment()
                ->setWrapText(true);
        }
    }
}
