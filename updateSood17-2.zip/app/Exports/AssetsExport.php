<?php

namespace App\Exports;

use Carbon\Carbon;
use Illuminate\Support\Collection;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class AssetsExport extends BaseExportTemplate
{
    private $assets;

    public function __construct(Collection $assets, $locale = null)
    {
        parent::__construct($locale);
        $this->assets = $assets;
        $this->logoHeight = 60;
    }

    public function collection()
    {
        return $this->assets;
    }

    public function map($asset): array
    {
        $teams = $asset->teamsName()?->toArray() ?? [];
        $tags = $asset->tags()?->pluck('tag')->toArray() ?? [];

        return [
            $this->getCounter(),
            $asset->name,
            $asset->ip,
            $asset->assetCategory->name ?? '',
            $asset->location->name ?? '',
            implode(', ', $teams),
            implode(', ', $tags),
            $asset->details,
            $asset->url,
            $asset->assetOs->name ?? '',
            $asset->os_version,
            $asset->project_vlan,
            $asset->vlan,
            $asset->model,
            $asset->firmware,
            $asset->city,
            $asset->rack_location,
            $asset->mac_address,
            $asset->subnet_mask,
            $asset->Users->name ?? '',
            $asset->assetEnvironmentCategory->name ?? '',
            optional($asset->start_date)->format('Y-m-d'),
            optional($asset->expiration_date)->format('Y-m-d'),
            $asset->alert_period,
            optional($asset->created)->format('Y-m-d'),
            $asset->verified
                ? __('locale.verified')
                : __('locale.not_verified'),
            $asset->rank,
        ];
    }

    public function headings(): array
    {
        return [
            __('locale.#'),
            __('locale.AssetName'),
            __('locale.IPAddress'),
            __('locale.Category'),
            __('locale.AssetSiteLocation'),
            __('locale.Teams'),
            __('locale.Tags'),
            __('locale.AssetDetails'),
            __('locale.Url'),
            __('locale.Os'),
            __('locale.OsVersion'),
            __('locale.ProjectVlan'),
            __('locale.Vlan'),
            __('locale.Model'),
            __('locale.Firmware'),
            __('locale.City'),
            __('locale.RackLocation'),
            __('locale.MacAddress'),
            __('locale.SubnetMask'),
            __('locale.Users'),
            __('locale.AssetEnvironmentCategory'),
            __('locale.StartDate'),
            __('locale.EndDate'),
            __('locale.alert_period'),
            __('locale.CreatedDate'),
            __('locale.VerifiedAssets'),
            __('locale.Rank'),
        ];
    }

    public function columnWidths(): array
    {
        return [
            'A'=>6,'B'=>25,'C'=>18,'D'=>20,'E'=>25,'F'=>30,'G'=>30,
            'H'=>40,'I'=>30,'J'=>15,'K'=>15,'L'=>15,'M'=>15,'N'=>20,
            'O'=>20,'P'=>20,'Q'=>25,'R'=>25,'S'=>20,'T'=>25,'U'=>25,
            'V'=>18,'W'=>18,'X'=>15,'Y'=>18,'Z'=>18,'AA'=>10
        ];
    }

    protected function applyCustomStyles(Worksheet $sheet)
    {
        foreach (['F','G','H','I'] as $col) {
            $sheet->getStyle($col)
                ->getAlignment()
                ->setWrapText(true);
        }
    }
}
