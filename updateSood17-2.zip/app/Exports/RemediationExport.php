<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithColumnWidths;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithCustomStartCell;
use Maatwebsite\Excel\Events\AfterSheet;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Font;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;
use App\Models\AuditResponsible;
use App\Models\RemediationDetail;
use Carbon\Carbon;
use Illuminate\Support\Facades\App;

class RemediationExport implements FromArray, WithStyles, WithColumnWidths, WithEvents, WithCustomStartCell
{
    protected $frameworkId;
    protected $auditId;
    protected $remediationData = [];
    protected $companyName;
    protected $auditName;
    protected $frameworkName;
    protected $statistics = [];
    protected $isRTL = false;

    public function __construct($frameworkId, $auditId, $companyName = "King Saud University")
    {
        $this->frameworkId = $frameworkId;
        $this->auditId = $auditId;
        $this->companyName = $companyName;

        // Check if current locale is Arabic (RTL)
        $this->isRTL = App::getLocale() == 'ar';

        $this->prepareData();
        $this->calculateStatistics();
    }

    protected function prepareData()
    {
        // Load AuditResponsible
        $audit = AuditResponsible::with(['frameworkaduit:id,name'])
            ->where('framework_id', $this->frameworkId)
            ->where('id', $this->auditId)
            ->first();

        if (!$audit) {
            $this->remediationData = [];
            return;
        }

        $this->auditName = $audit->audit_name;
        $this->frameworkName = $audit->frameworkaduit->name ?? '';

        // Load remediation details separately
        $remediationDetails = RemediationDetail::with([
            'user:id,name,department_id',
            'user.department:id,name',
            'controlTestAudit.frameworkControl:id,short_name',
            'controlTestAudit.auditResponsible:id,audit_name',
        ])
            ->whereHas('controlTestAudit', function ($query) use ($audit) {
                $query->where('audit_id', $audit->id);
            })
            ->get();

        $rows = collect();

        foreach ($remediationDetails as $remediation) {
            $controlTestAudit = $remediation->controlTestAudit;

            if (!$controlTestAudit) {
                continue;
            }

            $rows->push([
                __('report.Framework Name')          => $this->frameworkName,
                __('report.Audit Name')              => $this->auditName,
                __('report.Control Name')            => $controlTestAudit->frameworkControl->name ?? $controlTestAudit->name ?? '',
                __('report.Control Short Name')      => $controlTestAudit->frameworkControl->short_name ?? '',
                __('report.Responsible User')        => $remediation->user->name ?? '',
                __('report.Department')              => $remediation->user->department->name ?? '',
                __('report.Corrective Action Plan')  => strip_tags($remediation->corrective_action_plan ?? ''),
                __('report.Budgetary')               => $this->formatBudgetary($remediation->budgetary ?? ''),
                __('report.Status')                  => $this->getStatusText($remediation->status ?? ''),
                __('report.Due Date')                => $remediation?->due_date ? Carbon::parse($remediation->due_date)->format('Y-m-d') : '',
                __('report.Comments')                => $remediation->comments ?? '',
                'Is Overdue'                         => $this->isOverdue($remediation),
            ]);
        }

        $this->remediationData = $rows->toArray();
    }

    protected function calculateStatistics()
    {
        $totalRemediations = count($this->remediationData);

        // Count by status
        $approvedCount = 0;
        $rejectedCount = 0;
        $pendingCount = 0;
        $overdueCount = 0;
        $totalBudget = 0;

        foreach ($this->remediationData as $item) {
            switch ($item[__('report.Status')]) {
                case __('report.Approved'):
                    $approvedCount++;
                    break;
                case __('report.Rejected'):
                    $rejectedCount++;
                    break;
                case __('report.Pending'):
                    $pendingCount++;
                    break;
            }

            // Calculate overdue
            if ($item['Is Overdue']) {
                $overdueCount++;
            }

            // Calculate budget
            $budgetValue = $item[__('report.Budgetary')] ?? '';
            if (!empty($budgetValue) && is_numeric(str_replace(['$', ',', ' '], '', $budgetValue))) {
                $totalBudget += floatval(str_replace(['$', ',', ' '], '', $budgetValue));
            }
        }

        // Calculate percentages
        $completionRate = $totalRemediations > 0 ?
            round((($approvedCount + $rejectedCount) / $totalRemediations) * 100, 2) : 0;

        $approvalRate = $totalRemediations > 0 ?
            round(($approvedCount / $totalRemediations) * 100, 2) : 0;

        $this->statistics = [
            'total_remediations' => $totalRemediations,
            'approved_count' => $approvedCount,
            'rejected_count' => $rejectedCount,
            'pending_count' => $pendingCount,
            'overdue_count' => $overdueCount,
            'total_budget' => $totalBudget,
            'completion_rate' => $completionRate,
            'approval_rate' => $approvalRate,
        ];
    }

    protected function getStatusText($status)
    {
        return match ($status) {
            1 => __('report.Approved'),
            2 => __('report.Rejected'),
            default => __('report.Pending'),
        };
    }

    protected function formatBudgetary($budgetary)
    {
        if (empty($budgetary)) return '';

        // Format as currency if it's numeric
        if (is_numeric(str_replace(['$', ',', ' '], '', $budgetary))) {
            $value = floatval(str_replace(['$', ',', ' '], '', $budgetary));
            return '$' . number_format($value, 2);
        }

        return $budgetary;
    }

    protected function isOverdue($remediation)
    {
        if (!$remediation || empty($remediation->due_date)) {
            return false;
        }

        $dueDate = Carbon::parse($remediation->due_date);
        $status = $remediation->status;

        // Only pending items can be overdue
        return ($status != 1 && $status != 2) && $dueDate->isPast();
    }

    public function array(): array
    {
        // If no data, return empty with message
        if (empty($this->remediationData)) {
            return [
                [__('report.No remediation data found for the selected audit.')],
                [''],
                [__('report.Framework') . ': ' . $this->frameworkName],
                [__('report.Audit') . ': ' . $this->auditName],
                [__('report.Generated on') . ': ' . Carbon::now()->format('F j, Y H:i')],
            ];
        }

        // Introduction section
        $introductionData = [
            [__('report.Remediation Plan Report')],
            [__('report.Audit Remediation Details - Controls with Remediation Actions')],
            ['', '', '', '', '', '', '', '', '', ''],
            [__('report.Report Information')],
            [
                __('report.Framework'),
                __('report.Audit'),
                __('report.Total Controls with Remediation'),
                __('report.Generated By'),
                __('report.Generation Date')
            ],
            [
                $this->frameworkName,
                $this->auditName,
                count($this->remediationData),
                auth()->user()->name ?? __('report.System'),
                Carbon::now()->format('d/m/Y H:i')
            ],
            ['', '', '', '', ''],
            ['', '', '', '', ''],
            [__('report.Report Purpose') . ':'],
            [__('report.This report provides detailed information about remediation plans and corrective actions for audit findings.')],
            [__('report.It includes only controls that have remediation actions assigned, with assigned responsibilities, budgetary requirements, and implementation timelines.')],
            ['', '', '', '', '', '', '', '', '', ''],
            ['', '', '', '', '', '', '', '', '', ''],
            ['', '', '', '', '', '', '', '', '', ''],
        ];

        $headerRow = [[
            __('report.Framework Name'),
            __('report.Audit Name'),
            __('report.Control Name'),
            __('report.Control Short Name'),
            __('report.Responsible User'),
            __('report.Department'),
            __('report.Corrective Action Plan'),
            __('report.Budgetary'),
            __('report.Status'),
            __('report.Due Date'),
            __('report.Comments')
        ]];

        return array_merge($introductionData, $headerRow, $this->remediationData);
    }

    public function startCell(): string
    {
        return 'A1';
    }

    public function styles(Worksheet $sheet)
    {
        $totalDataRows = count($this->remediationData);
        $horizontalAlignment = $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_LEFT;

        // If no data, style the message
        if ($totalDataRows === 0) {
            return [
                1 => [
                    'font' => ['bold' => true, 'size' => 14, 'color' => ['rgb' => 'FF0000']],
                    'alignment' => ['horizontal' => $horizontalAlignment]
                ],
                'A1:E5' => [
                    'alignment' => [
                        'horizontal' => $horizontalAlignment,
                        'vertical' => Alignment::VERTICAL_CENTER,
                    ]
                ],
            ];
        }

        $dataStartRow = 15; // After introduction

        return [
            // Main title
            1 => [
                'font' => ['bold' => true, 'size' => 18, 'color' => ['rgb' => '1F4E78']],
                'alignment' => ['horizontal' => $horizontalAlignment]
            ],

            // Subtitle
            2 => [
                'font' => ['bold' => true, 'size' => 14, 'color' => ['rgb' => '2F75B5']],
                'alignment' => ['horizontal' => $horizontalAlignment]
            ],

            // Report Information header
            4 => [
                'font' => ['bold' => true, 'size' => 12],
                'alignment' => ['horizontal' => $horizontalAlignment]
            ],

            // Report Information column headers
            5 => [
                'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'color' => ['rgb' => '2F75B5']
                ],
                'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER]
            ],

            // Report Information data row
            6 => [
                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'color' => ['rgb' => 'F2F2F2']
                ],
                'alignment' => ['horizontal' => $horizontalAlignment]
            ],

            // Purpose header
            9 => [
                'font' => ['bold' => true, 'size' => 12],
                'alignment' => ['horizontal' => $horizontalAlignment]
            ],

            // Purpose descriptions
            10 => [
                'alignment' => [
                    'wrapText' => true,
                    'horizontal' => $horizontalAlignment
                ]
            ],
            11 => [
                'alignment' => [
                    'wrapText' => true,
                    'horizontal' => $horizontalAlignment
                ]
            ],

            // Header row
            $dataStartRow => [
                'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
                'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER, 'vertical' => Alignment::VERTICAL_CENTER],
                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'color' => ['rgb' => '1F4E78']
                ]
            ],

            // Data rows
            'A' . ($dataStartRow + 1) . ':J' . ($totalDataRows + $dataStartRow) => [
                'alignment' => [
                    'vertical' => Alignment::VERTICAL_CENTER,
                    'horizontal' => $horizontalAlignment,
                ],
                'borders' => [
                    'allBorders' => [
                        'borderStyle' => Border::BORDER_THIN,
                        'color' => ['rgb' => 'D9D9D9']
                    ]
                ]
            ],

            // Wrap text columns
            'F' . ($dataStartRow + 1) . ':F' . ($totalDataRows + $dataStartRow) => [
                'alignment' => [
                    'wrapText' => true,
                    'horizontal' => $horizontalAlignment
                ]
            ],
            'J' . ($dataStartRow + 1) . ':J' . ($totalDataRows + $dataStartRow) => [
                'alignment' => [
                    'wrapText' => true,
                    'horizontal' => $horizontalAlignment
                ]
            ],

            // Center align for specific columns (these remain centered regardless of RTL/LTR)
            'D' . ($dataStartRow + 1) . ':D' . ($totalDataRows + $dataStartRow) => [
                'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER]
            ],
            'G' . ($dataStartRow + 1) . ':G' . ($totalDataRows + $dataStartRow) => [
                'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER]
            ],
            'H' . ($dataStartRow + 1) . ':H' . ($totalDataRows + $dataStartRow) => [
                'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER]
            ],
            'I' . ($dataStartRow + 1) . ':I' . ($totalDataRows + $dataStartRow) => [
                'alignment' => [
                    'horizontal' => Alignment::HORIZONTAL_CENTER,
                    'vertical' => Alignment::VERTICAL_CENTER
                ]
            ],

            // All introduction cells
            'A1:J14' => [
                'alignment' => [
                    'vertical' => Alignment::VERTICAL_TOP,
                    'horizontal' => $horizontalAlignment
                ],
            ],
        ];
    }

    public function columnWidths(): array
    {
        if ($this->isRTL) {
            return [
                'A' => 25, // Framework Name
                'B' => 25, // Audit Name
                'C' => 35, // Control Name (wider for Arabic)
                'D' => 20, // Control Short Name
                'E' => 25, // Responsible User (wider for Arabic)
                'F' => 25, // Department (wider for Arabic)
                'G' => 45, // Corrective Action Plan (wider for Arabic)
                'H' => 15, // Budgetary
                'I' => 15, // Status
                'J' => 15, // Due Date
                'K' => 40, // Comments (wider for Arabic)
            ];
        }

        return [
            'A' => 25, // Framework Name
            'B' => 25, // Audit Name
            'C' => 30, // Control Name
            'D' => 20, // Control Short Name
            'E' => 20, // Responsible User
            'F' => 40, // Corrective Action Plan
            'G' => 15, // Budgetary
            'H' => 15, // Status
            'I' => 15, // Due Date
            'J' => 35, // Comments
        ];
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event) {
                $sheet = $event->sheet->getDelegate();
                $totalDataRows = count($this->remediationData);
                $horizontalAlignment = $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_LEFT;

                // Set sheet direction for RTL
                if ($this->isRTL) {
                    $sheet->setRightToLeft(true);
                }

                // If no data, just add logo and return
                if ($totalDataRows === 0) {
                    $this->addLogo($sheet);
                    return;
                }

                $dataStartRow = 16; // After introduction

                // Add logo - position on the left side visually
                $this->addLogo($sheet);

                // Add borders to report information section
                $sheet->getStyle('A5:E6')->applyFromArray([
                    'borders' => [
                        'allBorders' => [
                            'borderStyle' => Border::BORDER_THIN,
                            'color' => ['rgb' => '000000']
                        ]
                    ]
                ]);

                // Format report information header
                $sheet->getStyle('A5:E5')->applyFromArray([
                    'alignment' => [
                        'horizontal' => Alignment::HORIZONTAL_CENTER,
                    ]
                ]);

                // Format report information data
                $sheet->getStyle('A6:E6')->applyFromArray([
                    'alignment' => [
                        'horizontal' => $horizontalAlignment,
                    ]
                ]);

                // Apply zebra striping to data rows
                for ($i = $dataStartRow + 1; $i < $totalDataRows + $dataStartRow + 1; $i++) {
                    if ($i % 2 == 0) {
                        $sheet->getStyle('A' . $i . ':J' . $i)->applyFromArray([
                            'fill' => [
                                'fillType' => Fill::FILL_SOLID,
                                'color' => ['rgb' => 'F2F2F2']
                            ]
                        ]);
                    }
                }

                // Format date column
                $sheet->getStyle('I' . ($dataStartRow + 1) . ':I' . ($totalDataRows + $dataStartRow))->applyFromArray([
                    'alignment' => [
                        'horizontal' => Alignment::HORIZONTAL_CENTER
                    ],
                    'numberFormat' => [
                        'formatCode' => 'yyyy-mm-dd'
                    ]
                ]);

                // Format budgetary column as currency
                $sheet->getStyle('G' . ($dataStartRow + 1) . ':G' . ($totalDataRows + $dataStartRow))->applyFromArray([
                    'numberFormat' => [
                        'formatCode' => '#,##0.00"$"'
                    ]
                ]);

                // Color code status column
                $this->applyStatusColorCoding($sheet, $dataStartRow, $totalDataRows);

                // Add summary section with statistics
                $this->addSummarySection($sheet, $dataStartRow, $totalDataRows);

                // Freeze panes (header row stays visible when scrolling)
                $sheet->freezePane('A' . ($dataStartRow + 1));

                // Set auto filter on header
                $sheet->setAutoFilter('A' . $dataStartRow . ':J' . $dataStartRow);
            },
        ];
    }

    protected function addLogo($sheet)
    {
        $drawing = new Drawing();
        $drawing->setName('Logo');
        $drawing->setDescription('Logo');
        $drawing->setPath(public_path('images/ksu-logo.png'));
        $drawing->setHeight(70);

        // Position logo on the left side visually:
        // - In LTR mode, left side is column A
        // - In RTL mode, left side is the last column (J)
        if ($this->isRTL) {
            $drawing->setCoordinates('G1'); // Last column in RTL appears on left side
        } else {
            $drawing->setCoordinates('G1'); // First column in LTR appears on left side
        }

        $drawing->setWorksheet($sheet);
    }


    protected function applyStatusColorCoding($sheet, $dataStartRow, $totalDataRows)
    {
        for ($i = $dataStartRow + 1; $i <= $totalDataRows + $dataStartRow; $i++) {
            $statusCell = 'H' . $i;
            $statusValue = $sheet->getCell($statusCell)->getValue();

            if ($statusValue === __('report.Approved')) {
                $sheet->getStyle($statusCell)->applyFromArray([
                    'fill' => [
                        'fillType' => Fill::FILL_SOLID,
                        'color' => ['rgb' => 'C6EFCE']
                    ],
                    'font' => [
                        'color' => ['rgb' => '006100']
                    ]
                ]);
            } elseif ($statusValue === __('report.Rejected')) {
                $sheet->getStyle($statusCell)->applyFromArray([
                    'fill' => [
                        'fillType' => Fill::FILL_SOLID,
                        'color' => ['rgb' => 'FFC7CE']
                    ],
                    'font' => [
                        'color' => ['rgb' => '9C0006']
                    ]
                ]);
            } elseif ($statusValue === __('report.Pending')) {
                $sheet->getStyle($statusCell)->applyFromArray([
                    'fill' => [
                        'fillType' => Fill::FILL_SOLID,
                        'color' => ['rgb' => 'FFEB9C']
                    ],
                    'font' => [
                        'color' => ['rgb' => '9C6500']
                    ]
                ]);
            }
        }
    }

    protected function addSummarySection($sheet, $dataStartRow, $totalDataRows)
    {
        $summaryRow = $totalDataRows + $dataStartRow + 2;
        $horizontalAlignment = $this->isRTL ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_LEFT;

        // Summary title
        $sheet->setCellValue('A' . $summaryRow, __('report.Remediation Summary - Statistics'));
        $sheet->getStyle('A' . $summaryRow)->applyFromArray([
            'font' => ['bold' => true, 'size' => 14, 'color' => ['rgb' => '1F4E78']],
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'color' => ['rgb' => 'DDEBF7']
            ]
        ]);
        $sheet->mergeCells('A' . $summaryRow . ':J' . $summaryRow);
        $sheet->getStyle('A' . $summaryRow . ':J' . $summaryRow)->applyFromArray([
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER
            ],
            'borders' => [
                'outline' => [
                    'borderStyle' => Border::BORDER_MEDIUM,
                    'color' => ['rgb' => '1F4E78']
                ]
            ]
        ]);

        // Total Remediations
        $sheet->setCellValue('A' . ($summaryRow + 1), __('report.Total Remediation Items') . ':');
        $sheet->setCellValue('B' . ($summaryRow + 1), $this->statistics['total_remediations']);
        $sheet->getStyle('A' . ($summaryRow + 1) . ':B' . ($summaryRow + 1))->applyFromArray([
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'color' => ['rgb' => 'DDEBF7']
            ],
            'borders' => [
                'outline' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['rgb' => '5B9BD5']
                ]
            ],
            'alignment' => [
                'horizontal' => $horizontalAlignment
            ]
        ]);
        $sheet->getStyle('B' . ($summaryRow + 1))->applyFromArray([
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER
            ],
            'font' => ['bold' => true, 'size' => 12]
        ]);

        // Approved count
        $sheet->setCellValue('D' . ($summaryRow + 1), __('report.Approved Remediations') . ':');
        $sheet->setCellValue('E' . ($summaryRow + 1), $this->statistics['approved_count']);
        $sheet->getStyle('D' . ($summaryRow + 1) . ':E' . ($summaryRow + 1))->applyFromArray([
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'color' => ['rgb' => 'E2EFDA']
            ],
            'borders' => [
                'outline' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['rgb' => 'A9D08E']
                ]
            ],
            'alignment' => [
                'horizontal' => $horizontalAlignment
            ]
        ]);
        $sheet->getStyle('E' . ($summaryRow + 1))->applyFromArray([
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER
            ],
            'font' => ['bold' => true, 'size' => 12]
        ]);

        // Rejected count
        $sheet->setCellValue('G' . ($summaryRow + 1), __('report.Rejected Remediations') . ':');
        $sheet->setCellValue('H' . ($summaryRow + 1), $this->statistics['rejected_count']);
        $sheet->getStyle('G' . ($summaryRow + 1) . ':H' . ($summaryRow + 1))->applyFromArray([
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'color' => ['rgb' => 'FCE4D6']
            ],
            'borders' => [
                'outline' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['rgb' => 'FF7C80']
                ]
            ],
            'alignment' => [
                'horizontal' => $horizontalAlignment
            ]
        ]);
        $sheet->getStyle('H' . ($summaryRow + 1))->applyFromArray([
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER
            ],
            'font' => ['bold' => true, 'size' => 12]
        ]);

        // Pending count
        $sheet->setCellValue('A' . ($summaryRow + 2), __('report.Pending Remediations') . ':');
        $sheet->setCellValue('B' . ($summaryRow + 2), $this->statistics['pending_count']);
        $sheet->getStyle('A' . ($summaryRow + 2) . ':B' . ($summaryRow + 2))->applyFromArray([
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'color' => ['rgb' => 'FFF2CC']
            ],
            'borders' => [
                'outline' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['rgb' => 'FFD966']
                ]
            ],
            'alignment' => [
                'horizontal' => $horizontalAlignment
            ]
        ]);
        $sheet->getStyle('B' . ($summaryRow + 2))->applyFromArray([
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER
            ],
            'font' => ['bold' => true, 'size' => 12]
        ]);

        // Overdue count
        $sheet->setCellValue('D' . ($summaryRow + 2), __('report.Overdue Remediations') . ':');
        $sheet->setCellValue('E' . ($summaryRow + 2), $this->statistics['overdue_count']);
        $sheet->getStyle('D' . ($summaryRow + 2) . ':E' . ($summaryRow + 2))->applyFromArray([
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'color' => ['rgb' => 'FCE4D6']
            ],
            'borders' => [
                'outline' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['rgb' => 'FF7C80']
                ]
            ],
            'alignment' => [
                'horizontal' => $horizontalAlignment
            ]
        ]);
        $sheet->getStyle('E' . ($summaryRow + 2))->applyFromArray([
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER
            ],
            'font' => ['bold' => true, 'size' => 12, 'color' => ['rgb' => '9C0006']]
        ]);

        // Budget summary
        $sheet->setCellValue('G' . ($summaryRow + 2), __('report.Total Budget Required') . ':');
        $sheet->setCellValue('H' . ($summaryRow + 2), '$' . number_format($this->statistics['total_budget'], 2));
        $sheet->getStyle('G' . ($summaryRow + 2) . ':H' . ($summaryRow + 2))->applyFromArray([
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'color' => ['rgb' => 'E2EFDA']
            ],
            'borders' => [
                'outline' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['rgb' => '70AD47']
                ]
            ],
            'alignment' => [
                'horizontal' => $horizontalAlignment
            ]
        ]);
        $sheet->getStyle('H' . ($summaryRow + 2))->applyFromArray([
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER
            ],
            'font' => ['bold' => true, 'size' => 12],
            'numberFormat' => [
                'formatCode' => '#,##0.00"$"'
            ]
        ]);

        // Completion Rate
        $sheet->setCellValue('A' . ($summaryRow + 3), __('report.Completion Rate') . ':');
        $sheet->setCellValue('B' . ($summaryRow + 3), $this->statistics['completion_rate'] . '%');
        $sheet->getStyle('A' . ($summaryRow + 3) . ':B' . ($summaryRow + 3))->applyFromArray([
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'color' => ['rgb' => 'DDEBF7']
            ],
            'borders' => [
                'outline' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['rgb' => '5B9BD5']
                ]
            ],
            'alignment' => [
                'horizontal' => $horizontalAlignment
            ]
        ]);
        $sheet->getStyle('B' . ($summaryRow + 3))->applyFromArray([
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER
            ],
            'font' => ['bold' => true, 'size' => 12]
        ]);

        // Approval Rate
        $sheet->setCellValue('D' . ($summaryRow + 3), __('report.Approval Rate') . ':');
        $sheet->setCellValue('E' . ($summaryRow + 3), $this->statistics['approval_rate'] . '%');
        $sheet->getStyle('D' . ($summaryRow + 3) . ':E' . ($summaryRow + 3))->applyFromArray([
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'color' => ['rgb' => 'E2EFDA']
            ],
            'borders' => [
                'outline' => [
                    'borderStyle' => Border::BORDER_MEDIUM,
                    'color' => ['rgb' => '70AD47']
                ]
            ],
            'font' => ['bold' => true],
            'alignment' => [
                'horizontal' => $horizontalAlignment
            ]
        ]);
        $sheet->getStyle('E' . ($summaryRow + 3))->applyFromArray([
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER
            ]
        ]);

        // Report footer
        $footerRow = $summaryRow + 5;
        $sheet->setCellValue('A' . $footerRow, __('report.Report generated on') . ': ' . Carbon::now()->format('F j, Y H:i:s'));
        $sheet->getStyle('A' . $footerRow)->applyFromArray([
            'font' => ['italic' => true, 'size' => 10],
            'alignment' => ['horizontal' => $horizontalAlignment]
        ]);
        $sheet->mergeCells('A' . $footerRow . ':G' . $footerRow);
    }
}
