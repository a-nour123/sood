<?php

namespace App\Exports;

use App\Models\Family;
use App\Traits\LaravelExportPropertiesTrait;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class DomainsExport extends BaseExportTemplate
{
    use LaravelExportPropertiesTrait;

    /**
     * Get all families (domains) with relationships
     */
    public function collection()
    {
        return Family::with('parentFamily', 'families')->get();
    }

    /**
     * Map each family (domain) to an array for export
     */
    public function map($domain): array
    {
        $subDomainsNames = $domain->familiesOlny()->pluck('name')->toArray();

        $subDomainsNames = count($subDomainsNames) ? implode(', ', $subDomainsNames) : '';

        return [
            $this->getCounter(),
            $domain->name,
            $domain->order,
            optional($domain->parentFamily)->name,
            $subDomainsNames
        ];
    }

    /**
     * Column headings
     */
    public function headings(): array
    {
        return [
            __('locale.#'),
            __('locale.Name'),
            __('locale.Order'),
            __('locale.Domain'),
            __('locale.sub_domains')
        ];
    }

    /**
     * Column widths
     */
    public function columnWidths(): array
    {
        return [
            'A' => 6,
            'B' => 30,
            'C' => 15,
            'D' => 30,
            'E' => 40
        ];
    }

    /**
     * Custom styles for wrap text (optional)
     */
    protected function applyCustomStyles(Worksheet $sheet)
    {
        $totalRows = $this->collection()->count() + 1;

        foreach (['B', 'D', 'E'] as $col) {
            $sheet->getStyle("{$col}2:{$col}{$totalRows}")
                ->getAlignment()
                ->setWrapText(true);
        }
    }
}
