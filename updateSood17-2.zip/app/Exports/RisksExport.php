<?php

namespace App\Exports;

use App\Models\Impact;
use App\Models\Likelihood;
use App\Models\Risk;
use App\Models\RiskLevel;
use App\Models\ScoringMethod;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use App\Traits\LaravelExportPropertiesTrait;

class RisksExport extends BaseExportTemplate
{
    use LaravelExportPropertiesTrait;

    private array $rows = [];

    public function __construct($locale = null)
    {
        parent::__construct($locale);

        $risks = Risk::with(['riskScoring', 'source', 'submittedBy:id,name'])->get();

        foreach ($risks as $risk) {
            $calculatedRisk = $risk->riskScoring->calculated_risk ?? "0.0";
            $residualRisk = ($calculatedRisk && $calculatedRisk != "0.0") ? get_residual_risk($risk->id) : "0.0";

            $riskCatalogs = $risk->riskCatalogs();
            $threatCatalogs = $risk->threatCatalog();

            $this->rows[] = (object)[
                'status' => $risk->status,
                'subject' => $risk->subject,
                'calculated_risk' => $calculatedRisk . ' (' . ($this->getRiskValueData($calculatedRisk)['name']) . ')',
                'residual_risk' => $residualRisk . ' (' . ($this->getRiskValueData($residualRisk)['name']) . ')',
                'likelihood' => Likelihood::find($risk->riskScoring->CLASSIC_likelihood)?->name ?? '',
                'impact' => Impact::find($risk->riskScoring->CLASSIC_impact)?->name ?? '',
                'risk_scoring_method' => ScoringMethod::find($risk->riskScoring->scoring_method)?->name ?? '',
                'riskCatalogs' => $riskCatalogs,
                'threatCatalogs' => $threatCatalogs,
                'source' => $risk->source?->name ?? '',
                'submitted_by' => $risk->submittedBy?->name ?? '',
                'created_at' => $risk->created_at->format('Y-m-d H:i'),
            ];
        }
    }

    /**
     * Return collection
     */
    public function collection()
    {
        return collect($this->rows);
    }

    /**
     * Map each row
     */
    public function map($risk): array
    {
        $riskCatalogsNames = implode(', ', array_map(fn($r) => $r['name'], $risk->riskCatalogs) ?: []);
        $threatCatalogsNames = implode(', ', array_map(fn($t) => $t['name'], $risk->threatCatalogs) ?: []);

        return [
            $this->getCounter(),
            $risk->status,
            $risk->subject,
            $risk->calculated_risk,
            $risk->residual_risk,
            $risk->risk_scoring_method,
            $risk->likelihood,
            $risk->impact,
            $riskCatalogsNames,
            $threatCatalogsNames,
            $risk->source,
            $risk->submitted_by,
            $risk->created_at,
        ];
    }

    /**
     * Column headings
     */
    public function headings(): array
    {
        return [
            __('locale.#'),
            __('locale.Status'),
            __('locale.Subject'),
            __('locale.InherentRisk'),
            __('locale.ResidualRisk'),
            __('locale.RiskScoringMethod'),
            __('locale.CurrentLikelihood'),
            __('locale.CurrentImpact'),
            __('locale.VulnerabilityMapping'),
            __('locale.ThreatMapping'),
            __('locale.ImpactScope'),
            __('locale.SubmittedBy'),
            __('locale.SubmissionDate'),
        ];
    }

    /**
     * Column widths
     */
    public function columnWidths(): array
    {
        return [
            'A' => 6,
            'B' => 20,
            'C' => 40,
            'D' => 15,
            'E' => 15,
            'F' => 25,
            'G' => 20,
            'H' => 20,
            'I' => 40,
            'J' => 40,
            'K' => 20,
            'L' => 25,
            'M' => 20,
        ];
    }

    /**
     * Apply wrap text for long text columns
     */
    protected function applyCustomStyles(Worksheet $sheet)
    {
        $totalRows = count($this->rows) + 1;

        foreach (['C','I','J'] as $col) {
            $sheet->getStyle("{$col}2:{$col}{$totalRows}")
                ->getAlignment()
                ->setWrapText(true);
        }
    }

    /**
     * Return a risk level data.
     */
    protected function getRiskValueData($calculated_risk)
    {
        $riskLevel = RiskLevel::orderBy('value', 'desc')
            ->where('value', '<=', $calculated_risk)
            ->first();

        if (!$riskLevel) return ['name' => 'Insignificant', 'color' => 'white'];

        return [
            'name' => $riskLevel->display_name ?: $riskLevel->name ?: 'Insignificant',
            'color' => $riskLevel->color ?? 'white'
        ];
    }
}
