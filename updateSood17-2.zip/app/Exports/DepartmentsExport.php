<?php

namespace App\Exports;

use App\Models\Department;
use App\Traits\LaravelExportPropertiesTrait;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class DepartmentsExport extends BaseExportTemplate
{
    use LaravelExportPropertiesTrait;

    /**
     * Get all departments with relationships
     */
    public function collection()
    {
        return Department::with('manager', 'parentDepartment', 'departments')->get();
    }

    /**
     * Map each department to an array for export
     */
    public function map($department): array
    {
        $children = $department->departments->pluck('name')->implode(', ');

        return [
            $this->getCounter(),
            $department->name,
            $department->code,
            optional($department->parentDepartment)->name,
            $children,
            $department->required_num_emplyees,
            $department->employees()->count(),
            optional($department->manager)->name,
            optional($department->color)->name,
            optional($department->created_at)->format('Y-m-d H:i')
        ];
    }

    /**
     * Column headings
     */
    public function headings(): array
    {
        return [
            __('locale.#'),
            __('locale.Name'),
            __('locale.Code'),
            __('locale.ParentDepartment'),
            __('locale.ChildDepartments'),
            __('locale.RequiredNumberOfEmplyees'),
            __('locale.ActualNumberOfEmplyees'),
            __('locale.Manager'),
            __('locale.Color'),
            __('locale.CreatedDate')
        ];
    }

    /**
     * Column widths
     */
    public function columnWidths(): array
    {
        return [
            'A'=>6,
            'B'=>30,
            'C'=>60,
            'D'=>60,
            'E'=>40,
            'F'=>40,
            'G'=>20,
            'H'=>25,
            'I'=>20,
            'J'=>20
        ];
    }

    /**
     * Custom styles for wrap text
     */
    protected function applyCustomStyles(Worksheet $sheet)
    {
        $totalRows = $this->collection()->count() + 1;

        foreach (['B','C','D','E','F'] as $col) {
            $sheet->getStyle("{$col}2:{$col}{$totalRows}")
                ->getAlignment()
                ->setWrapText(true);
        }
    }
}
