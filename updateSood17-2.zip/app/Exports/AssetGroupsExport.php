<?php

namespace App\Exports;

use App\Models\AssetGroup;
use Carbon\Carbon;
use Maatwebsite\Excel\Concerns\WithProperties;

class AssetGroupsExport extends BaseExportTemplate implements WithProperties
{
    use \App\Traits\LaravelExportPropertiesTrait; // This trait implements properties function required by WithProperties

    // Remove initialization from property declarations
    protected $logoPath;
    protected $logoColumn;
    protected $logoHeight;

    /**
     * Constructor to initialize properties
     */
    public function __construct()
    {
        parent::__construct(); // Call parent constructor first
        
        // Initialize properties here (where function calls are allowed)
        $this->logoPath = public_path('images/ksu-logo.png'); // Adjust path as needed
        $this->logoColumn = 'D'; // Adjust column for logo placement
        $this->logoHeight = 60; // Adjust logo height as needed
    }

    /**
     * @return \Illuminate\Support\Collection
     */
    public function collection()
    {
        return AssetGroup::get();
    }

    /**
     * @var AssetGroup $assetGroup
     */
    public function map($assetGroup): array
    {
        $assetGroupAssetsNames = $assetGroup->assets()->pluck('name');
        
        if (count($assetGroupAssetsNames)) {
            $assetGroupAssetsNames = "(" . implode('), (', $assetGroupAssetsNames->toArray()) . ")";
        } else {
            $assetGroupAssetsNames = '';
        }

        return [
            $this->getCounter(), // Use getCounter() instead of manual counter
            $assetGroup->name,
            $assetGroupAssetsNames
        ];
    }

    public function headings(): array
    {
        return [
            __('locale.#'),
            __('locale.AssetGroupName'),
            __('locale.Assets')
        ];
    }

    /**
     * Define column widths
     */
    public function columnWidths(): array
    {
        return [
            'A' => 10,  // # column
            'B' => 30,  // Asset Group Name column
            'C' => 50,  // Assets column
            'D' => 5,   // Spacing for logo (if using column D for logo)
            'E' => 30,  // Logo column
        ];
    }

    /**
     * Get the column range for data
     */
    protected function getDataColumnRange(): string
    {
        return 'A2:C'; // Data starts from A2 to C (adjust if you have more columns)
    }

    /**
     * Get the last column letter for the data range
     */
    protected function getLastDataColumn(): string
    {
        return 'C'; // Since we have 3 columns (A, B, C)
    }

    /**
     * Override applyCustomStyles for any specific styling needs
     */
    protected function applyCustomStyles($sheet)
    {
        // You can add any custom styling specific to AssetGroupsExport here
        // For example, wrap text in the Assets column
        $sheet->getStyle('C')->getAlignment()->setWrapText(true);
    }
}