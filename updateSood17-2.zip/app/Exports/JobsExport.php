<?php

namespace App\Exports;

use App\Models\Job;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use App\Traits\LaravelExportPropertiesTrait;

class JobsExport extends BaseExportTemplate
{
    use LaravelExportPropertiesTrait;

    private array $rows = [];

    public function __construct($locale = null)
    {
        parent::__construct($locale);

        $jobs = Job::with('employees')->get();

        foreach ($jobs as $job) {
            $employeeNames = $job->employees->pluck('name')->toArray();
            $this->rows[] = [
                'name' => $job->name,
                'code' => $job->code,
                'description' => $job->description,
                'employees' => !empty($employeeNames) ? implode(', ', $employeeNames) : '',
                'created_at' => $job->created_at->format('Y-m-d H:i'),
            ];
        }
    }

    /**
     * Return collection for export
     */
    public function collection()
    {
        return collect($this->rows);
    }

    /**
     * Map each job to export format
     */
    public function map($row): array
    {
        return [
            $this->getCounter(),
            $row['name'],
            $row['code'],
            $row['description'],
            $row['employees'],
            $row['created_at'],
        ];
    }

    /**
     * Column headings
     */
    public function headings(): array
    {
        return [
            __('locale.#'),
            __('locale.Name'),
            __('locale.Code'),
            __('locale.Description'),
            __('locale.Employees'),
            __('locale.CreatedDate'),
        ];
    }

    /**
     * Column widths
     */
    public function columnWidths(): array
    {
        return [
            'A' => 6,
            'B' => 30,
            'C' => 20,
            'D' => 50,
            'E' => 40,
            'F' => 20,
        ];
    }

    /**
     * Apply wrap text for long text columns
     */
    protected function applyCustomStyles(Worksheet $sheet)
    {
        $totalRows = count($this->rows) + 1;

        foreach (['B', 'C', 'D', 'E'] as $col) {
            $sheet->getStyle("{$col}2:{$col}{$totalRows}")
                ->getAlignment()
                ->setWrapText(true);
        }
    }
}
