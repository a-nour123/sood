<?php

namespace App\Exports;

use App\Models\CenterPolicy;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use App\Traits\LaravelExportPropertiesTrait;

class PolicyClauseExport extends BaseExportTemplate
{
    use LaravelExportPropertiesTrait;

    private array $rows = [];

    public function __construct($locale = null)
    {
        parent::__construct($locale);

        $policies = CenterPolicy::with(['documents'])->get();

        foreach ($policies as $policy) {
            $documentNames = $policy->documents->pluck('document_name')->implode(', ');

            // Handle policy_name as array or JSON
            $policyNameEn = '';
            $policyNameAr = '';
            $policyNameRaw = $policy->getRawOriginal('policy_name');

            if (is_array($policyNameRaw)) {
                $policyNameEn = $policyNameRaw['en'] ?? '';
                $policyNameAr = $policyNameRaw['ar'] ?? '';
            } elseif (is_string($policyNameRaw)) {
                $decoded = json_decode($policyNameRaw, true);
                if (is_array($decoded)) {
                    $policyNameEn = $decoded['en'] ?? '';
                    $policyNameAr = $decoded['ar'] ?? '';
                } else {
                    $policyNameEn = $policyNameRaw;
                }
            }

            $this->rows[] = [
                'policy_en' => $policyNameEn,
                'policy_ar' => $policyNameAr,
                'documents' => $documentNames
            ];
        }
    }

    /**
     * Return collection
     */
    public function collection()
    {
        return collect($this->rows);
    }

    /**
     * Map each row
     */
    public function map($row): array
    {
        return [
            $this->getCounter(),
            $row['policy_en'],
            $row['policy_ar'],
            $row['documents'],
        ];
    }

    /**
     * Column headings
     */
    public function headings(): array
    {
        return [
            __('locale.#'),
            __('locale.PolicyClauseEn'),
            __('locale.PolicyClauseAr'),
            __('locale.Document'),
        ];
    }

    /**
     * Column widths
     */
    public function columnWidths(): array
    {
        return [
            'A' => 6,
            'B' => 50,
            'C' => 50,
            'D' => 60,
        ];
    }

    /**
     * Apply wrap text
     */
    protected function applyCustomStyles(Worksheet $sheet)
    {
        $totalRows = count($this->rows) + 1;

        foreach (['B','C','D'] as $col) {
            $sheet->getStyle("{$col}2:{$col}{$totalRows}")
                ->getAlignment()
                ->setWrapText(true);
        }
    }
}
