<?php

namespace App\Exports;

use App\Models\Task;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use App\Traits\LaravelExportPropertiesTrait;

class TasksExport extends BaseExportTemplate
{
    use LaravelExportPropertiesTrait;

    private string $tasksType = '';
    private array $rows = [];

    public function __construct(string $tasksType, ?string $locale = null)
    {
        parent::__construct($locale);

        $this->tasksType = in_array($tasksType, ['created', 'assigned']) ? $tasksType : 'created';

        $currentUser = auth()->user();

        if ($this->tasksType === 'created') {
            $tasks = $currentUser->createdTasks()
                ->with('assignable:id,name', 'action_by_user:id,name', 'created_by_user:id,name')
                ->orderBy('due_date')
                ->get();
        } else { // assigned
            $currentUserTasks = $currentUser->tasks()
                ->with('assignable:id,name', 'action_by_user:id,name', 'created_by_user:id,name')
                ->orderBy('due_date')
                ->get();

            $teamIds = $currentUser->teams()->pluck('id')->toArray();
            $teamTasks = Task::where('assignable_type', 'App\Models\Team')
                ->whereIn('assignable_id', $teamIds)
                ->with('assignable:id,name', 'created_by_user:id,name', 'action_by_user:id,name')
                ->orderBy('due_date')
                ->get();

            $tasks = $currentUserTasks->merge($teamTasks);
        }

        // Prepare rows
        foreach ($tasks as $task) {
            $this->rows[] = $task;
        }
    }

    public function collection()
    {
        return collect($this->rows);
    }

    /**
     * Map each task to an export row
     */
    public function map($task): array
    {
        return [
            $this->getCounter(),
            $task->title,
            class_basename($task->assignable_type),
            class_basename($task->assignable_type) === 'User' && $task->assignable->id === auth()->id()
                ? __('locale.Me')
                : $task->assignable->name,
            $task->start_date->format('Y-m-d'),
            $task->due_date->format('Y-m-d'),
            __('locale.' . $task->priority),
            __('locale.' . $task->status),
            $task->action_by_user->name ?? ($task->created_by_user->id === auth()->id() ? __('locale.Me') : $task->created_by_user->name ?? ''),
            strip_tags($task->description),
            $task->completed ? '✔' : '✘',
            $task->completed_date?->format('Y-m-d H:i') ?? '',
            $task->accepted_date?->format('Y-m-d H:i') ?? '',
            $this->tasksType === 'created' ? __('locale.Me') : $task->created_by_user->name ?? '',
            $task->created_at->format('Y-m-d H:i'),
        ];
    }

    /**
     * Column headings
     */
    public function headings(): array
    {
        return [
            __('locale.#'),
            __('locale.TaskTitle'),
            __('locale.AssigneeType'),
            __('locale.Assignee'),
            __('locale.StartDate'),
            __('locale.DueDate'),
            __('locale.TaskPriority'),
            __('locale.TaskStatus'),
            __('locale.ActionBy'),
            __('locale.Description'),
            __('locale.Completed'),
            __('locale.CompletedDate'),
            __('locale.AcceptedDate'),
            __('locale.CreatedBy'),
            __('locale.CreatedDate'),
        ];
    }

    /**
     * Column widths
     */
    public function columnWidths(): array
    {
        return [
            'A' => 6,
            'B' => 40,
            'C' => 20,
            'D' => 25,
            'E' => 15,
            'F' => 15,
            'G' => 15,
            'H' => 20,
            'I' => 25,
            'J' => 50,
            'K' => 10,
            'L' => 20,
            'M' => 20,
            'N' => 25,
            'O' => 20,
        ];
    }

    /**
     * Apply wrap text for long text columns
     */
    protected function applyCustomStyles(Worksheet $sheet)
    {
        $totalRows = count($this->rows) + 1;

        foreach (['B', 'D', 'J'] as $col) {
            $sheet->getStyle("{$col}2:{$col}{$totalRows}")
                ->getAlignment()
                ->setWrapText(true);
        }
    }
}
