(function ($) {
  'use strict';

  function initStrategicSelects(context) {
    $(context).find('select.form-select').each(function () {
      var $select = $(this);
      if ($select.data('select2')) {
        return;
      }
      if (!$select.parent().hasClass('position-relative')) {
        $select.wrap('<div class="position-relative"></div>');
      }
      $select.select2({
        width: '100%',
        dropdownAutoWidth: true,
        dropdownParent: $select.parent(),
        placeholder: ' ',
        allowClear: $select.find('option[value=""]').length > 0,
        dir: $('html').attr('data-textdirection') === 'rtl' ? 'rtl' : 'ltr'
      });
    });
  }

  function reloadStrategicFilters($form) {
    if (!$form || !$form.length) {
      return;
    }
    if ($form.is('#strategic-filters') && $.fn.dataTable && $.fn.dataTable.isDataTable('#strategic-table')) {
      $('#strategic-table').DataTable().ajax.reload();
      return;
    }
    if (($form.attr('method') || 'get').toLowerCase() === 'get') {
      $form.get(0).submit();
    }
  }

  var filterTimer;
  $(document).on('change', '.strategic-live-filter select, .strategic-live-filter input[type="date"]', function () {
    reloadStrategicFilters($(this).closest('form'));
  });
  $(document).on('input', '.strategic-live-filter input:not([type="hidden"]):not([type="date"]):not([type="checkbox"]):not([type="radio"])', function () {
    var $form = $(this).closest('form');
    clearTimeout(filterTimer);
    filterTimer = setTimeout(function () {
      reloadStrategicFilters($form);
    }, 400);
  });

  $(function () {
    initStrategicSelects(document);
  });
})(jQuery);
