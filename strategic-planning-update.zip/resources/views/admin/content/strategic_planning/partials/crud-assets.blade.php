@section('vendor-style')
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/dataTables.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/responsive.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">
    @include('admin.content.strategic_planning.partials.select2-style')
@endsection
@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/tables/datatable/jquery.dataTables.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.bootstrap5.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>
    @include('admin.content.strategic_planning.partials.select2-script')
@endsection
@section('page-script')
    <script>
        window.StrategicConfig = {
            listUrl: @json($screen['listUrl']),
            storeUrl: @json($screen['storeUrl']),
            updateUrl: @json($screen['updateUrl']),
            editUrl: @json($screen['editUrl']),
            deleteUrl: @json($screen['deleteUrl']),
            showUrl: @json($screen['showUrl'] ?? ''),
            permissions: {
                show: {{ !empty($screen['canShow']) ? 'true' : 'false' }},
                edit: {{ !empty($screen['canEdit']) ? 'true' : 'false' }},
                delete: {{ !empty($screen['canDelete']) ? 'true' : 'false' }}
            },
            labels: {
                view: @json(__('locale.View')),
                edit: @json(__('locale.Edit')),
                delete: @json(__('locale.Delete')),
                confirm: @json(__('locale.AreYouSureToDeleteThisRecord')),
                cancel: @json(__('locale.Cancel'))
            },
            columns: @json($screen['dataColumns'])
        };
    </script>
    <script src="{{ asset('ajax-files/strategic_planning/list.js') }}"></script>
@endsection
