@extends('admin/layouts/contentLayoutMaster')
@section('title', $kri->name)
@section('vendor-style')
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
@endsection
@section('content')
    @include('admin.content.strategic_planning.partials.heading', ['title' => $kri->name, 'permission' => null])
    <div class="row">
        <div class="col-lg-5">
            <div class="card"><div class="card-body">
                <p>{{ __('strategic.Current') }}: {{ $kri->current_value }} — {{ __('strategic.kri_levels.' . $kri->status) }}</p>
                <p>{{ __('strategic.Warning') }}: {{ $kri->warning_threshold }} | {{ __('strategic.Critical') }}: {{ $kri->critical_threshold }}</p>
                <p>{{ __('strategic.Direction') }}: {{ __('strategic.directions.' . $kri->direction) }}</p>
                <p>{{ __('strategic.Risk') }}: {{ $kri->risk_snapshot ?: optional($kri->risk)->subject }}</p>
                @if ($kri->risk)
                    <p>{{ __('strategic.InherentScore') }}: {{ optional($kri->risk->riskScoring)->calculated_risk }}</p>
                @endif
            </div></div>
            @if (\App\Services\Strategic\StrategicAccess::isAssigned(auth()->user(), $kri) && auth()->user()->hasPermission('strategic_kri.manage'))
                <form id="kri-measure" class="card"><div class="card-body">
                    @csrf
                    <input class="form-control mb-1" type="number" step="0.0001" name="actual_value" required>
                    <input class="form-control mb-1" type="date" name="measurement_date" required value="{{ now()->toDateString() }}">
                    <textarea class="form-control mb-1" name="comments"></textarea>
                    <button class="btn btn-primary" type="submit">{{ __('strategic.RecordMeasurement') }}</button>
                </div></form>
            @endif
        </div>
        <div class="col-lg-7">
            <table class="table card">
                <thead><tr><th>{{ __('strategic.DueDate') }}</th><th>{{ __('strategic.Current') }}</th><th>{{ __('strategic.Status') }}</th><th>{{ __('strategic.Comments') }}</th></tr></thead>
                <tbody>
                @foreach ($kri->measurements as $measurement)
                    <tr>
                        <td>{{ optional($measurement->measurement_date)->toDateString() }}</td>
                        <td>{{ $measurement->actual_value }}</td>
                        <td>{{ __('strategic.kri_levels.' . $measurement->breach_level) }}</td>
                        <td>{{ $measurement->comments }}</td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
@endsection
@section('page-script')
    <script>
        $('#kri-measure').on('submit', function (event) {
            event.preventDefault();
            $.post(@json(route('admin.strategic.kris.measurements.store', $kri->id)), $(this).serialize())
                .done(function () { window.location.reload(); })
                .fail(function (xhr) { toastr.error(xhr.responseJSON ? xhr.responseJSON.message : 'Error'); });
        });
    </script>
@endsection
