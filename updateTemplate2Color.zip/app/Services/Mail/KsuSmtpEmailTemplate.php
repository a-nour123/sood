<?php

namespace App\Services\Mail;

use PHPMailer\PHPMailer\PHPMailer;

/**
 * Shared KSU / cybersecurity branded HTML shell for all PHPMailer SMTP emails.
 * Idempotent: bodies already containing the shell marker are not wrapped twice.
 */
final class KsuSmtpEmailTemplate
{
    public const MARKER = 'ksu-grc-mail-shell';

    public static function wrap(string $body): string
    {
        if (str_contains($body, self::MARKER)) {
            return $body;
        }

        $logoPath = public_path('images/ksu-logo.png');

        $logoSrc = is_file($logoPath)
            ? 'cid:ksu_logo'
            : e(asset('images/ksu-logo.png'));

        $shell = <<<'HTML'
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<!-- ksu-grc-mail-shell -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="color-scheme" content="light">
<meta name="supported-color-schemes" content="light">

<style>
body {
    margin: 0;
    padding: 0;
    background-color: #e8eaed;
    direction: rtl !important;
}

table {
    border-collapse: collapse;
}

img {
    border: 0;
    outline: none;
    text-decoration: none;
    -ms-interpolation-mode: bicubic;
}

.ExternalClass {
    width: 100%;
}

.ExternalClass,
.ExternalClass p,
.ExternalClass span,
.ExternalClass td,
.ExternalClass div {
    line-height: 100%;
}
</style>

</head>

<body>

<table role="presentation"
       width="100%"
       cellspacing="0"
       cellpadding="0"
       style="background-color:#e8eaed;padding:24px 12px;">

<tr>
<td align="center">

<table role="presentation"
       width="600"
       cellspacing="0"
       cellpadding="0"
       style="max-width:600px;width:100%;background:#ffffff;border-radius:10px;overflow:hidden;">

    <!-- HEADER -->
    <tr>
        <td style="background-color:#1d70b8;padding:0;" dir="rtl">

            <!--[if mso]>
            <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
            <tr>
            <td align="right" style="padding:18px 24px 18px 12px;">
            <![endif]-->

            <table role="presentation"
                   width="100%"
                   cellspacing="0"
                   cellpadding="0">

                <tr>
                    <td align="right"
                        style="padding:18px 24px 18px 12px;text-align:right;">

                        <img
                            src="__LOGO_SRC__"
                            alt="جامعة الملك سعود"
                            width="130"
                            style="display:block;max-width:130px;height:auto;"
                        >

                    </td>
                </tr>

            </table>

            <!--[if mso]>
            </td>
            </tr>
            </table>
            <![endif]-->

        </td>
    </tr>

    <!-- BODY -->
    <tr>
        <td style="
            padding:32px 28px 36px 28px;
            background:#ffffff;
            color:#202124;
            font-size:15px;
            line-height:1.75;
            font-family:'Segoe UI',Tahoma,'Arabic UI Text','Noto Naskh Arabic',Arial,sans-serif;
            direction:rtl;
            text-align:right;
        ">
            __BODY__
        </td>
    </tr>

    <!-- FOOTER -->
    <tr>
        <td style="
            padding:14px 24px;
            background:#f3f4f6;
            border-top:1px solid #e8eaed;
            text-align:center;
        ">
            <p style="
                margin:0;
                color:#9aa0a6;
                font-size:11px;
                line-height:1.5;
                font-family:'Segoe UI',Tahoma,'Arabic UI Text',Arial,sans-serif;
            ">
                هذه رسالة آلية — يرجى عدم الرد على هذا البريد.
            </p>
        </td>
    </tr>

</table>

</td>
</tr>
</table>

</body>
</html>
HTML;

        return str_replace(
            ['__LOGO_SRC__', '__BODY__'],
            [$logoSrc, $body],
            $shell
        );
    }

    public static function embedKsuLogo(PHPMailer $mail): void
    {
        $ksuLogo = public_path('images/ksu-logo.png');

        if (
            is_file($ksuLogo) &&
            str_contains((string) $mail->Body, 'cid:ksu_logo')
        ) {
            $mail->addEmbeddedImage(
                $ksuLogo,
                'ksu_logo',
                'ksu-logo.png'
            );
        }
    }
}